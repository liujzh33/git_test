#!/bin/bash
set -euo pipefail

# Unified EEF Camera-Delta Wrist16 Training with VITRA + EgoDex + Xperience-10M
#
# Action representation: unified_eef_camera_delta_wrist16
# Layout: [left_delta_xyz_cam(3), left_delta_rotvec_cam(3), 0, 0,
#          right_delta_xyz_cam(3), right_delta_rotvec_cam(3), 0, 0]
#
# Reference camera: egocentric / head camera at anchor frame
# - VITRA: world-to-camera extrinsics
# - EgoDex: camera transform from HDF5
# - Xperience: SLAM pose + calibration T_c_b

TASK="cross_dataset_mixed_unified_eef_wrist16_xperience10m"
CONFIG_FILE="configs/motusv1_adapted/cross_dataset_mixed_unified_eef_wrist16_xperience10m.yaml"

export OUTPUT_DIR="outputs/motus-${TASK}"

if [ ! -d "$OUTPUT_DIR" ]; then
    mkdir -p "$OUTPUT_DIR"
    echo "Folder '$OUTPUT_DIR' created"
else
    echo "Folder '$OUTPUT_DIR' already exists"
fi

NNODES=${WORLD_SIZE:-${VC_WORKER_NUM:-1}}
NODE_RANK=${VC_TASK_INDEX:-0}
MASTER_ADDR=${MASTER_ADDR:-${DOLPHIN_MASTER_IP:-127.0.0.1}}
MASTER_PORT=${MASTER_PORT:-23456}
# NPROC_PER_NODE=${NPROC_PER_NODE:-8}

# Let the user set CUDA_VISIBLE_DEVICES externally; default to all visible GPUs.
NPROC_PER_NODE=${NPROC_PER_NODE:-2}

echo "===== distributed config ====="
echo "HOSTNAME=$(hostname)"
echo "NNODES=$NNODES"
echo "NODE_RANK=$NODE_RANK"
echo "MASTER_ADDR=$MASTER_ADDR"
echo "MASTER_PORT=$MASTER_PORT"
echo "NPROC_PER_NODE=$NPROC_PER_NODE"
echo "CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-}"
echo "NVIDIA_VISIBLE_DEVICES=${NVIDIA_VISIBLE_DEVICES:-}"
echo "=============================="

echo ""
echo "===== training config ====="
echo "TASK=$TASK"
echo "CONFIG_FILE=$CONFIG_FILE"
echo "OUTPUT_DIR=$OUTPUT_DIR"
echo "Action representation: unified_eef_camera_delta_wrist16"
echo "Datasets: VITRA + EgoDex + Xperience-10M"
echo "==========================="
echo ""

torchrun \
    --nnodes=${NNODES} \
    --nproc_per_node=${NPROC_PER_NODE} \
    --node_rank=${NODE_RANK} \
    --master_addr=${MASTER_ADDR} \
    --master_port=${MASTER_PORT} \
    train/train_wan_vlm_mask.py \
    --deepspeed configs/zero1.json \
    --config ${CONFIG_FILE} \
    --run_name ${TASK} \
    --report_to tensorboard

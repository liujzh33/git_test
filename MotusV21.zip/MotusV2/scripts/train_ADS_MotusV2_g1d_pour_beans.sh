#!/bin/bash
# G1-D pour-beans-eps380 (Unitree G1D mobile + Dex1, LeRobot v3.0) post-training
# — 16-dim qpos joint-position action (manipulation only), T-shape stitched cameras.
#
# Usage:
#   bash scripts/train_ADS_MotusV2_g1d_pour_beans.sh
#
# Pre-req (once, single process):
#   python scripts/prepopulate_g1d_t5_cache.py \
#       --config configs/g1d_pour_beans_wan_vlm_mask.yaml
#
# Smoke test (few steps, no checkpoint save):
#   bash scripts/train_ADS_MotusV2_g1d_pour_beans.sh --max_steps 20
set -euo pipefail

TASK="g1d_pour_beans_wan_vlm_mask"
CONFIG_FILE="configs/g1d_pour_beans_wan_vlm_mask.yaml"

export OUTPUT_DIR="outputs/motus-${TASK}"

if [ ! -d "$OUTPUT_DIR" ]; then
    mkdir -p "$OUTPUT_DIR"
    echo "Folder '$OUTPUT_DIR' created"
else
    echo "Folder '$OUTPUT_DIR' already exists"
fi

NNODES=${WORLD_SIZE:-${VC_WORKER_NUM:-1}}
NODE_RANK=${VC_TASK_INDEX:-0}
MASTER_ADDR=${MASTER_ADDR:-${DOLPHIN_MASTER_IP:-127.0.0.1}}
MASTER_PORT=${MASTER_PORT:-23456}
NPROC_PER_NODE=${NPROC_PER_NODE:-8}

PYTHON_BIN="${PYTHON_BIN:-$(command -v python)}"

echo "===== distributed config ====="
echo "HOSTNAME=$(hostname)"
echo "NNODES=$NNODES"
echo "NODE_RANK=$NODE_RANK"
echo "MASTER_ADDR=$MASTER_ADDR"
echo "MASTER_PORT=$MASTER_PORT"
echo "NPROC_PER_NODE=$NPROC_PER_NODE"
echo "PYTHON_BIN=$PYTHON_BIN"
echo "CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-}"
echo "NVIDIA_VISIBLE_DEVICES=${NVIDIA_VISIBLE_DEVICES:-}"
echo "=============================="

LOG_FILE="${OUTPUT_DIR}/console_$(date '+%Y%m%d_%H%M%S').log"

EXTRA_ARGS="$*"

"${PYTHON_BIN}" -m torch.distributed.run \
    --nnodes=${NNODES} \
    --nproc_per_node=${NPROC_PER_NODE} \
    --node_rank=${NODE_RANK} \
    --master_addr=${MASTER_ADDR} \
    --master_port=${MASTER_PORT} \
    train/train_wan_vlm_mask.py \
    --deepspeed configs/zero1.json \
    --config ${CONFIG_FILE} \
    --init_weights "/home/work/wenjj/pretrained_models/WanVlmMask_G1D_PickKettleEps89_5W_v2" \
    --run_name ${TASK} \
    --report_to tensorboard \
    ${EXTRA_ARGS} \
    2>&1 | tee "$LOG_FILE"

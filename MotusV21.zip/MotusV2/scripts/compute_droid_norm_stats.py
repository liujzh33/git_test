#!/usr/bin/env python3
"""Compute DROID q01/q99 normalization stats for state and delta-action targets.

The absolute-action quantiles in ``meta/stats.json`` are not usable directly:
the model regresses ``action[t+k] - state[t]`` on the arm dims (see
``data/droid/droid_norm.py``), whose distribution is ~3x narrower and centered
at zero.  This script streams the parquet files, builds the exact targets the
dataset will produce, and writes the stats file both training and inference read.

Usage:
  python scripts/compute_droid_norm_stats.py \
      --dataset-dir /cache/wx1469573/data/droid1.0.1-lerobot \
      --out data/droid/droid_norm_stats.json

  # quick pass over a subset
  python scripts/compute_droid_norm_stats.py --max-files 20
"""
from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from data.droid.droid_filter import (  # noqa: E402
    DEFAULT_MIN_IDLE_LEN,
    DEFAULT_MIN_NON_IDLE_LEN,
    DEFAULT_TRIM_LAST_N,
    compute_keep_ranges,
    sampleable_windows,
)
from data.droid.droid_norm import DEFAULT_DELTA_MASK, STATS_VERSION  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("compute_droid_norm_stats")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset-dir", default="/cache/wx1469573/data/droid1.0.1-lerobot")
    ap.add_argument("--out", default=str(Path(__file__).resolve().parent.parent / "data/droid/droid_norm_stats.json"))
    ap.add_argument("--action-chunk-size", type=int, default=16)
    ap.add_argument("--global-downsample-rate", type=int, default=1)
    ap.add_argument("--max-files", type=int, default=0, help="0 = all parquet files")
    ap.add_argument("--stride", type=int, default=20,
                    help="sample every Nth condition frame within an episode. Controls "
                         "memory, not accuracy: neighbouring frames of one episode are "
                         "near-duplicates for quantile estimation.")
    ap.add_argument("--max-episodes", type=int, default=0,
                    help="0 = every episode. Budgeting by EPISODES (not rows) is what "
                         "makes the result independent of --stride; episode coverage is "
                         "what the quantiles actually depend on.")
    ap.add_argument("--seed", type=int, default=0,
                    help="seed for per-file episode subsampling")
    # Must mirror the dataset's filtering, otherwise the normalizer is fitted to
    # a different distribution than the one actually trained on.
    ap.add_argument("--no-require-success", action="store_true")
    ap.add_argument("--no-filter-idle", action="store_true")
    ap.add_argument("--idle-min-len", type=int, default=DEFAULT_MIN_IDLE_LEN)
    ap.add_argument("--idle-min-non-idle-len", type=int, default=DEFAULT_MIN_NON_IDLE_LEN)
    ap.add_argument("--idle-trim-last-n", type=int, default=DEFAULT_TRIM_LAST_N)
    args = ap.parse_args()

    require_success = not args.no_require_success
    filter_idle = not args.no_filter_idle

    import pandas as pd

    data_root = Path(args.dataset_dir) / "data"
    files = sorted(data_root.rglob("*.parquet"))
    if not files:
        raise FileNotFoundError(f"No parquet files under {data_root}")
    rng = np.random.default_rng(args.seed)
    if args.max_files > 0:
        # Take an even spread rather than a prefix: DROID parquet files are
        # grouped by collection batch, so a prefix covers only a few labs.
        files = [files[i] for i in np.linspace(0, len(files) - 1, args.max_files).astype(int)]
    # Every file contributes an equal share of the episode budget.  The previous
    # behaviour -- stop as soon as --max-samples rows were collected -- silently
    # restricted the quantiles to whichever files came first AND made the result
    # depend on --stride, since a denser stride exhausted the row budget after
    # fewer episodes.  Budgeting by episodes removes both effects.
    per_file_eps = (max(1, args.max_episodes // max(1, len(files)))
                    if args.max_episodes > 0 else None)
    logger.info(f"scanning {len(files)} parquet files, "
                f"{'all' if per_file_eps is None else per_file_eps} episodes each "
                f"(stride={args.stride}, seed={args.seed})")

    delta_mask = np.asarray(DEFAULT_DELTA_MASK, dtype=bool)
    states, targets = [], []
    n_rows = 0

    cols = ["episode_index", "observation.state", "action"]
    if require_success:
        cols.append("is_episode_successful")
    if filter_idle:
        cols.append("action.joint_velocity")
    n_ep = n_ep_kept = 0

    for fi, pf in enumerate(files):
        try:
            df = pd.read_parquet(pf, columns=cols)
        except Exception as e:  # noqa: BLE001
            logger.warning(f"skip {pf}: {e}")
            continue
        # Visit this file's episodes in random order so a per-file cap does not
        # favour low episode indices.
        ep_ids = list(df["episode_index"].unique())
        rng.shuffle(ep_ids)
        if per_file_eps is not None:
            ep_ids = ep_ids[:per_file_eps]
        for ep_id in ep_ids:
            g = df[df["episode_index"] == ep_id]
            n_ep += 1
            if require_success and not bool(np.asarray(g["is_episode_successful"].iloc[0]).ravel()[0]):
                continue
            st = np.stack(g["observation.state"].to_numpy()).astype(np.float32)
            ac = np.stack(g["action"].to_numpy()).astype(np.float32)
            T = len(st)
            span = args.action_chunk_size * args.global_downsample_rate
            if T < span + 2:
                continue

            if filter_idle:
                jv = np.stack(g["action.joint_velocity"].to_numpy()).astype(np.float32)
                windows = sampleable_windows(
                    compute_keep_ranges(
                        jv,
                        min_idle_len=args.idle_min_len,
                        min_non_idle_len=args.idle_min_non_idle_len,
                        trim_last_n=args.idle_trim_last_n,
                    ),
                    span,
                )
            else:
                windows = [(0, T - span - 1)]
            if not windows:
                continue
            n_ep_kept += 1

            # Keep each valid condition frame independently with probability
            # 1/stride.  A deterministic range(lo, hi, stride) would always take
            # the first frame of every window, which over-weights short windows
            # (a 60-frame window yields 2 samples at stride 50 while a 300-frame
            # one yields 6, instead of 1 vs 5) and makes the quantiles drift with
            # --stride.  Bernoulli sampling is unbiased: stride then changes only
            # the variance, not the estimate.
            for lo, hi in windows:
                hi = min(hi, T - span - 1)
                if hi <= lo:
                    continue
                pos = np.arange(lo, hi)
                if args.stride > 1:
                    pos = pos[rng.random(len(pos)) < 1.0 / args.stride]
                for t in pos:
                    idx = np.minimum(
                        t + np.arange(1, args.action_chunk_size + 1) * args.global_downsample_rate,
                        T - 1,
                    )
                    chunk = ac[idx]
                    states.append(st[t])
                    targets.append(chunk - np.where(delta_mask, st[t], 0.0)[None, :])
                    n_rows += len(chunk)
        if (fi + 1) % 20 == 0:
            logger.info(f"  {fi + 1}/{len(files)} files, {n_rows} target rows, "
                        f"{n_ep_kept} episodes kept")

    if not targets:
        raise RuntimeError("no samples collected")

    S = np.stack(states, 0)
    A = np.concatenate(targets, 0)
    logger.info(f"collected {len(S)} states, {len(A)} action rows "
                f"from {n_ep_kept}/{n_ep} episodes that passed filtering")

    stats = {
        "version": STATS_VERSION,
        "delta_mask": [bool(x) for x in delta_mask],
        "dataset_dir": str(args.dataset_dir),
        "action_chunk_size": args.action_chunk_size,
        "global_downsample_rate": args.global_downsample_rate,
        # Recorded so a stats file fitted under different filtering is spottable.
        "filters": {
            "require_success": require_success,
            "filter_idle": filter_idle,
            "idle_min_len": args.idle_min_len,
            "idle_min_non_idle_len": args.idle_min_non_idle_len,
            "idle_trim_last_n": args.idle_trim_last_n,
        },
        "num_state_samples": int(len(S)),
        "num_action_rows": int(len(A)),
        "num_files_scanned": int(len(files)),
        "num_episodes_scanned": int(n_ep),
        "num_episodes_kept": int(n_ep_kept),
        "stride": int(args.stride),
        "state": {
            "q01": np.quantile(S, 0.01, axis=0).tolist(),
            "q99": np.quantile(S, 0.99, axis=0).tolist(),
            "mean": S.mean(0).tolist(),
            "std": S.std(0).tolist(),
        },
        "action": {
            "q01": np.quantile(A, 0.01, axis=0).tolist(),
            "q99": np.quantile(A, 0.99, axis=0).tolist(),
            "mean": A.mean(0).tolist(),
            "std": A.std(0).tolist(),
        },
    }

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, "w", encoding="utf-8") as f:
        json.dump(stats, f, indent=2)

    np.set_printoptions(precision=4, suppress=True, linewidth=200)
    logger.info(f"wrote {out}")
    logger.info(f"  action target q01 = {np.array(stats['action']['q01'])}")
    logger.info(f"  action target q99 = {np.array(stats['action']['q99'])}")
    logger.info(f"  action target std = {np.array(stats['action']['std'])}")
    logger.info(f"  state q01         = {np.array(stats['state']['q01'])}")
    logger.info(f"  state q99         = {np.array(stats['state']['q99'])}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

#!/bin/bash
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PROJECT_ROOT"

CONFIG_FILE="${CONFIG_FILE:-configs/robotwin_wan_vlm_mask_stage2_reweight_posttrain.yaml}"
TASKS_FILE="${TASKS_FILE:-policy/MotusWanVlmDirectMaskMotion/tasks_all_new.txt}"
DEEPSPEED_CONFIG="${DEEPSPEED_CONFIG:-configs/zero1.json}"

PRETRAINED_WEIGHTS_DIR="${1:-${PRETRAINED_WEIGHTS_DIR:-}}"
if [ -z "$PRETRAINED_WEIGHTS_DIR" ]; then
    echo "Usage: bash $0 /path/to/pretrained_weights_dir [run_name]"
    echo "The directory must contain mp_rank_00_model_states.pt and config.json."
    echo "Or set PRETRAINED_WEIGHTS_DIR in the environment."
    exit 2
fi
if [ ! -d "$PRETRAINED_WEIGHTS_DIR" ]; then
    echo "Pre-trained weights directory not found: $PRETRAINED_WEIGHTS_DIR"
    exit 2
fi
if [ ! -f "$PRETRAINED_WEIGHTS_DIR/mp_rank_00_model_states.pt" ]; then
    echo "Missing: $PRETRAINED_WEIGHTS_DIR/mp_rank_00_model_states.pt"
    exit 2
fi
if [ ! -f "$PRETRAINED_WEIGHTS_DIR/config.json" ]; then
    echo "Missing: $PRETRAINED_WEIGHTS_DIR/config.json"
    exit 2
fi

MAX_STEPS="${MAX_STEPS:-40000}"
RUN_NAME="${2:-${RUN_NAME:-robotwin_stage2_reweight_40k}}"

OUTPUT_DIR="${OUTPUT_DIR:-outputs/motus-${RUN_NAME}}"
mkdir -p "$OUTPUT_DIR"

NNODES="${WORLD_SIZE:-${VC_WORKER_NUM:-1}}"
NODE_RANK="${VC_TASK_INDEX:-0}"
MASTER_ADDR="${MASTER_ADDR:-${DOLPHIN_MASTER_IP:-127.0.0.1}}"
MASTER_PORT="${MASTER_PORT:-23456}"

if [ -z "${CUDA_VISIBLE_DEVICES:-}" ]; then
    export CUDA_VISIBLE_DEVICES="0,1,2,3,4,5,6,7"
fi
IFS=',' read -r -a CUDA_DEVICE_ARRAY <<< "$CUDA_VISIBLE_DEVICES"
NPROC_PER_NODE="${NPROC_PER_NODE:-${#CUDA_DEVICE_ARRAY[@]}}"

echo "===== task sampling preview ====="
PYTHONDONTWRITEBYTECODE=1 python scripts/inspect_robotwin_task_sampling.py \
    --config "$CONFIG_FILE" \
    --tasks-file "$TASKS_FILE"

echo "===== post-training config ====="
echo "HOSTNAME=$(hostname)"
echo "CONFIG_FILE=$CONFIG_FILE"
echo "PRETRAINED_WEIGHTS_DIR=$PRETRAINED_WEIGHTS_DIR"
echo "GLOBAL_STEP_START=0"
echo "MAX_STEPS=$MAX_STEPS"
echo "RUN_NAME=$RUN_NAME"
echo "NNODES=$NNODES"
echo "NODE_RANK=$NODE_RANK"
echo "MASTER_ADDR=$MASTER_ADDR"
echo "MASTER_PORT=$MASTER_PORT"
echo "NPROC_PER_NODE=$NPROC_PER_NODE"
echo "CUDA_VISIBLE_DEVICES=$CUDA_VISIBLE_DEVICES"
echo "OUTPUT_DIR=$OUTPUT_DIR"
echo "================================"

if [ "${DRY_RUN:-0}" = "1" ]; then
    echo "DRY_RUN=1; configuration validated, skipping torchrun."
    exit 0
fi

LOG_FILE="${OUTPUT_DIR}/console_$(date '+%Y%m%d_%H%M%S').log"

torchrun \
    --nnodes="$NNODES" \
    --nproc_per_node="$NPROC_PER_NODE" \
    --node_rank="$NODE_RANK" \
    --master_addr="$MASTER_ADDR" \
    --master_port="$MASTER_PORT" \
    train/train_wan_vlm_mask.py \
    --deepspeed "$DEEPSPEED_CONFIG" \
    --config "$CONFIG_FILE" \
    --init_weights "$PRETRAINED_WEIGHTS_DIR" \
    --max_steps "$MAX_STEPS" \
    --run_name "$RUN_NAME" \
    --report_to tensorboard \
    2>&1 | tee "$LOG_FILE"

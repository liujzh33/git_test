#!/bin/bash
set -euo pipefail

TASK="robotwin_unified_eef_wan_vlm_mask"
CONFIG_FILE="configs/robotwin_unified_eef_wan_vlm_mask.yaml"

export OUTPUT_DIR="outputs/motus-${TASK}"

if [ ! -d "$OUTPUT_DIR" ]; then
    mkdir -p "$OUTPUT_DIR"
    echo "Folder '$OUTPUT_DIR' created"
else
    echo "Folder '$OUTPUT_DIR' already exists"
fi

NNODES=${WORLD_SIZE:-${VC_WORKER_NUM:-1}}
NODE_RANK=${VC_TASK_INDEX:-0}
MASTER_ADDR=${MASTER_ADDR:-${DOLPHIN_MASTER_IP:-127.0.0.1}}
MASTER_PORT=${MASTER_PORT:-23456}
NPROC_PER_NODE=${NPROC_PER_NODE:-8}

# export CUDA_VISIBLE_DEVICES=4,5,6,7
# NPROC_PER_NODE=${NPROC_PER_NODE:-4}

echo "===== distributed config ====="
echo "HOSTNAME=$(hostname)"
echo "NNODES=$NNODES"
echo "NODE_RANK=$NODE_RANK"
echo "MASTER_ADDR=$MASTER_ADDR"
echo "MASTER_PORT=$MASTER_PORT"
echo "NPROC_PER_NODE=$NPROC_PER_NODE"
echo "CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-}"
echo "NVIDIA_VISIBLE_DEVICES=${NVIDIA_VISIBLE_DEVICES:-}"
echo "=============================="

LOG_FILE="${OUTPUT_DIR}/console_$(date '+%Y%m%d_%H%M%S').log"

torchrun \
    --nnodes=${NNODES} \
    --nproc_per_node=${NPROC_PER_NODE} \
    --node_rank=${NODE_RANK} \
    --master_addr=${MASTER_ADDR} \
    --master_port=${MASTER_PORT} \
    train/train_wan_vlm_mask.py \
    --deepspeed configs/zero1.json \
    --config ${CONFIG_FILE} \
    --run_name ${TASK} \
    --report_to tensorboard \
    2>&1 | tee "$LOG_FILE"

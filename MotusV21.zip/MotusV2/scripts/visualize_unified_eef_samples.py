#!/usr/bin/env python3
"""Visualize unified_eef_camera_delta_wrist16 samples per dataset.

For each dataset (VITRA x4 sub-datasets, EgoDex, Xperience-10M) this script:
  1. Builds the dataset with the REAL experiment config (exercising the
     production code path), with t5_mode='none' to skip the T5 encoder.
  2. Picks the first valid episode+frame deterministically.
  3. Calls the dataset's own extraction methods to get state / action /
     action_valid_mask (the exact tensors training would see).
  4. Re-reads the raw per-frame camera poses + intrinsics + native-res video.
  5. Reconstructs the hand EEF trajectory in the frame-0 camera frame from
     state + action, projects it onto EACH video frame, and renders an mp4
     with the trajectory overlaid + a side panel of the 16-d action/state.

If the camera-frame processing is correct, the overlaid dots sit on the actual
hands and move with them across frames. A numerical self-check compares the
state+action reconstruction against the raw world poses projected to the
frame-0 camera frame (should match to ~1e-5).

Reconstruction math (see data/human/unified_eef_action.py):
  state[:3]      = R_w_c[0].T @ (t_w_e_left[0]  - t_w_c[0])   (left,  frame-0 cam)
  state[8:11]    = R_w_c[0].T @ (t_w_e_right[0] - t_w_c[0])   (right, frame-0 cam)
  action[i][:3]  = R_w_c[0].T @ (t_w_e_left[i+1]  - t_w_e_left[0])   (anchor delta)
  action[i][8:11]= R_w_c[0].T @ (t_w_e_right[i+1] - t_w_e_right[0])
  => p_cam0[i] = state[:3] + action[i-1][:3]   (left),  state[8:11] + action[i-1][8:11]  (right)
  Overlay on frame i: p_world = R_w_c[0] @ p_cam0 + t_w_c[0]
                      p_cam_i = R_w_c[i].T @ (p_world - t_w_c[i])
                      pixel   = K @ (p_cam_i / p_cam_i[2])   if p_cam_i[2] > 0
"""

import argparse
import logging
import os
import sys
import types
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import cv2
import h5py
import numpy as np
import torch

# --- heavy optional dep stubs (matches tests/ pattern) ---
try:
    import qwen_vl_utils  # noqa: F401
except Exception:
    _m = types.ModuleType("qwen_vl_utils")
    _m.process_vision_info = lambda *a, **k: (None, None)
    sys.modules.setdefault("qwen_vl_utils", _m)

from omegaconf import OmegaConf

logging.basicConfig(level=logging.INFO, format="[%(levelname)s] %(name)s - %(message)s")
logger = logging.getLogger("viz_unified_eef")

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from data.dataset import create_dataset  # real builder
from data.human.unified_eef_action import build_camera_world_pose_from_slam
from data.human.vitra_core import load_video_decord  # native decord loader

# 16-d layout constants
LEFT_T_SLICE = slice(0, 3)
RIGHT_T_SLICE = slice(8, 11)
LEFT_MASK_SLICE = slice(0, 6)
RIGHT_MASK_SLICE = slice(8, 14)

LEFT_COLOR = (255, 128, 0)    # orange (BGR)
RIGHT_COLOR = (0, 128, 255)   # blue (BGR)
ANCHOR_COLOR = (0, 0, 255)    # red (BGR)


# --------------------------------------------------------------------------- #
# Dataset construction
# --------------------------------------------------------------------------- #
def build_datasets(config_path: str) -> List[Tuple[str, Any]]:
    """Build all datasets via the real config; return [(name, ds), ...]."""
    cfg = OmegaConf.load(config_path)
    # Skip the T5 encoder and VLM processor entirely (not needed for viz).
    cfg.dataset.params.t5_mode = "none"
    if hasattr(cfg, "model") and hasattr(cfg.model, "vlm"):
        cfg.model.vlm.checkpoint_path = None

    mwd = create_dataset(cfg, val=False)
    sub_cfgs = list(cfg.dataset.datasets)
    names = []
    for c in sub_cfgs:
        t = c.get("type")
        if t == "vitra_human":
            names.append(f"vitra_{c.get('name', 'x')}")
        else:
            names.append(str(t))
    assert len(names) == len(mwd.datasets), (len(names), len(mwd.datasets))
    return list(zip(names, mwd.datasets))


# --------------------------------------------------------------------------- #
# Generic helpers
# --------------------------------------------------------------------------- #
def decord_native_frames(mp4_path: str, frame_indices: List[int]) -> np.ndarray:
    """Load native-res RGB frames (T, H, W, 3) uint8 via decord."""
    import decord
    vr = decord.VideoReader(str(mp4_path), num_threads=1)
    n = len(vr)
    safe = [min(max(int(i), 0), n - 1) for i in frame_indices]
    batch = vr.get_batch(safe).asnumpy()
    if batch.shape[-1] == 4:
        batch = batch[..., :3]
    return batch.astype(np.uint8)


def project_to_frame(p_cam0: np.ndarray, R_w_c0: np.ndarray, t_w_c0: np.ndarray,
                     R_w_c_i: np.ndarray, t_w_c_i: np.ndarray, K: np.ndarray
                     ) -> Tuple[Optional[np.ndarray], float]:
    """Project a frame-0-camera-frame 3D point onto frame i's image.

    Returns (pixel_xy (2,) or None, depth_in_frame_i).
    """
    p_world = R_w_c0 @ p_cam0 + t_w_c0
    p_cam_i = R_w_c_i.T @ (p_world - t_w_c_i)
    if p_cam_i[2] <= 1e-4:
        return None, float(p_cam_i[2])
    uv = K @ (p_cam_i / p_cam_i[2])
    return uv[:2], float(p_cam_i[2])


def reconstruct_trajectory(state: np.ndarray, action: np.ndarray, n_frames: int
                           ) -> Tuple[np.ndarray, np.ndarray]:
    """Reconstruct absolute hand positions in frame-0 camera frame.

    Returns (left (F+1,3), right (F+1,3)) where F = n_frames (action length).
    Index 0 is the anchor (state), index i+1 = state + action[i].
    """
    F = action.shape[0]
    left = np.zeros((F + 1, 3), dtype=np.float64)
    right = np.zeros((F + 1, 3), dtype=np.float64)
    left[0] = state[LEFT_T_SLICE]
    right[0] = state[RIGHT_T_SLICE]
    for i in range(F):
        left[i + 1] = state[LEFT_T_SLICE] + action[i][LEFT_T_SLICE]
        right[i + 1] = state[RIGHT_T_SLICE] + action[i][RIGHT_T_SLICE]
    return left, right


def gt_trajectory_frame0(t_w_e: np.ndarray, R_w_c0: np.ndarray, t_w_c0: np.ndarray) -> np.ndarray:
    """Ground-truth hand positions in frame-0 camera frame from raw world poses."""
    # t_w_e: (W, 3); R_w_c0 maps cam->world, so cam = R_w_c0.T @ (world - t_w_c0)
    return (R_w_c0.T @ (t_w_e - t_w_c0).T).T  # (W, 3)


# --------------------------------------------------------------------------- #
# Per-dataset collectors
# Each returns a dict with:
#   native_frames: (F+1, H, W, 3) uint8 RGB
#   K: (3, 3) intrinsics matching native_frames
#   R_w_c_list: (F+1, 3, 3) camera rotation in world per frame
#   t_w_c_list: (F+1, 3) camera position in world per frame
#   gt_left_world: (F+1, 3) raw left hand world positions
#   gt_right_world: (F+1, 3) raw right hand world positions
#   state: (16,), action: (F, 16), action_mask: (F, 16)
#   label: str
# --------------------------------------------------------------------------- #
def collect_xperience(ds, n_samples: int) -> List[dict]:
    import h5py
    out = []
    F = ds.num_video_frames
    for ep in ds.episodes:
        if len(out) >= n_samples:
            break
        h5_path = ep["h5_path"]
        mp4_path = ep["mp4_path"]
        n_frames = ep["n_frames"]
        frame_idx = min(F, n_frames - F - 1)
        if frame_idx < 0:
            continue
        try:
            actions, state, action_masks, instruction = ds._extract_unified_eef_action_state(h5_path, frame_idx)
        except Exception as e:
            logger.info(f"xperience skip {ep['seq_name']}/{ep['ep_name']}: {e}")
            continue
        if not np.any(action_masks):
            continue
        with h5py.File(h5_path, "r") as f:
            slam_trans = f["slam/trans_xyz"][:]
            slam_quat = f["slam/quat_wxyz"][:]
            T_c_b = f["calibration/cam0/T_c_b"][:]
            K_raw = f["calibration/cam0/K"][:]  # [fx, fy, cx, cy]
            left_t_w = f["hand_mocap/left_translation"][:].astype(np.float64)
            right_t_w = f["hand_mocap/right_translation"][:].astype(np.float64)
        K = np.array([[K_raw[0], 0, K_raw[2]], [0, K_raw[1], K_raw[3]], [0, 0, 1]], dtype=np.float64)

        W = F + 1
        win = np.arange(frame_idx, frame_idx + W)
        R_w_c_list = np.zeros((W, 3, 3))
        t_w_c_list = np.zeros((W, 3))
        for j, fi in enumerate(win):
            R_w_c_list[j], t_w_c_list[j] = build_camera_world_pose_from_slam(
                slam_trans[fi], slam_quat[fi], T_c_b)
        native = decord_native_frames(mp4_path, win.tolist())
        out.append(dict(
            native_frames=native, K=K,
            R_w_c_list=R_w_c_list.astype(np.float64), t_w_c_list=t_w_c_list.astype(np.float64),
            gt_left_world=left_t_w[win], gt_right_world=right_t_w[win],
            state=np.asarray(state, dtype=np.float64),
            action=np.asarray(actions, dtype=np.float64),
            action_mask=np.asarray(action_masks, dtype=bool),
            label=f"xperience/{ep['seq_name']}/{ep['ep_name']}@f{frame_idx}",
        ))
    return out


def collect_egodex(ds, n_samples: int) -> List[dict]:
    out = []
    F = ds.num_video_frames
    for ep in ds.episodes:
        if len(out) >= n_samples:
            break
        h5_path = ep["h5_path"]
        mp4_path = ep["mp4_path"]
        n_frames = ep["n_frames"]
        frame_idx = min(F, n_frames - F - 1)
        if frame_idx < 0:
            continue
        try:
            actions, state, action_masks, instruction = ds._extract_unified_eef_action_state(h5_path, frame_idx)
        except Exception as e:
            logger.info(f"egodex skip {Path(h5_path).name}: {e}")
            continue
        if not np.any(action_masks):
            continue
        (left_tfs, right_tfs, cam_tfs, *_rest) = ds._read_raw_transforms(h5_path, frame_idx)
        with h5py.File(h5_path, "r") as f:
            K = np.asarray(f["/camera/intrinsic"][:], dtype=np.float64)
        if K.shape == (4,):
            K = np.array([[K[0], 0, K[2]], [0, K[1], K[3]], [0, 0, 1]], dtype=np.float64)

        W = F + 1
        win = np.array([min(frame_idx + j, len(cam_tfs) - 1) for j in range(W)])
        R_w_c_list = cam_tfs[win, :3, :3].astype(np.float64)
        t_w_c_list = cam_tfs[win, :3, 3].astype(np.float64)
        native = decord_native_frames(mp4_path, win.tolist())
        out.append(dict(
            native_frames=native, K=K,
            R_w_c_list=R_w_c_list, t_w_c_list=t_w_c_list,
            gt_left_world=left_tfs[win, :3, 3].astype(np.float64),
            gt_right_world=right_tfs[win, :3, 3].astype(np.float64),
            state=np.asarray(state, dtype=np.float64),
            action=np.asarray(actions, dtype=np.float64),
            action_mask=np.asarray(action_masks, dtype=bool),
            label=f"egodex/{Path(h5_path).parent.name}/{Path(h5_path).stem}@f{frame_idx}",
        ))
    return out


def _vitra_native_frames(ds, episode_id: str, frame_id: int) -> Tuple[np.ndarray, np.ndarray]:
    """Load native-res RGB frames for the window [frame_id .. frame_id+F].

    Mirrors VitraHumanMotusDataset._load_video_window but skips resize_with_padding.
    Returns (frames (F+1,H,W,3) uint8, idx_win).
    """
    epi, _, _ = ds.core._load_or_cache_episode(episode_id)
    T = len(epi["extrinsics"])
    idx_win, _ = ds.core._window_indices(frame_id, 0, ds.num_video_frames, 0, T - 1)
    decode_table = epi["video_decode_frame"]
    decode_ids = decode_table[idx_win].tolist()

    dataset_prefix = episode_id.split("_")[0]
    video_name = epi["video_name"]
    part_to_local: Dict[int, List[Tuple[int, int]]] = {}
    for pos, full_idx in enumerate(decode_ids):
        if ds.clip_len is None:
            part_idx, frame_in_part = 0, int(full_idx)
        else:
            part_idx = int(full_idx) // int(ds.clip_len)
            frame_in_part = int(full_idx) % int(ds.clip_len)
        part_to_local.setdefault(part_idx, []).append((pos, frame_in_part))

    images: List[Optional[np.ndarray]] = [None] * len(decode_ids)
    for part_idx, pairs in part_to_local.items():
        video_path = ds.core._resolve_video_path(dataset_prefix, video_name, part_idx)
        frame_list = [p[1] for p in pairs]
        imgs, _ = load_video_decord(video_path, frame_index=frame_list, rotation=False)
        for (pos, _), img in zip(pairs, imgs):
            images[pos] = img
    frames = np.stack(images, axis=0)
    if frames.shape[-1] == 4:
        frames = frames[..., :3]
    return frames.astype(np.uint8), idx_win


def collect_vitra(ds, n_samples: int) -> List[dict]:
    out = []
    F = ds.num_video_frames
    core = ds.core
    # iterate (data_id, episode_id, frame_id) in order; take first valid
    for data_id in range(len(core)):
        if len(out) >= n_samples:
            break
        corr = core.index_frame_pair[data_id]
        episode_id = core.index_to_episode_id[corr[0]]
        frame_id = int(corr[1])
        try:
            sample = ds._get_unified_eef_sample(episode_id, frame_id)
        except Exception as e:
            logger.info(f"vitra skip {episode_id}@f{frame_id}: {e}")
            continue
        state = sample["initial_state"].numpy().astype(np.float64)
        action = sample["action_sequence"].numpy().astype(np.float64)
        action_mask = sample["action_valid_mask"].numpy().astype(bool)
        if not np.any(action_mask):
            continue

        epi, R_w2c, t_w2c = core._load_or_cache_episode(episode_id)
        K = np.asarray(epi["intrinsics"], dtype=np.float64).copy()
        if K.shape == (4,):
            K = np.array([[K[0], 0, K[2]], [0, K[1], K[3]], [0, 0, 1]], dtype=np.float64)

        # window of frames used by _get_unified_eef_sample: action_past=0, so [frame_id .. frame_id+F]
        W = F + 1
        win = np.arange(frame_id, frame_id + W)
        win = np.clip(win, 0, len(R_w2c) - 1)
        R_w_c_list = np.stack([R_w2c[i].T for i in win])              # (W,3,3)
        t_w_c_list = np.stack([-R_w2c[i].T @ t_w2c[i] for i in win])  # (W,3)

        left_t_w = epi["left"]["transl_worldspace"][win].astype(np.float64)
        right_t_w = epi["right"]["transl_worldspace"][win].astype(np.float64)

        native, _ = _vitra_native_frames(ds, episode_id, frame_id)
        # Defensive: rescale K if native frame size != intrinsics implied size.
        H, Wp = native.shape[1], native.shape[2]
        orig_h = 2 * K[1, 2]
        orig_w = 2 * K[0, 2]
        if orig_h > 0 and orig_w > 0 and (abs(orig_h - H) > 1 or abs(orig_w - Wp) > 1):
            sx, sy = Wp / orig_w, H / orig_h
            K = K.copy()
            K[0, 0] *= sx; K[0, 2] *= sx
            K[1, 1] *= sy; K[1, 2] *= sy

        out.append(dict(
            native_frames=native, K=K,
            R_w_c_list=R_w_c_list, t_w_c_list=t_w_c_list,
            gt_left_world=left_t_w, gt_right_world=right_t_w,
            state=state, action=action, action_mask=action_mask,
            label=f"{ds.dataset_name}/{episode_id}@f{frame_id}",
        ))
    return out


COLLECTORS = {
    "xperience": collect_xperience,
    "egodex": collect_egodex,
}


# --------------------------------------------------------------------------- #
# Rendering
# --------------------------------------------------------------------------- #
def make_action_panel(state: np.ndarray, action: np.ndarray, action_mask: np.ndarray,
                      title: str, width: int) -> np.ndarray:
    """Render state + action translation curves as a static BGR panel."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    F = action.shape[0]
    fig, axes = plt.subplots(2, 1, figsize=(width / 100, 4.2), dpi=100)
    t = np.arange(F + 1)

    # Translation trajectories (reconstructed absolute cam-frame pos)
    left_traj = np.zeros((F + 1, 3))
    right_traj = np.zeros((F + 1, 3))
    left_traj[0] = state[LEFT_T_SLICE]
    right_traj[0] = state[RIGHT_T_SLICE]
    for i in range(F):
        left_traj[i + 1] = state[LEFT_T_SLICE] + action[i][LEFT_T_SLICE]
        right_traj[i + 1] = state[RIGHT_T_SLICE] + action[i][RIGHT_T_SLICE]

    ax = axes[0]
    ax.set_title(f"{title}\nleft hand cam-frame xyz (blue=x,orange=y,green=z)")
    for d, c in zip(range(3), ["tab:blue", "tab:orange", "tab:green"]):
        lm = np.full(F + 1, True)
        lm[1:] = action_mask[:, d]
        ax.plot(t, left_traj[:, d], color=c, marker=".")
    ax.set_xlabel("frame"); ax.grid(True, alpha=0.3)

    ax = axes[1]
    ax.set_title("right hand cam-frame xyz")
    for d, c in zip(range(3), ["tab:blue", "tab:orange", "tab:green"]):
        ax.plot(t, right_traj[:, d], color=c, marker=".")
    ax.set_xlabel("frame"); ax.grid(True, alpha=0.3)

    fig.tight_layout()
    fig.canvas.draw()
    panel_rgb = np.asarray(fig.canvas.buffer_rgba())
    plt.close(fig)
    panel_bgr = cv2.cvtColor(panel_rgb, cv2.COLOR_RGBA2BGR)
    return panel_bgr


def render_sample(sample: dict, out_path: Path, fps: int = 4) -> Tuple[float, float]:
    """Render one sample mp4. Returns (max_recon_err_left, max_recon_err_right)."""
    state = sample["state"]
    action = sample["action"]
    action_mask = sample["action_mask"]
    label = sample["label"]

    F = action.shape[0]
    R_w_c_list = sample["R_w_c_list"].copy()
    t_w_c_list = sample["t_w_c_list"]
    frames = sample["native_frames"]            # (F+1, H, W, 3) RGB uint8
    K = sample["K"].copy()
    H_img, W_img = frames.shape[1], frames.shape[2]

    # --- Display-only camera-convention adjustments (do NOT change state/action) ---
    # 1) K / video resolution mismatch: if the stored K's principal point implies a
    #    resolution different from the actual video, assume a center crop (fx,fy
    #    preserved, principal point recentered). Needed for Xperience, whose cam0 K
    #    is ~1083x1378 but stereo_left.mp4 is 512x512.
    raw_w = 2.0 * K[0, 2]
    raw_h = 2.0 * K[1, 2]
    if raw_w > 0 and raw_h > 0 and (abs(raw_w - W_img) > 2 or abs(raw_h - H_img) > 2):
        cx_crop = K[0, 2] - (raw_w - W_img) / 2.0
        cy_crop = K[1, 2] - (raw_h - H_img) / 2.0
        K[0, 2] = cx_crop
        K[1, 2] = cy_crop
        logger.info(f"  [{label}] K res mismatch (raw {raw_w:.0f}x{raw_h:.0f} vs video "
                    f"{W_img}x{H_img}); assuming center crop -> cx={cx_crop:.1f}, cy={cy_crop:.1f}")

    # 2) z-axis direction: VITRA/EgoDex cameras are z-forward (hand in front => z>0).
    #    Xperience's camera (from build_camera_world_pose_from_slam) is z-BACKWARD
    #    (hand in front => z<0, i.e. state[2]/state[10] < 0). For pixel projection
    #    (which assumes OpenCV z-forward) we flip the camera z for DISPLAY ONLY.
    #    This does not alter the recorded state/action; it only makes the overlay
    #    viewable. The z-sign inconsistency is reported separately.
    flip_z = False
    for zi in (2, 10):
        if np.isfinite(state[zi]) and state[zi] < -1e-3:
            flip_z = True
            break
    if flip_z:
        R_w_c_list[:, :, 2] = -R_w_c_list[:, :, 2]  # negate camera z-axis (col 2)
        logger.info(f"  [{label}] camera z points backward (state z<0); flipping z for "
                    f"display projection only (state/action unchanged).")

    R_w_c0 = R_w_c_list[0]
    t_w_c0 = t_w_c_list[0]

    # Reconstructed trajectory in frame-0 camera frame (dataset's convention).
    rec_left, rec_right = reconstruct_trajectory(state, action, F)
    if flip_z:
        rec_left[:, 2] = -rec_left[:, 2]
        rec_right[:, 2] = -rec_right[:, 2]
    # Ground-truth from raw world poses (uses the possibly-flipped R_w_c0).
    gt_left = gt_trajectory_frame0(sample["gt_left_world"], R_w_c0, t_w_c0)
    gt_right = gt_trajectory_frame0(sample["gt_right_world"], R_w_c0, t_w_c0)

    # Validity per frame (anchor + target both valid for that action step).
    lv = np.zeros(F + 1, dtype=bool)
    rv = np.zeros(F + 1, dtype=bool)
    lv[0] = bool(action_mask[:, 0].any()) if F > 0 else False
    rv[0] = bool(action_mask[:, 8].any()) if F > 0 else False
    for i in range(F):
        lv[i + 1] = bool(action_mask[i, 0])
        rv[i + 1] = bool(action_mask[i, 8])
    # Anchor validity: a hand is "active" if its mask has any True over the window.
    left_active = bool(action_mask[:, :6].any())
    right_active = bool(action_mask[:, 8:14].any())

    # Numerical self-check: max |reconstruction - gt| on valid frames.
    def _err(rec, gt, valid):
        if not valid.any():
            return float("nan")
        d = np.linalg.norm(rec[valid] - gt[valid], axis=1)
        return float(np.max(d)) if d.size else float("nan")
    err_left = _err(rec_left, gt_left, lv)
    err_right = _err(rec_right, gt_right, rv)

    # Pre-project all points into every frame for the trajectory polyline.
    H, W = frames.shape[1], frames.shape[2]
    # projected[i][j] = pixel of point j (in frame-0 cam coords) seen in frame i
    def _proj_all(pts: np.ndarray, valid: np.ndarray):
        out_pts = np.full((F + 1, F + 1, 2), np.nan)
        for i in range(F + 1):
            for j in range(i + 1):  # only points up to current frame
                if not valid[j]:
                    continue
                uv, _ = project_to_frame(pts[j], R_w_c0, t_w_c0, R_w_c_list[i], t_w_c_list[i], K)
                if uv is not None and 0 <= uv[0] < W and 0 <= uv[1] < H:
                    out_pts[i, j] = uv
        return out_pts
    proj_left = _proj_all(rec_left, lv & np.tile(left_active, (F + 1,))) if left_active else None
    proj_right = _proj_all(rec_right, rv & np.tile(right_active, (F + 1,))) if right_active else None

    panel = make_action_panel(state, action, action_mask, label, width=W // 2)
    panel_h, panel_w = panel.shape[:2]
    target_h = H
    scale = target_h / panel_h
    panel = cv2.resize(panel, (int(panel_w * scale), target_h))

    out_path.parent.mkdir(parents=True, exist_ok=True)
    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    vw = cv2.VideoWriter(str(out_path), fourcc, fps, (W + panel.shape[1], H))
    if not vw.isOpened():
        logger.error(f"VideoWriter failed to open for {out_path}")
        return err_left, err_right

    for i in range(F + 1):
        frame_bgr = cv2.cvtColor(frames[i], cv2.COLOR_RGB2BGR)

        def _draw(poly_pts, color):
            if poly_pts is None:
                return
            pts = poly_pts[i]
            prev = None
            for j in range(i + 1):
                if np.isnan(pts[j, 0]):
                    prev = None
                    continue
                p = (int(round(pts[j, 0])), int(round(pts[j, 1])))
                cv2.circle(frame_bgr, p, 4, color, -1)
                if prev is not None:
                    cv2.line(frame_bgr, prev, p, color, 2)
                prev = p
            # anchor (j=0) larger ring
            if not np.isnan(pts[0, 0]):
                cv2.circle(frame_bgr, (int(round(pts[0, 0])), int(round(pts[0, 1]))), 7, ANCHOR_COLOR, 1)

        _draw(proj_left, LEFT_COLOR)
        _draw(proj_right, RIGHT_COLOR)

        # legend / frame counter
        cv2.putText(frame_bgr, f"{label}  frame {i}/{F}", (8, 22),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1, cv2.LINE_AA)
        cv2.putText(frame_bgr, "left", (8, 42), cv2.FONT_HERSHEY_SIMPLEX, 0.5, LEFT_COLOR, 1)
        cv2.putText(frame_bgr, "right", (60, 42), cv2.FONT_HERSHEY_SIMPLEX, 0.5, RIGHT_COLOR, 1)
        cv2.putText(frame_bgr, f"recon_err L={err_left:.2e} R={err_right:.2e}", (8, H - 10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1, cv2.LINE_AA)

        composite = np.hstack([frame_bgr, panel])
        vw.write(composite)
    vw.release()
    logger.info(f"  wrote {out_path}  (recon_err L={err_left:.2e} R={err_right:.2e})")
    return err_left, err_right


# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument(
        "--config",
        default="configs/motusv1_adapted/cross_dataset_mixed_unified_eef_wrist16_xperience10m.yaml",
    )
    ap.add_argument("--samples-per-dataset", type=int, default=5)
    ap.add_argument("--output-dir", default="outputs/unified_eef_viz")
    ap.add_argument("--datasets", default="all", help="comma list (vitra_*,egodex,xperience) or 'all'")
    args = ap.parse_args()

    out_root = Path(args.output_dir)
    logger.info(f"Building datasets from {args.config} (t5_mode=none) ...")
    datasets = build_datasets(args.config)
    logger.info(f"Built {len(datasets)} datasets: {[n for n, _ in datasets]}")

    sel = None if args.datasets.lower() == "all" else set(args.datasets.split(","))
    summary = []
    for name, ds in datasets:
        if sel is not None and name not in sel:
            continue
        logger.info(f"=== Collecting from {name} (len={len(ds)}) ===")
        if name.startswith("vitra"):
            samples = collect_vitra(ds, args.samples_per_dataset)
        else:
            collector = COLLECTORS[name]
            samples = collector(ds, args.samples_per_dataset)
        logger.info(f"  collected {len(samples)} samples for {name}")
        if not samples:
            continue
        ds_out = out_root / name
        for i, s in enumerate(samples):
            mp4 = ds_out / f"{i:02d}_{s['label'].replace('/', '_').replace('@', '_f')}.mp4"
            el, er = render_sample(s, mp4)
            summary.append((s["label"], el, er))

    logger.info("==== Reconstruction error summary (max |state+action recon - raw world| in meters) ====")
    for label, el, er in summary:
        logger.info(f"  {label:70s} L={el:.2e}  R={er:.2e}")
    logger.info("If errors are ~1e-5, the action math is correct. Then check the mp4s: dots must sit on hands.")


if __name__ == "__main__":
    main()

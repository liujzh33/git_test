#!/bin/bash
# DROID (LeRobot v3.0) post-training — qpos joint-position action.
# Aligned with RoboLab Pi0.5 `pi05_droid_jointpos` inference settings.
#
# Usage:
#   bash scripts/train_ADS_MotusV2_droid.sh
#
# Multi-node / multi-GPU:
#   WORLD_SIZE=<nodes> VC_WORKER_NUM=<nodes> VC_TASK_INDEX=<rank> \
#     MASTER_ADDR=<addr> MASTER_PORT=<port> NPROC_PER_NODE=<gpus> \
#     bash scripts/train_ADS_MotusV2_droid.sh
set -euo pipefail

TASK="droid_wan_vlm_mask_stage2_15w"
CONFIG_FILE="configs/droid_wan_vlm_mask_stage2_15w.yaml"

export OUTPUT_DIR="outputs/motus-${TASK}"

if [ ! -d "$OUTPUT_DIR" ]; then
    mkdir -p "$OUTPUT_DIR"
    echo "Folder '$OUTPUT_DIR' created"
else
    echo "Folder '$OUTPUT_DIR' already exists"
fi

NNODES=${WORLD_SIZE:-${VC_WORKER_NUM:-1}}
NODE_RANK=${VC_TASK_INDEX:-0}
MASTER_ADDR=${MASTER_ADDR:-${DOLPHIN_MASTER_IP:-127.0.0.1}}
MASTER_PORT=${MASTER_PORT:-23456}
NPROC_PER_NODE=${NPROC_PER_NODE:-8}

# export CUDA_VISIBLE_DEVICES=4,5,6,7
# NPROC_PER_NODE=${NPROC_PER_NODE:-4}

echo "===== distributed config ====="
echo "HOSTNAME=$(hostname)"
echo "NNODES=$NNODES"
echo "NODE_RANK=$NODE_RANK"
echo "MASTER_ADDR=$MASTER_ADDR"
echo "MASTER_PORT=$MASTER_PORT"
echo "NPROC_PER_NODE=$NPROC_PER_NODE"
echo "CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-}"
echo "NVIDIA_VISIBLE_DEVICES=${NVIDIA_VISIBLE_DEVICES:-}"
echo "=============================="

LOG_FILE="${OUTPUT_DIR}/console_$(date '+%Y%m%d_%H%M%S').log"

torchrun \
    --nnodes=${NNODES} \
    --nproc_per_node=${NPROC_PER_NODE} \
    --node_rank=${NODE_RANK} \
    --master_addr=${MASTER_ADDR} \
    --master_port=${MASTER_PORT} \
    train/train_wan_vlm_mask.py \
    --deepspeed configs/zero1.json \
    --config ${CONFIG_FILE} \
    --run_name ${TASK} \
    --report_to tensorboard \
    2>&1 | tee "$LOG_FILE"

#!/usr/bin/env python3
"""Diagnose Xperience camera/hand world-frame alignment.

Project hand_mocap wrist positions onto stereo_left.mp4 frames using the SLAM
camera pose + cam0 intrinsics, and save annotated PNGs so we can SEE whether the
dots land on the hands. Tests several conventions to find the one that aligns.
"""
import sys
from pathlib import Path
import h5py
import numpy as np
import cv2
import decord

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO))
from data.human.unified_eef_action import build_camera_world_pose_from_slam, quat_wxyz_to_rotmat

EP = "/cache/wx1469573/data/xperience-10m-clean/003dcaf0-edba-4787-ada0-187d2748f684/ep1"
FRAME = 200  # use a mid-sequence frame where hands are likely visible


def quat_to_rotmat(q):
    w, x, y, z = q
    return np.array([
        [1-2*(y*y+z*z), 2*(x*y-w*z),   2*(x*z+w*y)],
        [2*(x*y+w*z),   1-2*(x*x+z*z), 2*(y*z-w*x)],
        [2*(x*z-w*y),   2*(y*z+w*x),   1-2*(x*x+y*y)],
    ])


def main():
    out_dir = Path("outputs/xp_diag"); out_dir.mkdir(parents=True, exist_ok=True)
    with h5py.File(f"{EP}/annotation.hdf5", "r") as f:
        slam_t = f["slam/trans_xyz"][:].astype(np.float64)
        slam_q = f["slam/quat_wxyz"][:].astype(np.float64)
        T_c_b = f["calibration/cam0/T_c_b"][:].astype(np.float64)
        K_raw = f["calibration/cam0/K"][:].astype(np.float64)
        left_t = f["hand_mocap/left_translation"][:].astype(np.float64)
        right_t = f["hand_mocap/right_translation"][:].astype(np.float64)
        left_R = f["hand_mocap/left_mano_hand_global_orient"][:].astype(np.float64).reshape(-1,3,3)
    K_full = np.array([[K_raw[0],0,K_raw[2]],[0,K_raw[1],K_raw[3]],[0,0,1]])
    print(f"K_full (fx,fy,cx,cy) = {K_raw}")
    print(f"T_c_b =\n{T_c_b}")
    print(f"slam_t[0] = {slam_t[0]}, slam_q[0] = {slam_q[0]}")
    print(f"left_t[{FRAME}] = {left_t[FRAME]}, right_t[{FRAME}] = {right_t[FRAME]}")
    print(f"left_R det[{FRAME}] = {np.linalg.det(left_R[FRAME]):.4f}")

    # Load frame
    vr = decord.VideoReader(f"{EP}/stereo_left.mp4", num_threads=1)
    n = len(vr); print(f"video frames = {n}, res = {vr[0].shape}")
    fi = min(FRAME, n-1)
    img = vr[fi].asnumpy().astype(np.uint8)
    H, W = img.shape[0], img.shape[1]
    print(f"video res = {W}x{H}")

    # Center-crop K to 512x512
    raw_w = 2*K_full[0,2]; raw_h = 2*K_full[1,2]
    K = K_full.copy()
    K[0,2] = K_full[0,2] - (raw_w - W)/2.0
    K[1,2] = K_full[1,2] - (raw_h - H)/2.0
    print(f"K after center-crop: cx={K[0,2]:.2f}, cy={K[1,2]:.2f} (res {W}x{H}, raw {raw_w:.0f}x{raw_h:.0f})")

    # Camera pose at frame fi
    R_w_c, t_w_c = build_camera_world_pose_from_slam(slam_t[fi], slam_q[fi], T_c_b)
    print(f"R_w_c =\n{R_w_c}")
    print(f"t_w_c = {t_w_c}")
    # camera z-axis in world (3rd col of R_w_c): if it points away from scene, z-backward
    cam_z_world = R_w_c[:,2]
    print(f"camera z-axis (world) = {cam_z_world}")

    # Hand world -> cam0
    def project(p_world):
        p_cam = R_w_c.T @ (p_world - t_w_c)
        if p_cam[2] <= 1e-4:
            return None, p_cam
        uv = K @ (p_cam / p_cam[2])
        return uv[:2], p_cam

    lt = left_t[fi]; rt = right_t[fi]
    for name, p in [("left", lt), ("right", rt)]:
        if not np.all(np.isfinite(p)):
            print(f"  {name}: NaN"); continue
        uv, pc = project(p)
        print(f"  {name}: world={p}  cam={pc}  -> pixel={uv}")

    # Also: distance from camera to hand
    if np.all(np.isfinite(lt)):
        d = np.linalg.norm(lt - t_w_c)
        print(f"  |left - cam_pos| = {d:.3f} m")

    # === Save annotated frames under several conventions ===
    def draw(img, pts, label):
        out = cv2.cvtColor(img, cv2.COLOR_RGB2BGR).copy()
        for (color, (px, py)) in pts:
            if px is None:
                cv2.putText(out, "(off-screen)", (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1)
                continue
            ix, iy = int(round(px)), int(round(py))
            if 0 <= ix < W and 0 <= iy < H:
                cv2.circle(out, (ix, iy), 10, color, -1)
            else:
                cx, cy = max(8, min(W-9, ix)), max(8, min(H-9, iy))
                cv2.circle(out, (cx, cy), 8, color, 2)
                cv2.arrowedLine(out, (cx, cy), (max(0,min(W-1,ix)), max(0,min(H-1,iy))), color, 2)
        cv2.putText(out, label, (8, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255), 1)
        return out

    BLUE = (255,128,0); GREEN = (0,255,0)
    panels = []

    # Convention A: as-is (OpenCV z-forward projection)
    def projA(p_world):
        if not np.all(np.isfinite(p_world)): return None
        pc = R_w_c.T @ (p_world - t_w_c)
        if pc[2] <= 1e-4: return None
        uv = K @ (pc/pc[2]); return uv[:2]
    def _px(uv):
        if uv is None: return None, None
        return float(uv[0]), float(uv[1])
    a_pts = [(BLUE, _px(projA(lt))), (GREEN, _px(projA(rt)))]
    panels.append(("A_as_is", draw(img, a_pts, "A as-is (z-forward, pc.z>0)")))

    # Convention B: flip camera z (negate col 2 of R_w_c, negate point z) - the viz hack
    R_w_c_b = R_w_c.copy(); R_w_c_b[:,2] = -R_w_c_b[:,2]
    def projB(p_world):
        if not np.all(np.isfinite(p_world)): return None
        # first to cam0 with original R, then negate z (mirrors flip_z hack)
        pc = R_w_c.T @ (p_world - t_w_c)
        pc[2] = -pc[2]
        if pc[2] <= 1e-4: return None
        uv = K @ (pc/pc[2]); return uv[:2]
    b_pts = [(BLUE, _px(projB(lt))), (GREEN, _px(projB(rt)))]
    panels.append(("B_flip_z", draw(img, b_pts, "B flip_z hack (negate pc.z)")))

    # Convention C: full camera convention flip — negate z AND x (mirror) so image not mirrored
    def projC(p_world):
        if not np.all(np.isfinite(p_world)): return None
        pc = R_w_c.T @ (p_world - t_w_c)
        # camera looks along -z; render as if +z: flip z and x
        pc = np.array([-pc[0], pc[1], -pc[2]])
        if pc[2] <= 1e-4: return None
        uv = K @ (pc/pc[2]); return uv[:2]
    c_pts = [(BLUE, _px(projC(lt))), (GREEN, _px(projC(rt)))]
    panels.append(("C_flip_zx", draw(img, c_pts, "C flip z&x (no-mirror)")))

    # Convention D: camera looks along -z, project with -z depth, x mirrored, y mirrored
    def projD(p_world):
        if not np.all(np.isfinite(p_world)): return None
        pc = R_w_c.T @ (p_world - t_w_c)
        pc = np.array([-pc[0], -pc[1], -pc[2]])
        if pc[2] <= 1e-4: return None
        uv = K @ (pc/pc[2]); return uv[:2]
    d_pts = [(BLUE, _px(projD(lt))), (GREEN, _px(projD(rt)))]
    panels.append(("D_flip_xyz", draw(img, d_pts, "D flip x,y,z")))

    # Convention E: maybe hand_mocap world != SLAM world. Try: hand in camera body frame directly.
    # i.e. maybe left_translation is already in body frame, and we apply T_c_b only.
    def projE(p_world):
        if not np.all(np.isfinite(p_world)): return None
        # treat p_world as body-frame point: p_cam0 = T_c_b @ p_body, then place camera at origin
        p_body_h = np.array([*p_world, 1.0])
        pc = (T_c_b @ p_body_h)[:3]
        if pc[2] <= 1e-4: return None
        uv = K @ (pc/pc[2]); return uv[:2]
    e_pts = [(BLUE, _px(projE(lt))), (GREEN, _px(projE(rt)))]
    panels.append(("E_body_frame", draw(img, e_pts, "E hand as body-frame (T_c_b @ p)")))

    # Convention F: T_c_b conventionally means camera-in-body (p_body = T_c_b @ p_cam),
    # so T_w_cam0 = T_w_body @ T_c_b (NOT inv). This is the robotics convention.
    R_w_c_F = quat_to_rotmat(slam_q[fi]) @ T_c_b[:3,:3]
    t_w_c_F = slam_t[fi] + quat_to_rotmat(slam_q[fi]) @ T_c_b[:3,3]
    def projF(p_world):
        if not np.all(np.isfinite(p_world)): return None
        pc = R_w_c_F.T @ (p_world - t_w_c_F)
        if pc[2] <= 1e-4: return None
        uv = K @ (pc/pc[2]); return uv[:2]
    f_l = projF(lt); f_r = projF(rt)
    # also report cam coords for F
    if np.all(np.isfinite(lt)):
        pcF = R_w_c_F.T @ (lt - t_w_c_F)
        print(f"  [F] left cam = {pcF}  (z>0 means in front)")
    f_pts = [(BLUE, _px(f_l)), (GREEN, _px(f_r))]
    panels.append(("F_Tcb_as_caminbody", draw(img, f_pts, "F T_c_b=caminbody (T_w_body @ T_c_b)")))

    # Stack into a grid and save
    imgs = [p for _, p in panels]
    h = H
    grid = np.hstack([cv2.resize(im, (h, h)) for im in imgs])
    cv2.imwrite(str(out_dir / "xperience_conventions.png"), grid)
    print(f"\nSaved grid -> {out_dir/'xperience_conventions.png'}")
    for name, _ in panels:
        print(f"  panel: {name}")


if __name__ == "__main__":
    main()

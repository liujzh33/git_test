#!/usr/bin/env python3
"""Pre-populate the DROID T5 (UMT5-XXL) language-embedding cache.

DataLoader workers cannot initialize the T5 encoder (CUDA fork restriction), so
a cache miss during multi-worker training is a hard error.  Run this once first.

    python scripts/prepopulate_droid_t5_cache.py \
        --config configs/droid_wan_vlm_mask_stage2_15w.yaml

Only the instructions the dataset can actually request are encoded: for each
*kept* episode the instruction is resolved exactly as ``__getitem__`` resolves it
(language_instruction -> _2 -> _3 -> DEFAULT_INSTRUCTION).  Collecting every
distinct string from all three columns across all episodes instead -- including
episodes dropped by require_success -- roughly triples the work for no benefit.

Batching is only safe because the encoder runs in float32.  UMT5 omits the
1/sqrt(d) attention scaling, so in bfloat16 cuBLAS picks a different reduction
per batch size and the same text differs by ~20% relative (cosine 0.98) between
batch=1 and batch=8 -- not leakage between samples (tests/diag_t5_batch_cause.py
shows the neighbours are irrelevant), just conditioning.  float32 brings that to
~1e-6, so a batched cache and the one-at-a-time call inference makes agree.
``dataset.t5_precision`` therefore has to be float32 for --batch-size > 1;
the script refuses otherwise.
"""
import argparse
import logging
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from omegaconf import OmegaConf

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("prepopulate_droid_t5")


def resolve_instruction(row, field: str, default: str) -> str:
    """Mirror DroidLeRobotDataset.__getitem__'s instruction resolution."""
    for col in (field, "language_instruction_2", "language_instruction_3"):
        val = row.get(col)
        if val is not None:
            text = str(val).strip()
            if text:
                return text
    return default


def collect_instructions(ds, dataset_dir: str, instruction_field: str) -> set:
    """Instructions the dataset can actually hand to the model."""
    import pandas as pd
    import pyarrow.parquet as pq

    kept = {int(e["episode_index"]) for e in ds.episodes}
    logger.info(f"resolving instructions for {len(kept)} indexed episodes")

    wanted = [instruction_field, "language_instruction_2", "language_instruction_3"]
    instructions = set()
    for pf in sorted((Path(dataset_dir) / "data").rglob("*.parquet")):
        try:
            available = set(pq.read_schema(pf).names)
            cols = [c for c in wanted if c in available]
            if not cols or "episode_index" not in available:
                continue
            df = pd.read_parquet(pf, columns=["episode_index", *cols])
        except Exception as e:  # noqa: BLE001
            logger.warning(f"skip {pf}: {e}")
            continue
        df = df[df["episode_index"].isin(kept)]
        if df.empty:
            continue
        # The annotation is constant within an episode, so one row per episode
        # is enough (verified across the DROID release).
        for _, row in df.groupby("episode_index").first().iterrows():
            instructions.add(resolve_instruction(row, instruction_field, ds.DEFAULT_INSTRUCTION))
    instructions.add(ds.DEFAULT_INSTRUCTION)
    return instructions


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/droid_wan_vlm_mask_stage2_15w.yaml")
    ap.add_argument("--max-episodes", type=int, default=0, help="0 = all episodes")
    ap.add_argument("--batch-size", type=int, default=64,
                    help="instructions per encoder call; requires t5_precision=float32")
    args = ap.parse_args()

    cfg = OmegaConf.load(args.config)
    cfg.dataset.max_episodes = None if args.max_episodes <= 0 else args.max_episodes

    from data.droid.droid_lerobot_dataset import DroidLeRobotDataset

    ds = DroidLeRobotDataset(
        dataset_dir=cfg.dataset.dataset_dir,
        num_video_frames=cfg.common.num_video_frames,
        video_size=(cfg.common.video_height, cfg.common.video_width),
        global_downsample_rate=cfg.common.global_downsample_rate,
        video_action_freq_ratio=cfg.common.video_action_freq_ratio,
        max_episodes=cfg.dataset.max_episodes,
        vlm_checkpoint_path=None,
        t5_mode="disk_cache",
        wan_path=cfg.dataset.params.wan_path,
        t5_cache_dir=cfg.dataset.t5_cache_dir,
        t5_text_len=cfg.dataset.t5_text_len,
        t5_device=cfg.dataset.t5_device,
        t5_precision=cfg.dataset.get("t5_precision", "float32"),
        instruction_field=cfg.dataset.get("instruction_field", "language_instruction"),
        require_success=cfg.dataset.get("require_success", True),
        filter_idle=cfg.dataset.get("filter_idle", True),
        action_normalization=cfg.dataset.get("action_normalization", True),
        norm_stats_path=cfg.dataset.get("norm_stats_path"),
    )

    instructions = collect_instructions(
        ds, cfg.dataset.dataset_dir,
        cfg.dataset.get("instruction_field", "language_instruction"),
    )
    instructions = sorted(i for i in instructions if i.strip())
    logger.info(f"instructions the dataset can request: {len(instructions)}")

    todo = [i for i in instructions if not ds.has_t5_cache_entry(i)]
    logger.info(f"already cached: {len(instructions) - len(todo)}   to encode: {len(todo)}")
    if not todo:
        logger.info("nothing to do")
        return

    from data import encode_texts, release_global_t5_encoder

    encoder = ds._ensure_t5_encoder()
    if encoder is None:
        raise RuntimeError("T5 encoder unavailable; check dataset.params.wan_path")

    import torch

    bs = max(1, args.batch_size)
    if bs > 1 and ds.t5_precision != "float32":
        raise ValueError(
            f"--batch-size={bs} requires dataset.t5_precision='float32'; got "
            f"{ds.t5_precision!r}. In bfloat16 the encoder is batch-dependent, so a "
            f"batched cache would not match what inference produces one at a time. "
            f"Either set t5_precision: float32 in the config or use --batch-size 1."
        )
    logger.info(f"encoding at t5_precision={ds.t5_precision}, batch_size={bs}")

    t0 = time.time()
    done = 0
    for start in range(0, len(todo), bs):
        chunk = todo[start:start + bs]
        with torch.no_grad():
            out = encode_texts(encoder, chunk, ds.t5_device, dynamic=True)
        for text, emb in zip(chunk, out):
            ds.write_t5_cache_entry(text, emb)
        done += len(chunk)
        if done % max(bs, 500) < bs or done == len(todo):
            rate = done / max(time.time() - t0, 1e-6)
            eta = (len(todo) - done) / max(rate, 1e-6)
            logger.info(f"  encoded {done}/{len(todo)}  ({rate:.1f}/s, ETA {eta/60:.1f} min)")

    logger.info(f"encoded {done} instructions in {(time.time()-t0)/60:.1f} min "
                f"-> {cfg.dataset.t5_cache_dir}")
    release_global_t5_encoder()


if __name__ == "__main__":
    main()

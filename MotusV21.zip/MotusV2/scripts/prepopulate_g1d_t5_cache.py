#!/usr/bin/env python3
"""Pre-populate the G1-D T5 (UMT5-XXL) language-embedding cache.

The G1-D dataset encodes task instructions on-the-fly and caches them to
``t5_cache_dir`` (keyed by SHA1(instruction)).  In multi-worker DataLoader
training, worker processes cannot safely initialize the heavy T5 encoder
(CUDA fork restriction), so cache misses would yield zero embeddings.

G1-D is single-task: instructions come from ``meta/tasks.parquet`` (the
``task`` column), so this script encodes one (or a few) unique strings.

Run this script once (single process) before multi-worker training so the
cache is populated:

    python scripts/prepopulate_g1d_t5_cache.py \\
        --config configs/g1d_pick_kettle_wan_vlm_mask.yaml

    python scripts/prepopulate_g1d_t5_cache.py \\
        --config configs/g1d_ego_mixed_eef_delta.yaml
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import logging
from omegaconf import OmegaConf

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("prepopulate_g1d_t5")


def _g1d_dataset_dir(cfg) -> str:
    """Pure G1-D configs use dataset.dataset_dir; mixed uses dataset.g1d.dataset_dir."""
    if hasattr(cfg.dataset, "g1d") and cfg.dataset.g1d.get("dataset_dir"):
        return str(cfg.dataset.g1d.dataset_dir)
    if cfg.dataset.get("dataset_dir"):
        return str(cfg.dataset.dataset_dir)
    raise ValueError("config has neither dataset.dataset_dir nor dataset.g1d.dataset_dir")


def _g1d_downsample(cfg) -> int:
    if hasattr(cfg.dataset, "g1d") and cfg.dataset.g1d.get("global_downsample_rate") is not None:
        return int(cfg.dataset.g1d.global_downsample_rate)
    return int(cfg.common.global_downsample_rate)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/g1d_pick_kettle_wan_vlm_mask.yaml")
    ap.add_argument("--max-episodes", type=int, default=0, help="0 = all episodes (unused for G1-D; kept for parity)")
    args = ap.parse_args()

    cfg = OmegaConf.load(args.config)
    dataset_dir = _g1d_dataset_dir(cfg)

    import pandas as pd
    from data.g1d.g1d_dataset import G1DLeRobotDataset

    ds = G1DLeRobotDataset(
        dataset_dir=dataset_dir,
        num_video_frames=cfg.common.num_video_frames,
        video_size=(cfg.common.video_height, cfg.common.video_width),
        global_downsample_rate=_g1d_downsample(cfg),
        video_action_freq_ratio=cfg.common.video_action_freq_ratio,
        max_episodes=None if args.max_episodes <= 0 else args.max_episodes,
        vlm_checkpoint_path=None,
        t5_mode="disk_cache",
        wan_path=cfg.dataset.params.wan_path,
        t5_cache_dir=cfg.dataset.t5_cache_dir,
        t5_text_len=cfg.dataset.t5_text_len,
        t5_device=cfg.dataset.t5_device,
        action_mode=str(cfg.dataset.get("action_mode", "qpos")),
        normalization=bool(cfg.dataset.get("normalization", False)),
        normalization_stats_path=cfg.dataset.get("normalization_stats_path", None),
    )

    # Collect unique instructions from meta/tasks.parquet (G1-D __getitem__)
    # plus dataset.instruction (ego / mixed override). Cache keys are SHA1(text).
    tasks_path = Path(dataset_dir) / "meta" / "tasks.parquet"
    instructions = set()
    yaml_instr = str(cfg.dataset.get("instruction", "") or "").strip()
    if yaml_instr:
        instructions.add(yaml_instr)
    try:
        tf = pd.read_parquet(tasks_path)
        for task_text in tf.index:
            instructions.add(str(task_text))
    except Exception as e:
        logger.warning(f"Failed to read {tasks_path}: {e}; falling back to dataset.task_index_to_text")
        for txt in ds.task_index_to_text.values():
            instructions.add(str(txt))
    logger.info(f"Unique instructions: {len(instructions)}")

    from data import release_global_t5_encoder
    done = 0
    for i, instr in enumerate(sorted(instructions)):
        if instr.strip() == "":
            continue
        emb = ds._get_t5_embedding(instr)
        done += 1
        logger.info(f"  encoded [{done}/{len(instructions)}] shape={tuple(emb.shape)} text={instr!r}")
    logger.info(f"Encoded {done} instructions -> {cfg.dataset.t5_cache_dir}")
    release_global_t5_encoder()


if __name__ == "__main__":
    main()

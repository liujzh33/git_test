#!/usr/bin/env python3
"""Visualize G1-D pick-kettle-and-cup samples exactly as MotusV2 training sees them.

The pixels rendered here come out of the production code path: this script loads the
real experiment config and builds the real ``G1DLeRobotDataset`` through
``data.dataset.create_dataset``, then calls the dataset's own
``_calculate_sampling_indices`` / ``_decode_frames`` / ``_stitch_t_shape``.

The checked-in config points at the training cluster's ``/cache/...`` paths, so
``--dataset-dir`` is applied to the loaded OmegaConf object in memory.  The config
file on disk is never written to.  T5 (UMT5-XXL) and the Qwen3-VL processor are
switched off the same way, since neither affects the image layout.

Outputs, per sample, under ``--output-dir``:
    <name>_01_stitched.png   the 9 frames WAN receives (condition + 8 targets)
    <name>_02_layout.png     per-camera pipeline stages + measured content boxes
    <name>_03_actions.png    initial_state and the 16x16 qpos action chunk
    <name>_04_chunk.mp4/gif  the 9-frame chunk animated
plus a shared ``layout_report.md`` and ``samples.json`` with the measured geometry.

Usage:
    python scripts/visualize_g1d_samples.py \
        --dataset-dir /home/work/wenjj/data/G1-D/pick-kettle-and-cup \
        --num-samples 4
"""

import argparse
import json
import logging
import random
import sys
import types
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

# Stub heavy optional deps that the dataset import chain pulls in but that pure
# image visualization never calls (same pattern as tests/ and
# scripts/visualize_unified_eef_samples.py).
try:  # pragma: no cover - environment dependent
    import qwen_vl_utils  # noqa: F401
except Exception:
    _qvu = types.ModuleType("qwen_vl_utils")
    _qvu.process_vision_info = lambda *a, **k: (None, None)
    sys.modules.setdefault("qwen_vl_utils", _qvu)
try:  # pragma: no cover - environment dependent
    import decord  # noqa: F401
except Exception:
    _dec = types.ModuleType("decord")

    class _MissingVideoReader:  # pragma: no cover - only hit if actually used
        def __init__(self, *a, **k):
            raise RuntimeError("decord is not installed in this environment")

    _dec.VideoReader = _MissingVideoReader
    _dec.cpu = lambda *a, **k: None
    sys.modules.setdefault("decord", _dec)

import cv2  # noqa: E402
import matplotlib  # noqa: E402

matplotlib.use("Agg")
import matplotlib.patches as mpatches  # noqa: E402
import matplotlib.pyplot as plt  # noqa: E402

from data.dataset import create_dataset  # noqa: E402  (real builder)
from data.g1d.g1d_dataset import _decode_video_frames_pyav  # noqa: E402

logging.basicConfig(level=logging.INFO, format="[%(levelname)s] %(message)s")
logger = logging.getLogger("viz_g1d")

DEFAULT_CONFIG = "configs/g1d_pick_kettle_wan_vlm_mask.yaml"
DEFAULT_DATASET_DIR = "/home/work/wenjj/data/G1-D/pick-kettle-and-cup"

# 16-dim qpos layout AFTER G1DLeRobotDataset._to_arm_interleaved reordering.
DIM_LABELS = (
    [f"L{i}" for i in range(7)] + ["L_grip"] + [f"R{i}" for i in range(7)] + ["R_grip"]
)
LEFT_ARM = list(range(0, 7))
LEFT_GRIP = 7
RIGHT_ARM = list(range(8, 15))
RIGHT_GRIP = 15

REGION_COLOR = "#ff2d55"
CONTENT_COLOR = "#00e5ff"


# --------------------------------------------------------------------------- #
# Dataset construction (config overridden in memory only)
# --------------------------------------------------------------------------- #
def build_dataset(config_path: Path, dataset_dir: str, scratch_dir: Path,
                  stitch_mode: Optional[str] = None):
    """Build the real G1DLeRobotDataset, overriding only paths / heavy encoders."""
    from omegaconf import OmegaConf

    cfg = OmegaConf.load(str(config_path))
    original_dir = cfg.dataset.dataset_dir
    if stitch_mode is not None:
        cfg.dataset.stitch_mode = stitch_mode

    # Point at the locally available copy of the dataset.
    cfg.dataset.dataset_dir = dataset_dir
    # Skip UMT5-XXL: language embeddings do not affect the visual layout.
    cfg.dataset.t5_mode = "none"
    cfg.dataset.allow_t5_cache_miss_zero = True
    cfg.dataset.t5_cache_dir = str(scratch_dir / "t5_cache_unused")
    # Skip the Qwen3-VL processor (weights live on the training cluster).
    if hasattr(cfg, "model") and hasattr(cfg.model, "vlm"):
        cfg.model.vlm.checkpoint_path = None

    logger.info("config %s", config_path)
    logger.info("  dataset_dir (config) : %s", original_dir)
    logger.info("  dataset_dir (used)   : %s", dataset_dir)
    ds = create_dataset(cfg, val=False)
    return ds, cfg, original_dir


def sanity_check(ds) -> Dict[str, Any]:
    """Pull one real ``__getitem__`` sample and report its shapes / value ranges."""
    sample = ds[0]
    if sample is None:
        raise RuntimeError("ds[0] returned None (all 8 retry attempts failed)")
    info: Dict[str, Any] = {}
    for key in ("first_frame", "video_frames", "initial_state", "action_sequence", "language_embedding"):
        t = sample.get(key)
        if t is None:
            info[key] = None
            continue
        info[key] = {
            "shape": list(t.shape),
            "dtype": str(t.dtype),
            "min": round(float(t.min()), 4),
            "max": round(float(t.max()), 4),
        }
    info["task_name"] = sample.get("task_name")
    info["vlm_inputs"] = "None (VLM processor disabled)" if sample.get("vlm_inputs") is None else "present"
    return info


@contextmanager
def forced_randint(value: int):
    """Pin ``random.randint`` so the dataset's own index math picks ``value``.

    Lets us drive ``_calculate_sampling_indices`` (production arithmetic) to a
    chosen condition frame instead of reimplementing the index computation.
    """
    original = random.randint

    def _patched(a, b):
        return max(a, min(b, value))

    random.randint = _patched
    try:
        yield
    finally:
        random.randint = original


# --------------------------------------------------------------------------- #
# Geometry measurement
# --------------------------------------------------------------------------- #
def content_bbox(img_hwc: np.ndarray, thr: int = 6) -> Optional[Tuple[int, int, int, int]]:
    """Bounding box (y0, y1, x0, x1) of non-black pixels; None if all black."""
    mask = img_hwc.max(axis=2) > thr
    rows = np.flatnonzero(mask.any(axis=1))
    cols = np.flatnonzero(mask.any(axis=0))
    if rows.size == 0 or cols.size == 0:
        return None
    return int(rows[0]), int(rows[-1]), int(cols[0]), int(cols[-1])


def to_uint8_hwc(frame_chw) -> np.ndarray:
    """[C,H,W] float in [0,1] -> [H,W,C] uint8 RGB."""
    arr = frame_chw.detach().cpu().numpy() if hasattr(frame_chw, "detach") else np.asarray(frame_chw)
    return (arr.transpose(1, 2, 0) * 255.0).clip(0, 255).astype(np.uint8)


def resize_pad_geometry(src_hw: Tuple[int, int], dst_hw: Tuple[int, int]) -> Dict[str, int]:
    """Analytic result of data.utils.image_utils.resize_with_padding."""
    sh, sw = src_hw
    dh, dw = dst_hw
    scale = min(dh / sh, dw / sw)
    nh, nw = int(sh * scale), int(sw * scale)
    return {
        "scale": scale,
        "new_h": nh,
        "new_w": nw,
        "y_offset": (dh - nh) // 2,
        "x_offset": (dw - nw) // 2,
    }


# --------------------------------------------------------------------------- #
# Sample collection
# --------------------------------------------------------------------------- #
def collect_sample(ds, ep: Dict[str, Any], cond_idx: int) -> Dict[str, Any]:
    """Reproduce one __getitem__ for a pinned (episode, condition frame).

    Returns the sample tensors plus every intermediate stage needed to explain
    the stitch geometry.
    """
    length = int(ep["length"])
    with forced_randint(cond_idx):
        cond, video_indices, action_indices = ds._calculate_sampling_indices(length)
    assert cond == cond_idx, (cond, cond_idx)

    rows = ds._load_parquet_rows(ep["data_chunk"], ep["data_file"], ep["episode_index"])
    if len(rows) <= action_indices[-1]:
        raise RuntimeError(f"episode {ep['episode_index']}: parquet has {len(rows)} rows")

    cond_row = rows.iloc[cond_idx]
    state_raw = np.array(cond_row["observation.state"], dtype=np.float32)
    state = ds._to_arm_interleaved(state_raw)
    actions = np.stack(
        [ds._to_arm_interleaved(np.array(rows.iloc[ai]["action"], dtype=np.float32)) for ai in action_indices],
        axis=0,
    )
    task_idx = int(cond_row["task_index"])
    instruction = ds.task_index_to_text.get(task_idx, "")

    offsets = [cond_idx] + list(video_indices)
    th, tw = ds.video_size

    # Native-resolution decode (production helper), also the input to the
    # aspect-preserving stitch.
    native_all = {
        "top": ds._decode_raw_frames(ep["top_video"], ep["top_start_frame"], offsets),
        "bl": ds._decode_raw_frames(ep["bottom_left_video"], ep["bottom_left_start_frame"], offsets),
        "br": ds._decode_raw_frames(ep["bottom_right_video"], ep["bottom_right_start_frame"], offsets),
    }
    native = {k: v[0] for k, v in native_all.items()}

    if ds.stitch_mode == "aspect":
        # One resize per camera, straight into its sub-region.
        video_all = ds._stitch_t_shape(native_all["top"], native_all["bl"], native_all["br"])
        geo = ds.t_shape_geometry(
            native["top"].shape[:2], native["bl"].shape[:2], native["br"].shape[:2]
        )
        y0 = geo["pad_top"]
        yb = y0 + geo["top_h"]
        regions = {
            "top": (y0, yb, 0, tw),
            "bl": (yb, yb + geo["bot_h"], 0, geo["split_w"]),
            "br": (yb, yb + geo["bot_h"], geo["split_w"], tw),
        }
        stage1 = None
    else:
        # Legacy: pad each camera to the full canvas first, then re-resize.
        stage1 = {
            "top": ds._decode_frames(ep["top_video"], ep["top_start_frame"], offsets),
            "bl": ds._decode_frames(ep["bottom_left_video"], ep["bottom_left_start_frame"], offsets),
            "br": ds._decode_frames(ep["bottom_right_video"], ep["bottom_right_start_frame"], offsets),
        }
        video_all = ds._stitch_t_shape_legacy(stage1["top"], stage1["bl"], stage1["br"])
        geo = {
            "canvas_h": th, "canvas_w": tw, "top_h": th // 2, "bot_h": th - th // 2,
            "split_w": tw // 2, "right_w": tw - tw // 2, "natural_h": th,
            "pad_top": 0, "pad_bottom": 0,
        }
        regions = {
            "top": (0, th // 2, 0, tw),
            "bl": (th // 2, th, 0, tw // 2),
            "br": (th // 2, th, tw // 2, tw),
        }

    return {
        "stitch_mode": ds.stitch_mode,
        "geometry": geo,
        "episode_index": int(ep["episode_index"]),
        "length": length,
        "cond_idx": int(cond_idx),
        "video_indices": [int(v) for v in video_indices],
        "action_indices": [int(a) for a in action_indices],
        "state": state,
        "state_raw": state_raw,
        "actions": actions,
        "instruction": instruction,
        "task_index": task_idx,
        "first_frame": video_all[0],
        "video_frames": video_all[1:],
        "video_all": video_all,
        "stage1": stage1,
        "native": native,
        "regions": regions,
        "video_size": (int(th), int(tw)),
        "videos": {
            "top": ep["top_video"],
            "bl": ep["bottom_left_video"],
            "br": ep["bottom_right_video"],
        },
        "start_frames": {
            "top": int(ep["top_start_frame"]),
            "bl": int(ep["bottom_left_start_frame"]),
            "br": int(ep["bottom_right_start_frame"]),
        },
    }


def measure_layout(sample: Dict[str, Any]) -> Dict[str, Any]:
    """Measure per-region content boxes on the real stitched condition frame."""
    canvas = to_uint8_hwc(sample["first_frame"])
    th, tw = sample["video_size"]
    out: Dict[str, Any] = {
        "stitch_mode": sample["stitch_mode"],
        "canvas_hw": [th, tw],
        "geometry": sample["geometry"],
        "regions": {},
    }
    total_content = 0
    for name, (y0, y1, x0, x1) in sample["regions"].items():
        crop = canvas[y0:y1, x0:x1]
        box = content_bbox(crop)
        rh, rw = y1 - y0, x1 - x0
        entry = {"region_hw": [rh, rw], "region_origin": [y0, x0]}
        if box is None:
            entry["content"] = None
        else:
            by0, by1, bx0, bx1 = box
            ch, cw = by1 - by0 + 1, bx1 - bx0 + 1
            total_content += ch * cw
            entry["content"] = {
                "box_in_region": [by0, by1, bx0, bx1],
                "box_in_canvas": [by0 + y0, by1 + y0, bx0 + x0, bx1 + x0],
                "hw": [ch, cw],
                "fill_pct": round(100.0 * ch * cw / (rh * rw), 1),
                "canvas_pct": round(100.0 * ch * cw / (th * tw), 1),
                "aspect": round(cw / ch, 4),
            }
        out["regions"][name] = entry
    out["canvas_content_pct"] = round(100.0 * total_content / (th * tw), 1)
    out["canvas_black_pct"] = round(100.0 - 100.0 * total_content / (th * tw), 1)
    return out


# --------------------------------------------------------------------------- #
# Rendering
# --------------------------------------------------------------------------- #
CAM_TITLES = {
    "top": "cam_left_high  -> TOP",
    "bl": "cam_left_wrist -> BOTTOM-LEFT",
    "br": "cam_right_wrist -> BOTTOM-RIGHT",
}


def _draw_region_lines(ax, sample: Dict[str, Any]) -> None:
    """Outline the T-shape partition using the sample's actual geometry."""
    th, tw = sample["video_size"]
    y_top0, y_top1, _, _ = sample["regions"]["top"]
    _, y_bot1, _, split_w = sample["regions"]["bl"]
    ax.plot([-0.5, tw - 0.5], [y_top1 - 0.5, y_top1 - 0.5], color=REGION_COLOR, lw=1.6)
    ax.plot([split_w - 0.5, split_w - 0.5], [y_top1 - 0.5, y_bot1 - 0.5], color=REGION_COLOR, lw=1.6)
    # Padding strips (only present in aspect mode).
    for y in (y_top0, y_bot1):
        if 0 < y < th:
            ax.plot([-0.5, tw - 0.5], [y - 0.5, y - 0.5], color=REGION_COLOR, lw=0.9, ls=":")


def render_stitched(sample: Dict[str, Any], out_path: Path) -> None:
    """The 9 frames WAN receives, with T-region boundaries drawn on top."""
    th, tw = sample["video_size"]
    frames = sample["video_all"]
    idxs = [sample["cond_idx"]] + sample["video_indices"]
    fig, axes = plt.subplots(3, 3, figsize=(9.6, 12.4), dpi=110, constrained_layout=True)
    for k, ax in enumerate(axes.flat):
        ax.imshow(to_uint8_hwc(frames[k]))
        _draw_region_lines(ax, sample)
        if k == 0:
            ax.set_title(f"first_frame (condition)\nepisode frame {idxs[k]}", fontsize=10, color="#c1121f")
            for spine in ax.spines.values():
                spine.set_color("#c1121f")
                spine.set_linewidth(2.5)
        else:
            ax.set_title(f"video_frames[{k - 1}]\nepisode frame {idxs[k]}  (+{idxs[k] - idxs[0]})", fontsize=10)
        ax.set_xticks([])
        ax.set_yticks([])
    fig.suptitle(
        f"G1-D episode {sample['episode_index']} (len {sample['length']})  |  "
        f"stitch_mode={sample['stitch_mode']}  |  stitched {th}x{tw} RGB, float [0,1]\n"
        f"WAN input = first_frame [3,{th},{tw}] + video_frames [8,3,{th},{tw}]",
        fontsize=11,
    )
    fig.savefig(out_path, bbox_inches="tight")
    plt.close(fig)


def render_layout(sample: Dict[str, Any], stats: Dict[str, Any], out_path: Path) -> None:
    """Per-camera pipeline stages + the annotated final canvas."""
    th, tw = sample["video_size"]
    canvas = to_uint8_hwc(sample["first_frame"])

    legacy = sample["stitch_mode"] == "legacy"
    ncols = 4 if legacy else 3
    widths = [1.15, 0.95, 0.75, 1.5] if legacy else [1.15, 0.9, 1.5]
    fig = plt.figure(figsize=(15.5 if legacy else 12.5, 10.0), dpi=110)
    gs = fig.add_gridspec(3, ncols, width_ratios=widths, hspace=0.32, wspace=0.24)

    for row, cam in enumerate(("top", "bl", "br")):
        nat = sample["native"][cam]
        y0, y1, x0, x1 = sample["regions"][cam]
        tile = canvas[y0:y1, x0:x1]

        ax = fig.add_subplot(gs[row, 0])
        ax.imshow(nat)
        ax.set_title(f"{CAM_TITLES[cam]}\nnative {nat.shape[0]}x{nat.shape[1]}", fontsize=9)
        ax.set_xticks([]); ax.set_yticks([])

        if legacy:
            s1 = to_uint8_hwc(sample["stage1"][cam][0])
            pad_geo = resize_pad_geometry(nat.shape[:2], (th, tw))
            ax = fig.add_subplot(gs[row, 1])
            ax.imshow(s1)
            box = content_bbox(s1)
            if box is not None:
                by0, by1, bx0, bx1 = box
                ax.add_patch(
                    mpatches.Rectangle(
                        (bx0 - 0.5, by0 - 0.5), bx1 - bx0 + 1, by1 - by0 + 1,
                        fill=False, ec=CONTENT_COLOR, lw=1.4,
                    )
                )
            ax.set_title(
                f"resize 1 of 2: pad to {th}x{tw}\n"
                f"scale {pad_geo['scale']:.3g} -> {pad_geo['new_h']}x{pad_geo['new_w']}, "
                f"pad y+{pad_geo['y_offset']}",
                fontsize=9,
            )
            ax.set_xticks([]); ax.set_yticks([])

        ax = fig.add_subplot(gs[row, 2 if legacy else 1])
        ax.imshow(tile)
        content = stats["regions"][cam]["content"]
        if content is not None:
            by0, by1, bx0, bx1 = content["box_in_region"]
            ax.add_patch(
                mpatches.Rectangle(
                    (bx0 - 0.5, by0 - 0.5), bx1 - bx0 + 1, by1 - by0 + 1,
                    fill=False, ec=CONTENT_COLOR, lw=1.4,
                )
            )
            sub = (f"content {content['hw'][0]}x{content['hw'][1]} = {content['fill_pct']}% of region, "
                   f"{content['canvas_pct']}% of canvas")
        else:
            sub = "no content detected"
        stage = "resize 2 of 2" if legacy else "single resize"
        ax.set_title(f"{stage}: T sub-region {tile.shape[0]}x{tile.shape[1]}\n{sub}", fontsize=9)
        ax.set_xticks([]); ax.set_yticks([])

    ax = fig.add_subplot(gs[:, ncols - 1])
    ax.imshow(canvas)
    _draw_region_lines(ax, sample)
    for cam in ("top", "bl", "br"):
        content = stats["regions"][cam]["content"]
        if content is None:
            continue
        by0, by1, bx0, bx1 = content["box_in_canvas"]
        ax.add_patch(
            mpatches.Rectangle(
                (bx0 - 0.5, by0 - 0.5), bx1 - bx0 + 1, by1 - by0 + 1,
                fill=False, ec=CONTENT_COLOR, lw=1.8,
            )
        )
        ax.text(
            bx0 + 3, by0 + 13, cam, color=CONTENT_COLOR, fontsize=9,
            fontweight="bold", ha="left", va="top",
        )
    ax.set_title(
        f"final stitched canvas {th}x{tw}\n"
        f"real pixels {stats['canvas_content_pct']}%   black padding {stats['canvas_black_pct']}%",
        fontsize=11,
    )
    ax.set_xticks([]); ax.set_yticks([])

    geo = sample["geometry"]
    if legacy:
        how = (f"legacy double-resize: each camera is padded to {th}x{tw} first, "
               f"then re-resized into a fixed 50/50 split")
    else:
        how = (f"aspect-preserving single resize: top {geo['top_h']}x{tw}, "
               f"wrists {geo['bot_h']}x{geo['split_w']}, "
               f"{geo['pad_top']}px + {geo['pad_bottom']}px vertical pad")
    fig.suptitle(
        f"G1-D T-shape stitch (stitch_mode={sample['stitch_mode']}), "
        f"episode {sample['episode_index']} frame {sample['cond_idx']}\n{how}\n"
        f"red = T-region boundaries,  dotted = padding edge,  cyan = measured non-black content box",
        fontsize=11,
    )
    fig.savefig(out_path, bbox_inches="tight")
    plt.close(fig)


def render_actions(sample: Dict[str, Any], out_path: Path) -> None:
    """initial_state + the 16-step qpos action chunk (post-reorder layout)."""
    state = sample["state"]
    actions = sample["actions"]
    n = actions.shape[0]
    t = np.arange(n + 1)  # 0 = state (condition frame), 1..n = action steps
    traj = np.vstack([state[None, :], actions])
    video_steps = [sample["action_indices"].index(v) + 1 for v in sample["video_indices"]]

    fig, axes = plt.subplots(2, 2, figsize=(14.0, 7.6), dpi=110)

    def _plot(ax, dims, title, ylabel):
        cmap = plt.get_cmap("viridis")
        for j, d in enumerate(dims):
            ax.plot(t, traj[:, d], marker="o", ms=3.2, lw=1.4,
                    color=cmap(j / max(1, len(dims) - 1)), label=DIM_LABELS[d])
        for vs in video_steps:
            ax.axvline(vs, color="#bbbbbb", lw=0.8, zorder=0)
        ax.axvline(0, color="#c1121f", lw=1.4)
        ax.set_title(title, fontsize=10)
        ax.set_xlabel("0 = initial_state (condition frame),  1..16 = action_sequence step")
        ax.set_ylabel(ylabel)
        ax.grid(alpha=0.25)
        ax.legend(fontsize=7, ncol=2, loc="best")

    _plot(axes[0, 0], LEFT_ARM, "left arm joints (dims 0-6, rad)", "rad")
    _plot(axes[0, 1], RIGHT_ARM, "right arm joints (dims 8-14, rad)", "rad")
    _plot(axes[1, 0], [LEFT_GRIP, RIGHT_GRIP], "grippers (dims 7 / 15, continuous)", "gripper")

    ax = axes[1, 1]
    delta = actions[-1] - state
    colors = ["#1f77b4" if i in LEFT_ARM else "#2ca02c" if i in RIGHT_ARM else "#d62728" for i in range(16)]
    ax.bar(np.arange(16), delta, color=colors)
    ax.set_xticks(np.arange(16))
    ax.set_xticklabels(DIM_LABELS, rotation=60, fontsize=7)
    ax.set_title("action[15] - initial_state  (motion covered by this chunk)", fontsize=10)
    ax.grid(alpha=0.25, axis="y")

    fig.suptitle(
        f"G1-D episode {sample['episode_index']}  cond frame {sample['cond_idx']}  |  "
        f"initial_state [16], action_sequence [16,16] raw qpos (no normalization)\n"
        f"dim order after reorder = [L0..L6, L_grip, R0..R6, R_grip];  "
        f"grey lines = the 8 steps that also have a video frame",
        fontsize=11,
    )
    fig.tight_layout(rect=[0, 0, 1, 0.93])
    fig.savefig(out_path, bbox_inches="tight")
    plt.close(fig)


def render_chunk_video(sample: Dict[str, Any], out_stem: Path, scale: int = 2, fps: int = 4) -> List[Path]:
    """Animate the 9 stitched frames (mp4 + gif) with region lines and labels."""
    th, tw = sample["video_size"]
    idxs = [sample["cond_idx"]] + sample["video_indices"]
    H, W = th * scale, tw * scale
    banner = 26
    rgb_frames: List[np.ndarray] = []
    for k in range(sample["video_all"].shape[0]):
        img = to_uint8_hwc(sample["video_all"][k])
        big = cv2.resize(img, (W, H), interpolation=cv2.INTER_NEAREST)
        cv2.line(big, (0, th // 2 * scale), (W, th // 2 * scale), (255, 45, 85), 1)
        cv2.line(big, (tw // 2 * scale, th // 2 * scale), (tw // 2 * scale, H), (255, 45, 85), 1)
        canvas = np.zeros((H + banner, W, 3), dtype=np.uint8)
        canvas[banner:] = big
        label = f"cond f{idxs[k]}" if k == 0 else f"target {k}/8  f{idxs[k]}  (+{idxs[k] - idxs[0]})"
        cv2.putText(canvas, f"ep{sample['episode_index']}  {label}", (6, 18),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.48, (255, 255, 255), 1, cv2.LINE_AA)
        rgb_frames.append(canvas)

    written: List[Path] = []
    mp4_path = out_stem.with_suffix(".mp4")
    vw = cv2.VideoWriter(str(mp4_path), cv2.VideoWriter_fourcc(*"mp4v"), fps, (W, H + banner))
    if vw.isOpened():
        for f in rgb_frames:
            vw.write(cv2.cvtColor(f, cv2.COLOR_RGB2BGR))
        vw.release()
        written.append(mp4_path)
    else:
        logger.warning("VideoWriter could not open %s", mp4_path)

    try:
        import imageio.v2 as imageio

        gif_path = out_stem.with_suffix(".gif")
        imageio.mimsave(gif_path, rgb_frames, duration=1.0 / fps, loop=0)
        written.append(gif_path)
    except Exception as exc:  # pragma: no cover
        logger.warning("gif export failed: %s", exc)
    return written


# --------------------------------------------------------------------------- #
# Report
# --------------------------------------------------------------------------- #
def write_report(
    out_dir: Path,
    ds,
    config_path: Path,
    config_dataset_dir: str,
    dataset_dir: str,
    records: List[Dict[str, Any]],
) -> Path:
    lines: List[str] = []
    a = lines.append
    a("# G1-D sample visualization report")
    a("")
    a(f"- config: `{config_path}` (read-only; `dataset_dir` overridden in memory)")
    a(f"- `dataset.dataset_dir` in config: `{config_dataset_dir}`")
    a(f"- dataset dir actually read: `{dataset_dir}`")
    a(f"- episodes indexed: {len(ds.episodes)}  (dataset `__len__` = {len(ds)} = episodes x 10)")
    a(f"- fps {ds.fps}, video_size {tuple(ds.video_size)}, num_video_frames {ds.num_video_frames}, "
      f"video_action_freq_ratio {ds.video_action_freq_ratio}, "
      f"global_downsample_rate {ds.global_downsample_rate}, action_chunk_size {ds.action_chunk_size}")
    a(f"- `dataset.stitch_mode` = `{ds.stitch_mode}`")
    a(f"- task_index -> instruction: {ds.task_index_to_text}")
    a("")
    a("## Sampling arithmetic")
    a("")
    a("With `global_downsample_rate=1`, `action_chunk_size=16`, `num_video_frames=8`, "
      "`video_action_freq_ratio=2`, for a condition frame `C`:")
    a("")
    a("```")
    a("action_indices = C+1, C+2, ..., C+16          (16 steps @30Hz = 0.53 s)")
    a("video_indices  = C+2, C+4, ..., C+16          (8 frames, every 2nd action step)")
    a("decoded        = [C] + video_indices          (9 frames per camera)")
    a("first_frame    = stitched[C];  video_frames = stitched[C+2 .. C+16]")
    a("```")
    a("")
    a(f"## Stitch layout (`stitch_mode={ds.stitch_mode}`)")
    a("")
    geo = records[0]["sample"]["geometry"]
    th, tw = geo["canvas_h"], geo["canvas_w"]
    a("```")
    if geo["pad_top"]:
        a(f"rows 0-{geo['pad_top'] - 1}: black padding")
    y = geo["pad_top"]
    a(f"+{'-' * 40}+  rows {y}-{y + geo['top_h'] - 1}")
    a(f"|      cam_left_high   ({geo['top_h']} x {tw})       |")
    y += geo["top_h"]
    a(f"+{'-' * 19}+{'-' * 20}+  rows {y}-{y + geo['bot_h'] - 1}")
    a(f"| cam_left_wrist    | cam_right_wrist    |")
    a(f"|   ({geo['bot_h']} x {geo['split_w']})      |   ({geo['bot_h']} x {geo['right_w']})       |")
    a(f"+{'-' * 19}+{'-' * 20}+")
    y += geo["bot_h"]
    if geo["pad_bottom"]:
        a(f"rows {y}-{th - 1}: black padding")
    a(f"  cols 0-{geo['split_w'] - 1}          cols {geo['split_w']}-{tw - 1}")
    a("```")
    a("")
    a("`cam_right_high` is decoded by nobody: it is not part of `_ALL_CAMS`.")
    a("")
    a("## Measured content boxes (non-black region of the condition frame)")
    a("")
    a("| sample | episode | cond frame | region | region HW | content HW | aspect | fill % | % of canvas |")
    a("|---|---|---|---|---|---|---|---|---|")
    for rec in records:
        st = rec["stats"]
        for cam in ("top", "bl", "br"):
            e = st["regions"][cam]
            c = e["content"]
            chw = f"{c['hw'][0]}x{c['hw'][1]}" if c else "-"
            a(f"| {rec['name']} | {rec['sample']['episode_index']} | {rec['sample']['cond_idx']} | "
              f"{cam} | {e['region_hw'][0]}x{e['region_hw'][1]} | {chw} | "
              f"{c['aspect'] if c else '-'} | {c['fill_pct'] if c else '-'} | "
              f"{c['canvas_pct'] if c else '-'} |")
    a("")
    a("| sample | real pixels % | black padding % |")
    a("|---|---|---|")
    for rec in records:
        a(f"| {rec['name']} | {rec['stats']['canvas_content_pct']} | {rec['stats']['canvas_black_pct']} |")
    a("")
    a("Native camera aspect ratio is 640/480 = 1.3333; every `aspect` column above should match it.")
    a("")
    a("## Files")
    a("")
    for rec in records:
        a(f"- **{rec['name']}** — episode {rec['sample']['episode_index']}, "
          f"cond frame {rec['sample']['cond_idx']} / {rec['sample']['length']}")
        for f in rec["files"]:
            a(f"  - `{Path(f).name}`")
    a("")
    path = out_dir / "layout_report.md"
    path.write_text("\n".join(lines), encoding="utf-8")
    return path


# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #
def main() -> None:
    ap = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter
    )
    ap.add_argument("--config", default=str(REPO_ROOT / DEFAULT_CONFIG))
    ap.add_argument("--dataset-dir", default=DEFAULT_DATASET_DIR,
                    help="local dataset root; overrides dataset.dataset_dir in memory only")
    ap.add_argument("--output-dir", default=str(REPO_ROOT / "outputs" / "g1d_sample_viz"))
    ap.add_argument("--num-samples", type=int, default=4)
    ap.add_argument("--stitch-mode", choices=["aspect", "legacy"], default=None,
                    help="override dataset.stitch_mode (default: whatever the config resolves to); "
                         "use 'legacy' to render the old double-resize layout for comparison")
    ap.add_argument("--episodes", default=None,
                    help="comma list of episode_index values (default: spread over the dataset)")
    ap.add_argument("--cond-fraction", type=float, default=0.35,
                    help="condition frame position as a fraction of episode length")
    ap.add_argument("--random", action="store_true",
                    help="sample episodes and condition frames randomly instead")
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    random.seed(args.seed)
    np.random.seed(args.seed)

    ds, _cfg, config_dataset_dir = build_dataset(
        Path(args.config), args.dataset_dir, out_dir, args.stitch_mode
    )
    logger.info("indexed %d episodes, __len__=%d", len(ds.episodes), len(ds))
    logger.info("instruction map: %s", ds.task_index_to_text)

    probe = sanity_check(ds)
    logger.info("--- real __getitem__ sample ---")
    for k, v in probe.items():
        logger.info("  %-18s %s", k, v)

    # Choose which (episode, condition frame) pairs to render.
    by_index = {int(e["episode_index"]): e for e in ds.episodes}
    picks: List[Tuple[Dict[str, Any], int]] = []
    if args.episodes:
        wanted = [int(x) for x in args.episodes.split(",") if x.strip()]
        for ei in wanted:
            if ei not in by_index:
                logger.warning("episode_index %d not indexed; skipping", ei)
                continue
            ep = by_index[ei]
            picks.append((ep, int(ep["length"] * args.cond_fraction)))
    elif args.random:
        for _ in range(args.num_samples):
            ep = ds.episodes[random.randrange(len(ds.episodes))]
            hi = int(ep["length"]) - ds.action_chunk_size * ds.global_downsample_rate - 1
            picks.append((ep, random.randint(0, max(0, hi))))
    else:
        n = min(args.num_samples, len(ds.episodes))
        for pos in np.linspace(0, len(ds.episodes) - 1, n).astype(int):
            ep = ds.episodes[int(pos)]
            picks.append((ep, int(ep["length"] * args.cond_fraction)))

    records: List[Dict[str, Any]] = []
    for i, (ep, cond_idx) in enumerate(picks):
        hi = int(ep["length"]) - ds.action_chunk_size * ds.global_downsample_rate - 1
        cond_idx = max(0, min(cond_idx, hi))
        name = f"sample{i:02d}_ep{int(ep['episode_index']):04d}_f{cond_idx:05d}"
        logger.info("=== %s (episode length %d) ===", name, ep["length"])
        try:
            sample = collect_sample(ds, ep, cond_idx)
        except Exception as exc:
            logger.error("  failed: %s", exc)
            continue
        stats = measure_layout(sample)
        logger.info("  video frames at %s", sample["video_indices"])
        logger.info("  real pixels %.1f%%, black padding %.1f%%",
                    stats["canvas_content_pct"], stats["canvas_black_pct"])
        for cam in ("top", "bl", "br"):
            c = stats["regions"][cam]["content"]
            if c:
                logger.info("  %-3s region %sx%s -> content %sx%s (%.1f%% of region)",
                            cam, *stats["regions"][cam]["region_hw"], *c["hw"], c["fill_pct"])

        files: List[Path] = []
        p = out_dir / f"{name}_01_stitched.png"; render_stitched(sample, p); files.append(p)
        p = out_dir / f"{name}_02_layout.png"; render_layout(sample, stats, p); files.append(p)
        p = out_dir / f"{name}_03_actions.png"; render_actions(sample, p); files.append(p)
        files.extend(render_chunk_video(sample, out_dir / f"{name}_04_chunk"))
        for f in files:
            logger.info("  wrote %s", f)

        records.append({"name": name, "sample": sample, "stats": stats, "files": [str(f) for f in files]})

    if not records:
        logger.error("no samples rendered")
        sys.exit(1)

    meta = {
        "config": str(args.config),
        "config_dataset_dir": str(config_dataset_dir),
        "dataset_dir_used": args.dataset_dir,
        "num_episodes_indexed": len(ds.episodes),
        "fps": ds.fps,
        "video_size": list(ds.video_size),
        "num_video_frames": ds.num_video_frames,
        "action_chunk_size": ds.action_chunk_size,
        "video_action_freq_ratio": ds.video_action_freq_ratio,
        "global_downsample_rate": ds.global_downsample_rate,
        "stitch_mode": ds.stitch_mode,
        "instructions": {str(k): v for k, v in ds.task_index_to_text.items()},
        "getitem_probe": probe,
        "samples": [
            {
                "name": r["name"],
                "episode_index": r["sample"]["episode_index"],
                "episode_length": r["sample"]["length"],
                "cond_idx": r["sample"]["cond_idx"],
                "video_indices": r["sample"]["video_indices"],
                "action_indices": r["sample"]["action_indices"],
                "instruction": r["sample"]["instruction"],
                "task_index": r["sample"]["task_index"],
                "initial_state": r["sample"]["state"].tolist(),
                "action_first": r["sample"]["actions"][0].tolist(),
                "action_last": r["sample"]["actions"][-1].tolist(),
                "layout": r["stats"],
                "files": [Path(f).name for f in r["files"]],
            }
            for r in records
        ],
    }
    (out_dir / "samples.json").write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")
    report = write_report(out_dir, ds, Path(args.config), str(config_dataset_dir), args.dataset_dir, records)
    logger.info("wrote %s", out_dir / "samples.json")
    logger.info("wrote %s", report)

    # The dataset mkdir's t5_cache_dir even with t5_mode=none; drop the empty stub.
    stub = out_dir / "t5_cache_unused"
    if stub.is_dir() and not any(stub.iterdir()):
        stub.rmdir()

    logger.info("done: %d samples in %s", len(records), out_dir)


if __name__ == "__main__":
    main()

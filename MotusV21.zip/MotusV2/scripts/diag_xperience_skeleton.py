#!/usr/bin/env python3
"""Diagnose Xperience cam0 projection convention via body skeleton.

full_body_mocap/keypoints (N,52,3) are ALREADY in cam0 frame (verified: a wrist
keypoint's z matches the cam0-frame wrist z to ~1e-3). All z are negative (scene
in front of a backward-z camera). We project the 52-joint skeleton to pixels
under the 4 sign conventions (sx, sy) and draw onto the actual stereo_left frame.
The convention that overlays the skeleton on the body is the correct one.
"""
import sys
from pathlib import Path
import h5py, numpy as np, cv2, decord

EP = "/cache/wx1469573/data/xperience-10m-clean/003dcaf0-edba-4787-ada0-187d2748f684/ep1"
FRAME = 200
OUT = Path("outputs/xp_diag"); OUT.mkdir(parents=True, exist_ok=True)

# COCO-ish skeleton edges for 52-joint body (best-effort: connect sequential + a
# few known pairs). We just draw all points + sequential links to see the shape.
def main():
    with h5py.File(f"{EP}/annotation.hdf5", "r") as f:
        kp = f["full_body_mocap/keypoints"][FRAME].astype(np.float64)  # (52,3)
        K_raw = f["calibration/cam0/K"][:].astype(np.float64)
    K = np.array([[K_raw[0],0,K_raw[2]],[0,K_raw[1],K_raw[3]],[0,0,1]])
    # center-crop to 512
    W=H=512
    K[0,2] = K_raw[2] - (2*K_raw[2]-W)/2.0
    K[1,2] = K_raw[3] - (2*K_raw[3]-H)/2.0
    fx,fy,cx,cy = K[0,0],K[1,1],K[0,2],K[1,2]
    print(f"kp z range: {kp[:,2].min():.3f}..{kp[:,2].max():.3f} (all<0 => z-backward)")
    print(f"kp x range: {kp[:,0].min():.3f}..{kp[:,0].max():.3f}, y range: {kp[:,1].min():.3f}..{kp[:,1].max():.3f}")

    vr = decord.VideoReader(f"{EP}/stereo_left.mp4", num_threads=1)
    img = vr[min(FRAME, len(vr)-1)].asnumpy().astype(np.uint8)
    H_img, W_img = img.shape[0], img.shape[1]

    def project(p, sx, sy):
        if p[2] >= -1e-4: return None  # behind (z must be <0 for scene)
        d = -p[2]
        u = sx*fx*p[0]/d + cx
        v = sy*fy*p[1]/d + cy
        return (u, v)

    convs = [(+1,+1,"C1 ++"), (+1,-1,"C2 +-"), (-1,+1,"C3 -+"), (-1,-1,"C4 --")]
    panels = []
    for sx, sy, label in convs:
        out = cv2.cvtColor(img, cv2.COLOR_RGB2BGR).copy()
        n_in = 0
        for j in range(len(kp)):
            uv = project(kp[j], sx, sy)
            if uv is None: continue
            ix, iy = int(round(uv[0])), int(round(uv[1]))
            if 0<=ix<W_img and 0<=iy<H_img:
                n_in += 1
                cv2.circle(out, (ix,iy), 3, (0,0,255), -1)
            else:
                cv2.circle(out, (max(0,min(W_img-1,ix)), max(0,min(H_img-1,iy))), 2, (0,255,255), 1)
        # connect sequential joints to reveal skeleton shape
        for j in range(len(kp)-1):
            uv1 = project(kp[j], sx, sy); uv2 = project(kp[j+1], sx, sy)
            if uv1 and uv2:
                p1=(int(round(uv1[0])),int(round(uv1[1]))); p2=(int(round(uv2[0])),int(round(uv2[1])))
                cv2.line(out, p1, p2, (0,255,0), 1)
        cv2.putText(out, f"{label}  in-frame:{n_in}/52", (8,24), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255), 1)
        panels.append((label, out))
        print(f"  {label}: {n_in}/52 keypoints in frame")

    grid = np.hstack([cv2.resize(p, (512,512)) for _, p in panels])
    cv2.imwrite(str(OUT/"xperience_skeleton_conventions.png"), grid)
    print(f"Saved -> {OUT/'xperience_skeleton_conventions.png'}")

if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Inspect a RoboTwin task-sampling mixture without loading model weights."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from omegaconf import OmegaConf

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from data.task_sampling import (  # noqa: E402
    resolve_task_sampling_weights,
    summarize_task_sampling,
)


def load_config(config_path: Path):
    config = OmegaConf.load(config_path)
    if hasattr(config, "defaults"):
        merged = OmegaConf.create()
        for default_path in config.defaults:
            resolved = Path(default_path)
            if not resolved.is_absolute():
                resolved = config_path.parent / resolved
            merged = OmegaConf.merge(merged, OmegaConf.load(resolved))
        config = OmegaConf.merge(merged, config)
    return config


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--tasks-file", type=Path, required=True)
    args = parser.parse_args()

    config_path = args.config.resolve()
    tasks_path = args.tasks_file.resolve()
    config = load_config(config_path)
    tasks = [
        line.strip()
        for line in tasks_path.read_text(encoding="utf-8").splitlines()
        if line.strip() and not line.lstrip().startswith("#")
    ]

    task_sampling = OmegaConf.to_object(
        config.dataset.get("task_sampling", OmegaConf.create())
    )
    weights = resolve_task_sampling_weights(tasks, task_sampling)
    groups = (
        task_sampling.get("groups", [])
        if task_sampling and task_sampling.get("enabled", False)
        else []
    )
    summary = summarize_task_sampling(
        weights,
        groups,
    )

    print(f"Tasks: {summary['num_tasks']}")
    print(f"Probability sum: {summary['probability_sum']:.8f}")
    print(
        "Probability range: "
        f"{summary['min_probability']:.4%} .. {summary['max_probability']:.4%}"
    )
    group_probabilities = summary.get("group_probabilities", {})
    if group_probabilities:
        print("Group totals (includes shared uniform mass):")
        for name, probability in group_probabilities.items():
            print(f"  {name:24s} {probability:8.3%}")
    print("Per-task probabilities:")
    for task_name, probability in sorted(
        weights.items(), key=lambda item: (-item[1], item[0])
    ):
        print(f"  {task_name:30s} {probability:8.3%}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

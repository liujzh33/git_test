"""MotusV2 training script.

Based on FastWAM's training pipeline, extended to support VLM expert.
Uses the same data flow (FastWAMProcessor, LinearNormalizer), DeepSpeed,
and training loop as FastWAM, with additional VLM inputs handling.
"""

import logging
import os
import sys
from pathlib import Path
from typing import Optional

import torch
from omegaconf import DictConfig, OmegaConf

# Ensure project root is on path
project_root = Path(__file__).resolve().parents[2]
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

from fastwam.trainer import Wan22Trainer
from fastwam.utils.logging_config import get_logger, setup_logging
from fastwam.utils import misc

logger = get_logger(__name__)


def _normalize_mixed_precision(mixed_precision: str) -> str:
    key = str(mixed_precision).strip().lower()
    if key not in {"no", "fp16", "bf16"}:
        raise ValueError(
            f"Unsupported mixed_precision: {mixed_precision}. "
            "Expected one of: ['no', 'fp16', 'bf16']."
        )
    return key


def _mixed_precision_to_model_dtype(mixed_precision: str) -> torch.dtype:
    precision = _normalize_mixed_precision(mixed_precision)
    if precision == "no":
        return torch.float32
    if precision == "fp16":
        return torch.float16
    return torch.bfloat16


def _resolve_train_device() -> str:
    if not torch.cuda.is_available():
        return "cpu"
    device_count = torch.cuda.device_count()
    if device_count <= 1:
        return "cuda:0"
    local_rank = int(os.environ.get("LOCAL_RANK", "0"))
    if local_rank < 0 or local_rank >= device_count:
        return "cuda:0"
    return f"cuda:{local_rank}"


def create_motus_v2_model(
    model_id: str,
    tokenizer_model_id: str,
    video_dit_config,
    tokenizer_max_len: int = 512,
    load_text_encoder: bool = True,
    proprio_dim: Optional[int] = None,
    action_dit_config=None,
    action_dit_pretrained_path: Optional[str] = None,
    skip_dit_load_from_pretrain: bool = False,
    video_scheduler=None,
    action_scheduler=None,
    loss=None,
    mot_checkpoint_mixed_attn: bool = True,
    redirect_common_files: bool = True,
    model_dtype: torch.dtype = torch.bfloat16,
    device: str = "cuda",
    vlm_config=None,
    vlm_model_path: Optional[str] = None,
    freeze_vlm: bool = False,
    motion_token_prediction=None,
):
    """Create a MotusV2 model instance.

    This factory function is designed to be called via Hydra instantiate()
    from the model config YAML.
    """
    from fastwam.models.wan22.motus_v2 import MotusV2

    if isinstance(video_dit_config, DictConfig):
        video_dit_config = OmegaConf.to_container(video_dit_config, resolve=True)
    if not isinstance(video_dit_config, dict):
        raise ValueError(f"`video_dit_config` must resolve to a dict, got {type(video_dit_config)}")

    if isinstance(action_dit_config, DictConfig):
        action_dit_config = OmegaConf.to_container(action_dit_config, resolve=True)
    if action_dit_config is None:
        action_dit_config = {}
    if not isinstance(action_dit_config, dict):
        raise ValueError(f"`action_dit_config` must resolve to a dict, got {type(action_dit_config)}")

    if isinstance(vlm_config, DictConfig):
        vlm_config = OmegaConf.to_container(vlm_config, resolve=True)
    if vlm_config is None:
        raise ValueError("`vlm_config` is required for MotusV2.")
    if not isinstance(vlm_config, dict):
        raise ValueError(f"`vlm_config` must resolve to a dict, got {type(vlm_config)}")

    if isinstance(video_scheduler, DictConfig):
        video_scheduler = OmegaConf.to_container(video_scheduler, resolve=True)
    if video_scheduler is None:
        video_scheduler = {}
    if not isinstance(video_scheduler, dict):
        raise ValueError(f"`video_scheduler` must be dict-like, got {type(video_scheduler)}")

    if isinstance(action_scheduler, DictConfig):
        action_scheduler = OmegaConf.to_container(action_scheduler, resolve=True)
    if action_scheduler is None:
        raise ValueError("`action_scheduler` is required for MotusV2.")
    if not isinstance(action_scheduler, dict):
        raise ValueError(f"`action_scheduler` must be dict-like, got {type(action_scheduler)}")
    required_keys = {"train_shift", "infer_shift", "num_train_timesteps"}
    missing_keys = required_keys - set(action_scheduler.keys())
    if missing_keys:
        raise ValueError(f"`action_scheduler` missing required keys: {sorted(missing_keys)}")

    if isinstance(loss, DictConfig):
        loss = OmegaConf.to_container(loss, resolve=True)
    if loss is None:
        loss = {}
    if not isinstance(loss, dict):
        raise ValueError(f"`loss` must be dict-like, got {type(loss)}")

    if isinstance(motion_token_prediction, DictConfig):
        motion_token_prediction = OmegaConf.to_container(motion_token_prediction, resolve=True)
    if motion_token_prediction is None:
        motion_token_prediction = {}
    if not isinstance(motion_token_prediction, dict):
        raise ValueError(
            f"`motion_token_prediction` must be dict-like, got {type(motion_token_prediction)}"
        )

    # Load VLM model if path provided
    vlm_model = None
    if vlm_model_path is not None:
        logger.info(f"Loading Qwen3-VL model from: {vlm_model_path}")
        from transformers import Qwen3VLForConditionalGeneration
        vlm_model = Qwen3VLForConditionalGeneration.from_pretrained(
            vlm_model_path,
            torch_dtype=model_dtype,
            device_map=None,  # Don't auto-place, MotusV2 handles device
        )
        logger.info("Qwen3-VL model loaded successfully.")

    return MotusV2.from_wan22_pretrained(
        device=device,
        torch_dtype=model_dtype,
        model_id=model_id,
        tokenizer_model_id=tokenizer_model_id,
        tokenizer_max_len=int(tokenizer_max_len),
        load_text_encoder=bool(load_text_encoder),
        proprio_dim=(None if proprio_dim is None else int(proprio_dim)),
        redirect_common_files=bool(redirect_common_files),
        video_dit_config=video_dit_config,
        action_dit_config=action_dit_config,
        action_dit_pretrained_path=action_dit_pretrained_path,
        skip_dit_load_from_pretrain=bool(skip_dit_load_from_pretrain),
        mot_checkpoint_mixed_attn=bool(mot_checkpoint_mixed_attn),
        vlm_config=vlm_config,
        vlm_model=vlm_model,
        vlm_model_path=vlm_model_path,
        freeze_vlm=bool(freeze_vlm),
        video_train_shift=float(video_scheduler.get("train_shift", 5.0)),
        video_infer_shift=float(video_scheduler.get("infer_shift", 5.0)),
        video_num_train_timesteps=int(video_scheduler.get("num_train_timesteps", 1000)),
        action_train_shift=float(action_scheduler["train_shift"]),
        action_infer_shift=float(action_scheduler["infer_shift"]),
        action_num_train_timesteps=int(action_scheduler["num_train_timesteps"]),
        loss_lambda_video=float(loss.get("lambda_video", 1.0)),
        loss_lambda_action=float(loss.get("lambda_action", 1.0)),
        loss_lambda_vlm=float(loss.get("lambda_vlm", 0.0)),
        motion_token_prediction=motion_token_prediction,
    )


def build_datasets(data_cfg: DictConfig):
    """Build train and validation datasets."""
    from hydra.utils import instantiate
    train_ds = instantiate(data_cfg.train)
    if data_cfg.get("val") is None:
        val_ds = train_ds
    else:
        train_stats_path = data_cfg.train.get("pretrained_norm_stats")
        default_stats_path = os.path.join(misc.get_work_dir(), "dataset_stats.json")
        val_stats_path = data_cfg.val.get("pretrained_norm_stats")
        pretrained_norm_stats = val_stats_path or train_stats_path or default_stats_path
        logger.info("Building val dataset with pretrained_norm_stats: %s", pretrained_norm_stats)
        val_ds = instantiate(data_cfg.val, pretrained_norm_stats=pretrained_norm_stats)
    return train_ds, val_ds


def run_training(cfg: DictConfig):
    """Main training entry point for MotusV2."""
    setup_logging(
        log_level=logging.INFO,
        is_main_process=torch.distributed.get_rank() == 0 if torch.distributed.is_initialized() else True,
    )
    misc.register_work_dir(cfg.output_dir)
    config_payload = OmegaConf.to_container(cfg, resolve=True)
    with open(Path(cfg.output_dir) / "config.yaml", "w") as f:
        OmegaConf.save(config_payload, f)

    model_device = _resolve_train_device()
    mixed_precision = _normalize_mixed_precision(cfg.mixed_precision)
    model_dtype = _mixed_precision_to_model_dtype(mixed_precision)

    model = create_motus_v2_model(
        model_id=cfg.model.model_id,
        tokenizer_model_id=cfg.model.tokenizer_model_id,
        video_dit_config=cfg.model.video_dit_config,
        tokenizer_max_len=int(cfg.model.get("tokenizer_max_len", 512)),
        load_text_encoder=bool(cfg.model.get("load_text_encoder", True)),
        proprio_dim=cfg.model.get("proprio_dim"),
        action_dit_config=cfg.model.get("action_dit_config"),
        action_dit_pretrained_path=cfg.model.get("action_dit_pretrained_path"),
        skip_dit_load_from_pretrain=bool(cfg.model.get("skip_dit_load_from_pretrain", False)),
        video_scheduler=cfg.model.get("video_scheduler"),
        action_scheduler=cfg.model.get("action_scheduler"),
        loss=cfg.model.get("loss"),
        mot_checkpoint_mixed_attn=bool(cfg.model.get("mot_checkpoint_mixed_attn", True)),
        redirect_common_files=bool(cfg.model.get("redirect_common_files", True)),
        model_dtype=model_dtype,
        device=model_device,
        vlm_config=cfg.model.get("vlm_config"),
        vlm_model_path=cfg.model.get("vlm_model_path"),
        freeze_vlm=bool(cfg.model.get("freeze_vlm", False)),
        motion_token_prediction=cfg.model.get("motion_token_prediction"),
    )

    train_ds, val_ds = build_datasets(cfg.data)

    trainer = Wan22Trainer(
        cfg=cfg,
        model=model,
        train_dataset=train_ds,
        val_dataset=val_ds,
    )
    trainer.train()


if __name__ == "__main__":
    import hydra

    @hydra.main(version_base="1.3", config_path="../../configs", config_name="sim_libero.yaml")
    def main(cfg: DictConfig):
        run_training(cfg)

    main()

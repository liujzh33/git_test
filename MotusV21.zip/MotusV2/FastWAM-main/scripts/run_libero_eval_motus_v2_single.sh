#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "${ROOT_DIR}"

source /root/miniconda3/etc/profile.d/conda.sh
conda activate motus_test
export PYTHONPATH="/home/ma-user/work/wx1469672/motus/LIBERO-master:/home/ma-user/work/wx1469672/motus/ref_eval_code/FastWAM-main/src:${PYTHONPATH:-}"
export MUJOCO_GL=osmesa
export DIFFSYNTH_MODEL_BASE_PATH="/cache/wwx1484778/motus_weights"
export HF_DATASETS_CACHE="/cache/wwx1484778/libero_lerobot_hf"

CKPT="/cache/wwx1484778/Fastwam/runs/libero_motus_v2_2cam224_1e-4/2026-06-03_09-51-05/checkpoints/weights/step_040000.pt"
STATS="/cache/wwx1484778/Fastwam/runs/libero_motus_v2_2cam224_1e-4/2026-06-03_09-51-05/dataset_stats.json"
DATA_ROOT="/cache/wwx1484778/libero_lerobot_hf"
DATASET_DIRS="['${DATA_ROOT}/libero_object_no_noops_lerobot', '${DATA_ROOT}/libero_spatial_no_noops_lerobot', '${DATA_ROOT}/libero_goal_no_noops_lerobot', '${DATA_ROOT}/libero_10_no_noops_lerobot']"

# --- Configurable parameters ---
TASK_SUITE="${1:-libero_spatial}"   # libero_spatial / libero_object / libero_goal / libero_10
TASK_ID="${2:-4}"                   # task index within the suite (0-based)
NUM_TRIALS="${3:-50}"               # number of evaluation trials
GPU_IDS="${4:-0}"                   # GPU(s) to use, e.g. 0 or 0,1

echo "Evaluating: suite=${TASK_SUITE}, task_id=${TASK_ID}, trials=${NUM_TRIALS}, gpus=${GPU_IDS}"

CUDA_VISIBLE_DEVICES=${GPU_IDS} python experiments/libero/eval_motus_v2_libero.py \
  task=libero_motus_v2_2cam224_1e-4 \
  ckpt=${CKPT} \
  EVALUATION.dataset_stats_path=${STATS} \
  EVALUATION.task_suite_name=${TASK_SUITE} \
  EVALUATION.task_id=${TASK_ID} \
  EVALUATION.num_trials=${NUM_TRIALS} \
  data.train.dataset_dirs="${DATASET_DIRS}"

#!/bin/bash
set -euo pipefail

source /root/miniconda3/etc/profile.d/conda.sh
conda activate motus_test
export PYTHONWARNINGS="ignore"
export PYTHONPATH="/home/ma-user/work/wx1469672/motus/LIBERO-master:/home/ma-user/work/wx1469672/motus/ref_eval_code/FastWAM-main/src:/home/ma-user/work/wx1469672/motus/ref_eval_code/FastWAM-main/experiments:${PYTHONPATH:-}"
export DIFFSYNTH_MODEL_BASE_PATH="/cache/wwx1484778/motus_weights"
export DIFFSYNTH_SKIP_DOWNLOAD=true

# 平台环境变量映射到 accelerate 变量
export NNODES=${WORLD_SIZE:-1}
export NODE_RANK=${RANK:-0}
export MASTER_ADDR=${MASTER_ADDR:-$(hostname -I | awk '{print $1}')}
export MASTER_PORT=${MASTER_PORT:-29500}

DATA_DIR="/cache/wwx1484778/robotwin2.0-fastwam/robotwin2.0"
DATASET_DIRS="['${DATA_DIR}']"

cd /home/ma-user/work/wx1469672/motus/ref_eval_code/FastWAM-main
bash scripts/train_zero1_motus_v2.sh 8 \
  task=robotwin_motus_v2_3cam_384_1e-4 \
  data.train.dataset_dirs="${DATASET_DIRS}" \
  data.train.val_set_proportion=0.0 \
  data.train.text_embedding_cache_dir=/cache/wwx1484778/robotwin2.0-fastwam/text_embeds_cache \
  max_steps=30000 \
  upload_on_save=true
#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "${ROOT_DIR}"

source /root/miniconda3/etc/profile.d/conda.sh
conda activate motus_test
export PYTHONPATH="/home/ma-user/work/wx1469672/motus/LIBERO-master:/home/ma-user/work/wx1469672/motus/ref_eval_code/FastWAM-main/src:${PYTHONPATH:-}"
export MUJOCO_GL=osmesa
export DIFFSYNTH_MODEL_BASE_PATH="/cache/wwx1484778/motus_weights"
export HF_DATASETS_CACHE="/cache/wwx1484778/libero_lerobot_hf"

# Find latest run directory and read final checkpoint path
RUN_BASE="/cache/wwx1484778/Fastwam/runs/libero_motus_v2_2cam224_1e-4"
FINAL_CKPT_FILE=$(ls -t "$RUN_BASE"/*/final_checkpoint.txt 2>/dev/null | head -1)
if [ -z "$FINAL_CKPT_FILE" ]; then
    echo "Error: No final_checkpoint.txt found"
    exit 1
fi
CKPT=$(cat "$FINAL_CKPT_FILE")
RUN_DIR=$(dirname "$FINAL_CKPT_FILE")
STATS="${RUN_DIR}/dataset_stats.json"
DATA_ROOT="/cache/wwx1484778/libero_lerobot_hf"
DATASET_DIRS="['${DATA_ROOT}/libero_object_no_noops_lerobot', '${DATA_ROOT}/libero_spatial_no_noops_lerobot', '${DATA_ROOT}/libero_goal_no_noops_lerobot', '${DATA_ROOT}/libero_10_no_noops_lerobot']"

echo "Using checkpoint: $CKPT"
echo "Using stats: $STATS"

# --- Single-task mode (original) ---
# Uncomment below to evaluate a single task on specific GPUs:
#
# CUDA_VISIBLE_DEVICES=0 python experiments/libero/eval_motus_v2_libero.py \
#   task=libero_motus_v2_2cam224_1e-4 \
#   ckpt=${CKPT} \
#   EVALUATION.dataset_stats_path=${STATS} \
#   EVALUATION.task_suite_name=libero_object \
#   EVALUATION.task_id=0 \
#   EVALUATION.num_trials=10

# --- Parallel multi-GPU mode ---
# Uses run_libero_manager_motus_v2.py to distribute tasks across GPUs via tmux.
# Each GPU runs one task at a time (configurable via MULTIRUN.max_tasks_per_gpu).
CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7 python experiments/libero/run_libero_manager_motus_v2.py \
  task=libero_motus_v2_2cam224_1e-4 \
  ckpt=${CKPT} \
  EVALUATION.dataset_stats_path=${STATS} \
  EVALUATION.num_trials=50 \
  data.train.dataset_dirs="${DATASET_DIRS}" \
  MULTIRUN.num_gpus=8 \
  MULTIRUN.max_tasks_per_gpu=4 \
  MULTIRUN.task_suite_names='["libero_spatial", "libero_object", "libero_goal", "libero_10"]'

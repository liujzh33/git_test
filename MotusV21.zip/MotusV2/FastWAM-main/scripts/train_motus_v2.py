"""MotusV2 training entry point.

Wraps the MotusV2 training function for Hydra/Accelerate launching.
"""

import hydra
from omegaconf import DictConfig

from experiments.libero.train_motus_v2 import run_training
from fastwam.utils.config_resolvers import register_default_resolvers

register_default_resolvers()


@hydra.main(config_path="../configs", config_name="train", version_base="1.3")
def main(cfg: DictConfig):
    run_training(cfg)


if __name__ == "__main__":
    main()

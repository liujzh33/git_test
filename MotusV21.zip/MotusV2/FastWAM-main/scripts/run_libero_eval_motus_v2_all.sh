#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "${ROOT_DIR}"

source /root/miniconda3/etc/profile.d/conda.sh
conda activate motus_test
export HYDRA_FULL_ERROR=1
export PYTHONPATH="/home/ma-user/work/wx1469672/motus/LIBERO-master:/home/ma-user/work/wx1469672/motus/ref_eval_code/FastWAM-main/src:${PYTHONPATH:-}"
export MUJOCO_GL=osmesa
export DIFFSYNTH_MODEL_BASE_PATH="/cache/wwx1484778/motus_weights"

CKPT="/cache/wwx1484778/motus/train_log/0610/runs/libero_motus_v2_2cam224_1e-4/2026-06-09_12-01-31/checkpoints/weights/step_020000.pt"
STATS="/cache/wwx1484778/motus/train_log/0610/runs/libero_motus_v2_2cam224_1e-4/2026-06-09_12-01-31/dataset_stats.json"

# --- Single-task mode (original) ---
# Uncomment below to evaluate a single task on specific GPUs:
#
# CUDA_VISIBLE_DEVICES=0 python experiments/libero/eval_motus_v2_libero.py \
#   task=libero_motus_v2_2cam224_1e-4 \
#   ckpt=${CKPT} \
#   EVALUATION.dataset_stats_path=${STATS} \
#   EVALUATION.task_suite_name=libero_object \
#   EVALUATION.task_id=0 \
#   EVALUATION.num_trials=10

# --- Parallel multi-GPU mode ---
# Uses run_libero_manager_motus_v2.py to distribute tasks across GPUs via tmux.
# Each GPU runs one task at a time (configurable via MULTIRUN.max_tasks_per_gpu).
CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7 python experiments/libero/run_libero_manager_motus_v2.py \
  task=libero_motus_v2_2cam224_1e-4 \
  ckpt=${CKPT} \
  EVALUATION.dataset_stats_path=${STATS} \
  EVALUATION.num_trials=50 \
  MULTIRUN.num_gpus=8 \
  MULTIRUN.max_tasks_per_gpu=2 \
  MULTIRUN.task_suite_names='["libero_spatial", "libero_object", "libero_goal", "libero_10"]'

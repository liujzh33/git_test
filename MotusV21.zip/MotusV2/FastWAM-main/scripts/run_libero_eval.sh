#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "${ROOT_DIR}"

source /root/miniconda3/etc/profile.d/conda.sh
conda activate motus_test
export PYTHONPATH="/home/ma-user/work/wx1469672/motus/LIBERO-master:/home/ma-user/work/wx1469672/motus/ref_eval_code/FastWAM-main/src:${PYTHONPATH:-}"
export MUJOCO_GL=osmesa
export DIFFSYNTH_MODEL_BASE_PATH="/cache/wwx1484778/motus_weights"
CUDA_VISIBLE_DEVICES=4,5,6,7 python experiments/libero/run_libero_manager.py \
  task=libero_uncond_2cam224_1e-4 \
  ckpt=/cache/wwx1484778/Fastwam/runs/libero_uncond_2cam224_1e-4/2026-05-20_06-54-16/checkpoints/weights/step_020000.pt \
  EVALUATION.dataset_stats_path=/cache/wwx1484778/Fastwam/runs/libero_uncond_2cam224_1e-4/2026-05-20_06-54-16/dataset_stats.json \
  EVALUATION.num_trials=50 \
  MULTIRUN.num_gpus=4 \
  MULTIRUN.task_suite_names='["libero_object"]'

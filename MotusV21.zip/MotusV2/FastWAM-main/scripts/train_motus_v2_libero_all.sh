#!/usr/bin/env bash
set -euo pipefail

# MotusV2 四场景联合训练脚本
# 训练 libero_object + libero_spatial + libero_goal + libero_10 四个场景
# 用法: bash scripts/train_motus_v2_libero_all.sh [NPROC_PER_NODE]

source /root/miniconda3/etc/profile.d/conda.sh
conda activate motus_test

export PYTHONPATH="/home/ma-user/work/wx1469672/motus/LIBERO-master:/home/ma-user/work/wx1469672/motus/ref_eval_code/FastWAM-main/src:/home/ma-user/work/wx1469672/motus/ref_eval_code/FastWAM-main/experiments:${PYTHONPATH:-}"
export PYTHONWARNINGS="ignore"
export MUJOCO_GL=osmesa
export DIFFSYNTH_MODEL_BASE_PATH="/cache/wwx1484778/motus_weights"
export CUDA_VISIBLE_DEVICES=4,5,6,7
NPROC_PER_NODE="${1:-4}"

DATA_ROOT="/cache/wwx1484778/libero_lerobot_hf"
DATASET_DIRS="['${DATA_ROOT}/libero_object_no_noops_lerobot', '${DATA_ROOT}/libero_spatial_no_noops_lerobot', '${DATA_ROOT}/libero_goal_no_noops_lerobot', '${DATA_ROOT}/libero_10_no_noops_lerobot']"

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "${ROOT_DIR}"

bash scripts/train_zero1_motus_v2.sh ${NPROC_PER_NODE} \
  task=libero_motus_v2_2cam224_1e-4 \
  data.train.dataset_dirs="${DATASET_DIRS}" \
  data.train.val_set_proportion=0.0 \
  data.train.text_embedding_cache_dir=${DATA_ROOT}/text_embeds_cache \
  max_steps=40000

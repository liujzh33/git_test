#!/usr/bin/env bash
set -euo pipefail

# MotusV2 RoboTwin 训练脚本
# 用法: bash scripts/train_robotwin_motus_v2.sh [NPROC_PER_NODE]

source /root/miniconda3/etc/profile.d/conda.sh
conda activate motus_test

# export PYTHONPATH="/home/ma-user/work/wx1469672/motus/LIBERO-master:/home/ma-user/work/wx1469672/motus/ref_eval_code/FastWAM-main/src:/home/ma-user/work/wx1469672/motus/ref_eval_code/FastWAM-main/experiments:${PYTHONPATH:-}"
export PYTHONWARNINGS="ignore"
export DIFFSYNTH_MODEL_BASE_PATH="/cache/wwx1484778/motus_weights"
export DIFFSYNTH_SKIP_DOWNLOAD=true
export CUDA_VISIBLE_DEVICES=4,5,6,7
NPROC_PER_NODE="${1:-4}"

DATA_DIR="/cache/wwx1484778/robotwin2.0-fastwam/robotwin2.0"
DATASET_DIRS="['${DATA_DIR}']"

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "${ROOT_DIR}"

# bash scripts/train_zero1_motus_v2.sh ${NPROC_PER_NODE} \
#   task=robotwin_motus_v2_3cam_384_1e-4 \
#   data.train.dataset_dirs="${DATASET_DIRS}" \
#   data.train.val_set_proportion=0.0 \
#   data.train.text_embedding_cache_dir=/cache/wwx1484778/robotwin2.0-fastwam/text_embeds_cache

cd /home/ma-user/work/wx1469672/motus/ref_eval_code/FastWAM-main
bash scripts/train_zero1_motus_v2.sh ${NPROC_PER_NODE} \
  task=robotwin_motus_v2_3cam_384_1e-4 \
  data.train.dataset_dirs="${DATASET_DIRS}" \
  data.train.val_set_proportion=0.0 \
  data.train.text_embedding_cache_dir=/cache/wwx1484778/robotwin2.0-fastwam/text_embeds_cache \
  max_steps=60000 \
  upload_on_save=true
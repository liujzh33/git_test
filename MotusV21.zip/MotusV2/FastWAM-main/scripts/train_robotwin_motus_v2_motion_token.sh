#!/usr/bin/env bash
set -euo pipefail

# MotusV2 RoboTwin motion-token training entrypoint.
# Usage: bash scripts/train_robotwin_motus_v2_motion_token.sh [NPROC_PER_NODE]

source /root/miniconda3/etc/profile.d/conda.sh
conda activate motus_test

export PYTHONWARNINGS="ignore"
export DIFFSYNTH_MODEL_BASE_PATH="/cache/wwx1484778/motus_weights"
export DIFFSYNTH_SKIP_DOWNLOAD=true

NPROC_PER_NODE="${1:-4}"
if [[ $# -gt 0 ]]; then
  shift
fi
DATA_DIR="/cache/wwx1484778/robotwin2.0-fastwam/robotwin2.0"
DATASET_DIRS="['${DATA_DIR}']"

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "${ROOT_DIR}"

bash scripts/train_zero1_motus_v2.sh "${NPROC_PER_NODE}" \
  task=robotwin_motus_v2_motion_token_3cam_384_1e-4 \
  data.train.dataset_dirs="${DATASET_DIRS}" \
  data.val.dataset_dirs="${DATASET_DIRS}" \
  data.train.text_embedding_cache_dir=/cache/wwx1484778/robotwin2.0-fastwam/text_embeds_cache \
  data.val.text_embedding_cache_dir=/cache/wwx1484778/robotwin2.0-fastwam/text_embeds_cache \
  "$@"

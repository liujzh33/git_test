#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "${ROOT_DIR}"

source /root/miniconda3/etc/profile.d/conda.sh
conda activate motus_test
export PYTHONPATH="/home/ma-user/work/wx1469672/motus/LIBERO-master:/home/ma-user/work/wx1469672/motus/ref_eval_code/FastWAM-main/src:${PYTHONPATH:-}"
export MUJOCO_GL=osmesa
export DIFFSYNTH_MODEL_BASE_PATH="/cache/wwx1484778/motus_weights"
CUDA_VISIBLE_DEVICES=0,1,2,3 python experiments/libero/run_libero_manager.py \
  task=libero_uncond_2cam224_1e-4 \
  ckpt=/cache/wwx1484778/Fastwam/runs/libero_uncond_2cam224_1e-4/2026-06-05_19-19-02/checkpoints/weights/step_040000.pt \
  EVALUATION.dataset_stats_path=/cache/wwx1484778/Fastwam/runs/libero_uncond_2cam224_1e-4/2026-06-05_19-19-02/dataset_stats.json \
  EVALUATION.num_trials=50 \
  MULTIRUN.num_gpus=4 \
  MULTIRUN.max_tasks_per_gpu=4 \
  MULTIRUN.task_suite_names='["libero_spatial", "libero_object", "libero_goal", "libero_10"]'

#!/usr/bin/env bash
set -euo pipefail

# 等待 GPU 4,5,6,7 显存同时小于 5000 MiB 时启动训练
# 显存检查间隔（秒）
CHECK_INTERVAL=60

check_gpu_memory() {
    local gpu_id=$1
    # 使用 nvidia-smi 查询显存（MiB），去掉 MiB 后缀转成数字
    nvidia-smi --id=${gpu_id} --query-gpu=memory.used --format=csv,noheader,nounits 2>/dev/null || echo "9999"
}

wait_for_gpus() {
    local gpus=(4 5 6 7)
    local threshold=5000

    echo "[$(date)] 等待 GPU ${gpus[*]} 显存 < ${threshold} MiB..."

    while true; do
        local all_available=true

        for gpu in "${gpus[@]}"; do
            local mem=$(check_gpu_memory ${gpu})
            echo "[$(date)] GPU ${gpu}: ${mem} MiB used"

            if [ "$(awk "BEGIN {print ($mem >= $threshold)}")" = "1" ]; then
                all_available=false
            fi
        done

        if $all_available; then
            echo "[$(date)] 所有 GPU 显存检查通过，启动训练！"
            return 0
        fi

        echo "[$(date)] GPU 仍有占用，等待 ${CHECK_INTERVAL}s..."
        sleep ${CHECK_INTERVAL}
    done
}

# 主逻辑
wait_for_gpus

cd "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

bash scripts/train_motus_v2_libero_object.sh

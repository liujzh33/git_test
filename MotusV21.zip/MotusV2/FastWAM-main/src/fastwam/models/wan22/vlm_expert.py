"""VLM Expert for Motus-V2: Qwen3-VL as a third expert in the FastWAM MoT framework.

This module adapts the Qwen3-VL model to be compatible with FastWAM's ActionDiT interface,
enabling it to participate in trimodal mixed attention alongside Video and Action experts.

Key design:
- VLMExpert implements the same interface as ActionDiT: blocks, num_heads, attn_head_dim
- Each VLMBlock contains norm1, QKV projection, Q/K norm, output projection, modulation params
- VLM uses its own internal FFN (no separate FFN in VLMBlock)
- 28 VLM layers are mapped to 30 WAN layers (layers 26/27 are reused for layers 28/29)
"""

import torch
import torch.nn as nn
from typing import Any, Dict, List, Optional, Tuple

from fastwam.utils.logging_config import get_logger
from .wan_video_dit import (
    RMSNorm,
    modulate,
    precompute_freqs_cis,
    sinusoidal_embedding_1d,
)

logger = get_logger(__name__)


class VLMBlock(nn.Module):
    """Per-layer projection block for VLM expert in the MoT framework.

    Unlike DiTBlock (which has self_attn, cross_attn, FFN), VLMBlock only provides:
    - norm1 + QKV projection to WAN head space
    - Q/K normalization (RMSNorm)
    - Output projection back to VLM dim
    - Modulation parameters for AdaLN compatibility

    VLM uses its own internal FFN and cross-attention, handled via
    extract_per_layer_features() in pre_dit().
    """

    def __init__(
        self,
        vlm_dim: int,
        num_heads: int,
        attn_head_dim: int,
        eps: float = 1e-5,
    ):
        super().__init__()
        self.vlm_dim = vlm_dim
        self.num_heads = num_heads
        self.attn_head_dim = attn_head_dim
        self.unified_dim = num_heads * attn_head_dim

        # LayerNorm (matching DiTBlock style)
        self.norm1 = nn.LayerNorm(vlm_dim, eps=eps, elementwise_affine=False)

        # QKV projection: VLM dim -> Unified WAN head space
        # Shape: (3, num_heads, vlm_dim, attn_head_dim)
        self.wan_vlm_qkv = nn.Parameter(
            torch.randn(3, num_heads, vlm_dim, attn_head_dim)
            / (vlm_dim * attn_head_dim) ** 0.5
        )

        # Output projection: Unified dim -> VLM dim
        self.wan_vlm_o = nn.Linear(self.unified_dim, vlm_dim, bias=False)

        # Q/K normalization (RMSNorm, matching WAN/WAM style)
        self.wan_vlm_norm_q = RMSNorm(self.unified_dim, eps=eps)
        self.wan_vlm_norm_k = RMSNorm(self.unified_dim, eps=eps)

        # Modulation parameters (6 params: shift_msa, scale_msa, gate_msa, shift_mlp, scale_mlp, gate_mlp)
        # Same format as DiTBlock.modulation for compatibility with MoT._split_modulation()
        self.modulation = nn.Parameter(torch.randn(1, 6, vlm_dim) / vlm_dim**0.5)


class VLMExpert(nn.Module):
    """VLM Expert module that integrates Qwen3-VL into the FastWAM MoT framework.

    This expert:
    1. Calls Qwen3-VL's vision encoder to extract image features
    2. Runs Qwen3-VL language model to get per-layer hidden states
    3. Maps 28 VLM layers to 30 WAN layers (26/27 reused for 28/29)
    4. Projects VLM features to WAN head space via per-layer VLMBlocks
    5. Returns tokens in the same format as ActionDiT.pre_dit()

    The Qwen3-VL model itself is stored as vlm_model and is optionally trainable.
    """

    VLM_BACKBONE_SKIP_PREFIXES = ("blocks.",)
    VLM_BACKBONE_META_KEYS = (
        "vlm_dim",
        "num_heads",
        "attn_head_dim",
        "num_layers",
        "freq_dim",
        "eps",
    )

    def __init__(
        self,
        vlm_dim: int = 2048,
        num_heads: int = 24,
        attn_head_dim: int = 128,
        num_layers: int = 30,
        freq_dim: int = 256,
        eps: float = 1e-5,
        vlm_model: Optional[Any] = None,
        freeze_vlm: bool = False,
        use_gradient_checkpointing: bool = False,
    ):
        super().__init__()
        self.vlm_dim = vlm_dim
        self.num_heads = num_heads
        self.attn_head_dim = attn_head_dim
        self.num_layers = num_layers
        self.freq_dim = freq_dim
        self.eps = eps
        self.freeze_vlm = freeze_vlm
        self.use_gradient_checkpointing = use_gradient_checkpointing

        if num_heads <= 0:
            raise ValueError(f"`num_heads` must be > 0, got {num_heads}")
        if attn_head_dim <= 0:
            raise ValueError(f"`attn_head_dim` must be > 0, got {attn_head_dim}")
        if attn_head_dim % 2 != 0:
            raise ValueError(f"`attn_head_dim` must be even for RoPE, got {attn_head_dim}")

        # VLMBlocks for projecting VLM features to WAN head space
        self.blocks = nn.ModuleList([
            VLMBlock(
                vlm_dim=vlm_dim,
                num_heads=num_heads,
                attn_head_dim=attn_head_dim,
                eps=eps,
            )
            for _ in range(num_layers)
        ])

        # RoPE frequencies for VLM tokens (1D, matching action expert)
        self.freqs = precompute_freqs_cis(attn_head_dim, end=4096)

        # Time embedding for VLM expert (same structure as ActionDiT)
        self.time_embedding = nn.Sequential(
            nn.Linear(freq_dim, vlm_dim),
            nn.SiLU(),
            nn.Linear(vlm_dim, vlm_dim),
        )
        self.time_projection = nn.Sequential(
            nn.SiLU(), nn.Linear(vlm_dim, vlm_dim * 6)
        )

        # Store VLM model reference (not as nn.Module to avoid parameter duplication)
        self._vlm_model = None
        self._vlm_device = None
        self._vlm_dtype = None
        if vlm_model is not None:
            self.set_vlm_model(vlm_model)

        logger.info(
            f"VLMExpert initialized: vlm_dim={vlm_dim}, num_heads={num_heads}, "
            f"attn_head_dim={attn_head_dim}, num_layers={num_layers}, "
            f"freeze_vlm={freeze_vlm}"
        )

    def set_vlm_model(self, vlm_model):
        """Set the Qwen3-VL model reference."""
        self._vlm_model = vlm_model
        if self.freeze_vlm:
            # Freeze VLM parameters
            if hasattr(vlm_model, 'parameters'):
                for param in vlm_model.parameters():
                    param.requires_grad = False
            logger.info("VLM model parameters frozen.")

    @property
    def vlm_model(self):
        return self._vlm_model

    def _process_vlm_inputs_to_tokens(
        self,
        vlm_inputs,
        B: int,
    ) -> Tuple[torch.Tensor, torch.Tensor, Optional[torch.Tensor], Optional[list], torch.Tensor]:
        """Convert VLM inputs to tokens ready for Qwen3-VL forward pass.

        Args:
            vlm_inputs: VLM inputs (list of dicts or dict of tensors)
            B: Batch size

        Returns:
            Tuple of (inputs_embeds, attention_mask, visual_pos_masks, deepstack_image_embeds, position_ids)
        """
        device = self._vlm_device or next(self.blocks.parameters()).device
        dtype = self._vlm_dtype or next(self.blocks.parameters()).dtype

        if isinstance(vlm_inputs, list):
            input_ids_list = [vlm_input['input_ids'] for vlm_input in vlm_inputs]
            attention_mask_list = [vlm_input.get('attention_mask') for vlm_input in vlm_inputs]
            pixel_values_list = [vlm_input.get('pixel_values') for vlm_input in vlm_inputs]
            image_grid_thw_list = [vlm_input.get('image_grid_thw') for vlm_input in vlm_inputs]

            max_seq_len = max(ids.shape[1] for ids in input_ids_list)
            padded_input_ids = []
            padded_attention_masks = []

            for ids, mask in zip(input_ids_list, attention_mask_list):
                if ids.shape[1] < max_seq_len:
                    padding_size = max_seq_len - ids.shape[1]
                    id_padding = torch.zeros(ids.shape[0], padding_size, dtype=ids.dtype, device=ids.device)
                    padded_ids = torch.cat([ids, id_padding], dim=1)
                    mask_padding = torch.zeros(mask.shape[0], padding_size, dtype=mask.dtype, device=mask.device)
                    padded_mask = torch.cat([mask, mask_padding], dim=1)
                else:
                    padded_ids = ids
                    padded_mask = mask
                padded_input_ids.append(padded_ids)
                padded_attention_masks.append(padded_mask)

            input_ids_batch = torch.cat(padded_input_ids, dim=0).to(device)
            attention_mask_batch = torch.cat(padded_attention_masks, dim=0).to(device)
            pixel_values_batch = torch.cat([pv.to(device) for pv in pixel_values_list], dim=0)
            image_grid_thw_batch = torch.cat([igt.to(device) for igt in image_grid_thw_list], dim=0)
        else:
            input_ids_batch = vlm_inputs['input_ids'].to(device)
            attention_mask_batch = vlm_inputs['attention_mask'].to(device)
            pixel_values_batch = vlm_inputs['pixel_values'].to(device)
            image_grid_thw_batch = vlm_inputs['image_grid_thw'].to(device)

        # Get input embeddings
        inputs_embeds = self._vlm_model.get_input_embeddings()(input_ids_batch)

        # Process images (vision encoder with no_grad)
        with torch.no_grad():
            image_embeds, deepstack_image_embeds = self._vlm_model.get_image_features(
                pixel_values_batch, image_grid_thw_batch
            )

        image_embeds = torch.cat(image_embeds, dim=0).to(device, dtype)

        # Insert image embeddings
        image_mask, _ = self._vlm_model.model.get_placeholder_mask(
            input_ids_batch, inputs_embeds=inputs_embeds, image_features=image_embeds
        )
        inputs_embeds = inputs_embeds.masked_scatter(image_mask, image_embeds)
        visual_pos_masks = image_mask[..., 0]

        # Compute position_ids
        position_ids, _rope_deltas = self._vlm_model.model.get_rope_index(
            input_ids=input_ids_batch,
            image_grid_thw=image_grid_thw_batch,
            video_grid_thw=None,
            attention_mask=attention_mask_batch,
        )

        return inputs_embeds, attention_mask_batch, visual_pos_masks, deepstack_image_embeds, position_ids

    def extract_per_layer_features(
        self,
        vlm_inputs,
    ) -> List[torch.Tensor]:
        """Extract Qwen3-VL hidden states from ALL layers for per-layer MoT.

        VLM has 28 layers, but WAN has 30 layers.
        We map: VLM Layer 26 -> WAN Layer 28, VLM Layer 27 -> WAN Layer 29

        Args:
            vlm_inputs: VLM inputs (list of dicts or dict of tensors)

        Returns:
            List of hidden states, 30 layers total: [layer_0, ..., layer_27, layer_26, layer_27]
            Each tensor: [B, seq_len, vlm_dim]
        """
        if self._vlm_model is None:
            raise ValueError("VLM model not set. Call set_vlm_model() first.")

        if isinstance(vlm_inputs, list):
            B = len(vlm_inputs)
        else:
            B = vlm_inputs['input_ids'].shape[0]

        # Process VLM inputs to tokens
        inputs_embeds, attention_mask, visual_pos_masks, deepstack_image_embeds, position_ids = \
            self._process_vlm_inputs_to_tokens(vlm_inputs, B)

        # Set up VLM forward kwargs
        vlm_kwargs = {
            'inputs_embeds': inputs_embeds,
            'attention_mask': attention_mask,
            'position_ids': position_ids,
            'past_key_values': None,
            'use_cache': False,
            'output_attentions': False,
            'output_hidden_states': True,
            'return_dict': True,
        }

        # Add DeepStack parameters for Qwen3-VL
        if visual_pos_masks is not None:
            vlm_kwargs['visual_pos_masks'] = visual_pos_masks
        if deepstack_image_embeds is not None:
            vlm_kwargs['deepstack_visual_embeds'] = deepstack_image_embeds

        # Forward through VLM (respecting freeze_vlm for gradient)
        if self.freeze_vlm:
            with torch.no_grad():
                vlm_output = self._vlm_model.model.language_model(**vlm_kwargs)
        else:
            vlm_output = self._vlm_model.model.language_model(**vlm_kwargs)

        # hidden_states is a tuple: (embeddings, layer_0, ..., layer_27)
        hidden_states = vlm_output.hidden_states

        # Return only layer outputs (skip embeddings at index 0)
        result = list(hidden_states[1:])  # 28 layers: [0, ..., 27]

        # Map 28 VLM layers to 30 WAN layers
        result.append(result[-2].clone())  # VLM Layer 26 -> WAN Layer 28
        result.append(result[-1].clone())  # VLM Layer 27 -> WAN Layer 29

        assert len(result) == 30, f"Expected 30 layers, got {len(result)}"

        return result

    def pre_dit(
        self,
        vlm_inputs,
        timestep: torch.Tensor,
    ) -> Dict[str, Any]:
        """Prepare VLM tokens for MoT forward pass.

        This method:
        1. Extracts per-layer VLM hidden states
        2. Projects the initial layer hidden states to VLM tokens
        3. Computes time embedding and modulation
        4. Returns the same dict format as ActionDiT.pre_dit()

        Args:
            vlm_inputs: VLM inputs (list of dicts or dict of tensors)
            timestep: Diffusion timestep [B]

        Returns:
            Dict with keys: tokens, freqs, t, t_mod, context, context_mask, meta,
            plus 'vlm_layer_features' for per-layer feature access in MoT forward.
        """
        # Extract per-layer VLM features (28 -> 30 layers)
        vlm_layer_features = self.extract_per_layer_features(vlm_inputs)

        # Use layer 0 features as initial tokens (before MoT mixing)
        tokens = vlm_layer_features[0]  # [B, S, vlm_dim]
        seq_len = tokens.shape[1]
        batch_size = tokens.shape[0]

        # Time embedding (same structure as ActionDiT)
        t = self.time_embedding(sinusoidal_embedding_1d(self.freq_dim, timestep))
        t_mod = self.time_projection(t).unflatten(1, (6, self.vlm_dim))

        # RoPE frequencies
        if seq_len > self.freqs.shape[0]:
            raise ValueError(
                f"VLM token length {seq_len} exceeds RoPE cache {self.freqs.shape[0]}."
            )
        freqs = self.freqs[:seq_len].view(seq_len, 1, -1).to(tokens.device)

        # VLM has no cross-attention context in MoT (it uses its own internal cross-attention)
        # But we provide a dummy context for API compatibility
        dummy_context = torch.zeros(
            (batch_size, 1, self.vlm_dim),
            dtype=tokens.dtype,
            device=tokens.device,
        )
        dummy_context_mask = torch.ones(
            (batch_size, seq_len, 1),
            dtype=torch.bool,
            device=tokens.device,
        )

        return {
            "tokens": tokens,
            "freqs": freqs,
            "t": t,
            "t_mod": t_mod,
            "context": dummy_context,
            "context_mask": dummy_context_mask,
            "meta": {
                "batch_size": batch_size,
                "seq_len": seq_len,
            },
            "vlm_layer_features": vlm_layer_features,
        }

    def post_dit(
        self,
        tokens: torch.Tensor,
        pre_state: Dict[str, Any],
    ) -> torch.Tensor:
        """Process VLM tokens after MoT attention.

        For VLM, we don't need a head projection. The tokens are used
        for their representation value in the MoT framework. We apply
        the residual + output projection from the last VLMBlock.

        Args:
            tokens: VLM tokens after MoT forward [B, S, vlm_dim]
            pre_state: Dict from pre_dit()

        Returns:
            Processed tokens [B, S, vlm_dim]
        """
        # Apply the output projection from the last VLMBlock
        last_block = self.blocks[-1]
        out = last_block.wan_vlm_o(tokens)
        return out

    def build_vlm_attention_io(
        self,
        block: VLMBlock,
        x: torch.Tensor,
        freqs: torch.Tensor,
        t_mod: torch.Tensor,
    ) -> Tuple[torch.Tensor, ...]:
        """Build VLM attention tensors for a single layer.

        This mirrors MoT._build_expert_attention_io() but uses VLMBlock's
        custom QKV projection instead of DiTBlock's self_attn.

        Args:
            block: VLMBlock for this layer
            x: VLM hidden states [B, S, vlm_dim]
            freqs: RoPE frequencies [S, 1, rope_dim]
            t_mod: Time modulation tensor

        Returns:
            Tuple of (q, k, v, residual_x, gate_msa, shift_mlp, scale_mlp, gate_mlp,
                      use_gradient_checkpointing)
        """
        # Split modulation (same as MoT._split_modulation)
        has_seq = len(t_mod.shape) == 4
        chunk_dim = 2 if has_seq else 1

        base_mod = block.modulation.to(dtype=t_mod.dtype, device=t_mod.device)
        shift_msa, scale_msa, gate_msa, shift_mlp, scale_mlp, gate_mlp = (
            base_mod + t_mod
        ).chunk(6, dim=chunk_dim)
        if has_seq:
            shift_msa, scale_msa, gate_msa, shift_mlp, scale_mlp, gate_mlp = (
                shift_msa.squeeze(2),
                scale_msa.squeeze(2),
                gate_msa.squeeze(2),
                shift_mlp.squeeze(2),
                scale_mlp.squeeze(2),
                gate_mlp.squeeze(2),
            )

        attn_input = modulate(block.norm1(x), shift_msa, scale_msa)

        # QKV projection using VLMBlock's custom parameter
        # wan_vlm_qkv shape: (3, num_heads, vlm_dim, attn_head_dim)
        qkv_weight = block.wan_vlm_qkv
        q = self._project_qkv(attn_input, qkv_weight[0])  # [B, S, num_heads * attn_head_dim]
        k = self._project_qkv(attn_input, qkv_weight[1])  # [B, S, num_heads * attn_head_dim]
        v = self._project_qkv(attn_input, qkv_weight[2])  # [B, S, num_heads * attn_head_dim]

        # Q/K normalization
        q = block.wan_vlm_norm_q(q)
        k = block.wan_vlm_norm_k(k)

        # Apply RoPE
        from .wan_video_dit import rope_apply
        q = rope_apply(q, freqs, self.num_heads)
        k = rope_apply(k, freqs, self.num_heads)

        use_gradient_checkpointing = self.use_gradient_checkpointing

        return (
            q, k, v,
            x,  # residual_x
            gate_msa, shift_mlp, scale_mlp, gate_mlp,
            use_gradient_checkpointing,
        )

    @staticmethod
    def _project_qkv(x: torch.Tensor, weight: torch.Tensor) -> torch.Tensor:
        """Project input using QKV weight parameter.

        Args:
            x: Input tensor [B, S, vlm_dim]
            weight: Weight tensor [num_heads, vlm_dim, attn_head_dim]

        Returns:
            Projected tensor [B, S, num_heads * attn_head_dim]
        """
        # weight: [num_heads, vlm_dim, attn_head_dim]
        # Reshape to [vlm_dim, num_heads * attn_head_dim]
        w = weight.permute(1, 0, 2).reshape(x.shape[-1], -1)
        return torch.nn.functional.linear(x, w.T)

    def apply_vlm_post_block(
        self,
        block: VLMBlock,
        residual_x: torch.Tensor,
        mixed_attn_out: torch.Tensor,
        gate_msa: torch.Tensor,
        shift_mlp: torch.Tensor,
        scale_mlp: torch.Tensor,
        gate_mlp: torch.Tensor,
        vlm_layer_feature: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """Apply post-attention computation for VLM block.

        For VLM, the post-block is different from DiTBlock:
        - Apply output projection + residual (like DiTBlock's self_attn.o + gate)
        - NO cross-attention (VLM has its own internal cross-attn)
        - NO FFN (VLM uses its own internal FFN from extract_per_layer_features)
        - Instead, add the VLM's internal layer feature as a residual

        Args:
            block: VLMBlock for this layer
            residual_x: Residual input tokens before attention [B, S, vlm_dim]
            mixed_attn_out: Mixed-attention output [B, S, unified_dim]
            gate_msa: Gating tensor for self-attention residual
            shift_mlp: Shift for MLP modulation (unused for VLM)
            scale_mlp: Scale for MLP modulation (unused for VLM)
            gate_mlp: Gating for MLP residual (unused for VLM)
            vlm_layer_feature: VLM internal layer feature for residual connection [B, S, vlm_dim]

        Returns:
            Updated VLM tokens [B, S, vlm_dim]
        """
        # Apply output projection and residual gate (same as DiTBlock)
        x = residual_x + gate_msa * block.wan_vlm_o(mixed_attn_out)

        # VLM has no cross-attention and no FFN in the MoT framework.
        # The VLM's internal FFN is already captured in vlm_layer_features.
        # We add the VLM internal feature as a skip connection.
        if vlm_layer_feature is not None:
            # The vlm_layer_feature already contains the VLM's internal
            # self-attention + FFN output. We add it as a residual.
            x = x + vlm_layer_feature

        return x

"""Trimodal MoT: Extends FastWAM's MoT to support three experts (Video, Action, VLM).

This module extends the bimodal MoT (video + action) to support a third VLM expert,
enabling trimodal mixed attention where:
- Video tokens attend to other video tokens
- Action tokens attend to video (first frame) + action + VLM tokens
- VLM tokens attend to other VLM tokens only

The core attention mechanism (concat QKV -> flash_attn -> split) is preserved from FastWAM.
The VLM expert uses custom VLMBlocks with per-layer QKV projections that integrate
VLM hidden states from each layer into the mixed attention.
"""

from __future__ import annotations

from typing import Dict, List, Optional

import torch
import torch.nn as nn

from .wan_video_dit import flash_attention, modulate, rope_apply
from .vlm_expert import VLMExpert
from fastwam.utils.logging_config import get_logger

logger = get_logger(__name__)


class TrimodalMoT(nn.Module):
    """Mixture-of-Transformers with three experts: Video, Action, and VLM.

    Extends FastWAM's bimodal MoT to include a VLM expert that participates
    in the mixed attention mechanism alongside Video and Action experts.
    """

    def __init__(
        self,
        mixtures: Dict[str, nn.Module],
        mot_checkpoint_mixed_attn: bool = True,
    ):
        super().__init__()
        if not mixtures:
            raise ValueError("`mixtures` cannot be empty.")
        required = {"video", "action", "vlm"}
        missing = required - set(mixtures.keys())
        if missing:
            raise ValueError(f"`mixtures` must include {required}, missing: {missing}")

        self.mixtures = nn.ModuleDict(mixtures)
        self.expert_order = list(self.mixtures.keys())
        self.mot_checkpoint_mixed_attn = mot_checkpoint_mixed_attn
        if mot_checkpoint_mixed_attn:
            logger.info(
                "Using gradient checkpointing for mixture attention. "
                "This will save memory but use more computation."
            )

        first_expert = self.mixtures[self.expert_order[0]]
        self.num_layers = len(first_expert.blocks)
        self.num_heads = first_expert.num_heads
        self.attn_head_dim = first_expert.attn_head_dim

        for name in self.expert_order[1:]:
            expert = self.mixtures[name]
            if len(expert.blocks) != self.num_layers:
                raise ValueError(
                    f"All experts must have same number of layers; "
                    f"got {self.num_layers} and {len(expert.blocks)}"
                )
            if expert.num_heads != self.num_heads:
                raise ValueError(
                    f"All experts must have same num_heads; "
                    f"got {self.num_heads} and {expert.num_heads}"
                )
            if expert.attn_head_dim != self.attn_head_dim:
                raise ValueError(
                    f"All experts must have same attn_head_dim; "
                    f"got {self.attn_head_dim} and {expert.attn_head_dim}"
                )

        logger.info(
            f"Initialized TrimodalMoT with experts: {self.expert_order}, "
            f"num_layers={self.num_layers}"
        )
        for name in self.expert_order:
            expert = self.mixtures[name]
            num_params = sum(p.numel() for p in expert.parameters()) / 1e9
            logger.info(f"  Expert '{name}': num_params={num_params:.2f} B")

    @staticmethod
    def _split_modulation(block, t_mod: torch.Tensor):
        """Split modulation parameters, same as MoT._split_modulation."""
        has_seq = len(t_mod.shape) == 4
        chunk_dim = 2 if has_seq else 1

        base_mod = block.modulation.to(dtype=t_mod.dtype, device=t_mod.device)
        shift_msa, scale_msa, gate_msa, shift_mlp, scale_mlp, gate_mlp = (
            base_mod + t_mod
        ).chunk(6, dim=chunk_dim)
        if has_seq:
            shift_msa, scale_msa, gate_msa, shift_mlp, scale_mlp, gate_mlp = (
                shift_msa.squeeze(2),
                scale_msa.squeeze(2),
                gate_msa.squeeze(2),
                shift_mlp.squeeze(2),
                scale_mlp.squeeze(2),
                gate_mlp.squeeze(2),
            )
        return shift_msa, scale_msa, gate_msa, shift_mlp, scale_mlp, gate_mlp

    def _mixed_attention(
        self,
        q_cat: torch.Tensor,
        k_cat: torch.Tensor,
        v_cat: torch.Tensor,
        attention_mask: torch.Tensor,
    ) -> torch.Tensor:
        """Run mixed attention with optional gradient checkpointing."""
        attn_mask = attention_mask.to(device=q_cat.device)
        if attn_mask.ndim == 3:
            attn_mask = attn_mask.unsqueeze(1)

        def _forward(q, k, v):
            return flash_attention(q=q, k=k, v=v, num_heads=self.num_heads, ctx_mask=attn_mask)

        if self.mot_checkpoint_mixed_attn and self.training:
            return torch.utils.checkpoint.checkpoint(
                _forward, q_cat, k_cat, v_cat, use_reentrant=False,
            )
        return _forward(q_cat, k_cat, v_cat)

    @staticmethod
    def _apply_expert_post_block(
        block,
        residual_x: torch.Tensor,
        mixed_attn_out: torch.Tensor,
        gate_msa: torch.Tensor,
        shift_mlp: torch.Tensor,
        scale_mlp: torch.Tensor,
        gate_mlp: torch.Tensor,
        context_payload: Optional[dict],
    ) -> torch.Tensor:
        """Apply post-attention computations for DiTBlock (video/action experts).

        Same as FastWAM MoT._apply_expert_post_block.
        """
        x = block.gate(residual_x, gate_msa, block.self_attn.o(mixed_attn_out))

        if context_payload is not None:
            context = context_payload.get("context")
            if context is not None:
                context_mask = context_payload.get("mask")
                if context_mask is not None and context_mask.dim() == 3:
                    context_mask = context_mask.unsqueeze(1)
                x = x + block.cross_attn(block.norm3(x), context, ctx_mask=context_mask)

        mlp_input = modulate(block.norm2(x), shift_mlp, scale_mlp)
        x = block.gate(x, gate_mlp, block.ffn(mlp_input))
        return x

    def _build_expert_attention_io(
        self,
        expert,
        block,
        x: torch.Tensor,
        freqs: torch.Tensor,
        t_mod: torch.Tensor,
    ) -> tuple:
        """Build per-expert attention tensors and post-block states.

        For VLM expert, uses VLMExpert.build_vlm_attention_io().
        For video/action experts, uses the standard DiTBlock approach.
        """
        from .vlm_expert import VLMExpert, VLMBlock

        if isinstance(expert, VLMExpert) and isinstance(block, VLMBlock):
            return expert.build_vlm_attention_io(
                block=block, x=x, freqs=freqs, t_mod=t_mod,
            )

        # Standard DiTBlock (video/action)
        shift_msa, scale_msa, gate_msa, shift_mlp, scale_mlp, gate_mlp = self._split_modulation(block, t_mod)
        attn_input = modulate(block.norm1(x), shift_msa, scale_msa)

        q = block.self_attn.norm_q(block.self_attn.q(attn_input))
        k = block.self_attn.norm_k(block.self_attn.k(attn_input))
        v = block.self_attn.v(attn_input)

        q = rope_apply(q, freqs, block.num_heads)
        k = rope_apply(k, freqs, block.num_heads)

        use_gradient_checkpointing = bool(getattr(expert, "use_gradient_checkpointing", False))
        return (
            q, k, v,
            x,  # residual_x
            gate_msa, shift_mlp, scale_mlp, gate_mlp,
            use_gradient_checkpointing,
        )

    def _apply_post_with_optional_checkpoint(
        self,
        expert,
        block,
        residual_x: torch.Tensor,
        gate_msa: torch.Tensor,
        shift_mlp: torch.Tensor,
        scale_mlp: torch.Tensor,
        gate_mlp: torch.Tensor,
        use_gradient_checkpointing: bool,
        mixed_slice: torch.Tensor,
        context_payload: Optional[dict],
        vlm_layer_feature: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """Apply post-attention computations, with optional checkpointing.

        For VLM expert, uses VLMExpert.apply_vlm_post_block().
        For video/action experts, uses the standard DiTBlock approach.
        """
        from .vlm_expert import VLMExpert, VLMBlock

        if isinstance(expert, VLMExpert) and isinstance(block, VLMBlock):
            def _vlm_post_fn(
                _mixed_slice, _x, _gate_msa, _shift_mlp, _scale_mlp, _gate_mlp,
                _block=block, _feature=vlm_layer_feature,
            ):
                return expert.apply_vlm_post_block(
                    block=_block,
                    residual_x=_x,
                    mixed_attn_out=_mixed_slice,
                    gate_msa=_gate_msa,
                    shift_mlp=_shift_mlp,
                    scale_mlp=_scale_mlp,
                    gate_mlp=_gate_mlp,
                    vlm_layer_feature=_feature,
                )

            if use_gradient_checkpointing and self.training:
                return torch.utils.checkpoint.checkpoint(
                    _vlm_post_fn,
                    mixed_slice, residual_x, gate_msa, shift_mlp, scale_mlp, gate_mlp,
                    use_reentrant=False,
                )
            return _vlm_post_fn(
                mixed_slice, residual_x, gate_msa, shift_mlp, scale_mlp, gate_mlp,
            )

        # Standard DiTBlock (video/action)
        def _post_fn(
            _mixed_slice, _x, _gate_msa, _shift_mlp, _scale_mlp, _gate_mlp,
            _block=block, _context_payload=context_payload,
        ):
            return self._apply_expert_post_block(
                block=_block,
                residual_x=_x,
                mixed_attn_out=_mixed_slice,
                gate_msa=_gate_msa,
                shift_mlp=_shift_mlp,
                scale_mlp=_scale_mlp,
                gate_mlp=_gate_mlp,
                context_payload=_context_payload,
            )

        if use_gradient_checkpointing and self.training:
            return torch.utils.checkpoint.checkpoint(
                _post_fn,
                mixed_slice, residual_x, gate_msa, shift_mlp, scale_mlp, gate_mlp,
                use_reentrant=False,
            )
        return _post_fn(
            mixed_slice, residual_x, gate_msa, shift_mlp, scale_mlp, gate_mlp,
        )

    def forward(
        self,
        embeds_all: Dict[str, torch.Tensor],
        attention_mask: torch.Tensor,
        freqs_all: Dict[str, torch.Tensor],
        context_all: Dict[str, Optional[dict]],
        t_mod_all: Dict[str, torch.Tensor],
        vlm_layer_features: Optional[List[torch.Tensor]] = None,
    ):
        """Trimodal MoT forward: three-way QKV concat -> mixed attention -> split.

        Args:
            embeds_all: Dict mapping expert name to initial tokens.
            attention_mask: Trimodal attention mask [Sv+Sa+Svlm, Sv+Sa+Svlm].
            freqs_all: Dict mapping expert name to RoPE frequencies.
            context_all: Dict mapping expert name to cross-attention context payload.
            t_mod_all: Dict mapping expert name to time modulation.
            vlm_layer_features: Optional list of 30 VLM per-layer hidden states
                for VLM residual connections. If None, no VLM layer features are used.

        Returns:
            Dict mapping expert name to updated tokens.
        """
        missing = [k for k in self.expert_order if k not in embeds_all]
        if missing:
            raise ValueError(f"Missing expert tokens for {missing}")
        missing = [k for k in self.expert_order if k not in freqs_all]
        if missing:
            raise ValueError(f"Missing expert freqs for {missing}")
        missing = [k for k in self.expert_order if k not in t_mod_all]
        if missing:
            raise ValueError(f"Missing expert t_mod for {missing}")

        if attention_mask.ndim not in (2, 3):
            raise ValueError(
                f"`attention_mask` must be 2D [S,S] or 3D [B,S,S], got shape {tuple(attention_mask.shape)}"
            )
        if attention_mask.shape[-1] != attention_mask.shape[-2]:
            raise ValueError(
                f"`attention_mask` must be square, got shape {tuple(attention_mask.shape)}"
            )

        tokens_all = {k: v for k, v in embeds_all.items()}

        for layer_idx in range(self.num_layers):
            q_chunks = []
            k_chunks = []
            v_chunks = []
            cached = {}
            seq_lens = []

            for name in self.expert_order:
                expert = self.mixtures[name]
                block = expert.blocks[layer_idx]
                x = tokens_all[name]
                freqs = freqs_all[name]
                t_mod = t_mod_all[name]

                (
                    q, k, v,
                    residual_x,
                    gate_msa, shift_mlp, scale_mlp, gate_mlp,
                    use_gradient_checkpointing,
                ) = self._build_expert_attention_io(
                    expert=expert,
                    block=block,
                    x=x,
                    freqs=freqs,
                    t_mod=t_mod,
                )

                q_chunks.append(q)
                k_chunks.append(k)
                v_chunks.append(v)
                seq_lens.append(x.shape[1])
                cached[name] = {
                    "block": block,
                    "residual_x": residual_x,
                    "gate_msa": gate_msa,
                    "shift_mlp": shift_mlp,
                    "scale_mlp": scale_mlp,
                    "gate_mlp": gate_mlp,
                    "use_gradient_checkpointing": use_gradient_checkpointing,
                }

            # Concat all tokens for mixed attention
            q_cat = torch.cat(q_chunks, dim=1)
            k_cat = torch.cat(k_chunks, dim=1)
            v_cat = torch.cat(v_chunks, dim=1)

            total_seq = q_cat.shape[1]
            if attention_mask.shape[-1] != total_seq:
                raise ValueError(
                    f"Attention mask seq length mismatch: "
                    f"mask={attention_mask.shape[-1]} vs tokens={total_seq}"
                )
            if attention_mask.ndim == 3 and attention_mask.shape[0] not in (1, q_cat.shape[0]):
                raise ValueError(
                    f"Attention mask batch mismatch: mask={attention_mask.shape[0]} vs tokens={q_cat.shape[0]}"
                )

            mixed = self._mixed_attention(
                q_cat=q_cat, k_cat=k_cat, v_cat=v_cat, attention_mask=attention_mask,
            )

            # Split mixed attention output and apply post-block for each expert
            start = 0
            for name, seq_len in zip(self.expert_order, seq_lens):
                end = start + seq_len
                mixed_slice = mixed[:, start:end, :]
                cached_expert = cached[name]
                block = cached_expert["block"]
                context_payload = context_all.get(name)

                # Get VLM layer feature for this layer (if VLM expert)
                vlm_feat = None
                if name == "vlm" and vlm_layer_features is not None:
                    vlm_feat = vlm_layer_features[layer_idx]

                updated_tokens = self._apply_post_with_optional_checkpoint(
                    expert=self.mixtures[name],
                    block=block,
                    residual_x=cached_expert["residual_x"],
                    gate_msa=cached_expert["gate_msa"],
                    shift_mlp=cached_expert["shift_mlp"],
                    scale_mlp=cached_expert["scale_mlp"],
                    gate_mlp=cached_expert["gate_mlp"],
                    use_gradient_checkpointing=cached_expert["use_gradient_checkpointing"],
                    mixed_slice=mixed_slice,
                    context_payload=context_payload,
                    vlm_layer_feature=vlm_feat,
                )

                tokens_all[name] = updated_tokens
                start = end

        return tokens_all

    def prefill_video_cache(
        self,
        video_tokens: torch.Tensor,
        video_freqs: torch.Tensor,
        video_t_mod: torch.Tensor,
        video_context_payload: Optional[dict],
        video_attention_mask: torch.Tensor,
        vlm_tokens: Optional[torch.Tensor] = None,
        vlm_freqs: Optional[torch.Tensor] = None,
        vlm_t_mod: Optional[torch.Tensor] = None,
        vlm_context_payload: Optional[dict] = None,
        vlm_kv_cache: Optional[list] = None,
    ) -> list[dict[str, torch.Tensor]]:
        """Prefill video (and optionally VLM) branch and cache per-layer K/V.

        During inference, video tokens are constant across denoising steps.
        VLM tokens are also constant. This method precomputes and caches
        their K/V tensors for each layer.

        Args:
            video_tokens: Video tokens before layer 0 [B, Sv, D].
            video_freqs: Video RoPE frequencies.
            video_t_mod: Video time modulation.
            video_context_payload: Video cross-attention context.
            video_attention_mask: Video self-attention mask [Sv, Sv].
            vlm_tokens: Optional VLM tokens for trimodal inference [B, Svlm, D].
            vlm_freqs: VLM RoPE frequencies.
            vlm_t_mod: VLM time modulation.
            vlm_context_payload: VLM cross-attention context.
            vlm_kv_cache: Optional pre-computed VLM KV cache. If provided,
                VLM K/V are not recomputed.

        Returns:
            Layer-wise cache list with length `num_layers`.
            Each entry contains:
                - `k_video`: video key tensor [B, Sv, H*Dh]
                - `v_video`: video value tensor [B, Sv, H*Dh]
                - `k_vlm` (optional): VLM key tensor [B, Svlm, H*Dh]
                - `v_vlm` (optional): VLM value tensor [B, Svlm, H*Dh]
        """
        from .vlm_expert import VLMExpert, VLMBlock

        if "video" not in self.mixtures:
            raise ValueError("TrimodalMoT requires `video` expert for `prefill_video_cache`.")
        if video_attention_mask.ndim != 2:
            raise ValueError(
                f"`video_attention_mask` must be 2D [S,S], got shape {tuple(video_attention_mask.shape)}"
            )
        if video_attention_mask.shape[0] != video_attention_mask.shape[1]:
            raise ValueError(
                f"`video_attention_mask` must be square, got shape {tuple(video_attention_mask.shape)}"
            )
        if video_attention_mask.shape[0] != video_tokens.shape[1]:
            raise ValueError(
                f"`video_attention_mask` seq length mismatch: "
                f"mask={video_attention_mask.shape[0]} vs tokens={video_tokens.shape[1]}"
            )

        has_vlm = vlm_tokens is not None
        vlm_expert = self.mixtures["vlm"] if "vlm" in self.mixtures else None

        expert = self.mixtures["video"]
        x = video_tokens
        x_vlm = vlm_tokens

        kv_cache: list[dict[str, torch.Tensor]] = []
        for layer_idx in range(self.num_layers):
            # --- Video expert ---
            block = expert.blocks[layer_idx]
            (
                q, k, v,
                residual_x, gate_msa, shift_mlp, scale_mlp, gate_mlp,
                use_gradient_checkpointing,
            ) = self._build_expert_attention_io(
                expert=expert, block=block, x=x, freqs=video_freqs, t_mod=video_t_mod,
            )

            # --- VLM expert (if present) ---
            k_vlm, v_vlm = None, None
            if has_vlm and vlm_kv_cache is None:
                vlm_block = vlm_expert.blocks[layer_idx]
                (
                    q_vlm, k_vlm_raw, v_vlm_raw,
                    residual_x_vlm, gate_msa_vlm, shift_mlp_vlm,
                    scale_mlp_vlm, gate_mlp_vlm,
                    use_gc_vlm,
                ) = self._build_expert_attention_io(
                    expert=vlm_expert, block=vlm_block, x=x_vlm,
                    freqs=vlm_freqs, t_mod=vlm_t_mod,
                )
                k_vlm = k_vlm_raw
                v_vlm = v_vlm_raw

            # Build combined mask and QKV for prefill
            if has_vlm:
                # Video+VLM self-attention only (no action yet)
                vlm_seq_len = vlm_tokens.shape[1]
                video_seq_len = video_tokens.shape[1]
                # Build video+VLM mask: video sees video, VLM sees VLM only
                combined_mask = torch.zeros(
                    (video_seq_len + vlm_seq_len, video_seq_len + vlm_seq_len),
                    dtype=torch.bool, device=video_tokens.device,
                )
                combined_mask[:video_seq_len, :video_seq_len] = video_attention_mask
                combined_mask[video_seq_len:, video_seq_len:] = True  # VLM sees VLM

                q_combined = torch.cat([q, q_vlm], dim=1)
                k_combined = torch.cat([k, k_vlm], dim=1)
                v_combined = torch.cat([v, v_vlm], dim=1)

                mixed = self._mixed_attention(
                    q_cat=q_combined, k_cat=k_combined, v_cat=v_combined,
                    attention_mask=combined_mask,
                )
            else:
                mixed = self._mixed_attention(
                    q_cat=q, k_cat=k, v_cat=v,
                    attention_mask=video_attention_mask,
                )

            # Update video tokens
            video_slice = mixed[:, :video_tokens.shape[1], :]
            x = self._apply_post_with_optional_checkpoint(
                expert=expert,
                block=block,
                residual_x=residual_x,
                gate_msa=gate_msa,
                shift_mlp=shift_mlp,
                scale_mlp=scale_mlp,
                gate_mlp=gate_mlp,
                use_gradient_checkpointing=use_gradient_checkpointing,
                mixed_slice=video_slice,
                context_payload=video_context_payload,
            )

            # Update VLM tokens
            if has_vlm and vlm_kv_cache is None:
                vlm_slice = mixed[:, video_tokens.shape[1]:, :]
                x_vlm = self._apply_post_with_optional_checkpoint(
                    expert=vlm_expert,
                    block=vlm_block,
                    residual_x=residual_x_vlm,
                    gate_msa=gate_msa_vlm,
                    shift_mlp=shift_mlp_vlm,
                    scale_mlp=scale_mlp_vlm,
                    gate_mlp=gate_mlp_vlm,
                    use_gradient_checkpointing=use_gc_vlm,
                    mixed_slice=vlm_slice,
                    context_payload=vlm_context_payload,
                )

            cache_entry = {"k_video": k, "v_video": v}
            if has_vlm:
                if vlm_kv_cache is not None:
                    cache_entry["k_vlm"] = vlm_kv_cache[layer_idx]["k_vlm"]
                    cache_entry["v_vlm"] = vlm_kv_cache[layer_idx]["v_vlm"]
                else:
                    cache_entry["k_vlm"] = k_vlm
                    cache_entry["v_vlm"] = v_vlm
            kv_cache.append(cache_entry)

        return kv_cache

    def forward_action_with_video_cache(
        self,
        action_tokens: torch.Tensor,
        action_freqs: torch.Tensor,
        action_t_mod: torch.Tensor,
        action_context_payload: Optional[dict],
        video_kv_cache: list[dict[str, torch.Tensor]],
        attention_mask: torch.Tensor,
        video_seq_len: int,
        vlm_seq_len: int = 0,
    ) -> torch.Tensor:
        """Run action branch with cached video/VLM K/V for inference.

        Args:
            action_tokens: Action tokens before layer 0 [B, Sa, D].
            action_freqs: Action RoPE frequencies.
            action_t_mod: Action time modulation.
            action_context_payload: Action cross-attention context.
            video_kv_cache: Cached K/V from prefill_video_cache.
            attention_mask: Trimodal attention mask for action query rows
                [Sa, Sv+Svlm+Sa].
            video_seq_len: Video token count.
            vlm_seq_len: VLM token count (0 if no VLM in cache).

        Returns:
            Updated action tokens after all layers [B, Sa, D].
        """
        if "action" not in self.mixtures:
            raise ValueError("TrimodalMoT requires `action` expert.")
        if len(video_kv_cache) != self.num_layers:
            raise ValueError(
                f"`video_kv_cache` must contain {self.num_layers} layers, got {len(video_kv_cache)}."
            )

        has_vlm = vlm_seq_len > 0
        action_seq_len = int(action_tokens.shape[1])
        # Layout: [Video | Action | VLM] — must match expert_order and _build_trimodal_attention_mask
        total_seq_len = int(video_seq_len) + action_seq_len + int(vlm_seq_len)

        # Build the action query rows from the full trimodal mask
        if attention_mask.ndim != 2:
            raise ValueError(f"`attention_mask` must be 2D, got ndim={attention_mask.ndim}")
        # The mask is [Sv+Sa+Svlm, Sv+Sa+Svlm] with layout [Video|Action|VLM]
        # Action rows are at [Sv : Sv+Sa, :]
        if attention_mask.shape[0] == total_seq_len:
            action_attention_mask = attention_mask[video_seq_len:video_seq_len + action_seq_len, :]
        elif attention_mask.shape[0] == action_seq_len:
            action_attention_mask = attention_mask
        else:
            raise ValueError(
                f"`attention_mask` shape mismatch: got {attention_mask.shape}, "
                f"expected [{total_seq_len}, {total_seq_len}] or [{action_seq_len}, {total_seq_len}]"
            )

        expert = self.mixtures["action"]
        x = action_tokens

        for layer_idx in range(self.num_layers):
            block = expert.blocks[layer_idx]
            (
                q_action, k_action, v_action,
                residual_x, gate_msa, shift_mlp, scale_mlp, gate_mlp,
                use_gradient_checkpointing,
            ) = self._build_expert_attention_io(
                expert=expert, block=block, x=x,
                freqs=action_freqs, t_mod=action_t_mod,
            )

            layer_cache = video_kv_cache[layer_idx]
            k_video = layer_cache["k_video"]
            v_video = layer_cache["v_video"]

            # Concatenate cached K/V with current action K/V
            # Layout: [Video | Action | VLM] — must match attention mask layout
            if has_vlm:
                k_vlm = layer_cache["k_vlm"]
                v_vlm = layer_cache["v_vlm"]
                k_cat = torch.cat([k_video, k_action, k_vlm], dim=1)
                v_cat = torch.cat([v_video, v_action, v_vlm], dim=1)
            else:
                k_cat = torch.cat([k_video, k_action], dim=1)
                v_cat = torch.cat([v_video, v_action], dim=1)

            mixed = self._mixed_attention(
                q_cat=q_action, k_cat=k_cat, v_cat=v_cat,
                attention_mask=action_attention_mask,
            )

            x = self._apply_post_with_optional_checkpoint(
                expert=expert,
                block=block,
                residual_x=residual_x,
                gate_msa=gate_msa,
                shift_mlp=shift_mlp,
                scale_mlp=scale_mlp,
                gate_mlp=gate_mlp,
                use_gradient_checkpointing=use_gradient_checkpointing,
                mixed_slice=mixed,
                context_payload=action_context_payload,
            )

        return x

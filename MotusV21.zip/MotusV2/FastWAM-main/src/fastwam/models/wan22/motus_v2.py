"""MotusV2: FastWAM + VLM Expert unified model.

Combines FastWAM's video and action experts with a Qwen3-VL VLM expert
in a trimodal Mixture-of-Transformers framework. This model extends FastWAM
to leverage visual-language understanding for improved robot action prediction.

Architecture:
    Video Expert (WAN 5B) + Action Expert (ActionDiT) + VLM Expert (Qwen3-VL)
         <-> Trimodal MoT Mixed Attention <->
    Video tokens + Action tokens + VLM tokens -> concat QKV -> flash_attn -> split

Attention mask:
    Query \ Key  | Video | Action | VLM
    -------------|-------|--------|-----
    Video        |   Y   |   N    |  N
    Action       |   Y*  |   Y    |  Y
    VLM          |   N   |   N    |  Y
    * Action sees only first-frame video tokens
"""

from typing import Any, Optional, Sequence, Union

import torch
import torch.nn as nn
import torch.nn.functional as F
from PIL import Image

from fastwam.utils.logging_config import get_logger

from .action_dit import ActionDiT
from .helpers.loader import load_wan22_ti2v_5b_components
from .trimodal_mot import TrimodalMoT
from .vlm_expert import VLMExpert
from .schedulers.scheduler_continuous import WanContinuousFlowMatchScheduler

logger = get_logger(__name__)


class MotusV2(torch.nn.Module):
    """MoT world model with video/action/VLM experts."""

    def __init__(
        self,
        video_expert,
        action_expert: ActionDiT,
        vlm_expert: VLMExpert,
        mot: TrimodalMoT,
        vae,
        text_encoder=None,
        tokenizer=None,
        text_dim: Optional[int] = None,
        proprio_dim: Optional[int] = None,
        device: str = "cpu",
        torch_dtype: torch.dtype = torch.float32,
        video_train_shift: float = 5.0,
        video_infer_shift: float = 5.0,
        video_num_train_timesteps: int = 1000,
        action_train_shift: float = 5.0,
        action_infer_shift: float = 5.0,
        action_num_train_timesteps: int = 1000,
        loss_lambda_video: float = 1.0,
        loss_lambda_action: float = 1.0,
        loss_lambda_vlm: float = 0.0,
        freeze_vlm: bool = False,
        vlm_model_path: Optional[str] = None,
        motion_token_prediction: Optional[dict[str, Any]] = None,
    ):
        super().__init__()
        self.video_expert = video_expert
        self.action_expert = action_expert
        self.vlm_expert = vlm_expert
        self.mot = mot
        # Keep trainer compatibility: optimizer and freeze logic use `model.dit`.
        self.dit = self.mot

        self.vae = vae
        self.text_encoder = text_encoder
        self.tokenizer = tokenizer
        if text_dim is None:
            if self.text_encoder is None:
                raise ValueError("`text_dim` is required when `text_encoder` is not loaded.")
            text_dim = int(self.text_encoder.dim)
        self.text_dim = int(text_dim)
        self.proprio_dim = None if proprio_dim is None else int(proprio_dim)
        if self.proprio_dim is not None:
            self.proprio_encoder = nn.Linear(self.proprio_dim, self.text_dim).to(torch_dtype)
        else:
            self.proprio_encoder = None

        self.train_video_scheduler = WanContinuousFlowMatchScheduler(
            num_train_timesteps=video_num_train_timesteps,
            shift=video_train_shift,
        )
        self.infer_video_scheduler = WanContinuousFlowMatchScheduler(
            num_train_timesteps=video_num_train_timesteps,
            shift=video_infer_shift,
        )
        self.train_action_scheduler = WanContinuousFlowMatchScheduler(
            num_train_timesteps=action_num_train_timesteps,
            shift=action_train_shift,
        )
        self.infer_action_scheduler = WanContinuousFlowMatchScheduler(
            num_train_timesteps=action_num_train_timesteps,
            shift=action_infer_shift,
        )
        # Aliases for consistency
        self.train_scheduler = self.train_video_scheduler
        self.infer_scheduler = self.infer_video_scheduler

        self.device = torch.device(device)
        self.torch_dtype = torch_dtype
        self.loss_lambda_video = float(loss_lambda_video)
        self.loss_lambda_action = float(loss_lambda_action)
        self.loss_lambda_vlm = float(loss_lambda_vlm)
        self.freeze_vlm = freeze_vlm
        self.vlm_model_path = vlm_model_path
        self.motion_token_prediction = dict(motion_token_prediction or {})
        self.motion_token_enabled = bool(self.motion_token_prediction.get("enabled", False))
        self._warned_empty_motion_labels = False
        self._warned_motion_label_mismatch = False

        # VLM processor for building vlm_inputs from (image, text)
        self._vlm_processor = None
        if vlm_model_path is not None:
            try:
                from transformers import AutoProcessor
                self._vlm_processor = AutoProcessor.from_pretrained(vlm_model_path)
                logger.info(f"VLM processor loaded from: {vlm_model_path}")
            except Exception as e:
                logger.warning(f"Failed to load VLM processor from {vlm_model_path}: {e}")

        self.to(self.device)
        self._validate_motion_token_setup()

    @classmethod
    def from_wan22_pretrained(
        cls,
        device: str = "cuda",
        torch_dtype: torch.dtype = torch.bfloat16,
        model_id: str = "Wan-AI/Wan2.2-TI2V-5B",
        tokenizer_model_id: str = "Wan-AI/Wan2.1-T2V-1.3B",
        tokenizer_max_len: int = 512,
        load_text_encoder: bool = True,
        proprio_dim: Optional[int] = None,
        redirect_common_files: bool = True,
        video_dit_config: dict[str, Any] | None = None,
        action_dit_config: dict[str, Any] | None = None,
        action_dit_pretrained_path: str | None = None,
        skip_dit_load_from_pretrain: bool = False,
        mot_checkpoint_mixed_attn: bool = True,
        vlm_config: dict[str, Any] | None = None,
        vlm_model=None,
        vlm_model_path: Optional[str] = None,
        freeze_vlm: bool = False,
        video_train_shift: float = 5.0,
        video_infer_shift: float = 5.0,
        video_num_train_timesteps: int = 1000,
        action_train_shift: float = 5.0,
        action_infer_shift: float = 5.0,
        action_num_train_timesteps: int = 1000,
        loss_lambda_video: float = 1.0,
        loss_lambda_action: float = 1.0,
        loss_lambda_vlm: float = 0.0,
        motion_token_prediction: Optional[dict[str, Any]] = None,
    ):
        if video_dit_config is None:
            raise ValueError("`video_dit_config` is required for MotusV2.from_wan22_pretrained().")
        if "text_dim" not in video_dit_config:
            raise ValueError("`video_dit_config['text_dim']` is required for MotusV2.")
        if vlm_config is None:
            raise ValueError("`vlm_config` is required for MotusV2.")

        # Load WAN components (video expert, VAE, text encoder, tokenizer)
        components = load_wan22_ti2v_5b_components(
            device=device,
            torch_dtype=torch_dtype,
            model_id=model_id,
            tokenizer_model_id=tokenizer_model_id,
            tokenizer_max_len=tokenizer_max_len,
            redirect_common_files=redirect_common_files,
            dit_config=video_dit_config,
            skip_dit_load_from_pretrain=skip_dit_load_from_pretrain,
            load_text_encoder=load_text_encoder,
        )

        video_expert = components.dit

        # Action expert
        action_expert = ActionDiT.from_pretrained(
            action_dit_config=action_dit_config,
            action_dit_pretrained_path=action_dit_pretrained_path,
            skip_dit_load_from_pretrain=skip_dit_load_from_pretrain,
            device=device,
            torch_dtype=torch_dtype,
        )
        if int(action_expert.num_heads) != int(video_expert.num_heads):
            raise ValueError("ActionDiT `num_heads` must match video expert.")
        if int(action_expert.attn_head_dim) != int(video_expert.attn_head_dim):
            raise ValueError("ActionDiT `attn_head_dim` must match video expert.")
        if int(len(action_expert.blocks)) != int(len(video_expert.blocks)):
            raise ValueError("ActionDiT `num_layers` must match video expert.")

        # VLM expert
        vlm_expert = VLMExpert(
            vlm_dim=vlm_config.get("vlm_dim", 2048),
            num_heads=int(video_expert.num_heads),
            attn_head_dim=int(video_expert.attn_head_dim),
            num_layers=int(len(video_expert.blocks)),
            freq_dim=vlm_config.get("freq_dim", 256),
            eps=vlm_config.get("eps", 1e-5),
            freeze_vlm=freeze_vlm,
            use_gradient_checkpointing=vlm_config.get("use_gradient_checkpointing", False),
        ).to(device=device, dtype=torch_dtype)

        if vlm_model is not None:
            vlm_expert.set_vlm_model(vlm_model)

        # Trimodal MoT
        mot = TrimodalMoT(
            mixtures={"video": video_expert, "action": action_expert, "vlm": vlm_expert},
            mot_checkpoint_mixed_attn=mot_checkpoint_mixed_attn,
        )

        model = cls(
            video_expert=video_expert,
            action_expert=action_expert,
            vlm_expert=vlm_expert,
            mot=mot,
            vae=components.vae,
            text_encoder=components.text_encoder,
            tokenizer=components.tokenizer,
            text_dim=int(video_dit_config["text_dim"]),
            proprio_dim=proprio_dim,
            device=device,
            torch_dtype=torch_dtype,
            video_train_shift=video_train_shift,
            video_infer_shift=video_infer_shift,
            video_num_train_timesteps=video_num_train_timesteps,
            action_train_shift=action_train_shift,
            action_infer_shift=action_infer_shift,
            action_num_train_timesteps=action_num_train_timesteps,
            loss_lambda_video=loss_lambda_video,
            loss_lambda_action=loss_lambda_action,
            loss_lambda_vlm=loss_lambda_vlm,
            freeze_vlm=freeze_vlm,
            vlm_model_path=vlm_model_path,
            motion_token_prediction=motion_token_prediction,
        )
        model.model_paths = {
            "video_dit": components.dit_path,
            "vae": components.vae_path,
            "text_encoder": components.text_encoder_path,
            "tokenizer": components.tokenizer_path,
            "action_dit_backbone": (
                "SKIPPED_PRETRAIN" if skip_dit_load_from_pretrain else action_dit_pretrained_path
            ),
        }
        return model

    def to(self, *args, **kwargs):
        super().to(*args, **kwargs)
        self.mot.to(*args, **kwargs)
        if self.text_encoder is not None:
            self.text_encoder.to(*args, **kwargs)
        self.vae.to(*args, **kwargs)
        return self

    def _validate_motion_token_setup(self):
        if not self.motion_token_enabled:
            return
        if self.loss_lambda_vlm <= 0:
            logger.warning(
                "motion_token_prediction.enabled=True but loss.lambda_vlm <= 0; "
                "motion-token labels will be built but will not affect training."
            )
        if self._vlm_processor is None:
            raise ValueError(
                "motion_token_prediction.enabled=True requires `vlm_model_path` "
                "to load an extended-vocabulary Qwen3-VL processor."
            )
        if self.vlm_expert.vlm_model is None:
            raise ValueError(
                "motion_token_prediction.enabled=True requires a loaded Qwen3-VL model."
            )
        tokenizer = getattr(self._vlm_processor, "tokenizer", self._vlm_processor)
        token_id = tokenizer.convert_tokens_to_ids("<|motion_x_0000|>")
        unk_id = getattr(tokenizer, "unk_token_id", None)
        if token_id is None or token_id == unk_id:
            raise ValueError(
                "`vlm_model_path` does not appear to contain motion special tokens. "
                "Expected token `<|motion_x_0000|>` in the tokenizer vocabulary."
            )
        lm_head = getattr(self.vlm_expert.vlm_model, "lm_head", None)
        if lm_head is not None and hasattr(lm_head, "out_features"):
            vocab_size = int(lm_head.out_features)
            tokenizer_size = len(tokenizer)
            if vocab_size < tokenizer_size:
                raise ValueError(
                    "Qwen3-VL lm_head vocabulary is smaller than tokenizer vocabulary: "
                    f"lm_head={vocab_size}, tokenizer={tokenizer_size}. "
                    "Use the extended motion-token model checkpoint."
                )

    def _format_vlm_user_text(self, text: str) -> str:
        if not self.motion_token_enabled:
            return text
        return (
            f"Task: {text}\n"
            "Predict the 3D wrist motion trajectories for both hands "
            "in the robot base coordinate system. Return only motion tokens."
        )

    @staticmethod
    def _video_frame_to_pil(frame: torch.Tensor) -> Image.Image:
        frame_uint8 = ((frame.float() + 1.0) * 0.5 * 255.0).clamp(0, 255).to(torch.uint8)
        frame_np = frame_uint8.permute(1, 2, 0).cpu().numpy()
        return Image.fromarray(frame_np)

    @staticmethod
    def _normalize_prompt_batch(prompt, batch_size: int) -> list[str]:
        if isinstance(prompt, str):
            return [prompt] * batch_size
        if isinstance(prompt, (list, tuple)):
            prompts = ["" if item is None else str(item) for item in prompt]
            if len(prompts) != batch_size:
                raise ValueError(
                    f"prompt list length ({len(prompts)}) != batch_size ({batch_size})"
                )
            return prompts
        return [""] * batch_size

    @staticmethod
    def _normalize_motion_token_batch(motion_token_strings, batch_size: int) -> tuple[list[str], list[str]]:
        if motion_token_strings is None:
            raise ValueError("`motion_token_strings` is required for motion-token VLM inputs.")

        if isinstance(motion_token_strings, dict):
            left = motion_token_strings.get("left")
            right = motion_token_strings.get("right")
        elif isinstance(motion_token_strings, (list, tuple)):
            left = [item["left"] for item in motion_token_strings]
            right = [item["right"] for item in motion_token_strings]
        else:
            raise TypeError(
                f"`motion_token_strings` must be a dict or list of dicts, got {type(motion_token_strings)}"
            )

        if isinstance(left, str):
            left = [left] * batch_size
        if isinstance(right, str):
            right = [right] * batch_size
        left = list(left)
        right = list(right)
        if len(left) != batch_size or len(right) != batch_size:
            raise ValueError(
                "motion token string batch size mismatch: "
                f"left={len(left)}, right={len(right)}, batch={batch_size}"
            )
        return left, right

    @staticmethod
    def _pad_vlm_input_dicts(inputs_list: list[dict]) -> dict:
        input_ids_list = [item["input_ids"] for item in inputs_list]
        attention_mask_list = [item.get("attention_mask") for item in inputs_list]
        max_seq_len = max(ids.shape[1] for ids in input_ids_list)

        padded_input_ids = []
        padded_attention_masks = []
        padded_optional = {
            "labels": [],
            "assistant_token_mask": [],
            "assistant_loss_mask": [],
        }

        for item, ids, attention_mask in zip(inputs_list, input_ids_list, attention_mask_list):
            pad_size = max_seq_len - ids.shape[1]
            if pad_size > 0:
                ids = torch.cat(
                    [ids, torch.zeros(ids.shape[0], pad_size, dtype=ids.dtype, device=ids.device)],
                    dim=1,
                )
                if attention_mask is not None:
                    attention_mask = torch.cat(
                        [
                            attention_mask,
                            torch.zeros(
                                attention_mask.shape[0],
                                pad_size,
                                dtype=attention_mask.dtype,
                                device=attention_mask.device,
                            ),
                        ],
                        dim=1,
                    )
            padded_input_ids.append(ids)
            padded_attention_masks.append(attention_mask)

            for key, values in padded_optional.items():
                value = item.get(key)
                if value is None:
                    if key == "labels":
                        fill = torch.full((ids.shape[0], max_seq_len), -100, dtype=torch.long)
                    else:
                        fill = torch.zeros((ids.shape[0], max_seq_len), dtype=torch.bool)
                    values.append(fill)
                    continue
                if value.shape[1] < max_seq_len:
                    opt_pad = max_seq_len - value.shape[1]
                    if key == "labels":
                        padding = torch.full(
                            (value.shape[0], opt_pad),
                            -100,
                            dtype=value.dtype,
                            device=value.device,
                        )
                    else:
                        padding = torch.zeros(
                            value.shape[0],
                            opt_pad,
                            dtype=value.dtype,
                            device=value.device,
                        )
                    value = torch.cat([value, padding], dim=1)
                values.append(value)

        result = {
            "input_ids": torch.cat(padded_input_ids, dim=0),
            "attention_mask": (
                torch.cat([mask for mask in padded_attention_masks if mask is not None], dim=0)
                if any(mask is not None for mask in padded_attention_masks)
                else None
            ),
            "pixel_values": torch.cat([item["pixel_values"] for item in inputs_list], dim=0),
            "image_grid_thw": torch.cat([item["image_grid_thw"] for item in inputs_list], dim=0),
        }
        for key, values in padded_optional.items():
            if any(key in item for item in inputs_list):
                result[key] = torch.cat(values, dim=0)
        return result

    def _build_motion_labels(self, inputs: dict) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        input_ids = inputs["input_ids"]
        labels = torch.full_like(input_ids, -100)
        labels[:, :-1] = input_ids[:, 1:]

        tokenizer = getattr(self._vlm_processor, "tokenizer", self._vlm_processor)
        assistant_start_ids = tokenizer.encode(
            "<|im_start|>assistant\n", add_special_tokens=False
        )
        ids_list = input_ids[0].tolist()
        assistant_pos = None
        marker_len = len(assistant_start_ids)
        for idx in range(len(ids_list) - marker_len + 1):
            if ids_list[idx: idx + marker_len] == assistant_start_ids:
                assistant_pos = idx + marker_len
                break

        assistant_token_mask = torch.zeros_like(input_ids, dtype=torch.bool)
        assistant_loss_mask = torch.zeros_like(input_ids, dtype=torch.bool)
        if assistant_pos is None:
            labels.fill_(-100)
            logger.warning("Could not find assistant response marker in motion-token VLM input.")
            return labels, assistant_token_mask, assistant_loss_mask

        labels[:, : max(assistant_pos - 1, 0)] = -100
        attention_mask = inputs.get("attention_mask")
        valid_len = int(attention_mask[0].sum().item()) if attention_mask is not None else input_ids.shape[1]
        assistant_token_mask[:, assistant_pos:valid_len] = True
        assistant_loss_mask[:] = labels != -100
        return labels, assistant_token_mask, assistant_loss_mask

    @staticmethod
    def _check_resize_height_width(height, width, num_frames):
        if height % 16 != 0:
            height = (height + 15) // 16 * 16
        if width % 16 != 0:
            width = (width + 15) // 16 * 16
        if num_frames % 4 != 1:
            num_frames = (num_frames + 3) // 4 * 4 + 1
        return height, width, num_frames

    @torch.no_grad()
    def _build_vlm_inputs_batch(
        self,
        video: torch.Tensor,
        prompt,
    ) -> Optional[dict]:
        """Build VLM inputs from video first frame + text instruction.

        Uses Qwen3VL processor to convert (image, text) into
        {input_ids, attention_mask, pixel_values, image_grid_thw}.

        Args:
            video: Video tensor [B, 3, T, H, W], range [-1, 1].
            prompt: Text instruction, either a single string (shared by batch)
                    or a list of strings (one per sample).

        Returns:
            Dict of VLM input tensors, or None if processor unavailable.
        """
        if self._vlm_processor is None:
            return None

        from qwen_vl_utils import process_vision_info

        batch_size = video.shape[0]
        prompts = self._normalize_prompt_batch(prompt, batch_size)
        first_frames = video[:, :, 0, :, :]  # [B, 3, H, W], range [-1, 1]
        inputs_list = []
        for b in range(batch_size):
            messages = [
                {
                    "role": "user",
                    "content": [
                        {"type": "image", "image": self._video_frame_to_pil(first_frames[b])},
                        {"type": "text", "text": self._format_vlm_user_text(prompts[b])},
                    ],
                }
            ]
            text = self._vlm_processor.apply_chat_template(
                messages, tokenize=False, add_generation_prompt=True
            )
            image_inputs, video_inputs = process_vision_info(messages)
            inputs = self._vlm_processor(
                text=[text],
                images=image_inputs,
                videos=video_inputs,
                padding=True,
                return_tensors="pt",
            )
            inputs_list.append(inputs)

        return self._pad_vlm_input_dicts(inputs_list)

    @torch.no_grad()
    def _build_motion_vlm_inputs_batch(
        self,
        video: torch.Tensor,
        prompt,
        motion_token_strings,
    ) -> Optional[dict]:
        """Build full prompt+assistant VLM inputs for motion-token CE training."""
        if self._vlm_processor is None:
            return None

        from qwen_vl_utils import process_vision_info

        batch_size = video.shape[0]
        prompts = self._normalize_prompt_batch(prompt, batch_size)
        left_tokens, right_tokens = self._normalize_motion_token_batch(
            motion_token_strings, batch_size
        )
        first_frames = video[:, :, 0, :, :]

        inputs_list = []
        for b in range(batch_size):
            messages = [
                {
                    "role": "user",
                    "content": [
                        {"type": "image", "image": self._video_frame_to_pil(first_frames[b])},
                        {"type": "text", "text": self._format_vlm_user_text(prompts[b])},
                    ],
                },
                {
                    "role": "assistant",
                    "content": f"Left:{left_tokens[b]}Right:{right_tokens[b]}",
                },
            ]
            text = self._vlm_processor.apply_chat_template(
                messages, tokenize=False, add_generation_prompt=False
            )
            image_inputs, video_inputs = process_vision_info(messages)
            inputs = self._vlm_processor(
                text=[text],
                images=image_inputs,
                videos=video_inputs,
                padding=True,
                return_tensors="pt",
            )
            labels, assistant_token_mask, assistant_loss_mask = self._build_motion_labels(inputs)
            inputs["labels"] = labels
            inputs["assistant_token_mask"] = assistant_token_mask
            inputs["assistant_loss_mask"] = assistant_loss_mask
            inputs_list.append(inputs)

        return self._pad_vlm_input_dicts(inputs_list)

    @torch.no_grad()
    def encode_prompt(self, prompt: Union[str, Sequence[str]]):
        if self.text_encoder is None or self.tokenizer is None:
            raise ValueError(
                "Prompt encoding requires loaded text encoder/tokenizer. "
                "Set `load_text_encoder=true` or provide precomputed `context/context_mask`."
            )
        ids, mask = self.tokenizer(prompt, return_mask=True, add_special_tokens=True)
        ids = ids.to(self.device)
        mask = mask.to(self.device, dtype=torch.bool)
        prompt_emb = self.text_encoder(ids, mask)
        seq_lens = mask.gt(0).sum(dim=1).long()
        for i, v in enumerate(seq_lens):
            prompt_emb[i, v:] = 0
        mask = torch.ones_like(mask)
        return prompt_emb.to(device=self.device), mask

    def _append_proprio_to_context(
        self,
        context: torch.Tensor,
        context_mask: torch.Tensor,
        proprio: Optional[torch.Tensor],
    ) -> tuple[torch.Tensor, torch.Tensor]:
        if self.proprio_encoder is None or proprio is None:
            return context, context_mask
        if proprio.ndim != 2:
            raise ValueError(f"`proprio` must be 2D [B, D], got shape {tuple(proprio.shape)}")
        if self.proprio_dim is None or proprio.shape[1] != self.proprio_dim:
            raise ValueError(
                f"`proprio` last dim must be {self.proprio_dim}, got {proprio.shape[1]}"
            )
        proprio_token = self.proprio_encoder(
            proprio.to(device=self.device, dtype=context.dtype).unsqueeze(1)
        ).to(dtype=context.dtype)
        proprio_mask = torch.ones((context_mask.shape[0], 1), dtype=torch.bool, device=context_mask.device)
        return (
            torch.cat([context, proprio_token], dim=1),
            torch.cat([context_mask, proprio_mask], dim=1),
        )

    @torch.no_grad()
    def _encode_video_latents(self, video_tensor, tiled=False, tile_size=(30, 52), tile_stride=(15, 26)):
        z = self.vae.encode(
            video_tensor,
            device=self.device,
            tiled=tiled,
            tile_size=tile_size,
            tile_stride=tile_stride,
        )
        return z

    @torch.no_grad()
    def _encode_input_image_latents_tensor(self, input_image: torch.Tensor, tiled=False, tile_size=(30, 52), tile_stride=(15, 26)):
        if input_image.ndim == 3:
            input_image = input_image.unsqueeze(0)
        if input_image.ndim != 4 or input_image.shape[0] != 1 or input_image.shape[1] != 3:
            raise ValueError(
                f"`input_image` must have shape [1,3,H,W] or [3,H,W], got {tuple(input_image.shape)}"
            )
        image = input_image.to(device=self.device)[0].unsqueeze(1)
        z = self.vae.encode([image], device=self.device, tiled=tiled, tile_size=tile_size, tile_stride=tile_stride)
        if isinstance(z, list):
            z = z[0].unsqueeze(0)
        return z

    def _decode_latents(self, latents, tiled=False, tile_size=(30, 52), tile_stride=(15, 26)):
        video_tensor = self.vae.decode(latents, device=self.device, tiled=tiled, tile_size=tile_size, tile_stride=tile_stride)
        video_tensor = video_tensor.squeeze(0).detach().float().clamp(-1, 1)
        video_tensor = ((video_tensor + 1.0) * 127.5).to(torch.uint8).cpu()
        frames = []
        for t in range(video_tensor.shape[1]):
            frame = video_tensor[:, t].permute(1, 2, 0).numpy()
            frames.append(Image.fromarray(frame))
        return frames

    def build_inputs(self, sample, tiled: bool = False):
        """Build training inputs from a data sample.

        Same as FastWAM.build_inputs, plus optional VLM inputs.
        """
        video = sample["video"]
        if "context" not in sample or "context_mask" not in sample:
            raise ValueError(
                "MotusV2 training requires `sample['context']` and `sample['context_mask']`."
            )
        context = sample["context"]
        context_mask = sample["context_mask"]
        proprio = sample.get("proprio", None)
        if video.ndim != 5:
            raise ValueError(f"`sample['video']` must be 5D [B, 3, T, H, W], got shape {tuple(video.shape)}")
        if video.shape[1] != 3:
            raise ValueError(f"`sample['video']` channel dimension must be 3, got shape {tuple(video.shape)}")

        batch_size, _, num_frames, height, width = video.shape
        if height % 16 != 0 or width % 16 != 0:
            raise ValueError(
                f"Video spatial dims must be multiples of 16, got H={height}, W={width}"
            )
        if num_frames % 4 != 1:
            raise ValueError(f"Video T must satisfy T % 4 == 1, got T={num_frames}")
        if num_frames <= 1:
            raise ValueError(f"Video T must be > 1 for action-conditioned training, got T={num_frames}")

        if "action" not in sample:
            raise ValueError("`sample['action']` is required for MotusV2 training.")

        action = sample["action"]
        if action.ndim != 3:
            raise ValueError(f"`sample['action']` must be 3D [B, T, a_dim], got shape {tuple(action.shape)}")
        action_horizon = int(action.shape[1])
        if action_horizon % (num_frames - 1) != 0:
            raise ValueError(
                f"`sample['action']` temporal dimension must be divisible by video transitions ({num_frames - 1}), got {action_horizon}"
            )

        action_is_pad = sample.get("action_is_pad", None)
        if action_is_pad is not None:
            if action_is_pad.ndim != 2:
                raise ValueError(
                    f"`sample['action_is_pad']` must be 2D [B, T], got shape {tuple(action_is_pad.shape)}"
                )
            if action_is_pad.shape[0] != batch_size or action_is_pad.shape[1] != action_horizon:
                raise ValueError(
                    "`sample['action_is_pad']` shape mismatch: "
                    f"got {tuple(action_is_pad.shape)} vs expected ({batch_size}, {action_horizon})"
                )

        image_is_pad = sample.get("image_is_pad", None)
        if image_is_pad is not None:
            if image_is_pad.ndim != 2:
                raise ValueError(
                    f"`sample['image_is_pad']` must be 2D [B, T], got shape {tuple(image_is_pad.shape)}"
                )
            if image_is_pad.shape[0] != batch_size or image_is_pad.shape[1] != num_frames:
                raise ValueError(
                    "`sample['image_is_pad']` shape mismatch: "
                    f"got {tuple(image_is_pad.shape)} vs expected ({batch_size}, {num_frames})"
                )

        input_video = video.to(device=self.device, dtype=self.torch_dtype, non_blocking=True)
        input_latents = self._encode_video_latents(input_video, tiled=tiled)

        first_frame_latents = None
        fuse_flag = False
        if getattr(self.video_expert, "fuse_vae_embedding_in_latents", False):
            first_frame_latents = input_latents[:, :, 0:1]
            fuse_flag = True

        if context.ndim != 3 or context_mask.ndim != 2:
            raise ValueError(
                f"`context/context_mask` must be [B,L,D]/[B,L], got {tuple(context.shape)} and {tuple(context_mask.shape)}"
            )
        context = context.to(device=self.device, dtype=self.torch_dtype, non_blocking=True)
        context_mask = context_mask.to(device=self.device, dtype=torch.bool, non_blocking=True)
        if self.proprio_encoder is not None:
            if proprio is None:
                raise ValueError("`sample['proprio']` is required when `proprio_dim` is enabled.")
            if proprio.ndim != 3:
                raise ValueError(f"`sample['proprio']` must be 3D [B, T, d], got shape {tuple(proprio.shape)}")
            if proprio.shape[2] != self.proprio_dim:
                raise ValueError(
                    f"`sample['proprio']` last dim must be {self.proprio_dim}, got {proprio.shape[2]}"
                )
            proprio = proprio[:, 0, :]
            context, context_mask = self._append_proprio_to_context(
                context=context,
                context_mask=context_mask,
                proprio=proprio.to(device=self.device, dtype=self.torch_dtype),
            )
        action = action.to(device=self.device, dtype=self.torch_dtype, non_blocking=True)

        if action_is_pad is not None:
            action_is_pad = action_is_pad.to(device=self.device, dtype=torch.bool, non_blocking=True)
        if image_is_pad is not None:
            image_is_pad = image_is_pad.to(device=self.device, dtype=torch.bool, non_blocking=True)

        # VLM inputs: build from first frame image + raw task instruction.
        # Motion-token mode uses a full prompt+assistant sequence for CE loss;
        # the trimodal mask blocks Action from attending to assistant GT tokens.
        vlm_inputs = sample.get("vlm_inputs", None)
        motion_token_labels = None
        if vlm_inputs is None and self._vlm_processor is not None:
            vlm_task = sample.get("task", sample.get("prompt", None))
            motion_token_strings = sample.get("motion_token_strings")
            if self.motion_token_enabled and motion_token_strings is not None:
                vlm_inputs = self._build_motion_vlm_inputs_batch(
                    video=video,
                    prompt=vlm_task,
                    motion_token_strings=motion_token_strings,
                )
                if vlm_inputs is not None:
                    motion_token_labels = vlm_inputs.pop("labels", None)
            else:
                vlm_inputs = self._build_vlm_inputs_batch(
                    video=video, prompt=vlm_task,
                )
        elif isinstance(vlm_inputs, dict):
            motion_token_labels = vlm_inputs.pop("labels", None)

        if motion_token_labels is None and "motion_token_labels" in sample:
            motion_token_labels = sample["motion_token_labels"]

        return {
            "context": context,
            "context_mask": context_mask,
            "input_latents": input_latents,
            "first_frame_latents": first_frame_latents,
            "fuse_vae_embedding_in_latents": fuse_flag,
            "action": action,
            "action_is_pad": action_is_pad,
            "image_is_pad": image_is_pad,
            "vlm_inputs": vlm_inputs,
            "motion_token_labels": motion_token_labels,
        }

    @torch.no_grad()
    def _build_trimodal_attention_mask(
        self,
        video_seq_len: int,
        action_seq_len: int,
        vlm_seq_len: int,
        video_tokens_per_frame: int,
        device: torch.device,
        vlm_attention_mask: Optional[torch.Tensor] = None,
        vlm_assistant_mask: Optional[torch.Tensor] = None,
        causal_vlm: bool = False,
    ) -> torch.Tensor:
        """Build trimodal attention mask.

        Layout: [Video | Action | VLM]  (matches expert_order in MoT forward)

        Attention Matrix:
        Query \ Key  | Video | Action | VLM
        -------------|-------|--------|-----
        Video        |   Y   |   N    |  N
        Action       |   Y*  |   Y    |  Y
        VLM          |   N   |   N    |  Y
        * Action sees only first-frame video tokens
        """
        total_seq_len = video_seq_len + action_seq_len + vlm_seq_len
        mask = torch.zeros((total_seq_len, total_seq_len), dtype=torch.bool, device=device)

        v_end = video_seq_len
        a_end = v_end + action_seq_len

        # video -> video (use video expert's mask)
        mask[:v_end, :v_end] = self.video_expert.build_video_to_video_mask(
            video_seq_len=video_seq_len,
            video_tokens_per_frame=video_tokens_per_frame,
            device=device,
        )

        # action -> action
        mask[v_end:a_end, v_end:a_end] = True

        # action -> first-frame video only
        first_frame_tokens = min(video_tokens_per_frame, video_seq_len)
        mask[v_end:a_end, :first_frame_tokens] = True

        # action -> VLM
        mask[v_end:a_end, a_end:] = True

        # VLM -> VLM
        mask[a_end:, a_end:] = True

        if vlm_attention_mask is None and vlm_assistant_mask is None and not causal_vlm:
            return mask

        if vlm_attention_mask is not None:
            vlm_valid = vlm_attention_mask[:, :vlm_seq_len].to(device=device, dtype=torch.bool)
            batch_size = vlm_valid.shape[0]
        elif vlm_assistant_mask is not None:
            batch_size = vlm_assistant_mask.shape[0]
            vlm_valid = torch.ones((batch_size, vlm_seq_len), dtype=torch.bool, device=device)
        else:
            batch_size = 1
            vlm_valid = torch.ones((batch_size, vlm_seq_len), dtype=torch.bool, device=device)

        if vlm_assistant_mask is not None:
            vlm_assistant = vlm_assistant_mask[:, :vlm_seq_len].to(device=device, dtype=torch.bool)
            if vlm_assistant.shape[0] != batch_size:
                raise ValueError(
                    "VLM assistant mask batch size mismatch: "
                    f"{vlm_assistant.shape[0]} vs {batch_size}"
                )
        else:
            vlm_assistant = torch.zeros((batch_size, vlm_seq_len), dtype=torch.bool, device=device)

        batched_mask = mask.unsqueeze(0).expand(batch_size, -1, -1).clone()

        # No branch should attend to right-padding VLM keys.
        batched_mask[:, :, a_end:] &= vlm_valid.unsqueeze(1)

        # Action may use user/image/prompt VLM tokens, but not assistant GT
        # motion tokens because those are derived from the target trajectory.
        action_to_vlm_allowed = (vlm_valid & ~vlm_assistant).unsqueeze(1)
        batched_mask[:, v_end:a_end, a_end:] &= action_to_vlm_allowed

        if causal_vlm:
            vlm_causal = torch.tril(
                torch.ones((vlm_seq_len, vlm_seq_len), dtype=torch.bool, device=device)
            )
            batched_mask[:, a_end:, a_end:] &= vlm_causal.unsqueeze(0)

        return batched_mask

    def _compute_video_loss_per_sample(
        self,
        pred_video: torch.Tensor,
        target_video: torch.Tensor,
        image_is_pad: Optional[torch.Tensor],
        include_initial_video_step: bool,
    ) -> torch.Tensor:
        video_loss_token = F.mse_loss(pred_video.float(), target_video.float(), reduction="none").mean(dim=(1, 3, 4))
        if image_is_pad is None:
            return video_loss_token.mean(dim=1)

        temporal_factor = int(self.vae.temporal_downsample_factor)
        if temporal_factor <= 0:
            raise ValueError(f"`vae.temporal_downsample_factor` must be positive, got {temporal_factor}.")
        if image_is_pad.shape[1] < 1:
            raise ValueError("`image_is_pad` must contain at least one frame.")
        if (image_is_pad.shape[1] - 1) % temporal_factor != 0:
            raise ValueError(
                "Cannot align `image_is_pad` with video latent steps: "
                f"num_frames={image_is_pad.shape[1]}, temporal_downsample_factor={temporal_factor}."
            )

        tail_is_pad = image_is_pad[:, 1:]
        latent_tail_is_pad = tail_is_pad.view(image_is_pad.shape[0], -1, temporal_factor).all(dim=2)
        if include_initial_video_step:
            video_is_pad = torch.cat([image_is_pad[:, :1], latent_tail_is_pad], dim=1)
        else:
            video_is_pad = latent_tail_is_pad

        if video_is_pad.shape[1] != video_loss_token.shape[1]:
            raise ValueError(
                "Video-loss mask shape mismatch: "
                f"mask steps={video_is_pad.shape[1]}, loss steps={video_loss_token.shape[1]}."
            )

        valid = (~video_is_pad).to(device=video_loss_token.device, dtype=video_loss_token.dtype)
        valid_sum = valid.sum(dim=1).clamp(min=1.0)
        return (video_loss_token * valid).sum(dim=1) / valid_sum

    def training_loss(self, sample, tiled: bool = False):
        """Compute training loss with trimodal MoT.

        Same as FastWAM.training_loss, but includes VLM expert in MoT forward.
        """
        inputs = self.build_inputs(sample, tiled=tiled)
        input_latents = inputs["input_latents"]
        batch_size = input_latents.shape[0]
        context = inputs["context"]
        context_mask = inputs["context_mask"]
        action = inputs["action"]
        action_is_pad = inputs["action_is_pad"]
        image_is_pad = inputs["image_is_pad"]
        vlm_inputs = inputs["vlm_inputs"]
        motion_token_labels = inputs.get("motion_token_labels")

        # Video noise schedule
        noise_video = torch.randn_like(input_latents)
        timestep_video = self.train_video_scheduler.sample_training_t(
            batch_size=batch_size, device=self.device, dtype=input_latents.dtype,
        )
        latents = self.train_video_scheduler.add_noise(input_latents, noise_video, timestep_video)
        target_video = self.train_video_scheduler.training_target(input_latents, noise_video, timestep_video)

        if inputs["first_frame_latents"] is not None:
            latents[:, :, 0:1] = inputs["first_frame_latents"]

        # Action noise schedule
        noise_action = torch.randn_like(action)
        timestep_action = self.train_action_scheduler.sample_training_t(
            batch_size=batch_size, device=self.device, dtype=action.dtype,
        )
        noisy_action = self.train_action_scheduler.add_noise(action, noise_action, timestep_action)
        target_action = self.train_action_scheduler.training_target(action, noise_action, timestep_action)

        # Video pre_dit
        video_pre = self.video_expert.pre_dit(
            x=latents, timestep=timestep_video, context=context,
            context_mask=context_mask, action=action,
            fuse_vae_embedding_in_latents=inputs["fuse_vae_embedding_in_latents"],
        )

        # Action pre_dit
        action_pre = self.action_expert.pre_dit(
            action_tokens=noisy_action, timestep=timestep_action,
            context=context, context_mask=context_mask,
        )

        video_tokens = video_pre["tokens"]
        action_tokens = action_pre["tokens"]

        # VLM pre_dit (if VLM inputs provided)
        vlm_layer_features = None
        if vlm_inputs is not None and self.vlm_expert.vlm_model is not None:
            vlm_pre = self.vlm_expert.pre_dit(
                vlm_inputs=vlm_inputs, timestep=timestep_action,
            )
            vlm_tokens = vlm_pre["tokens"]
            vlm_layer_features = vlm_pre.get("vlm_layer_features")
        else:
            # Create zero VLM tokens (no VLM participation)
            vlm_seq_len = 1  # minimal placeholder
            vlm_tokens = torch.zeros(
                (batch_size, vlm_seq_len, self.vlm_expert.vlm_dim),
                dtype=video_tokens.dtype, device=video_tokens.device,
            )
            vlm_pre = {
                "tokens": vlm_tokens,
                "freqs": self.vlm_expert.freqs[:1].view(1, 1, -1).to(video_tokens.device),
                "t_mod": torch.zeros(
                    (batch_size, 1, 6, self.vlm_expert.vlm_dim),
                    dtype=video_tokens.dtype, device=video_tokens.device,
                ),
                "context": torch.zeros(
                    (batch_size, 1, self.vlm_expert.vlm_dim),
                    dtype=video_tokens.dtype, device=video_tokens.device,
                ),
                "context_mask": torch.ones(
                    (batch_size, 1, 1), dtype=torch.bool, device=video_tokens.device,
                ),
            }

        # Build trimodal attention mask
        attention_mask = self._build_trimodal_attention_mask(
            video_seq_len=video_tokens.shape[1],
            action_seq_len=action_tokens.shape[1],
            vlm_seq_len=vlm_tokens.shape[1],
            video_tokens_per_frame=int(video_pre["meta"]["tokens_per_frame"]),
            device=video_tokens.device,
            vlm_attention_mask=(
                vlm_inputs.get("attention_mask")
                if isinstance(vlm_inputs, dict) and motion_token_labels is not None
                else None
            ),
            vlm_assistant_mask=(
                vlm_inputs.get("assistant_token_mask")
                if isinstance(vlm_inputs, dict) and motion_token_labels is not None
                else None
            ),
            causal_vlm=motion_token_labels is not None,
        )

        # Trimodal MoT forward
        tokens_out = self.mot(
            embeds_all={
                "video": video_tokens,
                "action": action_tokens,
                "vlm": vlm_tokens,
            },
            attention_mask=attention_mask,
            freqs_all={
                "video": video_pre["freqs"],
                "action": action_pre["freqs"],
                "vlm": vlm_pre["freqs"],
            },
            context_all={
                "video": {
                    "context": video_pre["context"],
                    "mask": video_pre["context_mask"],
                },
                "action": {
                    "context": action_pre["context"],
                    "mask": action_pre["context_mask"],
                },
                "vlm": None,  # VLM has no cross-attention context in MoT
            },
            t_mod_all={
                "video": video_pre["t_mod"],
                "action": action_pre["t_mod"],
                "vlm": vlm_pre["t_mod"],
            },
            vlm_layer_features=vlm_layer_features,
        )

        pred_video = self.video_expert.post_dit(tokens_out["video"], video_pre)
        pred_action = self.action_expert.post_dit(tokens_out["action"], action_pre)

        # Video loss
        include_initial_video_step = inputs["first_frame_latents"] is None
        if inputs["first_frame_latents"] is not None:
            pred_video = pred_video[:, :, 1:]
            target_video = target_video[:, :, 1:]

        loss_video_per_sample = self._compute_video_loss_per_sample(
            pred_video=pred_video, target_video=target_video,
            image_is_pad=image_is_pad,
            include_initial_video_step=include_initial_video_step,
        )
        video_weight = self.train_video_scheduler.training_weight(timestep_video).to(
            loss_video_per_sample.device, dtype=loss_video_per_sample.dtype,
        )
        loss_video = (loss_video_per_sample * video_weight).mean()

        # Action loss
        action_loss_token = F.mse_loss(pred_action.float(), target_action.float(), reduction="none").mean(dim=2)
        if action_is_pad is not None:
            valid = (~action_is_pad).to(device=action_loss_token.device, dtype=action_loss_token.dtype)
            valid_sum = valid.sum(dim=1).clamp(min=1.0)
            action_loss_per_sample = (action_loss_token * valid).sum(dim=1) / valid_sum
        else:
            action_loss_per_sample = action_loss_token.mean(dim=1)

        action_weight = self.train_action_scheduler.training_weight(timestep_action).to(
            action_loss_per_sample.device, dtype=action_loss_per_sample.dtype,
        )
        loss_action = (action_loss_per_sample * action_weight).mean()

        loss_token = torch.tensor(0.0, device=self.device)
        if self.loss_lambda_vlm > 0:
            if motion_token_labels is None:
                raise ValueError(
                    "loss.lambda_vlm > 0 requires motion-token labels. "
                    "Enable `motion_token_prediction` in the data/model configs."
                )
            if self.vlm_expert.vlm_model is None:
                raise ValueError("loss.lambda_vlm > 0 requires a loaded Qwen3-VL model.")
            motion_token_labels = motion_token_labels.to(device=self.device, dtype=torch.long)
            vlm_final_tokens = tokens_out["vlm"]
            token_logits = self.vlm_expert.vlm_model.lm_head(vlm_final_tokens)
            if motion_token_labels.shape[1] != token_logits.shape[1]:
                if not self._warned_motion_label_mismatch:
                    logger.warning(
                        "Motion-token label/logit length mismatch: labels=%d logits=%d; cropping to common length.",
                        motion_token_labels.shape[1],
                        token_logits.shape[1],
                    )
                    self._warned_motion_label_mismatch = True
                common_len = min(motion_token_labels.shape[1], token_logits.shape[1])
                motion_token_labels = motion_token_labels[:, :common_len]
                token_logits = token_logits[:, :common_len]

            if (motion_token_labels != -100).any():
                loss_token = F.cross_entropy(
                    token_logits.reshape(-1, token_logits.shape[-1]).float(),
                    motion_token_labels.reshape(-1),
                    ignore_index=-100,
                )
            elif not self._warned_empty_motion_labels:
                logger.warning(
                    "loss.lambda_vlm > 0 but all motion-token labels are -100; "
                    "token loss is zero for this step."
                )
                self._warned_empty_motion_labels = True

        loss_total = (
            self.loss_lambda_video * loss_video
            + self.loss_lambda_action * loss_action
            + self.loss_lambda_vlm * loss_token
        )
        loss_dict = {
            "loss_video": self.loss_lambda_video * float(loss_video.detach().item()),
            "loss_action": self.loss_lambda_action * float(loss_action.detach().item()),
        }
        if self.loss_lambda_vlm > 0 or motion_token_labels is not None:
            loss_dict["loss_token"] = self.loss_lambda_vlm * float(loss_token.detach().item())
            loss_dict["loss_token_raw"] = float(loss_token.detach().item())
        return loss_total, loss_dict

    @torch.no_grad()
    def infer_action(
        self,
        prompt: Optional[str],
        input_image: torch.Tensor,
        action_horizon: int,
        proprio: Optional[torch.Tensor] = None,
        context: Optional[torch.Tensor] = None,
        context_mask: Optional[torch.Tensor] = None,
        negative_prompt: Optional[str] = None,
        text_cfg_scale: float = 1.0,
        num_inference_steps: int = 20,
        sigma_shift: Optional[float] = None,
        seed: Optional[int] = None,
        rand_device: str = "cpu",
        tiled: bool = False,
        vlm_inputs=None,
        task: Optional[str] = None,
    ) -> dict[str, Any]:
        """Inference: predict actions using trimodal MoT with VLM.

        During inference:
        1. Video tokens are precomputed once (first frame)
        2. VLM tokens are precomputed once (from vlm_inputs)
        3. Action tokens go through denoising loop, attending to cached Video+VLM K/V

        Args:
            prompt: Text prompt (or use context/context_mask).
            input_image: First frame image [1, 3, H, W] or [3, H, W].
            action_horizon: Number of action steps to predict.
            proprio: Optional proprioceptive state.
            context: Precomputed text context.
            context_mask: Context attention mask.
            vlm_inputs: VLM inputs for Qwen3-VL (image + text tokens).
            Other args: Same as FastWAM.infer_action.

        Returns:
            Dict with "action" key: predicted actions [T, D].
        """
        self.eval()
        if str(getattr(self.video_expert, "video_attention_mask_mode", "")) != "first_frame_causal":
            raise ValueError(
                "`infer_action` requires `video_attention_mask_mode='first_frame_causal'`."
            )

        if input_image.ndim == 3:
            input_image = input_image.unsqueeze(0)
        if input_image.ndim != 4 or input_image.shape[0] != 1 or input_image.shape[1] != 3:
            raise ValueError(
                f"`input_image` must have shape [1,3,H,W] or [3,H,W], got {tuple(input_image.shape)}"
            )
        _, _, height, width = input_image.shape
        if height % 16 != 0 or width % 16 != 0:
            raise ValueError(
                f"`input_image` must be resized before infer, expected multiples of 16 but got HxW=({height},{width})"
            )
        if proprio is not None:
            if self.proprio_dim is None:
                raise ValueError("`proprio` was provided but `proprio_dim=None` so `proprio_encoder` is disabled.")
            if proprio.ndim == 1:
                proprio = proprio.unsqueeze(0)
            elif proprio.ndim == 2 and proprio.shape[0] == 1:
                pass
            else:
                raise ValueError(f"`proprio` must be [D] or [1,D], got shape {tuple(proprio.shape)}")
            if proprio.shape[1] != self.proprio_dim:
                raise ValueError(f"`proprio` last dim must be {self.proprio_dim}, got {proprio.shape[1]}")
            proprio = proprio.to(device=self.device, dtype=self.torch_dtype)

        generator = None if seed is None else torch.Generator(device=rand_device).manual_seed(seed)
        latents_action = torch.randn(
            (1, action_horizon, self.action_expert.action_dim),
            generator=generator,
            device=rand_device,
            dtype=torch.float32,
        ).to(device=self.device, dtype=self.torch_dtype)

        input_image = input_image.to(device=self.device, dtype=self.torch_dtype)
        first_frame_latents = self._encode_input_image_latents_tensor(input_image=input_image, tiled=tiled)
        fuse_flag = bool(getattr(self.video_expert, "fuse_vae_embedding_in_latents", False))

        use_prompt = prompt is not None
        use_context = context is not None or context_mask is not None
        if use_prompt and use_context:
            raise ValueError("`prompt` and `context/context_mask` are mutually exclusive.")
        if not use_prompt and not use_context:
            raise ValueError("Either `prompt` or both `context/context_mask` must be provided.")

        if use_prompt:
            context, context_mask = self.encode_prompt(prompt)
        else:
            if context is None or context_mask is None:
                raise ValueError("`context` and `context_mask` must be both provided together.")
            if context.ndim == 2:
                context = context.unsqueeze(0)
            if context_mask.ndim == 1:
                context_mask = context_mask.unsqueeze(0)
            if context.ndim != 3 or context_mask.ndim != 2:
                raise ValueError(
                    f"`context/context_mask` must be [B,L,D]/[B,L], got {tuple(context.shape)} and {tuple(context_mask.shape)}"
                )
            context = context.to(device=self.device, dtype=self.torch_dtype, non_blocking=True)
            context_mask = context_mask.to(device=self.device, dtype=torch.bool, non_blocking=True)
        if proprio is not None:
            context, context_mask = self._append_proprio_to_context(
                context=context, context_mask=context_mask, proprio=proprio,
            )

        # --- Prefill video ---
        timestep_video = torch.zeros(
            (first_frame_latents.shape[0],),
            dtype=first_frame_latents.dtype,
            device=self.device,
        )
        video_pre = self.video_expert.pre_dit(
            x=first_frame_latents, timestep=timestep_video,
            context=context, context_mask=context_mask,
            action=None, fuse_vae_embedding_in_latents=fuse_flag,
        )
        video_seq_len = int(video_pre["tokens"].shape[1])
        video_tokens_per_frame = int(video_pre["meta"]["tokens_per_frame"])

        # --- Auto-build VLM inputs if not provided ---
        if vlm_inputs is None and self._vlm_processor is not None:
            vlm_text = task or prompt
            if vlm_text is not None:
                vlm_inputs = self._build_vlm_inputs_single(
                    image_tensor=input_image[0],  # [3, H, W]
                    text=vlm_text,
                )

        # --- Prefill VLM (if inputs provided) ---
        vlm_pre = None
        vlm_seq_len = 0
        if vlm_inputs is not None and self.vlm_expert.vlm_model is not None:
            vlm_pre = self.vlm_expert.pre_dit(
                vlm_inputs=vlm_inputs, timestep=timestep_video,
            )
            vlm_seq_len = int(vlm_pre["tokens"].shape[1])

        # --- Build trimodal attention mask ---
        if vlm_seq_len > 0:
            attention_mask = self._build_trimodal_attention_mask(
                video_seq_len=video_seq_len,
                action_seq_len=latents_action.shape[1],
                vlm_seq_len=vlm_seq_len,
                video_tokens_per_frame=video_tokens_per_frame,
                device=video_pre["tokens"].device,
            )
        else:
            # Fallback to bimodal mask (no VLM)
            attention_mask = self._build_bimodal_attention_mask(
                video_seq_len=video_seq_len,
                action_seq_len=latents_action.shape[1],
                video_tokens_per_frame=video_tokens_per_frame,
                device=video_pre["tokens"].device,
            )

        # --- Prefill video+VLM cache ---
        vlm_kwargs = {}
        if vlm_pre is not None:
            vlm_kwargs = {
                "vlm_tokens": vlm_pre["tokens"],
                "vlm_freqs": vlm_pre["freqs"],
                "vlm_t_mod": vlm_pre["t_mod"],
                "vlm_context_payload": None,
            }

        video_kv_cache = self.mot.prefill_video_cache(
            video_tokens=video_pre["tokens"],
            video_freqs=video_pre["freqs"],
            video_t_mod=video_pre["t_mod"],
            video_context_payload={
                "context": video_pre["context"],
                "mask": video_pre["context_mask"],
            },
            video_attention_mask=attention_mask[:video_seq_len, :video_seq_len],
            **vlm_kwargs,
        )

        # --- Action denoising loop ---
        infer_timesteps_action, infer_deltas_action = self.infer_action_scheduler.build_inference_schedule(
            num_inference_steps=num_inference_steps,
            device=self.device,
            dtype=latents_action.dtype,
            shift_override=sigma_shift,
        )
        for step_t_action, step_delta_action in zip(infer_timesteps_action, infer_deltas_action):
            timestep_action = step_t_action.unsqueeze(0).to(dtype=latents_action.dtype, device=self.device)

            action_pre = self.action_expert.pre_dit(
                action_tokens=latents_action,
                timestep=timestep_action,
                context=context,
                context_mask=context_mask,
            )

            action_tokens = self.mot.forward_action_with_video_cache(
                action_tokens=action_pre["tokens"],
                action_freqs=action_pre["freqs"],
                action_t_mod=action_pre["t_mod"],
                action_context_payload={
                    "context": action_pre["context"],
                    "mask": action_pre["context_mask"],
                },
                video_kv_cache=video_kv_cache,
                attention_mask=attention_mask,
                video_seq_len=video_seq_len,
                vlm_seq_len=vlm_seq_len,
            )

            pred_action = self.action_expert.post_dit(action_tokens, action_pre)
            latents_action = self.infer_action_scheduler.step(pred_action, step_delta_action, latents_action)

        return {
            "action": latents_action[0].detach().to(device="cpu", dtype=torch.float32),
        }

    def _predict_joint_noise(
        self,
        latents_video: torch.Tensor,
        latents_action: torch.Tensor,
        timestep_video: torch.Tensor,
        timestep_action: torch.Tensor,
        context: torch.Tensor,
        context_mask: torch.Tensor,
        fuse_vae_embedding_in_latents: bool,
        gt_action: Optional[torch.Tensor] = None,
        vlm_inputs=None,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Predict noise for video and action via trimodal MoT."""
        video_pre = self.video_expert.pre_dit(
            x=latents_video, timestep=timestep_video,
            context=context, context_mask=context_mask,
            action=gt_action,
            fuse_vae_embedding_in_latents=fuse_vae_embedding_in_latents,
        )
        action_pre = self.action_expert.pre_dit(
            action_tokens=latents_action, timestep=timestep_action,
            context=context, context_mask=context_mask,
        )

        # VLM pre_dit
        vlm_layer_features = None
        if vlm_inputs is not None and self.vlm_expert.vlm_model is not None:
            vlm_pre = self.vlm_expert.pre_dit(
                vlm_inputs=vlm_inputs, timestep=timestep_action,
            )
            vlm_tokens = vlm_pre["tokens"]
            vlm_layer_features = vlm_pre.get("vlm_layer_features")
        else:
            vlm_seq_len_placeholder = 1
            vlm_tokens = torch.zeros(
                (latents_video.shape[0], vlm_seq_len_placeholder, self.vlm_expert.vlm_dim),
                dtype=video_pre["tokens"].dtype, device=video_pre["tokens"].device,
            )
            vlm_pre = {
                "tokens": vlm_tokens,
                "freqs": self.vlm_expert.freqs[:1].view(1, 1, -1).to(video_pre["tokens"].device),
                "t_mod": torch.zeros(
                    (latents_video.shape[0], 1, 6, self.vlm_expert.vlm_dim),
                    dtype=video_pre["tokens"].dtype, device=video_pre["tokens"].device,
                ),
                "context": torch.zeros(
                    (latents_video.shape[0], 1, self.vlm_expert.vlm_dim),
                    dtype=video_pre["tokens"].dtype, device=video_pre["tokens"].device,
                ),
                "context_mask": torch.ones(
                    (latents_video.shape[0], 1, 1), dtype=torch.bool, device=video_pre["tokens"].device,
                ),
            }

        # Build trimodal attention mask
        attention_mask = self._build_trimodal_attention_mask(
            video_seq_len=video_pre["tokens"].shape[1],
            action_seq_len=action_pre["tokens"].shape[1],
            vlm_seq_len=vlm_tokens.shape[1],
            video_tokens_per_frame=int(video_pre["meta"]["tokens_per_frame"]),
            device=video_pre["tokens"].device,
        )

        tokens_out = self.mot(
            embeds_all={
                "video": video_pre["tokens"],
                "action": action_pre["tokens"],
                "vlm": vlm_tokens,
            },
            attention_mask=attention_mask,
            freqs_all={
                "video": video_pre["freqs"],
                "action": action_pre["freqs"],
                "vlm": vlm_pre["freqs"],
            },
            context_all={
                "video": {
                    "context": video_pre["context"],
                    "mask": video_pre["context_mask"],
                },
                "action": {
                    "context": action_pre["context"],
                    "mask": action_pre["context_mask"],
                },
                "vlm": None,
            },
            t_mod_all={
                "video": video_pre["t_mod"],
                "action": action_pre["t_mod"],
                "vlm": vlm_pre["t_mod"],
            },
            vlm_layer_features=vlm_layer_features,
        )

        pred_video = self.video_expert.post_dit(tokens_out["video"], video_pre)
        pred_action = self.action_expert.post_dit(tokens_out["action"], action_pre)
        return pred_video, pred_action

    @torch.no_grad()
    def infer_joint(
        self,
        prompt: Optional[str],
        input_image: torch.Tensor,
        num_video_frames: int,
        action_horizon: int,
        action: Optional[torch.Tensor] = None,
        proprio: Optional[torch.Tensor] = None,
        context: Optional[torch.Tensor] = None,
        context_mask: Optional[torch.Tensor] = None,
        negative_prompt: Optional[str] = None,
        text_cfg_scale: float = 1.0,
        num_inference_steps: int = 20,
        sigma_shift: Optional[float] = None,
        seed: Optional[int] = None,
        rand_device: str = "cpu",
        tiled: bool = False,
        test_action_with_infer_action: bool = True,
        vlm_inputs=None,
        task: Optional[str] = None,
    ) -> dict[str, Any]:
        """Joint video + action inference with trimodal MoT."""
        self.eval()

        if input_image.ndim == 3:
            input_image = input_image.unsqueeze(0)
        if input_image.ndim != 4 or input_image.shape[0] != 1 or input_image.shape[1] != 3:
            raise ValueError(
                f"`input_image` must have shape [1,3,H,W] or [3,H,W], got {tuple(input_image.shape)}"
            )
        _, _, height, width = input_image.shape
        checked_h, checked_w, checked_t = self._check_resize_height_width(height, width, num_video_frames)
        if (checked_h, checked_w) != (height, width):
            raise ValueError(
                f"`input_image` must be resized before infer, expected multiples of 16 but got HxW=({height},{width})"
            )
        if checked_t != num_video_frames:
            raise ValueError(
                f"`num_video_frames` must satisfy T % 4 == 1, got {num_video_frames}"
            )
        if action is not None:
            if action.ndim == 2:
                action = action.unsqueeze(0)
            if action.ndim != 3 or action.shape[0] != 1 or action.shape[1] != action_horizon:
                raise ValueError(
                    f"`action` must have shape [1, T, a_dim] or [T, a_dim], got {tuple(action.shape)} with action_horizon={action_horizon}"
                )
            action = action.to(device=self.device, dtype=self.torch_dtype)
        if proprio is not None:
            if self.proprio_dim is None:
                raise ValueError("`proprio` was provided but `proprio_dim=None` so `proprio_encoder` is disabled.")
            if proprio.ndim == 1:
                proprio = proprio.unsqueeze(0)
            elif proprio.ndim == 2 and proprio.shape[0] == 1:
                pass
            else:
                raise ValueError(f"`proprio` must be [D] or [1,D], got shape {tuple(proprio.shape)}")
            if proprio.shape[1] != self.proprio_dim:
                raise ValueError(f"`proprio` last dim must be {self.proprio_dim}, got {proprio.shape[1]}")
            proprio = proprio.to(device=self.device, dtype=self.torch_dtype)

        latent_t = (num_video_frames - 1) // self.vae.temporal_downsample_factor + 1
        latent_h = height // self.vae.upsampling_factor
        latent_w = width // self.vae.upsampling_factor

        video_generator = None if seed is None else torch.Generator(device=rand_device).manual_seed(seed)
        action_generator = None if seed is None else torch.Generator(device=rand_device).manual_seed(seed)
        latents_video = torch.randn(
            (1, self.vae.model.z_dim, latent_t, latent_h, latent_w),
            generator=video_generator,
            device=rand_device,
            dtype=torch.float32,
        ).to(device=self.device, dtype=self.torch_dtype)
        latents_action = torch.randn(
            (1, action_horizon, self.action_expert.action_dim),
            generator=action_generator,
            device=rand_device,
            dtype=torch.float32,
        ).to(device=self.device, dtype=self.torch_dtype)

        input_image = input_image.to(device=self.device, dtype=self.torch_dtype)
        first_frame_latents = self._encode_input_image_latents_tensor(input_image=input_image, tiled=tiled)
        latents_video[:, :, 0:1] = first_frame_latents.clone()
        fuse_flag = bool(getattr(self.video_expert, "fuse_vae_embedding_in_latents", False))

        use_prompt = prompt is not None
        use_context = context is not None or context_mask is not None
        if use_prompt and use_context:
            raise ValueError("`prompt` and `context/context_mask` are mutually exclusive.")
        if not use_prompt and not use_context:
            raise ValueError("Either `prompt` or both `context/context_mask` must be provided.")

        if use_prompt:
            context, context_mask = self.encode_prompt(prompt)
        else:
            if context is None or context_mask is None:
                raise ValueError("`context` and `context_mask` must be both provided together.")
            if context.ndim == 2:
                context = context.unsqueeze(0)
            if context_mask.ndim == 1:
                context_mask = context_mask.unsqueeze(0)
            if context.ndim != 3 or context_mask.ndim != 2:
                raise ValueError(
                    f"`context/context_mask` must be [B,L,D]/[B,L], got {tuple(context.shape)} and {tuple(context_mask.shape)}"
                )
            context = context.to(device=self.device, dtype=self.torch_dtype, non_blocking=True)
            context_mask = context_mask.to(device=self.device, dtype=torch.bool, non_blocking=True)
        if proprio is not None:
            context, context_mask = self._append_proprio_to_context(
                context=context, context_mask=context_mask, proprio=proprio,
            )

        # Auto-build VLM inputs from input_image + task/prompt if not provided
        if vlm_inputs is None and self._vlm_processor is not None:
            vlm_text = task or prompt  # Prefer raw task instruction over T5-wrapped prompt
            if vlm_text is not None:
                vlm_inputs = self._build_vlm_inputs_single(
                    image_tensor=input_image[0],  # [3, H, W]
                    text=vlm_text,
                )

        infer_timesteps_video, infer_deltas_video = self.infer_video_scheduler.build_inference_schedule(
            num_inference_steps=num_inference_steps,
            device=self.device,
            dtype=latents_video.dtype,
            shift_override=sigma_shift,
        )
        infer_timesteps_action, infer_deltas_action = self.infer_action_scheduler.build_inference_schedule(
            num_inference_steps=num_inference_steps,
            device=self.device,
            dtype=latents_action.dtype,
            shift_override=sigma_shift,
        )
        for step_t_video, step_delta_video, step_t_action, step_delta_action in zip(
            infer_timesteps_video, infer_deltas_video,
            infer_timesteps_action, infer_deltas_action,
        ):
            timestep_video = step_t_video.unsqueeze(0).to(dtype=latents_video.dtype, device=self.device)
            timestep_action = step_t_action.unsqueeze(0).to(dtype=latents_action.dtype, device=self.device)

            pred_video, pred_action = self._predict_joint_noise(
                latents_video=latents_video,
                latents_action=latents_action,
                timestep_video=timestep_video,
                timestep_action=timestep_action,
                context=context,
                context_mask=context_mask,
                fuse_vae_embedding_in_latents=fuse_flag,
                gt_action=action,
                vlm_inputs=vlm_inputs,
            )

            latents_video = self.infer_video_scheduler.step(pred_video, step_delta_video, latents_video)
            latents_action = self.infer_action_scheduler.step(pred_action, step_delta_action, latents_action)
            latents_video[:, :, 0:1] = first_frame_latents.clone()

        return {
            "video": self._decode_latents(latents_video, tiled=tiled),
            "action": latents_action[0].detach().to(device="cpu", dtype=torch.float32),
        }

    @torch.no_grad()
    def infer(
        self,
        prompt: Optional[str],
        input_image: torch.Tensor,
        num_frames: int,
        action: Optional[torch.Tensor] = None,
        action_horizon: Optional[int] = None,
        proprio: Optional[torch.Tensor] = None,
        context: Optional[torch.Tensor] = None,
        context_mask: Optional[torch.Tensor] = None,
        negative_prompt: Optional[str] = None,
        text_cfg_scale: float = 5.0,
        action_cfg_scale: float = 1.0,
        num_inference_steps: int = 20,
        sigma_shift: Optional[float] = None,
        seed: Optional[int] = None,
        rand_device: str = "cpu",
        tiled: bool = False,
        vlm_inputs=None,
        task: Optional[str] = None,
    ):
        return self.infer_joint(
            prompt=prompt,
            input_image=input_image,
            num_video_frames=num_frames,
            action_horizon=action_horizon,
            action=action,
            proprio=proprio,
            context=context,
            context_mask=context_mask,
            negative_prompt=negative_prompt,
            text_cfg_scale=text_cfg_scale,
            num_inference_steps=num_inference_steps,
            sigma_shift=sigma_shift,
            seed=seed,
            rand_device=rand_device,
            tiled=tiled,
            vlm_inputs=vlm_inputs,
            task=task,
        )

    def _build_vlm_inputs_single(
        self,
        image_tensor: torch.Tensor,
        text: str,
    ) -> Optional[dict]:
        """Build VLM inputs from a single image tensor + text.

        Args:
            image_tensor: Image tensor [3, H, W], range [-1, 1].
            text: Task instruction string.

        Returns:
            Dict of VLM input tensors, or None if processor unavailable.
        """
        if self._vlm_processor is None:
            return None

        from qwen_vl_utils import process_vision_info

        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "image", "image": self._video_frame_to_pil(image_tensor)},
                    {"type": "text", "text": self._format_vlm_user_text(text)},
                ],
            }
        ]

        chat_text = self._vlm_processor.apply_chat_template(
            messages, tokenize=False, add_generation_prompt=True
        )
        image_inputs, video_inputs = process_vision_info(messages)
        inputs = self._vlm_processor(
            text=[chat_text],
            images=image_inputs,
            videos=video_inputs,
            padding=True,
            return_tensors="pt",
        )

        return {
            "input_ids": inputs["input_ids"],
            "attention_mask": inputs["attention_mask"],
            "pixel_values": inputs["pixel_values"],
            "image_grid_thw": inputs["image_grid_thw"],
        }

    @torch.no_grad()
    def _build_bimodal_attention_mask(
        self,
        video_seq_len: int,
        action_seq_len: int,
        video_tokens_per_frame: int,
        device: torch.device,
    ) -> torch.Tensor:
        """Build bimodal attention mask (same as FastWAM, for fallback)."""
        total_seq_len = video_seq_len + action_seq_len
        mask = torch.zeros((total_seq_len, total_seq_len), dtype=torch.bool, device=device)
        mask[:video_seq_len, :video_seq_len] = self.video_expert.build_video_to_video_mask(
            video_seq_len=video_seq_len, video_tokens_per_frame=video_tokens_per_frame, device=device,
        )
        mask[video_seq_len:, video_seq_len:] = True
        first_frame_tokens = min(video_tokens_per_frame, video_seq_len)
        mask[video_seq_len:, :first_frame_tokens] = True
        return mask

    def save_checkpoint(self, path, optimizer=None, step=None):
        payload = {
            "mot": self.mot.state_dict(),
            "step": step,
            "torch_dtype": str(self.torch_dtype),
        }
        if self.proprio_encoder is not None:
            payload["proprio_encoder"] = self.proprio_encoder.state_dict()
        if optimizer is not None:
            payload["optimizer"] = optimizer.state_dict()
        torch.save(payload, path)

    def load_checkpoint(self, path, optimizer=None):
        payload = torch.load(path, map_location="cpu")
        if "mot" in payload:
            missing, unexpected = self.mot.load_state_dict(payload["mot"], strict=False)
            if missing:
                logger.warning("load_checkpoint missing keys (%d): %s", len(missing), missing[:10])
            if unexpected:
                logger.warning("load_checkpoint unexpected keys (%d): %s", len(unexpected), unexpected[:10])
        elif "dit" in payload:
            logger.warning("Loading legacy `dit` checkpoint into video expert only.")
            self.video_expert.load_state_dict(payload["dit"], strict=False)
        else:
            raise ValueError(f"Checkpoint missing both `mot` and `dit` keys: {path}")
        if self.proprio_encoder is not None:
            if "proprio_encoder" in payload:
                self.proprio_encoder.load_state_dict(payload["proprio_encoder"], strict=True)
            else:
                logger.warning("Checkpoint has no `proprio_encoder` weights; keeping current params.")
        elif "proprio_encoder" in payload:
            logger.warning("Checkpoint contains `proprio_encoder` weights but model has `proprio_dim=None`; ignoring.")
        if optimizer is not None and "optimizer" in payload:
            optimizer.load_state_dict(payload["optimizer"])
        return payload

    def forward(self, *args, **kwargs):
        return self.training_loss(*args, **kwargs)

"""Utilities for discretizing wrist trajectories into motion tokens."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import numpy as np


@dataclass
class AxisRange:
    lo: float
    hi: float

    @property
    def width(self) -> float:
        return self.hi - self.lo


class WristMotionTokenizer:
    """Discretize 3D wrist trajectories into Qwen special-token strings."""

    def __init__(
        self,
        k: int = 1024,
        x_range: Tuple[float, float] = (-0.5, 0.5),
        y_range: Tuple[float, float] = (-0.5, 0.5),
        z_range: Tuple[float, float] = (0.0, 1.0),
        token_format: str = "<|motion_{axis}_{idx:04d}|>",
    ) -> None:
        if k <= 0:
            raise ValueError(f"`k` must be positive, got {k}")
        self.k = int(k)
        self.axes = ["x", "y", "z"]
        self.ranges: Dict[str, AxisRange] = {
            "x": AxisRange(*x_range),
            "y": AxisRange(*y_range),
            "z": AxisRange(*z_range),
        }
        for axis, axis_range in self.ranges.items():
            if axis_range.hi <= axis_range.lo:
                raise ValueError(
                    f"Invalid range for {axis}: hi={axis_range.hi} <= lo={axis_range.lo}"
                )
        self.token_format = token_format

    def _coord_to_bin(self, value: np.ndarray, axis_range: AxisRange) -> np.ndarray:
        value = np.asarray(value, dtype=np.float32)
        value = np.clip(value, axis_range.lo, axis_range.hi)
        normalized = (value - axis_range.lo) / axis_range.width
        idx = np.floor(normalized * self.k).astype(np.int64)
        return np.clip(idx, 0, self.k - 1)

    def encode_indices(self, traj: np.ndarray) -> np.ndarray:
        traj = np.asarray(traj, dtype=np.float32)
        if traj.ndim != 2 or traj.shape[1] != 3:
            raise ValueError(f"Expected trajectory shape [T,3], got {traj.shape}")
        if not np.isfinite(traj).all():
            raise ValueError("Trajectory contains NaN or Inf values.")

        indices = []
        for dim, axis in enumerate(self.axes):
            indices.append(self._coord_to_bin(traj[:, dim], self.ranges[axis]))
        return np.stack(indices, axis=1)

    def encode_tokens(self, traj: np.ndarray) -> List[str]:
        indices = self.encode_indices(traj)
        tokens: List[str] = []
        for t in range(indices.shape[0]):
            for dim, axis in enumerate(self.axes):
                tokens.append(self.token_format.format(axis=axis, idx=int(indices[t, dim])))
        return tokens

    def encode_token_string(self, traj: np.ndarray) -> str:
        return "".join(self.encode_tokens(traj))

    def build_motion_tokens(self, k: Optional[int] = None) -> List[str]:
        token_count = int(k or self.k)
        return [
            self.token_format.format(axis=axis, idx=idx)
            for axis in self.axes
            for idx in range(token_count)
        ]

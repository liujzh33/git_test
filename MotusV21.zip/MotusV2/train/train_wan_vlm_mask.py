#!/usr/bin/env python3
# Training script for MotusWanVlmDirect (WAN + Action + VLM Direct MoT)

import os
import re
import sys
import argparse
import json
import logging
import time
import shutil
import subprocess
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional
import warnings

# Set CUDA memory management environment variables to avoid fragmentation
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"

import torch
import numpy as np
import torch.distributed as dist
from torch.utils.data import DataLoader
from torch.utils.data.distributed import DistributedSampler
from torch.utils.tensorboard import SummaryWriter
import wandb
from accelerate import Accelerator
from accelerate.utils import DeepSpeedPlugin, ProjectConfiguration
import yaml
from omegaconf import OmegaConf

# Add project root to path
sys.path.append(str(Path(__file__).parent.parent))

from models.motus_wan_vlm_direct_mask import MotusWanVlmDirectMask, MotusWanVlmDirectMaskConfig
from data.dataset import create_dataset, collate_fn
from utils.scheduler import create_scheduler
from sample import evaluate_model, log_evaluation_metrics

logger = logging.getLogger(__name__)
train_start_timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")


class MultiSummaryWriter:
    """A wrapper class that writes TensorBoard logs to multiple directories simultaneously."""

    def __init__(self, log_dirs):
        if isinstance(log_dirs, str):
            log_dirs = [log_dirs]

        self.writers = []
        for log_dir in log_dirs:
            try:
                writer = SummaryWriter(log_dir=log_dir)
                self.writers.append(writer)
            except Exception as e:
                logger.warning(f"Failed to create SummaryWriter for {log_dir}: {e}")

        if not self.writers:
            raise RuntimeError("No valid SummaryWriter could be created")
        self.log_dirs = log_dirs

    def add_scalar(self, tag, scalar_value, global_step=None, walltime=None):
        for writer in self.writers:
            writer.add_scalar(tag, scalar_value, global_step, walltime)

    def add_text(self, tag, text, global_step=None, walltime=None):
        for writer in self.writers:
            writer.add_text(tag, text, global_step, walltime)

    def add_histogram(self, tag, values, global_step=None, bins='auto', walltime=None):
        for writer in self.writers:
            writer.add_histogram(tag, values, global_step, bins, walltime)

    def add_image(self, tag, img_tensor, global_step=None, walltime=None, dataformats='CHW'):
        for writer in self.writers:
            writer.add_image(tag, img_tensor, global_step, walltime, dataformats)

    def add_images(self, tag, img_tensor, global_step=None, walltime=None, dataformats='NCHW'):
        for writer in self.writers:
            writer.add_images(tag, img_tensor, global_step, walltime, dataformats)

    def add_scalars(self, main_tag, tag_scalar_dict, global_step=None, walltime=None):
        for writer in self.writers:
            writer.add_scalars(main_tag, tag_scalar_dict, global_step, walltime)

    def flush(self):
        for writer in self.writers:
            writer.flush()

    def close(self):
        for writer in self.writers:
            writer.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False


def setup_logging(rank: int = 0, log_level: str = "INFO", log_dir: str = None):
    """Setup logging: console for all ranks, file handler for rank0 only."""
    root_logger = logging.getLogger()
    root_logger.setLevel(getattr(logging, log_level.upper()))

    formatter = logging.Formatter(
        f'[Rank {rank}] %(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )

    # Console handler (all ranks)
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    # Non-rank0 only shows WARNING+ to reduce noise
    if rank != 0:
        console_handler.setLevel(logging.WARNING)
    root_logger.addHandler(console_handler)

    # File handler (rank0 only) — flushes immediately to survive crashes
    if log_dir is not None and rank == 0:
        os.makedirs(log_dir, exist_ok=True)

        class _FlushFileHandler(logging.FileHandler):
            """FileHandler that flushes after every emit to survive NCCL crashes."""
            def emit(self, record):
                super().emit(record)
                self.flush()

        file_handler = _FlushFileHandler(
            os.path.join(log_dir, "train.log"),
            mode="a"
        )
        file_handler.setFormatter(formatter)
        file_handler.setLevel(getattr(logging, log_level.upper()))
        root_logger.addHandler(file_handler)

    warnings.filterwarnings(
        "ignore",
        message=r"No device id is provided via `init_process_group` or `barrier`.*",
        category=UserWarning,
    )


def copy_config_to_logdir(config_path: str, train_logs_dir: str) -> Path:
    """Copy config file to training log directory for reproducibility."""
    config_path = Path(config_path)
    train_logs_dir = Path(train_logs_dir)

    if not config_path.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")

    train_logs_dir.mkdir(parents=True, exist_ok=True)
    dst_path = train_logs_dir / config_path.name

    if dst_path.exists():
        dst_path = train_logs_dir / f"{config_path.stem}_{train_start_timestamp}{config_path.suffix}"

    shutil.copy2(config_path, dst_path)
    return dst_path


def load_config(config_path: str) -> OmegaConf:
    """Load configuration from YAML file."""
    if not os.path.exists(config_path):
        raise FileNotFoundError(f"Config file not found: {config_path}")

    config = OmegaConf.load(config_path)
    if hasattr(config, "defaults"):
        merged = OmegaConf.create()
        config_dir = Path(config_path).resolve().parent
        for default_path in config.defaults:
            default_path = Path(default_path)
            if not default_path.is_absolute():
                default_path = config_dir / default_path
            merged = OmegaConf.merge(merged, OmegaConf.load(default_path))
        config = OmegaConf.merge(merged, config)

    # MotusV1 configs used top-level training_mode and und_expert. MotusV2 only
    # trains MotusWanVlmDirectMask, so normalize the schema here.
    if not hasattr(config.model, 'training_mode'):
        config.model.training_mode = getattr(config, 'training_mode', 'finetune')
    if not hasattr(config.model, 'qwen3_expert'):
        config.model.qwen3_expert = {
            'vlm_dim': 2048,
            'head_dim': 128,
            'num_heads': 24,
            'num_layers': 30,
            'norm_eps': 1e-5,
        }
    if not hasattr(config.model, 'loss_weights'):
        config.model.loss_weights = {'video_loss_weight': 1.0, 'action_loss_weight': 1.0}
    if not hasattr(config.model, 'inference'):
        config.model.inference = {'num_inference_timesteps': 10}
    if not hasattr(config.model, 'ema'):
        config.model.ema = {
            'enabled': False,
            'update_after_step': 0,
            'inv_gamma': 1.0,
            'power': 0.75,
            'min_value': 0.0,
            'max_value': 0.9999,
        }
    if not hasattr(config.model.vlm, 'frozen'):
        config.model.vlm.frozen = False
    if not hasattr(config.model, 'motion_token_prediction'):
        config.model.motion_token_prediction = {'enabled': False, 'num_bins': 1024}
    elif not hasattr(config.model.motion_token_prediction, 'enabled'):
        config.model.motion_token_prediction.enabled = False
    if not hasattr(config.model.loss_weights, 'token_loss_weight'):
        config.model.loss_weights.token_loss_weight = 0.0
    if not hasattr(config.training, 'vlm_learning_rate'):
        config.training.vlm_learning_rate = getattr(config.training, 'learning_rate', 5e-5)
    if not hasattr(config.training, 'wan_learning_rate'):
        config.training.wan_learning_rate = getattr(config.training, 'learning_rate', 5e-5)

    # Calculate derived parameters
    config.common.action_chunk_size = config.common.num_video_frames * config.common.video_action_freq_ratio

    # Adapt MotusV1 dataset configs to MotusV2 model dimensions.
    dataset_type = config.dataset.get('type', 'robotwin')
    action_mode = config.dataset.get('action_mode', 'default')
    if dataset_type == 'robotwin':
        robot_action_mode = config.dataset.get('action_mode', 'qpos')
        if robot_action_mode == 'qpos_unified_eef_combined32':
            dim = 32
        elif robot_action_mode == 'unified_eef_camera_delta_wrist16':
            dim = 16
        elif robot_action_mode == 'eepos':
            dim = 16
        else:
            dim = config.common.get('action_dim', 14)
        config.common.action_dim = dim
        config.common.state_dim = dim
    elif dataset_type in ('vitra_human', 'vitra_human_mixed'):
        wrist_mode = config.dataset.get('wrist_mode', False)
        latent_mode = config.dataset.get('latent_mode', False)
        if action_mode == 'padded_per_hand':
            config.common.action_dim = 450
            config.common.state_dim = 450
        elif action_mode in ('wrist_padded16', 'relative_wrist_padded16', 'unified_eef_camera_delta_wrist16'):
            config.common.action_dim = 16
            config.common.state_dim = 16
        elif action_mode == 'wrist' or wrist_mode:
            config.common.action_dim = 14
            config.common.state_dim = 14
        elif action_mode == 'latent' or latent_mode:
            latent_dim = config.dataset.get('latent_dim', 16)
            config.common.action_dim = latent_dim
            config.common.state_dim = latent_dim
        else:
            config.common.action_dim = config.common.get('action_dim', 192)
            config.common.state_dim = config.common.get('state_dim', 212)
    elif dataset_type == 'vitra_robot_mixed':
        config.common.action_dim = config.common.get('action_dim', 36)
        config.common.state_dim = config.common.get('state_dim', 36)
    elif dataset_type in ('wiyh', 'egodex', 'cross_dataset_mixed'):
        if action_mode == 'padded_per_hand':
            config.common.action_dim = 450
            config.common.state_dim = 450
        elif action_mode in ('wrist_padded16', 'relative_wrist_padded16', 'unified_eef_camera_delta_wrist16'):
            config.common.action_dim = 16
            config.common.state_dim = 16
        else:
            config.common.action_dim = 14
            config.common.state_dim = 14
    elif dataset_type == 'latent_action':
        dim = config.common.get('action_dim', config.common.get('max_action_dim', 16))
        config.common.action_dim = dim
        config.common.state_dim = config.common.get('state_dim', dim)
    elif dataset_type == 'droid':
        # DROID qpos action: 7 panda joints + 1 gripper (aligned with RoboLab Pi0.5)
        config.common.action_dim = 8
        config.common.state_dim = 8

    logger.info(f"Loaded config from {config_path}")
    logger.info(f"Dataset type: {config.dataset.type}")
    logger.info(f"Training mode: {config.model.training_mode}")
    logger.info(f"Action chunk size: {config.common.action_chunk_size}")
    logger.info(f"Video frames: {config.common.num_video_frames}")
    logger.info(f"Action dim: {config.common.action_dim}, State dim: {config.common.state_dim}")
    logger.info(f"WAN checkpoint path: {config.model.wan.checkpoint_path if hasattr(config.model, 'wan') and hasattr(config.model.wan, 'checkpoint_path') else 'NOT FOUND'}")

    return config


def setup_distributed():
    """Setup distributed training."""
    if 'RANK' in os.environ and 'WORLD_SIZE' in os.environ:
        rank = int(os.environ['RANK'])
        world_size = int(os.environ['WORLD_SIZE'])
        local_rank = int(os.environ.get('LOCAL_RANK', 0))

        torch.cuda.set_device(local_rank)
        dist.init_process_group(backend='nccl')

        return rank, world_size, local_rank
    else:
        return 0, 1, 0


class MotusWanVlmTrainer:
    """Trainer class for MotusWanVlmDirectMask (WAN + Action + VLM Direct MoT)."""

    def __init__(
        self,
        model: MotusWanVlmDirectMask,
        train_dataloader: DataLoader,
        val_dataloader: Optional[DataLoader] = None,
        optimizer: Optional[torch.optim.Optimizer] = None,
        scheduler: Optional[torch.optim.lr_scheduler.LRScheduler] = None,
        device: str = "cuda",
        rank: int = 0,
        world_size: int = 1,
        checkpoint_dir: str = "./checkpoints_wan_vlm",
        log_interval: int = 100,
        save_interval: int = 1000,
        val_interval: int = 1000,
        report_to: str = "wandb",
        tb_writer: Optional[SummaryWriter] = None,
        accelerator: Optional[Any] = None,
        config: Optional[Any] = None,
    ):
        self.model = model
        self.train_dataloader = train_dataloader
        self.val_dataloader = val_dataloader
        self.optimizer = optimizer
        self.scheduler = scheduler
        self.device = device
        self.rank = rank
        self.world_size = world_size

        self.dtype = torch.bfloat16
        self.checkpoint_dir = Path(checkpoint_dir)
        self.log_interval = log_interval
        self.save_interval = save_interval
        self.val_interval = val_interval
        self.report_to = report_to
        self.tb_writer = tb_writer
        self.accelerator = accelerator
        self.config = config

        if rank == 0:
            self.checkpoint_dir.mkdir(parents=True, exist_ok=True)

        self.global_step = 0
        self.epoch = 0

        # Track best action L2 loss for special checkpoint saving
        self.best_action_l2_loss = float('inf')
        self.best_action_l2_step = 0
        self.task_sample_counts = Counter()
        self.task_sample_total = 0
        task_sampling_config = config.dataset.get("task_sampling", {}) if config is not None else {}
        self.task_sampling_log_interval = int(
            task_sampling_config.get("log_interval", 500)
        )

        logger.info(f"MotusWanVlmDirect Trainer initialized on rank {rank}/{world_size}")
        logger.info(f"Logging backends: {report_to}")

    def save_checkpoint(self, suffix: str = "", is_best_checkpoint: bool = False):
        """Save complete training state using accelerator."""
        if is_best_checkpoint and suffix == "_best_action_l2":
            # For best checkpoint, use fixed name (overwrite old)
            checkpoint_dir = self.checkpoint_dir / "best_action_l2"
        else:
            checkpoint_dir = self.checkpoint_dir / f"checkpoint_step_{self.global_step}{suffix}"

        # Use accelerator to save complete training state
        self.accelerator.save_state(str(checkpoint_dir))
        logger.info(f"Checkpoint saved to {checkpoint_dir}")

        # Also save a config.json alongside weights for reproducibility
        try:
            from omegaconf import OmegaConf as _OmegaConf
            cfg_dict = _OmegaConf.to_container(self.config, resolve=True) if self.config is not None else {}
            # Filter only requested sections
            common = cfg_dict.get("common", {})
            model = cfg_dict.get("model", {})
            dataset = cfg_dict.get("dataset", {})
            filtered = {
                "common": common,
                "action_expert": model.get("action_expert", {}),
                "qwen3_expert": model.get("qwen3_expert", {}),
                "video_flow_shift": model.get("video_flow_shift", 5.0),
                "action_flow_shift": model.get("action_flow_shift", 5.0),
                # Action-space contract. Inference reads this back and refuses to
                # serve a checkpoint whose normalization disagrees with the config
                # it is being served under -- that mismatch produces plausible-
                # looking but wrong joint targets, which is near-impossible to
                # diagnose from eval results alone.
                "dataset": {
                    "type": dataset.get("type"),
                    "action_normalization": dataset.get("action_normalization", True),
                    "t5_precision": dataset.get("t5_precision", "float32"),
                },
            }
            import json as _json
            with open(checkpoint_dir / "config.json", "w") as f:
                _json.dump(filtered, f, indent=2)
            logger.info(f"Wrote config.json to {checkpoint_dir}")
        except Exception as e:
            logger.warning(f"Failed to write config.json: {e}")

        # Upload checkpoint to OBS (each node's local-rank-0, non-blocking)
        self._upload_checkpoint_to_obs(str(checkpoint_dir))

    def _upload_checkpoint_to_obs(self, local_dir: str):
        """Upload a checkpoint directory to OBS.

        In multi-node DeepSpeed ZeRO-1, each rank saves its own optimizer shard
        locally. To make the OBS copy usable for resuming training, every rank
        uploads its local files. Ranks on the same node share the same local
        filesystem, so only local-rank-0 per node does the upload to avoid
        redundant copies.
        """
        upload_obs_base = os.environ.get('UPLOAD_OBS_BASE', '')
        if not upload_obs_base:
            return

        # Only local rank 0 uploads (each node has its own filesystem)
        local_rank = int(os.environ.get('LOCAL_RANK', 0))
        if local_rank != 0:
            return

        # Determine node index for OBS path organization
        node_rank = int(os.environ.get('NODE_RANK', os.environ.get('GROUP_WORLD_SIZE', '0')))
        ckpt_name = os.path.basename(local_dir)

        if node_rank == 0:
            obs_dir = f"{upload_obs_base}/checkpoints/{ckpt_name}"
        else:
            obs_dir = f"{upload_obs_base}/checkpoints/{ckpt_name}/node_{node_rank}"

        # Use qwen3 conda env's python (which has moxing)
        qwen3_python = "/root/miniconda3/envs/qwen3/bin/python"
        if not os.path.exists(qwen3_python):
            logger.warning(f"qwen3 python not found at {qwen3_python}, skip OBS upload")
            return

        upload_cmd = (
            f'{qwen3_python} -c '
            f'"import moxing as mox; mox.file.copy_parallel(\'{local_dir}\', \'{obs_dir}\')"'
        )
        logger.info(f"Uploading checkpoint to OBS (node {node_rank}): {ckpt_name} -> {obs_dir}")
        try:
            proc = subprocess.Popen(upload_cmd, shell=True,
                                    stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            # Non-blocking: don't wait, let it run in background
            if not hasattr(self, '_upload_procs'):
                self._upload_procs = []
            self._upload_procs.append(proc)
            # Clean up finished processes
            self._upload_procs = [p for p in self._upload_procs if p.poll() is None]
        except Exception as e:
            logger.warning(f"Failed to start OBS upload: {e}")

    def load_checkpoint(self, checkpoint_path: str, reset_scheduler: bool = True):
        """
        Load checkpoint and resume training.

        Args:
            checkpoint_path: Path to checkpoint directory
            reset_scheduler: If True, reset scheduler to new config instead of loading from checkpoint
        """
        if not os.path.exists(checkpoint_path):
            logger.warning(f"Checkpoint path {checkpoint_path} does not exist")
            return

        logger.info(f"Loading checkpoint from {checkpoint_path}")

        # Extract step number from checkpoint path (e.g., checkpoint_step_125000)
        step_match = re.search(r'step_(\d+)', checkpoint_path)
        if step_match:
            self.global_step = int(step_match.group(1))
            logger.info(f"Resuming from step {self.global_step}")
        else:
            logger.warning(f"Could not extract step number from {checkpoint_path}, starting from step 0")

        # Load using accelerator
        self.accelerator.load_state(checkpoint_path)
        logger.info(f"Checkpoint loaded successfully from {checkpoint_path}")

        # Reset scheduler with new config if requested
        if reset_scheduler and self.config is not None and self.scheduler is not None:
            logger.info("Resetting scheduler to new configuration (not using checkpoint scheduler state)...")

            configured_lrs = [
                float(self.config.training.learning_rate),
                float(getattr(
                    self.config.training,
                    "wan_learning_rate",
                    self.config.training.learning_rate,
                )),
                float(getattr(
                    self.config.training,
                    "vlm_learning_rate",
                    self.config.training.learning_rate,
                )),
            ]
            named_lrs = {
                "main": configured_lrs[0],
                "wan": configured_lrs[1],
                "vlm": configured_lrs[2],
            }
            applied_lrs = []
            for index, group in enumerate(self.optimizer.param_groups):
                group_name = group.get("name")
                new_lr = named_lrs.get(
                    group_name,
                    configured_lrs[min(index, len(configured_lrs) - 1)],
                )
                group["lr"] = new_lr
                group["initial_lr"] = new_lr
                applied_lrs.append(new_lr)
            logger.info(
                "Reset optimizer learning rates from config: %s",
                ", ".join(f"{lr:.3e}" for lr in applied_lrs),
            )

            unwrapped_scheduler = self.scheduler
            # Accelerate uses `.scheduler`; some wrappers use `.module`.
            # Peel either wrapper so the underlying custom scheduler is reset.
            for wrapper_attr in ("scheduler", "module"):
                candidate = getattr(unwrapped_scheduler, wrapper_attr, None)
                if candidate is not None and candidate is not unwrapped_scheduler:
                    unwrapped_scheduler = candidate

            if hasattr(unwrapped_scheduler, 'warm_up_steps'):
                unwrapped_scheduler.warm_up_steps = self.config.training.warmup_steps
                unwrapped_scheduler.cycle_length = self.config.training.cycle_length
                unwrapped_scheduler.f_max = self.config.training.f_max
                unwrapped_scheduler.f_min = self.config.training.f_min
                unwrapped_scheduler.base_lrs = applied_lrs
                unwrapped_scheduler.step_count = 0

                logger.info("Scheduler reset complete")
                logger.info(f"Learning rate will be updated by scheduler on first training step")

    def track_task_sampling(self, batch: Dict[str, Any]):
        """Track the task mixture observed by rank 0's dataloader."""
        if self.rank != 0:
            return
        task_names = batch.get("task_names")
        if not task_names:
            return

        self.task_sample_counts.update(
            task_name for task_name in task_names if task_name is not None
        )
        self.task_sample_total += sum(
            task_name is not None for task_name in task_names
        )

        interval = self.task_sampling_log_interval
        if interval <= 0 or self.global_step <= 0 or self.global_step % interval != 0:
            return
        if self.task_sample_total == 0:
            return

        observed = sorted(
            (
                (task_name, count / self.task_sample_total)
                for task_name, count in self.task_sample_counts.items()
            ),
            key=lambda item: (-item[1], item[0]),
        )
        logger.info(
            "Observed task sampling over %d rank-0 samples; top=%s",
            self.task_sample_total,
            ", ".join(
                f"{task_name}:{probability:.2%}"
                for task_name, probability in observed[:10]
            ),
        )
        if self.tb_writer:
            for task_name, probability in observed:
                self.tb_writer.add_scalar(
                    f"sampling/task_probability/{task_name}",
                    probability,
                    self.global_step,
                )

    def train_step(self, batch: Dict[str, Any]) -> Dict[str, float]:
        """Single training step for MotusWanVlmDirect (complete step like original train.py)."""
        # Handle DDP wrapper
        model = self.model.module if hasattr(self.model, 'module') else self.model

        # Review Major-1: use Accelerate's accumulation context so
        # gradient_accumulation_steps controls optimizer/scheduler stepping.
        with self.accelerator.accumulate(self.model):
            # Prepare batch
            first_frame = batch['first_frame'].to(self.device, dtype=self.dtype)
            video_frames = batch['video_frames'].to(self.device, dtype=self.dtype)
            action_sequence = batch['action_sequence'].to(self.device, dtype=self.dtype)
            state = batch.get('initial_state')
            if state is not None:
                state = state.to(self.device, dtype=self.dtype)

            # Language embeddings (T5 for WAN cross attention)
            language_embeddings = batch.get('language_embedding')
            if language_embeddings is not None:
                language_embeddings = language_embeddings.to(self.device, dtype=self.dtype)

            # VLM inputs. In motion-token training this is the full
            # prompt+assistant sequence; model-side masks prevent leakage.
            vlm_inputs = batch.get('vlm_inputs')
            if vlm_inputs is not None:
                vlm_inputs = {k: v.to(self.device) if isinstance(v, torch.Tensor) else v
                             for k, v in vlm_inputs.items()}

            # Motion token labels
            motion_token_labels = batch.get('motion_token_labels')

            # Action valid mask (for unified_eef_camera_delta_wrist16 and similar)
            action_valid_mask = batch.get('action_valid_mask')
            if action_valid_mask is not None:
                action_valid_mask = action_valid_mask.to(self.device)

            # Model forward
            loss_dict = model.training_step(
                first_frame=first_frame,
                video_frames=video_frames,
                state=state,
                actions=action_sequence,
                language_embeddings=language_embeddings,
                vlm_inputs=vlm_inputs,
                motion_token_labels=motion_token_labels,
                action_valid_mask=action_valid_mask,
                return_dict=True
            )

            # Backward pass
            loss = loss_dict['total_loss']

            # NaN/Inf guard before backward.  The skip decision MUST be
            # collective: if only some ranks see a bad loss and skip backward
            # while the others call accelerator.backward(), the gradient
            # all-reduce mismatches and training hangs.  All-reduce a bad-loss
            # flag (MAX) so every rank branches identically.
            loss_is_bad = bool(torch.isnan(loss).item() or torch.isinf(loss).item())
            if dist.is_available() and dist.is_initialized():
                bad_flag = torch.tensor([1.0 if loss_is_bad else 0.0], device=self.device)
                dist.all_reduce(bad_flag, op=dist.ReduceOp.MAX)
                loss_is_bad = bad_flag.item() > 0.5
            if loss_is_bad:
                logger.error(
                    f"Step {self.global_step}: NaN/Inf loss on >=1 rank "
                    f"(local total_loss={loss.item()}); all ranks skip backward"
                )
                # Do NOT zero_grad here: at gradient_accumulation_steps > 1 that
                # would wipe gradients already accumulated from earlier
                # micro-batches in this window.  Skipping backward on all ranks
                # keeps collectives in lockstep; the normal path zeroes grads
                # after the next successful optimizer step.
                result = {k: v.item() if torch.is_tensor(v) else v for k, v in loss_dict.items()}
                result["_optimizer_step"] = False
                return result

            self.accelerator.backward(loss)

            # NaN diagnostic: check gradients after backward (first 2 steps only)
            if self.global_step < 3 and not hasattr(self, '_grad_check_done'):
                nan_params = []
                inf_params = []
                large_grad_params = []
                for name, param in model.named_parameters():
                    if param.grad is not None:
                        if torch.isnan(param.grad).any():
                            nan_params.append(name)
                        if torch.isinf(param.grad).any():
                            inf_params.append(name)
                        grad_norm = param.grad.data.float().norm().item()
                        if grad_norm > 100:
                            large_grad_params.append((name, grad_norm))
                if nan_params:
                    logger.error(f"Step {self.global_step}: NaN gradients in: {nan_params[:10]}")
                    self._grad_check_done = True
                if inf_params:
                    logger.error(f"Step {self.global_step}: Inf gradients in: {inf_params[:10]}")
                    self._grad_check_done = True
                if large_grad_params:
                    large_grad_params.sort(key=lambda x: -x[1])
                    logger.warning(f"Step {self.global_step}: Large gradients (>100): {large_grad_params[:10]}")

            # Gradient clipping only when gradients are synchronized.
            grad_clip_norm = getattr(self.config.training, 'grad_clip_norm', 1.0)
            if self.accelerator.sync_gradients and grad_clip_norm > 0:
                self.accelerator.clip_grad_norm_(
                    model.parameters(),
                    max_norm=grad_clip_norm
                )

            self.optimizer.step()
            if self.scheduler:
                self.scheduler.step()
            self.optimizer.zero_grad()
            did_optimizer_step = self.accelerator.sync_gradients

        result = {k: v.item() if torch.is_tensor(v) else v for k, v in loss_dict.items()}
        result["_optimizer_step"] = bool(did_optimizer_step)
        return result

    def train(self, max_steps: int, resume_from: Optional[str] = None, reset_scheduler: Optional[bool] = None):
        """
        Main training loop.

        Args:
            max_steps: Maximum number of training steps
            resume_from: Path to checkpoint to resume from
            reset_scheduler: If True, reset scheduler to new config. If None, use config value
        """
        # Load checkpoint if specified
        if resume_from:
            if reset_scheduler is None:
                reset_scheduler = True  # Default behavior
            self.load_checkpoint(resume_from, reset_scheduler=reset_scheduler)

        logger.info(f"Starting MotusWanVlmDirect training for {max_steps} steps")

        start_time = time.time()

        grad_accum_steps = getattr(self.config.training, 'gradient_accumulation_steps', 1)
        if self.rank == 0:
            logger.info(f"Gradient accumulation steps: {grad_accum_steps}")

        # Step-based training loop (same as original train.py to avoid epoch sync issues)
        data_iter = iter(self.train_dataloader)
        epoch = 0

        while self.global_step < max_steps:
            data_wait_start = time.time()
            try:
                batch = next(data_iter)
            except StopIteration:
                # End of epoch, restart dataloader
                epoch += 1
                self.epoch = epoch
                if hasattr(self.train_dataloader.sampler, 'set_epoch'):
                    self.train_dataloader.sampler.set_epoch(epoch)
                data_iter = iter(self.train_dataloader)
                batch = next(data_iter)
            data_wait = time.time() - data_wait_start

            # Partial-batch invariant: collate_fn returns None when every
            # sample on this rank was dropped.  Skipping only the affected rank
            # (per-rank `continue`) desyncs ranks: the others proceed to
            # backward/all-reduce and the collective barriers at val/save time
            # (keyed on global_step) deadlock.  Make the skip COLLECTIVE so all
            # ranks drop this iteration together and stay in lockstep.
            have_valid_batch = 0.0 if batch is None else 1.0
            if dist.is_available() and dist.is_initialized():
                flag = torch.tensor([have_valid_batch], device=self.device)
                dist.all_reduce(flag, op=dist.ReduceOp.MIN)
                have_valid_batch = flag.item()
            if have_valid_batch < 0.5:
                if batch is not None and self.rank == 0:
                    logger.warning(
                        f"Step {self.global_step}: another rank had an empty batch; "
                        "all ranks skip this iteration to stay in sync"
                    )
                continue

            # Training step
            step_start_time = time.time()
            self.track_task_sampling(batch)

            loss_dict = self.train_step(batch)  # Includes accumulation-aware optimizer step

            # Profile breakdown (log every 5 steps)
            model = self.model.module if hasattr(self.model, 'module') else self.model
            if self.rank == 0 and hasattr(model, '_timing') and self.global_step % 5 == 0:
                pass  # Skip profiling for now

            step_time = time.time() - step_start_time
            did_optimizer_step = bool(loss_dict.pop("_optimizer_step", True))
            if not did_optimizer_step:
                continue

            self.global_step += 1

            # Log each rank's global_step (commented out)
            # logger.info(f"Rank {self.rank}: global_step={self.global_step}")

            # Logging
            if self.global_step % self.log_interval == 0 and self.rank == 0:
                self.log_metrics(loss_dict, step_time, data_wait=data_wait)

            # Validation
            if self.global_step % self.val_interval == 0 and self.val_dataloader is not None:
                should_save_best = False
                if self.rank == 0:
                    # Unwrap model from DDP/DeepSpeed for inference
                    unwrapped_model = self.model.module if hasattr(self.model, 'module') else self.model
                    val_metrics = evaluate_model(
                        unwrapped_model, self.val_dataloader, self.accelerator, self.config,
                        num_eval_batches=int(
                            getattr(self.config.system, "num_eval_batches", 2)
                        )
                    )
                    logger.info(f"Validation - Step {self.global_step}")
                    log_evaluation_metrics(val_metrics, self.tb_writer, self.accelerator, self.global_step)

                    # Check if action L2 loss is the best.
                    # Prefer masked L2 (only valid dims) when available; fall
                    # back to raw L2 for legacy datasets that don't produce
                    # action_valid_mask.
                    action_l2_key = 'action_l2_error_masked' if 'action_l2_error_masked' in val_metrics else 'action_l2_error'
                    if action_l2_key in val_metrics:
                        current_action_l2 = val_metrics[action_l2_key]
                        if current_action_l2 < self.best_action_l2_loss:
                            self.best_action_l2_loss = current_action_l2
                            self.best_action_l2_step = self.global_step
                            logger.info(f"New best action L2 loss ({action_l2_key}): {current_action_l2:.6f} at step {self.global_step}")
                            should_save_best = True

                # Synchronize all processes using pure dist API
                # (mixing dist.* with accelerator.wait_for_everyone() causes deadlock in multi-node DeepSpeed)
                if dist.is_available() and dist.is_initialized():
                    should_save_best_tensor = torch.tensor([1.0 if should_save_best else 0.0], device='cuda')
                    dist.all_reduce(should_save_best_tensor, op=dist.ReduceOp.MAX)
                    should_save_best = should_save_best_tensor.item() > 0.5

                    try:
                        dist.barrier(device_ids=[torch.cuda.current_device()])
                    except TypeError:
                        dist.barrier()

                # Save best checkpoint (all ranks participate in DeepSpeed save)
                if should_save_best:
                    self.save_checkpoint(suffix="_best_action_l2", is_best_checkpoint=True)

            # Save checkpoint (avoid double save when step hits both save_interval and max_steps)
            if self.global_step % self.save_interval == 0 or self.global_step >= max_steps:
                if self.global_step >= max_steps:
                    logger.info(f"Reached max_steps {max_steps}, training complete!")
                self.save_checkpoint()

            if self.global_step >= max_steps:
                return

        total_time = time.time() - start_time
        # Log best action L2 checkpoint info (only rank 0)
        if self.rank == 0:
            if self.best_action_l2_step > 0:
                logger.info(f"Best action L2 loss: {self.best_action_l2_loss:.6f} at step {self.best_action_l2_step}")
                logger.info(f"Best action L2 checkpoint saved to: best_action_l2")

    def log_metrics(self, loss_dict: Dict[str, float], elapsed_time: float, data_wait: float = 0.0):
        """Log training metrics.

        ``elapsed_time`` covers the compute step only; ``data_wait`` is the time
        spent blocked on the dataloader, so the two together show whether the
        input pipeline is keeping up with the GPUs.
        """
        lrs = [g['lr'] for g in self.optimizer.param_groups]
        lr_main = lrs[0] if len(lrs) > 0 else 0.0
        lr_wan = lrs[1] if len(lrs) > 1 else lr_main
        lr_vlm = lrs[2] if len(lrs) > 2 else lr_main

        if self.rank == 0:
            logger.info(
                f"Step {self.global_step}/{self.config.training.max_steps} (Epoch {self.epoch}), "
                f"Loss: {loss_dict['total_loss']:.4f} "
                f"(Video: {loss_dict['video_loss']:.4f}, Action: {loss_dict['action_loss']:.4f}, Token: {loss_dict.get('token_loss', 0.0):.4f}), "
                f"LR(main/wan/vlm)={lr_main:.2e}/{lr_wan:.2e}/{lr_vlm:.2e}, "
                f"Time: {elapsed_time:.2f}s (data {data_wait:.2f}s)"
            )

            # Log to WandB - include all loss_dict metrics
            if self.report_to in ["wandb", "all"] or "wandb" in self.report_to:
                wandb.log({
                    **loss_dict,
                    'learning_rate_main': lr_main,
                    'learning_rate_wan': lr_wan,
                    'learning_rate_vlm': lr_vlm,
                    'step_time': elapsed_time,
                    'data_wait': data_wait,
                    'epoch': self.epoch,
                    'global_step': self.global_step,
                }, step=self.global_step)

            # Log to TensorBoard - include all loss_dict metrics
            if ("tensorboard" in self.report_to or "all" in self.report_to) and self.tb_writer:
                for key, value in loss_dict.items():
                    self.tb_writer.add_scalar(f'train/{key}', value, self.global_step)
                self.tb_writer.add_scalar('train/learning_rate_main', lr_main, self.global_step)
                self.tb_writer.add_scalar('train/learning_rate_wan', lr_wan, self.global_step)
                self.tb_writer.add_scalar('train/learning_rate_vlm', lr_vlm, self.global_step)
                self.tb_writer.add_scalar('train/step_time', elapsed_time, self.global_step)
                self.tb_writer.add_scalar('train/data_wait', data_wait, self.global_step)
                self.tb_writer.add_scalar('train/epoch', self.epoch, self.global_step)


def create_model_and_optimizer(config: OmegaConf) -> tuple:
    """Create MotusWanVlmDirectMask model and optimizer from config."""
    # Create MotusWanVlmDirectMask config
    model_config = MotusWanVlmDirectMaskConfig(
        wan_checkpoint_path=config.model.wan.checkpoint_path,
        vae_path=config.model.wan.vae_path,
        wan_config_path=config.model.wan.config_path,
        vlm_checkpoint_path=config.model.vlm.checkpoint_path,
        video_precision=config.model.wan.precision,
        action_state_dim=config.common.state_dim,
        action_dim=config.common.action_dim,
        # Action Expert configuration
        action_expert_dim=config.model.action_expert.hidden_size,
        action_expert_ffn_dim_multiplier=config.model.action_expert.ffn_dim_multiplier,
        action_expert_norm_eps=config.model.action_expert.norm_eps,
        # Qwen3-VL Expert configuration (per-layer QKV projections)
        vlm_dim=config.model.qwen3_expert.vlm_dim,
        qwen3_expert_head_dim=config.model.qwen3_expert.head_dim,
        qwen3_expert_num_heads=config.model.qwen3_expert.num_heads,
        qwen3_expert_num_layers=config.model.qwen3_expert.num_layers,
        qwen3_expert_norm_eps=config.model.qwen3_expert.norm_eps,
        # Other settings
        global_downsample_rate=config.common.global_downsample_rate,
        video_action_freq_ratio=config.common.video_action_freq_ratio,
        num_video_frames=config.common.num_video_frames,
        video_height=config.common.video_height,
        video_width=config.common.video_width,
        batch_size=config.training.batch_size,
        video_loss_weight=config.model.loss_weights.video_loss_weight,
        action_loss_weight=config.model.loss_weights.action_loss_weight,
        token_loss_weight=config.model.loss_weights.get('token_loss_weight', 0.0),
        training_mode=config.model.training_mode,
        load_pretrained_backbones=getattr(config.model, 'load_pretrained_backbones', None),
        vlm_frozen=getattr(config.model.vlm, 'frozen', False),
        gradient_checkpointing=getattr(config.model, 'gradient_checkpointing', True),
        vlm_causal_attention=getattr(config.model, 'vlm_causal_attention', False),
        video_flow_shift=float(config.model.get('video_flow_shift', 5.0)),
        action_flow_shift=float(config.model.get('action_flow_shift', 5.0)),
    )

    # Create model
    model = MotusWanVlmDirectMask(model_config)

    logger.info(f"Gradient checkpointing: {model_config.gradient_checkpointing}")
    logger.info(f"VLM causal attention: {model_config.vlm_causal_attention} (False=legacy bidirectional)")

    # Optimizer - parameter groups for separate learning rates
    base_lr = float(config.training.learning_rate)
    wan_lr = float(getattr(config.training, 'wan_learning_rate', base_lr))
    vlm_lr = float(getattr(config.training, 'vlm_learning_rate', base_lr))

    # Collect parameters by group
    wan_params = [p for p in model.video_model.wan_model.parameters() if p.requires_grad]
    vlm_params = [p for p in model.vlm_model.parameters() if p.requires_grad]
    all_trainable = [p for p in model.parameters() if p.requires_grad]

    # Get IDs for filtering
    wan_param_ids = {id(p) for p in wan_params}
    vlm_param_ids = {id(p) for p in vlm_params}

    # Other params are Action Expert + Qwen3 Module (projections)
    other_params = [p for p in all_trainable if id(p) not in wan_param_ids and id(p) not in vlm_param_ids]

    param_groups = []
    if len(other_params) > 0:
        param_groups.append({'params': other_params, 'lr': base_lr, 'name': 'main'})
    if len(wan_params) > 0:
        param_groups.append({'params': wan_params, 'lr': wan_lr, 'name': 'wan'})
    if len(vlm_params) > 0:
        param_groups.append({'params': vlm_params, 'lr': vlm_lr, 'name': 'vlm'})

    optimizer = torch.optim.AdamW(
        param_groups,
        weight_decay=config.training.weight_decay,
        betas=(0.9, 0.95)
    )

    # Scheduler
    scheduler = create_scheduler(optimizer, config)

    return model, optimizer, scheduler


def create_dataloaders(config: OmegaConf, rank: int, world_size: int) -> tuple:
    """Create train and validation dataloaders from config."""
    train_dataset = create_dataset(config, val=False)
    val_dataset = create_dataset(config, val=True)

    # Samplers
    if world_size > 1:
        train_sampler = DistributedSampler(train_dataset, num_replicas=world_size, rank=rank)
        val_sampler = DistributedSampler(val_dataset, num_replicas=world_size, rank=rank)
    else:
        train_sampler = None
        val_sampler = None

    # Dataloaders.
    # The training loop restarts the iterator on every StopIteration, which for
    # these small episode-sampled datasets happens every few steps.  Without
    # persistent_workers that tears down and re-forks num_workers processes per
    # rank each time, which on 8 ranks costs seconds per step and leaves the
    # GPUs idle.  Persistent workers also keep the prefetch queue warm.
    num_workers = int(config.system.num_workers)
    loader_kwargs: Dict[str, Any] = dict(
        num_workers=num_workers,
        pin_memory=bool(config.system.pin_memory),
        collate_fn=collate_fn,
        persistent_workers=num_workers > 0,
    )
    if num_workers > 0:
        loader_kwargs["prefetch_factor"] = int(config.system.get("prefetch_factor", 4))

    train_dataloader = DataLoader(
        train_dataset,
        batch_size=config.training.batch_size,
        shuffle=(train_sampler is None),
        sampler=train_sampler,
        drop_last=True,
        **loader_kwargs,
    )

    val_dataloader = None
    if val_dataset is not None:
        val_dataloader = DataLoader(
            val_dataset,
            batch_size=config.training.batch_size,
            shuffle=False,
            sampler=val_sampler,
            drop_last=False,
            **loader_kwargs,
        )

    return train_dataloader, val_dataloader


def main():
    parser = argparse.ArgumentParser(description="Train MotusWanVlmDirect (WAN + Action + VLM Direct MoT)")

    # Configuration file
    parser.add_argument("--config", type=str, required=True,
                       default="configs/robotwin_wan_vlm.yaml",
                       help="Path to configuration file")

    # System settings
    parser.add_argument("--checkpoint_dir", type=str, default=None, help="Override checkpoint directory")
    parser.add_argument("--log_level", type=str, default="INFO", help="Logging level")
    parser.add_argument("--max_steps", type=int, default=None, help="Override max_steps")

    # Logging settings
    parser.add_argument("--report_to", type=str, default=None,
                       choices=["wandb", "tensorboard", "all", "none"],
                       help="Logging backends to use")
    parser.add_argument("--wandb_project", type=str, default=None, help="Override WandB project name")
    parser.add_argument("--run_name", type=str, default=None, help="Override run name")

    # Resume settings
    parser.add_argument("--resume", type=str, default=None, help="Resume from checkpoint")
    parser.add_argument("--reset_scheduler", action="store_true", help="Reset scheduler when resuming")
    parser.add_argument(
        "--init_weights",
        type=str,
        default=None,
        help=(
            "Initialize model weights from a checkpoint directory/file while "
            "starting optimizer, scheduler, and global step from zero"
        ),
    )

    # DeepSpeed settings
    parser.add_argument("--deepspeed", type=str, default=None, help="Path to DeepSpeed config file")
    parser.add_argument("--local_rank", type=int, default=-1, help="Local rank for distributed training")

    args = parser.parse_args()
    if args.resume and args.init_weights:
        parser.error("--resume and --init_weights are mutually exclusive")

    # Load configuration
    config = load_config(args.config)
    if args.checkpoint_dir is not None:
        config.system.checkpoint_dir = args.checkpoint_dir
    if args.report_to is not None:
        config.logging.report_to = args.report_to
    if args.wandb_project is not None:
        config.logging.wandb_project = args.wandb_project
    if args.run_name is not None:
        config.logging.run_name = args.run_name
    if args.max_steps is not None:
        config.training.max_steps = args.max_steps
    if args.resume:
        config.resume.checkpoint_path = args.resume

    # Decide backbone loading policy
    try:
        if (args.init_weights or
            getattr(config.resume, 'checkpoint_path', None) or
            (hasattr(config, 'finetune') and getattr(config.finetune, 'checkpoint_path', None))):
            config.model.load_pretrained_backbones = False
    except Exception:
        pass

    # Extract dataset name from config file path for checkpoint organization
    config_filename = os.path.basename(args.config)
    dataset_name = os.path.splitext(config_filename)[0]

    # Update checkpoint directory to include dataset name
    base_checkpoint_dir = config.system.checkpoint_dir
    config.system.checkpoint_dir = os.path.join(base_checkpoint_dir, dataset_name)

    # Create the dataset directory
    os.makedirs(config.system.checkpoint_dir, exist_ok=True)

    # Determine log_with for Accelerator (it doesn't accept "none")
    _log_with = config.logging.get('report_to', 'tensorboard')
    if _log_with == "none":
        _log_with = None

    # Initialize Accelerator
    accelerator_project_config = ProjectConfiguration(total_limit=20)
    accelerator = Accelerator(
        deepspeed_plugin=DeepSpeedPlugin(
            hf_ds_config=args.deepspeed
        ) if args.deepspeed is not None else None,
        gradient_accumulation_steps=config.training.get('gradient_accumulation_steps', 1),
        mixed_precision="bf16",
        log_with=_log_with,
        project_dir=config.system.checkpoint_dir,
        project_config=accelerator_project_config,
    )

    rank = accelerator.process_index
    world_size = accelerator.num_processes

    # Setup logging with file handler
    train_logs_dir = os.path.join(config.system.checkpoint_dir, config.logging.tensorboard_log_dir, train_start_timestamp)
    setup_logging(rank, config.system.log_level if hasattr(config.system, 'log_level') else args.log_level, train_logs_dir)
    copied_path = copy_config_to_logdir(args.config, train_logs_dir)
    logger.info(f"Config File: {copied_path}")

    # Handle report_to settings
    report_to = config.logging.report_to
    if report_to == "all":
        report_to = ["wandb", "tensorboard"]
    elif report_to == "none":
        report_to = []
    elif isinstance(report_to, str):
        report_to = [report_to]

    # Create run name with timestamp
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_name = config.logging.get('run_name', None)
    if not run_name:
        run_name = f"motus_wan_vlm_{config.dataset.type}_bs{config.training.batch_size}_lr{config.training.learning_rate}"

    # Update checkpoint directory to include run name
    config.system.checkpoint_dir = os.path.join(config.system.checkpoint_dir, run_name)
    logger.info(f"Dataset: {dataset_name}")
    logger.info(f"Checkpoints will be saved to: {config.system.checkpoint_dir}")

    # Initialize TensorBoard writer (MultiSummaryWriter for primary + secondary sync)
    tb_writer = None
    if rank == 0 and "tensorboard" in report_to:
        tb_log_dirs = [train_logs_dir]
        secondary_tb_dir = config.logging.get('secondary_tensorboard_dir', None)
        if secondary_tb_dir:
            tb_log_dirs.append(secondary_tb_dir)
            logger.info(f"TensorBoard secondary sync path: {secondary_tb_dir}")
        tb_writer = MultiSummaryWriter(log_dirs=tb_log_dirs)
        logger.info(f"TensorBoard logs will be saved to: {tb_log_dirs}")
        config_dict = OmegaConf.to_container(config, resolve=True)
        tb_writer.add_text('config', yaml.dump(config_dict))

    # Initialize WandB
    if rank == 0 and "wandb" in report_to:
        wandb.init(
            project=config.logging.wandb_project,
            config=OmegaConf.to_container(config, resolve=True),
            name=run_name,
        )

    try:
        # Create model and optimizer
        logger.info("Creating MotusWanVlmDirect model and optimizer...")
        model, optimizer, scheduler = create_model_and_optimizer(config)

        # Fresh training run initialized from model weights only. This must
        # happen before accelerator.prepare() and never restores training state.
        if args.init_weights:
            logger.info(
                "Initializing model weights from %s; optimizer/scheduler/global_step "
                "will start from zero",
                args.init_weights,
            )
            load_report = model.load_initial_weights(args.init_weights)
            logger.info(
                "Initial weight compatibility: %.2f%% parameters loaded",
                load_report["loaded_parameter_ratio"] * 100,
            )

        # Optional: load finetune weights for partial init
        finetune_ckpt = getattr(config.finetune, 'checkpoint_path', None) if hasattr(config, 'finetune') else None
        if (
            not args.init_weights
            and getattr(config.model, 'training_mode', 'finetune') == 'finetune'
            and finetune_ckpt
        ):
            logger.info(f"Loading finetune weights from {finetune_ckpt} (partial)...")
            try:
                model.load_pretrain_weights(finetune_ckpt)
                logger.info("Finetune weights loaded (partial).")
            except Exception as e:
                logger.error(f"Failed to load finetune weights: {e}")

        # Create dataloaders
        logger.info("Creating dataloaders...")
        import time as _time
        _dl_start = _time.time()
        train_dataloader, val_dataloader = create_dataloaders(config, rank, world_size)
        _dl_elapsed = _time.time() - _dl_start
        logger.info(f"Dataloader creation took {_dl_elapsed:.1f}s (storage_mode={config.dataset.get('storage_mode', 'local')})")

        # Log dataset sizes
        train_dataset = train_dataloader.dataset
        if hasattr(train_dataset, "get_dataset_info"):
            info = train_dataset.get_dataset_info()
            logger.info(f"Multi-dataset training: {info['num_datasets']} datasets")
            for i, (w, l) in enumerate(zip(info['weights'], info['lengths'])):
                logger.info(f"  Dataset {i}: weight={w}, samples={l}")
            logger.info(f"  Total training samples: {info['total_length']}")
        else:
            logger.info(f"Training dataset samples: {len(train_dataset)}")
        if hasattr(train_dataset, "get_task_sampling_info"):
            sampling_info = train_dataset.get_task_sampling_info()
            logger.info(
                "Expected task sampling distribution: %s",
                ", ".join(
                    f"{task_name}={probability:.3%}"
                    for task_name, probability in sorted(
                        sampling_info["weights"].items(),
                        key=lambda item: (-item[1], item[0]),
                    )
                ),
            )

        # Synchronize all ranks before accelerator.prepare()

        # --- Debug / Sanity Check: log first batch action statistics ---
        # Only on rank 0 to avoid clutter
        if rank == 0:
            try:
                _debug_iter = iter(train_dataloader)
                _debug_batch = next(_debug_iter)
                if _debug_batch is not None:
                    _act = _debug_batch.get("action_sequence")
                    _mask = _debug_batch.get("action_valid_mask")
                    _state = _debug_batch.get("initial_state")
                    action_mode = config.dataset.get("action_mode", "unknown")
                    logger.info("=== First Batch Debug / Sanity Check ===")
                    logger.info(f"  action_mode: {action_mode}")
                    logger.info(f"  action_sequence shape: {_act.shape if _act is not None else 'None'}")
                    if _state is not None:
                        logger.info(f"  initial_state shape: {_state.shape}")
                    if _mask is not None:
                        logger.info(f"  action_valid_mask shape: {_mask.shape}")

                    if _act is not None:
                        _act_np = _act.float().numpy()
                        _has_nan = np.any(np.isnan(_act_np))
                        _has_inf = np.any(np.isinf(_act_np))
                        logger.info(f"  action has NaN: {_has_nan}, has Inf: {_has_inf}")

                        # Per-dim statistics for unified_eef_camera_delta_wrist16
                        if action_mode == "unified_eef_camera_delta_wrist16":
                            # Compute masked statistics (only over valid effective dims)
                            if _mask is not None:
                                _mask_np = _mask.float().numpy()
                                _masked_act = _act_np * _mask_np
                                _n_valid = _mask_np.sum().clip(min=1.0)
                                logger.info(f"  masked action mean: {(_masked_act.sum() / _n_valid):.6f}")
                                # Use masked arrays for per-dim stats so invalid
                                # entries (reserved dims, missing hands) are
                                # excluded from mean/std.
                                _left_mask = _mask_np[:, :, 0:6]
                                _right_mask = _mask_np[:, :, 8:14]
                                _left_eff = _act_np[:, :, 0:6]
                                _right_eff = _act_np[:, :, 8:14]
                                # Masked mean/std: only count where mask == 1
                                _left_valid = _left_mask.sum().clip(min=1.0)
                                _right_valid = _right_mask.sum().clip(min=1.0)
                                logger.info(f"  left_delta_xyz mean: {(_left_eff[:, :, :3] * _left_mask[:, :, :3]).sum() / _left_mask[:, :, :3].sum().clip(min=1.0):.6f}, "
                                            f"std: {(np.sqrt(((_left_eff[:, :, :3] - (_left_eff[:, :, :3] * _left_mask[:, :, :3]).sum() / _left_mask[:, :, :3].sum().clip(min=1.0))**2) * _left_mask[:, :, :3]).sum() / _left_mask[:, :, :3].sum().clip(min=1.0)):.6f}")
                                logger.info(f"  left_delta_rotvec mean: {(_left_eff[:, :, 3:6] * _left_mask[:, :, 3:6]).sum() / _left_mask[:, :, 3:6].sum().clip(min=1.0):.6f}")
                                logger.info(f"  right_delta_xyz mean: {(_right_eff[:, :, :3] * _right_mask[:, :, :3]).sum() / _right_mask[:, :, :3].sum().clip(min=1.0):.6f}")
                                logger.info(f"  right_delta_rotvec mean: {(_right_eff[:, :, 3:6] * _right_mask[:, :, 3:6]).sum() / _right_mask[:, :, 3:6].sum().clip(min=1.0):.6f}")
                            else:
                                _masked_act = _act_np
                                left_eff = _act_np[:, :, 0:6]
                                right_eff = _act_np[:, :, 8:14]
                                logger.info(f"  left_delta_xyz mean: {left_eff[:, :, :3].mean():.6f}, std: {left_eff[:, :, :3].std():.6f}")
                                logger.info(f"  left_delta_rotvec mean: {left_eff[:, :, 3:6].mean():.6f}, std: {left_eff[:, :, 3:6].std():.6f}")
                                logger.info(f"  right_delta_xyz mean: {right_eff[:, :, :3].mean():.6f}, std: {right_eff[:, :, :3].std():.6f}")
                                logger.info(f"  right_delta_rotvec mean: {right_eff[:, :, 3:6].mean():.6f}, std: {right_eff[:, :, 3:6].std():.6f}")

                            # Check rotvec range
                            if _mask is not None:
                                _left_rotvec = _act_np[:, :, 3:6][_mask_np[:, :, 3:6] > 0]
                                _right_rotvec = _act_np[:, :, 11:14][_mask_np[:, :, 11:14] > 0]
                                left_rotvec_max = np.abs(_left_rotvec).max() if _left_rotvec.size > 0 else 0.0
                                right_rotvec_max = np.abs(_right_rotvec).max() if _right_rotvec.size > 0 else 0.0
                            else:
                                left_rotvec_max = np.abs(_act_np[:, :, 3:6]).max()
                                right_rotvec_max = np.abs(_act_np[:, :, 11:14]).max()
                            logger.info(f"  left_rotvec max abs: {left_rotvec_max:.4f} (should be <= pi~3.14)")
                            logger.info(f"  right_rotvec max abs: {right_rotvec_max:.4f}")
                            if left_rotvec_max > np.pi + 0.1 or right_rotvec_max > np.pi + 0.1:
                                logger.warning(f"  *** Rotvec values exceed pi! This may indicate an issue. ***")

                            # Reserved dims should be all zero
                            # For robot data with gripper: reserved dims are [7] and [15]
                            # For human data: reserved dims are [6:8] and [14:16]
                            dataset_type = config.dataset.get('type', 'unknown')
                            if dataset_type == 'robotwin':
                                reserved = np.concatenate([_act_np[:, :, 7:8], _act_np[:, :, 15:16]], axis=-1)
                                # Log gripper statistics for robot data
                                left_grip = _act_np[:, :, 6]
                                right_grip = _act_np[:, :, 14]
                                logger.info(f"  left_gripper range: [{left_grip.min():.4f}, {left_grip.max():.4f}], "
                                            f"mean: {left_grip.mean():.4f}")
                                logger.info(f"  right_gripper range: [{right_grip.min():.4f}, {right_grip.max():.4f}], "
                                            f"mean: {right_grip.mean():.4f}")
                            else:
                                reserved = np.concatenate([_act_np[:, :, 6:8], _act_np[:, :, 14:16]], axis=-1)
                            logger.info(f"  reserved dims all zero: {np.allclose(reserved, 0)}")
                            if not np.allclose(reserved, 0):
                                logger.warning(f"  *** Reserved dims are not zero! max abs: {np.abs(reserved).max():.6f} ***")

                        elif action_mode == "qpos_unified_eef_combined32":
                            # 32D = padded abs qpos [0:16] || unified EEF [16:32]
                            qpos_block = _act_np[:, :, 0:16]
                            eef_block = _act_np[:, :, 16:32]
                            logger.info(f"  qpos block shape: {qpos_block.shape}, eef block shape: {eef_block.shape}")
                            logger.info(
                                f"  qpos L/R grip ranges: "
                                f"[{qpos_block[:, :, 6].min():.4f}, {qpos_block[:, :, 6].max():.4f}] / "
                                f"[{qpos_block[:, :, 14].min():.4f}, {qpos_block[:, :, 14].max():.4f}]"
                            )
                            logger.info(
                                f"  eef L/R grip ranges: "
                                f"[{eef_block[:, :, 6].min():.4f}, {eef_block[:, :, 6].max():.4f}] / "
                                f"[{eef_block[:, :, 14].min():.4f}, {eef_block[:, :, 14].max():.4f}]"
                            )
                            left_rotvec_max = np.abs(eef_block[:, :, 3:6]).max()
                            right_rotvec_max = np.abs(eef_block[:, :, 11:14]).max()
                            logger.info(f"  eef left_rotvec max abs: {left_rotvec_max:.4f} (should be <= pi~3.14)")
                            logger.info(f"  eef right_rotvec max abs: {right_rotvec_max:.4f}")
                            reserved = np.concatenate(
                                [
                                    _act_np[:, :, 7:8],
                                    _act_np[:, :, 15:16],
                                    _act_np[:, :, 23:24],
                                    _act_np[:, :, 31:32],
                                ],
                                axis=-1,
                            )
                            logger.info(f"  reserved dims [7,15,23,31] all zero: {np.allclose(reserved, 0)}")
                            if not np.allclose(reserved, 0):
                                logger.warning(
                                    f"  *** Reserved dims are not zero! max abs: {np.abs(reserved).max():.6f} ***"
                                )
                            if _mask is not None:
                                _mask_np = _mask.float().numpy()
                                expected_zero = _mask_np[:, :, [7, 15, 23, 31]]
                                logger.info(
                                    f"  reserved mask all zero: {np.allclose(expected_zero, 0)}, "
                                    f"effective mask mean: {_mask_np.mean():.4f}"
                                )

                    if _mask is not None:
                        _mask_np = _mask.float().numpy()
                        # For unified_eef, compute left/right valid ratios
                        if action_mode == "unified_eef_camera_delta_wrist16":
                            # Left valid: any of dims 0:6 has mask=1
                            left_valid_ratio = (_mask_np[:, :, 0:6].any(axis=-1)).mean()
                            right_valid_ratio = (_mask_np[:, :, 8:14].any(axis=-1)).mean()
                            logger.info(f"  left valid frame ratio: {left_valid_ratio:.4f}")
                            logger.info(f"  right valid frame ratio: {right_valid_ratio:.4f}")

                            # Check if camera extrinsics are used
                            logger.info(f"  require_camera_extrinsics: {config.dataset.get('require_camera_extrinsics', 'N/A')}")
                            logger.info(f"  allow_base_relative_fallback: {config.dataset.get('allow_base_relative_fallback', 'N/A')}")
                        elif action_mode == "qpos_unified_eef_combined32":
                            left_valid_ratio = (_mask_np[:, :, 16:22].any(axis=-1)).mean()
                            right_valid_ratio = (_mask_np[:, :, 24:30].any(axis=-1)).mean()
                            logger.info(f"  eef left valid frame ratio: {left_valid_ratio:.4f}")
                            logger.info(f"  eef right valid frame ratio: {right_valid_ratio:.4f}")

                    # Log Xperience-specific stats if available
                    _task_names = _debug_batch.get("task_names")
                    if _task_names is not None:
                        from collections import Counter
                        name_counts = Counter(str(n) for n in _task_names if n is not None)
                        logger.info(f"  task_names in batch: {dict(name_counts)}")

                    logger.info("=== End First Batch Debug ===")
                del _debug_batch
            except Exception as e:
                logger.warning(f"First batch debug check failed: {e}")
                import traceback
                logger.warning(traceback.format_exc())
        logger.info("Waiting for all ranks to complete data loading...")
        accelerator.wait_for_everyone()
        logger.info("All ranks synchronized, proceeding to accelerator.prepare()")

        # Release the global T5 encoder singleton to free ~9.4 GB GPU memory.
        # In disk_cache mode, T5 is only needed during dataset __init__ for
        # caching text embeddings.  Once all datasets are initialized, we can
        # safely release it before model creation and training begin.
        try:
            from data import release_global_t5_encoder
            release_global_t5_encoder()
            logger.info("[Main] Released global T5 encoder before accelerator.prepare()")
        except Exception as _t5_rel_err:
            logger.warning(f"[Main] Failed to release global T5 encoder: {_t5_rel_err}")

        # Create custom saving hook to avoid NCCL timeout issues
        def save_model_hook(models, weights, output_dir):
            """Custom save hook to save model safely and avoid NCCL timeouts."""
            if accelerator.is_main_process:
                logger.info(f"Saving model to {output_dir}")
                for i, model_to_save in enumerate(models):
                    # Unwrap the model if it's wrapped by DDP/DeepSpeed
                    unwrapped_model = accelerator.unwrap_model(model_to_save)

                    # Save using torch.save instead of accelerator's default method
                    model_save_path = os.path.join(output_dir, f"pytorch_model_{i}.bin")
                    torch.save(unwrapped_model.state_dict(), model_save_path)
                    logger.info(f"Model {i} saved to {model_save_path}")

        # Register the custom save hook
        accelerator.register_save_state_pre_hook(save_model_hook)

        # Prepare with accelerator
        logger.info("Preparing model, optimizer, and dataloader with Accelerator...")
        model, optimizer, train_dataloader, scheduler = accelerator.prepare(
            model, optimizer, train_dataloader, scheduler
        )

        # Re-attach file handler if Accelerate/DeepSpeed removed it
        if rank == 0:
            root_logger = logging.getLogger()
            has_file_handler = any(isinstance(h, logging.FileHandler) for h in root_logger.handlers)
            if not has_file_handler and os.path.isdir(train_logs_dir):
                class _FlushFileHandler(logging.FileHandler):
                    def emit(self, record):
                        super().emit(record)
                        self.flush()
                fh = _FlushFileHandler(os.path.join(train_logs_dir, "train.log"), mode="a")
                fh.setFormatter(logging.Formatter(
                    f'[Rank {rank}] %(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    datefmt='%Y-%m-%d %H:%M:%S'
                ))
                root_logger.addHandler(fh)
                logger.info("Re-attached file handler after accelerator.prepare()")

        # Create trainer
        trainer = MotusWanVlmTrainer(
            model=model,
            train_dataloader=train_dataloader,
            val_dataloader=val_dataloader,
            optimizer=optimizer,
            scheduler=scheduler,
            device=accelerator.device,
            rank=rank,
            world_size=world_size,
            checkpoint_dir=config.system.checkpoint_dir,
            log_interval=config.system.log_interval,
            save_interval=config.system.save_interval,
            val_interval=config.system.val_interval,
            report_to=report_to,
            tb_writer=tb_writer,
            accelerator=accelerator,
            config=config,
        )

        # Start training
        trainer.train(
            max_steps=config.training.max_steps,
            resume_from=args.resume,
            reset_scheduler=args.reset_scheduler
        )

    except Exception as e:
        logger.error(f"Training failed: {e}")
        import traceback
        logger.error("Full traceback:")
        logger.error(traceback.format_exc())
        print(f"[CRITICAL ERROR] Training failed: {e}")
        print("Full traceback:")
        traceback.print_exc()
        raise

    finally:
        # Clean up resources
        if torch.distributed.is_initialized():
            torch.distributed.destroy_process_group()
        if rank == 0 and "wandb" in report_to:
            wandb.finish()
        if tb_writer is not None:
            tb_writer.close()


if __name__ == "__main__":
    main()

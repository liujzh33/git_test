"""Shared layout and delta conventions for the G1-D Cartesian action modes.

Both the offline converter (tools/g1_qpos_to_eef.py, which needs pinocchio) and
the dataset (which must not) import this, so the two cannot drift apart on what
"delta" means. Only numpy and scipy are required here.

16-dim layout, two symmetric 8-dim per-arm blocks:
    [xyz(3), rotvec(3), reserved(1), gripper(1)]

Grippers sit at dims 7/15 to match the qpos layout used by the pretrained
checkpoint; dims 6/14 carry no signal and are masked out of the loss.
"""

import random
from typing import Any, List, Optional

import numpy as np
from scipy.spatial.transform import Rotation

ARM_BASES = (0, 8)
XYZ_SLICES = tuple(slice(b, b + 3) for b in ARM_BASES)
ROT_SLICES = tuple(slice(b + 3, b + 6) for b in ARM_BASES)
RESERVED_DIMS = (6, 14)
GRIPPER_DIMS = (7, 15)
ACTION_DIM = 16


EPISODE_SUBSETS = ("all", "train", "val")


def select_episodes(
    episodes: List[Any],
    max_episodes: Optional[int],
    seed: Optional[int],
    subset: str = "all",
) -> List[Any]:
    """Cap an episode list, or split it into disjoint train/val halves.

    ``subset="all"`` keeps the repo's existing behaviour: first N, or a seeded
    draw of N when a seed is given.

    ``"train"`` / ``"val"`` return the two sides of one seeded draw of
    ``max_episodes``. They partition the list, so an episode used for training is
    never available for validation. Both need a seed: without one the two calls
    would have no shared basis to be complementary.
    """
    if subset not in EPISODE_SUBSETS:
        raise ValueError(f"subset must be one of {EPISODE_SUBSETS}, got {subset!r}")
    if subset == "all":
        if not max_episodes or max_episodes <= 0 or len(episodes) <= max_episodes:
            return episodes
        if seed is None:
            return episodes[:max_episodes]
        picked = random.Random(seed).sample(range(len(episodes)), int(max_episodes))
        return [episodes[i] for i in sorted(picked)]

    if seed is None:
        raise ValueError(f"subset={subset!r} needs episode_seed so the two sides stay disjoint")
    if not max_episodes or max_episodes <= 0:
        raise ValueError(f"subset={subset!r} needs max_episodes to know where to cut")
    if max_episodes >= len(episodes):
        if subset == "val":
            raise ValueError(
                f"max_episodes={max_episodes} takes all {len(episodes)} episodes for training, "
                f"leaving nothing to validate on"
            )
        return episodes
    train = set(random.Random(seed).sample(range(len(episodes)), int(max_episodes)))
    keep = train if subset == "train" else set(range(len(episodes))) - train
    return [episodes[i] for i in sorted(keep)]


def to_delta(cond: np.ndarray, targets: np.ndarray) -> np.ndarray:
    """Express absolute EEF poses relative to a condition-frame pose.

    Translation is rotated into the condition frame's own EEF frame rather than
    differenced in the report frame, so the result reads as "move this far along
    my own axes" and is invariant to where the arm happens to be pointing.
    Rotation composes on SO(3); subtracting rotation vectors would be wrong.

    Gripper dims pass through as absolute values -- a difference of opening
    amounts has no useful meaning.

    Args:
        cond: Absolute 16-dim pose at the condition frame.
        targets: Absolute 16-dim poses, shape (T, 16).

    Returns:
        (T, 16) delta actions in the same slot layout.
    """
    cond = np.asarray(cond, dtype=np.float64)
    targets = np.asarray(targets, dtype=np.float64)
    out = np.zeros_like(targets)
    for xyz, rot in zip(XYZ_SLICES, ROT_SLICES):
        r_cond = Rotation.from_rotvec(cond[rot])
        r_inv = r_cond.inv()
        out[:, xyz] = r_inv.apply(targets[:, xyz] - cond[xyz])
        out[:, rot] = (r_inv * Rotation.from_rotvec(targets[:, rot])).as_rotvec()
    for g in GRIPPER_DIMS:
        out[:, g] = targets[:, g]
    return out


def from_delta(cond: np.ndarray, deltas: np.ndarray) -> np.ndarray:
    """Inverse of :func:`to_delta`, for turning model output back into targets."""
    cond = np.asarray(cond, dtype=np.float64)
    deltas = np.asarray(deltas, dtype=np.float64)
    out = np.zeros_like(deltas)
    for xyz, rot in zip(XYZ_SLICES, ROT_SLICES):
        r_cond = Rotation.from_rotvec(cond[rot])
        out[:, xyz] = r_cond.apply(deltas[:, xyz]) + cond[xyz]
        out[:, rot] = (r_cond * Rotation.from_rotvec(deltas[:, rot])).as_rotvec()
    for g in GRIPPER_DIMS:
        out[:, g] = deltas[:, g]
    return out


def delta_stats(abs_poses: np.ndarray, episode_ids: np.ndarray, horizon: int):
    """Min/max of the delta representation over every (condition, target) pair.

    Walks each horizon 1..`horizon` within episode boundaries, which is exactly
    the set of pairs the sampler can produce for an action chunk of that length.
    """
    lo = np.full(ACTION_DIM, np.inf)
    hi = np.full(ACTION_DIM, -np.inf)
    for ep in np.unique(episode_ids):
        p = abs_poses[episode_ids == ep].astype(np.float64)
        if len(p) < 2:
            continue
        for h in range(1, min(horizon, len(p) - 1) + 1):
            d = _delta_pairs(p[:-h], p[h:])
            lo = np.minimum(lo, d.min(axis=0))
            hi = np.maximum(hi, d.max(axis=0))
    for d in RESERVED_DIMS:
        lo[d], hi[d] = 0.0, 1.0
    return lo, hi


def delta_moments(abs_poses: np.ndarray, episode_ids: np.ndarray, horizon: int):
    """Mean and std of the delta representation over the same pairs as
    :func:`delta_stats`.

    Standardising with these puts the training targets at zero mean and unit
    variance, which is the scale a flow-matching head's N(0, 1) prior expects.
    Min-max to [0, 1] instead leaves them at std ~0.17, a ~10x compression
    against the raw joint targets the repo's working configurations use.
    """
    total = np.zeros(ACTION_DIM)
    total_sq = np.zeros(ACTION_DIM)
    count = 0
    for ep in np.unique(episode_ids):
        p = abs_poses[episode_ids == ep].astype(np.float64)
        if len(p) < 2:
            continue
        for h in range(1, min(horizon, len(p) - 1) + 1):
            d = _delta_pairs(p[:-h], p[h:])
            total += d.sum(axis=0)
            total_sq += (d ** 2).sum(axis=0)
            count += len(d)
    if count == 0:
        return np.zeros(ACTION_DIM), np.ones(ACTION_DIM)
    mean = total / count
    std = np.sqrt(np.maximum(total_sq / count - mean ** 2, 0.0))
    # Reserved dims are constant zero: keep them at zero with a unit scale so
    # standardising leaves them untouched rather than dividing by ~0.
    for d in RESERVED_DIMS:
        mean[d], std[d] = 0.0, 1.0
    std[std < 1e-8] = 1.0
    return mean, std


def _delta_pairs(conds: np.ndarray, targets: np.ndarray) -> np.ndarray:
    """Vectorised :func:`to_delta` over paired rows."""
    out = np.zeros_like(targets)
    for xyz, rot in zip(XYZ_SLICES, ROT_SLICES):
        r_inv = Rotation.from_rotvec(conds[:, rot]).inv()
        out[:, xyz] = r_inv.apply(targets[:, xyz] - conds[:, xyz])
        out[:, rot] = (r_inv * Rotation.from_rotvec(targets[:, rot])).as_rotvec()
    for g in GRIPPER_DIMS:
        out[:, g] = targets[:, g]
    return out

"""G1-D (Unitree G1 Dex1) LeRobot v3.0 dataset adapter for MotusV2."""

from .g1d_dataset import G1DLeRobotDataset

__all__ = ["G1DLeRobotDataset"]

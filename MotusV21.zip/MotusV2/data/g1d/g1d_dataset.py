"""G1-D (Unitree G1 Dex1) LeRobot v3.0 dataset adapter for MotusV2 post-training.

This dataset reads the self-collected ``pick-kettle-and-cup`` LeRobot-format
dataset at ``/cache/wx1469573/data/G1-D/pick-kettle-and-cup`` and produces
Motus-compatible training samples (same contract as ``DroidLeRobotDataset``):

    first_frame:        [C, H, W]               (condition frame, T-shape stitched)
    video_frames:       [T, C, H, W]           (target video frames)
    initial_state:      [16]                   (7+7 joints + 2 grippers, qpos)
    action_sequence:    [chunk, 16]            (7+7 joints + 2 grippers, qpos)
    language_embedding: [S, 4096]           (UMT5-XXL for WAN cross-attn)
    vlm_inputs:         dict                 (Qwen3-VL processor output)
    task_name:          str

Action / state schema (16-dim absolute joint-position target, qpos):
    Dex1 16-dim raw layout (pick-kettle info.json): [L7, R7, LG, RG]
    (grippers at dims 14/15).
    G1D-mobile 19-dim action / 23-dim state (pour-beans info.json):
        [L7, R7, HighLift, MoveX, MoveYaw, LG, RG]  (+ 4 base pose dims on state).
    Those extra chassis / lift dims are dropped so both robots share the same
    16-dim manipulation qpos; grippers are taken from indices 17/18.
    This dataset then REORDERS the Dex1-raw 16-vector to the per-arm layout
    [L7, LG, R7, RG]  (grippers at dims 7/15), matching the per-arm structure
    of ``unify_action_to_16`` in multi_source_pretrain_dataset:
        new[0:7]  = old[0:7]   # kLeftShoulderPitch..kLeftWristYaw
        new[7]    = old[14]    # kLeftGripper
        new[8:15] = old[7:14]  # kRightShoulderPitch..kRightWristYaw
        new[15]   = old[15]    # kRightGripper
    Joints 0..6 / 8..14 are in radians; grippers 7 / 15 are continuous
    (~1.95..5.45).  No normalization is applied (raw qpos), matching the
    DROID / RoboTwin stage-2 setting.

Cameras (T-shape stitch into a single WAN video stream):
    observation.images.cam_left_high    -> top         (full width)
    observation.images.cam_left_wrist   -> bottom-left  (half width)
    observation.images.cam_right_wrist  -> bottom-right (half width)
    (observation.images.cam_right_high is unused.)

    ``stitch_mode="aspect"`` (default) uses the aspect-ratio-preserving
    single-resize T-shape, matching ``DroidLeRobotDataset._stitch_t_shape``:
    frames are decoded at native resolution and resized ONCE into their
    sub-region, then the T canvas is vertically center-padded to ``video_size``.
    For G1-D's 4:3 cameras (480x640) at 384x320 this gives

        top    : 240 x 320   (cam_left_high, full width, no padding at all)
        bottom : 120 x 160   (each wrist, half width, no padding)
        natural height = 360 -> 12px pad at the very top and bottom

    which is 93.8% real pixels.  320 is the canvas width, so 240x320 is the
    largest ``cam_left_high`` can possibly be without distorting it.

    ``stitch_mode="legacy"`` reproduces the old ``has_three_cam`` double
    resize (each camera resize-padded to the full ``video_size`` first, then
    re-resized into a fixed 50/50 top/bottom split).  That wasted 53.1% of the
    canvas on black padding and shrank cam_left_high to 120x160 -- a quarter of
    the area it gets now -- so it is kept only to serve checkpoints trained
    before the switch.  See ``docs/changelog_vs_main/review_20260709.md``
    (finding B2), which flagged this as the known cost of the legacy stitch.

The dataset is self-contained: it reads parquet frames directly (pandas) and
decodes AV1 video with PyAV, so it does NOT depend on the ``lerobot`` runtime
library.  Task text comes from ``meta/tasks.parquet`` (task_index -> task),
not from a per-frame language column.
"""

import os
import json
import random
import logging
import hashlib
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.utils.data as data

# Video decoding via PyAV (AV1 codec, which decord cannot decode)
import av

# Image / VLM utils (shared with other datasets)
from data.utils.image_utils import resize_with_padding
from utils.vlm_utils import preprocess_vlm_messages

# Shared with tools/g1_qpos_to_eef.py so the delta convention cannot drift.
from .eef_actions import select_episodes, to_delta

logger = logging.getLogger(__name__)
try:
    import warnings as _warnings
    _warnings.filterwarnings("ignore", category=FutureWarning, message=".*multichannel.*")
except Exception:
    pass


# Minimum valid mp4 file size.  Real AV1 videos are hundreds of MB; a tiny
# file is a corrupt/truncated placeholder that PyAV cannot open.  1 MB cleanly
# separates them (same threshold as DROID).
_CORRUPT_VIDEO_MIN_BYTES = 1 * 1024 * 1024  # 1 MB

# The T-shape stitch reads three independent mp4 files per sample.  Decoding
# them one after another makes a sample cost 3x one camera; a small per-worker
# pool overlaps them instead.
_DECODE_POOL: Optional[ThreadPoolExecutor] = None


def _camera_decode_pool() -> ThreadPoolExecutor:
    global _DECODE_POOL
    if _DECODE_POOL is None:
        _DECODE_POOL = ThreadPoolExecutor(max_workers=3)
    return _DECODE_POOL


# ---------------------------------------------------------------------------
# PyAV video decoding helper
# ---------------------------------------------------------------------------
def _decode_video_frames_pyav(
    video_path: str,
    frame_indices: List[int],
    fps: float,
) -> np.ndarray:
    """Decode specific frames (by global index within the concatenated mp4).

    G1-D videos are AV1-encoded and concatenated per parquet file (multiple
    episodes share one mp4, see DATASET.md §9).  ``frame_indices`` are global
    frame indices within the mp4, computed as ``start_frame + offset`` where
    ``start_frame`` comes from ``round(from_timestamp * fps)``.

    Returns ``[len(frame_indices), H, W, 3]`` uint8 RGB.  Frames are collected
    by presentation timestamp; seeking jumps to the nearest keyframe before the
    first requested index, then frames are decoded forward.

    A chunk spans ~64 frames but only 9 of them are ever returned, so the
    YUV->RGB conversion is done for wanted indices only and the loop stops as
    soon as they are all in hand.
    """
    if not frame_indices:
        return np.zeros((0, 180, 320, 3), dtype=np.uint8)

    wanted = sorted(set(int(i) for i in frame_indices))
    wanted_set = set(wanted)
    first_wanted = wanted[0]
    last_wanted = wanted[-1]

    container = av.open(str(video_path))
    try:
        stream = container.streams.video[0]
        if stream is None:
            raise ValueError(f"No video stream in {video_path}")
        time_base = float(stream.time_base) if stream.time_base else 1.0

        # Seek to just before the first wanted frame (keyframe-based seek).
        seek_sec = max(0.0, first_wanted / float(fps) - 1.0 / float(fps))
        seek_pts = int(seek_sec / time_base)
        try:
            container.seek(seek_pts, stream=stream)
        except Exception:
            container.seek(0, stream=stream)

        idx_to_arr: Dict[int, np.ndarray] = {}
        last_arr = None
        for frame in container.decode(stream):
            pts = float(frame.pts) * time_base if frame.pts is not None else 0.0
            fidx = int(round(pts * float(fps)))
            if fidx > last_wanted + 2:
                break
            if fidx in wanted_set and fidx not in idx_to_arr:
                arr = frame.to_ndarray(format="rgb24")  # [H, W, 3] uint8
                last_arr = arr
                idx_to_arr[fidx] = arr
                if len(idx_to_arr) == len(wanted_set):
                    break

        if last_arr is None:
            raise ValueError(f"Decoded 0 frames from {video_path}")
        out = []
        for i in frame_indices:
            if i in idx_to_arr:
                out.append(idx_to_arr[i])
            else:
                nearest = min(idx_to_arr.keys(), key=lambda k: abs(k - i)) if idx_to_arr else None
                out.append(idx_to_arr.get(nearest, last_arr) if nearest is not None else last_arr)
        return np.stack(out, axis=0)
    finally:
        container.close()


class _AffineNormalizer:
    """Per-dimension affine scaling, ``(x - offset) / scale``.

    Two constructions, and the choice matters more than it looks. The action
    expert is a flow-matching head whose prior is N(0, 1):

    * ``from_min_max`` maps to [0, 1], the convention data/robotwin2 uses. On the
      G1-D deltas that leaves targets at std ~0.17 against a unit-variance prior.
    * ``from_mean_std`` standardises to zero mean and unit variance, which is the
      scale the prior expects and roughly what the raw joint targets of the
      repo's working configurations already have (std ~1.6).
    """

    def __init__(self, offset: np.ndarray, scale: np.ndarray):
        self.offset = np.asarray(offset, dtype=np.float32)
        self.scale = np.asarray(scale, dtype=np.float32)

    @classmethod
    def from_min_max(cls, vmin, vmax, epsilon: float = 1e-8):
        vmin = np.asarray(vmin, dtype=np.float32)
        return cls(vmin, np.asarray(vmax, dtype=np.float32) - vmin + epsilon)

    @classmethod
    def from_mean_std(cls, mean, std, epsilon: float = 1e-8):
        std = np.asarray(std, dtype=np.float32).copy()
        std[std < epsilon] = 1.0
        return cls(np.asarray(mean, dtype=np.float32), std)

    def normalize(self, x: np.ndarray) -> np.ndarray:
        return (x - self.offset) / self.scale

    def denormalize(self, y: np.ndarray) -> np.ndarray:
        return y * self.scale + self.offset


# ---------------------------------------------------------------------------
# Dataset
# ---------------------------------------------------------------------------
class G1DLeRobotDataset(data.Dataset):
    """MotusV2 dataset for the G1-D pick-kettle-and-cup LeRobot dataset.

    ``action_mode`` picks the 16-dim action/state representation:

    * ``"qpos"`` (default) — joint angles straight from ``observation.state`` /
      ``action``, reordered to ``[L7, LG, R7, RG]``.
    * ``"eef"`` — absolute Cartesian poses from the precomputed ``*.eef``
      columns, laid out as ``[xyz(3), rotvec(3), reserved, gripper]`` per arm.
    * ``"eef_delta"`` — the same poses expressed relative to the condition
      frame. The state stays absolute; only the actions become offsets.

    All three are 16-dim, so the action expert keeps its shape across modes and
    the grippers stay at dims 7/15 either way.
    """

    # G1-D info.json constants
    G1D_FPS = 30
    ACTION_DIM = 16   # 7 left joints + 7 right joints + 2 grippers (qpos)
    STATE_DIM = 16

    # Dimension reorder: Dex1-raw layout is [L7, R7, LG, RG] (grippers at the
    # tail, dims 14/15).  The training target layout interleaves each gripper
    # after its arm: [L7, LG, R7, RG]  ->  new[0:7]=old[0:7], new[7]=old[14],
    # new[8:15]=old[7:14], new[15]=old[15].  This matches the per-arm structure
    # of ``unify_action_to_16`` in multi_source_pretrain_dataset (gripper right
    # after its arm's joints), which matters for cross-dataset joint training.
    _REORDER_FROM_RAW = [0, 1, 2, 3, 4, 5, 6, 14, 7, 8, 9, 10, 11, 12, 13, 15]
    # G1D-mobile (pour-beans) 19-dim action / 23-dim state -> Dex1-raw 16-dim
    # [L7, R7, LG, RG], dropping HighLift / MoveX / MoveYaw / base pose.
    _MOBILE_TO_DEX1_RAW = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 17, 18]

    # The eef modes read Cartesian columns precomputed by
    # tools/g1_qpos_to_eef.py instead, laid out as two 8-dim per-arm blocks of
    # [xyz(3), rotvec(3), reserved(1), gripper(1)].  The grippers stay at dims
    # 7/15 so that dim keeps the same meaning as in qpos mode; dims 6/14 carry no
    # signal and are masked out of the loss.  No reorder applies -- the columns
    # are written in final layout.
    ACTION_MODES = ("qpos", "eef", "eef_delta")
    EEF_STATE_COLUMN = "observation.state.eef"
    EEF_ACTION_COLUMN = "action.eef"
    EEF_RESERVED_DIMS = (6, 14)

    # T-shape camera selection (cam_right_high is intentionally unused).
    TOP_CAM = "observation.images.cam_left_high"
    BOTTOM_LEFT_CAM = "observation.images.cam_left_wrist"
    BOTTOM_RIGHT_CAM = "observation.images.cam_right_wrist"
    _ALL_CAMS = (TOP_CAM, BOTTOM_LEFT_CAM, BOTTOM_RIGHT_CAM)

    def __init__(
        self,
        dataset_dir: str,
        *,
        # Sampling parameters (match RoboTwin stage-2 defaults)
        num_video_frames: int = 8,
        video_size: Tuple[int, int] = (384, 320),
        global_downsample_rate: int = 1,
        video_action_freq_ratio: int = 2,
        max_episodes: Optional[int] = None,
        episode_seed: Optional[int] = None,
        episode_subset: str = "all",
        image_aug: bool = False,
        val: bool = False,
        stitch_mode: str = "aspect",   # "aspect" (single resize) or "legacy" (double resize)
        # Action representation
        action_mode: str = "qpos",     # "qpos" | "eef" | "eef_delta"
        normalization: bool = False,
        normalization_stats_path: Optional[str] = None,
        normalization_mode: str = "standard",
        # VLM processing
        vlm_checkpoint_path: Optional[str] = None,
        vlm_type: str = "qwen3_vl",
        # T5 embedding (UMT5-XXL for WAN cross-attention)
        t5_mode: str = "disk_cache",      # "disk_cache" or "none"
        wan_path: Optional[str] = None,
        t5_cache_dir: str = "./t5_cache_g1d",
        t5_text_len: int = 512,
        t5_device: str = "cuda",
        allow_t5_cache_miss_zero: bool = False,
        **kwargs: Any,
    ) -> None:
        super().__init__()

        self.dataset_dir = str(dataset_dir)
        self.root = Path(dataset_dir)
        self.num_video_frames = int(num_video_frames)
        self.video_size = video_size
        self.global_downsample_rate = int(global_downsample_rate)
        self.video_action_freq_ratio = int(video_action_freq_ratio)
        self.action_chunk_size = self.num_video_frames * self.video_action_freq_ratio
        self.max_episodes = max_episodes
        self.episode_seed = episode_seed
        self.episode_subset = episode_subset
        self.image_aug = bool(image_aug) and not val
        self.val = bool(val)
        if stitch_mode not in ("aspect", "legacy"):
            raise ValueError(f"stitch_mode must be 'aspect' or 'legacy', got {stitch_mode!r}")
        self.stitch_mode = stitch_mode
        if action_mode not in self.ACTION_MODES:
            raise ValueError(f"action_mode must be one of {self.ACTION_MODES}, got {action_mode!r}")
        self.action_mode = action_mode
        self.is_eef = action_mode in ("eef", "eef_delta")
        self.normalization = bool(normalization)
        self.normalization_mode = str(normalization_mode)
        # Separate normalizers because in eef_delta the state stays absolute
        # while the actions are offsets, so the two have different ranges.
        self.state_normalizer, self.action_normalizer = self._load_normalizers(
            normalization_stats_path
        )

        # Load info.json (fps, features)
        self.fps = self.G1D_FPS
        info_path = self.root / "meta" / "info.json"
        if info_path.exists():
            try:
                with open(info_path, "r") as f:
                    info = json.load(f)
                self.fps = float(info.get("fps", self.G1D_FPS))
            except Exception:
                pass
        self.action_dim = self.ACTION_DIM
        self.state_dim = self.STATE_DIM

        # Task text: task_index -> task string (from meta/tasks.parquet).
        # G1-D is single-task, so this maps {0: "拿起水杯和茶壶，并倒水"}.
        self.task_index_to_text: Dict[int, str] = self._load_tasks()

        # Episode index (built from meta/episodes parquet)
        self.episodes: List[Dict[str, Any]] = []
        self._index_episodes()

        if len(self.episodes) == 0:
            raise RuntimeError(
                f"No valid G1-D episodes found in {dataset_dir} "
                f"(checked meta/episodes, data/, and videos/ for {self._ALL_CAMS})"
            )
        self._check_action_columns()
        logger.info(
            f"G1DLeRobotDataset: {len(self.episodes)} episodes indexed "
            f"(fps={self.fps}, chunk={self.action_chunk_size}, ds={self.global_downsample_rate}, "
            f"stitch={self.stitch_mode}, action_mode={self.action_mode}, "
            f"normalization={self.normalization}, subset={self.episode_subset})"
        )

        # Parquet DataFrame cache (LRU-ish: keep last N files)
        self._parquet_cache: Dict[Tuple[int, int], "pd.DataFrame"] = {}
        self._parquet_cache_order: List[Tuple[int, int]] = []
        self._parquet_cache_max = 8

        self._init_text_stack(
            vlm_checkpoint_path=vlm_checkpoint_path,
            vlm_type=vlm_type,
            t5_mode=t5_mode,
            t5_cache_dir=t5_cache_dir,
            t5_text_len=t5_text_len,
            t5_device=t5_device,
            allow_t5_cache_miss_zero=allow_t5_cache_miss_zero,
            wan_path=wan_path,
        )

    def _init_text_stack(
        self,
        *,
        vlm_checkpoint_path: Optional[str],
        vlm_type: str,
        t5_mode: str,
        t5_cache_dir: str,
        t5_text_len: int,
        t5_device: str,
        allow_t5_cache_miss_zero: bool,
        wan_path: Optional[str],
    ) -> None:
        """VLM processor + T5 disk cache. Split out so EgoRetargetDataset, which
        shares the instruction and the cache but not the storage layout, does not
        have to duplicate the worker-safety rules below."""
        # VLM processor (Qwen3-VL), same pattern as RoboTwin / DROID
        self.vlm_processor = None
        self.vlm_type = vlm_type
        if vlm_checkpoint_path is not None:
            try:
                from transformers import AutoProcessor
                if self.vlm_type == "molmo2":
                    self.vlm_processor = AutoProcessor.from_pretrained(
                        vlm_checkpoint_path, trust_remote_code=True
                    )
                else:
                    self.vlm_processor = AutoProcessor.from_pretrained(vlm_checkpoint_path)
                logger.info(f"G1-D VLM processor loaded from {vlm_checkpoint_path}")
            except Exception as e:
                logger.warning(f"Failed to load VLM processor from {vlm_checkpoint_path}: {e}")

        # T5 encoder (shared singleton, disk-cached per instruction hash)
        self.t5_mode = t5_mode
        self.t5_cache_dir = Path(t5_cache_dir)
        self.t5_cache_dir.mkdir(parents=True, exist_ok=True)
        self.t5_text_len = int(t5_text_len)
        self.t5_device = t5_device
        self.allow_t5_cache_miss_zero = bool(allow_t5_cache_miss_zero)
        self.wan_path = wan_path or os.environ.get("WAN_PATH") or os.environ.get("WAN_ROOT")
        self._t5_encoder = None
        if self.t5_mode == "disk_cache":
            if self.wan_path is None:
                if self.allow_t5_cache_miss_zero:
                    logger.warning(
                        "G1-D t5_mode=disk_cache but wan_path is None; "
                        "T5 will be zero embeddings because "
                        "allow_t5_cache_miss_zero=True. Set dataset.params.wan_path."
                    )
                    self.t5_mode = "none"
                else:
                    raise ValueError(
                        "G1-D t5_mode=disk_cache requires dataset.params.wan_path "
                        "or WAN_PATH/WAN_ROOT. Set t5_mode='none' or "
                        "allow_t5_cache_miss_zero=True explicitly to use zero embeddings."
                    )
        if self.t5_mode == "none":
            logger.warning("G1-D t5_mode=none: language_embedding will be zeros (WAN T5 disabled)")

    # ------------------------------------------------------------------
    # Action representation
    # ------------------------------------------------------------------
    def _load_normalizers(self, stats_path: Optional[str]):
        if not self.normalization:
            return None, None
        path = Path(stats_path) if stats_path else self.root / "meta" / "eef_stats.json"
        if not path.exists():
            hint = (
                "tools/g1_qpos_to_eef.py --write generates it, and it belongs to the G1-D "
                "dataset -- other sources in a mix normalize with G1-D's constants and have "
                "none of their own, so point normalization_stats_path at G1-D's copy"
                if not stats_path
                else "tools/g1_qpos_to_eef.py --write generates it"
            )
            raise FileNotFoundError(f"normalization=True but no stats at {path}. {hint}.")
        with open(path, "r") as f:
            stats = json.load(f)
        mode = self.normalization_mode
        if mode not in ("minmax", "standard"):
            raise ValueError(f"normalization_mode must be 'minmax' or 'standard', got {mode!r}")

        def build(keys_minmax, keys_meanstd):
            if mode == "minmax":
                missing = set(keys_minmax) - set(stats)
                if missing:
                    raise KeyError(f"{path} is missing {sorted(missing)}; regenerate with "
                                   f"tools/g1_qpos_to_eef.py --write")
                return _AffineNormalizer.from_min_max(
                    np.asarray(stats[keys_minmax[0]]), np.asarray(stats[keys_minmax[1]]))
            missing = set(keys_meanstd) - set(stats)
            if missing:
                raise KeyError(f"{path} is missing {sorted(missing)}; regenerate with "
                               f"tools/g1_qpos_to_eef.py --write")
            return _AffineNormalizer.from_mean_std(
                np.asarray(stats[keys_meanstd[0]]), np.asarray(stats[keys_meanstd[1]]))

        state_norm = build(("min", "max"), ("mean", "std"))
        if self.action_mode == "eef_delta":
            horizon = int(stats.get("delta_horizon", 0))
            if horizon < self.action_chunk_size:
                raise ValueError(
                    f"delta stats in {path} cover horizons up to {horizon}, but the action "
                    f"chunk is {self.action_chunk_size}. Regenerate with "
                    f"--horizon {self.action_chunk_size}."
                )
            action_norm = build(("delta_min", "delta_max"), ("delta_mean", "delta_std"))
        else:
            action_norm = state_norm
        logger.info(f"G1-D {mode} normalization enabled from {path}")
        return state_norm, action_norm

    def _check_action_columns(self) -> None:
        """Fail at construction rather than after N sample retries swallow it."""
        import pyarrow.parquet as pq

        ep = self.episodes[0]
        path = self._data_path(ep["data_chunk"], ep["data_file"])
        names = set(pq.read_schema(path).names)
        if self.is_eef:
            missing = {self.EEF_STATE_COLUMN, self.EEF_ACTION_COLUMN} - names
            if missing:
                raise RuntimeError(
                    f"action_mode={self.action_mode!r} needs columns {sorted(missing)} in {path}. "
                    f"Generate them with tools/g1_qpos_to_eef.py --write."
                )
            return
        pf = pq.ParquetFile(path)
        batch = next(pf.iter_batches(batch_size=1, columns=["action", "observation.state"]))
        row = batch.to_pydict()
        action_n = len(row["action"][0])
        state_n = len(row["observation.state"][0])
        if action_n not in (16, 19) or state_n not in (16, 23):
            raise RuntimeError(
                f"qpos mode expected action dim 16 (Dex1) or 19 (G1D-mobile) and "
                f"state dim 16 or 23, got action={action_n} state={state_n} in {path}."
            )
        if action_n == 19 or state_n == 23:
            logger.info(
                "G1-D qpos: mapping mobile layout "
                f"(action={action_n}, state={state_n}) to 16-dim Dex1 "
                "[L7, R7, LG, RG] then [L7, LG, R7, RG]; "
                "dropping HighLift / MoveX / MoveYaw / base pose"
            )

    def _raw_vec(self, row: Any, kind: str) -> np.ndarray:
        """One un-normalized 16-dim vector from a parquet row.

        qpos columns are reduced to Dex1-raw 16-dim if needed, then
        arm-interleaved; eef columns are already stored in final layout.
        """
        if self.is_eef:
            col = self.EEF_STATE_COLUMN if kind == "state" else self.EEF_ACTION_COLUMN
            return np.array(row[col], dtype=np.float32)
        col = "observation.state" if kind == "state" else "action"
        return self._to_arm_interleaved(np.array(row[col], dtype=np.float32))

    def _read_state(self, cond_row: Any) -> np.ndarray:
        """State stays absolute even in eef_delta: the offsets the model predicts
        only mean something if it also knows where the arms currently are."""
        vec = self._raw_vec(cond_row, "state")
        if self.state_normalizer is not None:
            vec = self.state_normalizer.normalize(vec).astype(np.float32)
        return vec

    def _read_actions(self, rows: Any, action_indices: List[int], cond_row: Any) -> np.ndarray:
        acts = np.stack([self._raw_vec(rows.iloc[ai], "action") for ai in action_indices], axis=0)
        if self.action_mode == "eef_delta":
            acts = to_delta(self._raw_vec(cond_row, "state"), acts)
        acts = acts.astype(np.float32)
        if self.action_normalizer is not None:
            acts = self.action_normalizer.normalize(acts).astype(np.float32)
        return acts

    def _action_valid_mask(self) -> Optional[torch.Tensor]:
        """Per-dim loss mask. Only the eef modes have dead dims (reserved 6/14)."""
        if not self.is_eef:
            return None
        mask = torch.ones(self.action_chunk_size, self.action_dim, dtype=torch.float32)
        mask[:, list(self.EEF_RESERVED_DIMS)] = 0.0
        return mask

    # ------------------------------------------------------------------
    # Task text
    # ------------------------------------------------------------------
    def _load_tasks(self) -> Dict[int, str]:
        """Load task_index -> task text mapping from meta/tasks.parquet."""
        import pandas as pd

        tasks_path = self.root / "meta" / "tasks.parquet"
        if not tasks_path.exists():
            logger.warning(f"G1-D: meta/tasks.parquet not found at {tasks_path}; "
                           "falling back to a generic instruction")
            return {0: "manipulate the object"}
        try:
            tf = pd.read_parquet(tasks_path)
            mapping: Dict[int, str] = {}
            # tasks.parquet layout: index = task text, column "task_index" = int.
            # (The task string is the DataFrame index, not a column.)
            if "task_index" in tf.columns:
                for task_text, row in tf.iterrows():
                    idx = int(row["task_index"])
                    txt = str(task_text).strip()
                    if txt:
                        mapping[idx] = txt
            else:
                # Fallback: treat the index as task text and assign sequential indices.
                for idx, task_text in enumerate(tf.index):
                    txt = str(task_text).strip()
                    if txt:
                        mapping[idx] = txt
            if not mapping:
                mapping = {0: "manipulate the object"}
            return mapping
        except Exception as e:
            logger.warning(f"G1-D: failed to read tasks.parquet ({e}); "
                           "falling back to a generic instruction")
            return {0: "manipulate the object"}

    # ------------------------------------------------------------------
    # Episode indexing
    # ------------------------------------------------------------------
    def _video_path(self, video_key: str, chunk_index: int, file_index: int) -> Path:
        return (
            self.root
            / "videos"
            / video_key
            / f"chunk-{chunk_index:03d}"
            / f"file-{file_index:03d}.mp4"
        )

    def _data_path(self, chunk_index: int, file_index: int) -> Path:
        return self.root / "data" / f"chunk-{chunk_index:03d}" / f"file-{file_index:03d}.parquet"

    def _index_episodes(self) -> None:
        import pandas as pd

        meta_dir = self.root / "meta" / "episodes"
        if not meta_dir.exists():
            raise FileNotFoundError(f"meta/episodes not found in {self.root}")
        ep_files = sorted(meta_dir.rglob("*.parquet"))
        if not ep_files:
            raise FileNotFoundError(f"No episode parquet files under {meta_dir}")

        # Pre-scan video files and skip corrupt/truncated mp4 files.
        corrupt_files: set = set()
        skipped_corrupt = 0

        def _is_valid_video(path: Path) -> bool:
            key = str(path)
            if key in corrupt_files:
                return False
            try:
                if not path.exists() or path.stat().st_size < _CORRUPT_VIDEO_MIN_BYTES:
                    corrupt_files.add(key)
                    return False
            except OSError:
                corrupt_files.add(key)
                return False
            return True

        all_eps: List[Dict[str, Any]] = []
        for epf in ep_files:
            try:
                ep = pd.read_parquet(epf)
            except Exception as e:
                logger.warning(f"Failed to read episode meta {epf}: {e}")
                continue
            for _, row in ep.iterrows():
                cam_paths: Dict[str, str] = {}
                cam_starts: Dict[str, int] = {}
                missing = False
                for cam in self._ALL_CAMS:
                    chunk_idx = int(row[f"videos/{cam}/chunk_index"])
                    file_idx = int(row[f"videos/{cam}/file_index"])
                    from_ts = float(row[f"videos/{cam}/from_timestamp"])
                    vpath = self._video_path(cam, chunk_idx, file_idx)
                    if not vpath.exists() or not _is_valid_video(vpath):
                        missing = True
                        break
                    cam_paths[cam] = str(vpath)
                    cam_starts[cam] = int(round(from_ts * self.fps))
                if missing:
                    skipped_corrupt += 1
                    continue
                data_chunk = int(row["data/chunk_index"])
                data_file = int(row["data/file_index"])
                data_path = self._data_path(data_chunk, data_file)
                if not data_path.exists():
                    continue
                length = int(row["length"])
                episode_index = int(row["episode_index"])
                all_eps.append({
                    "episode_index": episode_index,
                    "length": length,
                    "data_chunk": data_chunk,
                    "data_file": data_file,
                    "top_video": cam_paths[self.TOP_CAM],
                    "bottom_left_video": cam_paths[self.BOTTOM_LEFT_CAM],
                    "bottom_right_video": cam_paths[self.BOTTOM_RIGHT_CAM],
                    "top_start_frame": cam_starts[self.TOP_CAM],
                    "bottom_left_start_frame": cam_starts[self.BOTTOM_LEFT_CAM],
                    "bottom_right_start_frame": cam_starts[self.BOTTOM_RIGHT_CAM],
                })

        if skipped_corrupt > 0:
            logger.info(
                f"G1-D: skipped {skipped_corrupt} episodes with missing/corrupt "
                f"video files ({len(corrupt_files)} unique bad mp4s)"
            )

        all_eps = select_episodes(
            all_eps, self.max_episodes, self.episode_seed, self.episode_subset
        )
        self.episodes = all_eps

    # ------------------------------------------------------------------
    # Parquet frame access
    # ------------------------------------------------------------------
    def _load_parquet_rows(self, data_chunk: int, data_file: int, episode_index: int) -> "pd.DataFrame":
        import pandas as pd
        key = (data_chunk, data_file)
        df = self._parquet_cache.get(key)
        if df is None:
            path = self._data_path(data_chunk, data_file)
            df = pd.read_parquet(path)
            self._parquet_cache[key] = df
            self._parquet_cache_order.append(key)
            if len(self._parquet_cache_order) > self._parquet_cache_max:
                old = self._parquet_cache_order.pop(0)
                self._parquet_cache.pop(old, None)
        sub = df[df["episode_index"] == episode_index]
        return sub.reset_index(drop=True)

    @classmethod
    def _to_dex1_raw(cls, vec: np.ndarray) -> np.ndarray:
        """Map a parquet qpos vector onto Dex1-raw 16-dim [L7, R7, LG, RG].

        16-dim Dex1 is already that layout. 19-dim action / 23-dim G1D-mobile
        state drop HighLift, chassis motion, and (on state) base pose, keeping
        the two grippers at source indices 17/18.
        """
        flat = np.asarray(vec, dtype=np.float32).reshape(-1)
        n = int(flat.shape[0])
        if n == cls.ACTION_DIM:
            return flat
        if n in (19, 23):
            return flat[cls._MOBILE_TO_DEX1_RAW]
        raise ValueError(
            f"qpos vector has dim {n}; expected 16 (Dex1) or 19/23 (G1D-mobile)"
        )

    @classmethod
    def _to_arm_interleaved(cls, vec: np.ndarray) -> np.ndarray:
        """Reorder qpos from Dex1-raw [L7, R7, LG, RG] to [L7, LG, R7, RG].

        G1D-mobile 19/23-dim vectors are first reduced to Dex1-raw 16-dim.
        Applied to both ``observation.state`` and ``action`` so each gripper
        sits right after its arm's 7 joints (dims 7/15), matching the
        multi-source per-arm layout.
        """
        return cls._to_dex1_raw(vec)[cls._REORDER_FROM_RAW]

    # ------------------------------------------------------------------
    # Sampling indices (same logic as RoboTwin / DROID / LeRobotMotusDataset)
    # ------------------------------------------------------------------
    def _calculate_sampling_indices(self, total_frames: int) -> Tuple[int, List[int], List[int]]:
        physical_chunk_size = self.action_chunk_size * self.global_downsample_rate
        max_condition_idx = total_frames - physical_chunk_size - 1
        if max_condition_idx < 0:
            condition_frame_idx = 0
        else:
            condition_frame_idx = random.randint(0, max_condition_idx)
        action_indices = []
        for i in range(self.action_chunk_size):
            action_idx = condition_frame_idx + (i + 1) * self.global_downsample_rate
            action_indices.append(min(action_idx, total_frames - 1))
        video_indices = []
        for i in range(self.num_video_frames):
            action_step = (i + 1) * self.video_action_freq_ratio - 1
            if action_step < len(action_indices):
                video_indices.append(action_indices[action_step])
            else:
                video_indices.append(action_indices[-1])
        return condition_frame_idx, video_indices, action_indices

    # ------------------------------------------------------------------
    # T5 embedding (disk-cached, shared singleton encoder)
    # ------------------------------------------------------------------
    def _ensure_t5_encoder(self):
        if self._t5_encoder is not None:
            return self._t5_encoder
        if self.t5_mode != "disk_cache":
            return None
        if self.wan_path is None:
            return None
        from data import get_global_t5_encoder
        self._t5_encoder = get_global_t5_encoder(self.wan_path, self.t5_text_len, self.t5_device)
        return self._t5_encoder

    @staticmethod
    def _hash_text(text: str) -> str:
        return hashlib.sha1(text.encode("utf-8")).hexdigest()

    def _zero_t5_embedding(self) -> torch.Tensor:
        return torch.zeros((self.t5_text_len, 4096), dtype=torch.float32)

    def _validate_t5_embedding(self, emb: torch.Tensor, path: Path) -> torch.Tensor:
        emb = emb.float()
        expected_shape = (self.t5_text_len, 4096)
        if tuple(emb.shape) != expected_shape:
            raise ValueError(
                f"G1-D T5 cache file has shape {tuple(emb.shape)}, "
                f"expected {expected_shape}: {path}"
            )
        return emb

    def _get_t5_embedding(self, instruction: str) -> torch.Tensor:
        if self.t5_mode == "none":
            return self._zero_t5_embedding()
        key = self._hash_text(instruction)
        path = self.t5_cache_dir / f"{key}.pt"
        if path.exists():
            try:
                return self._validate_t5_embedding(
                    torch.load(path, map_location="cpu", weights_only=True),
                    path,
                )
            except Exception as exc:
                raise RuntimeError(f"Failed to load G1-D T5 cache file {path}") from exc
        # DataLoader worker processes cannot safely initialize the heavy T5
        # encoder (CUDA fork restriction).  Cache misses in workers are
        # correctness errors by default; pre-populate the cache before
        # multi-worker training.  A legacy zero fallback is available only
        # through allow_t5_cache_miss_zero=True.
        import multiprocessing
        if multiprocessing.current_process().name != "MainProcess":
            if self.allow_t5_cache_miss_zero:
                logger.warning(
                    "G1-D T5 cache miss in worker; returning zeros because "
                    "allow_t5_cache_miss_zero=True (key=%s, cache=%s)",
                    key,
                    path,
                )
                return self._zero_t5_embedding()
            raise RuntimeError(
                "G1-D T5 cache miss in DataLoader worker. Run "
                "scripts/prepopulate_g1d_t5_cache.py before multi-worker "
                f"training, or set allow_t5_cache_miss_zero=True explicitly. "
                f"key={key}, cache={path}"
            )
        encoder = self._ensure_t5_encoder()
        if encoder is None:
            if self.allow_t5_cache_miss_zero:
                logger.warning(
                    "G1-D T5 encoder unavailable; returning zeros because "
                    "allow_t5_cache_miss_zero=True"
                )
                return self._zero_t5_embedding()
            raise RuntimeError(
                "G1-D t5_mode=disk_cache but no T5 encoder is available. "
                "Set dataset.params.wan_path/WAN_PATH correctly, use "
                "t5_mode='none', or set allow_t5_cache_miss_zero=True explicitly."
            )
        with torch.no_grad():
            out = encoder([instruction], self.t5_device)
        if isinstance(out, list):
            emb = out[0]
        elif isinstance(out, torch.Tensor):
            emb = out.squeeze(0)
        else:
            raise TypeError(f"Unexpected T5 encoder output: {type(out)}")
        if emb.ndim == 3 and emb.shape[0] == 1:
            emb = emb.squeeze(0)
        # T5EncoderModel returns embeddings truncated to the actual token count
        # (u[:v]), which for short Chinese instructions is much smaller than
        # t5_text_len (e.g. 13 vs 512).  Pad with zeros / truncate to the
        # fixed cache shape (t5_text_len, 4096) so the cache is uniform and
        # matches _validate_t5_embedding.  The model pads/truncates again at
        # consume time (preprocess_t5_embeddings), so this is lossless.
        emb = emb.detach().to("cpu").float()
        if emb.shape[0] < self.t5_text_len:
            pad = emb.new_zeros(self.t5_text_len - emb.shape[0], emb.shape[1])
            emb = torch.cat([emb, pad], dim=0)
        elif emb.shape[0] > self.t5_text_len:
            emb = emb[: self.t5_text_len]
        self._validate_t5_embedding(emb, path)
        tmp = self.t5_cache_dir / f".tmp_{key}_{os.getpid()}.pt"
        torch.save(emb, tmp)
        os.replace(tmp, path)
        return emb

    # ------------------------------------------------------------------
    # Video decoding (T-shape: top cam_left_high + bottom cam_left/right_wrist)
    # ------------------------------------------------------------------
    def _decode_frames(self, video_path: str, start_frame: int, frame_offsets: List[int]) -> torch.Tensor:
        """Decode frames at ``start_frame + frame_offsets`` from one camera, return [T, C, H, W] in [0,1]."""
        if not frame_offsets:
            return torch.zeros((0, 3, self.video_size[0], self.video_size[1]))
        abs_indices = [int(start_frame + off) for off in frame_offsets]
        raw = _decode_video_frames_pyav(video_path, abs_indices, self.fps)  # [T, H, W, 3] uint8
        th, tw = self.video_size
        out = torch.zeros((len(frame_offsets), 3, th, tw), dtype=torch.float32)
        for i in range(len(frame_offsets)):
            arr = raw[i]  # [H, W, 3] uint8
            resized = resize_with_padding(arr, self.video_size)  # [th, tw, 3] uint8
            out[i] = torch.from_numpy(resized).permute(2, 0, 1).float() / 255.0
        return out

    def _decode_raw_frames(self, video_path: str, start_frame: int, frame_offsets: List[int]) -> np.ndarray:
        """Decode frames at ``start_frame + frame_offsets`` at NATIVE resolution.

        Returns ``[T, H, W, 3]`` uint8 with no resizing.  Used by the
        ``stitch_mode="aspect"`` stitcher, which resizes each camera exactly
        once, straight into its T-shape sub-region.
        """
        if not frame_offsets:
            return np.zeros((0, 0, 0, 3), dtype=np.uint8)
        abs_indices = [int(start_frame + off) for off in frame_offsets]
        return _decode_video_frames_pyav(video_path, abs_indices, self.fps)  # [T, H, W, 3] uint8

    def t_shape_geometry(self, top_hw: Tuple[int, int], bl_hw: Tuple[int, int], br_hw: Tuple[int, int]) -> Dict[str, int]:
        """Solve the aspect-preserving T-shape layout for ``video_size``.

        ``cam_left_high`` spans the full canvas width, which is the largest it
        can be without distortion, and the bottom row takes only the height its
        two half-width wrist views naturally need.  The resulting T block is
        center-padded vertically, so the only black pixels are a thin strip at
        the very top and bottom of the canvas.

        The inference adapter (InferenceMotusV2) mirrors this function, since it
        cannot import from this repo.  ``tests/test_g1d_stitch_geometry.py``
        asserts the two produce identical pixels, so drift fails the tests
        rather than silently degrading a deployed policy.
        """
        th, tw = self.video_size
        split_w = tw // 2
        right_w = tw - split_w

        def _natural_h(hw: Tuple[int, int], target_w: int) -> int:
            h, w = hw
            return max(1, int(round(h * target_w / w)))

        # Bottom row height: whatever the wrist views need at half width.
        bot_h = max(_natural_h(bl_hw, split_w), _natural_h(br_hw, right_w))
        bot_h = min(bot_h, th - 1)
        # Top row: full-width cam_left_high, capped by the space the bottom leaves.
        top_h = min(_natural_h(top_hw, tw), th - bot_h)
        natural_h = top_h + bot_h
        pad_top = (th - natural_h) // 2
        return {
            "canvas_h": th,
            "canvas_w": tw,
            "top_h": top_h,
            "bot_h": bot_h,
            "split_w": split_w,
            "right_w": right_w,
            "natural_h": natural_h,
            "pad_top": pad_top,
            "pad_bottom": th - natural_h - pad_top,
        }

    def _stitch_t_shape(self, top_raw: np.ndarray, bl_raw: np.ndarray, br_raw: np.ndarray) -> torch.Tensor:
        """Stitch top + (bottom-left | bottom-right) into a T shape -> ``video_size``.

        Aspect-ratio-preserving single resize (see class docstring).  Each camera
        is resized exactly once from native resolution into its sub-region, so
        no camera is ever squeezed through an intermediate padded canvas.

        For G1-D's 480x640 cameras at 384x320:
            top    : 240 x 320   (cam_left_high, fills its region exactly)
            bottom : 120 x 160   (each wrist, fills its region exactly)
            natural height 360 -> 12px black strip at the top and bottom

        ``resize_with_padding`` is used per region so that a camera whose aspect
        ratio does not match its region is letterboxed rather than distorted.
        For G1-D every region matches exactly, so it degenerates to a plain
        resize with zero padding.

        Inputs are raw ``[T, H, W, 3]`` uint8 arrays at native camera
        resolution.  Returns ``[T, C, H, W]`` float in [0,1] at ``video_size``.
        """
        T = top_raw.shape[0]
        th, tw = self.video_size
        geo = self.t_shape_geometry(top_raw.shape[1:3], bl_raw.shape[1:3], br_raw.shape[1:3])
        top_h, bot_h = geo["top_h"], geo["bot_h"]
        split_w, right_w = geo["split_w"], geo["right_w"]
        y0 = geo["pad_top"]

        out = torch.zeros((T, 3, th, tw), dtype=torch.float32)
        for i in range(T):
            canvas = np.zeros((th, tw, 3), dtype=np.uint8)
            canvas[y0:y0 + top_h, :, :] = resize_with_padding(top_raw[i], (top_h, tw))
            yb = y0 + top_h
            canvas[yb:yb + bot_h, :split_w, :] = resize_with_padding(bl_raw[i], (bot_h, split_w))
            canvas[yb:yb + bot_h, split_w:, :] = resize_with_padding(br_raw[i], (bot_h, right_w))
            out[i] = torch.from_numpy(canvas).permute(2, 0, 1).float() / 255.0
        return out

    def _stitch_t_shape_legacy(self, top_frames: torch.Tensor, bl_frames: torch.Tensor, br_frames: torch.Tensor) -> torch.Tensor:
        """LEGACY double-resize stitch, for checkpoints trained before the switch.

        ``top_frames`` / ``bl_frames`` / ``br_frames`` arrive already
        resize-padded to the full ``video_size`` and are re-resized here into a
        fixed 50/50 top/bottom split, which is what wasted 53.1% of the canvas.

        Layout (mirrors LeRobotMotusDataset.has_three_cam stitching):
            ┌────────────────────┐
            │     top (cam_high)  │   full width, height top_h
            ├─────────┬──────────┤
            │ bl_wrist │ br_wrist │   each half width, height bottom_h
            └─────────┴──────────┘
        Inputs are [T, C, H, W] float in [0,1], each already resize-padded to
        ``video_size``.  Returns [T, C, H, W] at ``video_size``.
        """
        T = top_frames.shape[0]
        c = top_frames.shape[1]
        th, tw = self.video_size
        top_h = th // 2
        bottom_h = th - top_h
        split_w = tw // 2
        right_w = tw - split_w

        # Resize each camera's frames to their T-shape sub-region.
        def _to_sub(frames: torch.Tensor, sub_h: int, sub_w: int) -> torch.Tensor:
            if frames.shape[2] == sub_h and frames.shape[3] == sub_w:
                return frames
            out = torch.zeros((T, c, sub_h, sub_w), dtype=frames.dtype)
            for i in range(T):
                arr = frames[i].permute(1, 2, 0).cpu().numpy()  # [H, W, 3] float [0,1]
                arr_uint8 = (arr * 255.0).clip(0, 255).astype("uint8")
                resized = resize_with_padding(arr_uint8, (sub_h, sub_w))  # [sub_h, sub_w, 3] uint8
                out[i] = torch.from_numpy(resized).permute(2, 0, 1).float() / 255.0
            return out

        top_r = _to_sub(top_frames, top_h, tw)
        bl_r = _to_sub(bl_frames, bottom_h, split_w)
        br_r = _to_sub(br_frames, bottom_h, right_w)

        stitched = torch.zeros((T, c, th, tw), dtype=top_r.dtype)
        stitched[:, :, :top_h, :] = top_r
        stitched[:, :, top_h:, :split_w] = bl_r
        stitched[:, :, top_h:, split_w:] = br_r
        # Stitched is already at video_size (th x tw), so no final resize needed.
        return stitched

    # ------------------------------------------------------------------
    # __len__ / __getitem__
    # ------------------------------------------------------------------
    def __len__(self) -> int:
        return len(self.episodes) * 10

    def _tensor_to_pil(self, frame_chw: torch.Tensor):
        from PIL import Image
        arr = (frame_chw.permute(1, 2, 0).cpu().numpy() * 255.0).clip(0, 255).astype("uint8")
        return Image.fromarray(arr)

    def __getitem__(self, idx: int) -> Optional[Dict[str, Any]]:
        max_attempts = 8
        for _ in range(max_attempts):
            try:
                ep = self.episodes[random.randint(0, len(self.episodes) - 1)]
                length = ep["length"]
                if length < self.action_chunk_size * self.global_downsample_rate + 2:
                    continue

                cond_idx, video_indices, action_indices = self._calculate_sampling_indices(length)

                # Parquet rows for this episode
                rows = self._load_parquet_rows(ep["data_chunk"], ep["data_file"], ep["episode_index"])
                if len(rows) <= action_indices[-1]:
                    continue

                # 16-dim state at the condition frame and the action chunk, in
                # whichever representation action_mode selects.
                cond_row = rows.iloc[cond_idx]
                state = self._read_state(cond_row)
                acts = self._read_actions(rows, action_indices, cond_row)
                # Instruction from tasks.parquet via task_index (single-task dataset).
                task_idx = int(cond_row["task_index"])
                instr = self.task_index_to_text.get(task_idx, "")
                if not instr.strip():
                    instr = "manipulate the object"
                task_name = instr[:64]

                # Video decoding: offsets relative to episode start (cond + targets).
                offsets = [cond_idx] + video_indices
                # T-shape stitch (top: cam_left_high, bottom-left: cam_left_wrist, bottom-right: cam_right_wrist)
                # The three cameras are separate mp4 files, so they decode concurrently.
                pool = _camera_decode_pool()
                if self.stitch_mode == "aspect":
                    # Decode at native resolution and resize once into each sub-region.
                    top = pool.submit(self._decode_raw_frames, ep["top_video"], ep["top_start_frame"], offsets)
                    bl = pool.submit(self._decode_raw_frames, ep["bottom_left_video"], ep["bottom_left_start_frame"], offsets)
                    br = pool.submit(self._decode_raw_frames, ep["bottom_right_video"], ep["bottom_right_start_frame"], offsets)
                    video_all = self._stitch_t_shape(
                        top.result(), bl.result(), br.result(),
                    )  # [T+1, C, H, W]
                else:
                    top = pool.submit(self._decode_frames, ep["top_video"], ep["top_start_frame"], offsets)
                    bl = pool.submit(self._decode_frames, ep["bottom_left_video"], ep["bottom_left_start_frame"], offsets)
                    br = pool.submit(self._decode_frames, ep["bottom_right_video"], ep["bottom_right_start_frame"], offsets)
                    video_all = self._stitch_t_shape_legacy(
                        top.result(), bl.result(), br.result(),
                    )  # [T+1, C, H, W]
                first_frame = video_all[0]
                video_frames = video_all[1:]

                # T5 language embedding (disk-cached)
                language_embedding = self._get_t5_embedding(instr)

                # VLM inputs (Qwen3-VL)
                vlm_inputs = None
                if self.vlm_processor is not None:
                    first_pil = self._tensor_to_pil(first_frame)
                    vlm_inputs = preprocess_vlm_messages(instr, first_pil, self.vlm_processor)

                initial_state = torch.from_numpy(state).float()
                action_sequence = torch.from_numpy(acts).float()

                sample = {
                    "first_frame": first_frame,
                    "video_frames": video_frames,
                    "initial_state": initial_state,
                    "action_sequence": action_sequence,
                    "language_embedding": language_embedding,
                    "vlm_inputs": vlm_inputs,
                    "task_name": task_name,
                }
                action_valid_mask = self._action_valid_mask()
                if action_valid_mask is not None:
                    sample["action_valid_mask"] = action_valid_mask
                return sample
            except Exception as e:
                logger.warning(f"G1-D sample retry (ep {ep.get('episode_index','?')}): {e}")
                continue
        return None

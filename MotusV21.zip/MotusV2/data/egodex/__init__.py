# EgoDex dataset adapter for Motus

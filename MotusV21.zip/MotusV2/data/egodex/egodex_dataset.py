"""
EgoDex Dataset Adapter for Motus.

Supports two action modes:
1. "wrist" (default): 14-dim = [left_xyz(3), left_quat_WXYZ(4),
                                right_xyz(3), right_quat_WXYZ(4)]
2. "padded_per_hand":  per-hand features padded to MAX_PER_HAND_DIM,
   layout = [left_pad(max), right_pad(max)]
   EgoDex per-hand: 25 hand+finger joints x 9 (xyz + rot6d) = 225 dims

Data layout:
    <data_root>/
        part1/<task>/0.hdf5 + 0.mp4
        ...

HDF5: transforms/leftHand, rightHand, camera (N,4,4); confidences/*; attrs
"""

import os
import random
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import h5py
import numpy as np
import torch
import torch.utils.data as data
from scipy.spatial.transform import Rotation as R

from data.utils.image_utils import resize_with_padding, load_video_frames, tensor_to_pil
from data.human.wrist_feature import (
    WristGaussianNormalizer,
    pad_wrist_14_to_16,
    relative_wrist_14_to_initial,
)
from data.human.unified_eef_action import (
    build_hand_world_poses_from_se3_4x4,
    compute_unified_eef_action_sequence,
    compute_unified_eef_state_from_poses,
    UNIFIED_EEF_ACTION_DIM,
    UNIFIED_EEF_STATE_DIM,
)
from data.per_hand_dims import (
    EGODEX_PER_HAND_ACTION_DIM, EGODEX_PER_HAND_STATE_DIM,
    MAX_PER_HAND_ACTION_DIM, MAX_PER_HAND_STATE_DIM,
    PADDED_ACTION_DIM, PADDED_STATE_DIM,
    concat_per_hand,
)

logger = logging.getLogger(__name__)


def _get_shared_t5_encoder(wan_path: str, t5_text_len: int, t5_device: str):
    """Delegate to the global cross-dataset T5 singleton in data/__init__.py."""
    from data import get_global_t5_encoder
    return get_global_t5_encoder(wan_path, t5_text_len, t5_device)


def _rotation_matrix_to_rot6d(rot_mat: np.ndarray) -> np.ndarray:
    """Convert 3x3 rotation matrix to 6D rotation representation (Zhou et al.)."""
    return rot_mat[:, :2].flatten().astype(np.float32)


# EgoDex hand+finger joint names (per side)
HAND_JOINT_NAMES = [
    "Hand",
    # Thumb
    "ThumbKnuckle", "ThumbIntermediateBase", "ThumbIntermediateTip", "ThumbTip",
    # Index
    "IndexFingerMetacarpal", "IndexFingerKnuckle",
    "IndexFingerIntermediateBase", "IndexFingerIntermediateTip", "IndexFingerTip",
    # Middle
    "MiddleFingerMetacarpal", "MiddleFingerKnuckle",
    "MiddleFingerIntermediateBase", "MiddleFingerIntermediateTip", "MiddleFingerTip",
    # Ring
    "RingFingerMetacarpal", "RingFingerKnuckle",
    "RingFingerIntermediateBase", "RingFingerIntermediateTip", "RingFingerTip",
    # Little
    "LittleFingerMetacarpal", "LittleFingerKnuckle",
    "LittleFingerIntermediateBase", "LittleFingerIntermediateTip", "LittleFingerTip",
]
# 1 + 4 + 5*3 + 5*3 = 1 + 4 + 15 + 15 = ... let me count properly
# Hand + Thumb(4) + Index(5) + Middle(5) + Ring(5) + Little(5) = 25
# But EgoDex has 21 per side (no ThumbTip? no, let me re-check)
# From actual data: 21 hand+finger joints per side
# Hand, ThumbKnuckle, ThumbIntermediateBase, ThumbIntermediateTip, ThumbTip,
# IndexMetacarpal, IndexKnuckle, IndexIntermediateBase, IndexIntermediateTip, IndexTip,
# Middle..., Ring..., Little...
# That's 1 + 4 + 5 + 5 + 5 + 5 = 25? No. Let me check the actual names from the data.

# From the HDF5 inspection:
# leftHand, leftThumbKnuckle, leftThumbIntermediateBase, leftThumbIntermediateTip, leftThumbTip,
# leftIndexFingerMetacarpal, leftIndexFingerKnuckle, leftIndexFingerIntermediateBase, leftIndexFingerIntermediateTip, leftIndexFingerTip,
# ... etc = 1 + 4 + 5 + 5 + 5 + 5 = 25? But we saw 21 in the data.
# The discrepancy is because some joints have different naming. Let me just use what's in the file.


class EgoDexMotusDataset(data.Dataset):
    """
    EgoDex dataset adapter producing Motus-compatible samples.

    action_mode="wrist" (default):
        action_sequence: [F, 14],  initial_state: [14]
    action_mode="wrist_padded16":
        action_sequence: [F, 16],  initial_state: [16]
        layout: [left_xyzquat(7), 0, right_xyzquat(7), 0]
    action_mode="relative_wrist_padded16":
        action_sequence: [F, 16] relative to initial wrist pose, initial_state: [16]
    action_mode="padded_per_hand":
        action_sequence: [F, 450], initial_state: [450]
        layout: [left_per_hand(max225), right_per_hand(max225)]
        EgoDex per-hand = 25 joints x 9 (xyz + rot6d) = 225 dims (no padding needed)
    """

    def __init__(
        self,
        dataset_dir: str,
        *,
        num_video_frames: int = 8,
        video_size: Tuple[int, int] = (384, 320),
        splits: Optional[List[str]] = None,
        confidence_threshold: float = 0.3,
        # Action mode
        action_mode: str = "wrist",
        # Wrist normalization (only for action_mode="wrist")
        wrist_statistics_path: Optional[str] = None,
        # VLM
        vlm_checkpoint_path: Optional[str] = None,
        # T5 embedding
        t5_mode: str = "disk_cache",
        wan_path: str = "./pretrained_models",
        t5_cache_dir: str = "./t5_cache_egodex",
        t5_text_len: int = 512,
        t5_device: str = "cuda",
        # Sampling
        max_episodes: Optional[int] = None,
        max_attempts: int = 8,
        val: bool = False,
        **kwargs: Any,
    ) -> None:
        super().__init__()
        self.dataset_dir = str(dataset_dir)
        self.num_video_frames = int(num_video_frames)
        self.video_size = video_size
        self.confidence_threshold = confidence_threshold
        self.action_mode = action_mode
        self.max_attempts = int(max_attempts)
        self.val = val
        self.splits = splits or ["part1", "part2", "part3", "part4", "part5", "extra", "test"]

        assert self.action_mode in ("wrist", "wrist_padded16", "relative_wrist_padded16", "unified_eef_camera_delta_wrist16", "padded_per_hand"), \
            f"action_mode must be 'wrist', 'wrist_padded16', 'relative_wrist_padded16', 'unified_eef_camera_delta_wrist16', or 'padded_per_hand', got '{self.action_mode}'"

        if self.action_mode == "padded_per_hand":
            self._action_dim = PADDED_ACTION_DIM
            self._state_dim = PADDED_STATE_DIM
        elif self.action_mode == "unified_eef_camera_delta_wrist16":
            self._action_dim = UNIFIED_EEF_ACTION_DIM  # 16
            self._state_dim = UNIFIED_EEF_STATE_DIM    # 16
        else:
            self._action_dim = 16 if self.action_mode in ("wrist_padded16", "relative_wrist_padded16") else 14
            self._state_dim = self._action_dim

        # Index all episodes
        self.episodes: List[Dict[str, Any]] = []
        self._index_episodes(max_episodes)

        if len(self.episodes) == 0:
            raise RuntimeError(f"No valid EgoDex episodes found in {dataset_dir}")

        # Cache hand joint names from first episode
        self._hand_joint_names_left: List[str] = []
        self._hand_joint_names_right: List[str] = []
        self._cache_joint_names()

        logger.info(f"[EgoDex->Motus] Indexed {len(self.episodes)} episodes, "
                     f"action_mode={self.action_mode}, "
                     f"action_dim={self._action_dim}, state_dim={self._state_dim}")

        # Wrist normalizer
        self.wrist_normalizer: Optional[WristGaussianNormalizer] = None
        if self.action_mode in ("wrist", "wrist_padded16", "relative_wrist_padded16") and wrist_statistics_path is not None and os.path.exists(wrist_statistics_path):
            from data.human.wrist_feature import load_wrist_statistics
            stats = load_wrist_statistics(wrist_statistics_path)
            self.wrist_normalizer = WristGaussianNormalizer(stats)

        # VLM processor
        self.vlm_processor = None
        if vlm_checkpoint_path:
            from transformers import AutoProcessor
            self.vlm_processor = AutoProcessor.from_pretrained(vlm_checkpoint_path)

        # T5 embedding
        self.t5_mode = t5_mode
        self.t5_cache_dir = Path(t5_cache_dir)
        self.t5_cache_dir.mkdir(parents=True, exist_ok=True)
        self.t5_encoder = None
        self.t5_device = t5_device
        if self.t5_mode == "disk_cache":
            self.t5_encoder = _get_shared_t5_encoder(wan_path, t5_text_len, t5_device)
        elif self.t5_mode == "none":
            logger.warning("[EgoDex->Motus] t5_mode=none: language_embedding will be zeros")

    # ------------------------------------------------------------------
    # Episode indexing (with disk cache to avoid opening 338K HDF5 files per process)
    # ------------------------------------------------------------------
    def _index_episodes(self, max_episodes: Optional[int]):
        # Try to load from cache first to avoid opening 338K HDF5 files
        cache_path = self._get_index_cache_path()
        if cache_path is not None and os.path.exists(cache_path):
            try:
                import json
                with open(cache_path, "r") as f:
                    cached = json.load(f)
                # Validate cache matches current config
                if (cached.get("splits") == self.splits and
                    cached.get("min_frames") == self.num_video_frames + 1):
                    self.episodes = cached["episodes"]
                    logger.info(f"[EgoDex->Motus] Loaded {len(self.episodes)} episodes from cache: {cache_path}")
                    if max_episodes is not None and len(self.episodes) > max_episodes:
                        self.episodes = self.episodes[:max_episodes]
                    return
                else:
                    logger.info("[EgoDex->Motus] Cache config mismatch, re-indexing...")
            except Exception as e:
                logger.warning(f"[EgoDex->Motus] Failed to load cache: {e}, re-indexing...")

        root = Path(self.dataset_dir)
        for split_name in self.splits:
            split_dir = root / split_name
            if not split_dir.exists():
                continue
            for task_dir in sorted(split_dir.iterdir()):
                if not task_dir.is_dir():
                    continue
                for h5_file in sorted(task_dir.glob("*.hdf5")):
                    mp4_file = h5_file.with_suffix(".mp4")
                    if not mp4_file.exists():
                        continue
                    try:
                        n_frames = self._get_frame_count(str(h5_file))
                        if n_frames < self.num_video_frames + 1:
                            continue
                        self.episodes.append({
                            "h5_path": str(h5_file),
                            "mp4_path": str(mp4_file),
                            "task_name": task_dir.name,
                            "n_frames": n_frames,
                        })
                        if max_episodes is not None and len(self.episodes) >= max_episodes:
                            return
                    except Exception as e:
                        logger.warning(f"[EgoDex->Motus] Skipping {h5_file}: {e}")

        # Save to cache for future runs
        if cache_path is not None and len(self.episodes) > 0:
            try:
                import json
                cache_path.parent.mkdir(parents=True, exist_ok=True)
                with open(cache_path, "w") as f:
                    json.dump({
                        "splits": self.splits,
                        "min_frames": self.num_video_frames + 1,
                        "episodes": self.episodes,
                    }, f)
                logger.info(f"[EgoDex->Motus] Cached {len(self.episodes)} episodes to {cache_path}")
            except Exception as e:
                logger.warning(f"[EgoDex->Motus] Failed to save cache: {e}")

    def _get_index_cache_path(self) -> Optional[Path]:
        """Get path for the index cache file based on dataset_dir and splits."""
        import hashlib
        key = f"{self.dataset_dir}:{','.join(self.splits)}:{self.num_video_frames}"
        h = hashlib.md5(key.encode()).hexdigest()[:12]
        return Path(self.dataset_dir) / f".egodex_index_cache_{h}.json"

    def _get_frame_count(self, h5_path: str) -> int:
        with h5py.File(h5_path, "r") as f:
            return f["/transforms/leftHand"].shape[0]

    def _cache_joint_names(self):
        """Cache the hand+finger joint names from the first episode's HDF5."""
        if not self.episodes:
            return
        try:
            with h5py.File(self.episodes[0]["h5_path"], "r") as f:
                all_keys = list(f["transforms"].keys())
                self._hand_joint_names_left = sorted(
                    [k for k in all_keys if k.startswith("left") and
                     ("Hand" in k or "Finger" in k or "Thumb" in k)]
                )
                self._hand_joint_names_right = sorted(
                    [k for k in all_keys if k.startswith("right") and
                     ("Hand" in k or "Finger" in k or "Thumb" in k)]
                )
            logger.info(f"[EgoDex->Motus] Left hand joints: {len(self._hand_joint_names_left)}, "
                         f"Right hand joints: {len(self._hand_joint_names_right)}")
        except Exception as e:
            logger.warning(f"[EgoDex->Motus] Failed to cache joint names: {e}")

    # ------------------------------------------------------------------
    # Data loading helpers
    # ------------------------------------------------------------------
    def _load_frames_window(self, mp4_path: str, frame_start: int) -> torch.Tensor:
        frame_indices = list(range(frame_start, frame_start + self.num_video_frames + 1))
        return load_video_frames(mp4_path, frame_indices, target_size=self.video_size)

    def _read_raw_transforms(self, h5_path: str, frame_idx: int):
        """Read raw transforms and metadata from HDF5."""
        with h5py.File(h5_path, "r") as f:
            left_tfs = f["/transforms/leftHand"][:]
            right_tfs = f["/transforms/rightHand"][:]
            cam_tfs = f["/transforms/camera"][:]

            has_conf = "confidences" in f
            left_conf = f["/confidences/leftHand"][:] if has_conf else None
            right_conf = f["/confidences/rightHand"][:] if has_conf else None

            # Read all hand+finger transforms for padded_per_hand mode
            left_hand_tfs = {}
            right_hand_tfs = {}
            left_hand_confs = {}
            right_hand_confs = {}
            for name in self._hand_joint_names_left:
                key = f"/transforms/{name}"
                if key in f:
                    left_hand_tfs[name] = f[key][:]
                ckey = f"/confidences/{name}"
                if ckey in f:
                    left_hand_confs[name] = f[ckey][:]

            for name in self._hand_joint_names_right:
                key = f"/transforms/{name}"
                if key in f:
                    right_hand_tfs[name] = f[key][:]
                ckey = f"/confidences/{name}"
                if ckey in f:
                    right_hand_confs[name] = f[ckey][:]

            # Language instruction
            instruction = ""
            llm_type = f.attrs.get("llm_type", "single")
            if isinstance(llm_type, bytes):
                llm_type = llm_type.decode("utf-8")
            if llm_type == "reversible":
                direction = f.attrs.get("which_llm_description", "1")
                if isinstance(direction, bytes):
                    direction = direction.decode("utf-8")
                key = "llm_description" if direction == "1" else "llm_description2"
                instruction = f.attrs.get(key, "")
            else:
                instruction = f.attrs.get("llm_description", "")
            if isinstance(instruction, bytes):
                instruction = instruction.decode("utf-8")

        return (left_tfs, right_tfs, cam_tfs,
                left_conf, right_conf,
                left_hand_tfs, right_hand_tfs,
                left_hand_confs, right_hand_confs,
                instruction)

    def _extract_wrist_action_state(self, h5_path: str, frame_idx: int):
        """Extract 14-dim wrist action/state (camera-relative frame)."""
        (left_tfs, right_tfs, cam_tfs,
         left_conf, right_conf, *_, instruction) = self._read_raw_transforms(h5_path, frame_idx)

        cam_world_inv = np.linalg.inv(cam_tfs[frame_idx])

        def _se3_to_xyzquat(tf):
            xyz = tf[:3, 3]
            quat_xyzw = R.from_matrix(tf[:3, :3]).as_quat()
            quat_wxyz = np.roll(quat_xyzw, 1)
            return np.concatenate([xyz, quat_wxyz]).astype(np.float32)

        actions, valid_masks = [], []
        for i in range(self.num_video_frames):
            fi = min(frame_idx + i + 1, len(left_tfs) - 1)
            left_cam = cam_world_inv @ left_tfs[fi]
            right_cam = cam_world_inv @ right_tfs[fi]

            left_valid = left_conf[fi] >= self.confidence_threshold if left_conf is not None and fi < len(left_conf) else True
            right_valid = right_conf[fi] >= self.confidence_threshold if right_conf is not None and fi < len(right_conf) else True

            left_feat = _se3_to_xyzquat(left_cam) if left_valid else np.zeros(7, dtype=np.float32)
            right_feat = _se3_to_xyzquat(right_cam) if right_valid else np.zeros(7, dtype=np.float32)

            actions.append(np.concatenate([left_feat, right_feat]))
            valid_masks.append([left_valid, right_valid])

        action_arr = np.stack(actions, axis=0).astype(np.float32)
        valid_arr = np.array(valid_masks, dtype=bool)

        left_cam_cur = cam_world_inv @ left_tfs[frame_idx]
        right_cam_cur = cam_world_inv @ right_tfs[frame_idx]
        cur_lv = left_conf[frame_idx] >= self.confidence_threshold if left_conf is not None and frame_idx < len(left_conf) else True
        cur_rv = right_conf[frame_idx] >= self.confidence_threshold if right_conf is not None and frame_idx < len(right_conf) else True
        cur_left = _se3_to_xyzquat(left_cam_cur) if cur_lv else np.zeros(7, dtype=np.float32)
        cur_right = _se3_to_xyzquat(right_cam_cur) if cur_rv else np.zeros(7, dtype=np.float32)
        state = np.concatenate([cur_left, cur_right]).astype(np.float32)

        return action_arr, state, valid_arr, instruction

    def _extract_unified_eef_action_state(self, h5_path: str, frame_idx: int):
        """Extract unified EEF camera-delta wrist16 action/state.

        EgoDex provides:
          - leftHand, rightHand, camera transforms as (N, 4, 4) SE(3) in world frame
          - confidences for validity

        The camera transform at frame_idx is the reference camera.
        Hand transforms are absolute poses in world frame.

        Returns:
            action: (F, 16) unified action
            state: (16,) unified state
            valid_mask: (F, 16) per-dim validity mask
            instruction: str
        """
        (left_tfs, right_tfs, cam_tfs,
         left_conf, right_conf, *_,
         instruction) = self._read_raw_transforms(h5_path, frame_idx)

        # Camera pose in world at frame_idx (reference camera)
        # cam_tfs[i] is the camera-to-world transform: p_world = cam_tfs[i] @ p_cam
        R_w_c = cam_tfs[frame_idx, :3, :3]  # (3, 3) camera rotation in world
        t_w_c = cam_tfs[frame_idx, :3, 3]   # (3,) camera position in world

        # Build hand world poses for the window
        W = self.num_video_frames + 1
        left_R_w = np.zeros((W, 3, 3), dtype=np.float64)
        left_t_w = np.zeros((W, 3), dtype=np.float64)
        right_R_w = np.zeros((W, 3, 3), dtype=np.float64)
        right_t_w = np.zeros((W, 3), dtype=np.float64)
        left_valid = np.zeros(W, dtype=bool)
        right_valid = np.zeros(W, dtype=bool)

        for i in range(W):
            fi = min(frame_idx + i, len(left_tfs) - 1)

            # Left hand
            lv = left_conf[fi] >= self.confidence_threshold if left_conf is not None and fi < len(left_conf) else True
            left_valid[i] = lv
            if lv:
                left_R_w[i] = left_tfs[fi, :3, :3]
                left_t_w[i] = left_tfs[fi, :3, 3]
            else:
                left_R_w[i] = np.eye(3)
                left_t_w[i] = 0.0

            # Right hand
            rv = right_conf[fi] >= self.confidence_threshold if right_conf is not None and fi < len(right_conf) else True
            right_valid[i] = rv
            if rv:
                right_R_w[i] = right_tfs[fi, :3, :3]
                right_t_w[i] = right_tfs[fi, :3, 3]
            else:
                right_R_w[i] = np.eye(3)
                right_t_w[i] = 0.0

        # Compute action sequence
        actions, action_masks = compute_unified_eef_action_sequence(
            R_w_e_left=left_R_w,
            t_w_e_left=left_t_w,
            R_w_e_right=right_R_w,
            t_w_e_right=right_t_w,
            R_w_c=R_w_c,
            left_valid=left_valid,
            right_valid=right_valid,
            num_action_frames=self.num_video_frames,
        )

        # Compute state
        state, state_mask = compute_unified_eef_state_from_poses(
            R_w_e_left=left_R_w[0],
            t_w_e_left=left_t_w[0],
            R_w_e_right=right_R_w[0],
            t_w_e_right=right_t_w[0],
            R_w_c=R_w_c,
            t_w_c=t_w_c,
            left_valid=bool(left_valid[0]),
            right_valid=bool(right_valid[0]),
        )

        return actions, state, action_masks, instruction

    def _extract_padded_per_hand_action_state(self, h5_path: str, frame_idx: int):
        """Extract padded_per_hand action/state.

        Per-hand: 25 joints x 9 (xyz + rot6d) = 225 dims, no padding needed.
        Layout: [left(225), right(225)] = 450
        """
        (left_tfs, right_tfs, cam_tfs,
         left_conf, right_conf,
         left_hand_tfs, right_hand_tfs,
         left_hand_confs, right_hand_confs,
         instruction) = self._read_raw_transforms(h5_path, frame_idx)

        cam_world_inv = np.linalg.inv(cam_tfs[frame_idx])

        def _get_per_hand_feat(fi: int, hand_tfs: dict, hand_confs: dict, is_left: bool):
            """Extract per-hand features for one frame: all joints in camera frame, xyz + rot6d."""
            features = []
            all_valid = True

            for joint_name in (self._hand_joint_names_left if is_left else self._hand_joint_names_right):
                if joint_name not in hand_tfs:
                    # Joint not in this file, zero-pad
                    features.extend(np.zeros(6, dtype=np.float32))
                    continue

                tf_world = hand_tfs[joint_name][fi]  # (4, 4)
                tf_cam = cam_world_inv @ tf_world

                # xyz (3)
                xyz = tf_cam[:3, 3]
                # rot6d (6): first two columns of rotation matrix
                rot6d = _rotation_matrix_to_rot6d(tf_cam[:3, :3])

                features.extend(xyz)
                features.extend(rot6d)

                # Check confidence
                if joint_name in hand_confs:
                    conf = hand_confs[joint_name]
                    if fi < len(conf) and conf[fi] < self.confidence_threshold:
                        all_valid = False

            feat = np.array(features, dtype=np.float32)  # [25*9 = 225]
            return feat, all_valid

        actions, valid_masks = [], []
        for i in range(self.num_video_frames):
            fi = min(frame_idx + i + 1, len(left_tfs) - 1)

            left_feat, left_valid = _get_per_hand_feat(fi, left_hand_tfs, left_hand_confs, is_left=True)
            right_feat, right_valid = _get_per_hand_feat(fi, right_hand_tfs, right_hand_confs, is_left=False)

            # Concat with padding: [left(max126), right(max126)]
            action = concat_per_hand(left_feat, right_feat, MAX_PER_HAND_ACTION_DIM)  # [450]
            actions.append(action)
            valid_masks.append([left_valid, right_valid])

        action_arr = np.stack(actions, axis=0).astype(np.float32)  # [F, 450]
        valid_arr = np.array(valid_masks, dtype=bool)

        # Current state
        cur_left, cur_lv = _get_per_hand_feat(frame_idx, left_hand_tfs, left_hand_confs, is_left=True)
        cur_right, cur_rv = _get_per_hand_feat(frame_idx, right_hand_tfs, right_hand_confs, is_left=False)
        state = concat_per_hand(cur_left, cur_right, MAX_PER_HAND_STATE_DIM).astype(np.float32)

        return action_arr, state, valid_arr, instruction

    # ------------------------------------------------------------------
    # T5 embedding
    # ------------------------------------------------------------------
    @staticmethod
    def _hash_text(text: str) -> str:
        import hashlib
        return hashlib.sha1(text.encode("utf-8")).hexdigest()

    def _get_t5_embedding(self, instruction: str) -> torch.Tensor:
        if self.t5_mode == "none":
            return torch.zeros((512, 4096), dtype=torch.float32)

        key = self._hash_text(instruction)
        path = self.t5_cache_dir / f"{key}.pt"
        if path.exists():
            return torch.load(path, map_location="cpu", weights_only=True).float()

        assert self.t5_encoder is not None
        out = self.t5_encoder([instruction], self.t5_device)
        if isinstance(out, list):
            emb = out[0]
        elif isinstance(out, torch.Tensor):
            emb = out.squeeze(0)
        else:
            raise TypeError(f"Unexpected T5 encoder output: {type(out)}")
        emb = emb.detach().to("cpu").float()

        tmp = self.t5_cache_dir / f".tmp_{key}_{os.getpid()}.pt"
        torch.save(emb, tmp)
        os.replace(tmp, path)
        return emb

    # ------------------------------------------------------------------
    # Debug / visualization interface (NOT used by the training path).
    #
    # Only called explicitly by offline tools such as
    # tools/visualize_egodex_unified_eef.py.  Does not touch __getitem__ and so
    # leaves default training behaviour / performance unchanged.
    # ------------------------------------------------------------------
    def get_debug_sample(
        self,
        episode_index: int,
        frame_start: int,
        load_video: bool = True,
    ) -> Dict[str, Any]:
        """Deterministically extract one window with full re-projection metadata.

        ``action`` / ``state`` / ``action_valid_mask`` come from the *exact*
        training extraction (``_extract_unified_eef_action_state``).  We also
        return the raw per-frame world-frame hand poses, the per-frame
        camera-to-world transforms, and the camera intrinsics so callers can
        re-project the trajectory.

        Coordinate frames (EgoDex, verified OpenCV +Z convention):
          - transforms/camera[i] : camera-to-world SE(3) (T_w_c). +Z looks forward.
          - transforms/{left,right}Hand[i] : hand pose in world SE(3).
          - camera/intrinsic : (3,3) pinhole K, image 1920x1080.

        Returns dict with keys documented inline.
        """
        ep = self.episodes[episode_index]
        h5_path = ep["h5_path"]
        mp4_path = ep["mp4_path"]
        F = self.num_video_frames
        W = F + 1
        win = list(range(frame_start, frame_start + W))

        with h5py.File(h5_path, "r") as f:
            cam_tfs = f["/transforms/camera"][:].astype(np.float64)     # (N,4,4) T_w_c
            left_tfs = f["/transforms/leftHand"][:].astype(np.float64)  # (N,4,4) world
            right_tfs = f["/transforms/rightHand"][:].astype(np.float64)
            K = f["/camera/intrinsic"][:].astype(np.float64) if "/camera/intrinsic" in f else None
            has_conf = "confidences" in f
            left_conf = f["/confidences/leftHand"][:] if has_conf else None
            right_conf = f["/confidences/rightHand"][:] if has_conf else None

        N = left_tfs.shape[0]

        def _win(a):
            idx = [min(frame_start + i, N - 1) for i in range(W)]
            return a[idx]

        def _conf_valid(conf):
            out = np.ones(W, dtype=bool)
            if conf is None:
                return out
            for i in range(W):
                fi = min(frame_start + i, N - 1)
                out[i] = bool(fi < len(conf) and conf[fi] >= self.confidence_threshold) \
                    if fi < len(conf) else True
            return out

        action = state = action_valid_mask = None
        error = None
        try:
            action, state, action_valid_mask, _ = \
                self._extract_unified_eef_action_state(h5_path, frame_start)
        except Exception as e:
            error = f"{type(e).__name__}: {e}"

        # instruction (reuse the raw transforms reader, which parses attrs)
        try:
            *_ignore, instruction = self._read_raw_transforms(h5_path, frame_start)
        except Exception:
            instruction = ""

        cam_win = _win(cam_tfs)
        result: Dict[str, Any] = {
            "episode_index": int(episode_index),
            "frame_start": int(frame_start),
            "num_video_frames": int(F),
            "window_indices": np.asarray(win, dtype=np.int64),
            # raw WORLD-frame hand poses over the window
            "left_tfs_win": _win(left_tfs),     # (W,4,4)
            "right_tfs_win": _win(right_tfs),   # (W,4,4)
            "left_valid_win": _conf_valid(left_conf),
            "right_valid_win": _conf_valid(right_conf),
            # per-frame camera-to-world (T_w_c)
            "cam_tfs_win": cam_win,             # (W,4,4)
            "R_w_c_ref": cam_win[0, :3, :3].copy(),
            "t_w_c_ref": cam_win[0, :3, 3].copy(),
            "K": K,
            "action": None if action is None else np.asarray(action, dtype=np.float64),
            "state": None if state is None else np.asarray(state, dtype=np.float64),
            "action_valid_mask": None if action_valid_mask is None else np.asarray(action_valid_mask, dtype=bool),
            "error": error,
            "instruction": instruction,
            "task_name": ep.get("task_name", "egodex"),
            "h5_path": h5_path,
            "mp4_path": mp4_path,
            "n_frames": int(ep["n_frames"]),
        }

        if load_video:
            frames = self._load_frames_window(mp4_path, frame_start)
            result["frames"] = frames
            result["first_frame"] = frames[0]
            result["video_frames"] = frames[1:]

        return result

    # ------------------------------------------------------------------
    # __len__ / __getitem__
    # ------------------------------------------------------------------
    def __len__(self) -> int:
        return len(self.episodes)

    def __getitem__(self, idx: int) -> Optional[Dict[str, Any]]:
        for _ in range(self.max_attempts):
            try:
                ep_idx = random.randint(0, len(self.episodes) - 1)
                ep = self.episodes[ep_idx]
                n_frames = ep["n_frames"]
                frame_start = random.randint(0, n_frames - self.num_video_frames - 1)

                frames = self._load_frames_window(ep["mp4_path"], frame_start)
                first_frame = frames[0]
                video_frames = frames[1:]

                if self.action_mode in ("wrist", "wrist_padded16", "relative_wrist_padded16"):
                    action, state, valid_mask, instruction = self._extract_wrist_action_state(
                        ep["h5_path"], frame_start)
                    if self.wrist_normalizer is not None and self.action_mode != "relative_wrist_padded16":
                        action = self.wrist_normalizer.normalize_action(action)
                        state = self.wrist_normalizer.normalize_state(state)
                    if self.action_mode == "relative_wrist_padded16":
                        action = relative_wrist_14_to_initial(action, state)
                        action = pad_wrist_14_to_16(action)
                        state = pad_wrist_14_to_16(state)
                    elif self.action_mode == "wrist_padded16":
                        action = pad_wrist_14_to_16(action)
                        state = pad_wrist_14_to_16(state)
                elif self.action_mode == "unified_eef_camera_delta_wrist16":
                    action, state, valid_mask, instruction = self._extract_unified_eef_action_state(
                        ep["h5_path"], frame_start)
                else:
                    action, state, valid_mask, instruction = self._extract_padded_per_hand_action_state(
                        ep["h5_path"], frame_start)

                action_sequence = torch.tensor(action, dtype=torch.float32)
                current_state = torch.tensor(state, dtype=torch.float32)
                action_valid_mask = torch.tensor(valid_mask, dtype=torch.bool)

                language_embedding = self._get_t5_embedding(instruction)

                vlm_inputs = None
                if self.vlm_processor is not None:
                    from utils.vlm_utils import preprocess_vlm_messages
                    first_frame_pil = tensor_to_pil(first_frame)
                    vlm_inputs = preprocess_vlm_messages(instruction, first_frame_pil, self.vlm_processor)

                return {
                    "first_frame": first_frame,
                    "video_frames": video_frames,
                    "initial_state": current_state,
                    "action_sequence": action_sequence,
                    "language_embedding": language_embedding,
                    "vlm_inputs": vlm_inputs,
                    "action_valid_mask": action_valid_mask,
                }

            except Exception as e:
                logger.warning(f"[EgoDex->Motus] sample retry due to error: {e}")
                continue

        return None

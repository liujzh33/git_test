"""
OpenAoE-2000h Dataset Adapter for MotusV2.

Supports the ``unified_eef_camera_delta_wrist16`` action mode, producing exactly
the same 16-D action space as the VITRA / EgoDex / Xperience human datasets:

    16D = [left_delta_xyz_cam(3), left_delta_rotvec_cam(3), 0, 0,
           right_delta_xyz_cam(3), right_delta_rotvec_cam(3), 0, 0]

Data layout (one directory per sample, ~13.3k samples):

    <data_root>/<sample_dir>/                     # aoe_* or raw_*
        raw_video.mp4                             # original (lens-distorted) video
        video_info.json                           # device / raw intrinsics
        ego_annotation/
            ego_action_annotation.json            # segment-level atomic actions
        ego_process/
            ego_undistorted_video/
                raw_video_undistorted.mp4         # undistorted, frame-aligned with raw
                undistorted_video_info.json
            ego_hands_reconstruction/
                camera_traj.npz                   # cam_c2w (T,4,4), intrinsic (3,3)
                hands.npz                         # MANO wrist poses + validity

COORDINATE FRAMES (documented by the dataset, OpenCV convention x-right/y-down/z-forward):

    camera_traj.npz:
        cam_c2w[t]  : (4,4) camera-to-world homogeneous transform  == T_w_c(t)
                      p_world = cam_c2w[t] @ [p_cam; 1]
        intrinsic   : (3,3) pinhole K of the UNDISTORTED video

    hands.npz (first axis of the 2-sized dim: index 0 = LEFT, index 1 = RIGHT):
        pred_trans[h]  : (T,3)  wrist translation in WORLD frame  (meters)
        pred_rot[h]    : (T,3)  wrist global rotation in WORLD frame (axis-angle, radians)
        pred_valid[h]  : (T,)   1.0 = valid detection, 0.0 = invalid
        R_w2c/t_w2c    : (T,3,3)/(T,3)  world->camera (redundant with cam_c2w)
        R_c2w/t_c2w    : (T,3,3)/(T,3)  camera->world (redundant with cam_c2w)

Because the hand poses are already absolute world poses and ``cam_c2w`` is a
camera-to-world transform, this dataset feeds the shared unified-EEF math
directly (the same situation as EgoDex):

    R_w_e = exp_SO3(pred_rot[h, t]),  t_w_e = pred_trans[h, t]
    R_w_c = cam_c2w[anchor, :3, :3],  t_w_c = cam_c2w[anchor, :3, 3]

All frame-indexed arrays (video, cam_c2w, hands.npz, annotation frame numbers)
are 1:1 aligned to ``raw_video.mp4`` / ``raw_video_undistorted.mp4`` frame
indices.  ``visualization/hands_combined.mp4`` is NOT aligned (half the frames)
and is never read here.
"""

import hashlib
import json
import logging
import os
import random
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.utils.data as data
from scipy.spatial.transform import Rotation as R

from data.utils.image_utils import load_video_frames, tensor_to_pil
from data.human.unified_eef_action import (
    compute_unified_eef_action_sequence,
    compute_unified_eef_state_from_poses,
    UNIFIED_EEF_ACTION_DIM,
    UNIFIED_EEF_STATE_DIM,
)

logger = logging.getLogger(__name__)

# hands.npz two-hand axis order (documented by the dataset).
HAND_INDEX_LEFT = 0
HAND_INDEX_RIGHT = 1

_REL_HANDS_NPZ = "ego_process/ego_hands_reconstruction/hands.npz"
_REL_CAMTRAJ_NPZ = "ego_process/ego_hands_reconstruction/camera_traj.npz"
_REL_ANNOTATION = "ego_annotation/ego_action_annotation.json"
_REL_VIDEO_UNDIST = "ego_process/ego_undistorted_video/raw_video_undistorted.mp4"
_REL_VIDEO_RAW = "raw_video.mp4"


def _get_shared_t5_encoder(wan_path: str, t5_text_len: int, t5_device: str):
    """Delegate to the global cross-dataset T5 singleton in data/__init__.py."""
    from data import get_global_t5_encoder
    return get_global_t5_encoder(wan_path, t5_text_len, t5_device)


@lru_cache(maxsize=64)
def _load_npz_cached(path: str) -> Dict[str, np.ndarray]:
    """Load a (small) .npz fully into memory, cached across __getitem__ calls.

    hands.npz is ~3-5 MB and camera_traj.npz ~0.6-1 MB, so a small LRU keeps
    consecutive samples from the same episode cheap without exploding RSS.
    """
    with np.load(path) as f:
        return {k: f[k] for k in f.files}


@lru_cache(maxsize=64)
def _load_annotation_cached(path: str) -> Tuple[Tuple[int, int, str], ...]:
    """Parse ego_action_annotation.json into (start_frame, end_frame, text) tuples.

    Frame numbers in the annotation are strings and index the raw video.
    """
    try:
        with open(path, "r", encoding="utf-8") as f:
            segments = json.load(f)
    except Exception:
        return tuple()

    out: List[Tuple[int, int, str]] = []
    for seg in segments or []:
        try:
            sf = int(float(seg.get("start_frame", 0)))
            ef = int(float(seg.get("end_frame", 0)))
        except (TypeError, ValueError):
            continue
        texts: List[str] = []
        for aa in seg.get("atomic_action", []) or []:
            desc = (aa.get("description") or "").strip()
            if not desc:
                verb = (aa.get("verb") or "").strip()
                obj = (aa.get("object") or "").strip()
                desc = f"{verb} {obj}".strip()
            if desc:
                texts.append(desc)
        out.append((sf, ef, " ".join(texts).strip()))
    return tuple(out)


class OpenAoEMotusDataset(data.Dataset):
    """OpenAoE-2000h adapter producing Motus-compatible unified-EEF samples.

    action_mode="unified_eef_camera_delta_wrist16":
        action_sequence: [F, 16], initial_state: [16], action_valid_mask: [F, 16]
        Layout: [left_delta_xyz_cam(3), left_delta_rotvec_cam(3), 0, 0,
                 right_delta_xyz_cam(3), right_delta_rotvec_cam(3), 0, 0]
    """

    def __init__(
        self,
        dataset_dir: str,
        *,
        num_video_frames: int = 8,
        video_size: Tuple[int, int] = (384, 320),
        action_mode: str = "unified_eef_camera_delta_wrist16",
        # Frame sampling
        frame_stride: int = 1,
        # Video source: the undistorted video is the one whose geometry matches
        # camera_traj.npz's intrinsic; "raw" is the smaller, lens-distorted file.
        video_source: str = "undistorted",
        allow_video_fallback: bool = True,
        # Instruction
        instruction_mode: str = "description",
        default_instruction: str = "",
        # VLM
        vlm_checkpoint_path: Optional[str] = None,
        # T5 embedding
        t5_mode: str = "disk_cache",
        wan_path: str = "./pretrained_models",
        t5_cache_dir: str = "./t5_cache_openaoe",
        t5_text_len: int = 512,
        t5_device: str = "cuda",
        # Indexing
        max_episodes: Optional[int] = None,
        index_cache_path: Optional[str] = None,
        max_attempts: int = 8,
        val: bool = False,
        **kwargs: Any,
    ) -> None:
        super().__init__()
        self.dataset_dir = str(dataset_dir)
        self.num_video_frames = int(num_video_frames)
        self.video_size = video_size
        self.action_mode = action_mode
        self.frame_stride = max(1, int(frame_stride))
        self.video_source = video_source
        self.allow_video_fallback = bool(allow_video_fallback)
        self.instruction_mode = instruction_mode
        self.default_instruction = default_instruction
        self.max_attempts = int(max_attempts)
        self.val = val

        if self.action_mode != "unified_eef_camera_delta_wrist16":
            raise ValueError(
                f"OpenAoE dataset currently only supports "
                f"action_mode='unified_eef_camera_delta_wrist16', got '{self.action_mode}'"
            )
        if self.video_source not in ("undistorted", "raw"):
            raise ValueError(f"video_source must be 'undistorted' or 'raw', got '{self.video_source}'")

        self._action_dim = UNIFIED_EEF_ACTION_DIM  # 16
        self._state_dim = UNIFIED_EEF_STATE_DIM    # 16

        # Skip counters
        self._skipped_missing_files = 0
        self._skipped_too_short = 0
        self._skipped_other_error = 0
        self._skipped_other_error_samples: List[str] = []
        self._skipped_no_hand_data = 0
        self._skipped_nan_hand = 0
        self._total_samples = 0

        self.episodes: List[Dict[str, Any]] = []
        self._index_cache_path = index_cache_path
        self._index_episodes(max_episodes)

        if len(self.episodes) == 0:
            raise RuntimeError(f"No valid OpenAoE episodes found in {dataset_dir}")

        logger.info(
            f"[OpenAoE->Motus] Indexed {len(self.episodes)} episodes "
            f"(skipped missing_files={self._skipped_missing_files}, "
            f"too_short={self._skipped_too_short}, other={self._skipped_other_error}), "
            f"action_mode={self.action_mode}, action_dim={self._action_dim}, "
            f"video_source={self.video_source}, frame_stride={self.frame_stride}"
        )
        for p in self._skipped_other_error_samples[:3]:
            logger.warning(f"[OpenAoE->Motus] Example indexing error: {p}")

        # VLM processor
        self.vlm_processor = None
        if vlm_checkpoint_path:
            from transformers import AutoProcessor
            self.vlm_processor = AutoProcessor.from_pretrained(vlm_checkpoint_path)

        # T5 embedding
        self.t5_mode = t5_mode
        self.t5_cache_dir = Path(t5_cache_dir)
        self.t5_cache_dir.mkdir(parents=True, exist_ok=True)
        self.t5_encoder = None
        self.t5_device = t5_device
        if self.t5_mode == "disk_cache":
            self.t5_encoder = _get_shared_t5_encoder(wan_path, t5_text_len, t5_device)
        elif self.t5_mode == "none":
            logger.warning("[OpenAoE->Motus] t5_mode=none: language_embedding will be zeros")

    # ------------------------------------------------------------------
    # Episode indexing (disk-cached: the root holds ~13.3k sample dirs)
    # ------------------------------------------------------------------
    def _default_index_cache_path(self) -> Path:
        key = f"{self.dataset_dir}:{self.num_video_frames}:{self.frame_stride}:{self.video_source}"
        h = hashlib.md5(key.encode()).hexdigest()[:12]
        return Path(self.dataset_dir) / f".openaoe_index_cache_{h}.json"

    def _min_required_frames(self) -> int:
        """Frames needed to build one window of F+1 samples at the given stride."""
        return (self.num_video_frames * self.frame_stride) + 1

    def _index_episodes(self, max_episodes: Optional[int]):
        cache_path = Path(self._index_cache_path) if self._index_cache_path else self._default_index_cache_path()
        if cache_path.exists():
            try:
                with open(cache_path, "r") as f:
                    cached = json.load(f)
                if (cached.get("min_frames") == self._min_required_frames()
                        and cached.get("video_source") == self.video_source):
                    self.episodes = cached["episodes"]
                    if max_episodes is not None and len(self.episodes) > max_episodes:
                        self.episodes = self.episodes[:max_episodes]
                    logger.info(f"[OpenAoE->Motus] Loaded {len(self.episodes)} episodes from cache {cache_path}")
                    return
                logger.info("[OpenAoE->Motus] Index cache config mismatch, re-indexing...")
            except Exception as e:
                logger.warning(f"[OpenAoE->Motus] Failed to read index cache ({e}), re-indexing...")

        root = Path(self.dataset_dir)
        if not root.is_dir():
            raise RuntimeError(f"OpenAoE dataset_dir does not exist: {root}")

        for sample_dir in sorted(root.iterdir()):
            if not sample_dir.is_dir():
                continue
            if sample_dir.name.startswith("."):
                continue
            try:
                hands_path = sample_dir / _REL_HANDS_NPZ
                cam_path = sample_dir / _REL_CAMTRAJ_NPZ
                video_path = self._resolve_video_path(sample_dir)
                if not hands_path.exists() or not cam_path.exists() or video_path is None:
                    self._skipped_missing_files += 1
                    continue

                n_frames = self._peek_frame_count(str(hands_path))
                if n_frames < self._min_required_frames():
                    self._skipped_too_short += 1
                    continue

                self.episodes.append({
                    "sample_dir": str(sample_dir),
                    "video_path": str(video_path),
                    "hands_path": str(hands_path),
                    "cam_path": str(cam_path),
                    "annotation_path": str(sample_dir / _REL_ANNOTATION),
                    "sample_name": sample_dir.name,
                    "n_frames": int(n_frames),
                })
                if max_episodes is not None and len(self.episodes) >= max_episodes:
                    break
            except Exception as e:
                self._skipped_other_error += 1
                if len(self._skipped_other_error_samples) < 3:
                    self._skipped_other_error_samples.append(f"{sample_dir}: {e}")

        if self.episodes:
            try:
                with open(cache_path, "w") as f:
                    json.dump({
                        "min_frames": self._min_required_frames(),
                        "video_source": self.video_source,
                        "episodes": self.episodes,
                    }, f)
                logger.info(f"[OpenAoE->Motus] Cached {len(self.episodes)} episodes to {cache_path}")
            except Exception as e:
                logger.warning(f"[OpenAoE->Motus] Failed to write index cache: {e}")

    def _resolve_video_path(self, sample_dir: Path) -> Optional[Path]:
        """Pick the configured video, optionally falling back to the other one."""
        preferred = sample_dir / (_REL_VIDEO_UNDIST if self.video_source == "undistorted" else _REL_VIDEO_RAW)
        if preferred.exists():
            return preferred
        if not self.allow_video_fallback:
            return None
        other = sample_dir / (_REL_VIDEO_RAW if self.video_source == "undistorted" else _REL_VIDEO_UNDIST)
        return other if other.exists() else None

    @staticmethod
    def _peek_frame_count(hands_path: str) -> int:
        """Read only ``pred_valid`` (2,T) to get the frame count cheaply."""
        with np.load(hands_path) as f:
            if "pred_valid" in f.files:
                return int(np.asarray(f["pred_valid"]).shape[-1])
            if "pred_trans" in f.files:
                return int(np.asarray(f["pred_trans"]).shape[1])
        raise KeyError("hands.npz missing pred_valid / pred_trans")

    # ------------------------------------------------------------------
    # Raw reads
    # ------------------------------------------------------------------
    def _read_episode(self, ep: Dict[str, Any]) -> Tuple[Dict[str, np.ndarray], Dict[str, np.ndarray]]:
        hands = _load_npz_cached(ep["hands_path"])
        cam = _load_npz_cached(ep["cam_path"])
        return hands, cam

    def _build_instruction(self, annotation_path: str, anchor_frame: int) -> str:
        if self.instruction_mode == "none":
            return self.default_instruction
        segments = _load_annotation_cached(annotation_path)
        for sf, ef, text in segments:
            if sf <= anchor_frame < ef and text:
                return text
        # Fall back to the temporally nearest annotated segment, then the default.
        best, best_dist = None, None
        for sf, ef, text in segments:
            if not text:
                continue
            dist = 0 if sf <= anchor_frame < ef else min(abs(anchor_frame - sf), abs(anchor_frame - ef))
            if best_dist is None or dist < best_dist:
                best, best_dist = text, dist
        return best or self.default_instruction

    # ------------------------------------------------------------------
    # Unified EEF extraction (shared math with VITRA / EgoDex / Xperience)
    # ------------------------------------------------------------------
    def _extract_unified_eef_action_state(
        self, ep: Dict[str, Any], frame_start: int
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray, str]:
        """Extract unified EEF camera-delta action and state for one window.

        Returns:
            action: (F, 16) unified action sequence
            state: (16,) unified state
            action_valid_mask: (F, 16) per-dim validity mask
            instruction: str
        """
        hands, cam = self._read_episode(ep)
        self._total_samples += 1

        cam_c2w = np.asarray(cam["cam_c2w"], dtype=np.float64)     # (T,4,4) camera->world
        pred_trans = np.asarray(hands["pred_trans"], dtype=np.float64)  # (2,T,3) world
        pred_rot = np.asarray(hands["pred_rot"], dtype=np.float64)      # (2,T,3) world axis-angle
        pred_valid = np.asarray(hands["pred_valid"])                    # (2,T)

        if cam_c2w.ndim != 3 or cam_c2w.shape[1:] != (4, 4):
            raise ValueError(f"cam_c2w has unexpected shape {cam_c2w.shape}")
        if pred_trans.shape[0] != 2 or pred_rot.shape[0] != 2 or pred_valid.shape[0] != 2:
            raise ValueError("hands.npz arrays must have a leading two-hand axis")

        N = min(cam_c2w.shape[0], pred_trans.shape[1], pred_rot.shape[1], pred_valid.shape[1])
        if N <= 0:
            raise ValueError("empty episode")

        # Window frame indices (stride-aware), clipped to the episode and
        # padded by repeating the last valid index — the video window below
        # uses the SAME index list, so frames and poses stay aligned.
        W = self.num_video_frames + 1
        win = [min(frame_start + i * self.frame_stride, N - 1) for i in range(W)]
        win_arr = np.asarray(win, dtype=np.int64)

        # Per-hand world poses over the window.
        def _hand_window(h: int) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
            t_w_e = pred_trans[h][win_arr]                     # (W,3)
            rotvec = pred_rot[h][win_arr]                      # (W,3) axis-angle (world)
            valid = np.asarray(pred_valid[h][win_arr]) > 0.5   # (W,)
            finite = np.all(np.isfinite(t_w_e), axis=1) & np.all(np.isfinite(rotvec), axis=1)
            valid = valid & finite
            # exp_SO3 on non-finite input would raise; zero them out first.
            rotvec_safe = np.where(finite[:, None], rotvec, 0.0)
            R_w_e = R.from_rotvec(rotvec_safe).as_matrix()     # (W,3,3) EEF->world
            t_w_e = np.where(finite[:, None], t_w_e, 0.0)
            return R_w_e, t_w_e, valid

        left_R_w, left_t_w, left_valid = _hand_window(HAND_INDEX_LEFT)
        right_R_w, right_t_w, right_valid = _hand_window(HAND_INDEX_RIGHT)

        # Camera poses over the window; invalidate frames whose pose is broken.
        cam_win = cam_c2w[win_arr]                              # (W,4,4) camera->world
        cam_finite = np.all(np.isfinite(cam_win.reshape(W, -1)), axis=1)
        if not bool(cam_finite[0]):
            raise ValueError(f"non-finite camera pose at anchor frame {win[0]}")
        left_valid = left_valid & cam_finite
        right_valid = right_valid & cam_finite

        if not (bool(left_valid[0]) or bool(right_valid[0])):
            self._skipped_no_hand_data += 1
            raise ValueError("no valid hand at anchor frame")

        # Reference camera = anchor frame camera (camera->world), OpenCV +Z forward.
        R_w_c = cam_win[0, :3, :3]
        t_w_c = cam_win[0, :3, 3]

        actions, action_masks = compute_unified_eef_action_sequence(
            R_w_e_left=left_R_w,
            t_w_e_left=left_t_w,
            R_w_e_right=right_R_w,
            t_w_e_right=right_t_w,
            R_w_c=R_w_c,
            left_valid=left_valid,
            right_valid=right_valid,
            num_action_frames=self.num_video_frames,
        )
        if not np.any(action_masks):
            self._skipped_no_hand_data += 1
            raise ValueError("no valid hand action pairs in window")

        state, _ = compute_unified_eef_state_from_poses(
            R_w_e_left=left_R_w[0],
            t_w_e_left=left_t_w[0],
            R_w_e_right=right_R_w[0],
            t_w_e_right=right_t_w[0],
            R_w_c=R_w_c,
            t_w_c=t_w_c,
            left_valid=bool(left_valid[0]),
            right_valid=bool(right_valid[0]),
        )

        if not np.all(np.isfinite(actions)) or not np.all(np.isfinite(state)):
            self._skipped_nan_hand += 1
            raise ValueError("non-finite unified EEF action/state")

        instruction = self._build_instruction(ep["annotation_path"], int(win[0]))
        return actions, state, action_masks, instruction

    # ------------------------------------------------------------------
    # T5 embedding
    # ------------------------------------------------------------------
    @staticmethod
    def _hash_text(text: str) -> str:
        return hashlib.sha1(text.encode("utf-8")).hexdigest()

    def _get_t5_embedding(self, instruction: str) -> torch.Tensor:
        if self.t5_mode == "none":
            return torch.zeros((512, 4096), dtype=torch.float32)

        key = self._hash_text(instruction)
        path = self.t5_cache_dir / f"{key}.pt"
        if path.exists():
            return torch.load(path, map_location="cpu", weights_only=True).float()

        assert self.t5_encoder is not None
        out = self.t5_encoder([instruction], self.t5_device)
        if isinstance(out, list):
            emb = out[0]
        elif isinstance(out, torch.Tensor):
            emb = out.squeeze(0)
        else:
            raise TypeError(f"Unexpected T5 encoder output: {type(out)}")
        emb = emb.detach().to("cpu").float()

        tmp = self.t5_cache_dir / f".tmp_{key}_{os.getpid()}.pt"
        torch.save(emb, tmp)
        os.replace(tmp, path)
        return emb

    # ------------------------------------------------------------------
    # Video
    # ------------------------------------------------------------------
    def _window_indices(self, ep: Dict[str, Any], frame_start: int) -> List[int]:
        N = int(ep["n_frames"])
        W = self.num_video_frames + 1
        return [min(frame_start + i * self.frame_stride, N - 1) for i in range(W)]

    def _load_frames_window(self, ep: Dict[str, Any], frame_start: int) -> torch.Tensor:
        return load_video_frames(ep["video_path"], self._window_indices(ep, frame_start),
                                 target_size=self.video_size)

    # ------------------------------------------------------------------
    # Debug interface (offline tools only; not used by training)
    # ------------------------------------------------------------------
    def get_debug_sample(self, episode_index: int, frame_start: int,
                         load_video: bool = False) -> Dict[str, Any]:
        """Deterministic extraction with full re-projection metadata.

        ``action`` / ``state`` / ``action_valid_mask`` come from the exact
        training extraction; the extra fields let an offline tool re-project the
        trajectory onto the video (see tools/visualize_openaoe_unified_eef.py).
        """
        ep = self.episodes[episode_index]
        hands, cam = self._read_episode(ep)
        win = self._window_indices(ep, frame_start)
        win_arr = np.asarray(win, dtype=np.int64)

        cam_c2w = np.asarray(cam["cam_c2w"], dtype=np.float64)
        K = np.asarray(cam["intrinsic"], dtype=np.float64) if "intrinsic" in cam else None

        action = state = mask = None
        error = None
        instruction = ""
        try:
            action, state, mask, instruction = self._extract_unified_eef_action_state(ep, frame_start)
        except Exception as e:
            error = f"{type(e).__name__}: {e}"

        out: Dict[str, Any] = {
            "episode_index": int(episode_index),
            "frame_start": int(frame_start),
            "num_video_frames": int(self.num_video_frames),
            "frame_stride": int(self.frame_stride),
            "window_indices": win_arr,
            "sample_name": ep["sample_name"],
            "video_path": ep["video_path"],
            "hands_path": ep["hands_path"],
            "n_frames": int(ep["n_frames"]),
            "K": K,
            "cam_c2w_win": cam_c2w[win_arr],                                        # (W,4,4) cam->world
            # Same key names as the EgoVerse adapter so one offline tool can
            # verify both datasets.
            "R_w_c_win": cam_c2w[win_arr][:, :3, :3],                               # (W,3,3) cam->world
            "t_w_c_win": cam_c2w[win_arr][:, :3, 3],                                # (W,3)
            "R_w_c_ref": cam_c2w[win_arr][0, :3, :3].copy(),
            "t_w_c_ref": cam_c2w[win_arr][0, :3, 3].copy(),
            "left_wrist_world_win": np.asarray(hands["pred_trans"], dtype=np.float64)[HAND_INDEX_LEFT][win_arr],
            "right_wrist_world_win": np.asarray(hands["pred_trans"], dtype=np.float64)[HAND_INDEX_RIGHT][win_arr],
            "left_valid_win": np.asarray(hands["pred_valid"])[HAND_INDEX_LEFT][win_arr] > 0.5,
            "right_valid_win": np.asarray(hands["pred_valid"])[HAND_INDEX_RIGHT][win_arr] > 0.5,
            "action": None if action is None else np.asarray(action, dtype=np.float64),
            "state": None if state is None else np.asarray(state, dtype=np.float64),
            "action_valid_mask": None if mask is None else np.asarray(mask, dtype=bool),
            "error": error,
            "instruction": instruction,
        }
        if load_video:
            out["frames"] = self._load_frames_window(ep, frame_start)
        return out

    # ------------------------------------------------------------------
    # __len__ / __getitem__
    # ------------------------------------------------------------------
    def __len__(self) -> int:
        return len(self.episodes)

    @property
    def effective_len(self) -> int:
        """Episodes that survived indexing — used by ``auto_weight``."""
        return len(self.episodes)

    def get_dataset_stats(self) -> Dict[str, Any]:
        return {
            "total_samples": self._total_samples,
            "skipped_no_hand_data": self._skipped_no_hand_data,
            "skipped_nan_hand": self._skipped_nan_hand,
        }

    def __getitem__(self, idx: int) -> Optional[Dict[str, Any]]:
        for _ in range(self.max_attempts):
            try:
                ep = self.episodes[random.randint(0, len(self.episodes) - 1)]
                max_start = max(0, int(ep["n_frames"]) - self._min_required_frames())
                frame_start = random.randint(0, max_start)

                frames = self._load_frames_window(ep, frame_start)
                first_frame = frames[0]
                video_frames = frames[1:]

                action, state, action_valid_mask, instruction = \
                    self._extract_unified_eef_action_state(ep, frame_start)

                action_sequence = torch.tensor(action, dtype=torch.float32)
                current_state = torch.tensor(state, dtype=torch.float32)
                action_valid_mask_tensor = torch.tensor(action_valid_mask, dtype=torch.bool)

                language_embedding = self._get_t5_embedding(instruction)

                vlm_inputs = None
                if self.vlm_processor is not None:
                    from utils.vlm_utils import preprocess_vlm_messages
                    first_frame_pil = tensor_to_pil(first_frame)
                    vlm_inputs = preprocess_vlm_messages(instruction, first_frame_pil, self.vlm_processor)

                return {
                    "first_frame": first_frame,
                    "video_frames": video_frames,
                    "initial_state": current_state,
                    "action_sequence": action_sequence,
                    "language_embedding": language_embedding,
                    "vlm_inputs": vlm_inputs,
                    "action_valid_mask": action_valid_mask_tensor,
                    "task_name": "openaoe",
                }
            except Exception as e:
                logger.warning(f"[OpenAoE->Motus] sample retry due to error: {e}")
                continue
        return None

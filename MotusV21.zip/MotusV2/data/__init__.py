# Data package for Motus

# Cross-dataset T5 encoder singleton.
# UMT5-XXL is ~4.7B params (~9.4 GB in bf16).  When training with multiple
# datasets (VITRA, EgoDex, Xperience), each was loading its own copy,
# burning ~28 GB per GPU just for T5 encoders.  This module provides a
# single shared instance that all datasets can reuse.
#
# Usage:
#   from data import get_global_t5_encoder
#   encoder = get_global_t5_encoder(wan_path, t5_text_len, t5_device)

import os
import torch
import logging

logger = logging.getLogger(__name__)

_GLOBAL_T5_ENCODER = None
_GLOBAL_T5_CONFIG = None


def get_global_t5_encoder(wan_path: str, t5_text_len: int, t5_device: str,
                          precision: str = "bfloat16"):
    """Get or create a singleton T5EncoderModel shared across ALL datasets.

    This prevents loading multiple copies of UMT5-XXL (~10.6 GB in bf16,
    ~21.2 GB in fp32) when using multiple dataset types in a mixed training setup.

    Args:
        wan_path: Path to WAN pretrained models directory containing
            ``Wan2.2-TI2V-5B/``.
        t5_text_len: Maximum text sequence length for T5.
        t5_device: Device string (e.g. "cuda", "cpu").
        precision: "bfloat16" (default) or "float32".

            UMT5 omits the usual 1/sqrt(d) attention scaling, so its logits are
            large and bf16 resolves them poorly: cuBLAS picks a different
            reduction per batch size, and the same text encoded at batch=1 vs
            batch=8 differs by ~20% relative (cosine 0.98).  That is harmless as
            long as everything encodes the same way, but it means a cache built
            in batches disagrees with inference, which encodes one at a time.
            float32 removes the batch dependence (~1e-6), which is what makes
            batched cache generation safe.  Whichever is chosen must be used for
            BOTH cache generation and inference.

    Returns:
        T5EncoderModel instance.
    """
    global _GLOBAL_T5_ENCODER, _GLOBAL_T5_CONFIG

    import sys
    from pathlib import Path
    BAK_ROOT = str((Path(__file__).resolve().parent.parent / "bak").resolve())
    if BAK_ROOT not in sys.path:
        sys.path.insert(0, BAK_ROOT)
    from wan.modules.t5 import T5EncoderModel

    if precision not in ("bfloat16", "float32"):
        raise ValueError(f"t5 precision must be 'bfloat16' or 'float32', got {precision!r}")
    config_key = (wan_path, t5_text_len, t5_device, precision)

    if _GLOBAL_T5_ENCODER is not None and _GLOBAL_T5_CONFIG == config_key:
        return _GLOBAL_T5_ENCODER

    # Release previous encoder if config changed
    if _GLOBAL_T5_ENCODER is not None:
        del _GLOBAL_T5_ENCODER
        torch.cuda.empty_cache()
        logger.info("[GlobalT5] Released previous T5EncoderModel singleton")

    ckpt = os.path.join(wan_path, "Wan2.2-TI2V-5B", "models_t5_umt5-xxl-enc-bf16.pth")
    tok = os.path.join(wan_path, "Wan2.2-TI2V-5B", "google/umt5-xxl")
    _GLOBAL_T5_ENCODER = T5EncoderModel(
        text_len=t5_text_len,
        dtype=getattr(torch, precision),
        device=t5_device,
        checkpoint_path=ckpt,
        tokenizer_path=tok,
    )
    _GLOBAL_T5_CONFIG = config_key
    logger.info(f"[GlobalT5] Created shared T5EncoderModel singleton on {t5_device} ({precision})")
    return _GLOBAL_T5_ENCODER


def encode_texts(encoder, texts, device, dynamic: bool = True):
    """Encode a list of texts, optionally padding to the batch's longest sequence.

    ``T5EncoderModel.__call__`` always pads to its ``text_len`` (512), which makes
    batching pointless and memory-hungry: the attention matrix is [B, heads, 512,
    512], so batch=64 in float32 needs ~4 GB per layer and OOMs next to the 21 GB
    of weights.  Real instructions are 5-20 tokens, so padding to the batch max
    instead is both far cheaper and -- in float32 -- numerically equivalent, since
    padded keys are masked out anyway.

    Returns a list of ``[num_tokens, 4096]`` tensors, same as the encoder.
    """
    kwargs = {"padding": True, "truncation": True, "max_length": encoder.text_len} if dynamic else {}
    ids, mask = encoder.tokenizer(texts, return_mask=True, add_special_tokens=True, **kwargs)
    ids, mask = ids.to(device), mask.to(device)
    seq_lens = mask.gt(0).sum(dim=1).long()
    context = encoder.model(ids, mask)
    return [u[:v] for u, v in zip(context, seq_lens)]


def release_global_t5_encoder():
    """Release the global T5 encoder to free GPU memory.

    Call this after all datasets have been initialized and T5 embeddings
    have been cached to disk.  In disk_cache mode, the encoder is only
    needed during dataset init, not during training.
    """
    global _GLOBAL_T5_ENCODER, _GLOBAL_T5_CONFIG
    if _GLOBAL_T5_ENCODER is not None:
        del _GLOBAL_T5_ENCODER
        _GLOBAL_T5_ENCODER = None
        _GLOBAL_T5_CONFIG = None
        torch.cuda.empty_cache()
        logger.info("[GlobalT5] Released T5EncoderModel singleton, GPU memory freed")

"""
Xperience 10M Dataset Adapter for MotusV2.

Supports the unified_eef_camera_delta_wrist16 action mode.

Data layout:
    <data_root>/
        <uuid>/<epN>/
            annotation.hdf5
            stereo_left.mp4
            stereo_right.mp4

HDF5 fields used:
    hand_mocap/left_translation:  (N, 3)  - left wrist position (see COORD FRAME note)
    hand_mocap/left_mano_hand_global_orient: (N, 9) - left wrist 3x3 rotation flattened
    hand_mocap/right_translation: (N, 3)  - right wrist position
    hand_mocap/right_mano_hand_global_orient: (N, 9) - right wrist 3x3 rotation flattened
    slam/trans_xyz: (N, 3) - SLAM body position in world
    slam/quat_wxyz: (N, 4) - SLAM body orientation in world (WXYZ)
    calibration/cam01/T_c0_b: (4, 4) - rectified stereo-left (cam01) extrinsic
        (body -> cam01: p_cam01 = T_c0_b @ p_body).  cam01 is the virtual pinhole
        camera whose image is rendered in stereo_left.mp4 (512x512, K=[fx,fy,cx,cy]).
    calibration/cam0/T_c_b: (4, 4) - raw fisheye cam0 extrinsic (NOT the video frame).
    caption: JSON string with task descriptions

COORD FRAME (verified empirically, see tools/visualize_xperience_unified_eef.py):
    The hand_mocap translation *and* global_orient are expressed in the
    PER-FRAME rectified stereo-left camera frame (cam01) at each timestamp --
    i.e. the same frame that stereo_left.mp4 is rendered in -- NOT in the SLAM
    world frame.  Projecting the raw hand translation directly with the cam01
    intrinsics tracks the visible hand across the whole clip (100% depth>0),
    whereas treating it as a world point and going world->camera via SLAM puts
    the hand behind the camera on ~100% of frames.

    Therefore the pipeline (1) lifts each per-frame camera-frame hand pose to a
    true world pose using the per-frame cam01 pose T_w_cam01(t) = T_w_body(t) @
    inv(T_c0_b), and (2) uses cam01 at the anchor frame as the reference camera.
    The existing unified-eef action/state math then produces the correct
    first-frame-camera delta representation.

Action representation: unified_eef_camera_delta_wrist16
    16D = [left_delta_xyz_cam(3), left_delta_rotvec_cam(3), 0, 0,
           right_delta_xyz_cam(3), right_delta_rotvec_cam(3), 0, 0]

Camera reference: cam01 (rectified stereo-left, == stereo_left.mp4) at the anchor
frame, derived from SLAM + calibration/cam01/T_c0_b.
"""

import os
import random
import json
import logging
import hashlib
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import h5py
import numpy as np
import torch
import torch.utils.data as data

from data.utils.image_utils import resize_with_padding, load_video_frames, tensor_to_pil
from data.human.unified_eef_action import (
    build_hand_world_poses_from_rotmat,
    build_hand_world_poses_from_camera_frame,
    build_camera_world_pose_from_slam,
    compute_unified_eef_action_sequence,
    compute_unified_eef_state_from_poses,
    UNIFIED_EEF_ACTION_DIM,
    UNIFIED_EEF_STATE_DIM,
)

logger = logging.getLogger(__name__)

_FRAME_ALIGNED_REQUIRED_KEYS = (
    "hand_mocap/left_translation",
    "hand_mocap/left_mano_hand_global_orient",
    "hand_mocap/right_translation",
    "hand_mocap/right_mano_hand_global_orient",
    "slam/trans_xyz",
    "slam/quat_wxyz",
)
# cam01 (rectified stereo-left) is the camera whose image is stereo_left.mp4 and
# is the frame the hand mocap is expressed in; it is what we actually need.
# cam0 (fisheye) is still read for debugging/metadata but is not the video frame.
_REQUIRED_HDF5_KEYS = _FRAME_ALIGNED_REQUIRED_KEYS + (
    "calibration/cam01/T_c0_b",
    "calibration/cam0/T_c_b",
)


def _get_shared_t5_encoder(wan_path: str, t5_text_len: int, t5_device: str):
    """Delegate to the global cross-dataset T5 singleton in data/__init__.py."""
    from data import get_global_t5_encoder
    return get_global_t5_encoder(wan_path, t5_text_len, t5_device)


class XperienceMotusDataset(data.Dataset):
    """
    Xperience 10M dataset adapter producing Motus-compatible samples.

    Currently supports:
      action_mode="unified_eef_camera_delta_wrist16":
        action_sequence: [F, 16], initial_state: [16]
        Layout: [left_delta_xyz_cam(3), left_delta_rotvec_cam(3), 0, 0,
                 right_delta_xyz_cam(3), right_delta_rotvec_cam(3), 0, 0]
    """

    def __init__(
        self,
        dataset_dir: str,
        *,
        num_video_frames: int = 8,
        video_size: Tuple[int, int] = (384, 320),
        # Action mode
        action_mode: str = "unified_eef_camera_delta_wrist16",
        # Camera / extrinsics config
        reference_camera_key: str = "cam0",
        require_camera_extrinsics: bool = True,
        allow_base_relative_fallback: bool = False,
        # VLM
        vlm_checkpoint_path: Optional[str] = None,
        # T5 embedding
        t5_mode: str = "disk_cache",
        wan_path: str = "./pretrained_models",
        t5_cache_dir: str = "./t5_cache_xperience",
        t5_text_len: int = 512,
        t5_device: str = "cuda",
        # Sampling
        max_episodes: Optional[int] = None,
        max_attempts: int = 8,
        val: bool = False,
        **kwargs: Any,
    ) -> None:
        super().__init__()
        self.dataset_dir = str(dataset_dir)
        self.num_video_frames = int(num_video_frames)
        self.video_size = video_size
        self.action_mode = action_mode
        self.reference_camera_key = reference_camera_key
        self.require_camera_extrinsics = require_camera_extrinsics
        self.allow_base_relative_fallback = allow_base_relative_fallback
        self.max_attempts = int(max_attempts)
        self.val = val

        if self.action_mode not in ("unified_eef_camera_delta_wrist16",):
            raise ValueError(
                f"Xperience dataset currently only supports "
                f"action_mode='unified_eef_camera_delta_wrist16', "
                f"got '{self.action_mode}'"
            )

        # Currently only cam0 (stereo_left) is implemented.
        if self.reference_camera_key != "cam0":
            raise ValueError(
                f"reference_camera_key must be 'cam0' (stereo_left), "
                f"got '{self.reference_camera_key}'. "
                f"Other camera keys are not yet implemented."
            )
        if self.allow_base_relative_fallback:
            raise NotImplementedError(
                "allow_base_relative_fallback is not implemented for Xperience. "
                "Set allow_base_relative_fallback=False."
            )

        self._action_dim = UNIFIED_EEF_ACTION_DIM  # 16
        self._state_dim = UNIFIED_EEF_STATE_DIM    # 16

        # Statistics counters (initialized before indexing so _index_episodes
        # can accumulate skip reasons into them).
        self._skipped_no_extrinsics = 0
        self._skipped_missing_keys = 0
        self._skipped_too_short = 0
        self._skipped_other_error = 0
        self._skipped_other_error_samples: List[str] = []
        # Per-sample (runtime) skip counters, used in __getitem__ / stats.
        self._skipped_no_hand_data = 0
        self._skipped_nan_hand = 0
        self._total_samples = 0

        # Index all episodes
        self.episodes: List[Dict[str, Any]] = []
        self._index_episodes(max_episodes)

        if len(self.episodes) == 0:
            raise RuntimeError(f"No valid Xperience episodes found in {dataset_dir}")

        # Summarize skipped episodes in a single line instead of one WARNING
        # per file (the dataset legitimately contains many episodes without a
        # SLAM track, which flood the logs across every rank).
        total_scanned = (
            len(self.episodes)
            + self._skipped_no_extrinsics
            + self._skipped_missing_keys
            + self._skipped_too_short
            + self._skipped_other_error
        )
        if total_scanned:
            skip_parts = [
                f"missing_keys={self._skipped_missing_keys}",
                f"no_extrinsics={self._skipped_no_extrinsics}",
                f"too_short={self._skipped_too_short}",
                f"other_error={self._skipped_other_error}",
            ]
            logger.info(
                f"[Xperience->Motus] Indexing done: kept {len(self.episodes)}/{total_scanned} "
                f"episodes (skipped {total_scanned - len(self.episodes)}: "
                + ", ".join(p for p in skip_parts if not p.endswith("=0")) + ")"
            )
        if self._skipped_other_error_samples:
            # Keep a few representative paths for unexpected errors so they stay debuggable.
            for p in self._skipped_other_error_samples[:3]:
                logger.warning(f"[Xperience->Motus] Example other_error skip: {p}")

        logger.info(
            f"[Xperience->Motus] Indexed {len(self.episodes)} episodes, "
            f"action_mode={self.action_mode}, "
            f"action_dim={self._action_dim}, state_dim={self._state_dim}, "
            f"reference_camera_key={self.reference_camera_key}"
        )

        # VLM processor
        self.vlm_processor = None
        if vlm_checkpoint_path:
            from transformers import AutoProcessor
            self.vlm_processor = AutoProcessor.from_pretrained(vlm_checkpoint_path)

        # T5 embedding
        self.t5_mode = t5_mode
        self.t5_cache_dir = Path(t5_cache_dir)
        self.t5_cache_dir.mkdir(parents=True, exist_ok=True)
        self.t5_encoder = None
        self.t5_device = t5_device
        if self.t5_mode == "disk_cache":
            self.t5_encoder = _get_shared_t5_encoder(wan_path, t5_text_len, t5_device)
        elif self.t5_mode == "none":
            logger.warning("[Xperience->Motus] t5_mode=none: language_embedding will be zeros")

    # ------------------------------------------------------------------
    # Episode indexing
    # ------------------------------------------------------------------
    def _index_episodes(self, max_episodes: Optional[int]):
        root = Path(self.dataset_dir)
        for seq_dir in sorted(root.iterdir()):
            if not seq_dir.is_dir():
                continue
            for ep_dir in sorted(seq_dir.iterdir()):
                if not ep_dir.is_dir() or not ep_dir.name.startswith("ep"):
                    continue
                h5_path = ep_dir / "annotation.hdf5"
                mp4_path = ep_dir / "stereo_left.mp4"
                if not h5_path.exists() or not mp4_path.exists():
                    continue
                try:
                    n_frames, has_calib = self._get_frame_count_and_calib(str(h5_path))
                    if n_frames < self.num_video_frames + 1:
                        self._skipped_too_short += 1
                        continue
                    if not has_calib:
                        self._skipped_no_extrinsics += 1
                        continue
                    self.episodes.append({
                        "h5_path": str(h5_path),
                        "mp4_path": str(mp4_path),
                        "seq_name": seq_dir.name,
                        "ep_name": ep_dir.name,
                        "n_frames": n_frames,
                    })
                    if max_episodes is not None and len(self.episodes) >= max_episodes:
                        return
                except KeyError as e:
                    # Missing required HDF5 keys (e.g. slam/* when an episode has
                    # no SLAM track) — expected for a known fraction of the
                    # dataset; count silently and summarize at the end.
                    self._skipped_missing_keys += 1
                except Exception as e:
                    # Unexpected error — count it and keep a few sample paths
                    # for debugging without flooding the log per-file.
                    self._skipped_other_error += 1
                    if len(self._skipped_other_error_samples) < 3:
                        self._skipped_other_error_samples.append(f"{h5_path}: {e}")

    @staticmethod
    def _get_frame_count_and_calib(h5_path: str) -> Tuple[int, bool]:
        """Return (frame_count, has_calibration).

        has_calibration is True only when ``calibration/cam01/T_c0_b`` (the
        rectified stereo-left camera == stereo_left.mp4, the frame the hand mocap
        lives in) exists and contains finite values.
        """
        with h5py.File(h5_path, "r") as f:
            missing = [key for key in _REQUIRED_HDF5_KEYS if key not in f]
            if missing:
                raise KeyError(f"missing required HDF5 keys: {missing}")

            frame_counts = {}
            for key in _FRAME_ALIGNED_REQUIRED_KEYS:
                ds = f[key]
                if ds.ndim == 0:
                    raise ValueError(f"{key} must be frame-aligned, got scalar dataset")
                frame_counts[key] = int(ds.shape[0])

            n_frames = min(frame_counts.values())
            if n_frames <= 0:
                raise ValueError(f"non-positive frame count from required keys: {frame_counts}")

            T_c0_b = f["calibration/cam01/T_c0_b"][:]
            has_calib = bool(
                T_c0_b is not None
                and T_c0_b.shape == (4, 4)
                and np.all(np.isfinite(T_c0_b))
            )
            return n_frames, has_calib

    # ------------------------------------------------------------------
    # Data loading helpers
    # ------------------------------------------------------------------
    def _load_frames_window(self, mp4_path: str, frame_start: int) -> torch.Tensor:
        frame_indices = list(range(frame_start, frame_start + self.num_video_frames + 1))
        return load_video_frames(mp4_path, frame_indices, target_size=self.video_size)

    def _read_annotation(self, h5_path: str, frame_idx: int):
        """Read raw annotation data from HDF5 for a window of frames."""
        with h5py.File(h5_path, "r") as f:
            missing = [key for key in _REQUIRED_HDF5_KEYS if key not in f]
            if missing:
                raise KeyError(f"missing required HDF5 keys: {missing}")

            # Hand poses in world frame
            left_trans = f["hand_mocap/left_translation"][:]    # (N, 3)
            left_orient = f["hand_mocap/left_mano_hand_global_orient"][:]  # (N, 9)
            right_trans = f["hand_mocap/right_translation"][:]  # (N, 3)
            right_orient = f["hand_mocap/right_mano_hand_global_orient"][:]  # (N, 9)

            # SLAM (body pose in world)
            slam_trans = f["slam/trans_xyz"][:]    # (N, 3)
            slam_quat = f["slam/quat_wxyz"][:]     # (N, 4) WXYZ

            # Camera calibration.
            # cam01 = rectified stereo-left (the frame of stereo_left.mp4 AND of
            #         the hand mocap). This is the one we actually use.
            # cam0  = raw fisheye camera, kept only for debugging/metadata.
            T_c_b = f["calibration/cam0/T_c_b"][:]  # (4, 4) body -> fisheye cam0
            T_c0_b = None
            if "calibration/cam01/T_c0_b" in f:
                T_c0_b = f["calibration/cam01/T_c0_b"][:]  # (4, 4) body -> cam01

            # Caption / instruction
            instruction = ""
            if "caption" in f:
                caption_raw = f["caption"][()]
                if isinstance(caption_raw, bytes):
                    caption_raw = caption_raw.decode("utf-8")
                try:
                    caption_data = json.loads(caption_raw)
                    instruction = caption_data.get("config", {}).get("Main Task", "")
                    if not instruction:
                        # Fallback: use first segment's Sub Task
                        segments = caption_data.get("segments", [])
                        if segments:
                            instruction = segments[0].get("Sub Task", "")
                except (json.JSONDecodeError, AttributeError, TypeError):
                    instruction = ""

        return (left_trans, left_orient, right_trans, right_orient,
                slam_trans, slam_quat, T_c_b, T_c0_b, instruction)

    def _extract_unified_eef_action_state(
        self, h5_path: str, frame_idx: int
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray, str]:
        """Extract unified EEF camera-delta action and state.

        Returns:
            action: (F, 16) unified action sequence
            state: (16,) unified state
            action_valid_mask: (F, 16) per-dim validity mask
            instruction: str
        """
        (left_trans, left_orient, right_trans, right_orient,
         slam_trans, slam_quat, T_c_b, T_c0_b, instruction) = self._read_annotation(h5_path, frame_idx)

        self._total_samples += 1

        # cam01 (rectified stereo-left) extrinsics are required: the hand mocap
        # is expressed in the *per-frame* cam01 frame and stereo_left.mp4 is the
        # cam01 image.  cam0 (fisheye) is NOT the video frame.
        if T_c0_b is None or np.any(~np.isfinite(T_c0_b)):
            if self.require_camera_extrinsics and not self.allow_base_relative_fallback:
                self._skipped_no_extrinsics += 1
                raise ValueError("cam01 (stereo_left) extrinsics unavailable and fallback not allowed")

        # Validate SLAM data at the anchor frame
        slam_t_anchor = slam_trans[frame_idx]
        slam_q_anchor = slam_quat[frame_idx]
        if not np.all(np.isfinite(slam_t_anchor)) or not np.all(np.isfinite(slam_q_anchor)):
            self._skipped_no_extrinsics += 1
            raise ValueError(f"SLAM data not finite at frame {frame_idx}")
        q_norm = np.linalg.norm(slam_q_anchor)
        if abs(q_norm - 1.0) > 1e-3:
            self._skipped_no_extrinsics += 1
            raise ValueError(
                f"SLAM quaternion norm {q_norm:.6f} != 1.0 at frame {frame_idx}"
            )

        # Window of frames: frame_idx ... frame_idx + num_video_frames
        win_start = frame_idx
        win_end = frame_idx + self.num_video_frames + 1  # inclusive range for actions
        N = left_trans.shape[0]

        # Clip to valid range
        win_end = min(win_end, N)

        # Hand poses in the PER-FRAME CAMERA (cam01) frame.
        # left_orient is (N, 9) = 3x3 rotation flattened, mapping EEF->camera.
        left_R_c = left_orient.reshape(-1, 3, 3)  # (N, 3, 3)  R_cam(t)_e
        right_R_c = right_orient.reshape(-1, 3, 3)
        left_t_c = left_trans   # (N, 3)  t_cam(t)_e
        right_t_c = right_trans

        # Determine hand validity (not all-zero and finite)
        left_R_det = np.linalg.det(left_R_c.astype(np.float64))
        right_R_det = np.linalg.det(right_R_c.astype(np.float64))
        left_has_data = (
            np.any(np.abs(left_t_c) > 1e-12, axis=1)
            & np.all(np.isfinite(left_t_c), axis=1)
            & np.all(np.isfinite(left_R_c.reshape(-1, 9)), axis=1)
            & np.isfinite(left_R_det)
            & (left_R_det > 0.1)
        )
        right_has_data = (
            np.any(np.abs(right_t_c) > 1e-12, axis=1)
            & np.all(np.isfinite(right_t_c), axis=1)
            & np.all(np.isfinite(right_R_c.reshape(-1, 9)), axis=1)
            & np.isfinite(right_R_det)
            & (right_R_det > 0.1)
        )

        # Check that at least one hand has data in this window
        if not np.any(left_has_data[win_start:win_end]) and not np.any(right_has_data[win_start:win_end]):
            self._skipped_no_hand_data += 1
            raise ValueError("No valid hand data in window")

        # Extract window data (still in the per-frame camera frame)
        left_R_win = left_R_c[win_start:win_end]   # (W, 3, 3)
        left_t_win = left_t_c[win_start:win_end]   # (W, 3)
        right_R_win = right_R_c[win_start:win_end]
        right_t_win = right_t_c[win_start:win_end]
        left_valid_win = left_has_data[win_start:win_end].copy()
        right_valid_win = right_has_data[win_start:win_end].copy()
        slam_t_win = slam_trans[win_start:win_end]
        slam_q_win = slam_quat[win_start:win_end]

        W = left_R_win.shape[0]
        if W < self.num_video_frames + 1:
            # Pad by repeating last frame
            pad_count = self.num_video_frames + 1 - W
            def _pad(a):
                return np.concatenate([a] + [a[-1:]] * pad_count)
            left_R_win = _pad(left_R_win)
            left_t_win = _pad(left_t_win)
            right_R_win = _pad(right_R_win)
            right_t_win = _pad(right_t_win)
            left_valid_win = _pad(left_valid_win)
            right_valid_win = _pad(right_valid_win)
            slam_t_win = _pad(slam_t_win)
            slam_q_win = _pad(slam_q_win)

        # Build per-frame cam01 camera pose in world:
        #   T_w_cam01(t) = T_w_body(t) @ inv(T_c0_b)
        # Frames whose SLAM pose is invalid are marked invalid for both hands so
        # they do not contribute a corrupt anchor/target to the delta.
        Wf = self.num_video_frames + 1
        R_w_c01_win = np.zeros((Wf, 3, 3), dtype=np.float64)
        t_w_c01_win = np.zeros((Wf, 3), dtype=np.float64)
        for j in range(Wf):
            qj = slam_q_win[j]
            tj = slam_t_win[j]
            if not (np.all(np.isfinite(qj)) and np.all(np.isfinite(tj))
                    and abs(np.linalg.norm(qj) - 1.0) < 1e-2):
                R_w_c01_win[j] = np.eye(3)
                t_w_c01_win[j] = 0.0
                left_valid_win[j] = False
                right_valid_win[j] = False
                continue
            R_w_c01_win[j], t_w_c01_win[j] = build_camera_world_pose_from_slam(
                slam_trans=tj, slam_quat_wxyz=qj, T_c_b=T_c0_b,
            )

        if not (bool(left_valid_win[0]) or bool(right_valid_win[0])):
            self._skipped_no_hand_data += 1
            raise ValueError("No valid hand data at anchor frame")

        # Lift the per-frame camera-frame hand poses to TRUE world poses so the
        # existing unified-eef math (which expects world poses + a world->camera
        # reference) produces the correct first-frame-camera delta representation.
        left_R_w_win, left_t_w_win = build_hand_world_poses_from_camera_frame(
            left_R_win, left_t_win, R_w_c01_win, t_w_c01_win)
        right_R_w_win, right_t_w_win = build_hand_world_poses_from_camera_frame(
            right_R_win, right_t_win, R_w_c01_win, t_w_c01_win)

        # Reference camera = cam01 at the anchor frame (frame 0 of the window).
        R_w_c = R_w_c01_win[0]
        t_w_c = t_w_c01_win[0]

        # Compute action sequence
        actions, action_masks = compute_unified_eef_action_sequence(
            R_w_e_left=left_R_w_win,
            t_w_e_left=left_t_w_win,
            R_w_e_right=right_R_w_win,
            t_w_e_right=right_t_w_win,
            R_w_c=R_w_c,
            left_valid=left_valid_win,
            right_valid=right_valid_win,
            num_action_frames=self.num_video_frames,
        )
        if not np.any(action_masks):
            self._skipped_no_hand_data += 1
            raise ValueError("No valid hand action pairs in window")

        # Compute state at frame_idx
        lv = bool(left_valid_win[0])
        rv = bool(right_valid_win[0])
        state, state_mask = compute_unified_eef_state_from_poses(
            R_w_e_left=left_R_w_win[0],
            t_w_e_left=left_t_w_win[0],
            R_w_e_right=right_R_w_win[0],
            t_w_e_right=right_t_w_win[0],
            R_w_c=R_w_c,
            t_w_c=t_w_c,
            left_valid=lv,
            right_valid=rv,
        )

        if not np.all(np.isfinite(actions)) or not np.all(np.isfinite(state)):
            self._skipped_nan_hand += 1
            raise ValueError("Non-finite unified EEF action/state")

        return actions, state, action_masks, instruction

    # ------------------------------------------------------------------
    # T5 embedding
    # ------------------------------------------------------------------
    @staticmethod
    def _hash_text(text: str) -> str:
        return hashlib.sha1(text.encode("utf-8")).hexdigest()

    def _get_t5_embedding(self, instruction: str) -> torch.Tensor:
        if self.t5_mode == "none":
            return torch.zeros((512, 4096), dtype=torch.float32)

        key = self._hash_text(instruction)
        path = self.t5_cache_dir / f"{key}.pt"
        if path.exists():
            return torch.load(path, map_location="cpu", weights_only=True).float()

        assert self.t5_encoder is not None
        out = self.t5_encoder([instruction], self.t5_device)
        if isinstance(out, list):
            emb = out[0]
        elif isinstance(out, torch.Tensor):
            emb = out.squeeze(0)
        else:
            raise TypeError(f"Unexpected T5 encoder output: {type(out)}")
        emb = emb.detach().to("cpu").float()

        tmp = self.t5_cache_dir / f".tmp_{key}_{os.getpid()}.pt"
        torch.save(emb, tmp)
        os.replace(tmp, path)
        return emb

    # ------------------------------------------------------------------
    # __len__ / __getitem__
    # ------------------------------------------------------------------
    def __len__(self) -> int:
        return len(self.episodes)

    @property
    def effective_len(self) -> int:
        """Number of indexed episodes that survived calibration pre-checks.

        Used by ``auto_weight`` to compute sampling weights that reflect
        *actually usable* episodes rather than raw ``len(self)``.
        """
        return len(self.episodes)

    def get_dataset_stats(self) -> Dict[str, Any]:
        """Return statistics about sample processing (for debug logging)."""
        return {
            "total_samples": self._total_samples,
            "skipped_no_extrinsics": self._skipped_no_extrinsics,
            "skipped_no_hand_data": self._skipped_no_hand_data,
            "skipped_nan_hand": self._skipped_nan_hand,
        }

    # ------------------------------------------------------------------
    # Debug / visualization interface (NOT used by the training path).
    #
    # This method is only ever called explicitly by offline tools such as
    # tools/visualize_xperience_unified_eef.py.  It does not touch __getitem__
    # and therefore leaves the default training behaviour and performance
    # completely unchanged.
    # ------------------------------------------------------------------
    def get_debug_sample(
        self,
        episode_index: int,
        frame_start: int,
        load_video: bool = True,
    ) -> Dict[str, Any]:
        """Deterministically extract one window with full re-projection metadata.

        The returned ``action`` / ``state`` / ``action_valid_mask`` are produced by
        the *exact* training extraction (``_extract_unified_eef_action_state``), so
        anything reconstructed from them mirrors what the model is trained on.
        In addition we return the raw per-frame annotation window, the reference
        camera pose, and both the ``cam0`` (fisheye) and ``cam01`` (rectified
        stereo-left / the frame actually rendered in ``stereo_left.mp4``)
        calibrations so callers can re-project the trajectory.

        Args:
            episode_index: Index into ``self.episodes``.
            frame_start: Anchor / window-start frame index (== dataset ``frame_idx``).
            load_video: If True, also decode the ``stereo_left.mp4`` window.

        Returns:
            Dict with keys (all coordinate frames are documented per-field):
              - action:            (F, 16)  training action (camera-delta, per dataset math)
              - state:             (16,)     training state
              - action_valid_mask: (F, 16)
              - error:             Optional[str] set if extraction raised (still
                                   returns raw metadata so the failure is inspectable)
              - window_indices:    (W,) int frame indices, W = F+1
              - left_trans_win / right_trans_win:  (W, 3) raw hand translation
                                   as stored in the HDF5 (SEE ANALYSIS: these are
                                   in the *per-frame camera* frame, not world).
              - left_orient_win / right_orient_win: (W, 3, 3) raw hand rotation
              - left_valid_win / right_valid_win:   (W,) bool
              - slam_trans_win:    (W, 3)  SLAM body position in world
              - slam_quat_win:     (W, 4)  SLAM body orientation in world (WXYZ)
              - T_c_b_cam0:        (4, 4)  body -> fisheye cam0
              - K_cam0:            (4,) [fx, fy, cx, cy] fisheye cam0 (1088x1280)
              - T_c_b_cam01:       (4, 4)  body -> rectified stereo-left cam01
              - K_cam01:           (4,) [fx, fy, cx, cy] rectified cam01 (512x512)
              - R_w_c_ref / t_w_c_ref: reference (anchor) camera pose in world,
                                   built from cam01 exactly like the fixed training
                                   code (falls back to cam0 only if cam01 missing).
              - frames:            (W, 3, H, W) float tensor in [0,1] (dataset resized)
              - first_frame / video_frames: dataset-formatted tensors
              - instruction, seq_name, ep_name, h5_path, mp4_path, n_frames, num_video_frames
        """
        ep = self.episodes[episode_index]
        h5_path = ep["h5_path"]
        mp4_path = ep["mp4_path"]
        F = self.num_video_frames
        W = F + 1
        win = list(range(frame_start, frame_start + W))

        # --- raw annotation (reuse training reader) ---
        (left_trans, left_orient, right_trans, right_orient,
         slam_trans, slam_quat, T_c_b_cam0, T_c_b_cam01_read, instruction) = \
            self._read_annotation(h5_path, frame_start)

        left_R = left_orient.reshape(-1, 3, 3)
        right_R = right_orient.reshape(-1, 3, 3)

        def _hand_valid(t_w, R_w):
            det = np.linalg.det(R_w.astype(np.float64))
            return (
                np.any(np.abs(t_w) > 1e-12, axis=1)
                & np.all(np.isfinite(t_w), axis=1)
                & np.all(np.isfinite(R_w.reshape(-1, 9)), axis=1)
                & np.isfinite(det)
                & (det > 0.1)
            )

        left_valid = _hand_valid(left_trans, left_R)
        right_valid = _hand_valid(right_trans, right_R)

        # --- extra calibration for cam01 (rectified stereo-left = stereo_left.mp4) ---
        K_cam0 = None
        K_cam01 = None
        T_c_b_cam01 = None
        with h5py.File(h5_path, "r") as f:
            if "calibration/cam0/K" in f:
                K_cam0 = f["calibration/cam0/K"][:].astype(np.float64)
            if "calibration/cam01/K" in f:
                K_cam01 = f["calibration/cam01/K"][:].astype(np.float64)
            if "calibration/cam01/T_c0_b" in f:
                T_c_b_cam01 = f["calibration/cam01/T_c0_b"][:].astype(np.float64)
        if T_c_b_cam01 is None and T_c_b_cam01_read is not None:
            T_c_b_cam01 = np.asarray(T_c_b_cam01_read, dtype=np.float64)

        # --- training action/state (reuse exact training math) ---
        action = state = action_valid_mask = None
        error = None
        try:
            action, state, action_valid_mask, _ = \
                self._extract_unified_eef_action_state(h5_path, frame_start)
        except Exception as e:  # keep raw metadata inspectable on skip
            error = f"{type(e).__name__}: {e}"

        # --- reference (anchor) camera pose, built from cam01 exactly like the
        # fixed training code (cam01 == stereo_left.mp4 == hand-mocap frame).
        # Falls back to cam0 only if cam01 calibration is unavailable. ---
        ref_calib = T_c_b_cam01 if T_c_b_cam01 is not None else T_c_b_cam0
        R_w_c_ref, t_w_c_ref = build_camera_world_pose_from_slam(
            slam_trans=slam_trans[frame_start],
            slam_quat_wxyz=slam_quat[frame_start],
            T_c_b=ref_calib,
        )

        result: Dict[str, Any] = {
            "episode_index": int(episode_index),
            "frame_start": int(frame_start),
            "num_video_frames": int(F),
            "window_indices": np.asarray(win, dtype=np.int64),
            "left_trans_win": left_trans[frame_start:frame_start + W].astype(np.float64),
            "right_trans_win": right_trans[frame_start:frame_start + W].astype(np.float64),
            "left_orient_win": left_R[frame_start:frame_start + W].astype(np.float64),
            "right_orient_win": right_R[frame_start:frame_start + W].astype(np.float64),
            "left_valid_win": left_valid[frame_start:frame_start + W],
            "right_valid_win": right_valid[frame_start:frame_start + W],
            "slam_trans_win": slam_trans[frame_start:frame_start + W].astype(np.float64),
            "slam_quat_win": slam_quat[frame_start:frame_start + W].astype(np.float64),
            "T_c_b_cam0": np.asarray(T_c_b_cam0, dtype=np.float64),
            "K_cam0": K_cam0,
            "T_c_b_cam01": T_c_b_cam01,
            "K_cam01": K_cam01,
            "R_w_c_ref": np.asarray(R_w_c_ref, dtype=np.float64),
            "t_w_c_ref": np.asarray(t_w_c_ref, dtype=np.float64),
            "action": None if action is None else np.asarray(action, dtype=np.float64),
            "state": None if state is None else np.asarray(state, dtype=np.float64),
            "action_valid_mask": None if action_valid_mask is None else np.asarray(action_valid_mask, dtype=bool),
            "error": error,
            "instruction": instruction,
            "seq_name": ep.get("seq_name", ""),
            "ep_name": ep.get("ep_name", ""),
            "h5_path": h5_path,
            "mp4_path": mp4_path,
            "n_frames": int(ep["n_frames"]),
        }

        if load_video:
            frames = self._load_frames_window(mp4_path, frame_start)  # (W, 3, H, W) in [0,1]
            result["frames"] = frames
            result["first_frame"] = frames[0]
            result["video_frames"] = frames[1:]

        return result

    def __getitem__(self, idx: int) -> Optional[Dict[str, Any]]:
        for _ in range(self.max_attempts):
            try:
                ep_idx = random.randint(0, len(self.episodes) - 1)
                ep = self.episodes[ep_idx]
                n_frames = ep["n_frames"]
                frame_start = random.randint(0, n_frames - self.num_video_frames - 1)

                # Load video frames
                frames = self._load_frames_window(ep["mp4_path"], frame_start)
                first_frame = frames[0]
                video_frames = frames[1:]

                # Extract unified EEF action/state
                action, state, action_valid_mask, instruction = \
                    self._extract_unified_eef_action_state(ep["h5_path"], frame_start)

                action_sequence = torch.tensor(action, dtype=torch.float32)
                current_state = torch.tensor(state, dtype=torch.float32)
                action_valid_mask_tensor = torch.tensor(action_valid_mask, dtype=torch.bool)

                language_embedding = self._get_t5_embedding(instruction)

                vlm_inputs = None
                if self.vlm_processor is not None:
                    from utils.vlm_utils import preprocess_vlm_messages
                    first_frame_pil = tensor_to_pil(first_frame)
                    vlm_inputs = preprocess_vlm_messages(instruction, first_frame_pil, self.vlm_processor)

                return {
                    "first_frame": first_frame,
                    "video_frames": video_frames,
                    "initial_state": current_state,
                    "action_sequence": action_sequence,
                    "language_embedding": language_embedding,
                    "vlm_inputs": vlm_inputs,
                    "action_valid_mask": action_valid_mask_tensor,
                    "task_name": ep.get("seq_name", "xperience"),
                }

            except Exception as e:
                logger.warning(f"[Xperience->Motus] sample retry due to error: {e}")
                continue

        return None

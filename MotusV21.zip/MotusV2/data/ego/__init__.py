"""FastEgo human-hand data retargeted into the G1-D Cartesian action space."""

from .ego_dataset import EgoRetargetDataset

__all__ = ["EgoRetargetDataset"]

"""FastEgo human-hand dataset, retargeted into the G1-D Cartesian action space.

The retarget pipeline (see EGO_TO_G1D.md next to the dataset) already wrote a
16-dim ``eef16`` per frame in exactly the layout G1-D uses -- same per-arm block
``[xyz(3), rotvec(3), reserved(1), gripper(1)]``, same gripper slots 7/15, same
torso-style reference frame, gripper quantile-mapped into G1-D's own units. So
this class does no retargeting; it reads those arrays and presents them through
the same sample contract ``G1DLeRobotDataset`` produces, which is what lets the
two be mixed in one batch.

Three things genuinely differ from G1-D and are handled here:

* **Frame rate varies by capture batch.** The first ego package is 60 Hz, the
  second is 30 Hz. ``self.fps`` is therefore *resolved from the package*, exactly
  as ``G1DLeRobotDataset`` resolves its own from ``meta/info.json`` -- it must not
  be assumed, because ``_decode_video_frames_pyav`` uses it to convert a frame
  index into a presentation timestamp. Getting it wrong does not merely warn: at
  2x the true rate, odd condition frames match nothing ("Decoded 0 frames") while
  even ones silently return the frame at *half* the intended time. Every video's
  container rate is cross-checked against it at construction so that mismatch is
  a startup error instead of corrupt training data.
  At 60 Hz pass ``global_downsample_rate=2`` for a chunk to cover the same
  wall-clock span as G1-D at rate 1; at 30 Hz rate 1 already matches.
* **Sparse validity.** Only 31.4% of ego frames have both hands tracked. Windows
  are pre-indexed so a chunk is only ever drawn from a stretch where both hands
  are valid from the condition frame through the last action.
* **One fisheye camera vs three.** The frame goes into the same top sub-region
  that G1-D fills with ``cam_left_high``; the two wrist sub-regions stay black.
  Keeping the head view in the same pixels in both datasets is the point.
"""

import json
import logging
import os
import random
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import torch

from data.g1d.eef_actions import select_episodes, to_delta
from data.g1d.g1d_dataset import G1DLeRobotDataset
from data.utils.image_utils import resize_with_padding
from utils.vlm_utils import preprocess_vlm_messages

logger = logging.getLogger(__name__)


class EgoRetargetDataset(G1DLeRobotDataset):
    """Ego sessions served in G1-D's action space and sample format."""

    # Fallback only, for a package that records its rate nowhere. The first ego
    # batch is 60 Hz; the second is 30 Hz and declares it in dataset_manifest.json.
    EGO_FPS = 60
    # Sub-region shapes G1-D's cameras produce, so the ego frame lands in the
    # exact pixels G1-D puts cam_left_high in. Hardcoded rather than measured
    # because the ego dataset has no such cameras to measure.
    G1D_TOP_CAM_HW = (480, 640)
    G1D_WRIST_CAM_HW = (480, 640)

    def __init__(
        self,
        dataset_dir: str,
        *,
        num_video_frames: int = 8,
        video_size: Tuple[int, int] = (384, 320),
        global_downsample_rate: int = 2,
        video_action_freq_ratio: int = 2,
        max_episodes: Optional[int] = None,
        episode_seed: Optional[int] = None,
        episode_subset: str = "all",
        image_aug: bool = False,
        val: bool = False,
        instruction: str = "",
        action_mode: str = "eef_delta",
        normalization: bool = False,
        normalization_stats_path: Optional[str] = None,
        normalization_mode: str = "standard",
        vlm_checkpoint_path: Optional[str] = None,
        vlm_type: str = "qwen3_vl",
        t5_mode: str = "disk_cache",
        wan_path: Optional[str] = None,
        t5_cache_dir: str = "./t5_cache_g1d",
        t5_text_len: int = 512,
        t5_device: str = "cuda",
        allow_t5_cache_miss_zero: bool = False,
        **kwargs: Any,
    ) -> None:
        torch.utils.data.Dataset.__init__(self)

        self.dataset_dir = str(dataset_dir)
        self.root = Path(dataset_dir)
        self.num_video_frames = int(num_video_frames)
        self.video_size = video_size
        self.global_downsample_rate = int(global_downsample_rate)
        self.video_action_freq_ratio = int(video_action_freq_ratio)
        self.action_chunk_size = self.num_video_frames * self.video_action_freq_ratio
        self.max_episodes = max_episodes
        self.episode_seed = episode_seed
        self.episode_subset = episode_subset
        self.image_aug = bool(image_aug) and not val
        self.val = bool(val)
        self.fps = self._resolve_fps()
        self.instruction = instruction

        if action_mode not in ("eef", "eef_delta"):
            raise ValueError(
                f"ego data only exists in the Cartesian space, so action_mode must be "
                f"'eef' or 'eef_delta', got {action_mode!r}"
            )
        self.action_mode = action_mode
        self.is_eef = True
        self.normalization = bool(normalization)
        self.normalization_mode = str(normalization_mode)
        # Deliberately G1-D's statistics: the retarget aligned ego onto G1-D's
        # distribution, so normalising the two with different constants would
        # pull them back apart in exactly the dimension the alignment fixed.
        self.state_normalizer, self.action_normalizer = self._load_normalizers(
            normalization_stats_path
        )

        self.action_dim = self.ACTION_DIM
        self.state_dim = self.STATE_DIM

        self.episodes: List[Dict[str, Any]] = []
        self._index_sessions()
        if not self.episodes:
            # Separate "nothing to read" from "read it, nothing was usable": the
            # first is a path or retarget problem, the second is a chunk-length
            # problem, and they have completely different fixes.
            n_found = len(list(self.root.glob("sessions/*/retarget_eef16.npz")))
            if n_found == 0:
                raise RuntimeError(
                    f"No ego sessions under {self.root}/sessions/*/retarget_eef16.npz. "
                    f"Check dataset_dir, and that the retarget has been run "
                    f"(h2g.retarget_ego --write)."
                )
            raise RuntimeError(
                f"{n_found} ego sessions in {dataset_dir} but none has a stretch of "
                f"{self._required_span()} frames with both hands valid. Lower "
                f"video_action_freq_ratio or global_downsample_rate."
            )

        total_windows = sum(len(ep["starts"]) for ep in self.episodes)
        logger.info(
            f"EgoRetargetDataset: {len(self.episodes)} sessions, {total_windows} both-hands-valid "
            f"windows (fps={self.fps}, chunk={self.action_chunk_size}, "
            f"ds={self.global_downsample_rate}, span={self._required_span()} frames "
            f"= {self._required_span() / self.fps:.2f}s, action_mode={self.action_mode}, "
            f"normalization={self.normalization})"
        )

        self._init_text_stack(
            vlm_checkpoint_path=vlm_checkpoint_path,
            vlm_type=vlm_type,
            t5_mode=t5_mode,
            t5_cache_dir=t5_cache_dir,
            t5_text_len=t5_text_len,
            t5_device=t5_device,
            allow_t5_cache_miss_zero=allow_t5_cache_miss_zero,
            wan_path=wan_path,
        )

    # ------------------------------------------------------------------
    # Session index
    # ------------------------------------------------------------------
    def _resolve_fps(self) -> float:
        """Output rate of this ego package, in order of authority.

        ``dataset_manifest.json`` first, mirroring how ``G1DLeRobotDataset`` reads
        ``meta/info.json``; then the recorded timestamps, which every package has;
        then :attr:`EGO_FPS`. Timestamps are snapped to the nearest integer rate
        because a measured 60.0312 Hz would slowly drift the pts->index mapping.
        """
        manifest = self.root / "dataset_manifest.json"
        if manifest.exists():
            try:
                fps = json.load(open(manifest)).get("fps")
                if fps:
                    return float(fps)
            except Exception:
                pass
        for npz_path in sorted(self.root.glob("sessions/*/retarget_eef16.npz")):
            try:
                with np.load(npz_path) as d:
                    ts = np.asarray(d["timestamp_ros_s"], dtype=np.float64)
            except Exception:
                continue
            dt = np.diff(ts)
            dt = dt[np.isfinite(dt) & (dt > 0)]
            if dt.size:
                return float(round(1.0 / float(np.median(dt))))
        return float(self.EGO_FPS)

    def _assert_video_rate(self, video_path: Path) -> Optional[float]:
        """Container frame rate, or None if it cannot be read.

        ``_decode_video_frames_pyav`` maps index <-> timestamp with ``self.fps``,
        so a video whose real rate differs decodes the wrong frames. Reading the
        header is cheap and turns that into a construction-time failure.
        """
        try:
            import av

            with av.open(str(video_path)) as container:
                rate = container.streams.video[0].average_rate
            return float(rate) if rate else None
        except Exception:
            return None

    def _required_span(self) -> int:
        """Frames from the condition frame through the last action, inclusive."""
        return self.action_chunk_size * self.global_downsample_rate + 1

    def _index_sessions(self) -> None:
        span = self._required_span()
        candidates = []
        rate_mismatch: List[str] = []
        for npz_path in sorted(self.root.glob("sessions/*/retarget_eef16.npz")):
            session_id = npz_path.parent.name
            video = self.root / "videos" / session_id / "rgb_fisheye.mp4"
            if not video.exists():
                continue
            rate = self._assert_video_rate(video)
            if rate is not None and abs(rate - self.fps) > 0.5:
                rate_mismatch.append(f"{session_id}: video {rate:g} Hz vs fps {self.fps:g}")
            with np.load(npz_path) as d:
                arm_valid = d["arm_valid"]
                n_frames = len(arm_valid)
            starts = self._valid_window_starts(arm_valid, span)
            if not starts:
                continue
            candidates.append(
                {
                    "session_id": session_id,
                    "npz_path": str(npz_path),
                    "video_path": str(video),
                    "length": int(n_frames),
                    "starts": starts,
                }
            )
        if rate_mismatch:
            raise RuntimeError(
                f"Ego video frame rate disagrees with the resolved dataset rate "
                f"({self.fps:g} Hz) in {len(rate_mismatch)} session(s). Decoding "
                f"would silently return frames from the wrong time, so this is "
                f"refused rather than trained on. Record the correct 'fps' in "
                f"{self.root / 'dataset_manifest.json'}. First few: "
                + "; ".join(rate_mismatch[:5])
            )
        # Sessions with no usable window are dropped before the draw, so
        # max_episodes counts sessions that can actually produce samples.
        self.episodes = select_episodes(
            candidates, self.max_episodes, self.episode_seed, self.episode_subset
        )

    @staticmethod
    def _valid_window_starts(arm_valid: np.ndarray, span: int) -> List[int]:
        """Condition-frame indices whose whole window has both hands tracked.

        The condition frame must be included, not just the actions: in
        eef_delta every action is expressed relative to it, so an untracked
        condition frame would corrupt the entire chunk rather than one step.
        """
        both = (arm_valid[:, 0] & arm_valid[:, 1]).astype(np.int32)
        if len(both) < span:
            return []
        cum = np.concatenate([[0], np.cumsum(both)])
        window_sums = cum[span:] - cum[:-span]
        return np.flatnonzero(window_sums == span).astype(int).tolist()

    # ------------------------------------------------------------------
    # Frames
    # ------------------------------------------------------------------
    def _top_slot_geometry(self) -> Dict[str, int]:
        return self.t_shape_geometry(
            self.G1D_TOP_CAM_HW, self.G1D_WRIST_CAM_HW, self.G1D_WRIST_CAM_HW
        )

    def _place_in_top_slot(self, frames_raw: np.ndarray) -> torch.Tensor:
        """Put the fisheye where G1-D puts its head camera, wrist slots black."""
        th, tw = self.video_size
        geo = self._top_slot_geometry()
        top_h, y0 = geo["top_h"], geo["pad_top"]
        out = torch.zeros((len(frames_raw), 3, th, tw), dtype=torch.float32)
        for i, frame in enumerate(frames_raw):
            canvas = np.zeros((th, tw, 3), dtype=np.uint8)
            canvas[y0:y0 + top_h, :, :] = resize_with_padding(frame, (top_h, tw))
            out[i] = torch.from_numpy(canvas).permute(2, 0, 1).float() / 255.0
        return out

    # ------------------------------------------------------------------
    # Sampling
    # ------------------------------------------------------------------
    def _ego_sampling_indices(self, starts: List[int]) -> Tuple[int, List[int], List[int]]:
        cond_idx = starts[random.randint(0, len(starts) - 1)]
        action_indices = [
            cond_idx + (i + 1) * self.global_downsample_rate
            for i in range(self.action_chunk_size)
        ]
        video_indices = [
            action_indices[(i + 1) * self.video_action_freq_ratio - 1]
            for i in range(self.num_video_frames)
        ]
        return cond_idx, video_indices, action_indices

    def __len__(self) -> int:
        return len(self.episodes) * 10

    def __getitem__(self, idx: int) -> Optional[Dict[str, Any]]:
        for _ in range(8):
            ep = self.episodes[random.randint(0, len(self.episodes) - 1)]
            try:
                cond_idx, video_indices, action_indices = self._ego_sampling_indices(ep["starts"])

                with np.load(ep["npz_path"]) as d:
                    eef16 = d["eef16"]
                    valid_mask = d["valid_mask"]
                cond = eef16[cond_idx].astype(np.float32)
                acts = eef16[action_indices].astype(np.float32)

                state = cond
                if self.state_normalizer is not None:
                    state = self.state_normalizer.normalize(state).astype(np.float32)
                if self.action_mode == "eef_delta":
                    acts = to_delta(cond, acts).astype(np.float32)
                if self.action_normalizer is not None:
                    acts = self.action_normalizer.normalize(acts).astype(np.float32)

                offsets = [cond_idx] + video_indices
                frames = self._place_in_top_slot(
                    self._decode_raw_frames(ep["video_path"], 0, offsets)
                )
                first_frame, video_frames = frames[0], frames[1:]

                language_embedding = self._get_t5_embedding(self.instruction)
                vlm_inputs = None
                if self.vlm_processor is not None:
                    vlm_inputs = preprocess_vlm_messages(
                        self.instruction, self._tensor_to_pil(first_frame), self.vlm_processor
                    )

                return {
                    "first_frame": first_frame,
                    "video_frames": video_frames,
                    "initial_state": torch.from_numpy(state).float(),
                    "action_sequence": torch.from_numpy(acts).float(),
                    "language_embedding": language_embedding,
                    "vlm_inputs": vlm_inputs,
                    "task_name": self.instruction[:64],
                    # Windows are pre-filtered to be fully valid, so this is the
                    # reserved-dim mask -- but it is read off the data rather
                    # than assumed, so a bad window shows up as a masked loss
                    # instead of a silently wrong target.
                    "action_valid_mask": torch.from_numpy(
                        valid_mask[action_indices].astype(np.float32)
                    ),
                }
            except Exception as e:
                logger.warning(f"ego sample retry (session {ep.get('session_id', '?')}): {e}")
        return None

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Rename an already-converted single-embodiment dataset into the suffixed layout.

The earlier aloha-only conversion wrote ``{split}/{task}/``.  The multi-embodiment
layout is ``{split}/{task}__{embodiment}/``, which is what lets several robots share
one ``dataset_dir`` without their task folders colliding.  This renames the existing
folders in place, so the tens of hours already spent converting and encoding aloha
data do not have to be repeated.

Only directory names change -- no episode is read, re-encoded or moved across
filesystems -- so a full dataset migrates in seconds.

Usage::

    python migrate_legacy_layout.py --target-root /data/RoboTwin_emb_ee --embodiment aloha-agilex --dry-run
    python migrate_legacy_layout.py --target-root /data/RoboTwin_emb_ee --embodiment aloha-agilex

Pass ``--link-into /data/RoboTwin_emb_multi`` instead of renaming if the original
layout has to keep working (for example while an existing run is still training off
it); that creates symlinks in the new tree rather than touching the old one.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import List, Optional, Sequence, Tuple

sys.path.insert(0, str(Path(__file__).resolve().parent))
from embodiments import EMBODIMENT_SEPARATOR, get_embodiment  # noqa: E402


def plan(target_root: Path, embodiment: str, splits: Sequence[str]) -> List[Tuple[Path, str]]:
    """Return ``(existing_dir, new_name)`` for every folder that needs renaming."""
    entries: List[Tuple[Path, str]] = []
    for split in splits:
        split_dir = target_root / split
        if not split_dir.is_dir():
            continue
        for task_dir in sorted(p for p in split_dir.iterdir() if p.is_dir()):
            if EMBODIMENT_SEPARATOR in task_dir.name:
                continue  # already migrated
            if not (task_dir / "eepos").is_dir():
                continue  # not a converted task folder
            entries.append((task_dir, f"{task_dir.name}{EMBODIMENT_SEPARATOR}{embodiment}"))
    return entries


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Migrate a legacy single-embodiment layout")
    parser.add_argument("--target-root", required=True, help="dataset root holding clean/ and randomized/")
    parser.add_argument("--embodiment", required=True, help="which embodiment this data came from")
    parser.add_argument("--splits", nargs="+", default=["clean", "randomized"])
    parser.add_argument(
        "--link-into",
        help="build a new tree of symlinks here instead of renaming the originals",
    )
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args(argv)

    get_embodiment(args.embodiment)
    root = Path(args.target_root)
    if not root.is_dir():
        parser.error(f"target_root not found: {root}")

    entries = plan(root, args.embodiment, args.splits)
    if not entries:
        print("nothing to migrate: every task folder is already suffixed (or none were found)")
        return 0

    action = "symlink" if args.link_into else "rename"
    print(f"{len(entries)} task folders to {action}:")
    for task_dir, new_name in entries[:5]:
        destination = Path(args.link_into) / task_dir.parent.name / new_name if args.link_into else task_dir.with_name(new_name)
        print(f"  {task_dir}  ->  {destination}")
    if len(entries) > 5:
        print(f"  ... and {len(entries) - 5} more")

    if args.dry_run:
        print("\ndry run: nothing was changed")
        return 0

    done = 0
    for task_dir, new_name in entries:
        if args.link_into:
            destination = Path(args.link_into) / task_dir.parent.name / new_name
            destination.parent.mkdir(parents=True, exist_ok=True)
            if destination.exists() or destination.is_symlink():
                print(f"skipping {destination}: already exists")
                continue
            destination.symlink_to(task_dir.resolve(), target_is_directory=True)
        else:
            destination = task_dir.with_name(new_name)
            if destination.exists():
                print(f"skipping {task_dir}: {destination} already exists")
                continue
            task_dir.rename(destination)
        done += 1

    print(f"\n{action}d {done}/{len(entries)} task folders")
    if args.link_into:
        print(f"point the training config's dataset_dir at {args.link_into}")
    return 0


if __name__ == "__main__":
    sys.exit(main())

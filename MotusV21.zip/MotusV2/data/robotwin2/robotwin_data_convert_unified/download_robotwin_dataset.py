#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Download RoboTwin 2.0 archives for any subset of embodiments, tasks and splits.

Generalizes the aloha-only downloader.  The release has 460 archives named
``dataset/{task}/{embodiment}_{clean|randomized}_{50|500}.zip``; coverage is not
uniform, so archives that do not exist for an embodiment are reported as expected
gaps rather than errors (see ``embodiments.py`` for the per-robot missing lists).

Extracts into exactly the layout ``robotwin_unified_converter.py`` scans::

    output_dir/{task}/{embodiment}_{split}_{count}/data/episode{N}.hdf5
                                                  /instructions/episode{N}.json

Usage::

    python download_robotwin_dataset.py --output_dir /data/RoboTwin2_0
    python download_robotwin_dataset.py --output_dir /data/RoboTwin2_0 \
        --embodiments franka ur5 piper arx-x5 --splits clean
    python download_robotwin_dataset.py --plan --embodiments piper
"""

from __future__ import annotations

import argparse
import logging
import os
import shutil
import sys
import zipfile
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

sys.path.insert(0, str(Path(__file__).resolve().parent))
from embodiments import (  # noqa: E402
    ALL_TASKS,
    DEFAULT_EMBODIMENT_ORDER,
    SPLIT_EPISODE_COUNTS,
    coverage_summary,
    get_embodiment,
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger("download_robotwin")

REPO_ID = "TianxingChen/RoboTwin2.0"


def build_plan(
    embodiment_keys: Sequence[str],
    tasks: Sequence[str],
    splits: Sequence[str],
) -> List[Tuple[str, str, str, str]]:
    """Return ``(task, embodiment, split, archive_stem)`` for every existing archive."""
    plan: List[Tuple[str, str, str, str]] = []
    for key in embodiment_keys:
        spec = get_embodiment(key)
        released = set(spec.tasks)
        for task in tasks:
            if task not in released:
                continue
            for split in splits:
                plan.append((task, key, split, spec.archive_name(task, split)))
    return plan


def _extract(zip_path: Path, task_dir: Path, archive_stem: str, keep_zip: bool) -> bool:
    """Extract one archive so its contents land under ``task_dir/archive_stem``.

    Archives already contain a top-level ``{archive_stem}/`` folder, so extracting
    into ``task_dir`` produces the right nesting.  A few archives omit that folder,
    hence the fallback.
    """
    try:
        with zipfile.ZipFile(zip_path, "r") as handle:
            names = handle.namelist()
            has_root = any(name.startswith(f"{archive_stem}/") for name in names)
            handle.extractall(task_dir if has_root else task_dir / archive_stem)
    except zipfile.BadZipFile as exc:
        logger.error(f"corrupt archive {zip_path}: {exc}; delete it and re-run")
        return False
    except Exception as exc:  # noqa: BLE001
        logger.error(f"failed to extract {zip_path}: {exc}")
        return False

    if not keep_zip:
        zip_path.unlink(missing_ok=True)
    return True


def download(
    output_dir: str,
    plan: Sequence[Tuple[str, str, str, str]],
    *,
    extract: bool = True,
    keep_zip: bool = False,
    skip_existing: bool = True,
) -> Dict[str, int]:
    from huggingface_hub import hf_hub_download
    from huggingface_hub.utils import EntryNotFoundError

    root = Path(output_dir)
    root.mkdir(parents=True, exist_ok=True)

    counts = {"downloaded": 0, "skipped": 0, "missing": 0, "failed": 0}
    for index, (task, embodiment, split, archive_stem) in enumerate(plan, start=1):
        task_dir = root / task
        extracted_dir = task_dir / archive_stem
        prefix = f"[{index}/{len(plan)}] {task}/{archive_stem}"

        if skip_existing and (extracted_dir / "data").is_dir():
            logger.info(f"{prefix}: already extracted, skipping")
            counts["skipped"] += 1
            continue

        task_dir.mkdir(parents=True, exist_ok=True)
        remote_path = f"dataset/{task}/{archive_stem}.zip"
        try:
            logger.info(f"{prefix}: downloading")
            local_path = hf_hub_download(
                repo_id=REPO_ID,
                filename=remote_path,
                repo_type="dataset",
                local_dir=str(root / ".hf_download"),
            )
        except EntryNotFoundError:
            # Expected for the task-embodiment pairs RoboTwin never released.
            logger.info(f"{prefix}: not present in the release")
            counts["missing"] += 1
            continue
        except Exception as exc:  # noqa: BLE001
            logger.error(f"{prefix}: download failed: {exc}")
            counts["failed"] += 1
            continue

        zip_path = task_dir / f"{archive_stem}.zip"
        shutil.move(local_path, zip_path)

        if extract:
            if not _extract(zip_path, task_dir, archive_stem, keep_zip):
                counts["failed"] += 1
                continue
        counts["downloaded"] += 1

    shutil.rmtree(root / ".hf_download", ignore_errors=True)
    return counts


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        description="Download RoboTwin 2.0 archives for the multi-embodiment converter",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=coverage_summary(),
    )
    parser.add_argument("--output_dir", required=True, help="becomes the converter's source_root")
    parser.add_argument("--embodiments", nargs="+", default=list(DEFAULT_EMBODIMENT_ORDER))
    parser.add_argument("--tasks", nargs="+", default=list(ALL_TASKS))
    parser.add_argument("--splits", nargs="+", default=["clean", "randomized"], choices=sorted(SPLIT_EPISODE_COUNTS))
    parser.add_argument("--plan", action="store_true", help="list the archives that would be fetched and exit")
    parser.add_argument("--no_extract", action="store_true")
    parser.add_argument("--keep_zip", action="store_true")
    parser.add_argument("--overwrite", action="store_true", help="re-download archives already extracted")
    parser.add_argument("--no_mirror", action="store_true", help="do not use hf-mirror.com")
    args = parser.parse_args(argv)

    if not args.no_mirror and "HF_ENDPOINT" not in os.environ:
        os.environ["HF_ENDPOINT"] = "https://hf-mirror.com"
        logger.info("using HuggingFace mirror https://hf-mirror.com (--no_mirror to disable)")

    for key in args.embodiments:
        get_embodiment(key)

    plan = build_plan(args.embodiments, args.tasks, args.splits)
    requested = len(args.embodiments) * len(args.tasks) * len(args.splits)
    logger.info(f"{len(plan)} archives to fetch ({requested - len(plan)} task-embodiment pairs were never released)")

    if args.plan:
        for task, embodiment, split, stem in plan:
            print(f"dataset/{task}/{stem}.zip")
        return 0

    try:
        import huggingface_hub  # noqa: F401
    except ImportError:
        parser.error("huggingface_hub is not installed; run `pip install huggingface_hub`")

    counts = download(
        args.output_dir,
        plan,
        extract=not args.no_extract,
        keep_zip=args.keep_zip,
        skip_existing=not args.overwrite,
    )

    logger.info(
        f"done: {counts['downloaded']} downloaded, {counts['skipped']} already present, "
        f"{counts['missing']} not in the release, {counts['failed']} failed"
    )
    logger.info(f"point the converter's source_root at {args.output_dir}")
    return 1 if counts["failed"] else 0


if __name__ == "__main__":
    sys.exit(main())

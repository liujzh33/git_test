#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Registry of the RoboTwin 2.0 embodiments and the facts the converter relies on.

Everything that differs between the five released embodiments lives here, so the
converter itself stays embodiment-agnostic.

What is *shared* by all five (verified against released episode files, see
``verify_conversion.py --check-shared-assumptions``) is what makes a single
UnifiedEEF action space possible in the first place:

  * ``endpose/{left,right}_endpose`` is 7-dim ``[x, y, z, qw, qx, qy, qz]`` in the
    **world** frame, and the world origin is the same scene origin for every
    embodiment.
  * The end-effector frame convention is already normalized across embodiments by
    RoboTwin's ``delta_matrix`` / ``global_trans_matrix`` (x = approach axis), and
    the frame origin sits at the same canonical 0.12 m offset behind the gripper
    for every robot.  Measured at the grasp instant, all five agree to ~0.01.
  * ``endpose/{left,right}_gripper`` is normalized to [0, 1] (0 closed, 1 open) for
    every robot; the per-robot raw joint scaling is applied before recording.
  * The head camera is at the identical world pose for every embodiment
    (``extrinsic_cv`` is byte-identical), so the camera-frame delta transform in
    ``RobotWinTaskDataset`` needs no per-embodiment extrinsics.
  * ``observation/{head,left,right}_camera/rgb`` all exist at 320x240.

The consequence: converting a new embodiment needs no new action math at all.  The
real differences are the source directory naming, the joint-space dimension, and
which tasks were released.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, FrozenSet, List, Optional, Tuple

# --------------------------------------------------------------------------- #
# Facts shared by every embodiment
# --------------------------------------------------------------------------- #

#: HDF5 camera groups stitched into the training video, in T-layout order.
CAMERA_KEYS: Tuple[str, str, str] = ("head_camera", "left_camera", "right_camera")

#: HDF5 paths for the three views the converter reads.
CAMERA_PATH_MAPPING: Dict[str, str] = {
    "head": "observation/head_camera/rgb",
    "left_wrist": "observation/left_camera/rgb",
    "right_wrist": "observation/right_camera/rgb",
}

#: Width of the ``eepos/*.pt`` tensor written by the converter.
#: [left_xyz(3), left_quat_wxyz(4), left_gripper(1),
#:  right_xyz(3), right_quat_wxyz(4), right_gripper(1)]
EEPOS_DIM: int = 16

#: World-to-camera extrinsics of the head camera, identical for all embodiments.
#: Kept here only so ``verify_conversion.py`` can assert the released data still
#: matches what ``RobotWinTaskDataset._HEAD_CAMERA_R_W_C`` hardcodes.
HEAD_CAMERA_EXTRINSIC_CV: Tuple[Tuple[float, ...], ...] = (
    (1.0, 0.0, 0.0, 0.032),
    (0.0, -0.8, -0.6, 0.45),
    (0.0, 0.6, -0.8, 1.35),
)

#: Splits released on HuggingFace and their nominal episode counts.
SPLIT_EPISODE_COUNTS: Dict[str, int] = {"clean": 50, "randomized": 500}

#: The 50 RoboTwin 2.0 tasks.
ALL_TASKS: Tuple[str, ...] = (
    "adjust_bottle",
    "beat_block_hammer",
    "blocks_ranking_rgb",
    "blocks_ranking_size",
    "click_alarmclock",
    "click_bell",
    "dump_bin_bigbin",
    "grab_roller",
    "handover_block",
    "handover_mic",
    "hanging_mug",
    "lift_pot",
    "move_can_pot",
    "move_pillbottle_pad",
    "move_playingcard_away",
    "move_stapler_pad",
    "open_laptop",
    "open_microwave",
    "pick_diverse_bottles",
    "pick_dual_bottles",
    "place_a2b_left",
    "place_a2b_right",
    "place_bread_basket",
    "place_bread_skillet",
    "place_burger_fries",
    "place_can_basket",
    "place_cans_plasticbox",
    "place_container_plate",
    "place_dual_shoes",
    "place_empty_cup",
    "place_fan",
    "place_mouse_pad",
    "place_object_basket",
    "place_object_scale",
    "place_object_stand",
    "place_phone_stand",
    "place_shoe",
    "press_stapler",
    "put_bottles_dustbin",
    "put_object_cabinet",
    "rotate_qrcode",
    "scan_object",
    "shake_bottle",
    "shake_bottle_horizontally",
    "stack_blocks_three",
    "stack_blocks_two",
    "stack_bowls_three",
    "stack_bowls_two",
    "stamp_seal",
    "turn_switch",
)

#: Prefix prepended to every instruction line in ``metas/*.txt``.  ``{robot}`` is
#: filled from :attr:`EmbodimentSpec.language_name`.
META_PREFIX_TEMPLATE = (
    "The whole scene is in a realistic, industrial art style with three views: "
    "a fixed rear camera, a movable left arm camera, and a movable right arm camera. "
    "The {robot} robot is currently performing the following task: "
)


# --------------------------------------------------------------------------- #
# Per-embodiment specification
# --------------------------------------------------------------------------- #


@dataclass(frozen=True)
class EmbodimentSpec:
    """Everything the converter needs to know about one embodiment."""

    #: Token used in the HuggingFace archive names, e.g. ``aloha-agilex_clean_50``.
    #: Also the suffix appended to output task folders.
    key: str

    #: Name of the matching ``assets/embodiments/*`` directory in the RoboTwin repo.
    #: Only informational; the converter never reads the URDFs.
    asset_name: str

    #: Word substituted into :data:`META_PREFIX_TEMPLATE`.
    language_name: str

    #: Revolute joints per arm.
    arm_dof: int

    #: Width of ``joint_action/vector`` == 2 * (arm_dof + 1 gripper).
    qpos_dim: int

    #: Reject an episode whose ``|qpos|`` exceeds this.  The check exists to catch
    #: corrupted trajectories, not to enforce joint limits, so it is set well above
    #: each robot's reachable range.
    qpos_abs_threshold: float

    #: Tasks with no released archive for this embodiment.  Each one corresponds to
    #: a 0% collection success rate in Table 11 of the RoboTwin 2.0 paper.
    missing_tasks: FrozenSet[str] = frozenset()

    #: Extra ``observation/*`` groups this embodiment happens to carry.  The
    #: converter ignores them; listed so the difference is not mistaken for
    #: corruption.
    extra_observations: Tuple[str, ...] = ()

    @property
    def tasks(self) -> List[str]:
        """Tasks actually released for this embodiment."""
        return [t for t in ALL_TASKS if t not in self.missing_tasks]

    def archive_name(self, task: str, split: str) -> str:
        """HuggingFace archive stem, e.g. ``aloha-agilex_clean_50``."""
        if split not in SPLIT_EPISODE_COUNTS:
            raise ValueError(f"unknown split {split!r}, expected one of {sorted(SPLIT_EPISODE_COUNTS)}")
        return f"{self.key}_{split}_{SPLIT_EPISODE_COUNTS[split]}"

    def meta_prefix(self) -> str:
        return META_PREFIX_TEMPLATE.format(robot=self.language_name)


EMBODIMENTS: Dict[str, EmbodimentSpec] = {
    spec.key: spec
    for spec in (
        EmbodimentSpec(
            key="aloha-agilex",
            asset_name="aloha-agilex",
            # "aloha" (not "aloha-agilex") reproduces byte-for-byte the prefix used
            # by the existing single-embodiment conversion, so already-converted
            # aloha metas and their cached T5 embeddings stay valid.
            language_name="aloha",
            arm_dof=6,
            qpos_dim=14,
            qpos_abs_threshold=4.0,
            extra_observations=("front_camera",),
        ),
        EmbodimentSpec(
            key="arx-x5",
            asset_name="ARX-X5",
            language_name="ARX X5",
            arm_dof=6,
            qpos_dim=14,
            qpos_abs_threshold=4.0,
        ),
        EmbodimentSpec(
            key="franka",
            asset_name="franka-panda",
            language_name="Franka Panda",
            arm_dof=7,
            qpos_dim=16,
            qpos_abs_threshold=4.0,
            missing_tasks=frozenset({
                "handover_block",
                "pick_diverse_bottles",
                "pick_dual_bottles",
                "put_bottles_dustbin",
            }),
        ),
        EmbodimentSpec(
            key="ur5",
            asset_name="ur5-wsg",
            language_name="UR5",
            arm_dof=6,
            qpos_dim=14,
            # UR5 joint limits are +-2*pi, so the 4.0 used for the other robots
            # would reject perfectly good trajectories.
            qpos_abs_threshold=7.0,
            missing_tasks=frozenset({
                "handover_block",
                "put_bottles_dustbin",
                "put_object_cabinet",
            }),
        ),
        EmbodimentSpec(
            key="piper",
            asset_name="piper",
            language_name="Piper",
            arm_dof=6,
            qpos_dim=14,
            qpos_abs_threshold=4.0,
            missing_tasks=frozenset({
                "adjust_bottle",
                "click_alarmclock",
                "hanging_mug",
                "place_bread_skillet",
                "place_can_basket",
                "place_cans_plasticbox",
                "place_fan",
                "place_object_basket",
                "put_object_cabinet",
                "rotate_qrcode",
                "scan_object",
                "stack_blocks_three",
                "stack_bowls_three",
            }),
        ),
    )
}

#: Default conversion order: largest coverage first, so a partial run still spans
#: every task.
DEFAULT_EMBODIMENT_ORDER: Tuple[str, ...] = ("aloha-agilex", "arx-x5", "ur5", "franka", "piper")

#: Separator between task name and embodiment key in output folder names.
#: ``__`` is unambiguous: task names use single underscores and embodiment keys
#: use hyphens, so ``place_dual_shoes__arx-x5`` splits cleanly.
EMBODIMENT_SEPARATOR = "__"


def get_embodiment(key: str) -> EmbodimentSpec:
    try:
        return EMBODIMENTS[key]
    except KeyError:
        raise KeyError(
            f"unknown embodiment {key!r}; known embodiments: {sorted(EMBODIMENTS)}"
        ) from None


def resolve_embodiments(keys: Optional[List[str]]) -> List[EmbodimentSpec]:
    """Resolve a config list of embodiment keys, ``None``/empty meaning all."""
    if not keys:
        return [EMBODIMENTS[k] for k in DEFAULT_EMBODIMENT_ORDER]
    return [get_embodiment(k) for k in keys]


def output_folder_name(task: str, embodiment_key: str, *, with_suffix: bool = True) -> str:
    """Name of the per-(task, embodiment) output folder under a split."""
    if not with_suffix:
        return task
    return f"{task}{EMBODIMENT_SEPARATOR}{embodiment_key}"


def parse_output_folder_name(folder: str) -> Tuple[str, Optional[str]]:
    """Inverse of :func:`output_folder_name`; embodiment is ``None`` if unsuffixed."""
    if EMBODIMENT_SEPARATOR in folder:
        task, _, embodiment = folder.partition(EMBODIMENT_SEPARATOR)
        return task, embodiment
    return folder, None


def coverage_summary() -> str:
    """Human-readable table of released task counts, for logs and ``--dry-run``."""
    lines = [f"{'embodiment':<14}{'qpos':>6}{'tasks':>7}   missing"]
    for key in DEFAULT_EMBODIMENT_ORDER:
        spec = EMBODIMENTS[key]
        missing = ", ".join(sorted(spec.missing_tasks)) or "-"
        lines.append(f"{spec.key:<14}{spec.qpos_dim:>6}{len(spec.tasks):>7}   {missing}")
    total = sum(len(EMBODIMENTS[k].tasks) for k in DEFAULT_EMBODIMENT_ORDER)
    lines.append(f"{'TOTAL':<14}{'':>6}{total:>7}   task-embodiment pairs")
    return "\n".join(lines)


if __name__ == "__main__":
    print(coverage_summary())

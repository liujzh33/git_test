#!/bin/bash
# Drive the full RoboTwin 2.0 -> Motus UnifiedEEF conversion for all embodiments.
#
#   ./run_conversion.sh                       # convert, then encode T5, then verify
#   ./run_conversion.sh --stage convert       # conversion only
#   ./run_conversion.sh --stage t5            # T5 embeddings only
#   ./run_conversion.sh --stage verify        # verification only
#   ./run_conversion.sh --dry-run             # print the plan, touch nothing
#   ./run_conversion.sh --embodiments franka ur5
#
# Any stage can be re-run: conversion skips finished episodes and T5 skips existing
# embeddings, so an interrupted run is resumed by simply invoking the script again.

set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_FILE="${SCRIPT_DIR}/config.yml"

STAGE="all"
DRY_RUN=""
EMBODIMENTS=()
EXTRA_ARGS=()

while [[ $# -gt 0 ]]; do
    case "$1" in
        --config)       CONFIG_FILE="$2"; shift 2 ;;
        --stage)        STAGE="$2"; shift 2 ;;
        --dry-run)      DRY_RUN="--dry-run"; shift ;;
        --embodiments)
            shift
            while [[ $# -gt 0 && "$1" != --* ]]; do EMBODIMENTS+=("$1"); shift; done
            ;;
        -h|--help)
            sed -n '2,15p' "${BASH_SOURCE[0]}"
            exit 0 ;;
        *)              EXTRA_ARGS+=("$1"); shift ;;
    esac
done

case "$STAGE" in
    all|convert|t5|verify) ;;
    *) echo "Error: --stage must be one of: all, convert, t5, verify (got '$STAGE')"; exit 1 ;;
esac

if [ ! -f "$CONFIG_FILE" ]; then
    echo "Error: config file not found: $CONFIG_FILE"
    exit 1
fi

# ----------------------------------------------------------------------------
# Python interpreter
# ----------------------------------------------------------------------------
PYTHON_CMD="${PYTHON_CMD:-}"
if [ -z "$PYTHON_CMD" ]; then
    if command -v python &>/dev/null; then
        PYTHON_CMD="python"
    elif command -v python3 &>/dev/null; then
        PYTHON_CMD="python3"
    else
        echo "Error: no Python interpreter found (set PYTHON_CMD to override)"
        exit 1
    fi
fi

if ! $PYTHON_CMD -c "import torch, h5py, cv2, yaml" &>/dev/null; then
    echo "Error: the Python environment is missing one of torch / h5py / opencv / pyyaml"
    echo "  interpreter: $(command -v $PYTHON_CMD)"
    echo "  environment: ${CONDA_DEFAULT_ENV:-system}"
    exit 1
fi

# ----------------------------------------------------------------------------
# Read the two paths we need for reporting (the Python side owns the real parsing)
# ----------------------------------------------------------------------------
read -r SOURCE_ROOT TARGET_ROOT <<<"$($PYTHON_CMD - "$CONFIG_FILE" <<'PY'
import sys, yaml
cfg = yaml.safe_load(open(sys.argv[1], encoding="utf-8")) or {}
print(cfg.get("source_root", ""), cfg.get("target_root", ""))
PY
)"

if [ -z "$SOURCE_ROOT" ] || [ -z "$TARGET_ROOT" ]; then
    echo "Error: source_root and target_root must both be set in $CONFIG_FILE"
    exit 1
fi

LOG_DIR="${SCRIPT_DIR}/logs"
mkdir -p "$LOG_DIR"
TIMESTAMP="$(date +%Y%m%d_%H%M%S)"

echo "=========================================="
echo "RoboTwin 2.0 -> Motus UnifiedEEF conversion"
echo "=========================================="
echo "  config:  $CONFIG_FILE"
echo "  source:  $SOURCE_ROOT"
echo "  target:  $TARGET_ROOT"
echo "  stage:   $STAGE"
echo "  python:  $(command -v $PYTHON_CMD)"
[ ${#EMBODIMENTS[@]} -gt 0 ] && echo "  embodiments: ${EMBODIMENTS[*]}"
echo "  started: $(date)"
echo

EMB_ARGS=()
[ ${#EMBODIMENTS[@]} -gt 0 ] && EMB_ARGS=(--embodiments "${EMBODIMENTS[@]}")

cd "$SCRIPT_DIR"

# ----------------------------------------------------------------------------
# Stage 1: HDF5 -> videos / eepos / qpos / metas
# ----------------------------------------------------------------------------
if [ "$STAGE" = "all" ] || [ "$STAGE" = "convert" ]; then
    LOG_FILE="${LOG_DIR}/convert_${TIMESTAMP}.log"
    echo ">>> Stage 1/3: converting episodes  (log: $LOG_FILE)"
    $PYTHON_CMD robotwin_unified_converter.py \
        --config "$CONFIG_FILE" \
        $DRY_RUN \
        "${EMB_ARGS[@]}" \
        "${EXTRA_ARGS[@]}" 2>&1 | tee "$LOG_FILE"
    STATUS=${PIPESTATUS[0]}
    if [ "$STATUS" -ne 0 ]; then
        echo "Conversion failed (exit $STATUS); see $LOG_FILE"
        exit "$STATUS"
    fi
    echo
fi

if [ -n "$DRY_RUN" ]; then
    echo "Dry run complete; no data was written."
    exit 0
fi

# ----------------------------------------------------------------------------
# Stage 2: metas -> UMT5-XXL embeddings (required by RobotWinTaskDataset)
# ----------------------------------------------------------------------------
if [ "$STAGE" = "all" ] || [ "$STAGE" = "t5" ]; then
    LOG_FILE="${LOG_DIR}/t5_${TIMESTAMP}.log"
    echo ">>> Stage 2/3: encoding instructions  (log: $LOG_FILE)"
    $PYTHON_CMD generate_t5_embeddings.py \
        --config "$CONFIG_FILE" \
        "${EMB_ARGS[@]}" 2>&1 | tee "$LOG_FILE"
    STATUS=${PIPESTATUS[0]}
    if [ "$STATUS" -ne 0 ]; then
        echo "T5 embedding generation failed (exit $STATUS); see $LOG_FILE"
        exit "$STATUS"
    fi
    echo
fi

# ----------------------------------------------------------------------------
# Stage 3: verification
# ----------------------------------------------------------------------------
if [ "$STAGE" = "all" ] || [ "$STAGE" = "verify" ]; then
    LOG_FILE="${LOG_DIR}/verify_${TIMESTAMP}.log"
    echo ">>> Stage 3/3: verifying output  (log: $LOG_FILE)"
    $PYTHON_CMD verify_conversion.py \
        --config "$CONFIG_FILE" \
        "${EMB_ARGS[@]}" 2>&1 | tee "$LOG_FILE"
    STATUS=${PIPESTATUS[0]}
    echo
fi

# ----------------------------------------------------------------------------
# Summary
# ----------------------------------------------------------------------------
echo "=========================================="
echo "SUMMARY"
echo "=========================================="
if [ -d "$TARGET_ROOT" ]; then
    printf "  %-16s %s\n" "videos"  "$(find "$TARGET_ROOT" -path '*/videos/*.mp4'   | wc -l)"
    printf "  %-16s %s\n" "eepos"   "$(find "$TARGET_ROOT" -path '*/eepos/*.pt'     | wc -l)"
    printf "  %-16s %s\n" "qpos"    "$(find "$TARGET_ROOT" -path '*/qpos/*.pt'      | wc -l)"
    printf "  %-16s %s\n" "metas"   "$(find "$TARGET_ROOT" -path '*/metas/*.txt'    | wc -l)"
    printf "  %-16s %s\n" "umt5_wan" "$(find "$TARGET_ROOT" -path '*/umt5_wan/*.pt' | wc -l)"
    printf "  %-16s %s\n" "task folders" "$(find "$TARGET_ROOT" -mindepth 2 -maxdepth 2 -type d | wc -l)"
    printf "  %-16s %s\n" "total size" "$(du -sh "$TARGET_ROOT" 2>/dev/null | cut -f1)"
fi
echo "  finished: $(date)"
echo "=========================================="

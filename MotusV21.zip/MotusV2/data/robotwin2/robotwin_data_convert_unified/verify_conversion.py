#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Check converted RoboTwin data before committing GPU time to training.

Three independent checks, each runnable on its own:

``--check-source`` (needs ``source_root``)
    Re-verifies the cross-embodiment assumptions the UnifiedEEF space rests on:
    identical head-camera extrinsics, unit quaternions, grippers in [0, 1], and a
    shared end-effector frame convention.  If a future RoboTwin release breaks any
    of these, mixing embodiments in one action space stops being valid, and this is
    where that shows up.

``--check-output`` (default)
    Per-episode integrity of ``target_root``: video frame count against eepos
    length, tensor shapes and dtypes, meta line count against the number of cached
    T5 embeddings, and embedding width.

``--check-unified-eef`` (default)
    Runs converted eepos through the *actual* training transform from
    ``data/human/unified_eef_action.py`` and asserts the invariants the model
    depends on: reserved dims 7/15 exactly zero, gripper dims in [0, 1], rotation
    vectors no longer than pi, everything finite.

Usage::

    python verify_conversion.py --config config.yml
    python verify_conversion.py --config config.yml --check-source --samples 3
    python verify_conversion.py --target-root /data/RoboTwin_emb_multi --full
"""

from __future__ import annotations

import argparse
import logging
import random
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np
import yaml

sys.path.insert(0, str(Path(__file__).resolve().parent))
from embodiments import (  # noqa: E402
    EEPOS_DIM,
    HEAD_CAMERA_EXTRINSIC_CV,
    get_embodiment,
    parse_output_folder_name,
)

REPO_ROOT = Path(__file__).resolve().parents[3]

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
logger = logging.getLogger("verify_conversion")


class Report:
    """Collects failures so one run surfaces every problem, not just the first."""

    def __init__(self) -> None:
        self.errors: List[str] = []
        self.warnings: List[str] = []
        self.checked = 0

    def error(self, message: str) -> None:
        self.errors.append(message)

    def warn(self, message: str) -> None:
        self.warnings.append(message)

    def summarize(self, title: str) -> bool:
        logger.info(f"--- {title}: {self.checked} checked, {len(self.errors)} errors, {len(self.warnings)} warnings")
        for message in self.errors[:25]:
            logger.error(f"  {message}")
        if len(self.errors) > 25:
            logger.error(f"  ... and {len(self.errors) - 25} more errors")
        for message in self.warnings[:15]:
            logger.warning(f"  {message}")
        if len(self.warnings) > 15:
            logger.warning(f"  ... and {len(self.warnings) - 15} more warnings")
        return not self.errors


# --------------------------------------------------------------------------- #
# Source-side: the assumptions that make one action space valid across robots
# --------------------------------------------------------------------------- #


def check_source(source_root: str, embodiments: Optional[Sequence[str]], samples: int) -> bool:
    import h5py

    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from robotwin_unified_converter import scan_source

    report = Report()
    groups = scan_source(
        source_root,
        embodiment_keys=list(embodiments) if embodiments else [
            "aloha-agilex", "arx-x5", "ur5", "franka", "piper"
        ],
        tasks=None,
        splits=["clean", "randomized"],
    )
    if not groups:
        logger.error(f"no source groups found under {source_root}")
        return False

    by_embodiment: Dict[str, List] = defaultdict(list)
    for group in groups:
        by_embodiment[group.embodiment].append(group)

    expected_extrinsic = np.array(HEAD_CAMERA_EXTRINSIC_CV, dtype=np.float64)
    approach_axes: Dict[str, List[np.ndarray]] = defaultdict(list)

    for embodiment, embodiment_groups in sorted(by_embodiment.items()):
        spec = get_embodiment(embodiment)
        chosen = random.sample(embodiment_groups, min(samples, len(embodiment_groups)))
        for group in chosen:
            _, hdf5_path, _ = group.episodes[0]
            report.checked += 1
            label = f"{embodiment}/{group.task}/{Path(hdf5_path).name}"
            try:
                with h5py.File(hdf5_path, "r") as handle:
                    extrinsic = np.asarray(handle["observation/head_camera/extrinsic_cv"][0], dtype=np.float64)
                    if not np.allclose(extrinsic, expected_extrinsic, atol=1e-4):
                        report.error(
                            f"{label}: head camera extrinsics differ from the value hardcoded in "
                            f"RobotWinTaskDataset._HEAD_CAMERA_R_W_C:\n{extrinsic}"
                        )

                    vector = handle["joint_action/vector"]
                    if vector.shape[1] != spec.qpos_dim:
                        report.error(
                            f"{label}: joint_action/vector is {vector.shape[1]}-dim, "
                            f"registry says {spec.qpos_dim}"
                        )

                    for side in ("left", "right"):
                        pose = np.asarray(handle[f"endpose/{side}_endpose"][()])
                        if pose.shape[1] != 7:
                            report.error(f"{label}: {side}_endpose is {pose.shape[1]}-dim, expected 7")
                            continue
                        norms = np.linalg.norm(pose[:, 3:7], axis=1)
                        if not np.allclose(norms, 1.0, atol=1e-3):
                            report.error(
                                f"{label}: {side} quaternions are not unit norm "
                                f"[{norms.min():.4f}, {norms.max():.4f})"
                            )

                        gripper = np.asarray(handle[f"endpose/{side}_gripper"][()])
                        if gripper.min() < -1e-3 or gripper.max() > 1 + 1e-3:
                            report.error(
                                f"{label}: {side} gripper is outside [0, 1] "
                                f"([{gripper.min():.3f}, {gripper.max():.3f}]); the unified action "
                                f"space assumes RoboTwin's normalized gripper"
                            )

                        closed = np.where(gripper < 0.3)[0]
                        if len(closed):
                            rotation = _quat_wxyz_to_matrix(pose[closed[0], 3:7])
                            approach_axes[embodiment].append(rotation[:, 0])
            except Exception as exc:  # noqa: BLE001
                report.error(f"{label}: could not read: {type(exc).__name__}: {exc}")

    # The x-axis of the EE frame is the approach direction for every embodiment.
    # If one robot disagreed, its rotation deltas would mean something different
    # from the others' and a shared action head could not fit both.
    if len(approach_axes) > 1:
        means = {k: np.mean(v, axis=0) / max(np.linalg.norm(np.mean(v, axis=0)), 1e-9)
                 for k, v in approach_axes.items() if v}
        logger.info("  end-effector approach axis at the grasp instant (world frame):")
        for key, axis in sorted(means.items()):
            logger.info(f"    {key:<14} {np.round(axis, 3)}")
        reference_key = next(iter(sorted(means)))
        reference = means[reference_key]
        for key, axis in means.items():
            similarity = float(np.dot(axis, reference))
            if similarity < 0.8:
                report.error(
                    f"{key} approach axis {np.round(axis, 3)} disagrees with {reference_key} "
                    f"{np.round(reference, 3)} (cosine {similarity:.3f}); the EE frame convention "
                    f"is not shared, so these embodiments cannot use one action space unmodified"
                )

    return report.summarize("source assumptions")


def _quat_wxyz_to_matrix(quat: np.ndarray) -> np.ndarray:
    w, x, y, z = (float(v) for v in quat)
    return np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
        [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
        [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
    ])


# --------------------------------------------------------------------------- #
# Output-side
# --------------------------------------------------------------------------- #


def iter_task_dirs(target_root: Path, embodiments: Optional[Sequence[str]], splits: Optional[Sequence[str]]):
    for split_dir in sorted(p for p in target_root.iterdir() if p.is_dir()):
        if splits and split_dir.name not in splits:
            continue
        for task_dir in sorted(p for p in split_dir.iterdir() if p.is_dir()):
            task, embodiment = parse_output_folder_name(task_dir.name)
            if embodiments and embodiment not in embodiments:
                continue
            yield split_dir.name, task, embodiment, task_dir


def check_output(
    target_root: str,
    embodiments: Optional[Sequence[str]],
    splits: Optional[Sequence[str]],
    samples: int,
    full: bool,
    require_t5: bool,
) -> bool:
    import torch
    from decord import VideoReader

    report = Report()
    root = Path(target_root)
    if not root.is_dir():
        logger.error(f"target_root not found: {target_root}")
        return False

    coverage: Dict[Tuple[str, str], Dict[str, int]] = defaultdict(lambda: {"groups": 0, "episodes": 0, "t5": 0})
    any_group = False

    for split, task, embodiment, task_dir in iter_task_dirs(root, embodiments, splits):
        any_group = True
        eepos_dir = task_dir / "eepos"
        videos_dir = task_dir / "videos"
        metas_dir = task_dir / "metas"
        umt5_dir = task_dir / "umt5_wan"

        if not eepos_dir.is_dir():
            report.error(f"{split}/{task_dir.name}: no eepos/ directory")
            continue

        episode_ids = sorted(p.stem for p in eepos_dir.glob("*.pt"))
        bucket = coverage[(embodiment or "unknown", split)]
        bucket["groups"] += 1
        bucket["episodes"] += len(episode_ids)
        bucket["t5"] += len(list(umt5_dir.glob("*.pt"))) if umt5_dir.is_dir() else 0

        if not episode_ids:
            report.warn(f"{split}/{task_dir.name}: no episodes")
            continue

        chosen = episode_ids if full else random.sample(episode_ids, min(samples, len(episode_ids)))
        for episode_id in chosen:
            report.checked += 1
            label = f"{split}/{task_dir.name}/{episode_id}"

            eepos = torch.load(eepos_dir / f"{episode_id}.pt", map_location="cpu", weights_only=False)
            if tuple(eepos.shape[1:]) != (EEPOS_DIM,):
                report.error(f"{label}: eepos shape {tuple(eepos.shape)}, expected (T, {EEPOS_DIM})")
                continue
            if eepos.dtype != torch.float32:
                report.error(f"{label}: eepos dtype {eepos.dtype}, expected float32")
            if not torch.isfinite(eepos).all():
                report.error(f"{label}: eepos contains non-finite values")

            for index in (7, 15):
                gripper = eepos[:, index]
                if gripper.min() < -1e-3 or gripper.max() > 1 + 1e-3:
                    report.error(
                        f"{label}: eepos gripper dim {index} outside [0, 1] "
                        f"([{gripper.min():.3f}, {gripper.max():.3f}])"
                    )

            video_path = videos_dir / f"{episode_id}.mp4"
            if not video_path.exists():
                report.error(f"{label}: missing video")
            else:
                try:
                    num_frames = len(VideoReader(str(video_path)))
                except Exception as exc:  # noqa: BLE001
                    report.error(f"{label}: unreadable video: {exc}")
                    num_frames = -1
                if num_frames >= 0 and num_frames != eepos.shape[0]:
                    report.error(
                        f"{label}: video has {num_frames} frames but eepos has {eepos.shape[0]} rows; "
                        f"actions would be misaligned from observations"
                    )

            meta_path = metas_dir / f"{episode_id}.txt"
            num_instructions = 0
            if not meta_path.exists():
                report.error(f"{label}: missing meta file")
            else:
                lines = [l for l in meta_path.read_text(encoding="utf-8").splitlines() if l.strip()]
                num_instructions = len(lines)
                if num_instructions == 0:
                    report.error(f"{label}: meta file is empty")

            embedding_path = umt5_dir / f"{episode_id}.pt"
            if not embedding_path.exists():
                message = f"{label}: missing umt5_wan embedding (RobotWinTaskDataset skips such episodes)"
                report.error(message) if require_t5 else report.warn(message)
            else:
                embeddings = torch.load(embedding_path, map_location="cpu", weights_only=False)
                if not isinstance(embeddings, list):
                    report.error(f"{label}: umt5_wan payload is {type(embeddings).__name__}, expected list")
                elif num_instructions and len(embeddings) != num_instructions:
                    report.error(
                        f"{label}: {len(embeddings)} embeddings but {num_instructions} instructions; "
                        f"the dataset indexes both with the same integer"
                    )
                elif embeddings and embeddings[0].shape[-1] != 4096:
                    report.error(f"{label}: embedding width {embeddings[0].shape[-1]}, expected 4096")

    if not any_group:
        logger.error(f"no task folders found under {target_root}")
        return False

    logger.info(f"  {'embodiment':<14}{'split':<12}{'folders':>9}{'episodes':>10}{'t5':>10}")
    for (embodiment, split), stats in sorted(coverage.items()):
        logger.info(
            f"  {embodiment:<14}{split:<12}{stats['groups']:>9}{stats['episodes']:>10}{stats['t5']:>10}"
        )
    total_episodes = sum(s["episodes"] for s in coverage.values())
    total_t5 = sum(s["t5"] for s in coverage.values())
    logger.info(f"  {'TOTAL':<26}{sum(s['groups'] for s in coverage.values()):>9}{total_episodes:>10}{total_t5:>10}")

    return report.summarize("output integrity")


# --------------------------------------------------------------------------- #
# UnifiedEEF transform
# --------------------------------------------------------------------------- #


def check_unified_eef(
    target_root: str,
    embodiments: Optional[Sequence[str]],
    splits: Optional[Sequence[str]],
    samples: int,
) -> bool:
    """Push converted eepos through the real training transform and check invariants."""
    import torch

    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    from data.human.unified_eef_action import (
        UNIFIED_EEF_ROBOT_RESERVED_INDICES,
        build_hand_world_poses_from_xyzquat,
        compute_unified_eef_action_sequence_with_gripper,
        compute_unified_eef_state_from_poses_with_gripper,
    )
    from data.robotwin2.robotwin_agilex_dataset import RobotWinTaskDataset

    R_w_c = RobotWinTaskDataset._HEAD_CAMERA_R_W_C.astype(np.float32)
    t_w_c = RobotWinTaskDataset._HEAD_CAMERA_T_W_C.astype(np.float32)

    report = Report()
    root = Path(target_root)
    chunk = 16  # action_chunk_size in configs/robotwin_unified_eef_wan_vlm_mask.yaml
    stride = 3  # global_downsample_rate

    per_embodiment_action_range: Dict[str, List[np.ndarray]] = defaultdict(list)

    for split, task, embodiment, task_dir in iter_task_dirs(root, embodiments, splits):
        eepos_files = sorted((task_dir / "eepos").glob("*.pt")) if (task_dir / "eepos").is_dir() else []
        if not eepos_files:
            continue
        for path in random.sample(eepos_files, min(samples, len(eepos_files))):
            report.checked += 1
            label = f"{split}/{task_dir.name}/{path.stem}"

            eepos = torch.load(path, map_location="cpu", weights_only=False).numpy().astype(np.float64)
            if eepos.shape[0] < chunk * stride + 2:
                report.warn(f"{label}: only {eepos.shape[0]} frames, too short for one 48-frame window")
                continue

            anchor = 0
            action_indices = [anchor + (i + 1) * stride for i in range(chunk)]
            frames = [anchor] + action_indices

            left_R, left_t = build_hand_world_poses_from_xyzquat(eepos[:, 0:3], eepos[:, 3:7])
            right_R, right_t = build_hand_world_poses_from_xyzquat(eepos[:, 8:11], eepos[:, 11:15])
            valid = np.ones(len(frames), dtype=bool)

            actions, masks = compute_unified_eef_action_sequence_with_gripper(
                R_w_e_left=left_R[frames], t_w_e_left=left_t[frames],
                R_w_e_right=right_R[frames], t_w_e_right=right_t[frames],
                R_w_c=R_w_c,
                left_gripper=eepos[frames, 7], right_gripper=eepos[frames, 15],
                left_valid=valid, right_valid=valid,
                num_action_frames=chunk,
            )
            state, _ = compute_unified_eef_state_from_poses_with_gripper(
                R_w_e_left=left_R[anchor], t_w_e_left=left_t[anchor],
                R_w_e_right=right_R[anchor], t_w_e_right=right_t[anchor],
                R_w_c=R_w_c, t_w_c=t_w_c,
                left_gripper=float(eepos[anchor, 7]), right_gripper=float(eepos[anchor, 15]),
            )

            if actions.shape != (chunk, 16):
                report.error(f"{label}: action shape {actions.shape}, expected ({chunk}, 16)")
                continue
            if not np.isfinite(actions).all() or not np.isfinite(state).all():
                report.error(f"{label}: unified action/state contains non-finite values")

            for index in UNIFIED_EEF_ROBOT_RESERVED_INDICES:
                if np.abs(actions[:, index]).max() > 0 or abs(state[index]) > 0:
                    report.error(f"{label}: reserved dim {index} is not zero")
                if masks[:, index].max() > 0:
                    report.error(f"{label}: reserved dim {index} is marked valid in the mask")

            for index in (6, 14):
                gripper = actions[:, index]
                if gripper.min() < -1e-3 or gripper.max() > 1 + 1e-3:
                    report.error(
                        f"{label}: unified gripper dim {index} outside [0, 1] "
                        f"([{gripper.min():.3f}, {gripper.max():.3f}])"
                    )

            for start in (3, 11):
                norms = np.linalg.norm(actions[:, start:start + 3], axis=1)
                if norms.max() > np.pi + 1e-4:
                    report.error(
                        f"{label}: rotation vector norm {norms.max():.4f} exceeds pi at dims "
                        f"{start}:{start + 3}"
                    )

            expected_mask = np.zeros(16, dtype=np.float32)
            expected_mask[0:7] = 1.0
            expected_mask[8:15] = 1.0
            if not np.allclose(masks, expected_mask[None, :]):
                report.error(f"{label}: action_valid_mask is not the expected robot 14-of-16 pattern")

            if embodiment:
                translation = np.concatenate([actions[:, 0:3], actions[:, 8:11]], axis=0)
                per_embodiment_action_range[embodiment].append(
                    np.array([np.abs(translation).max(), np.abs(actions[:, 3:6]).max()])
                )

    # Wildly different magnitudes across embodiments would mean shared normalization
    # statistics fit one robot and squash another.
    if per_embodiment_action_range:
        logger.info("  unified action magnitude by embodiment (max |delta xyz| m, max |rotvec| rad):")
        for key in sorted(per_embodiment_action_range):
            stacked = np.stack(per_embodiment_action_range[key])
            logger.info(f"    {key:<14} xyz {stacked[:, 0].max():.3f}   rot {stacked[:, 1].max():.3f}")

    return report.summarize("unified EEF transform")


# --------------------------------------------------------------------------- #


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Verify converted RoboTwin data")
    parser.add_argument("--config", default=str(Path(__file__).parent / "config.yml"))
    parser.add_argument("--source-root", help="override config source_root")
    parser.add_argument("--target-root", help="override config target_root")
    parser.add_argument("--embodiments", nargs="+")
    parser.add_argument("--splits", nargs="+")
    parser.add_argument("--samples", type=int, default=2, help="episodes sampled per task folder")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--full", action="store_true", help="check every episode instead of sampling")
    parser.add_argument("--require-t5", action="store_true", help="treat missing umt5_wan as an error")
    parser.add_argument("--check-source", action="store_true", help="also re-verify source assumptions")
    parser.add_argument("--only-source", action="store_true", help="run only the source check")
    args = parser.parse_args(argv)

    random.seed(args.seed)

    config: Dict[str, Any] = {}
    if Path(args.config).exists():
        with open(args.config, "r", encoding="utf-8") as f:
            config = yaml.safe_load(f) or {}

    source_root = args.source_root or config.get("source_root")
    target_root = args.target_root or config.get("target_root")

    ok = True
    if args.check_source or args.only_source:
        if not source_root:
            parser.error("--check-source needs source_root in the config or --source-root")
        ok &= check_source(source_root, args.embodiments, args.samples)

    if not args.only_source:
        if not target_root:
            parser.error("target_root must be in the config or passed with --target-root")
        ok &= check_output(
            target_root, args.embodiments, args.splits, args.samples, args.full, args.require_t5
        )
        ok &= check_unified_eef(target_root, args.embodiments, args.splits, args.samples)

    logger.info("PASS" if ok else "FAIL")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())

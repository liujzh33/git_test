# RoboTwin 2.0 -> Motus, all embodiments, one UnifiedEEF action space

Extends `../robotwin_data_convert_ee/` from aloha-agilex to all five released
RoboTwin 2.0 embodiments, so `aloha-agilex`, `arx-x5`, `ur5`, `franka` and `piper`
can be trained together in the `unified_eef_camera_delta_wrist16` action space.

## Why this needs almost no new action math

Before writing anything, the five embodiments were compared against each other on
released episode files. Everything the unified action space depends on turned out
to already be shared:

| Property | Finding |
|---|---|
| Head camera extrinsics | `extrinsic_cv` is **byte-identical** for all five, so the value hardcoded in `RobotWinTaskDataset._HEAD_CAMERA_R_W_C` is correct for every robot |
| `endpose` frame | World frame, shared scene origin |
| EE frame convention | RoboTwin normalizes it per robot via `delta_matrix`/`global_trans_matrix`; measured at the grasp instant, the approach axes agree to within ~0.01 |
| Gripper | Normalized to [0, 1] (0 closed, 1 open) for every robot |
| Cameras | `head_camera` + `left_camera` + `right_camera` at 320x240 everywhere |
| `endpose` layout | `(T, 7)` xyz + wxyz quaternion, plus a scalar gripper, for every robot |

So the 16-dim `eepos` record and the camera-delta transform carry over unchanged.
What actually differs between embodiments is small and handled in `embodiments.py`:

| Difference | Handling |
|---|---|
| `joint_action/vector` is 16-dim for franka, 14-dim for the rest | per-embodiment `qpos_dim`; the old converter hard-rejected anything that was not 14 |
| UR5 joint limits reach +-2pi | per-embodiment `qpos_abs_threshold` (7.0 for ur5, 4.0 elsewhere) |
| Source folders are named `{embodiment}_{split}_{count}` | scanner parses embodiment/split out of the folder name |
| Coverage is uneven: 50 / 50 / 47 / 46 / 37 tasks | per-embodiment `missing_tasks`, so gaps are reported as expected rather than as errors |
| aloha has `front_camera`, the others `third_view_rgb` | both ignored; the T-stitch only uses the three shared views |

`verify_conversion.py --check-source` re-runs those cross-embodiment checks against
your data. If a future RoboTwin release breaks one of them, mixing embodiments in a
single action space stops being valid, and that is where it will show up.

## Layout

Input (what `download_robotwin_dataset.py` produces, and the native HuggingFace
extraction):

```
source_root/{task}/{embodiment}_{clean|randomized}_{50|500}/
    data/episode{N}.hdf5
    instructions/episode{N}.json      # {"seen": [100 strings], "unseen": [100]}
```

Output:

```
target_root/{clean|randomized}/{task}__{embodiment}/
    videos/{episode}.mp4       T-stitch: head full width on top, both wrists below
    eepos/{episode}.pt         (T, 16) float32  world-frame EE poses + grippers
    qpos/{episode}.pt          (T, 14|16) float32  native joint dim
    metas/{episode}.txt        one prefixed instruction per line
    umt5_wan/{episode}.pt      list[Tensor[num_tokens, 4096]], one per meta line
    convert_info.json          provenance for this (task, embodiment, split)
target_root/conversion_manifest.json
```

The `{task}__{embodiment}` folder name is the whole trick for mixed training:
`RobotWinTaskDataset`'s multi-task scan already treats every folder under a split as
a task, so each (task, embodiment) pair becomes its own sampling bucket and **no
training code changes at all**. `__` is unambiguous because task names use single
underscores and embodiment keys use hyphens.

`eepos` layout, unchanged from the single-embodiment converter:

```
[left_xyz(3), left_quat_wxyz(4), left_gripper(1),
 right_xyz(3), right_quat_wxyz(4), right_gripper(1)]
```

`RobotWinTaskDataset` turns this into camera-frame anchor deltas at sample time:

```
[left_delta_xyz(3), left_delta_rotvec(3), left_gripper(1), 0,
 right_delta_xyz(3), right_delta_rotvec(3), right_gripper(1), 0]
```

## Running it

```bash
# 1. download (all embodiments by default; skips pairs that were never released)
python download_robotwin_dataset.py --output_dir /data/RoboTwin2_0

# 2. edit paths and scope
vim config.yml

# 3. convert -> encode -> verify
./run_conversion.sh

# or one stage at a time
./run_conversion.sh --stage convert
./run_conversion.sh --stage t5
./run_conversion.sh --stage verify

# or incrementally, one embodiment at a time
./run_conversion.sh --embodiments franka ur5
```

Every stage is resumable: conversion skips episodes whose outputs already exist and
T5 skips existing embeddings, so an interrupted run is continued by re-invoking the
same command. Check the plan first with `--dry-run`.

### Scripts

| Script | Role |
|---|---|
| `embodiments.py` | Registry: dims, thresholds, task coverage, language prefixes. Single source of truth; run it to print the coverage table |
| `download_robotwin_dataset.py` | Fetch and extract archives for any subset of embodiments / tasks / splits |
| `robotwin_unified_converter.py` | HDF5 -> videos / eepos / qpos / metas. Parallel and resumable |
| `generate_t5_embeddings.py` | metas -> `umt5_wan/`, sharded over GPUs |
| `verify_conversion.py` | Source assumptions, output integrity, and the unified-EEF transform invariants |
| `make_task_sampling.py` | Emit a `task_sampling` block that balances or weights embodiments |
| `migrate_legacy_layout.py` | Rename already-converted `{split}/{task}/` data into `{split}/{task}__{embodiment}/` |

## aloha-agilex: re-convert or reuse

`embodiments: null` re-converts aloha-agilex along with the other four. That is the
default because it makes all five come out of one pipeline, and the T5 numerics are
the reason it matters more than it looks:

* **T5 numerics.** The earlier conversion encoded every prompt of an episode in a
  single bf16 call. UMT5 omits the 1/sqrt(d) attention scaling, so in bf16 the result
  is batch-size dependent (~20% relative between batch=1 and batch=8) and those
  embeddings do not match what inference produces one instruction at a time. This
  converter encodes at batch=1, which does. Reusing the old data would leave the
  aloha portion of a mixed run with a train/inference language mismatch the other
  four do not have.
* **Paraphrase count.** 100 variants for aloha against 8 for everyone else is
  harmless mechanically — the loader reads `len(embedding_list)` at runtime and the
  same index picks the matching `metas` line — but it does mean aloha sees richer
  language variation per episode than the others.
* **Disk.** Re-converting *saves* space: ~1.4 TB of 100-variant embeddings is
  replaced by ~130 GB of 8-variant ones, so the old target root can be deleted once
  the new run verifies.

This needs the aloha source in the native HuggingFace layout,
`{task}/aloha-agilex_{split}_{count}/data/`. The pre-reorganized `{split}/{task}/data/`
layout the old converter wanted is **not** recognized; it yields no aloha groups
rather than an error, so check the `--dry-run` table shows `aloha-agilex` with 50
groups before starting.

Note that re-converting does **not** change sampling balance. Weights are per task
folder and aloha contributes 50 folders either way, so it stays at 50/230 (~22%).
What becomes balanced is how the data was produced, not how much of it there is.

### Reusing it instead

Set `embodiments: ["arx-x5", "ur5", "franka", "piper"]` and rename the old folders
into the suffixed layout:

```bash
python migrate_legacy_layout.py --target-root /data/RoboTwin_emb_ee \
    --embodiment aloha-agilex --dry-run
python migrate_legacy_layout.py --target-root /data/RoboTwin_emb_ee \
    --embodiment aloha-agilex
```

Use `--link-into /data/RoboTwin_emb_multi` if the old layout has to keep working, for
example while a run is still training off it. The video pipeline is byte-identical to
the old converter (verified frame by frame on a 312-frame episode: max per-pixel
difference 0) and the aloha language prefix is unchanged, so that data is
mechanically valid — it just carries the T5 mismatch above. Re-encoding only the
language fixes that without redoing videos:
`./run_conversion.sh --stage t5 --embodiments aloha-agilex` with `--overwrite`.
`tests/diag_t5_cache_vs_inference.py` measures whether the difference is worth it.

## Wiring it into training

Point the existing config at the merged root:

```yaml
# configs/robotwin_unified_eef_wan_vlm_mask.yaml
dataset:
  type: "robotwin"
  dataset_dir: "/data/RoboTwin_emb_multi"
  action_mode: "unified_eef_camera_delta_wrist16"
  data_mode: "both"
  task_mode: "multi"
```

Nothing else has to change: `action_dim`/`state_dim` stay at 16, and the model keeps
seeing the same 14-valid-of-16 `action_valid_mask`.

Uniform sampling over the 230 task-embodiment folders is already close to even
across robots (aloha-agilex and arx-x5 ~22% each, piper ~16%). To make it exactly
even, or to weight the embodiment you evaluate on:

```bash
python make_task_sampling.py --target-root /data/RoboTwin_emb_multi \
    --mode balance-embodiments

python make_task_sampling.py --target-root /data/RoboTwin_emb_multi \
    --mode custom --mass aloha-agilex=3 arx-x5=1 ur5=1 franka=1 piper=1
```

It prints the resulting per-embodiment probabilities to stderr and the YAML block to
stdout; paste the block under `dataset:`.

## Sizing the run

The full release is ~126,500 episodes (230 task-embodiment pairs x 550). Two config
keys dominate the cost:

The counter-intuitive part is that **language embeddings dominate, not video**. A
full meta line is the ~43-token scene prefix plus a ~17-token instruction, so one
bf16 UMT5-XXL embedding is `[~75, 4096]` ~= 600 KB, and RoboTwin ships 100
paraphrases per episode. Measured on the existing aloha-agilex conversion: 49 MB of
`umt5_wan/` per episode, ~1.3 TB for its 27,244 episodes — more than 30x the video
for the same episodes.

Two config keys therefore set the budget:

* **`max_instructions_per_episode`** caps language variants. 8 brings the 49 MB per
  episode down to ~4 MB, and costs nothing in practice because training draws one
  variant per sample anyway.
* **`max_episodes_per_group`** caps episodes per (task, embodiment, split).
  `clean_50` on its own already covers all 230 pairs, so capping `randomized` never
  costs coverage — only visual variety within a pair.

All five embodiments, full release (230 pairs, 126,500 episodes):

| instructions | episodes | umt5_wan | videos |
|---|---|---|---|
| 100 (as aloha was originally done) | 126,500 | ~6.2 TB | ~60 GB |
| 8, full randomized (the default) | 126,500 | ~495 GB | ~60 GB |
| 8, randomized capped at 100 | 34,500 | ~135 GB | ~17 GB |

Dropping aloha-agilex from the run removes 50 pairs / 27,500 episodes, about a fifth
of each figure.

`--dry-run` prints the episode count per embodiment before anything is written.

## Differences from `../robotwin_data_convert_ee/`

Beyond multi-embodiment support:

* **Parallel.** The old converter processed episodes one at a time, which does not
  finish at this scale. `num_workers` now actually does something.
* **Resumable.** `skip_existing` is implemented, and the video is written to a
  temporary and renamed, so an interrupted run never leaves a half-written episode
  that a later run mistakes for a finished one.
* **Traceable episode ids.** Output names reuse the source episode number rather
  than a scan-order index (`episode_id_mode: sequential` restores the old
  behaviour).
* **Frame-count check.** The old converter skipped undecodable frames and kept
  going, which silently desynchronised the video from `eepos` — the dataset indexes
  both with the same integers. Such an episode is now rejected.
* **Missing gripper is an error.** The old converter substituted zeros, which would
  teach the policy to hold that hand shut. Every released episode has both.
* **T5 is a separate stage**, so the multi-hour CPU pass does not hold GPUs idle,
  and either half can be re-run alone.
* **bf16 batching guard.** UMT5 omits the 1/sqrt(d) attention scaling, so in
  bfloat16 the same text encodes differently at batch=1 than at batch=8 (~20%
  relative). Inference encodes one instruction at a time, so `batch_size > 1` is
  refused unless `precision: float32`. The old converter batched every prompt in a
  single bf16 call.

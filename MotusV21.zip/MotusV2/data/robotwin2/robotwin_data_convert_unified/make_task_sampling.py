#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Emit a ``task_sampling`` block that balances embodiments in mixed training.

With ``{task}__{embodiment}`` folders, ``RobotWinTaskDataset`` sees each pair as its
own task and samples them uniformly.  That is already close to even across robots
(aloha-agilex and arx-x5 have 50 tasks, piper only 37, so piper gets ~16% and the
other two ~22% each), but it cannot express "weight the embodiment I actually
evaluate on more heavily", and ``resolve_task_sampling_weights`` takes explicit task
lists rather than patterns.  This script writes those lists out.

The weights are additive masses on top of a uniform component, matching
``data/task_sampling.py``: ``uniform_mass`` spreads evenly over every folder, then
each group's mass is spread evenly within the group, and everything is normalized.

Usage::

    # equal probability per embodiment, regardless of how many tasks it has
    python make_task_sampling.py --target-root /data/RoboTwin_emb_multi --mode balance-embodiments

    # emphasise the embodiment you evaluate on
    python make_task_sampling.py --target-root /data/RoboTwin_emb_multi \\
        --mode custom --mass aloha-agilex=2 arx-x5=1 ur5=1 franka=1 piper=1

    # equal probability per task, split across whichever embodiments have it
    python make_task_sampling.py --target-root /data/RoboTwin_emb_multi --mode balance-tasks

Paste the printed block under ``dataset:`` in the training config, or write it
straight in with ``--inplace-config configs/robotwin_unified_eef_wan_vlm_mask.yaml``.
"""

from __future__ import annotations

import argparse
import sys
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Optional, Sequence

import yaml

sys.path.insert(0, str(Path(__file__).resolve().parent))
from embodiments import parse_output_folder_name  # noqa: E402


def collect_folders(target_root: str, splits: Optional[Sequence[str]] = None) -> Dict[str, List[str]]:
    """Map embodiment -> folder names, and ``__task__`` -> folders per task."""
    root = Path(target_root)
    if not root.is_dir():
        raise FileNotFoundError(f"target_root not found: {target_root}")

    by_embodiment: Dict[str, set] = defaultdict(set)
    for split_dir in sorted(p for p in root.iterdir() if p.is_dir()):
        if splits and split_dir.name not in splits:
            continue
        for task_dir in sorted(p for p in split_dir.iterdir() if p.is_dir()):
            if not (task_dir / "eepos").is_dir():
                continue
            _, embodiment = parse_output_folder_name(task_dir.name)
            by_embodiment[embodiment or "unknown"].add(task_dir.name)
    # A folder name can appear in both clean/ and randomized/; the dataset merges
    # them into one task bucket, so deduplicate.
    return {k: sorted(v) for k, v in sorted(by_embodiment.items())}


def group_by_task(by_embodiment: Dict[str, List[str]]) -> Dict[str, List[str]]:
    by_task: Dict[str, set] = defaultdict(set)
    for folders in by_embodiment.values():
        for folder in folders:
            task, _ = parse_output_folder_name(folder)
            by_task[task].add(folder)
    return {k: sorted(v) for k, v in sorted(by_task.items())}


def build_block(
    by_embodiment: Dict[str, List[str]],
    mode: str,
    masses: Dict[str, float],
    uniform_mass: float,
) -> Dict:
    groups = []
    if mode == "balance-tasks":
        for task, folders in group_by_task(by_embodiment).items():
            groups.append({"name": task, "mass": masses.get(task, 1.0), "tasks": folders})
    else:
        for embodiment, folders in by_embodiment.items():
            mass = masses.get(embodiment, 1.0)
            if mass <= 0:
                continue
            groups.append({"name": embodiment, "mass": mass, "tasks": folders})

    return {
        "task_sampling": {
            "enabled": True,
            "uniform_mass": uniform_mass,
            "validation_mode": "uniform",
            "strict": True,
            "groups": groups,
        }
    }


def report(block: Dict, by_embodiment: Dict[str, List[str]]) -> None:
    """Print the resulting per-embodiment probabilities so the mix is visible."""
    sys.path.insert(0, str(Path(__file__).resolve().parents[3]))
    from data.task_sampling import resolve_task_sampling_weights

    all_folders = sorted({f for folders in by_embodiment.values() for f in folders})
    weights = resolve_task_sampling_weights(all_folders, block["task_sampling"])

    print("# resulting sampling probability by embodiment:", file=sys.stderr)
    for embodiment, folders in by_embodiment.items():
        total = sum(weights.get(f, 0.0) for f in folders)
        print(f"#   {embodiment:<14} {len(folders):>3} folders   {total:6.2%}", file=sys.stderr)
    print(f"#   {'TOTAL':<14} {len(all_folders):>3} folders   {sum(weights.values()):6.2%}", file=sys.stderr)


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Generate a task_sampling block for mixed-embodiment training")
    parser.add_argument("--target-root", required=True)
    parser.add_argument("--splits", nargs="+")
    parser.add_argument(
        "--mode",
        default="balance-embodiments",
        choices=["balance-embodiments", "balance-tasks", "custom"],
    )
    parser.add_argument(
        "--mass",
        nargs="+",
        default=[],
        metavar="KEY=VALUE",
        help="per-embodiment (or per-task in balance-tasks mode) mass, e.g. aloha-agilex=2",
    )
    parser.add_argument(
        "--uniform-mass",
        type=float,
        default=0.0,
        help="mass spread evenly over every folder before the groups are added",
    )
    parser.add_argument("--output", help="write the YAML block here instead of stdout")
    args = parser.parse_args(argv)

    masses: Dict[str, float] = {}
    for item in args.mass:
        if "=" not in item:
            parser.error(f"--mass entries must look like KEY=VALUE, got {item!r}")
        key, _, value = item.partition("=")
        masses[key] = float(value)

    if args.mode == "custom" and not masses:
        parser.error("--mode custom needs at least one --mass entry")

    by_embodiment = collect_folders(args.target_root, args.splits)
    if not by_embodiment:
        parser.error(f"no converted task folders found under {args.target_root}")

    unknown = sorted(set(masses) - set(by_embodiment)) if args.mode != "balance-tasks" else []
    if unknown:
        parser.error(f"--mass refers to embodiments not present in the data: {unknown}")

    block = build_block(by_embodiment, args.mode, masses, args.uniform_mass)
    text = yaml.safe_dump(block, sort_keys=False, default_flow_style=False, width=100)

    try:
        report(block, by_embodiment)
    except Exception as exc:  # noqa: BLE001
        print(f"# (could not compute probabilities: {exc})", file=sys.stderr)

    if args.output:
        Path(args.output).write_text(text, encoding="utf-8")
        print(f"wrote {args.output}", file=sys.stderr)
    else:
        print(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())

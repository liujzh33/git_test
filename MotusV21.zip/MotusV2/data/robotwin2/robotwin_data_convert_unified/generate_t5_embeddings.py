#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Encode ``metas/*.txt`` into ``umt5_wan/*.pt`` with UMT5-XXL, sharded over GPUs.

Split out of the converter on purpose: the video/eepos pass is CPU-bound and takes
hours, and coupling it to the encoder would either hold GPUs idle for that whole
time or force the two to be re-run together.  This script is idempotent, so it can
be run repeatedly as more embodiments finish converting.

Each output is a ``list[Tensor]`` of ``[num_tokens, 4096]`` embeddings, one per line
of the meta file, in file order -- ``RobotWinTaskDataset`` picks an index at random
and uses the same index to pick the matching instruction text for the VLM.

Usage::

    python generate_t5_embeddings.py --config config.yml
    python generate_t5_embeddings.py --config config.yml --devices 0 1 2 3
    python generate_t5_embeddings.py --config config.yml --embodiments franka --dry-run
"""

from __future__ import annotations

import argparse
import logging
import multiprocessing as mp
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

import yaml

sys.path.insert(0, str(Path(__file__).resolve().parent))
from embodiments import parse_output_folder_name  # noqa: E402

REPO_ROOT = Path(__file__).resolve().parents[3]

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger("generate_t5_embeddings")


def resolve_t5_paths(wan_repo_path: str) -> Tuple[str, str]:
    """Return ``(checkpoint, tokenizer)``, accepting either level of the WAN tree.

    Both ``.../pretrained_models`` and ``.../pretrained_models/Wan2.2-TI2V-5B`` are
    passed around in different configs in this repo, so accept whichever is given.
    """
    root = Path(wan_repo_path)
    for candidate in (root, root / "Wan2.2-TI2V-5B"):
        checkpoint = candidate / "models_t5_umt5-xxl-enc-bf16.pth"
        tokenizer = candidate / "google" / "umt5-xxl"
        if checkpoint.exists():
            return str(checkpoint), str(tokenizer)
    raise FileNotFoundError(
        f"could not find models_t5_umt5-xxl-enc-bf16.pth under {root} or {root / 'Wan2.2-TI2V-5B'}"
    )


def collect_jobs(
    target_root: str,
    *,
    embodiments: Optional[Sequence[str]] = None,
    splits: Optional[Sequence[str]] = None,
    skip_existing: bool = True,
) -> List[Tuple[str, str]]:
    """Find ``(meta_path, embedding_path)`` pairs that still need encoding."""
    root = Path(target_root)
    if not root.is_dir():
        raise FileNotFoundError(f"target_root not found: {target_root}")

    wanted_embodiments = set(embodiments) if embodiments else None
    wanted_splits = set(splits) if splits else None

    jobs: List[Tuple[str, str]] = []
    for split_dir in sorted(p for p in root.iterdir() if p.is_dir()):
        if wanted_splits is not None and split_dir.name not in wanted_splits:
            continue
        for task_dir in sorted(p for p in split_dir.iterdir() if p.is_dir()):
            _, embodiment = parse_output_folder_name(task_dir.name)
            if wanted_embodiments is not None and embodiment not in wanted_embodiments:
                continue
            metas_dir = task_dir / "metas"
            if not metas_dir.is_dir():
                continue
            umt5_dir = task_dir / "umt5_wan"
            umt5_dir.mkdir(exist_ok=True)
            for meta_path in sorted(metas_dir.glob("*.txt")):
                embedding_path = umt5_dir / f"{meta_path.stem}.pt"
                if skip_existing and embedding_path.exists() and embedding_path.stat().st_size > 0:
                    continue
                jobs.append((str(meta_path), str(embedding_path)))
    return jobs


def _worker(
    device_index: int,
    jobs: List[Tuple[str, str]],
    checkpoint: str,
    tokenizer: str,
    text_len: int,
    precision: str,
    batch_size: int,
    progress_every: int,
) -> None:
    """Encode one shard on one GPU.  Runs as a spawned subprocess."""
    os.environ["CUDA_VISIBLE_DEVICES"] = str(device_index)

    import torch

    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    bak_root = str(REPO_ROOT / "bak")
    if bak_root not in sys.path:
        sys.path.insert(0, bak_root)

    from wan.modules.t5 import T5EncoderModel
    from data import encode_texts

    # CUDA_VISIBLE_DEVICES has already remapped the shard's GPU to ordinal 0.
    device = "cuda:0"
    encoder = T5EncoderModel(
        text_len=text_len,
        dtype=getattr(torch, precision),
        device=device,
        checkpoint_path=checkpoint,
        tokenizer_path=tokenizer,
    )
    print(f"[gpu{device_index}] encoder ready, {len(jobs)} files to encode", flush=True)

    started = time.time()
    done = failed = 0
    for meta_path, embedding_path in jobs:
        try:
            with open(meta_path, "r", encoding="utf-8") as f:
                prompts = [line.strip() for line in f if line.strip()]
            if not prompts:
                print(f"[gpu{device_index}] empty meta file: {meta_path}", flush=True)
                failed += 1
                continue

            embeddings = []
            with torch.no_grad():
                for start in range(0, len(prompts), batch_size):
                    chunk = prompts[start:start + batch_size]
                    embeddings.extend(encode_texts(encoder, chunk, device, dynamic=True))

            tmp_path = f"{embedding_path}.tmp"
            torch.save([e.cpu() for e in embeddings], tmp_path)
            os.replace(tmp_path, embedding_path)
            done += 1
        except Exception as exc:  # noqa: BLE001
            print(f"[gpu{device_index}] FAILED {meta_path}: {type(exc).__name__}: {exc}", flush=True)
            failed += 1

        if progress_every and (done + failed) % progress_every == 0:
            processed = done + failed
            rate = processed / max(time.time() - started, 1e-6)
            eta = (len(jobs) - processed) / max(rate, 1e-6)
            print(
                f"[gpu{device_index}] {processed}/{len(jobs)}  {rate:.1f} files/s  ETA {eta / 60:.1f} min",
                flush=True,
            )

    print(
        f"[gpu{device_index}] finished: {done} encoded, {failed} failed "
        f"in {(time.time() - started) / 60:.1f} min",
        flush=True,
    )


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Generate UMT5-XXL embeddings for converted RoboTwin data")
    parser.add_argument("--config", default=str(Path(__file__).parent / "config.yml"))
    parser.add_argument("--target-root", help="override config target_root")
    parser.add_argument("--wan-repo-path", help="override config t5.wan_repo_path")
    parser.add_argument("--devices", nargs="+", type=int, help="override config t5.cuda_devices")
    parser.add_argument("--embodiments", nargs="+", help="only encode these embodiments")
    parser.add_argument("--splits", nargs="+", help="only encode these splits")
    parser.add_argument("--batch-size", type=int, help="override config t5.batch_size")
    parser.add_argument("--precision", choices=["bfloat16", "float32"], help="override config t5.precision")
    parser.add_argument("--overwrite", action="store_true", help="re-encode files that already exist")
    parser.add_argument("--progress-every", type=int, default=200)
    parser.add_argument("--dry-run", action="store_true", help="report what would be encoded and exit")
    args = parser.parse_args(argv)

    with open(args.config, "r", encoding="utf-8") as f:
        config: Dict[str, Any] = yaml.safe_load(f) or {}
    t5_config: Dict[str, Any] = config.get("t5") or {}

    target_root = args.target_root or config.get("target_root")
    if not target_root:
        parser.error("target_root must be set in the config or passed with --target-root")

    wan_repo_path = args.wan_repo_path or t5_config.get("wan_repo_path")
    if not wan_repo_path:
        parser.error("t5.wan_repo_path must be set in the config or passed with --wan-repo-path")

    precision = args.precision or str(t5_config.get("precision", "bfloat16"))
    if precision not in ("bfloat16", "float32"):
        parser.error(f"t5.precision must be 'bfloat16' or 'float32', got {precision!r}")
    batch_size = int(args.batch_size if args.batch_size is not None else t5_config.get("batch_size", 1))
    if batch_size > 1 and precision == "bfloat16":
        parser.error(
            f"batch_size={batch_size} with precision=bfloat16 would produce embeddings that "
            f"disagree with inference. UMT5 omits the 1/sqrt(d) attention scaling, so bf16 "
            f"cuBLAS picks a different reduction per batch size and the same text differs by "
            f"~20% relative between batch=1 and batch=8. Inference encodes one instruction at "
            f"a time. Use --batch-size 1, or --precision float32 (which is batch-independent "
            f"to ~1e-6) for both this script and inference."
        )

    devices = args.devices or t5_config.get("cuda_devices") or [0]
    devices = [int(d) for d in devices]

    skip_existing = not args.overwrite and bool(t5_config.get("skip_existing", True))
    jobs = collect_jobs(
        target_root,
        embodiments=args.embodiments,
        splits=args.splits,
        skip_existing=skip_existing,
    )

    logger.info(f"target_root: {target_root}")
    logger.info(f"files to encode: {len(jobs)} (skip_existing={skip_existing})")
    if not jobs:
        logger.info("nothing to do")
        return 0
    if args.dry_run:
        for meta_path, _ in jobs[:10]:
            logger.info(f"  would encode {meta_path}")
        if len(jobs) > 10:
            logger.info(f"  ... and {len(jobs) - 10} more")
        return 0

    checkpoint, tokenizer = resolve_t5_paths(wan_repo_path)
    logger.info(f"checkpoint: {checkpoint}")
    logger.info(f"devices: {devices}   precision: {precision}   batch_size: {batch_size}")

    context = mp.get_context("spawn")
    processes = []
    started = time.time()
    for rank, device_index in enumerate(devices):
        shard = jobs[rank::len(devices)]
        if not shard:
            continue
        process = context.Process(
            target=_worker,
            args=(
                device_index,
                shard,
                checkpoint,
                tokenizer,
                int(t5_config.get("text_len", 512)),
                precision,
                batch_size,
                int(args.progress_every),
            ),
            daemon=False,
        )
        process.start()
        processes.append((device_index, process))

    exit_code = 0
    for device_index, process in processes:
        process.join()
        if process.exitcode != 0:
            logger.error(f"worker on gpu{device_index} exited with code {process.exitcode}")
            exit_code = 1

    remaining = collect_jobs(
        target_root, embodiments=args.embodiments, splits=args.splits, skip_existing=True
    )
    logger.info(
        f"finished in {(time.time() - started) / 60:.1f} min; "
        f"{len(jobs) - len(remaining)}/{len(jobs)} encoded, {len(remaining)} still missing"
    )
    return exit_code


if __name__ == "__main__":
    sys.exit(main())

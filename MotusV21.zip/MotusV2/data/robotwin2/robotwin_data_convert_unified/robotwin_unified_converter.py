#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Convert RoboTwin 2.0 (all embodiments) to the Motus layout for UnifiedEEF training.

Generalizes ``robotwin_data_convert_ee/robotwin_converter.py`` from aloha-agilex to
all five released embodiments.  The action math is unchanged: ``eepos`` is still the
raw 16-dim world-frame end-effector record, and ``RobotWinTaskDataset`` still turns
it into camera-frame anchor deltas at sample time.  That works across embodiments
without modification because RoboTwin already normalizes the EE frame convention and
the gripper scale, and puts the head camera at the same world pose for every robot
(see ``embodiments.py`` for the specifics).

Source layout (native HuggingFace extraction)::

    source_root/{task}/{embodiment}_{clean|randomized}_{50|500}/
        data/episode{N}.hdf5
        instructions/episode{N}.json

Output layout::

    target_root/{clean|randomized}/{task}__{embodiment}/
        videos/{episode}.mp4     T-stitched head + both wrist views
        eepos/{episode}.pt       (T, 16) float32, world-frame EE poses + grippers
        qpos/{episode}.pt        (T, 14) or (T, 16) float32, native joint dim
        metas/{episode}.txt      one prefixed instruction per line
        convert_info.json        provenance for this (task, embodiment, split)

The ``{task}__{embodiment}`` folder name is what lets all embodiments train together
with no change to ``RobotWinTaskDataset``: its multi-task scan already treats every
folder under a split as a task, so each (task, embodiment) pair becomes its own
sampling bucket.

T5 embeddings are *not* produced here -- run ``generate_t5_embeddings.py`` afterwards.
Keeping the CPU-bound video work and the GPU-bound text encoding separate means the
long conversion never holds GPUs idle, and either half can be re-run alone.

Usage::

    python robotwin_unified_converter.py --config config.yml
    python robotwin_unified_converter.py --config config.yml --dry-run
    python robotwin_unified_converter.py --config config.yml --embodiments franka ur5
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import random
import re
import sys
import time
from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

import multiprocessing as mp

import cv2
import h5py
import numpy as np
import torch
import yaml
from tqdm import tqdm

sys.path.insert(0, str(Path(__file__).resolve().parent))
from embodiments import (  # noqa: E402
    CAMERA_PATH_MAPPING,
    EEPOS_DIM,
    SPLIT_EPISODE_COUNTS,
    EmbodimentSpec,
    coverage_summary,
    get_embodiment,
    output_folder_name,
    resolve_embodiments,
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger("robotwin_unified_converter")

#: ``{embodiment}_{split}_{count}``.  Embodiment keys contain hyphens but never
#: underscores, so this splits unambiguously.
GROUP_DIR_RE = re.compile(r"^(?P<embodiment>[A-Za-z0-9.\-]+)_(?P<split>clean|randomized)_(?P<count>\d+)$")
EPISODE_FILE_RE = re.compile(r"^episode(?P<index>\d+)$")


# --------------------------------------------------------------------------- #
# Configuration
# --------------------------------------------------------------------------- #


@dataclass
class ConvertOptions:
    """Per-episode conversion knobs.  Must stay picklable for the worker pool."""

    fps: int = 30
    target_width: int = 320
    target_height: int = 360
    save_qpos: bool = True
    qpos_abs_threshold: Optional[float] = None  # None -> per-embodiment default
    eepos_pos_threshold: float = 10.0
    eepos_gripper_threshold: float = 2.0
    strict_frame_count: bool = True
    instruction_field: str = "seen"
    max_instructions_per_episode: int = 8
    instruction_sample_seed: int = 0
    meta_prefix: str = ""
    expected_qpos_dim: int = 14
    embodiment_key: str = ""


@dataclass
class EpisodeJob:
    """One episode of work handed to a pool worker."""

    hdf5_path: str
    instruction_path: Optional[str]
    output_dir: str
    episode_id: int
    options: ConvertOptions


@dataclass
class SourceGroup:
    """All episodes of one (task, embodiment, split) triple."""

    task: str
    embodiment: str
    split: str
    source_dir: str
    episodes: List[Tuple[int, str, Optional[str]]] = field(default_factory=list)

    @property
    def label(self) -> str:
        return f"{self.split}/{self.task}__{self.embodiment}"


DEFAULT_CONFIG: Dict[str, Any] = {
    "source_root": "",
    "target_root": "",
    "embodiments": None,
    "tasks": None,
    "splits": ["clean", "randomized"],
    "max_episodes_per_group": None,
    "fps": 30,
    "target_width": 320,
    "target_height": 360,
    "instruction_field": "seen",
    "max_instructions_per_episode": 8,
    "instruction_sample_seed": 0,
    "embodiment_suffix": True,
    "episode_id_mode": "source",
    "skip_existing": True,
    "num_workers": 16,
    "save_qpos": True,
    "qpos_abs_threshold": None,
    "eepos_pos_threshold": 10.0,
    "eepos_gripper_threshold": 2.0,
    "strict_frame_count": True,
    "log_level": "INFO",
}


def load_config(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        raw = yaml.safe_load(f) or {}
    config = dict(DEFAULT_CONFIG)
    config.update({k: v for k, v in raw.items() if k in DEFAULT_CONFIG})
    unknown = sorted(set(raw) - set(DEFAULT_CONFIG) - {"t5"})
    if unknown:
        logger.warning(f"ignoring unknown config keys: {unknown}")
    for key in ("source_root", "target_root"):
        if not config[key]:
            raise ValueError(f"config key {key!r} must be set")
    return config


def _episode_limit(config: Dict[str, Any], split: str) -> Optional[int]:
    """Resolve ``max_episodes_per_group`` for a split (scalar or per-split mapping)."""
    limit = config.get("max_episodes_per_group")
    if limit is None:
        return None
    if isinstance(limit, dict):
        value = limit.get(split)
        return None if value in (None, 0) else int(value)
    return None if int(limit) <= 0 else int(limit)


# --------------------------------------------------------------------------- #
# Source scanning
# --------------------------------------------------------------------------- #


def _episode_index(stem: str, fallback: int) -> int:
    match = EPISODE_FILE_RE.match(stem)
    return int(match.group("index")) if match else fallback


def _find_data_dir(group_dir: Path) -> Optional[Path]:
    """Locate the ``data/`` folder, tolerating one level of redundant nesting.

    ``unzip aloha-agilex_clean_50.zip -d {task}/`` gives ``{task}/aloha-agilex_clean_50/data``
    but ``-d {task}/aloha-agilex_clean_50/`` gives that path twice over, and both
    show up in practice.
    """
    if (group_dir / "data").is_dir():
        return group_dir / "data"
    nested = group_dir / group_dir.name / "data"
    if nested.is_dir():
        return nested
    return None


def _instruction_path(data_dir: Path, stem: str) -> Optional[str]:
    for candidate in (
        data_dir.parent / "instructions" / f"{stem}.json",
        data_dir / "instructions" / f"{stem}.json",
        data_dir / f"{stem}.json",
    ):
        if candidate.exists():
            return str(candidate)
    return None


def scan_source(
    source_root: str,
    *,
    embodiment_keys: Sequence[str],
    tasks: Optional[Sequence[str]],
    splits: Sequence[str],
) -> List[SourceGroup]:
    """Find every (task, embodiment, split) group under ``source_root``.

    Walks for directories named ``{embodiment}_{split}_{count}`` and takes the parent
    directory as the task, which makes the scan independent of how deeply the
    archives were extracted.
    """
    root = Path(source_root)
    if not root.is_dir():
        raise FileNotFoundError(f"source_root not found: {source_root}")

    wanted_embodiments = set(embodiment_keys)
    wanted_tasks = set(tasks) if tasks else None
    wanted_splits = set(splits)

    groups: List[SourceGroup] = []
    seen_dirs: set = set()
    skipped_embodiments: Dict[str, int] = {}

    for dirpath, dirnames, _ in os.walk(root):
        current = Path(dirpath)
        for name in list(dirnames):
            match = GROUP_DIR_RE.match(name)
            if not match:
                continue
            group_dir = current / name
            if str(group_dir) in seen_dirs:
                continue

            embodiment = match.group("embodiment")
            split = match.group("split")
            task = current.name

            if split not in wanted_splits:
                continue
            if embodiment not in wanted_embodiments:
                skipped_embodiments[embodiment] = skipped_embodiments.get(embodiment, 0) + 1
                continue
            if wanted_tasks is not None and task not in wanted_tasks:
                continue

            data_dir = _find_data_dir(group_dir)
            if data_dir is None:
                logger.warning(f"no data/ directory under {group_dir}, skipping")
                continue

            hdf5_files = sorted(
                data_dir.glob("*.hdf5"),
                key=lambda p: (_episode_index(p.stem, 1 << 30), p.stem),
            )
            if not hdf5_files:
                logger.warning(f"no .hdf5 files under {data_dir}, skipping")
                continue

            seen_dirs.add(str(group_dir))
            # Never descend into a matched group; its contents are episodes.
            if name in dirnames:
                dirnames.remove(name)

            episodes = [
                (_episode_index(p.stem, i), str(p), _instruction_path(data_dir, p.stem))
                for i, p in enumerate(hdf5_files)
            ]
            groups.append(
                SourceGroup(
                    task=task,
                    embodiment=embodiment,
                    split=split,
                    source_dir=str(group_dir),
                    episodes=episodes,
                )
            )

    if skipped_embodiments:
        logger.info(f"skipped embodiments not selected: {skipped_embodiments}")

    groups.sort(key=lambda g: (g.split, g.embodiment, g.task))
    return groups


# --------------------------------------------------------------------------- #
# Per-episode conversion (runs in worker processes)
# --------------------------------------------------------------------------- #


def _decode_jpeg(buffer: bytes) -> Optional[np.ndarray]:
    array = np.frombuffer(buffer, dtype=np.uint8)
    return cv2.imdecode(array, cv2.IMREAD_COLOR)


def _stitch_t_layout(head: np.ndarray, left: np.ndarray, right: np.ndarray) -> np.ndarray:
    """Head view on top at full size, both wrist views half-size underneath."""
    height, width = head.shape[:2]
    half = (width // 2, height // 2)
    bottom = np.hstack([cv2.resize(left, half), cv2.resize(right, half)])
    return np.vstack([head, bottom])


def _write_video(handle: h5py.File, output_path: str, options: ConvertOptions) -> Tuple[bool, int, str]:
    """Write the stitched MP4.  Returns ``(ok, num_frames, message)``.

    Frames are decoded one index at a time rather than all up front: the three
    camera streams of a 300-frame episode are ~200 MB decoded, which multiplied by
    the worker count is enough to matter.

    The channel handling deliberately reproduces the existing single-embodiment
    converter, so videos are comparable across old and new output.  RoboTwin encodes
    its JPEGs from RGB arrays passed to ``cv2.imencode`` (which assumes BGR), so
    ``imdecode`` returns RGB-ordered data; the swap below turns it into the BGR that
    ``VideoWriter`` expects, and the colours come out correct.
    """
    streams = {}
    for name, key in CAMERA_PATH_MAPPING.items():
        if key not in handle:
            return False, 0, f"missing camera stream {key}"
        streams[name] = handle[key]

    counts = {name: stream.shape[0] for name, stream in streams.items()}
    if len(set(counts.values())) != 1:
        return False, 0, f"inconsistent camera frame counts {counts}"
    num_frames = next(iter(counts.values()))
    if num_frames == 0:
        return False, 0, "episode has no frames"

    size = (options.target_width, options.target_height)
    writer = cv2.VideoWriter(output_path, cv2.VideoWriter_fourcc(*"mp4v"), options.fps, size)
    if not writer.isOpened():
        return False, 0, f"could not open VideoWriter for {output_path}"

    written = 0
    try:
        for i in range(num_frames):
            frames = []
            for name in ("head", "left_wrist", "right_wrist"):
                image = _decode_jpeg(streams[name][i])
                if image is None:
                    break
                frames.append(image)
            if len(frames) != 3:
                return False, written, f"failed to decode frame {i}"

            combined = _stitch_t_layout(*frames)
            if combined.shape[:2] != (options.target_height, options.target_width):
                combined = cv2.resize(combined, size)
            combined = cv2.cvtColor(combined, cv2.COLOR_BGR2RGB)
            if not combined.flags["C_CONTIGUOUS"]:
                combined = np.ascontiguousarray(combined)
            writer.write(combined)
            written += 1
    finally:
        writer.release()

    if written != num_frames:
        return False, written, f"wrote {written}/{num_frames} frames"
    return True, num_frames, ""


def _extract_qpos(handle: h5py.File, options: ConvertOptions) -> Tuple[Optional[torch.Tensor], str]:
    """Read ``joint_action/vector`` at the embodiment's native width."""
    if "joint_action/vector" not in handle:
        return None, "no joint_action/vector"
    data = np.asarray(handle["joint_action/vector"][()])
    if data.ndim != 2:
        return None, f"joint_action/vector has shape {data.shape}"
    if data.shape[1] != options.expected_qpos_dim:
        return None, (
            f"joint_action/vector is {data.shape[1]}-dim but {options.embodiment_key} "
            f"should be {options.expected_qpos_dim}-dim"
        )

    tensor = torch.from_numpy(data).float()
    threshold = options.qpos_abs_threshold
    if threshold is not None:
        peak = float(torch.max(torch.abs(tensor)).item())
        if peak > threshold:
            return None, f"max |qpos| {peak:.3f} exceeds {threshold}"
    return tensor, ""


def _extract_eepos(handle: h5py.File, options: ConvertOptions) -> Tuple[Optional[torch.Tensor], str]:
    """Read ``endpose/*`` into the 16-dim layout the dataset expects.

    Layout: ``[left_xyz(3), left_quat_wxyz(4), left_gripper(1),
    right_xyz(3), right_quat_wxyz(4), right_gripper(1)]``.
    """
    if "endpose" not in handle:
        return None, "no endpose group"
    group = handle["endpose"]

    left = group.get("left_endpose")
    right = group.get("right_endpose")
    if left is None or right is None:
        return None, "endpose group is missing left_endpose or right_endpose"

    left_pose = np.asarray(left[()])
    right_pose = np.asarray(right[()])
    if left_pose.shape[1:] != (7,) or right_pose.shape[1:] != (7,):
        return None, f"endpose shapes {left_pose.shape}/{right_pose.shape} are not (T, 7)"

    num_frames = left_pose.shape[0]
    grippers = []
    for side, pose in (("left", left_pose), ("right", right_pose)):
        raw = group.get(f"{side}_gripper")
        if raw is None:
            # Zero-filling would silently teach the policy to keep this hand shut;
            # every released episode has both, so treat absence as corruption.
            return None, f"endpose group is missing {side}_gripper"
        grippers.append(np.asarray(raw[()]).reshape(num_frames, 1))

    eepos = np.concatenate([left_pose, grippers[0], right_pose, grippers[1]], axis=1)
    if eepos.shape[1] != EEPOS_DIM:
        return None, f"assembled eepos is {eepos.shape[1]}-dim, expected {EEPOS_DIM}"

    tensor = torch.from_numpy(eepos).float()

    pose_dims = torch.cat([tensor[:, :7], tensor[:, 8:15]], dim=0)
    peak_pose = float(torch.max(torch.abs(pose_dims)).item())
    if peak_pose > options.eepos_pos_threshold:
        return None, f"max |pose| {peak_pose:.3f} exceeds {options.eepos_pos_threshold}"

    gripper_dims = torch.cat([tensor[:, 7:8], tensor[:, 15:16]], dim=0)
    peak_gripper = float(torch.max(torch.abs(gripper_dims)).item())
    if peak_gripper > options.eepos_gripper_threshold:
        return None, f"max |gripper| {peak_gripper:.3f} exceeds {options.eepos_gripper_threshold}"

    quat_norms = np.linalg.norm(np.concatenate([left_pose[:, 3:7], right_pose[:, 3:7]], axis=0), axis=1)
    if not np.allclose(quat_norms, 1.0, atol=1e-3):
        return None, f"quaternions are not unit norm (min {quat_norms.min():.4f}, max {quat_norms.max():.4f})"

    return tensor, ""


def _read_instructions(path: Optional[str], options: ConvertOptions, episode_id: int) -> List[str]:
    """Load and subsample the instruction variants for one episode.

    RoboTwin ships 100 ``seen`` and 100 ``unseen`` paraphrases per episode.  Encoding
    all of them would dominate storage -- one UMT5-XXL embedding is ~150 KB, so 100
    variants x 126,500 episodes is petabyte scale -- and training only ever draws one
    variant per sample.  A capped, deterministic subsample keeps the language
    diversity that matters at a manageable size.
    """
    if not path or not os.path.exists(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            payload = json.load(f)
    except Exception as exc:  # noqa: BLE001
        logger.warning(f"could not parse instructions {path}: {exc}")
        return []

    instructions: List[str] = []
    if isinstance(payload, dict):
        fields = ["seen", "unseen"] if options.instruction_field == "both" else [options.instruction_field]
        for name in fields:
            value = payload.get(name)
            if isinstance(value, list):
                instructions.extend(str(v) for v in value)
        if not instructions:
            for name in ("captions", "caption"):
                value = payload.get(name)
                if isinstance(value, list):
                    instructions.extend(str(v) for v in value)
                elif isinstance(value, str):
                    instructions.append(value)
    elif isinstance(payload, list):
        for item in payload:
            if isinstance(item, str):
                instructions.append(item)
            elif isinstance(item, dict) and "caption" in item:
                caption = item["caption"]
                if isinstance(caption, list):
                    instructions.extend(str(c) for c in caption)
                else:
                    instructions.append(str(caption))

    instructions = [text.strip() for text in instructions if text and text.strip()]
    # Preserve order while dropping duplicates.
    instructions = list(dict.fromkeys(instructions))

    cap = options.max_instructions_per_episode
    if cap and len(instructions) > cap:
        rng = random.Random(f"{options.instruction_sample_seed}:{path}:{episode_id}")
        instructions = sorted(rng.sample(instructions, cap), key=instructions.index)
    return instructions


def convert_episode(job: EpisodeJob) -> Dict[str, Any]:
    """Convert one episode.  Returns a status record; never raises."""
    cv2.setNumThreads(1)

    options = job.options
    output_dir = Path(job.output_dir)
    episode_id = job.episode_id
    result: Dict[str, Any] = {
        "episode_id": episode_id,
        "source": job.hdf5_path,
        "ok": False,
        "reason": "",
        "num_frames": 0,
        "num_instructions": 0,
    }

    video_path = output_dir / "videos" / f"{episode_id}.mp4"
    eepos_path = output_dir / "eepos" / f"{episode_id}.pt"
    qpos_path = output_dir / "qpos" / f"{episode_id}.pt"
    meta_path = output_dir / "metas" / f"{episode_id}.txt"

    # Write the video to a temporary first so an interrupted run never leaves a
    # half-written episode that `skip_existing` would then treat as complete.  The
    # name has to keep the .mp4 extension: OpenCV picks the container from it.
    tmp_video = video_path.with_name(f"{episode_id}.partial.mp4")

    try:
        with h5py.File(job.hdf5_path, "r") as handle:
            eepos, reason = _extract_eepos(handle, options)
            if eepos is None:
                result["reason"] = f"eepos: {reason}"
                return result

            qpos = None
            if options.save_qpos:
                qpos, reason = _extract_qpos(handle, options)
                if qpos is None:
                    result["reason"] = f"qpos: {reason}"
                    return result

            ok, num_frames, reason = _write_video(handle, str(tmp_video), options)
            if not ok:
                result["reason"] = f"video: {reason}"
                return result

        # The dataset indexes video frames and eepos rows with the same integers, so
        # any length mismatch silently misaligns actions from observations.
        if options.strict_frame_count and num_frames != eepos.shape[0]:
            result["reason"] = f"video has {num_frames} frames but eepos has {eepos.shape[0]} rows"
            return result
        if qpos is not None and options.strict_frame_count and num_frames != qpos.shape[0]:
            result["reason"] = f"video has {num_frames} frames but qpos has {qpos.shape[0]} rows"
            return result

        instructions = _read_instructions(job.instruction_path, options, episode_id)
        if not instructions:
            result["reason"] = "no instructions found"
            return result

        torch.save(eepos, eepos_path)
        if qpos is not None:
            torch.save(qpos, qpos_path)
        with open(meta_path, "w", encoding="utf-8") as f:
            for instruction in instructions:
                f.write(f"{options.meta_prefix}{instruction}\n")
        os.replace(tmp_video, video_path)

        result.update(ok=True, num_frames=int(num_frames), num_instructions=len(instructions))
        return result

    except Exception as exc:  # noqa: BLE001
        result["reason"] = f"unhandled error: {type(exc).__name__}: {exc}"
        return result
    finally:
        if tmp_video.exists():
            tmp_video.unlink(missing_ok=True)


# --------------------------------------------------------------------------- #
# Driver
# --------------------------------------------------------------------------- #


class UnifiedConverter:
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.target_root = Path(config["target_root"])
        self.embodiments: Dict[str, EmbodimentSpec] = {
            spec.key: spec for spec in resolve_embodiments(config.get("embodiments"))
        }

    def build_options(self, spec: EmbodimentSpec) -> ConvertOptions:
        override = self.config.get("qpos_abs_threshold")
        return ConvertOptions(
            fps=int(self.config["fps"]),
            target_width=int(self.config["target_width"]),
            target_height=int(self.config["target_height"]),
            save_qpos=bool(self.config["save_qpos"]),
            qpos_abs_threshold=spec.qpos_abs_threshold if override is None else float(override),
            eepos_pos_threshold=float(self.config["eepos_pos_threshold"]),
            eepos_gripper_threshold=float(self.config["eepos_gripper_threshold"]),
            strict_frame_count=bool(self.config["strict_frame_count"]),
            instruction_field=str(self.config["instruction_field"]),
            max_instructions_per_episode=int(self.config["max_instructions_per_episode"] or 0),
            instruction_sample_seed=int(self.config["instruction_sample_seed"]),
            meta_prefix=spec.meta_prefix(),
            expected_qpos_dim=spec.qpos_dim,
            embodiment_key=spec.key,
        )

    def group_output_dir(self, group: SourceGroup) -> Path:
        folder = output_folder_name(
            group.task, group.embodiment, with_suffix=bool(self.config["embodiment_suffix"])
        )
        return self.target_root / group.split / folder

    def build_jobs(self, group: SourceGroup, options: ConvertOptions) -> Tuple[List[EpisodeJob], int]:
        """Materialize the job list for a group, honouring limits and resume."""
        output_dir = self.group_output_dir(group)
        limit = _episode_limit(self.config, group.split)
        sequential = self.config["episode_id_mode"] == "sequential"
        skip_existing = bool(self.config["skip_existing"])

        episodes = group.episodes[:limit] if limit else group.episodes

        jobs: List[EpisodeJob] = []
        skipped = 0
        for position, (source_id, hdf5_path, instruction_path) in enumerate(episodes):
            episode_id = position if sequential else source_id
            if skip_existing and self._episode_complete(output_dir, episode_id, options):
                skipped += 1
                continue
            jobs.append(
                EpisodeJob(
                    hdf5_path=hdf5_path,
                    instruction_path=instruction_path,
                    output_dir=str(output_dir),
                    episode_id=episode_id,
                    options=options,
                )
            )
        return jobs, skipped

    @staticmethod
    def _episode_complete(output_dir: Path, episode_id: int, options: ConvertOptions) -> bool:
        required = [
            output_dir / "videos" / f"{episode_id}.mp4",
            output_dir / "eepos" / f"{episode_id}.pt",
            output_dir / "metas" / f"{episode_id}.txt",
        ]
        if options.save_qpos:
            required.append(output_dir / "qpos" / f"{episode_id}.pt")
        return all(path.exists() and path.stat().st_size > 0 for path in required)

    def run(self, dry_run: bool = False) -> Dict[str, Any]:
        groups = scan_source(
            self.config["source_root"],
            embodiment_keys=list(self.embodiments),
            tasks=self.config.get("tasks"),
            splits=self.config["splits"],
        )
        if not groups:
            raise RuntimeError(
                f"no (task, embodiment, split) groups found under {self.config['source_root']!r}. "
                f"Expected directories named like '<embodiment>_clean_50' with a data/ subfolder."
            )

        self._log_plan(groups)
        if dry_run:
            return {"groups": len(groups), "dry_run": True}

        self.target_root.mkdir(parents=True, exist_ok=True)
        num_workers = max(1, int(self.config["num_workers"]))
        context = mp.get_context("spawn")

        totals = {"converted": 0, "skipped": 0, "failed": 0, "groups": 0}
        failures: List[Dict[str, Any]] = []
        started = time.time()

        with ProcessPoolExecutor(max_workers=num_workers, mp_context=context) as executor:
            for group in groups:
                spec = self.embodiments[group.embodiment]
                options = self.build_options(spec)
                output_dir = self.group_output_dir(group)
                for sub in ("videos", "eepos", "metas") + (("qpos",) if options.save_qpos else ()):
                    (output_dir / sub).mkdir(parents=True, exist_ok=True)

                jobs, skipped = self.build_jobs(group, options)
                totals["skipped"] += skipped
                totals["groups"] += 1

                if not jobs:
                    logger.info(f"{group.label}: nothing to do ({skipped} already converted)")
                    self._write_group_info(group, output_dir, spec, converted=0, skipped=skipped, failed=[])
                    continue

                results = list(
                    tqdm(
                        executor.map(convert_episode, jobs, chunksize=1),
                        total=len(jobs),
                        desc=group.label,
                        leave=False,
                    )
                )

                converted = [r for r in results if r["ok"]]
                failed = [r for r in results if not r["ok"]]
                totals["converted"] += len(converted)
                totals["failed"] += len(failed)
                failures.extend({"group": group.label, **r} for r in failed)

                logger.info(
                    f"{group.label}: converted {len(converted)}, skipped {skipped}, failed {len(failed)}"
                )
                for record in failed[:5]:
                    logger.warning(f"  episode {record['episode_id']} failed: {record['reason']}")

                self._write_group_info(
                    group, output_dir, spec, converted=len(converted), skipped=skipped, failed=failed
                )

        elapsed = time.time() - started
        self._write_manifest(groups, totals, failures, elapsed)

        logger.info(
            f"done in {elapsed / 60:.1f} min: {totals['converted']} converted, "
            f"{totals['skipped']} skipped, {totals['failed']} failed "
            f"across {totals['groups']} groups"
        )
        if totals["failed"]:
            logger.warning(
                f"see {self.target_root / 'conversion_manifest.json'} for the full failure list"
            )
        return totals

    def _log_plan(self, groups: List[SourceGroup]) -> None:
        by_embodiment: Dict[str, Dict[str, int]] = {}
        for group in groups:
            bucket = by_embodiment.setdefault(group.embodiment, {"groups": 0, "episodes": 0})
            limit = _episode_limit(self.config, group.split)
            bucket["groups"] += 1
            bucket["episodes"] += min(len(group.episodes), limit) if limit else len(group.episodes)

        logger.info("conversion plan:")
        logger.info(f"  {'embodiment':<14}{'groups':>8}{'episodes':>10}")
        for key in sorted(by_embodiment):
            stats = by_embodiment[key]
            logger.info(f"  {key:<14}{stats['groups']:>8}{stats['episodes']:>10}")
        logger.info(
            f"  {'TOTAL':<14}{sum(s['groups'] for s in by_embodiment.values()):>8}"
            f"{sum(s['episodes'] for s in by_embodiment.values()):>10}"
        )

    def _write_group_info(
        self,
        group: SourceGroup,
        output_dir: Path,
        spec: EmbodimentSpec,
        *,
        converted: int,
        skipped: int,
        failed: List[Dict[str, Any]],
    ) -> None:
        info = {
            "task": group.task,
            "embodiment": group.embodiment,
            "split": group.split,
            "source_dir": group.source_dir,
            "arm_dof": spec.arm_dof,
            "qpos_dim": spec.qpos_dim,
            "eepos_dim": EEPOS_DIM,
            "action_space": "unified_eef_camera_delta_wrist16",
            "meta_prefix": spec.meta_prefix(),
            "converted": converted,
            "skipped_existing": skipped,
            "failed": [{"episode_id": r["episode_id"], "reason": r["reason"]} for r in failed],
            "num_episodes_available": len(group.episodes),
        }
        with open(output_dir / "convert_info.json", "w", encoding="utf-8") as f:
            json.dump(info, f, indent=2, ensure_ascii=False)

    def _write_manifest(
        self,
        groups: List[SourceGroup],
        totals: Dict[str, int],
        failures: List[Dict[str, Any]],
        elapsed: float,
    ) -> None:
        manifest = {
            "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "elapsed_seconds": round(elapsed, 1),
            "source_root": self.config["source_root"],
            "target_root": str(self.target_root),
            "action_space": "unified_eef_camera_delta_wrist16",
            "config": {k: v for k, v in self.config.items() if k != "t5"},
            "totals": totals,
            "groups": [
                {
                    "split": g.split,
                    "task": g.task,
                    "embodiment": g.embodiment,
                    "folder": output_folder_name(
                        g.task, g.embodiment, with_suffix=bool(self.config["embodiment_suffix"])
                    ),
                    "num_episodes_available": len(g.episodes),
                }
                for g in groups
            ],
            "failures": failures,
        }
        with open(self.target_root / "conversion_manifest.json", "w", encoding="utf-8") as f:
            json.dump(manifest, f, indent=2, ensure_ascii=False)


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Convert RoboTwin 2.0 (all embodiments) to the Motus UnifiedEEF layout",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=coverage_summary(),
    )
    parser.add_argument("--config", default=str(Path(__file__).parent / "config.yml"))
    parser.add_argument("--source-root", help="override config source_root")
    parser.add_argument("--target-root", help="override config target_root")
    parser.add_argument("--embodiments", nargs="+", help="override config embodiments")
    parser.add_argument("--tasks", nargs="+", help="override config tasks")
    parser.add_argument("--splits", nargs="+", choices=sorted(SPLIT_EPISODE_COUNTS), help="override config splits")
    parser.add_argument("--num-workers", type=int, help="override config num_workers")
    parser.add_argument("--max-episodes-per-group", type=int, help="cap episodes per (task, embodiment, split)")
    parser.add_argument("--dry-run", action="store_true", help="scan and print the plan, convert nothing")
    parser.add_argument("--verbose", action="store_true")
    return parser.parse_args(argv)


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = parse_args(argv)
    config = load_config(args.config)

    for name in ("source_root", "target_root", "num_workers"):
        value = getattr(args, name, None)
        if value is not None:
            config[name] = value
    for name in ("embodiments", "tasks", "splits"):
        value = getattr(args, name, None)
        if value:
            config[name] = value
    if args.max_episodes_per_group is not None:
        config["max_episodes_per_group"] = args.max_episodes_per_group

    if args.verbose or str(config.get("log_level", "")).upper() == "DEBUG":
        logging.getLogger().setLevel(logging.DEBUG)

    # Validate embodiment keys before doing any filesystem work.
    for key in config.get("embodiments") or []:
        get_embodiment(key)

    converter = UnifiedConverter(config)
    try:
        totals = converter.run(dry_run=args.dry_run)
    except Exception as exc:  # noqa: BLE001
        logger.error(f"conversion failed: {exc}")
        return 1
    return 1 if totals.get("failed") and not totals.get("converted") else 0


if __name__ == "__main__":
    mp.set_start_method("spawn", force=True)
    sys.exit(main())

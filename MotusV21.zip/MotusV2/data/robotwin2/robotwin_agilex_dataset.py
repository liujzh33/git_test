# Robotwin2 Dataset Loader for Motus
# Supports Robotwin2 data with video and action data from multiple tasks

import os
import io
import random
import h5py
import numpy as np
import cv2
import json
import torch
import torch.utils.data as data
from typing import Dict, Any, List, Optional, Tuple
import logging
from pathlib import Path
import warnings
from PIL import Image
import tempfile

# VLM processing imports
from utils.vlm_utils import preprocess_vlm_messages
from transformers import AutoProcessor

# Import image processing utilities
from data.utils.image_utils import (
    tensor_to_pil, apply_image_augmentation,
    load_video_frames, get_video_frame_count
)
from data.task_sampling import (
    resolve_task_sampling_weights,
    summarize_task_sampling,
)

# Unified EEF camera-delta imports
from data.human.unified_eef_action import (
    build_hand_world_poses_from_xyzquat,
    build_combined_qpos_eef_valid_mask,
    compute_unified_eef_action_sequence_with_gripper,
    compute_unified_eef_state_from_poses_with_gripper,
    pack_combined_qpos_eef_32,
    COMBINED_QPOS_EEF_ACTION_DIM,
    COMBINED_QPOS_EEF_RESERVED_INDICES,
    UNIFIED_EEF_ACTION_DIM,
    UNIFIED_EEF_STATE_DIM,
)

# Min-max normalizer for RobotWin
class MinMaxNormalizer:
    """Min-max normalizer for RobotWin actions/states.

    Normalizes data to [0, 1] range using min/max statistics.
    """

    def __init__(self, action_min: torch.Tensor, action_max: torch.Tensor, epsilon: float = 1e-7):
        """
        Args:
            action_min: Minimum values for each dimension [action_dim]
            action_max: Maximum values for each dimension [action_dim]
            epsilon: Small value to prevent division by zero
        """
        self.action_min = action_min
        self.action_max = action_max
        self.action_range = action_max - action_min
        self.epsilon = epsilon

    def normalize(self, x: torch.Tensor) -> torch.Tensor:
        """Normalize to [0, 1] range."""
        shape = x.shape
        x_flat = x.reshape(-1, shape[-1])
        norm = (x_flat - self.action_min.unsqueeze(0)) / (self.action_range.unsqueeze(0) + self.epsilon)
        return norm.reshape(shape)

    def denormalize(self, y: torch.Tensor) -> torch.Tensor:
        """Denormalize from [0, 1] range."""
        shape = y.shape
        y_flat = y.reshape(-1, shape[-1])
        denorm = y_flat * (self.action_range.unsqueeze(0) + self.epsilon) + self.action_min.unsqueeze(0)
        return denorm.reshape(shape)

    @classmethod
    def from_stats_file(cls, stats_path: str, action_mode: str = "qpos", device: str = "cpu") -> "MinMaxNormalizer":
        """Create normalizer from statistics JSON file.

        Args:
            stats_path: Path to stat.json file (local path or OBS URL)
            action_mode: "qpos" for 14-dim, "eepos" for 16-dim
            device: Device to load tensors on

        Returns:
            MinMaxNormalizer instance
        """
        if stats_path.startswith("obs://"):
            import moxing as mox
            stats_text = mox.file.read(stats_path, binary=False)
            stats = json.loads(stats_text)
        else:
            with open(stats_path, 'r') as f:
                stats = json.load(f)

        robotwin_stats = stats.get('robotwin2', stats)

        if action_mode == "qpos":
            # Use existing 14-dim stats
            action_min = torch.tensor(robotwin_stats['min'], dtype=torch.float32, device=device)
            action_max = torch.tensor(robotwin_stats['max'], dtype=torch.float32, device=device)
        elif action_mode == "eepos":
            # Check for 16-dim eepos stats
            if 'eepos_min' in robotwin_stats and 'eepos_max' in robotwin_stats:
                action_min = torch.tensor(robotwin_stats['eepos_min'], dtype=torch.float32, device=device)
                action_max = torch.tensor(robotwin_stats['eepos_max'], dtype=torch.float32, device=device)
            else:
                raise ValueError(
                    f"eepos statistics not found in {stats_path}. "
                    f"Please run scripts/generate_eepos_stats.py to generate eepos statistics."
                )
        elif action_mode == "unified_eef_camera_delta_wrist16":
            # Check for unified EEF stats
            if 'unified_eef_min' in robotwin_stats and 'unified_eef_max' in robotwin_stats:
                action_min = torch.tensor(robotwin_stats['unified_eef_min'], dtype=torch.float32, device=device)
                action_max = torch.tensor(robotwin_stats['unified_eef_max'], dtype=torch.float32, device=device)
            else:
                raise ValueError(
                    f"unified_eef_camera_delta_wrist16 statistics not found in {stats_path}. "
                    f"Please run scripts/generate_unified_eef_stats.py to generate statistics."
                )
        elif action_mode == "qpos_unified_eef_combined32":
            # Prefer dedicated 32D stats; otherwise concatenate qpos(14->16 padded) + unified_eef(16).
            if 'qpos_unified_eef_combined32_min' in robotwin_stats and 'qpos_unified_eef_combined32_max' in robotwin_stats:
                action_min = torch.tensor(
                    robotwin_stats['qpos_unified_eef_combined32_min'], dtype=torch.float32, device=device
                )
                action_max = torch.tensor(
                    robotwin_stats['qpos_unified_eef_combined32_max'], dtype=torch.float32, device=device
                )
            elif (
                'min' in robotwin_stats and 'max' in robotwin_stats
                and 'unified_eef_min' in robotwin_stats and 'unified_eef_max' in robotwin_stats
            ):
                from data.human.unified_eef_action import pad_qpos_14_to_16
                qpos_min_16 = pad_qpos_14_to_16(np.asarray(robotwin_stats['min'], dtype=np.float32))
                qpos_max_16 = pad_qpos_14_to_16(np.asarray(robotwin_stats['max'], dtype=np.float32))
                # Reserved pad dims stay zero range so normalize/denorm keep them at 0.
                qpos_min_16[[7, 15]] = 0.0
                qpos_max_16[[7, 15]] = 0.0
                eef_min = np.asarray(robotwin_stats['unified_eef_min'], dtype=np.float32)
                eef_max = np.asarray(robotwin_stats['unified_eef_max'], dtype=np.float32)
                action_min = torch.tensor(
                    np.concatenate([qpos_min_16, eef_min], axis=-1), dtype=torch.float32, device=device
                )
                action_max = torch.tensor(
                    np.concatenate([qpos_max_16, eef_max], axis=-1), dtype=torch.float32, device=device
                )
            else:
                raise ValueError(
                    f"qpos_unified_eef_combined32 statistics not found in {stats_path}. "
                    f"Provide qpos_unified_eef_combined32_min/max or both qpos min/max and unified_eef_min/max."
                )
        else:
            raise ValueError(f"Unknown action_mode: {action_mode}")

        return cls(action_min, action_max)

warnings.filterwarnings("ignore", category=FutureWarning, message=".*multichannel.*")

logger = logging.getLogger(__name__)

class RobotWinTaskDataset(data.Dataset):
    """
    Dataset for RobotWin data with task-level organization and flexible sampling.

    Data structure:
    /share/dataset/preprocess/robotwin2/
    ├── clean/
    │   ├── adjust_bottle/
    │   │   ├── qpos/           # Robot position files (.pt) - 14-dim joint positions
    │   │   ├── eepos/          # End-effector pose files (.pt) - 16-dim EE poses
    │   │   ├── videos/         # MP4 video files
    │   │   └── umt5_wan/       # Pre-encoded language embeddings (.pt)
    │   ├── beat_block_hammer/
    │   └── ...
    └── randomized/
        ├── adjust_bottle/
        └── ...
    """

    def __init__(
        self,
        dataset_dir: str = "/share/dataset/preprocess/robotwin2/",
        data_mode: str = "clean",  # "clean", "randomized", or "both"
        task_mode: str = "multi",  # "single" or "multi"
        task_name: Optional[str] = None,  # Required for single task mode
        randomized_limit_per_task: Optional[int] = None,  # Limit randomized episodes per task (take first N)
        task_sampling: Optional[Dict[str, Any]] = None,
        action_mode: str = "qpos",  # "qpos" | "eepos" | "unified_eef_camera_delta_wrist16" | "qpos_unified_eef_combined32"

        # Sampling parameters
        global_downsample_rate: int = 3,  # Global downsampling (e.g., 30Hz -> 10Hz)
        video_action_freq_ratio: int = 5,  # Video:Action frequency ratio
        num_video_frames: int = 3,  # Number of video frames to predict

        # Standard parameters
        video_size: Tuple[int, int] = (320, 384),
        max_episodes: Optional[int] = None,
        validation_split: float = 0.0,
        validation_seed: int = 42,
        upsample_rate: int = 1,  # For compatibility with H_RDT
        val: bool = False,
        image_aug: bool = False,

        # Normalization parameters
        normalization: bool = False,  # Enable min-max normalization
        normalization_stats_path: Optional[str] = None,  # Path to stat.json

        # VLM processing parameters
        vlm_checkpoint_path: Optional[str] = None,  # Path to VLM model
        vlm_type: str = "qwen3_vl",  # "qwen3_vl" or "molmo2"

        # OBS storage parameters
        storage_mode: str = "local",  # "local" (default) or "obs"
        obs_base_path: Optional[str] = None,  # OBS URL prefix when storage_mode="obs"

        # Motion token prediction parameters
        motion_token_prediction: Optional[Dict[str, Any]] = None,  # Config dict for motion token prediction
    ):
        """
        Initialize RobotWin dataset with flexible sampling.

        Args:
            dataset_dir: Root directory containing clean/ and randomized/ folders
            data_mode: Which data split to use ("clean", "randomized", or "both")
            task_mode: Single task or multi-task ("single" or "multi")
            task_name: Task name for single task mode (e.g., "adjust_bottle")
            action_mode: Action data mode - "qpos" (14-dim), "eepos" (16-dim),
                "unified_eef_camera_delta_wrist16" (16-dim), or
                "qpos_unified_eef_combined32" (32-dim abs qpos padded + unified EEF)

            global_downsample_rate: Global downsampling rate (e.g., 3 for 30Hz->10Hz)
            video_action_freq_ratio: Frequency ratio between video and action
            num_video_frames: Number of video frames to predict

            video_size: Target video resolution (H, W)
            max_episodes: Maximum number of episodes to load (for debugging)
            upsample_rate: Temporal data upsampling rate (for H_RDT compatibility)
            val: Whether this is validation set
            image_aug: Whether to apply image augmentation

            normalization: Enable min-max normalization to [0, 1] range
            normalization_stats_path: Path to stat.json file (required if normalization=True)

            storage_mode: "local" for local filesystem, "obs" for reading directly from OBS
            obs_base_path: OBS URL prefix (e.g., "obs://bucket/path/RoboTwin_emb") when storage_mode="obs"
        """
        self.dataset_dir = Path(dataset_dir)
        self.dataset_dir_str = str(dataset_dir)
        self.data_mode = data_mode
        self.task_mode = task_mode
        self.task_name = task_name
        self.randomized_limit_per_task = randomized_limit_per_task
        self.task_sampling = task_sampling or {}
        self.action_mode = action_mode

        # OBS storage setup
        self.storage_mode = storage_mode
        self.obs_base_path = obs_base_path
        self._mox = None
        if storage_mode == "obs":
            if obs_base_path is None:
                raise ValueError("obs_base_path is required when storage_mode='obs'")
            import moxing as mox
            self._mox = mox
            self._video_cache_dir = tempfile.mkdtemp(prefix="obs_video_cache_")
            logger.info(f"OBS storage mode enabled, base path: {obs_base_path}")
            logger.info(f"Video cache dir: {self._video_cache_dir}")

        # Validate action_mode
        valid_modes = [
            "qpos",
            "eepos",
            "unified_eef_camera_delta_wrist16",
            "qpos_unified_eef_combined32",
        ]
        if action_mode not in valid_modes:
            raise ValueError(f"action_mode must be one of {valid_modes}, got {action_mode}")

        # Set action dimension based on mode
        if action_mode == "qpos":
            self.action_dim = 14
        elif action_mode == "qpos_unified_eef_combined32":
            self.action_dim = COMBINED_QPOS_EEF_ACTION_DIM  # 32
        else:
            # eepos and unified_eef_camera_delta_wrist16 both use 16 dims
            self.action_dim = 16

        # Sampling parameters
        self.global_downsample_rate = global_downsample_rate
        self.video_action_freq_ratio = video_action_freq_ratio
        self.num_video_frames = num_video_frames

        # Calculate action sequence length
        self.action_chunk_size = num_video_frames * video_action_freq_ratio

        # Standard parameters
        self.video_size = video_size
        self.max_episodes = max_episodes
        self.validation_split = float(validation_split or 0.0)
        self.validation_seed = int(validation_seed)
        self.upsample_rate = upsample_rate
        self.val = val
        self.image_aug = image_aug

        # Normalization
        self.normalization = normalization
        self.normalizer = None
        if normalization:
            if normalization_stats_path is None:
                raise ValueError("normalization_stats_path is required when normalization=True")
            self.normalizer = MinMaxNormalizer.from_stats_file(
                normalization_stats_path, action_mode=action_mode
            )
            logger.info(f"Min-max normalization enabled with stats from {normalization_stats_path}")

        # Validate parameters
        if task_mode == "single" and not task_name:
            raise ValueError("Single task mode requires task_name parameter")

        assert data_mode in ["clean", "randomized", "both"], \
            f"data_mode must be 'clean', 'randomized', or 'both', got {data_mode}"

        # Initialize data structures
        if task_mode == "single":
            self.episode_files = []  # List of episode files for single task
        else:
            self.task_to_episodes = {}  # Task name -> episode files mapping
            self.task_weights = {}      # Task sampling weights

        self.total_episodes = 0
        
        logger.info(f"RobotWin dataset initialized:")
        logger.info(f"  Storage mode: {storage_mode}")
        if storage_mode == "obs":
            logger.info(f"  OBS base path: {obs_base_path}")
        logger.info(f"  Data mode: {data_mode}")
        logger.info(f"  Task mode: {task_mode}")
        logger.info(f"  Action mode: {action_mode} ({self.action_dim}-dim)")
        if task_name:
            logger.info(f"  Task name: {task_name}")
        logger.info(f"  Global downsample rate: {global_downsample_rate}")
        logger.info(f"  Video:Action frequency ratio: {video_action_freq_ratio}")
        logger.info(f"  Action chunk size: {self.action_chunk_size}")
        logger.info(f"  Video frames to predict: {num_video_frames}")
        logger.info(f"  Min-max normalization: {normalization}")
        logger.info(f"  Total episodes: {self.total_episodes}")
        
        # Initialize VLM processor for complete VLM processing in dataset
        self.vlm_processor = None
        self.vlm_type = vlm_type
        if vlm_checkpoint_path is not None:
            try:
                if vlm_type == "molmo2":
                    self.vlm_processor = AutoProcessor.from_pretrained(
                        vlm_checkpoint_path, trust_remote_code=True
                    )
                else:
                    self.vlm_processor = AutoProcessor.from_pretrained(vlm_checkpoint_path)
                logger.info(f"VLM processor loaded from {vlm_checkpoint_path} (type={vlm_type})")
            except Exception as e:
                logger.warning(f"Failed to load VLM processor from {vlm_checkpoint_path}: {e}")
                logger.warning("VLM processing will be disabled for this dataset instance")
        else:
            logger.info("VLM checkpoint path not provided, VLM processing disabled")

        # Load dataset episodes
        self._load_episodes()

        # Motion token prediction setup
        self.motion_token_enabled = False
        self.motion_tokenizer = None
        self.motion_token_processor = None
        if motion_token_prediction is not None and motion_token_prediction.get('enabled', False):
            from utils.motion_tokenizer import WristMotionTokenizer
            num_bins = motion_token_prediction.get('num_bins', 1024)
            self.motion_tokenizer = WristMotionTokenizer(
                k=num_bins,
                x_range=tuple(motion_token_prediction.get('x_range', [-0.5, 0.5])),
                y_range=tuple(motion_token_prediction.get('y_range', [-0.5, 0.5])),
                z_range=tuple(motion_token_prediction.get('z_range', [0.0, 1.2])),
            )
            # Load the extended-vocab processor for motion token encoding
            motion_vlm_path = motion_token_prediction.get('vlm_checkpoint_path', vlm_checkpoint_path)
            if motion_vlm_path is not None:
                try:
                    from transformers import AutoProcessor as _AP
                    self.motion_token_processor = _AP.from_pretrained(motion_vlm_path)
                    logger.info(f"Motion token processor loaded from {motion_vlm_path}")
                except Exception as e:
                    logger.warning(f"Failed to load motion token processor from {motion_vlm_path}: {e}")
            if self.motion_token_processor is None:
                raise ValueError(
                    "motion_token_prediction.enabled=True requires a valid extended-vocab "
                    "VLM processor. Check model.vlm.checkpoint_path / vlm_checkpoint_path."
                )
            tokenizer = getattr(self.motion_token_processor, "tokenizer", self.motion_token_processor)
            test_ids = tokenizer.encode("<|motion_x_0000|>", add_special_tokens=False)
            if len(test_ids) != 1:
                raise ValueError(
                    "Extended VLM tokenizer does not recognize motion tokens as single tokens: "
                    f"<|motion_x_0000|> -> {test_ids}"
                )
            self.motion_token_enabled = True
            logger.info(f"Motion token prediction enabled: bins={num_bins}, eepos dims [0:3]+[8:11]")

    # ── OBS storage helpers ──────────────────────────────────────────────

    def _local_to_obs(self, local_path: str) -> str:
        """Convert a local path to its OBS equivalent."""
        if self.storage_mode != "obs":
            return local_path
        rel = os.path.relpath(local_path, self.dataset_dir_str)
        return f"{self.obs_base_path}/{rel}"

    def _obs_to_local_cache(self, obs_path: str) -> str:
        """Map an OBS video path to a local cache path."""
        rel = obs_path.replace(self.obs_base_path + "/", "")
        return os.path.join(self._video_cache_dir, rel)

    def _path_exists(self, path: str) -> bool:
        if self.storage_mode == "obs":
            return self._mox.file.exists(path)
        return Path(path).exists()

    def _path_is_dir(self, path: str) -> bool:
        if self.storage_mode == "obs":
            return self._mox.file.is_directory(path)
        return Path(path).is_dir()

    def _list_dir(self, path: str) -> List[str]:
        """List directory entries. Returns absolute paths."""
        if self.storage_mode == "obs":
            return self._mox.file.list_directory(path, return_abs_path=True)
        return [str(p) for p in Path(path).iterdir()]

    def _read_bytes(self, path: str) -> bytes:
        """Read file content as bytes."""
        if self.storage_mode == "obs":
            return self._mox.file.read(path, binary=True)
        with open(path, 'rb') as f:
            return f.read()

    def _read_text(self, path: str) -> str:
        """Read file content as string."""
        if self.storage_mode == "obs":
            return self._mox.file.read(path, binary=False)
        with open(path, 'r', encoding='utf-8') as f:
            return f.read()

    def _get_video_local_path(self, video_path: str) -> str:
        """Get a local file path for a video. Downloads from OBS if not cached."""
        if self.storage_mode != "obs":
            return video_path
        local_cache = self._obs_to_local_cache(video_path)
        if not os.path.exists(local_cache):
            os.makedirs(os.path.dirname(local_cache), exist_ok=True)
            video_bytes = self._mox.file.read(video_path, binary=True)
            with open(local_cache, 'wb') as f:
                f.write(video_bytes)
        return local_cache
    
    def _limit_episodes_first_n(self, episodes: List[Dict[str, Any]], n: int) -> List[Dict[str, Any]]:
        """
        Limit to the first N episodes based on sorted episode_name.
        Numeric names are sorted numerically; otherwise lexicographically.
        """
        if n is None or n <= 0 or not episodes:
            return episodes
        def _sort_key(ep: Dict[str, Any]):
            name = ep.get('episode_name', '')
            try:
                return (0, int(name))
            except Exception:
                return (1, str(name))
        episodes_sorted = sorted(episodes, key=_sort_key)
        return episodes_sorted[:n]
    
    def _scan_task_folder(self, task_path) -> List[str]:
        """
        Scan a single task folder.

        Args:
            task_path: Path to task folder (e.g., .../clean/adjust_bottle).
                       str when storage_mode="obs", Path when "local".

        Returns:
            List of valid episode identifiers
        """
        # Determine which action directory to use based on action_mode.
        # Combined mode requires both qpos/ and eepos/; scan from eepos and
        # require a matching qpos file for each episode.
        combined_mode = self.action_mode == "qpos_unified_eef_combined32"
        if self.action_mode == "qpos":
            action_dir_name = "qpos"
        else:
            # eepos, unified_eef_camera_delta_wrist16, qpos_unified_eef_combined32
            action_dir_name = "eepos"

        # Key name in episode_data: for unified_eef / combined, raw data is eepos.
        if self.action_mode in ("qpos", "eepos"):
            action_path_key = f'{self.action_mode}_path'
        else:
            action_path_key = f'{action_dir_name}_path'  # e.g., 'eepos_path'

        # Extract task_name and split_name from path
        task_path_str = str(task_path)
        task_name = task_path_str.rstrip("/").split("/")[-1]
        split_name = task_path_str.rstrip("/").split("/")[-2]

        if self.storage_mode == "obs":
            action_dir = f"{task_path_str}/{action_dir_name}"
            videos_dir = f"{task_path_str}/videos"
            umt5_dir = f"{task_path_str}/umt5_wan"
            qpos_dir = f"{task_path_str}/qpos" if combined_mode else None

            required_dirs = [action_dir, videos_dir, umt5_dir]
            if combined_mode:
                required_dirs.append(qpos_dir)
            if not all([self._path_exists(d) for d in required_dirs]):
                logger.warning(
                    f"Missing data directories in {task_path_str} "
                    f"(looking for {action_dir_name}"
                    f"{' + qpos' if combined_mode else ''})"
                )
                return []

            valid_episodes = []
            action_entries = self._list_dir(action_dir)
            for entry in action_entries:
                if not entry.endswith(".pt"):
                    continue
                episode_name = entry.rsplit("/", 1)[-1][:-3]  # strip .pt
                video_file = f"{videos_dir}/{episode_name}.mp4"
                lang_file = f"{umt5_dir}/{episode_name}.pt"
                qpos_file = f"{qpos_dir}/{episode_name}.pt" if combined_mode else None

                if not (self._path_exists(video_file) and self._path_exists(lang_file)):
                    continue
                if combined_mode and not self._path_exists(qpos_file):
                    continue

                episode_data = {
                    'episode_name': episode_name,
                    'task_name': task_name,
                    action_path_key: entry,
                    'video_path': video_file,
                    'lang_path': lang_file,
                }
                if combined_mode:
                    episode_data['qpos_path'] = qpos_file
                valid_episodes.append(episode_data)
        else:
            action_dir = Path(task_path) / action_dir_name
            videos_dir = Path(task_path) / "videos"
            umt5_dir = Path(task_path) / "umt5_wan"
            qpos_dir = Path(task_path) / "qpos" if combined_mode else None

            required_dirs = [action_dir, videos_dir, umt5_dir]
            if combined_mode:
                required_dirs.append(qpos_dir)
            if not all(d.exists() for d in required_dirs):
                logger.warning(
                    f"Missing data directories in {task_path} "
                    f"(looking for {action_dir_name}"
                    f"{' + qpos' if combined_mode else ''})"
                )
                return []

            valid_episodes = []
            action_files = list(action_dir.glob("*.pt"))

            for action_file in action_files:
                episode_name = action_file.stem
                video_file = videos_dir / f"{episode_name}.mp4"
                lang_file = umt5_dir / f"{episode_name}.pt"
                qpos_file = qpos_dir / f"{episode_name}.pt" if combined_mode else None

                if not (video_file.exists() and lang_file.exists()):
                    continue
                if combined_mode and not qpos_file.exists():
                    continue

                episode_data = {
                    'episode_name': episode_name,
                    'task_name': Path(task_path).name,
                    action_path_key: str(action_file),
                    'video_path': str(video_file),
                    'lang_path': str(lang_file),
                }
                if combined_mode:
                    episode_data['qpos_path'] = str(qpos_file)
                valid_episodes.append(episode_data)

        logger.info(
            f"Task {task_name} ({split_name}): Found {len(valid_episodes)} valid episodes "
            f"using {action_dir_name}{' + qpos' if combined_mode else ''}"
        )
        return valid_episodes
    
    def _load_episodes(self) -> List[Dict[str, Any]]:
        """Initialize dataset by scanning folders."""
        logger.info("Initializing dataset...")

        # Determine which data splits to scan
        if self.data_mode == "both":
            data_splits = ["clean", "randomized"]
        else:
            data_splits = [self.data_mode]

        all_episodes = []

        for split in data_splits:
            if self.storage_mode == "obs":
                split_dir = f"{self.obs_base_path}/{split}"
            else:
                split_dir = self.dataset_dir / split

            if not self._path_exists(str(split_dir)):
                logger.warning(f"Split directory not found: {split_dir}")
                continue

            if self.task_mode == "single":
                # Single task mode: scan specific task
                if self.storage_mode == "obs":
                    task_dir = f"{split_dir}/{self.task_name}"
                else:
                    task_dir = split_dir / self.task_name

                if self._path_exists(str(task_dir)):
                    episodes = self._scan_task_folder(task_dir)
                    if split == "randomized" and self.randomized_limit_per_task is not None:
                        before = len(episodes)
                        episodes = self._limit_episodes_first_n(episodes, self.randomized_limit_per_task)
                        logger.info(f"Applied randomized per-task limit ({self.randomized_limit_per_task}) for {task_dir}: {before} -> {len(episodes)}")
                    all_episodes.extend(episodes)
                else:
                    logger.warning(f"Task directory not found: {task_dir}")

            else:
                # Multi task mode: scan all tasks
                entries = self._list_dir(str(split_dir))
                for entry in entries:
                    entry_str = str(entry)
                    if not self._path_is_dir(entry_str):
                        continue
                    episodes = self._scan_task_folder(entry_str)

                    if split == "randomized" and self.randomized_limit_per_task is not None:
                        before = len(episodes)
                        episodes = self._limit_episodes_first_n(episodes, self.randomized_limit_per_task)
                        task_name = entry_str.rstrip("/").split("/")[-1]
                        logger.info(f"Applied randomized per-task limit ({self.randomized_limit_per_task}) for {task_name}: {before} -> {len(episodes)}")

                    # Group by task for multi-task sampling
                    task_name = entry_str.rstrip("/").split("/")[-1]
                    if task_name not in self.task_to_episodes:
                        self.task_to_episodes[task_name] = []
                    self.task_to_episodes[task_name].extend(episodes)
        
        if self.task_mode == "single":
            self.episode_files = self._apply_train_val_split(all_episodes)
            
            # Limit episodes if requested
            if self.max_episodes is not None:
                self.episode_files = self.episode_files[:self.max_episodes]
            
            self.total_episodes = len(self.episode_files)
            
            if self.total_episodes == 0:
                raise ValueError(f"No valid episodes found for task {self.task_name}")
        
        else:
            # Apply deterministic held-out split per task when requested.
            # Review Major-2: train/val previously sampled from the same episode
            # pool, which made validation metrics non-independent.
            if self.validation_split > 0:
                for task_name in list(self.task_to_episodes.keys()):
                    split_episodes = self._apply_train_val_split(
                        self.task_to_episodes[task_name],
                        namespace=task_name,
                    )
                    if split_episodes:
                        self.task_to_episodes[task_name] = split_episodes
                    else:
                        logger.warning(
                            f"Task {task_name} has no episodes after "
                            f"{'val' if self.val else 'train'} split; dropping task"
                        )
                        del self.task_to_episodes[task_name]

            # Multi-task mode: calculate sampling weights
            if not self.task_to_episodes:
                raise ValueError("No valid episodes found for any task")

            num_tasks = len(self.task_to_episodes)
            self.task_weights = resolve_task_sampling_weights(
                self.task_to_episodes.keys(),
                self.task_sampling,
                is_validation=self.val,
            )
            
            self.total_episodes = sum(len(episodes) for episodes in self.task_to_episodes.values())
            
            logger.info(f"Multi-task dataset with {num_tasks} tasks:")
            for task_name, episodes in self.task_to_episodes.items():
                logger.info(f"  {task_name}: {len(episodes)} episodes")

            sampling_summary = self.get_task_sampling_info()
            logger.info(
                "Task sampling mode=%s, probability range=[%.4f, %.4f], sum=%.6f",
                "validation" if self.val else "training",
                sampling_summary["min_probability"],
                sampling_summary["max_probability"],
                sampling_summary["probability_sum"],
            )
            for task_name, probability in sampling_summary["top_tasks"]:
                logger.info(f"  sampling top: {task_name}={probability:.4%}")
            for group_name, probability in sampling_summary.get(
                "group_probabilities", {}
            ).items():
                logger.info(
                    f"  sampling group probability: {group_name}={probability:.4%}"
                )
        
        # Return all episodes for consistency with other datasets
        return all_episodes

    def get_task_sampling_info(self) -> Dict[str, Any]:
        """Return normalized task probabilities and configured group totals."""
        groups = (
            self.task_sampling.get("groups", [])
            if self.task_sampling and self.task_sampling.get("enabled", False)
            else []
        )
        summary = summarize_task_sampling(self.task_weights, groups)
        summary["weights"] = dict(self.task_weights)
        summary["is_validation"] = self.val
        return summary

    def _apply_train_val_split(
        self,
        episodes: List[Dict[str, Any]],
        namespace: str = "",
    ) -> List[Dict[str, Any]]:
        """Deterministically split episodes into train/validation subsets."""
        if self.validation_split <= 0 or not episodes:
            return episodes
        if self.validation_split >= 1:
            raise ValueError(f"validation_split must be in [0, 1), got {self.validation_split}")

        episodes_sorted = sorted(
            episodes,
            key=lambda ep: (
                ep.get("task_name", ""),
                ep.get("episode_name", ""),
                ep.get("eepos_path", ep.get("qpos_path", "")),
            ),
        )
        rng = random.Random(f"{self.validation_seed}:{namespace}")
        shuffled = list(episodes_sorted)
        rng.shuffle(shuffled)
        val_count = max(1, int(round(len(shuffled) * self.validation_split))) if len(shuffled) > 1 else 0
        val_keys = {
            (
                ep.get("task_name", ""),
                ep.get("episode_name", ""),
                ep.get("eepos_path", ep.get("qpos_path", "")),
            )
            for ep in shuffled[:val_count]
        }

        def _key(ep: Dict[str, Any]):
            return (
                ep.get("task_name", ""),
                ep.get("episode_name", ""),
                ep.get("eepos_path", ep.get("qpos_path", "")),
            )

        selected = [ep for ep in episodes_sorted if (_key(ep) in val_keys) == self.val]
        split_name = "val" if self.val else "train"
        logger.info(
            f"Applied RobotWin {split_name} split"
            f"{f' ({namespace})' if namespace else ''}: "
            f"{len(selected)}/{len(episodes_sorted)} episodes "
            f"(validation_split={self.validation_split})"
        )
        return selected

    def _load_robot_data(self, action_path: str, action_indices: List[int], initial_state_idx: int = 0) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Load robot action data (qpos or eepos).

        Args:
            action_path: Path to action .pt file (qpos or eepos), or OBS URL
            action_indices: List of action frame indices
            initial_state_idx: Index for initial state (should match condition frame)

        Returns:
            - initial_state: Robot state at condition frame [state_dim]
            - action_sequence: Actions at specified indices [len(action_indices), action_dim]
        """
        if self.storage_mode == "obs":
            data_bytes = self._read_bytes(action_path)
            action_data = torch.load(io.BytesIO(data_bytes), map_location='cpu', weights_only=True)
        else:
            action_data = torch.load(action_path, map_location='cpu', weights_only=True)

        # Get initial state at the condition frame index
        if initial_state_idx >= len(action_data):
            initial_state_idx = len(action_data) - 1
        initial_state = action_data[initial_state_idx].float()

        # Get action sequence at specified indices
        actions = []
        for idx in action_indices:
            if idx >= len(action_data):
                raise IndexError(f"Action index {idx} out of bounds for data length {len(action_data)}")
            else:
                action = action_data[idx]
            actions.append(action)

        action_sequence = torch.stack(actions).float()

        return initial_state, action_sequence

    def _load_raw_eepos(self, eepos_path: str) -> torch.Tensor:
        """Load raw eepos data for unified EEF conversion.

        Args:
            eepos_path: Path to eepos .pt file, or OBS URL.

        Returns:
            eepos_data: Shape (N, 16), float32 tensor with absolute EEF poses.
        """
        if self.storage_mode == "obs":
            data_bytes = self._read_bytes(eepos_path)
            action_data = torch.load(io.BytesIO(data_bytes), map_location='cpu', weights_only=True)
        else:
            action_data = torch.load(eepos_path, map_location='cpu', weights_only=True)
        return action_data.float()

    def _normalize_robot_data(
        self,
        initial_state: torch.Tensor,
        action_sequence: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Normalize robot state/actions and keep unified EEF reserved dims zero."""
        initial_state = self.normalizer.normalize(initial_state)
        action_sequence = self.normalizer.normalize(action_sequence)
        if self.action_mode == "unified_eef_camera_delta_wrist16":
            initial_state[[7, 15]] = 0.0
            action_sequence[:, [7, 15]] = 0.0
        elif self.action_mode == "qpos_unified_eef_combined32":
            initial_state[COMBINED_QPOS_EEF_RESERVED_INDICES] = 0.0
            action_sequence[:, COMBINED_QPOS_EEF_RESERVED_INDICES] = 0.0
        return initial_state, action_sequence

    def _load_language_embedding(self, lang_path: str) -> tuple[torch.Tensor, int]:
        """Load pre-encoded language embedding and return the selected index."""
        try:
            if self.storage_mode == "obs":
                data_bytes = self._read_bytes(lang_path)
                embedding_data = torch.load(io.BytesIO(data_bytes), map_location='cpu', weights_only=True)
            else:
                embedding_data = torch.load(lang_path, map_location='cpu', weights_only=True)
            
            # RobotWin embedding is always a list of tensors
            selected_idx = random.randint(0, len(embedding_data) - 1)
            embeddings = embedding_data[selected_idx]  # [seq_len, 4096]
            
            # Remove batch dimension if present
            if embeddings.dim() == 3:
                embeddings = embeddings.squeeze(0)
            
            return embeddings, selected_idx
            
        except Exception as e:
            logger.error(f"Error loading language embedding from {lang_path}: {e}")
            raise
    
    def _load_text_instruction(self, task_name: str, episode_name: str, instruction_idx: int = None, split: Optional[str] = None) -> str:
        """Load text instruction for VLM processing.

        Args:
            task_name: Task name (e.g., "adjust_bottle")
            episode_name: Episode identifier (e.g., "429")
            instruction_idx: Optional index to select a deterministic instruction
            split: Dataset split to read from ("clean" or "randomized"). If None,
                   falls back to self.data_mode when it is not "both".
        """
        try:
            if split is None:
                if self.data_mode in ["clean", "randomized"]:
                    split_to_use = self.data_mode
                else:
                    split_to_use = "clean"
            else:
                split_to_use = split

            if self.storage_mode == "obs":
                meta_file = f"{self.obs_base_path}/{split_to_use}/{task_name}/metas/{episode_name}.txt"
            else:
                meta_file = str(self.dataset_dir / split_to_use / task_name / "metas" / f"{episode_name}.txt")

            if self._path_exists(meta_file):
                text = self._read_text(meta_file)
                lines = text.strip().split('\n')
                instructions = [line.strip() for line in lines if line.strip()]

                if instructions:
                    if instruction_idx is not None and 0 <= instruction_idx < len(instructions):
                        return instructions[instruction_idx]
                    else:
                        import random
                        return random.choice(instructions)
                else:
                    raise ValueError(f"No instructions found in meta file for {task_name}/{episode_name}")
            else:
                raise FileNotFoundError(f"Meta file not found: {meta_file}")

        except Exception as e:
            logger.error(f"Failed to load text instruction for {task_name}/{episode_name}: {e}")
            raise
    
    def _calculate_sampling_indices(self, total_frames: int) -> Tuple[int, List[int], List[int]]:
        """
        Calculate sampling indices.
        
        Args:
            total_frames: Total number of frames in the episode
            
        Returns:
            - condition_frame_idx: Index of condition frame (corresponds to initial state)
            - video_indices: List of video frame indices to predict
            - action_indices: List of action frame indices to predict
        """
        # Calculate physical span of one chunk
        physical_chunk_size = self.action_chunk_size * self.global_downsample_rate
        
        # Sample condition frame directly in physical space
        # Ensure the last action doesn't exceed total_frames - 1
        max_condition_idx = total_frames - physical_chunk_size - 1
        
        if max_condition_idx < 0:
            condition_frame_idx = 0
        else:
            condition_frame_idx = random.randint(0, max_condition_idx)
        
        # Action indices: from condition_frame_idx+1 onwards, with downsampling
        action_indices = []
        for i in range(self.action_chunk_size):
            # Each action is separated by global_downsample_rate frames
            action_idx = condition_frame_idx + (i + 1) * self.global_downsample_rate
            action_indices.append(min(action_idx, total_frames - 1))
        
        # Video indices: sample at frequency ratio intervals from action indices
        # Example: ratio=5, frames=[5, 10, 15, 20] for 4 video frames
        video_indices = []
        for i in range(self.num_video_frames):
            action_step = (i + 1) * self.video_action_freq_ratio - 1
            if action_step < len(action_indices):
                video_indices.append(action_indices[action_step])
            else:
                video_indices.append(action_indices[-1])
        
        # Verify spacing
        if len(action_indices) > 1:
            intervals = [action_indices[i+1] - action_indices[i] for i in range(len(action_indices)-1)]
            # print(f"  Action interval verification: {set(intervals)} (should all be {self.global_downsample_rate})")
        
        return condition_frame_idx, video_indices, action_indices

    # ── Head camera extrinsics (fixed, verified from HDF5 data) ──
    #
    # Source: /cache/wx1469573/data/aloha-agilex_clean_50/data/episode*.hdf5
    #   observation/head_camera/extrinsic_cv  (world-to-camera, OpenCV convention)
    #
    # Verified: all 50 episodes have IDENTICAL extrinsics (max diff = 0.0),
    # and the value is constant across all frames within each episode.
    # This is expected because random_head_camera_dis=0 in the task configs.
    #
    # The extrinsic_cv is the world-to-camera transform [R_w2c | t_w2c]:
    #   R_w2c = [[1,  0,  0],
    #            [0, -0.8, -0.6],
    #            [0,  0.6, -0.8]]
    #   t_w2c = [0.032, 0.45, 1.35]
    #
    # We need R_w_c (camera-to-world rotation) and t_w_c (camera position):
    #   R_w_c = R_w2c^T
    #   t_w_c = -R_w_c @ t_w2c = [-0.032, -0.45, 1.35]
    #
    # Convention: R_w_c maps camera-frame vectors to world frame (OpenCV:
    # x=right, y=down, z=forward).
    #
    # NOTE: The forward/left/up from config.yml (position=[-0.032,-0.45,1.35],
    # forward=[0,0.6,-0.8], left=[-1,0,0]) are *semantic* directions, not
    # camera axes.  SAPIEN's get_extrinsic_matrix() converts them to OpenCV:
    #   x_cam = right = -left
    #   y_cam = down  = -up = -cross(forward, left)
    #   z_cam = forward
    # So R_w_c = [right, down, forward] = [-left, -up, forward].
    _HEAD_CAMERA_R_W_C = np.array([
        [ 1.0,  0.0,  0.0],
        [ 0.0, -0.8,  0.6],
        [ 0.0, -0.6, -0.8],
    ], dtype=np.float64)

    _HEAD_CAMERA_T_W_C = np.array([-0.032, -0.45, 1.35], dtype=np.float64)

    def _get_head_camera_extrinsics(self) -> Tuple[np.ndarray, np.ndarray]:
        """Return (R_w_c, t_w_c) for the fixed head camera.

        Returns:
            R_w_c: Camera rotation in world (3, 3), maps camera-frame vectors to world.
            t_w_c: Camera position in world (3,).
        """
        return self._HEAD_CAMERA_R_W_C.astype(np.float32), self._HEAD_CAMERA_T_W_C.astype(np.float32)

    def _extract_unified_eef_action_state(
        self,
        eepos_data: torch.Tensor,
        condition_frame_idx: int,
        action_indices: List[int],
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, None]:
        """Extract unified_eef_camera_delta_wrist16 action and state from eepos data.

        Converts absolute EEF poses (xyz + quat_wxyz + gripper) to camera-frame
        delta actions with gripper state, using the fixed head camera extrinsics.

        eepos layout: [left_xyz(3), left_quat_wxyz(4), left_gripper(1),
                       right_xyz(3), right_quat_wxyz(4), right_gripper(1)] = 16D

        Output layout: [left_delta_xyz_cam(3), left_delta_rotvec_cam(3), left_gripper(1), 0,
                        right_delta_xyz_cam(3), right_delta_rotvec_cam(3), right_gripper(1), 0] = 16D

        Args:
            eepos_data: Raw eepos tensor, shape (N, 16).
            condition_frame_idx: Anchor frame index.
            action_indices: Target frame indices for actions.

        Returns:
            initial_state: Shape (16,), unified state.
            action_sequence: Shape (T, 16,), unified action sequence.
            action_valid_mask: Shape (T, 16,), per-dim validity mask.
            instruction: Always None (instruction loaded separately).
        """
        R_w_c, t_w_c = self._get_head_camera_extrinsics()

        eepos_np = eepos_data.numpy().astype(np.float64)

        # Build world-frame hand poses from eepos data
        left_xyz = eepos_np[:, 0:3]     # (N, 3)
        left_quat = eepos_np[:, 3:7]    # (N, 4) WXYZ
        left_grip = eepos_np[:, 7]      # (N,)
        right_xyz = eepos_np[:, 8:11]   # (N, 3)
        right_quat = eepos_np[:, 11:15] # (N, 4) WXYZ
        right_grip = eepos_np[:, 15]    # (N,)

        left_R_w, left_t_w = build_hand_world_poses_from_xyzquat(left_xyz, left_quat)
        right_R_w, right_t_w = build_hand_world_poses_from_xyzquat(right_xyz, right_quat)

        # Build full frame sequence: anchor + targets
        # Frame 0 = anchor, Frame 1..T = action targets
        all_frame_indices = [condition_frame_idx] + action_indices
        num_action_frames = len(action_indices)

        # Extract poses for all frames
        left_R_seq = left_R_w[all_frame_indices]    # (T+1, 3, 3)
        left_t_seq = left_t_w[all_frame_indices]    # (T+1, 3)
        right_R_seq = right_R_w[all_frame_indices]  # (T+1, 3, 3)
        right_t_seq = right_t_w[all_frame_indices]  # (T+1, 3)

        left_grip_seq = left_grip[all_frame_indices]   # (T+1,)
        right_grip_seq = right_grip[all_frame_indices] # (T+1,)

        # Both hands are always valid for robot data
        left_valid = np.ones(len(all_frame_indices), dtype=bool)
        right_valid = np.ones(len(all_frame_indices), dtype=bool)

        # Compute action sequence (anchor-based)
        actions, action_masks = compute_unified_eef_action_sequence_with_gripper(
            R_w_e_left=left_R_seq,
            t_w_e_left=left_t_seq,
            R_w_e_right=right_R_seq,
            t_w_e_right=right_t_seq,
            R_w_c=R_w_c,
            left_gripper=left_grip_seq,
            right_gripper=right_grip_seq,
            left_valid=left_valid,
            right_valid=right_valid,
            num_action_frames=num_action_frames,
        )

        # Compute state at anchor frame
        state, _ = compute_unified_eef_state_from_poses_with_gripper(
            R_w_e_left=left_R_seq[0],
            t_w_e_left=left_t_seq[0],
            R_w_e_right=right_R_seq[0],
            t_w_e_right=right_t_seq[0],
            R_w_c=R_w_c,
            t_w_c=t_w_c,
            left_gripper=float(left_grip_seq[0]),
            right_gripper=float(right_grip_seq[0]),
            left_valid=True,
            right_valid=True,
        )

        return (
            torch.from_numpy(state),
            torch.from_numpy(actions),
            torch.from_numpy(action_masks),
            None,
        )

    def _extract_combined_qpos_eef_action_state(
        self,
        qpos_path: str,
        eepos_path: str,
        condition_frame_idx: int,
        action_indices: List[int],
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, None]:
        """Build 32D state/action: padded abs qpos (16) || unified EEF (16).

        Layout:
            [0:16]  abs qpos padded: [L_qpos7, 0, R_qpos7, 0]
            [16:32] unified EEF:     [L_eef7,  0, R_eef7,  0]

        Qpos semantics match action_mode=qpos (absolute joint targets).
        EEF semantics match action_mode=unified_eef_camera_delta_wrist16.
        Reserved dims [7, 15, 23, 31] are zero and masked out of loss.
        """
        qpos_state, qpos_actions = self._load_robot_data(
            qpos_path, action_indices, condition_frame_idx
        )
        if qpos_state.shape[-1] != 14 or qpos_actions.shape[-1] != 14:
            raise ValueError(
                f"Expected 14D qpos, got state={tuple(qpos_state.shape)} "
                f"actions={tuple(qpos_actions.shape)}"
            )

        eepos_data = self._load_raw_eepos(eepos_path)
        eef_state, eef_actions, eef_mask, _ = self._extract_unified_eef_action_state(
            eepos_data, condition_frame_idx, action_indices
        )

        state_32 = pack_combined_qpos_eef_32(
            qpos_state.numpy(),
            eef_state.numpy(),
        )
        actions_32 = pack_combined_qpos_eef_32(
            qpos_actions.numpy(),
            eef_actions.numpy(),
        )
        mask_32 = build_combined_qpos_eef_valid_mask(eef_mask.numpy())

        return (
            torch.from_numpy(state_32),
            torch.from_numpy(actions_32),
            torch.from_numpy(mask_32),
            None,
        )

    def __len__(self) -> int:
        """Return approximate dataset length."""
        return self.total_episodes * 10  # Assume 100 samples per episode
    
    def __getitem__(self, idx: int) -> Optional[Dict[str, Any]]:
        """
        Get a training sample.
        
        Args:
            idx: Sample index (not used, random sampling)
            
        Returns:
            Dictionary containing training data
        """
        # Robust sampling with retries to avoid returning None (which breaks DDP sync)
        max_attempts = 8
        for _ in range(max_attempts):
            # Select episode
            if self.task_mode == "single":
                if not self.episode_files:
                    continue
                episode_data = random.choice(self.episode_files)
            else:
                if not self.task_to_episodes:
                    continue
                task_name = random.choices(
                    list(self.task_weights.keys()),
                    weights=list(self.task_weights.values()),
                    k=1
                )[0]
                task_episodes = self.task_to_episodes.get(task_name, [])
                if not task_episodes:
                    continue
                episode_data = random.choice(task_episodes)

            try:
                # Get local video path (downloads to cache if OBS mode)
                video_local_path = self._get_video_local_path(episode_data['video_path'])

                # Get video frame count (decord-based; robust to ffmpeg timeouts)
                total_frames = get_video_frame_count(video_local_path)
                if total_frames < 2:
                    continue

                # Calculate sampling indices
                condition_frame_idx, video_indices, action_indices = self._calculate_sampling_indices(total_frames)

                # Load frames and aligned robot/action data
                first_frame = load_video_frames(video_local_path, [condition_frame_idx], self.video_size)
                video_frames = load_video_frames(video_local_path, video_indices, self.video_size)

                # Action loading depends on action_mode
                action_valid_mask = None
                if self.action_mode == "unified_eef_camera_delta_wrist16":
                    # Read raw eepos data and convert to unified camera-delta
                    eepos_data = self._load_raw_eepos(episode_data['eepos_path'])
                    initial_state, action_sequence, action_valid_mask, _ = \
                        self._extract_unified_eef_action_state(
                            eepos_data, condition_frame_idx, action_indices)
                elif self.action_mode == "qpos_unified_eef_combined32":
                    initial_state, action_sequence, action_valid_mask, _ = \
                        self._extract_combined_qpos_eef_action_state(
                            episode_data['qpos_path'],
                            episode_data['eepos_path'],
                            condition_frame_idx,
                            action_indices,
                        )
                else:
                    # Original path: qpos or eepos (direct use)
                    action_path_key = f'{self.action_mode}_path'  # 'qpos_path' or 'eepos_path'
                    initial_state, action_sequence = self._load_robot_data(episode_data[action_path_key], action_indices, condition_frame_idx)

                language_embedding, instruction_idx = self._load_language_embedding(episode_data['lang_path'])

                # Apply min-max normalization if enabled.  Unified EEF uses
                # its own unified_eef_min/max stats loaded at init; keep the
                # reserved dims zero after normalization so they never become
                # state/action signal by min/max offset.
                if self.normalization:
                    initial_state, action_sequence = self._normalize_robot_data(
                        initial_state,
                        action_sequence,
                    )

                # Infer split from paths
                inferred_split = None
                try:
                    # Check keys that exist in episode_data
                    for key in ('eepos_path', 'qpos_path', 'video_path', 'lang_path'):
                        if key in episode_data:
                            path_str = str(episode_data[key])
                            if '/clean/' in path_str:
                                inferred_split = 'clean'
                                break
                            if '/randomized/' in path_str:
                                inferred_split = 'randomized'
                                break
                except Exception:
                    inferred_split = None

                # Load raw text instruction for VLM processing using the same index
                text_instruction = self._load_text_instruction(
                    episode_data['task_name'],
                    episode_data['episode_name'],
                    instruction_idx,
                    split=inferred_split,
                )

                # Complete VLM processing in dataset
                vlm_inputs = None
                vlm_user_inputs = None
                motion_token_labels = None
                first_frame_pil = tensor_to_pil(first_frame.squeeze(0))

                if self.motion_token_enabled and self.motion_token_processor is not None:
                    # Motion token prediction: build full prompt+response VLM inputs
                    raw_action = action_sequence
                    if self.normalization and self.normalizer is not None:
                        raw_action = self.normalizer.denormalize(action_sequence)

                    import numpy as np
                    left_xyz = raw_action[:, 0:3].numpy().astype(np.float32)   # [T, 3]
                    right_xyz = raw_action[:, 8:11].numpy().astype(np.float32)  # [T, 3]

                    left_token_str = self.motion_tokenizer.encode_token_string(left_xyz)
                    right_token_str = self.motion_tokenizer.encode_token_string(right_xyz)

                    from utils.vlm_utils import preprocess_vlm_messages_with_motion_tokens
                    mt_inputs = preprocess_vlm_messages_with_motion_tokens(
                        text_instruction=text_instruction,
                        image_pil=first_frame_pil,
                        processor=self.motion_token_processor,
                        left_motion_token_str=left_token_str,
                        right_motion_token_str=right_token_str,
                    )
                    from utils.vlm_utils import preprocess_vlm_messages_motion_prompt_only
                    vlm_user_inputs = preprocess_vlm_messages_motion_prompt_only(
                        text_instruction=text_instruction,
                        image_pil=first_frame_pil,
                        processor=self.motion_token_processor,
                    )
                    vlm_inputs = mt_inputs
                    motion_token_labels = mt_inputs.pop('labels')  # [1, seq_len]

                elif self.vlm_processor is not None:
                    # Standard VLM processing (user prompt only, for MoT)
                    if self.vlm_type == "molmo2":
                        from utils.vlm_utils import preprocess_vlm_messages_molmo2
                        vlm_inputs = preprocess_vlm_messages_molmo2(text_instruction, first_frame_pil, self.vlm_processor)
                    else:
                        vlm_inputs = preprocess_vlm_messages(text_instruction, first_frame_pil, self.vlm_processor)

                result = {
                    'first_frame': first_frame.squeeze(0),
                    'video_frames': video_frames,
                    'initial_state': initial_state,
                    'action_sequence': action_sequence,
                    'language_embedding': language_embedding,
                    'task_name': episode_data['task_name'],
                    'vlm_inputs': vlm_inputs,
                    'vlm_user_inputs': vlm_user_inputs,
                    'motion_token_labels': motion_token_labels,
                }
                if action_valid_mask is not None:
                    result['action_valid_mask'] = action_valid_mask
                return result

            except Exception as e:
                logger.warning(f"Retry due to sample error ({episode_data.get('episode_name','?')}): {e}")
                continue

        # If all attempts failed, let caller drop this sample (rare)
        return None

#!/bin/bash
# Add eepos data to existing converted RobotWin dataset

echo "Starting eepos addition at $(date)"

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ============================================================================
# Load Configuration from config.yml
# ============================================================================
CONFIG_FILE="${SCRIPT_DIR}/config.yml"

if [ ! -f "$CONFIG_FILE" ]; then
    echo "Error: Configuration file not found: $CONFIG_FILE"
    exit 1
fi

echo "Loading configuration from: $CONFIG_FILE"

# Parse YAML configuration
SOURCE_ROOT=$(grep "^source_root:" "$CONFIG_FILE" | sed 's/#.*//' | sed 's/.*: *"\?\([^"]*\)"\?.*/\1/' | tr -d '"' | xargs)
TARGET_ROOT=$(grep "^target_root:" "$CONFIG_FILE" | sed 's/#.*//' | sed 's/.*: *"\?\([^"]*\)"\?.*/\1/' | tr -d '"' | xargs)

# ============================================================================
# Validation
# ============================================================================
if [ -z "$SOURCE_ROOT" ]; then
    echo "Error: source_root is not set in $CONFIG_FILE"
    exit 1
fi

if [ -z "$TARGET_ROOT" ]; then
    echo "Error: target_root is not set in $CONFIG_FILE"
    exit 1
fi

if [ ! -d "$SOURCE_ROOT" ]; then
    echo "Error: Source root not found: $SOURCE_ROOT"
    exit 1
fi

if [ ! -d "$TARGET_ROOT" ]; then
    echo "Error: Target root not found: $TARGET_ROOT"
    echo "Please run the main conversion first to create the target dataset."
    exit 1
fi

echo "Configuration loaded successfully:"
echo "  Source Root: $SOURCE_ROOT"
echo "  Target Root: $TARGET_ROOT"

# ============================================================================
# Run add_eepos.py
# ============================================================================
cd "$SCRIPT_DIR"

# Create log directory
LOG_DIR="${SCRIPT_DIR}/logs"
mkdir -p "$LOG_DIR"

TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
LOG_FILE="${LOG_DIR}/add_eepos_${TIMESTAMP}.log"

echo "Logs will be saved to: $LOG_FILE"

python add_eepos.py --config "$CONFIG_FILE" --skip_existing 2>&1 | tee "$LOG_FILE"

EXIT_STATUS=${PIPESTATUS[0]}

# ============================================================================
# Summary
# ============================================================================
if [ $EXIT_STATUS -eq 0 ]; then
    echo ""
    echo "=========================================="
    echo "EEPOS ADDITION COMPLETED"
    echo "=========================================="

    # Count eepos files
    EEPOS_COUNT=$(find "$TARGET_ROOT" -path "*/eepos/*.pt" | wc -l)
    QPOS_COUNT=$(find "$TARGET_ROOT" -path "*/qpos/*.pt" | wc -l)

    echo "  QPos files: $QPOS_COUNT"
    echo "  EEPos files: $EEPOS_COUNT"
    echo "  Log file: $LOG_FILE"
    echo "=========================================="
else
    echo ""
    echo "=========================================="
    echo "EEPOS ADDITION FAILED"
    echo "=========================================="
    echo "Check log file for details: $LOG_FILE"
    echo "=========================================="
    exit $EXIT_STATUS
fi

echo "Script completed at $(date)"

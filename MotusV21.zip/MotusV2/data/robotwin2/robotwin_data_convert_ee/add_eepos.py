#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Add eepos (End-Effector Pose) to existing converted RobotWin dataset.

This script processes existing converted datasets that only have qpos data,
and adds the missing eepos data extracted from the original HDF5 files.

Usage:
    python add_eepos.py --config config.yml

Or with command line arguments:
    python add_eepos.py --source_root /path/to/RoboTwin2_0 \
                        --target_root /path/to/RoboTwin_emb \
                        --skip_existing
"""

import os
import sys
import argparse
import logging
from pathlib import Path
from typing import Optional, Dict, Tuple

import torch
import numpy as np
import h5py
from tqdm import tqdm
import yaml

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class EEPosAdder:
    """
    Add end-effector pose data to existing converted RobotWin datasets
    """

    # Demo type mapping (from original dataset to converted structure)
    DEMO_TYPE_MAPPING = {
        'aloha-agilex_clean_50': 'clean',
        'aloha-agilex_randomized_500': 'randomized',
        'arx-x5_clean_50': 'clean',
        'arx-x5_randomized_500': 'randomized',
        'franka_clean_50': 'clean',
        'franka_randomized_500': 'randomized',
        'ur5_clean_50': 'clean',
        'ur5_randomized_500': 'randomized',
    }

    def __init__(self, config_path: str):
        """Initialize with configuration file"""
        self.config = self._load_config(config_path)
        self._validate_config()

    def _load_config(self, config_path: str) -> dict:
        """Load configuration from YAML file"""
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)
            logger.info(f"Loaded configuration from: {config_path}")
            return config
        except Exception as e:
            logger.error(f"Failed to load config file {config_path}: {e}")
            raise

    def _validate_config(self):
        """Validate required configuration parameters"""
        if 'source_root' not in self.config:
            raise ValueError("source_root not in config")
        if 'target_root' not in self.config:
            raise ValueError("target_root not in config")

        if not os.path.exists(self.config['source_root']):
            raise FileNotFoundError(f"Source root not found: {self.config['source_root']}")

        if not os.path.exists(self.config['target_root']):
            raise FileNotFoundError(f"Target root not found: {self.config['target_root']}")

    def extract_eepos_from_hdf5(self, hdf5_path: str) -> Optional[torch.Tensor]:
        """
        Extract 16-dimensional end-effector poses from HDF5 file

        Data format (16-dim):
            - left_endpose: (T, 7) - position (x,y,z) + quaternion (qw,qx,qy,qz)
            - left_gripper: (T, 1) - left gripper state
            - right_endpose: (T, 7) - position (x,y,z) + quaternion (qw,qx,qy,qz)
            - right_gripper: (T, 1) - right gripper state

        Args:
            hdf5_path: Path to HDF5 file

        Returns:
            Tensor with shape (num_timesteps, 16) or None if failed
        """
        try:
            with h5py.File(hdf5_path, 'r') as hdf5_file:
                # Check if endpose group exists
                if 'endpose' not in hdf5_file:
                    logger.warning(f"No endpose group found in {hdf5_path}")
                    return None

                endpose_group = hdf5_file['endpose']

                # Extract each component
                left_endpose = endpose_group.get('left_endpose')
                left_gripper = endpose_group.get('left_gripper')
                right_endpose = endpose_group.get('right_endpose')
                right_gripper = endpose_group.get('right_gripper')

                if left_endpose is None or right_endpose is None:
                    logger.warning(f"Missing endpose data in {hdf5_path}")
                    return None

                left_endpose_data = left_endpose[()]
                right_endpose_data = right_endpose[()]

                # Get gripper data (default to zeros if not present)
                if left_gripper is not None:
                    left_gripper_data = left_gripper[()].reshape(-1, 1)
                else:
                    left_gripper_data = np.zeros((left_endpose_data.shape[0], 1))
                    logger.warning(f"No left_gripper in {hdf5_path}, using zeros")

                if right_gripper is not None:
                    right_gripper_data = right_gripper[()].reshape(-1, 1)
                else:
                    right_gripper_data = np.zeros((right_endpose_data.shape[0], 1))
                    logger.warning(f"No right_gripper in {hdf5_path}, using zeros")

                # Concatenate to 16-dim
                eepos_data = np.concatenate([
                    left_endpose_data,      # (T, 7)
                    left_gripper_data,      # (T, 1)
                    right_endpose_data,     # (T, 7)
                    right_gripper_data      # (T, 1)
                ], axis=1)

                eepos_tensor = torch.from_numpy(eepos_data).float()
                logger.debug(f"Extracted end-effector poses with shape: {eepos_tensor.shape}")

                return eepos_tensor

        except Exception as e:
            logger.error(f"Error extracting end-effector poses from {hdf5_path}: {e}")
            return None

    def find_hdf5_path(self, source_root: Path, task_name: str, demo_type: str, episode_id: int) -> Optional[Path]:
        """
        Find the original HDF5 file path for a given episode

        Args:
            source_root: Root path of the original dataset
            task_name: Task name (e.g., 'adjust_bottle')
            demo_type: Demo type ('clean' or 'randomized')
            episode_id: Episode ID

        Returns:
            Path to HDF5 file or None if not found
        """
        task_dir = source_root / task_name
        if not task_dir.exists():
            return None

        # Try different demo directory patterns
        for demo_dir_name, target_type in self.DEMO_TYPE_MAPPING.items():
            if target_type != demo_type:
                continue

            # Try nested structure: task/demo_type/demo_type/data/
            demo_path = task_dir / demo_dir_name / demo_dir_name / "data" / f"episode{episode_id}.hdf5"
            if demo_path.exists():
                return demo_path

            # Try direct structure: task/demo_type/data/
            demo_path = task_dir / demo_dir_name / "data" / f"episode{episode_id}.hdf5"
            if demo_path.exists():
                return demo_path

        return None

    def process_existing_dataset(self, skip_existing: bool = True):
        """
        Process existing converted dataset and add eepos data

        Args:
            skip_existing: Skip if eepos file already exists
        """
        source_root = Path(self.config['source_root'])
        target_root = Path(self.config['target_root'])

        # Statistics
        total_processed = 0
        total_success = 0
        total_skipped = 0
        total_failed = 0

        # Scan target directory for processed episodes
        for subset_dir in target_root.iterdir():
            if not subset_dir.is_dir():
                continue

            subset_name = subset_dir.name  # 'clean' or 'randomized'
            logger.info(f"Processing subset: {subset_name}")

            for task_dir in subset_dir.iterdir():
                if not task_dir.is_dir():
                    continue

                task_name = task_dir.name
                qpos_dir = task_dir / "qpos"
                eepos_dir = task_dir / "eepos"

                if not qpos_dir.exists():
                    logger.warning(f"No qpos directory for task {task_name}")
                    continue

                # Create eepos directory
                eepos_dir.mkdir(parents=True, exist_ok=True)

                # Process each qpos file
                qpos_files = sorted(qpos_dir.glob("*.pt"))

                for qpos_file in tqdm(qpos_files, desc=f"Processing {task_name}"):
                    episode_id = int(qpos_file.stem)
                    eepos_file = eepos_dir / f"{episode_id}.pt"

                    total_processed += 1

                    # Skip if eepos already exists
                    if skip_existing and eepos_file.exists():
                        total_skipped += 1
                        continue

                    # Find original HDF5 file
                    hdf5_path = self.find_hdf5_path(source_root, task_name, subset_name, episode_id)

                    if hdf5_path is None:
                        logger.warning(f"HDF5 file not found for {task_name}/{subset_name}/episode{episode_id}")
                        total_failed += 1
                        continue

                    # Extract eepos
                    eepos_data = self.extract_eepos_from_hdf5(str(hdf5_path))

                    if eepos_data is not None:
                        torch.save(eepos_data, eepos_file)
                        total_success += 1
                        logger.debug(f"Saved eepos to {eepos_file}")
                    else:
                        logger.warning(f"Failed to extract eepos for episode {episode_id}")
                        total_failed += 1

        # Print summary
        logger.info("=" * 50)
        logger.info("EEPos Addition Summary:")
        logger.info(f"  Total processed: {total_processed}")
        logger.info(f"  Successfully added: {total_success}")
        logger.info(f"  Skipped (existing): {total_skipped}")
        logger.info(f"  Failed: {total_failed}")
        logger.info("=" * 50)


def parse_args():
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(
        description="Add eepos data to existing converted RobotWin dataset"
    )
    parser.add_argument(
        "--config",
        type=str,
        default="config.yml",
        help="Path to configuration YAML file"
    )
    parser.add_argument(
        "--source_root",
        type=str,
        default=None,
        help="Override source root from config"
    )
    parser.add_argument(
        "--target_root",
        type=str,
        default=None,
        help="Override target root from config"
    )
    parser.add_argument(
        "--skip_existing",
        action="store_true",
        default=True,
        help="Skip episodes that already have eepos files"
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Enable verbose logging"
    )

    return parser.parse_args()


def main():
    """Main function"""
    args = parse_args()

    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    try:
        adder = EEPosAdder(args.config)

        # Override paths if provided
        if args.source_root:
            adder.config['source_root'] = args.source_root
        if args.target_root:
            adder.config['target_root'] = args.target_root

        adder.process_existing_dataset(skip_existing=args.skip_existing)

    except Exception as e:
        logger.error(f"Failed to add eepos: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Human Latent Action Encoder for MotusV2

Wraps the cross-human VAE from CEG_V2 to encode 450-dim padded_per_hand
human actions to 16-dim latent space, matching robot action dimensions.

Checkpoint: CEG_V2/checkpoints/cross_human_vae_20260429_231936
Architecture: encoder(450->256->256) -> mu_head(256->16), logvar_head(256->16)
              decoder(16->256->256->450)
"""

import logging
from pathlib import Path
from typing import Dict, Optional, Tuple

import torch
import torch.nn as nn

logger = logging.getLogger(__name__)


class HumanLatentActionEncoder(nn.Module):
    """
    VAE encoder that maps 450-dim padded_per_hand human actions to 16-dim latent space.

    This matches the cross_human_vae checkpoint trained on VITRA+WIYH+EgoDex
    with action_mode=padded_per_hand (450-dim).
    """

    def __init__(
        self,
        checkpoint_path: str,
        latent_dim: int = 16,
        hidden_dim: int = 256,
        action_dim: int = 450,
        freeze: bool = True,
        device: str = "cuda",
    ) -> None:
        super().__init__()
        self.latent_dim = latent_dim
        self.hidden_dim = hidden_dim
        self.action_dim = action_dim
        self.freeze = freeze
        self.device = device

        # Build VAE architecture (must match CEG_V2 checkpoint)
        self.encoder = nn.Sequential(
            nn.Linear(action_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.mu_head = nn.Linear(hidden_dim, latent_dim)
        self.logvar_head = nn.Linear(hidden_dim, latent_dim)

        # Decoder (for validation only, not used in training)
        # Checkpoint structure: 0:Linear, 1:GELU, 2:Linear, 3:GELU, 4:Linear
        self.decoder = nn.Sequential(
            nn.Linear(latent_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, action_dim),
        )

        # Load pretrained weights
        self._load_weights(checkpoint_path)

        # Freeze if requested
        if freeze:
            for param in self.parameters():
                param.requires_grad = False
            logger.info("[HumanLatentActionEncoder] Weights frozen")

        self.to(device)
        self.eval()
        logger.info(
            f"[HumanLatentActionEncoder] Initialized: "
            f"action_dim={action_dim} -> latent_dim={latent_dim}, "
            f"hidden_dim={hidden_dim}, device={device}"
        )

    def _load_weights(self, checkpoint_path: str) -> None:
        """Load weights from CEG_V2 checkpoint (direct key mapping)."""
        checkpoint_path = Path(checkpoint_path)
        if not checkpoint_path.exists():
            raise FileNotFoundError(f"Checkpoint not found: {checkpoint_path}")

        checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
        state_dict = checkpoint.get("model", checkpoint)

        # Direct mapping - checkpoint keys match our structure exactly
        expected_keys = [
            "encoder.0.weight", "encoder.0.bias",
            "encoder.2.weight", "encoder.2.bias",
            "mu_head.weight", "mu_head.bias",
            "logvar_head.weight", "logvar_head.bias",
            "decoder.0.weight", "decoder.0.bias",
            "decoder.2.weight", "decoder.2.bias",
            "decoder.4.weight", "decoder.4.bias",
        ]

        new_state_dict = {}
        for key in expected_keys:
            if key in state_dict:
                new_state_dict[key] = state_dict[key]
            else:
                logger.warning(f"Key not found in checkpoint: {key}")

        missing, unexpected = self.load_state_dict(new_state_dict, strict=False)
        if missing:
            logger.warning(f"Missing keys: {missing}")
        if unexpected:
            logger.warning(f"Unexpected keys: {unexpected}")

        # Log checkpoint info
        step = checkpoint.get("step", "unknown")
        logger.info(f"[HumanLatentActionEncoder] Loaded from step={step}")

    @torch.no_grad()
    def encode(self, action: torch.Tensor) -> torch.Tensor:
        """
        Encode 450-dim action to 16-dim latent space (deterministic, uses mu).

        Args:
            action: [..., 450] action tensor

        Returns:
            z: [..., 16] latent tensor
        """
        action = action.to(self.device, dtype=torch.float32)
        embed = self.encoder(action)
        mu = self.mu_head(embed)
        return mu

    @torch.no_grad()
    def encode_batch(self, action_sequence: torch.Tensor) -> torch.Tensor:
        """
        Encode a batch of action sequences.

        Args:
            action_sequence: [B, F, 450] or [F, 450]

        Returns:
            [B, F, 16] or [F, 16] latent tensor (on CPU for DataLoader compat)
        """
        original_shape = action_sequence.shape
        # Flatten to 2D for encoder
        flat = action_sequence.reshape(-1, self.action_dim)
        latent = self.encode(flat)
        # Reshape back and move to CPU
        latent = latent.reshape(*original_shape[:-1], self.latent_dim)
        return latent.cpu().float()


# ---- Singleton for sharing encoder across dataset instances ----
_GLOBAL_HUMAN_ENCODER: Optional[HumanLatentActionEncoder] = None
_ENCODER_CONFIG = None


def get_shared_human_encoder(
    checkpoint_path: str,
    latent_dim: int = 16,
    hidden_dim: int = 256,
    action_dim: int = 450,
    freeze: bool = True,
    device: str = "cuda",
) -> HumanLatentActionEncoder:
    """
    Get or create a singleton HumanLatentActionEncoder shared across
    all dataset instances to save GPU memory.
    """
    global _GLOBAL_HUMAN_ENCODER, _ENCODER_CONFIG

    config_key = (checkpoint_path, latent_dim, hidden_dim, action_dim, freeze, device)

    if _GLOBAL_HUMAN_ENCODER is None or _ENCODER_CONFIG != config_key:
        if _GLOBAL_HUMAN_ENCODER is not None:
            del _GLOBAL_HUMAN_ENCODER
            torch.cuda.empty_cache()
            logger.info("[HumanLatentActionEncoder] Released previous singleton")

        _GLOBAL_HUMAN_ENCODER = HumanLatentActionEncoder(
            checkpoint_path=checkpoint_path,
            latent_dim=latent_dim,
            hidden_dim=hidden_dim,
            action_dim=action_dim,
            freeze=freeze,
            device=device,
        )
        _ENCODER_CONFIG = config_key
        logger.info(f"[HumanLatentActionEncoder] Created shared singleton on {device}")

    return _GLOBAL_HUMAN_ENCODER

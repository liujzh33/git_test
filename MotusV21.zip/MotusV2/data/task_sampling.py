"""Task-level sampling utilities for multi-task datasets."""

from __future__ import annotations

from typing import Any, Dict, Iterable, List, Mapping, Optional


def _uniform_weights(task_names: List[str]) -> Dict[str, float]:
    if not task_names:
        raise ValueError("Cannot build task weights for an empty task list")
    probability = 1.0 / len(task_names)
    return {task_name: probability for task_name in task_names}


def resolve_task_sampling_weights(
    task_names: Iterable[str],
    task_sampling: Optional[Mapping[str, Any]] = None,
    *,
    is_validation: bool = False,
) -> Dict[str, float]:
    """Resolve additive mixture masses into normalized task probabilities.

    A mixture consists of a uniform component over all available tasks plus
    optional named components distributed uniformly across their task lists.
    Components may overlap; their masses are additive before normalization.
    """
    names = sorted(set(task_names))
    if not names:
        raise ValueError("Cannot build task weights for an empty task list")

    config = dict(task_sampling or {})
    if not config.get("enabled", False):
        return _uniform_weights(names)

    validation_mode = str(config.get("validation_mode", "uniform")).lower()
    if is_validation and validation_mode == "uniform":
        return _uniform_weights(names)
    if validation_mode not in {"uniform", "weighted"}:
        raise ValueError(
            "task_sampling.validation_mode must be 'uniform' or 'weighted', "
            f"got {validation_mode!r}"
        )

    strict = bool(config.get("strict", True))
    uniform_mass = float(config.get("uniform_mass", 1.0))
    if uniform_mass < 0:
        raise ValueError("task_sampling.uniform_mass must be non-negative")

    scores = {task_name: uniform_mass / len(names) for task_name in names}
    available = set(names)

    groups = config.get("groups", []) or []
    for index, raw_group in enumerate(groups):
        group = dict(raw_group)
        group_name = str(group.get("name", f"group_{index}"))
        mass = float(group.get("mass", 0.0))
        if mass < 0:
            raise ValueError(
                f"task_sampling group {group_name!r} has negative mass {mass}"
            )
        if mass == 0:
            continue

        requested_tasks = list(dict.fromkeys(group.get("tasks", []) or []))
        if not requested_tasks:
            raise ValueError(
                f"task_sampling group {group_name!r} has positive mass but no tasks"
            )

        unknown = sorted(set(requested_tasks) - available)
        if unknown and strict:
            raise ValueError(
                f"task_sampling group {group_name!r} contains unknown tasks: {unknown}"
            )

        matched = [task_name for task_name in requested_tasks if task_name in available]
        if not matched:
            if strict:
                raise ValueError(
                    f"task_sampling group {group_name!r} matches no available tasks"
                )
            continue

        per_task_mass = mass / len(matched)
        for task_name in matched:
            scores[task_name] += per_task_mass
    total = sum(scores.values())
    if total <= 0:
        raise ValueError(
            "Task sampling masses sum to zero; set uniform_mass or a group mass"
        )

    # Normalize even when configured masses do not sum to one. This makes
    # ablations easy while preserving the relative mixture.
    return {task_name: score / total for task_name, score in scores.items()}


def summarize_task_sampling(
    weights: Mapping[str, float],
    groups: Optional[Iterable[Mapping[str, Any]]] = None,
) -> Dict[str, Any]:
    """Return a compact summary suitable for logs and tests."""
    ordered = sorted(weights.items(), key=lambda item: (-item[1], item[0]))
    summary: Dict[str, Any] = {
        "num_tasks": len(ordered),
        "probability_sum": sum(weights.values()),
        "min_probability": ordered[-1][1] if ordered else 0.0,
        "max_probability": ordered[0][1] if ordered else 0.0,
        "top_tasks": ordered[:10],
    }

    if groups is not None:
        group_probabilities = {}
        for index, raw_group in enumerate(groups):
            group = dict(raw_group)
            group_name = str(group.get("name", f"group_{index}"))
            requested_tasks = set(group.get("tasks", []) or [])
            group_probabilities[group_name] = sum(
                probability
                for task_name, probability in weights.items()
                if task_name in requested_tasks
            )
        summary["group_probabilities"] = group_probabilities

    return summary

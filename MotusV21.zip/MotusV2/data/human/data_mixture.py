# Data Mixture Configurations for Multi-Dataset Training
# Similar to VITRA's HAND_MIXTURES
#
# Format: Dict[str, List[Tuple[str, float]]]
#   - Key: mixture name (used in config.dataset.dataset_name or config.dataset.data_mix)
#   - Value: List of (dataset_name, weight) tuples
#   - Weight: controls the sampling ratio relative to dataset size
#
# Example:
#   "ssv2_epic_mix": [("ssv2", 1.0), ("epic", 1.0)]
#   This means: sample from ssv2 and epic with equal weight (proportional to dataset size * weight)

from typing import Dict, List, Tuple

# VITRA human datasets mixture configurations
VITRA_MIXTURES: Dict[str, List[Tuple[str, float]]] = {
    # === Single Datasets ===
    "ssv2": [
        ("ssv2", 1.0),
    ],
    "epic": [
        ("epic", 1.0),
    ],
    "ego4d_cooking_and_cleaning": [
        ("ego4d_cooking_and_cleaning", 1.0),
    ],
    "egoexo4d": [
        ("egoexo4d", 1.0),
    ],
    "ego4d_other": [
        ("ego4d_other", 1.0),
    ],

    # === Mixed Datasets ===
    # ssv2 + epic (equal weight)
    "ssv2_epic": [
        ("ssv2", 1.0),
        ("epic", 1.0),
    ],

    # ssv2 + epic (ssv2 weighted 5x)
    "ssv2_epic_weighted": [
        ("ssv2", 5.0),
        ("epic", 1.0),
    ],

    # Full VITRA mixture: all 4 main datasets
    "vitra_full": [
        ("ssv2", 1.0),
        ("epic", 1.0),
        ("ego4d_cooking_and_cleaning", 1.0),
        ("egoexo4d", 1.0),
    ],

    # Full VITRA mixture with ssv2 weighted
    "vitra_full_ssv2_weighted": [
        ("ssv2", 5.0),
        ("epic", 1.0),
        ("ego4d_cooking_and_cleaning", 1.0),
        ("egoexo4d", 1.0),
    ],
}


def get_mixture_config(mixture_name: str) -> List[Tuple[str, float]]:
    """
    Get dataset mixture configuration by name.

    Args:
        mixture_name: Name of the mixture (e.g., "ssv2_epic", "vitra_full")

    Returns:
        List of (dataset_name, weight) tuples

    Raises:
        ValueError: If mixture name is not found
    """
    if mixture_name in VITRA_MIXTURES:
        return VITRA_MIXTURES[mixture_name]

    # Check if it's a single dataset name
    single_datasets = ["ssv2", "epic", "ego4d_cooking_and_cleaning", "egoexo4d", "ego4d_other"]
    if mixture_name in single_datasets:
        return [(mixture_name, 1.0)]

    raise ValueError(f"Unknown mixture name: {mixture_name}. "
                     f"Available: {list(VITRA_MIXTURES.keys())}")


def list_available_mixtures() -> List[str]:
    """List all available mixture names."""
    return list(VITRA_MIXTURES.keys())

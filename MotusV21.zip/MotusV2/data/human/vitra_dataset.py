# data/vitra/vitra_human_dataset.py
import os
import sys
import random
import hashlib
import logging
from pathlib import Path
from typing import Any, Dict, Optional, Tuple, List

import numpy as np
import torch
import torch.utils.data as data

from PIL import Image
from transformers import AutoProcessor

from data.utils.image_utils import resize_with_padding, tensor_to_pil
from utils.vlm_utils import preprocess_vlm_messages

logger = logging.getLogger(__name__)

# Import wrist feature extraction
from data.human.wrist_feature import (
    WristFeatureExtractor,
    WristGaussianNormalizer,
    load_wrist_statistics,
    pad_wrist_14_to_16,
    relative_wrist_14_to_initial,
)

# Import unified EEF action utilities
from data.human.unified_eef_action import (
    compute_unified_eef_action_sequence,
    compute_unified_eef_state_from_poses,
    quat_wxyz_to_rotmat,
    UNIFIED_EEF_ACTION_DIM,
    UNIFIED_EEF_STATE_DIM,
)

# Import per-hand padding utilities
from data.per_hand_dims import (
    VITRA_PER_HAND_ACTION_DIM, VITRA_PER_HAND_STATE_DIM,
    MAX_PER_HAND_ACTION_DIM, MAX_PER_HAND_STATE_DIM,
    PADDED_ACTION_DIM, PADDED_STATE_DIM,
    concat_per_hand,
)

# Import latent action encoder
from data.latent_action.human_latent_action_encoder import get_shared_human_encoder
from data.human.latent_normalizer import LatentNormalizer

# Ensure Motus bak/ is importable (for wan.modules.*)
BAK_ROOT = str((Path(__file__).resolve().parents[2] / "bak").resolve())
if BAK_ROOT not in sys.path:
    sys.path.insert(0, BAK_ROOT)

from data import get_global_t5_encoder  # cross-dataset shared singleton


def _get_shared_t5_encoder(wan_path: str, t5_text_len: int, t5_device: str):
    """Delegate to the global cross-dataset T5 singleton in data/__init__.py."""
    return get_global_t5_encoder(wan_path, t5_text_len, t5_device)


# ---- Local VITRA-compatible core ----
from data.human.vitra_core import VitraEpisodeCore as EpisodicDatasetCore  # noqa: E402
from data.human.vitra_core import load_video_decord  # noqa: E402


def _vitra_paths(dataset_dir: str, dataset_name: str) -> Dict[str, str]:
    """
    Mirror VITRA's FrameDataset path mapping (data placement stays identical). :contentReference[oaicite:4]{index=4}
    """
    root = Path(dataset_dir)
    if dataset_name == "ego4d_cooking_and_cleaning":
        return dict(
            annotation_file=str(root / "Annotation/ego4d_cooking_and_cleaning/episode_frame_index.npz"),
            label_folder=str(root / "Annotation/ego4d_cooking_and_cleaning/episodic_annotations"),
            statistics_path=str(root / "Annotation/statistics/ego4d_cooking_and_cleaning_angle_statistics.json"),
            video_root=str(root / "Video/Ego4D_root"),
        )
    if dataset_name == "egoexo4d":
        return dict(
            annotation_file=str(root / "Annotation/egoexo4d/episode_frame_index.npz"),
            label_folder=str(root / "Annotation/egoexo4d/episodic_annotations"),
            statistics_path=str(root / "Annotation/statistics/egoexo4d_angle_statistics.json"),
            video_root=str(root / "Video/EgoExo4D_root"),
        )
    if dataset_name == "epic":
        return dict(
            annotation_file=str(root / "Annotation/epic/episode_frame_index.npz"),
            label_folder=str(root / "Annotation/epic/episodic_annotations"),
            statistics_path=str(root / "Annotation/statistics/epic_angle_statistics.json"),
            video_root=str(root / "Video/Epic-Kitchen_root"),
        )
    if dataset_name == "ssv2":
        return dict(
            annotation_file=str(root / "Annotation/ssv2/episode_frame_index.npz"),
            label_folder=str(root / "Annotation/ssv2/episodic_annotations"),
            statistics_path=str(root / "Annotation/statistics/ssv2_angle_statistics.json"),
            video_root=str(root / "Video/Somethingsomething-v2_root"),
        )
    if dataset_name == "ego4d_other":
        # VITRA uses the same index/stats/video root as ego4d_cooking_and_cleaning :contentReference[oaicite:5]{index=5}
        return dict(
            annotation_file=str(root / "Annotation/ego4d_other/episode_frame_index.npz"),
            label_folder=str(root / "Annotation/ego4d_other/episodic_annotations"),
            statistics_path=str(root / "Annotation/statistics/ego4d_other_angle_statistics.json"),
            video_root=str(root / "Video/Ego4D_root"),
        )
    raise ValueError(f"Unknown VITRA dataset_name: {dataset_name}")


class VitraHumanMotusDataset(data.Dataset):
    """
    Wrap VITRA EpisodicDatasetCore to produce Motus training samples.
    Output dict matches Motus collate_fn + train_step expectations. :contentReference[oaicite:6]{index=6}
    """

    def __init__(
        self,
        dataset_dir: str,
        dataset_name: str,
        *,
        num_video_frames: int = 8,
        video_size: Tuple[int, int] = (384, 320),  # (H, W)
        # VITRA window params
        action_past_window_size: int = 0,
        image_past_window_size: int = 0,
        # We will request a window of (num_video_frames + 1) frames (t0..tF) from VITRA action logic
        clip_len: Optional[int] = None,
        normalization: bool = True,
        # Action mode: "default", "wrist", "padded_per_hand", or "latent"
        action_mode: str = "default",
        # Wrist mode (14-dim action/state) - legacy, equivalent to action_mode="wrist"
        wrist_mode: bool = False,
        wrist_statistics_path: Optional[str] = None,
        # Latent mode (CEG_V2 VAE encoding) - legacy, equivalent to action_mode="latent"
        latent_mode: bool = False,
        latent_checkpoint_path: Optional[str] = None,
        latent_dim: int = 16,  # Default matches CEG_V2 checkpoint
        latent_hidden_dim: int = 256,
        latent_device: str = "cuda",
        latent_normalization: bool = True,
        latent_statistics_path: Optional[str] = None,
        # FOV (Camera parameters) conditioning
        use_fov: bool = False,
        # VLM (Qwen3-VL) inputs
        vlm_checkpoint_path: Optional[str] = None,
        # T5 embedding for WAN cross-attn
        t5_mode: str = "disk_cache",  # "none" | "disk_cache"
        wan_path: str = "./pretrained_models",
        t5_cache_dir: str = "./t5_cache_vitra",
        t5_text_len: int = 512,
        t5_device: str = "cuda",
        # sampling behavior
        max_attempts: int = 8,
        **kwargs: Any,
    ) -> None:
        super().__init__()
        self.dataset_dir = str(dataset_dir)
        self.dataset_name = str(dataset_name)
        self.num_video_frames = int(num_video_frames)
        self.video_size = video_size
        self.action_past = int(action_past_window_size)
        self.image_past = int(image_past_window_size)
        self.clip_len = clip_len
        self.normalization = bool(normalization)
        self.max_attempts = int(max_attempts)

        # Unify action_mode from legacy wrist_mode/latent_mode flags
        if action_mode == "default":
            if wrist_mode:
                action_mode = "wrist"
            elif latent_mode:
                action_mode = "latent"
        self.action_mode = action_mode

        assert self.action_mode in ("default", "wrist", "wrist_padded16", "relative_wrist_padded16", "unified_eef_camera_delta_wrist16", "padded_per_hand", "latent"), \
            f"action_mode must be 'default', 'wrist', 'wrist_padded16', 'relative_wrist_padded16', 'unified_eef_camera_delta_wrist16', 'padded_per_hand', or 'latent', got '{self.action_mode}'"

        # Wrist mode configuration
        self.wrist_mode = self.action_mode in ("wrist", "wrist_padded16", "relative_wrist_padded16")
        self.wrist_padded16 = self.action_mode == "wrist_padded16"
        self.relative_wrist_padded16 = self.action_mode == "relative_wrist_padded16"
        self.unified_eef_mode = self.action_mode == "unified_eef_camera_delta_wrist16"
        self.wrist_statistics_path = wrist_statistics_path

        # FOV configuration
        self.use_fov = use_fov
        if self.use_fov:
            logger.info(f"[VITRA->Motus] FOV conditioning enabled")

        paths = _vitra_paths(self.dataset_dir, self.dataset_name)
        self.core = EpisodicDatasetCore(
            video_root=paths["video_root"],
            annotation_file=paths["annotation_file"],
            label_folder=paths["label_folder"],
            statistics_path=paths["statistics_path"],
            augmentation=False,          # keep deterministic; Motus has its own aug if needed
            flip_augmentation=False,
            set_none_ratio=0.0,
            action_type="angle",
            use_rel=False,
            clip_len=self.clip_len,
            action_past_window_size=self.action_past,
            action_future_window_size=self.num_video_frames,   # request t0..tF window (F=num_video_frames)
            image_past_window_size=self.image_past,
            image_future_window_size=0,  # we load frames ourselves (supports clip_len-part videos)
            load_images=False,
        )

        # Ensure GaussianNormalizer exists when normalization=True (VITRA transform_trajectory expects it). :contentReference[oaicite:7]{index=7}
        if self.normalization and hasattr(self.core, "data_statistics") and getattr(self.core, "data_statistics", None) is not None:
            self.core.set_global_data_statistics(self.core.data_statistics)

        # Wrist mode setup
        if self.wrist_mode:
            self.wrist_extractor = WristFeatureExtractor()
            if self.wrist_statistics_path is not None and os.path.exists(self.wrist_statistics_path):
                wrist_stats = load_wrist_statistics(self.wrist_statistics_path)
                self.wrist_normalizer = WristGaussianNormalizer(wrist_stats)
                logger.info(f"[VITRA->Motus] Loaded wrist normalizer from {self.wrist_statistics_path}")
            else:
                self.wrist_normalizer = None
                logger.warning(f"[VITRA->Motus] Wrist mode enabled but statistics not found at {self.wrist_statistics_path}. Normalization disabled for wrist.")
            wrist_dim = 16 if (self.wrist_padded16 or self.relative_wrist_padded16) else 14
            logger.info(f"[VITRA->Motus] Wrist mode enabled: action_dim={wrist_dim}, state_dim={wrist_dim}")

        # Latent mode setup (CEG_V2 VAE encoding)
        self.latent_mode = self.action_mode == "latent"
        self.latent_dim = latent_dim
        self.latent_encoder = None
        self.latent_normalization = latent_normalization
        self.latent_normalizer = None
        if self.latent_mode:
            if latent_checkpoint_path is None:
                raise ValueError("latent_mode=True requires latent_checkpoint_path")
            # Use shared singleton to save memory
            self.latent_encoder = get_shared_human_encoder(
                checkpoint_path=latent_checkpoint_path,
                latent_dim=latent_dim,
                hidden_dim=latent_hidden_dim,
                freeze=True,  # Always freeze during dataset encoding
                device=latent_device,
            )

            # NOTE: Latent normalization is disabled by default.
            # The VAE latent space is already well-conditioned (trained with KL loss
            # to approximate N(0, I)), so normalization is not needed and can cause
            # numerical instability if the computed statistics don't match the true
            # latent distribution scale.
            if latent_normalization and latent_statistics_path is not None:
                if os.path.exists(latent_statistics_path):
                    self.latent_normalizer = LatentNormalizer.from_json(
                        latent_statistics_path, mode="center"  # Only center, don't scale
                    )
                    logger.info(f"[VITRA->Motus] Loaded latent normalizer from {latent_statistics_path} (mode=center, only subtracts mean)")
                else:
                    logger.warning(f"[VITRA->Motus] Latent statistics not found at {latent_statistics_path}. Normalization disabled.")

            logger.info(f"[VITRA->Motus] Latent mode enabled: action_dim={latent_dim}, state_dim={latent_dim}, normalization={self.latent_normalizer is not None}")

        # VLM processor (Qwen3-VL)
        self.vlm_processor = None
        if vlm_checkpoint_path:
            self.vlm_processor = AutoProcessor.from_pretrained(vlm_checkpoint_path)
            logger.info(f"[VITRA->Motus] Loaded VLM processor from {vlm_checkpoint_path}")

        # T5 embedding setup (WAN UMT5)
        self.t5_mode = t5_mode
        self.wan_path = str(wan_path)
        self.t5_cache_dir = Path(t5_cache_dir)
        self.t5_cache_dir.mkdir(parents=True, exist_ok=True)

        self.t5_encoder = None
        self.t5_device = t5_device
        if self.t5_mode == "disk_cache":
            # Use shared singleton T5 encoder to save memory when using multiple datasets
            # (UMT5-XXL is ~10GB per instance)
            self.t5_encoder = _get_shared_t5_encoder(
                wan_path=self.wan_path,
                t5_text_len=t5_text_len,
                t5_device=t5_device,
            )
            logger.info(f"[VITRA->Motus] T5EncoderModel ready (cache={self.t5_cache_dir})")
        elif self.t5_mode == "none":
            logger.warning("[VITRA->Motus] t5_mode=none: language_embedding will be zeros (no WAN text conditioning)")
        else:
            raise ValueError("t5_mode must be 'disk_cache' or 'none'")

    def __len__(self) -> int:
        return len(self.core)

    @staticmethod
    def _hash_text(text: str) -> str:
        return hashlib.sha1(text.encode("utf-8")).hexdigest()

    def _get_t5_embedding(self, instruction: str) -> torch.Tensor:
        """
        Return Tensor [seq_len, 4096] (UMT5 encoder output) like Motus datasets expect. :contentReference[oaicite:8]{index=8}
        """
        if self.t5_mode == "none":
            return torch.zeros((512, 4096), dtype=torch.float32)

        key = self._hash_text(instruction)
        path = self.t5_cache_dir / f"{key}.pt"
        if path.exists():
            emb = torch.load(path, map_location="cpu")
            return emb.float()

        # cache miss -> encode then atomically write
        assert self.t5_encoder is not None
        out = self.t5_encoder([instruction], self.t5_device)
        if isinstance(out, list):
            emb = out[0]
        elif isinstance(out, torch.Tensor):
            emb = out.squeeze(0)
        else:
            raise TypeError(f"Unexpected T5 encoder output: {type(out)}")
        emb = emb.detach().to("cpu").float()

        tmp = self.t5_cache_dir / f".tmp_{key}_{os.getpid()}.pt"
        torch.save(emb, tmp)
        os.replace(tmp, path)
        return emb

    def _load_video_window(self, episode_id: str, frame_id: int) -> torch.Tensor:
        """
        Load frames [t0..tF] using VITRA's episode metadata + path logic.
        Returns: Tensor [F+1, C, H, W] in [0,1], resized with padding to self.video_size.
        """
        epi, _, _ = self.core._load_or_cache_episode(episode_id)
        T = len(epi["extrinsics"])

        idx_win, _ = self.core._window_indices(frame_id, 0, self.num_video_frames, 0, T - 1)  # len = F+1 :contentReference[oaicite:9]{index=9}
        decode_table = epi["video_decode_frame"]
        decode_ids_full = decode_table[idx_win].tolist()

        dataset_prefix = episode_id.split("_")[0]
        video_name = epi["video_name"]

        # group by part index (because VITRA stores *_partK.mp4 when clip_len is set)
        part_to_local: Dict[int, List[Tuple[int, int]]] = {}  # part_idx -> [(pos_in_window, frame_in_part)]
        for pos, full_idx in enumerate(decode_ids_full):
            if self.clip_len is None:
                part_idx = 0
                frame_in_part = int(full_idx)
            else:
                part_idx = int(full_idx) // int(self.clip_len)
                frame_in_part = int(full_idx) % int(self.clip_len)
            part_to_local.setdefault(part_idx, []).append((pos, frame_in_part))

        # decode frames per part
        images: List[Optional[np.ndarray]] = [None] * len(decode_ids_full)
        for part_idx, pairs in part_to_local.items():
            video_path = self.core._resolve_video_path(dataset_prefix, video_name, part_idx)
            frame_list = [p[1] for p in pairs]
            # retry decode a few times (VITRA code uses retries too)
            for attempt in range(3):
                try:
                    imgs, _ = load_video_decord(video_path, frame_index=frame_list, rotation=False)
                    break
                except Exception as e:
                    if attempt == 2:
                        raise
            for (pos, _), img in zip(pairs, imgs):
                images[pos] = img

        assert all(im is not None for im in images)
        # resize-with-padding -> tensor
        resized = [resize_with_padding(im, self.video_size) for im in images]  # (H,W,3) uint8
        arr = np.stack(resized, axis=0)
        ten = torch.from_numpy(arr).permute(0, 3, 1, 2).float() / 255.0
        return ten  # [F+1,C,H,W]

    def _get_wrist_sample(
        self,
        episode_id: str,
        frame_id: int,
    ) -> Dict[str, Any]:
        """Get a sample with 14-dimensional wrist action/state.

        This method extracts wrist features (xyz + quaternion) directly from
        VITRA's camera-space rotation and translation, bypassing the full
        192/212-dimensional representation.

        Args:
            episode_id: Episode identifier
            frame_id: Frame index within episode

        Returns:
            Sample dict with action_sequence (14-dim) and initial_state (14-dim)
        """
        # Extract wrist features using the extractor
        action, action_mask, state, state_mask, instruction = self.wrist_extractor.extract_from_vitra_core(
            self.core, episode_id, frame_id,
            action_past_window_size=self.action_past,
            action_future_window_size=self.num_video_frames,
        )

        # Normalize absolute wrist only. Relative actions require separate stats.
        if self.normalization and self.wrist_normalizer is not None and not self.relative_wrist_padded16:
            action = self.wrist_normalizer.normalize_action(action)
            state = self.wrist_normalizer.normalize_state(state)

        # Load frames window [t0..tF]
        frames = self._load_video_window(episode_id, frame_id)  # [F+1,C,H,W]
        first_frame = frames[0]
        video_frames = frames[1:]  # [F,C,H,W]

        # Align action_sequence length to F (t0->t1 ... t(F-1)->tF)
        if self.relative_wrist_padded16:
            action = relative_wrist_14_to_initial(action, state)
            state = pad_wrist_14_to_16(state)
            action = pad_wrist_14_to_16(action)
        elif self.wrist_padded16:
            action = pad_wrist_14_to_16(action)
            state = pad_wrist_14_to_16(state)
        action_sequence = torch.tensor(action[:self.num_video_frames], dtype=torch.float32)
        current_state = torch.tensor(state, dtype=torch.float32)

        # WAN language embedding (UMT5)
        language_embedding = self._get_t5_embedding(instruction)  # [seq,4096]

        # VLM inputs (Qwen3-VL)
        vlm_inputs = None
        if self.vlm_processor is not None:
            first_frame_pil = tensor_to_pil(first_frame)
            vlm_inputs = preprocess_vlm_messages(instruction, first_frame_pil, self.vlm_processor)

        return {
            "first_frame": first_frame,                 # [C,H,W]
            "video_frames": video_frames,               # [F,C,H,W]
            "initial_state": current_state,             # [14]
            "action_sequence": action_sequence,         # [F, 14]
            "language_embedding": language_embedding,   # [L,4096]
            "vlm_inputs": vlm_inputs,                   # dict or None
        }

    def _compute_unified_eef_action_state(
        self,
        episode_id: str,
        frame_id: int,
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray, str, Dict[str, Any]]:
        """Compute unified-eef action/state WITHOUT loading video.

        Factored out of ``_get_unified_eef_sample`` so that offline debug tools
        (tools/visualize_vitra_unified_eef.py) can obtain the *exact* training
        action/state plus the intermediate geometry (reference camera pose,
        per-window world hand poses, validity) needed for re-projection, without
        changing the training behaviour.

        Returns:
            actions:      (F, 16)
            state:        (16,)
            action_masks: (F, 16)
            instruction:  str
            meta:         dict with reference camera pose + window arrays
        """
        epi, R_w2c, t_w2c = self.core._load_or_cache_episode(episode_id)
        T = len(epi["extrinsics"])

        idx_win, oob = self.core._window_indices(frame_id, self.action_past, self.num_video_frames, 0, T - 1)

        # Get instruction text (with hand-specific temporal windows)
        main_type = epi["anno_type"]
        instruction, idx_win_left, oob_left, idx_win_right, oob_right, \
            start_left, end_left, start_right, end_right = self.core._build_instruction(
                main_type=main_type,
                text_clip=epi["text"],
                text_rephrase=epi.get("text_rephrase"),
                idx_win=idx_win,
                oob=oob,
                epi_len=T,
                frame_id=frame_id,
                action_past_window_size=self.action_past,
                action_future_window_size=self.num_video_frames,
            )

        # Extract world-frame wrist poses
        # VITRA stores: global_orient_worldspace (3x3 rot in world), transl_worldspace (3, position in world)
        left_R_w = epi["left"]["global_orient_worldspace"]    # (T, 3, 3)
        left_t_w = epi["left"]["transl_worldspace"]           # (T, 3)
        right_R_w = epi["right"]["global_orient_worldspace"]
        right_t_w = epi["right"]["transl_worldspace"]
        left_kept = epi["left"]["kept_frames"].astype(bool)   # (T,)
        right_kept = epi["right"]["kept_frames"].astype(bool)

        # Reference camera pose in world frame.
        # VITRA extrinsics: p_cam = R_w2c @ p_world + t_w2c  =>  R_w_c = R_w2c^T,  t_w_c = -R_w2c^T @ t_w2c
        R_w_c = R_w2c[frame_id].T                              # (3, 3) camera rotation in world
        t_w_c = -R_w2c[frame_id].T @ t_w2c[frame_id]           # (3,) camera position in world

        # Build hand-specific windows using idx_win_left / idx_win_right.
        # These are pre-clipped by _window_indices, so the window length is always
        # action_past + num_video_frames + 1.  Out-of-bounds indices repeat the
        # nearest valid frame; we mark those as invalid via oob_left / oob_right.
        left_R_win = left_R_w[idx_win_left]       # (W, 3, 3)
        left_t_win = left_t_w[idx_win_left]       # (W, 3)
        right_R_win = right_R_w[idx_win_right]    # (W, 3, 3)
        right_t_win = right_t_w[idx_win_right]    # (W, 3)
        left_valid_win = left_kept[idx_win_left] & ~oob_left    # (W,)
        right_valid_win = right_kept[idx_win_right] & ~oob_right  # (W,)

        # For actions, we compute deltas between consecutive frames starting at action_past offset
        # Frame action_past is the "current" frame (frame_id)
        ap = self.action_past  # usually 0
        left_R_action = left_R_win[ap:ap + self.num_video_frames + 1]  # (F+1, 3, 3)
        left_t_action = left_t_win[ap:ap + self.num_video_frames + 1]
        right_R_action = right_R_win[ap:ap + self.num_video_frames + 1]
        right_t_action = right_t_win[ap:ap + self.num_video_frames + 1]
        left_valid_action = left_valid_win[ap:ap + self.num_video_frames + 1]
        right_valid_action = right_valid_win[ap:ap + self.num_video_frames + 1]

        # Compute unified EEF action sequence
        actions, action_masks = compute_unified_eef_action_sequence(
            R_w_e_left=left_R_action,
            t_w_e_left=left_t_action,
            R_w_e_right=right_R_action,
            t_w_e_right=right_t_action,
            R_w_c=R_w_c,
            left_valid=left_valid_action,
            right_valid=right_valid_action,
            num_action_frames=self.num_video_frames,
        )

        # Compute state at current frame (index ap in the window = frame_id)
        state, state_mask = compute_unified_eef_state_from_poses(
            R_w_e_left=left_R_action[0],
            t_w_e_left=left_t_action[0],
            R_w_e_right=right_R_action[0],
            t_w_e_right=right_t_action[0],
            R_w_c=R_w_c,
            t_w_c=t_w_c,
            left_valid=bool(left_valid_action[0]),
            right_valid=bool(right_valid_action[0]),
        )

        meta = {
            "R_w_c_ref": np.asarray(R_w_c, dtype=np.float64),   # cam->world at anchor
            "t_w_c_ref": np.asarray(t_w_c, dtype=np.float64),
            "left_t_action": np.asarray(left_t_action, dtype=np.float64),   # (F+1,3) world wrist
            "right_t_action": np.asarray(right_t_action, dtype=np.float64),
            "left_valid_action": np.asarray(left_valid_action, dtype=bool),
            "right_valid_action": np.asarray(right_valid_action, dtype=bool),
            "idx_win": np.asarray(idx_win, dtype=np.int64),
            "idx_win_left": np.asarray(idx_win_left, dtype=np.int64),
            "idx_win_right": np.asarray(idx_win_right, dtype=np.int64),
        }
        return actions, state, action_masks, instruction, meta

    def get_debug_sample(self, data_id: int, load_video: bool = False) -> Dict[str, Any]:
        """Deterministic debug extraction with re-projection metadata (offline only).

        NOT used by training.  ``data_id`` indexes ``core.index_frame_pair``.
        Returns the exact training ``action``/``state`` (via
        ``_compute_unified_eef_action_state``) plus the per-frame World2Cam
        extrinsics, intrinsics, and world-space wrist positions needed to
        re-project onto the video.

        Coordinate frames (VITRA):
          - extrinsics[t] : World2Cam SE(3) (p_cam = R_w2c @ p_world + t_w2c), +Z forward.
          - transl/global_orient_worldspace : world-frame wrist pose.
          - intrinsics : (3,3) pinhole K for the canonical (2*cx x 2*cy) resolution.
        """
        corr = self.core.index_frame_pair[data_id]
        episode_id = self.core.index_to_episode_id[corr[0]]
        frame_id = int(corr[1])

        epi, R_w2c, t_w2c = self.core._load_or_cache_episode(episode_id)
        T = len(epi["extrinsics"])
        F = self.num_video_frames
        idx_win, oob = self.core._window_indices(frame_id, 0, F, 0, T - 1)  # video window (F+1)

        actions = state = action_masks = None
        error = None
        meta = {}
        try:
            actions, state, action_masks, instruction, meta = \
                self._compute_unified_eef_action_state(episode_id, frame_id)
        except Exception as e:
            error = f"{type(e).__name__}: {e}"
            instruction = ""

        K = np.asarray(epi["intrinsics"], dtype=np.float64)
        # world-frame wrist positions over the *video* window (frame-aligned to frames)
        left_t_w = np.asarray(epi["left"]["transl_worldspace"], dtype=np.float64)[idx_win]
        right_t_w = np.asarray(epi["right"]["transl_worldspace"], dtype=np.float64)[idx_win]
        left_kept = epi["left"]["kept_frames"].astype(bool)[idx_win] & ~oob
        right_kept = epi["right"]["kept_frames"].astype(bool)[idx_win] & ~oob

        result: Dict[str, Any] = {
            "data_id": int(data_id),
            "episode_id": episode_id,
            "frame_id": frame_id,
            "num_video_frames": int(F),
            "window_indices": np.asarray(idx_win, dtype=np.int64),
            "decode_ids": np.asarray(epi["video_decode_frame"], dtype=np.int64)[idx_win],
            "video_name": epi["video_name"],
            "dataset_prefix": episode_id.split("_")[0],
            "clip_len": self.clip_len,
            "video_root": self.core.video_root,
            "K": K,
            "R_w2c_win": np.asarray(R_w2c, dtype=np.float64)[idx_win],   # (W,3,3) world->cam
            "t_w2c_win": np.asarray(t_w2c, dtype=np.float64)[idx_win],   # (W,3)
            "R_w_c_ref": meta.get("R_w_c_ref"),
            "t_w_c_ref": meta.get("t_w_c_ref"),
            "left_wrist_world_win": left_t_w,     # (W,3)
            "right_wrist_world_win": right_t_w,
            "left_valid_win": left_kept,
            "right_valid_win": right_kept,
            "action": None if actions is None else np.asarray(actions, dtype=np.float64),
            "state": None if state is None else np.asarray(state, dtype=np.float64),
            "action_valid_mask": None if action_masks is None else np.asarray(action_masks, dtype=bool),
            "error": error,
            "instruction": instruction,
            "anno_type": epi.get("anno_type", ""),
        }
        if load_video:
            result["frames"] = self._load_video_window(episode_id, frame_id)
        return result

    def _get_unified_eef_sample(
        self,
        episode_id: str,
        frame_id: int,
    ) -> Dict[str, Any]:
        """Get a sample with unified EEF camera-delta wrist16 action/state.

        VITRA provides wrist poses in world space directly from episode data.
        To compute camera-frame delta, we need world-frame wrist and camera poses.

        VITRA's episode data provides:
          - extrinsics: [T, 4, 4] world-to-camera transforms
            R_w2c = extr[t, :3, :3], t_w2c = extr[t, :3, 3]
          - side_dict['global_orient_worldspace']: [T, 3, 3] wrist rotation in world
          - side_dict['transl_worldspace']: [T, 3] wrist position in world
          - side_dict['kept_frames']: [T] bool validity

        The reference camera is the camera at frame_id (anchor frame).

        Returns:
            Sample dict with action_sequence (16-dim) and initial_state (16-dim)
        """
        actions, state, action_masks, instruction, _meta = \
            self._compute_unified_eef_action_state(episode_id, frame_id)

        # Load frames window [t0..tF]
        frames = self._load_video_window(episode_id, frame_id)
        first_frame = frames[0]
        video_frames = frames[1:]

        action_sequence = torch.tensor(actions, dtype=torch.float32)
        current_state = torch.tensor(state, dtype=torch.float32)
        action_valid_mask = torch.tensor(action_masks, dtype=torch.bool)

        # WAN language embedding (UMT5)
        language_embedding = self._get_t5_embedding(instruction)

        # VLM inputs (Qwen3-VL)
        vlm_inputs = None
        if self.vlm_processor is not None:
            first_frame_pil = tensor_to_pil(first_frame)
            vlm_inputs = preprocess_vlm_messages(instruction, first_frame_pil, self.vlm_processor)

        return {
            "first_frame": first_frame,
            "video_frames": video_frames,
            "initial_state": current_state,
            "action_sequence": action_sequence,
            "language_embedding": language_embedding,
            "vlm_inputs": vlm_inputs,
            "action_valid_mask": action_valid_mask,
        }

    def _get_latent_sample(
        self,
        episode_id: str,
        frame_id: int,
    ) -> Dict[str, Any]:
        """Get a sample with latent-encoded action/state.

        This method extracts 192-dim action and 212-dim state, then:
        - Action: directly encode to latent space via CEG_V2 encoder
        - State: remove betas (last 20 dims) to get 192-dim, then encode

        Args:
            episode_id: Episode identifier
            frame_id: Frame index within episode

        Returns:
            Sample dict with action_sequence (latent_dim) and initial_state (latent_dim)
        """
        # Get raw sample from VITRA core
        sample = self.core.get_item_frame(
            episode_id,
            frame_id,
            action_past_window_size=self.action_past,
            action_future_window_size=self.num_video_frames,
            image_past_window_size=0,
            image_future_window_size=0,
            rel_mode=self.core.rel_mode,
            load_images=False,
        )

        if self.normalization:
            sample = self.core.transform_trajectory(sample, normalization=True)

        instruction = sample["instruction"]
        action_list = sample["action_list"]          # [F+1, 192]
        current_state = sample["current_state"]      # [212]

        # Load frames window [t0..tF]
        frames = self._load_video_window(episode_id, frame_id)  # [F+1,C,H,W]
        first_frame = frames[0]
        video_frames = frames[1:]  # [F,C,H,W]

        # Convert to tensor
        if isinstance(action_list, np.ndarray):
            action_list = torch.tensor(action_list, dtype=torch.float32)
        if isinstance(current_state, np.ndarray):
            current_state = torch.tensor(current_state, dtype=torch.float32)

        # MotusV2 latent encoder is trained on padded_per_hand 450-dim actions.
        action_frames = action_list[:self.num_video_frames]
        action_padded = []
        for f in range(action_frames.shape[0]):
            left_action = action_frames[f, :VITRA_PER_HAND_ACTION_DIM]
            right_action = action_frames[f, 51:51 + VITRA_PER_HAND_ACTION_DIM]
            action_padded.append(concat_per_hand(left_action, right_action, MAX_PER_HAND_ACTION_DIM))
        action_sequence = torch.tensor(np.stack(action_padded), dtype=torch.float32)

        F = action_sequence.shape[0]
        action_flat = action_sequence.reshape(-1, PADDED_ACTION_DIM)
        with torch.no_grad():
            action_latent = self.latent_encoder.encode(action_flat)  # [F, latent_dim]
        # Move back to CPU for DataLoader pin_memory compatibility
        action_sequence = action_latent.cpu().reshape(F, self.latent_dim)  # [F, latent_dim]

        # Encode state through the same 450-dim padded-per-hand representation.
        left_state = current_state[:VITRA_PER_HAND_STATE_DIM]
        right_state = current_state[61:61 + VITRA_PER_HAND_STATE_DIM]
        state_450 = torch.tensor(
            concat_per_hand(left_state.numpy(), right_state.numpy(), MAX_PER_HAND_STATE_DIM),
            dtype=torch.float32,
        )
        with torch.no_grad():
            state_latent = self.latent_encoder.encode(state_450.unsqueeze(0))  # [1, latent_dim]
        # Move back to CPU for DataLoader pin_memory compatibility
        current_state = state_latent.cpu().squeeze(0)  # [latent_dim]

        # Apply latent normalization if available
        if self.latent_normalizer is not None:
            action_sequence = self.latent_normalizer.normalize_action(action_sequence)
            current_state = self.latent_normalizer.normalize_state(current_state)

        # WAN language embedding (UMT5)
        language_embedding = self._get_t5_embedding(instruction)  # [seq,4096]

        # VLM inputs (Qwen3-VL)
        vlm_inputs = None
        if self.vlm_processor is not None:
            first_frame_pil = tensor_to_pil(first_frame)
            vlm_inputs = preprocess_vlm_messages(instruction, first_frame_pil, self.vlm_processor)

        return {
            "first_frame": first_frame,                 # [C,H,W]
            "video_frames": video_frames,               # [F,C,H,W]
            "initial_state": current_state,             # [latent_dim]
            "action_sequence": action_sequence,         # [F, latent_dim]
            "language_embedding": language_embedding,   # [L,4096]
            "vlm_inputs": vlm_inputs,                   # dict or None
        }

    def _get_padded_per_hand_sample(
        self,
        episode_id: str,
        frame_id: int,
    ) -> Dict[str, Any]:
        """Get a sample with padded_per_hand action/state.

        Extracts per-hand features from VITRA's default 192/212 representation:
        - Action per hand: 51 dims (16 MANO joints x 3 axis-angle + 3 root rotation)
        - State per hand:  61 dims (51 pose + 10 shape betas)

        Pads each hand to MAX_PER_HAND_DIM (225) and concatenates to 450 total.

        Layout: [left_per_hand(max126), right_per_hand(max126)]

        Args:
            episode_id: Episode identifier
            frame_id: Frame index within episode

        Returns:
            Sample dict with action_sequence (450-dim) and initial_state (450-dim)
        """
        # Get raw sample from VITRA core (192-dim action, 212-dim state)
        sample = self.core.get_item_frame(
            episode_id,
            frame_id,
            action_past_window_size=self.action_past,
            action_future_window_size=self.num_video_frames,
            image_past_window_size=0,
            image_future_window_size=0,
            rel_mode=self.core.rel_mode,
            load_images=False,
        )

        if self.normalization:
            sample = self.core.transform_trajectory(sample, normalization=True)

        instruction = sample["instruction"]
        action_list = sample["action_list"]          # [F+1, 192]
        current_state = sample["current_state"]      # [212]

        # Load frames window [t0..tF]
        frames = self._load_video_window(episode_id, frame_id)  # [F+1,C,H,W]
        first_frame = frames[0]
        video_frames = frames[1:]  # [F,C,H,W]

        # Convert to numpy if needed
        if isinstance(action_list, torch.Tensor):
            action_list = action_list.numpy()
        if isinstance(current_state, torch.Tensor):
            current_state = current_state.numpy()

        # ---- Action: [F+1, 192] -> [F, 450] ----
        # Action layout in VITRA: left(51) + right(51) + padding(90) = 192
        action_frames = action_list[:self.num_video_frames]  # [F, 192]
        actions_padded = []
        for f in range(action_frames.shape[0]):
            left_action = action_frames[f, :VITRA_PER_HAND_ACTION_DIM]   # [51]
            right_action = action_frames[f, 51:51 + VITRA_PER_HAND_ACTION_DIM]  # [51]
            padded = concat_per_hand(left_action, right_action, MAX_PER_HAND_ACTION_DIM)  # [450]
            actions_padded.append(padded)
        action_sequence = torch.tensor(np.stack(actions_padded), dtype=torch.float32)  # [F, 450]

        # ---- State: [212] -> [450] ----
        # State layout in VITRA: left_pose(51) + left_beta(10) + right_pose(51) + right_beta(10) + padding(90) = 212
        left_state = current_state[:VITRA_PER_HAND_STATE_DIM]              # [61] (pose + betas)
        right_state = current_state[61:61 + VITRA_PER_HAND_STATE_DIM]      # [61]
        state_padded = concat_per_hand(left_state, right_state, MAX_PER_HAND_STATE_DIM)  # [450]
        current_state_tensor = torch.tensor(state_padded, dtype=torch.float32)

        # WAN language embedding (UMT5)
        language_embedding = self._get_t5_embedding(instruction)  # [seq,4096]

        # VLM inputs (Qwen3-VL)
        vlm_inputs = None
        if self.vlm_processor is not None:
            first_frame_pil = tensor_to_pil(first_frame)
            vlm_inputs = preprocess_vlm_messages(instruction, first_frame_pil, self.vlm_processor)

        return {
            "first_frame": first_frame,                 # [C,H,W]
            "video_frames": video_frames,               # [F,C,H,W]
            "initial_state": current_state_tensor,      # [450]
            "action_sequence": action_sequence,         # [F, 450]
            "language_embedding": language_embedding,   # [L,4096]
            "vlm_inputs": vlm_inputs,                   # dict or None
        }

    def __getitem__(self, idx: int) -> Optional[Dict[str, Any]]:
        # robust retry sampling (DDP-friendly) like other datasets :contentReference[oaicite:10]{index=10}
        for _ in range(self.max_attempts):
            try:
                # Randomize underlying frame index (ignore incoming idx)
                data_id = random.randint(0, len(self.core) - 1)
                corr = self.core.index_frame_pair[data_id]
                episode_id = self.core.index_to_episode_id[corr[0]]
                frame_id = int(corr[1])

                # Dispatch based on action_mode
                if self.action_mode in ("wrist", "wrist_padded16", "relative_wrist_padded16"):
                    return self._get_wrist_sample(episode_id, frame_id)
                elif self.action_mode == "unified_eef_camera_delta_wrist16":
                    return self._get_unified_eef_sample(episode_id, frame_id)
                elif self.action_mode == "padded_per_hand":
                    return self._get_padded_per_hand_sample(episode_id, frame_id)
                elif self.action_mode == "latent":
                    return self._get_latent_sample(episode_id, frame_id)

                # Default mode: 192/212-dim action/state
                sample = self.core.get_item_frame(
                    episode_id,
                    frame_id,
                    action_past_window_size=self.action_past,
                    action_future_window_size=self.num_video_frames,  # window t0..tF
                    image_past_window_size=0,
                    image_future_window_size=0,
                    rel_mode=self.core.rel_mode,
                    load_images=False,
                )  # returns instruction/action/state etc :contentReference[oaicite:11]{index=11}

                if self.normalization:
                    sample = self.core.transform_trajectory(sample, normalization=True)  # pads to action=192, state=212 :contentReference[oaicite:12]{index=12}

                instruction = sample["instruction"]
                action_list = sample["action_list"]              # [F+1, action_dim]
                current_state = sample["current_state"]          # [state_dim]

                # Load frames window [t0..tF]
                frames = self._load_video_window(episode_id, frame_id)  # [F+1,C,H,W]
                first_frame = frames[0]
                video_frames = frames[1:]  # [F,C,H,W]

                # Align action_sequence length to F (t0->t1 ... t(F-1)->tF)
                if isinstance(action_list, np.ndarray):
                    action_list = torch.tensor(action_list, dtype=torch.float32)
                action_sequence = action_list[: self.num_video_frames]  # [F, D]

                # State (Motus uses it when present) :contentReference[oaicite:13]{index=13}
                if isinstance(current_state, np.ndarray):
                    current_state = torch.tensor(current_state, dtype=torch.float32)

                # WAN language embedding (UMT5)
                language_embedding = self._get_t5_embedding(instruction)  # [seq,4096]

                # VLM inputs (Qwen3-VL)
                vlm_inputs = None
                if self.vlm_processor is not None:
                    first_frame_pil = tensor_to_pil(first_frame)
                    vlm_inputs = preprocess_vlm_messages(instruction, first_frame_pil, self.vlm_processor)

                # Extract FOV from VITRA sample if enabled
                fov = None
                if self.use_fov and "fov" in sample:
                    fov_data = sample["fov"]
                    if isinstance(fov_data, np.ndarray):
                        fov = torch.tensor(fov_data, dtype=torch.float32)  # [2] (hfov, vfov)
                    elif isinstance(fov_data, torch.Tensor):
                        fov = fov_data.float()

                result = {
                    "first_frame": first_frame,                 # [C,H,W]
                    "video_frames": video_frames,               # [F,C,H,W]
                    "initial_state": current_state,             # [state_dim]
                    "action_sequence": action_sequence,          # [F, action_dim]
                    "language_embedding": language_embedding,    # [L,4096]
                    "vlm_inputs": vlm_inputs,                    # dict or None
                }

                # Add FOV if enabled and available
                if fov is not None:
                    result["fov"] = fov  # [2]

                return result
            except Exception as e:
                logger.debug(f"[VITRA->Motus] sample retry due to error: {e}", exc_info=True)
                logger.warning(f"[VITRA->Motus] sample retry due to error: {e}")
                continue

        return None

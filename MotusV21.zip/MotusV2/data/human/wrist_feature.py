"""
wrist_feature.py

14-dimensional Wrist Mode feature extraction for VITRA/Motus.

Action/State representation:
- 14 dims = left hand (xyz + quaternion) + right hand (xyz + quaternion)
- Quaternion in WXYZ order (w, x, y, z)
- Absolute pose representation (independent per frame)
"""

from typing import Dict, Tuple, Optional
import numpy as np
from scipy.spatial.transform import Rotation as R
import json
import os


class WristActionFeature:
    """Feature indices for 14-dimensional wrist action/state.

    Layout: [left_xyz(3), left_quat(4), right_xyz(3), right_quat(4)] = 14 dims
    Quaternion order: WXYZ (w, x, y, z) - scalar first
    """
    ALL_FEATURES = (0, 14)

    LEFT_XYZ = (0, 3)       # Left hand translation
    LEFT_QUAT = (3, 7)      # Left hand quaternion WXYZ
    LEFT_ALL = (0, 7)       # Left hand full (xyz + quat)

    RIGHT_XYZ = (7, 10)     # Right hand translation
    RIGHT_QUAT = (10, 14)   # Right hand quaternion WXYZ
    RIGHT_ALL = (7, 14)     # Right hand full (xyz + quat)


class PaddedWristActionFeature:
    """16-dimensional wrist layout for robot-aligned MotusV2 training.

    Layout: [left_xyzquat(7), left_pad(1), right_xyzquat(7), right_pad(1)].
    """

    ALL_FEATURES = (0, 16)
    LEFT_ALL = (0, 7)
    LEFT_PAD = (7, 8)
    RIGHT_ALL = (8, 15)
    RIGHT_PAD = (15, 16)


def pad_wrist_14_to_16(features: np.ndarray) -> np.ndarray:
    """Pad 14-dim wrist features to [left7, 0, right7, 0].

    Supports either a single state vector [14] or an action sequence [T, 14].
    """
    features = np.asarray(features, dtype=np.float32)
    if features.shape[-1] != 14:
        raise ValueError(f"Expected wrist feature dim 14, got shape {features.shape}")

    out_shape = features.shape[:-1] + (16,)
    padded = np.zeros(out_shape, dtype=np.float32)
    padded[..., :7] = features[..., :7]
    padded[..., 8:15] = features[..., 7:14]
    return padded


def relative_wrist_14_to_initial(actions: np.ndarray, state: np.ndarray) -> np.ndarray:
    """Convert absolute wrist actions to SE(3) deltas from the initial wrist state.

    Input/output layout is the 14-dim wrist format:
    [left_xyz(3), left_quat_wxyz(4), right_xyz(3), right_quat_wxyz(4)].

    Translation deltas are expressed in the initial wrist's local frame:
    R_0^T * (t_future - t_0). Rotation deltas are R_0^T * R_future.
    """
    actions = np.asarray(actions, dtype=np.float32)
    state = np.asarray(state, dtype=np.float32)
    if actions.shape[-1] != 14 or state.shape[-1] != 14:
        raise ValueError(f"Expected actions/state last dim 14, got {actions.shape} and {state.shape}")

    relative = np.zeros_like(actions, dtype=np.float32)

    def _relative_hand(action_hand: np.ndarray, state_hand: np.ndarray) -> np.ndarray:
        if np.allclose(action_hand, 0.0) or np.allclose(state_hand, 0.0):
            return np.zeros(7, dtype=np.float32)

        state_rot = quaternion_to_rotation_matrix_np(state_hand[3:7])
        action_rot = quaternion_to_rotation_matrix_np(action_hand[3:7])
        rel_xyz = state_rot.T @ (action_hand[:3] - state_hand[:3])
        rel_rot = state_rot.T @ action_rot
        rel_quat = rotation_matrix_to_quaternion_np(rel_rot)
        return np.concatenate([rel_xyz, rel_quat], axis=-1).astype(np.float32)

    flat_actions = actions.reshape(-1, 14)
    flat_relative = relative.reshape(-1, 14)
    for i, action in enumerate(flat_actions):
        flat_relative[i, :7] = _relative_hand(action[:7], state[:7])
        flat_relative[i, 7:14] = _relative_hand(action[7:14], state[7:14])

    return relative


def rotation_matrix_to_quaternion_np(rot_mat: np.ndarray) -> np.ndarray:
    """Convert 3x3 rotation matrix to quaternion (WXYZ order).

    Args:
        rot_mat: Rotation matrix, shape (..., 3, 3)

    Returns:
        Quaternion in WXYZ order, shape (..., 4)
    """
    # scipy returns XYZW order
    quat_xyzw = R.from_matrix(rot_mat).as_quat()
    # Convert XYZW -> WXYZ
    return np.roll(quat_xyzw, 1, axis=-1)


def quaternion_to_rotation_matrix_np(quat: np.ndarray) -> np.ndarray:
    """Convert quaternion (WXYZ order) to 3x3 rotation matrix.

    Args:
        quat: Quaternion in WXYZ order, shape (..., 4)

    Returns:
        Rotation matrix, shape (..., 3, 3)
    """
    # Convert WXYZ -> XYZW for scipy
    quat_xyzw = np.roll(quat, -1, axis=-1)
    return R.from_quat(quat_xyzw).as_matrix()


def euler_to_quaternion_np(euler: np.ndarray) -> np.ndarray:
    """Convert Euler angles (XYZ order) to quaternion (WXYZ order).

    Args:
        euler: Euler angles in radians, shape (..., 3)

    Returns:
        Quaternion in WXYZ order, shape (..., 4)
    """
    quat_xyzw = R.from_euler('xyz', euler).as_quat()
    return np.roll(quat_xyzw, 1, axis=-1)


def quaternion_to_euler_np(quat: np.ndarray) -> np.ndarray:
    """Convert quaternion (WXYZ order) to Euler angles (XYZ order).

    Args:
        quat: Quaternion in WXYZ order, shape (..., 4)

    Returns:
        Euler angles in radians, shape (..., 3)
    """
    quat_xyzw = np.roll(quat, -1, axis=-1)
    return R.from_quat(quat_xyzw).as_euler('xyz')


class WristFeatureExtractor:
    """Extract 14-dimensional wrist features from VITRA window data.

    The extractor works with the output of VITRA's _prepare_side_window() method,
    which provides R_cam, t_cam, R_cam_next, t_cam_next in camera space.
    """

    def __init__(self):
        pass

    def extract_wrist_action(
        self,
        win_left: Dict[str, np.ndarray],
        win_right: Dict[str, np.ndarray],
        action_past_window_size: int = 0,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """Extract 14-dimensional wrist action sequence from window data.

        Action is defined as the absolute pose at t+1 (next frame).
        For each time step t in window, the action is [t_cam_next, quat_next].

        Args:
            win_left: Left hand window dict from _prepare_side_window
            win_right: Right hand window dict from _prepare_side_window
            action_past_window_size: Number of past frames in window (to find current frame index)

        Returns:
            action: Wrist action sequence, shape (W, 14)
            action_mask: Valid mask for each hand, shape (W, 2) - [left_valid, right_valid]
        """
        # Get next-frame camera-space rotation and translation
        R_left_next = win_left['R_cam_next']    # (W, 3, 3)
        t_left_next = win_left['t_cam_next']    # (W, 3)
        kept_left_next = win_left['kept_next']  # (W,)

        R_right_next = win_right['R_cam_next']
        t_right_next = win_right['t_cam_next']
        kept_right_next = win_right['kept_next']

        # Convert rotation matrices to quaternions (WXYZ)
        quat_left_next = rotation_matrix_to_quaternion_np(R_left_next)   # (W, 4)
        quat_right_next = rotation_matrix_to_quaternion_np(R_right_next) # (W, 4)

        # Concatenate: [t_left, quat_left, t_right, quat_right]
        action = np.concatenate([
            t_left_next, quat_left_next, t_right_next, quat_right_next
        ], axis=-1).astype(np.float32)  # (W, 14)

        # Build action mask
        W = len(t_left_next)
        action_mask = np.stack([kept_left_next, kept_right_next], axis=1)  # (W, 2)

        # Zero out invalid actions
        valid_left = kept_left_next.astype(bool)
        valid_right = kept_right_next.astype(bool)

        # Create per-dim mask for zeroing
        if not np.all(valid_left):
            for i in range(W):
                if not valid_left[i]:
                    action[i, :7] = 0.0  # Zero left hand features
        if not np.all(valid_right):
            for i in range(W):
                if not valid_right[i]:
                    action[i, 7:] = 0.0  # Zero right hand features

        return action, action_mask

    def extract_wrist_state(
        self,
        win_left: Dict[str, np.ndarray],
        win_right: Dict[str, np.ndarray],
        action_past_window_size: int = 0,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """Extract 14-dimensional wrist state from window data.

        State is defined as the absolute pose at current frame t0.
        The current frame is at index `action_past_window_size` in the window.

        Args:
            win_left: Left hand window dict from _prepare_side_window
            win_right: Right hand window dict from _prepare_side_window
            action_past_window_size: Index of current frame in window

        Returns:
            state: Wrist state, shape (14,)
            state_mask: Valid mask for each hand, shape (2,) - [left_valid, right_valid]
        """
        idx_center = action_past_window_size

        # Get current frame camera-space rotation and translation
        R_left_cur = win_left['R_cam'][idx_center]    # (3, 3)
        t_left_cur = win_left['t_cam'][idx_center]    # (3,)
        kept_left_cur = win_left['kept'][idx_center]  # scalar bool

        R_right_cur = win_right['R_cam'][idx_center]
        t_right_cur = win_right['t_cam'][idx_center]
        kept_right_cur = win_right['kept'][idx_center]

        # Convert rotation matrices to quaternions (WXYZ)
        quat_left_cur = rotation_matrix_to_quaternion_np(R_left_cur)   # (4,)
        quat_right_cur = rotation_matrix_to_quaternion_np(R_right_cur) # (4,)

        # Concatenate: [t_left, quat_left, t_right, quat_right]
        state = np.concatenate([
            t_left_cur, quat_left_cur, t_right_cur, quat_right_cur
        ], axis=-1).astype(np.float32)  # (14,)

        # Build state mask
        state_mask = np.array([kept_left_cur, kept_right_cur], dtype=bool)

        # Zero out invalid state
        if not kept_left_cur:
            state[:7] = 0.0
        if not kept_right_cur:
            state[7:] = 0.0

        return state, state_mask

    def extract_from_vitra_core(
        self,
        core,
        episode_id: str,
        frame_id: int,
        action_past_window_size: int = 0,
        action_future_window_size: int = 15,
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, str]:
        """Extract wrist features directly from VITRA EpisodicDatasetCore.

        This is a convenience method that handles the full extraction pipeline.

        Args:
            core: VITRA EpisodicDatasetCore instance
            episode_id: Episode identifier
            frame_id: Frame index within episode
            action_past_window_size: Number of past frames
            action_future_window_size: Number of future frames

        Returns:
            action: Action sequence, shape (W, 14)
            action_mask: Action validity mask, shape (W, 2)
            state: Current state, shape (14,)
            state_mask: State validity mask, shape (2,)
            instruction: Text instruction
        """
        # Load episode data
        epi, R_w2c, t_w2c = core._load_or_cache_episode(episode_id)
        T = len(epi['extrinsics'])

        # Build window indices
        idx_win, oob = core._window_indices(
            frame_id, action_past_window_size, action_future_window_size, 0, T - 1
        )
        W = len(idx_win)

        # Get instruction text
        main_type = epi['anno_type']
        instruction, idx_win_left, oob_left, idx_win_right, oob_right, \
            start_left, end_left, start_right, end_right = core._build_instruction(
                main_type=main_type,
                text_clip=epi['text'],
                text_rephrase=epi.get('text_rephrase'),
                idx_win=idx_win,
                oob=oob,
                epi_len=T,
                frame_id=frame_id,
                action_past_window_size=action_past_window_size,
                action_future_window_size=action_future_window_size,
            )

        # Prepare side windows
        win_left = core._prepare_side_window(
            epi['left'], R_w2c, t_w2c, idx_win_left, frame_id,
            anchor_frame=True, oob=oob_left, start=start_left, end=end_left,
            upsample_factor=core.upsample_factor
        )
        win_right = core._prepare_side_window(
            epi['right'], R_w2c, t_w2c, idx_win_right, frame_id,
            anchor_frame=True, oob=oob_right, start=start_right, end=end_right,
            upsample_factor=core.upsample_factor
        )

        # Extract wrist features
        action, action_mask = self.extract_wrist_action(
            win_left, win_right, action_past_window_size
        )
        state, state_mask = self.extract_wrist_state(
            win_left, win_right, action_past_window_size
        )

        return action, action_mask, state, state_mask, instruction


class WristGaussianNormalizer:
    """Gaussian normalizer for 14-dimensional wrist features.

    Assumes layout: [left_xyz(3), left_quat(4), right_xyz(3), right_quat(4)]
    """

    def __init__(self, data_statistics: dict):
        """
        Args:
            data_statistics: Dictionary with keys:
                - 'state_left_mean', 'state_left_std' (7-dim)
                - 'state_right_mean', 'state_right_std' (7-dim)
                - 'action_left_mean', 'action_left_std' (7-dim)
                - 'action_right_mean', 'action_right_std' (7-dim)
        """
        # Concatenate left and right statistics
        self.state_mean = np.concatenate([
            data_statistics['state_left_mean'],
            data_statistics['state_right_mean']
        ]).astype(np.float32)
        self.state_std = np.concatenate([
            data_statistics['state_left_std'],
            data_statistics['state_right_std']
        ]).astype(np.float32)
        self.action_mean = np.concatenate([
            data_statistics['action_left_mean'],
            data_statistics['action_right_mean']
        ]).astype(np.float32)
        self.action_std = np.concatenate([
            data_statistics['action_left_std'],
            data_statistics['action_right_std']
        ]).astype(np.float32)

        # Validate dimensions
        assert len(self.state_mean) == 14, f"state_mean should be 14-dim, got {len(self.state_mean)}"
        assert len(self.action_mean) == 14, f"action_mean should be 14-dim, got {len(self.action_mean)}"

    def normalize_state(self, state: np.ndarray, epsilon: float = 1e-7) -> np.ndarray:
        """Normalize state to zero mean and unit variance."""
        return (state - self.state_mean) / (self.state_std + epsilon)

    def unnormalize_state(self, norm_state: np.ndarray, epsilon: float = 1e-7) -> np.ndarray:
        """Denormalize state back to original scale."""
        return norm_state * (self.state_std + epsilon) + self.state_mean

    def normalize_action(self, action: np.ndarray, epsilon: float = 1e-7) -> np.ndarray:
        """Normalize action to zero mean and unit variance."""
        return (action - self.action_mean) / (self.action_std + epsilon)

    def unnormalize_action(self, norm_action: np.ndarray, epsilon: float = 1e-7) -> np.ndarray:
        """Denormalize action back to original scale."""
        return norm_action * (self.action_std + epsilon) + self.action_mean


def compute_wrist_statistics(
    dataset,
    num_samples: int = 10000,
    seed: int = 42,
) -> dict:
    """Compute normalization statistics for wrist features.

    Args:
        dataset: VITRA EpisodicDatasetCore instance
        num_samples: Number of samples to use for statistics
        seed: Random seed for reproducibility

    Returns:
        Dictionary with mean and std for state and action (per hand)
    """
    np.random.seed(seed)

    extractor = WristFeatureExtractor()

    # Collect all wrist features
    left_states = []
    right_states = []
    left_actions = []
    right_actions = []

    total_frames = len(dataset)
    sample_indices = np.random.choice(total_frames, min(num_samples, total_frames), replace=False)

    print(f"Computing wrist statistics from {len(sample_indices)} samples...")

    for i, idx in enumerate(sample_indices):
        if (i + 1) % 1000 == 0:
            print(f"  Processed {i + 1}/{len(sample_indices)} samples")

        try:
            # Get frame data
            if hasattr(dataset, 'training_idx') and dataset.training_idx is not None:
                data_id = dataset.training_idx[idx]
            else:
                data_id = idx

            corr = dataset.index_frame_pair[data_id]
            episode_id = dataset.index_to_episode_id[corr[0]]
            frame_id = int(corr[1])

            # Extract wrist features
            action, action_mask, state, state_mask, _ = extractor.extract_from_vitra_core(
                dataset, episode_id, frame_id,
                action_past_window_size=dataset.action_past_window_size,
                action_future_window_size=dataset.action_future_window_size,
            )

            # Collect valid samples only
            if state_mask[0]:  # left hand valid
                left_states.append(state[:7])
            if state_mask[1]:  # right hand valid
                right_states.append(state[7:])

            # Collect valid actions
            for t in range(len(action)):
                if action_mask[t, 0]:  # left hand valid
                    left_actions.append(action[t, :7])
                if action_mask[t, 1]:  # right hand valid
                    right_actions.append(action[t, 7:])

        except Exception as e:
            print(f"Warning: Failed to process sample {idx}: {e}")
            continue

    # Compute statistics
    left_states = np.array(left_states)
    right_states = np.array(right_states)
    left_actions = np.array(left_actions)
    right_actions = np.array(right_actions)

    print(f"Collected {len(left_states)} left states, {len(right_states)} right states")
    print(f"Collected {len(left_actions)} left actions, {len(right_actions)} right actions")

    statistics = {
        'state_left_mean': np.mean(left_states, axis=0).tolist(),
        'state_left_std': np.std(left_states, axis=0).tolist(),
        'state_right_mean': np.mean(right_states, axis=0).tolist(),
        'state_right_std': np.std(right_states, axis=0).tolist(),
        'action_left_mean': np.mean(left_actions, axis=0).tolist(),
        'action_left_std': np.std(left_actions, axis=0).tolist(),
        'action_right_mean': np.mean(right_actions, axis=0).tolist(),
        'action_right_std': np.std(right_actions, axis=0).tolist(),
    }

    return statistics


def save_wrist_statistics(statistics: dict, save_path: str):
    """Save wrist statistics to JSON file."""
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    with open(save_path, 'w') as f:
        json.dump(statistics, f, indent=2)
    print(f"Saved wrist statistics to {save_path}")


def load_wrist_statistics(load_path: str) -> dict:
    """Load wrist statistics from JSON file."""
    with open(load_path, 'r') as f:
        statistics = json.load(f)

    # Convert lists to numpy arrays
    for key in statistics:
        statistics[key] = np.array(statistics[key])

    return statistics

"""
Per-hand feature dimension constants for padded_per_hand action mode.

In this mode, each dataset preserves its original per-hand features and
pads to a unified max dimension. The padding layout is:
    [left_hand(max_per_hand_dim), right_hand(max_per_hand_dim)]

This preserves all original hand information without lossy compression
to 14-dim wrist mode, while still enabling cross-dataset mixed training.
"""

# ---- Per-hand dimensions for each dataset ----

# Vitra (MANO):
#   action per hand: 51  (16 MANO joints x 3 axis-angle + 3 root rotation)
#   state per hand:  61  (51 pose + 10 shape betas)
VITRA_PER_HAND_ACTION_DIM = 51
VITRA_PER_HAND_STATE_DIM = 61

# WIYH:
#   action per hand: 82  (eef_pose(7) + hand_joint_positions(75))
#   state per hand:  82  (same)
WIYH_PER_HAND_ACTION_DIM = 82
WIYH_PER_HAND_STATE_DIM = 82

# EgoDex:
#   action per hand: 225 (25 hand+finger joints x 9 = xyz(3) + rot6d(6))
#   state per hand:  225 (same)
#   Note: EgoDex has 25 joints per side (Hand + 4 Thumb + 5 Index + 5 Middle + 5 Ring + 5 Little)
#   Each joint contributes xyz(3) + rot6d(6) = 9 dims
EGODEX_PER_HAND_ACTION_DIM = 225
EGODEX_PER_HAND_STATE_DIM = 225

# ---- Unified maximum dimensions ----
MAX_PER_HAND_ACTION_DIM = max(VITRA_PER_HAND_ACTION_DIM, WIYH_PER_HAND_ACTION_DIM, EGODEX_PER_HAND_ACTION_DIM)
MAX_PER_HAND_STATE_DIM = max(VITRA_PER_HAND_STATE_DIM, WIYH_PER_HAND_STATE_DIM, EGODEX_PER_HAND_STATE_DIM)

# Total padded dimensions
PADDED_ACTION_DIM = MAX_PER_HAND_ACTION_DIM * 2  # 450
PADDED_STATE_DIM = MAX_PER_HAND_STATE_DIM * 2    # 450


def pad_per_hand(
    left_feat: "np.ndarray | torch.Tensor",
    right_feat: "np.ndarray | torch.Tensor",
    target_dim: int,
    is_tensor: bool = False,
) -> "tuple[np.ndarray, np.ndarray] | tuple[torch.Tensor, torch.Tensor]":
    """
    Pad per-hand features to target_dim by appending zeros.

    Args:
        left_feat:  [..., D_left] per-hand features for left hand
        right_feat: [..., D_right] per-hand features for right hand
        target_dim: target per-hand dimension (MAX_PER_HAND_*_DIM)
        is_tensor:  if True, use torch; else numpy

    Returns:
        (left_padded, right_padded) each with shape [..., target_dim]
    """
    if is_tensor:
        import torch as _torch
        left_pad_size = target_dim - left_feat.shape[-1]
        right_pad_size = target_dim - right_feat.shape[-1]
        if left_pad_size > 0:
            pad_shape = list(left_feat.shape)
            pad_shape[-1] = left_pad_size
            left_feat = _torch.cat([left_feat, _torch.zeros(pad_shape, dtype=left_feat.dtype)], dim=-1)
        if right_pad_size > 0:
            pad_shape = list(right_feat.shape)
            pad_shape[-1] = right_pad_size
            right_feat = _torch.cat([right_feat, _torch.zeros(pad_shape, dtype=right_feat.dtype)], dim=-1)
    else:
        import numpy as _np
        left_pad_size = target_dim - left_feat.shape[-1]
        right_pad_size = target_dim - right_feat.shape[-1]
        if left_pad_size > 0:
            pad_shape = list(left_feat.shape)
            pad_shape[-1] = left_pad_size
            left_feat = _np.concatenate([left_feat, _np.zeros(pad_shape, dtype=left_feat.dtype)], axis=-1)
        if right_pad_size > 0:
            pad_shape = list(right_feat.shape)
            pad_shape[-1] = right_pad_size
            right_feat = _np.concatenate([right_feat, _np.zeros(pad_shape, dtype=right_feat.dtype)], axis=-1)
    return left_feat, right_feat


def concat_per_hand(
    left_feat: "np.ndarray | torch.Tensor",
    right_feat: "np.ndarray | torch.Tensor",
    target_dim: int,
    is_tensor: bool = False,
):
    """
    Pad and concatenate left+right per-hand features.

    Output: [..., target_dim * 2] with layout [left_padded, right_padded]

    Args:
        left_feat:  [..., D_left]
        right_feat: [..., D_right]
        target_dim: MAX_PER_HAND_*_DIM
        is_tensor:  use torch if True

    Returns:
        concatenated tensor/array of shape [..., target_dim * 2]
    """
    left_padded, right_padded = pad_per_hand(left_feat, right_feat, target_dim, is_tensor)
    if is_tensor:
        import torch as _torch
        return _torch.cat([left_padded, right_padded], dim=-1)
    else:
        import numpy as _np
        return _np.concatenate([left_padded, right_padded], axis=-1)

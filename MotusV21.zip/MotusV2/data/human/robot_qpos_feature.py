"""
robot_qpos_feature.py

36-dimensional Robot Qpos feature extraction for VITRA/Motus.

Action/State representation (Inspire Hand):
- 36 dims = left hand qpos(18) + right hand qpos(18)
- Per hand: [dummy_free_joint(6), finger_joints(12)]
  - [0:3]  xyz translation (wrist position)
  - [3:6]  xyz rotation (wrist euler angles, intrinsic)
  - [6:18] finger joints (6 active + 6 mimic)
"""

from typing import Dict, Tuple
import numpy as np
import json
import os
import logging

logger = logging.getLogger(__name__)

# Inspire Hand qpos dimension per hand
QPOS_DIM_PER_HAND = 18
QPOS_DIM_BOTH_HANDS = 2 * QPOS_DIM_PER_HAND  # 36


class RobotQposFeature:
    """Feature indices for 36-dimensional robot qpos action/state.

    Layout: [left_qpos(18), right_qpos(18)] = 36 dims
    Per hand: [wrist_xyz(3), wrist_euler(3), finger_joints(12)]
    """
    ALL_FEATURES = (0, QPOS_DIM_BOTH_HANDS)

    # Left hand
    LEFT_ALL = (0, QPOS_DIM_PER_HAND)
    LEFT_XYZ = (0, 3)             # Wrist translation
    LEFT_EULER = (3, 6)           # Wrist rotation (XYZ intrinsic euler)
    LEFT_6D = (0, 6)              # Wrist full 6D
    LEFT_FINGERS = (6, QPOS_DIM_PER_HAND)  # Finger joints (6 active + 6 mimic)

    # Right hand
    RIGHT_ALL = (QPOS_DIM_PER_HAND, QPOS_DIM_BOTH_HANDS)
    RIGHT_XYZ = (QPOS_DIM_PER_HAND, QPOS_DIM_PER_HAND + 3)
    RIGHT_EULER = (QPOS_DIM_PER_HAND + 3, QPOS_DIM_PER_HAND + 6)
    RIGHT_6D = (QPOS_DIM_PER_HAND, QPOS_DIM_PER_HAND + 6)
    RIGHT_FINGERS = (QPOS_DIM_PER_HAND + 6, QPOS_DIM_BOTH_HANDS)


class RobotQposNormalizer:
    """Gaussian normalizer for 36-dimensional robot qpos features.

    Assumes layout: [left_qpos(18), right_qpos(18)]
    """

    def __init__(self, data_statistics: dict):
        """
        Args:
            data_statistics: Dictionary with keys:
                - 'state_left_mean', 'state_left_std' (18-dim)
                - 'state_right_mean', 'state_right_std' (18-dim)
                - 'action_left_mean', 'action_left_std' (18-dim)
                - 'action_right_mean', 'action_right_std' (18-dim)
        """
        self.state_mean = np.concatenate([
            data_statistics['state_left_mean'],
            data_statistics['state_right_mean'],
        ]).astype(np.float32)
        self.state_std = np.concatenate([
            data_statistics['state_left_std'],
            data_statistics['state_right_std'],
        ]).astype(np.float32)
        self.action_mean = np.concatenate([
            data_statistics['action_left_mean'],
            data_statistics['action_right_mean'],
        ]).astype(np.float32)
        self.action_std = np.concatenate([
            data_statistics['action_left_std'],
            data_statistics['action_right_std'],
        ]).astype(np.float32)

        assert len(self.state_mean) == QPOS_DIM_BOTH_HANDS, \
            f"state_mean should be {QPOS_DIM_BOTH_HANDS}-dim, got {len(self.state_mean)}"
        assert len(self.action_mean) == QPOS_DIM_BOTH_HANDS, \
            f"action_mean should be {QPOS_DIM_BOTH_HANDS}-dim, got {len(self.action_mean)}"

    def normalize_state(self, state: np.ndarray, epsilon: float = 1e-7) -> np.ndarray:
        """Normalize state to zero mean and unit variance."""
        return (state - self.state_mean) / (self.state_std + epsilon)

    def unnormalize_state(self, norm_state: np.ndarray, epsilon: float = 1e-7) -> np.ndarray:
        """Denormalize state back to original scale."""
        return norm_state * (self.state_std + epsilon) + self.state_mean

    def normalize_action(self, action: np.ndarray, epsilon: float = 1e-7) -> np.ndarray:
        """Normalize action to zero mean and unit variance."""
        return (action - self.action_mean) / (self.action_std + epsilon)

    def unnormalize_action(self, norm_action: np.ndarray, epsilon: float = 1e-7) -> np.ndarray:
        """Denormalize action back to original scale."""
        return norm_action * (self.action_std + epsilon) + self.action_mean


def extract_robot_action_state(
    retarget_data: dict,
    idx_window: np.ndarray,
    anchor_idx: int = 0,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Extract robot qpos action and state from retarget data.

    Args:
        retarget_data: Dict from AnnotationRetarget .npy file containing
            'left_retarget' and 'right_retarget' with 'qpos' arrays.
        idx_window: Frame indices for the window, shape (W+1,)
            where W = past + future frames.
        anchor_idx: Index of current frame t0 in the window.

    Returns:
        action: Qpos at each t+1, shape (W, 36) where W = len(idx_window)-1
        state: Qpos at t0, shape (36,)
        valid_mask: Per-hand validity, shape (W, 2) [left_valid, right_valid]
    """
    left_ret = retarget_data.get('left_retarget', None)
    right_ret = retarget_data.get('right_retarget', None)

    left_qpos = left_ret['qpos'] if left_ret is not None and left_ret['valid'] else None
    right_qpos = right_ret['qpos'] if right_ret is not None and right_ret['valid'] else None
    left_kept = left_ret['kept_frames'] if left_ret is not None else None
    right_kept = right_ret['kept_frames'] if right_ret is not None else None

    # Build full-window qpos with next-frame lookahead
    W_full = len(idx_window)
    action_frames = W_full - 1  # t -> t+1 pairs

    action = np.zeros((action_frames, QPOS_DIM_BOTH_HANDS), dtype=np.float32)
    state = np.zeros(QPOS_DIM_BOTH_HANDS, dtype=np.float32)
    valid_mask = np.zeros((action_frames, 2), dtype=bool)

    for t in range(action_frames):
        idx_next = idx_window[t + 1]

        # Left hand: use carry-forward qpos (already filled by batch_retargeting.py)
        # even when kept_frames is False, so action is never zero-padded.
        # valid_mask still tracks which frames had original tracking data.
        if left_qpos is not None:
            if 0 <= idx_next < left_qpos.shape[0]:
                action[t, :QPOS_DIM_PER_HAND] = left_qpos[idx_next]
                if left_kept is not None and left_kept[idx_next]:
                    valid_mask[t, 0] = True

        # Right hand
        if right_qpos is not None:
            if 0 <= idx_next < right_qpos.shape[0]:
                action[t, QPOS_DIM_PER_HAND:] = right_qpos[idx_next]
                if right_kept is not None and right_kept[idx_next]:
                    valid_mask[t, 1] = True

    # State at t0 (anchor): also use carry-forward qpos
    idx_t0 = idx_window[anchor_idx]
    if left_qpos is not None:
        if 0 <= idx_t0 < left_qpos.shape[0]:
            state[:QPOS_DIM_PER_HAND] = left_qpos[idx_t0]
    if right_qpos is not None:
        if 0 <= idx_t0 < right_qpos.shape[0]:
            state[QPOS_DIM_PER_HAND:] = right_qpos[idx_t0]

    return action, state, valid_mask


def compute_qpos_statistics(
    retarget_folder: str,
    num_samples: int = 10000,
    seed: int = 42,
) -> dict:
    """Compute normalization statistics for robot qpos from retarget data.

    Args:
        retarget_folder: Path to AnnotationRetarget/<subset>/episodic_annotations/
        num_samples: Number of episodes to sample
        seed: Random seed

    Returns:
        Dictionary with mean and std for state and action (per hand)
    """
    np.random.seed(seed)

    import glob
    npy_files = sorted(glob.glob(os.path.join(retarget_folder, "*.npy")))
    if len(npy_files) == 0:
        raise ValueError(f"No .npy files found in {retarget_folder}")

    sample_indices = np.random.choice(len(npy_files), min(num_samples, len(npy_files)), replace=False)

    left_states, right_states = [], []
    left_actions, right_actions = [], []

    logger.info(f"Computing qpos statistics from {len(sample_indices)} episodes...")

    for i, idx in enumerate(sample_indices):
        if (i + 1) % 1000 == 0:
            logger.info(f"  Processed {i + 1}/{len(sample_indices)} episodes")

        try:
            data = np.load(npy_files[idx], allow_pickle=True).item()

            for hand_key, state_list, action_list in [
                ('left_retarget', left_states, left_actions),
                ('right_retarget', right_states, right_actions),
            ]:
                ret = data.get(hand_key, None)
                if ret is None or not ret.get('valid', False):
                    continue
                qpos = ret['qpos']  # (T, 18)
                kept = ret['kept_frames']  # (T,)

                # State: first valid frame
                valid_indices = np.where(kept)[0]
                if len(valid_indices) > 0:
                    state_list.append(qpos[valid_indices[0]])

                # Actions: all valid frames (absolute qpos as action)
                for vi in valid_indices:
                    action_list.append(qpos[vi])

        except Exception as e:
            logger.warning(f"Failed to process {npy_files[idx]}: {e}")
            continue

    left_states = np.array(left_states) if left_states else np.zeros((1, QPOS_DIM_PER_HAND))
    right_states = np.array(right_states) if right_states else np.zeros((1, QPOS_DIM_PER_HAND))
    left_actions = np.array(left_actions) if left_actions else np.zeros((1, QPOS_DIM_PER_HAND))
    right_actions = np.array(right_actions) if right_actions else np.zeros((1, QPOS_DIM_PER_HAND))

    logger.info(f"Collected {len(left_states)} left states, {len(right_states)} right states")
    logger.info(f"Collected {len(left_actions)} left actions, {len(right_actions)} right actions")

    statistics = {
        'state_left_mean': np.mean(left_states, axis=0).tolist(),
        'state_left_std': np.std(left_states, axis=0).tolist(),
        'state_right_mean': np.mean(right_states, axis=0).tolist(),
        'state_right_std': np.std(right_states, axis=0).tolist(),
        'action_left_mean': np.mean(left_actions, axis=0).tolist(),
        'action_left_std': np.std(left_actions, axis=0).tolist(),
        'action_right_mean': np.mean(right_actions, axis=0).tolist(),
        'action_right_std': np.std(right_actions, axis=0).tolist(),
    }

    return statistics


def save_qpos_statistics(statistics: dict, save_path: str):
    """Save qpos statistics to JSON file."""
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    with open(save_path, 'w') as f:
        json.dump(statistics, f, indent=2)
    logger.info(f"Saved qpos statistics to {save_path}")


def load_qpos_statistics(load_path: str) -> dict:
    """Load qpos statistics from JSON file."""
    with open(load_path, 'r') as f:
        statistics = json.load(f)
    for key in statistics:
        statistics[key] = np.array(statistics[key])
    return statistics

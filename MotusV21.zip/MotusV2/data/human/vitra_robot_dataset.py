# data/vitra/vitra_robot_dataset.py
"""
VitraRobotMotusDataset: Robot qpos-based dataset for VITRA-Motus training.

Replaces the 192/212-dim human MANO representation with 36/36-dim Inspire Hand
robot qpos (18-dim per hand × 2 hands). Reads pre-computed retargeting results
from AnnotationRetarget/ instead of processing MANO parameters at runtime.

Output format matches VitraHumanMotusDataset for seamless integration with
the Motus training pipeline.
"""

import os
import sys
import random
import hashlib
import logging
from pathlib import Path
from typing import Any, Dict, Optional, Tuple, List

import numpy as np
import torch
import torch.utils.data as data

from PIL import Image
from transformers import AutoProcessor

from data.utils.image_utils import resize_with_padding, tensor_to_pil
from utils.vlm_utils import preprocess_vlm_messages

logger = logging.getLogger(__name__)

# Import robot qpos feature extraction
from data.human.robot_qpos_feature import (
    RobotQposNormalizer,
    QPOS_DIM_PER_HAND,
    QPOS_DIM_BOTH_HANDS,
    extract_robot_action_state,
    load_qpos_statistics,
)

# Ensure Motus bak/ is importable (for wan.modules.*)
BAK_ROOT = str((Path(__file__).resolve().parents[2] / "bak").resolve())
if BAK_ROOT not in sys.path:
    sys.path.insert(0, BAK_ROOT)

from wan.modules.t5 import T5EncoderModel  # noqa: E402

# ---- T5 Encoder Singleton (shared across all dataset instances) ----
_GLOBAL_T5_ENCODER = None
_GLOBAL_T5_CONFIG = None


def _get_shared_t5_encoder(wan_path: str, t5_text_len: int, t5_device: str):
    """Get or create a singleton T5EncoderModel shared across all dataset instances."""
    global _GLOBAL_T5_ENCODER, _GLOBAL_T5_CONFIG

    config_key = (wan_path, t5_text_len, t5_device)

    if _GLOBAL_T5_ENCODER is None or _GLOBAL_T5_CONFIG != config_key:
        if _GLOBAL_T5_ENCODER is not None:
            del _GLOBAL_T5_ENCODER
            torch.cuda.empty_cache()
            logger.info("[VITRA-Robot] Released previous T5EncoderModel singleton")

        ckpt = os.path.join(wan_path, "Wan2.2-TI2V-5B", "models_t5_umt5-xxl-enc-bf16.pth")
        tok = os.path.join(wan_path, "Wan2.2-TI2V-5B", "google/umt5-xxl")
        _GLOBAL_T5_ENCODER = T5EncoderModel(
            text_len=t5_text_len,
            dtype=torch.bfloat16,
            device=t5_device,
            checkpoint_path=ckpt,
            tokenizer_path=tok,
        )
        _GLOBAL_T5_CONFIG = config_key
        logger.info(f"[VITRA-Robot] Created shared T5EncoderModel singleton on {t5_device}")

    return _GLOBAL_T5_ENCODER


# ---- Local VITRA-compatible core ----
from data.human.vitra_core import VitraEpisodeCore as EpisodicDatasetCore  # noqa: E402
from data.human.vitra_core import load_video_decord  # noqa: E402


def _vitra_paths(dataset_dir: str, dataset_name: str) -> Dict[str, str]:
    """Mirror VITRA's FrameDataset path mapping (same as human dataset)."""
    root = Path(dataset_dir)
    if dataset_name == "ego4d_cooking_and_cleaning":
        return dict(
            annotation_file=str(root / "Annotation/ego4d_cooking_and_cleaning/episode_frame_index.npz"),
            label_folder=str(root / "Annotation/ego4d_cooking_and_cleaning/episodic_annotations"),
            statistics_path=str(root / "Annotation/statistics/ego4d_cooking_and_cleaning_angle_statistics.json"),
            video_root=str(root / "Video/Ego4D_root"),
        )
    if dataset_name == "egoexo4d":
        return dict(
            annotation_file=str(root / "Annotation/egoexo4d/episode_frame_index.npz"),
            label_folder=str(root / "Annotation/egoexo4d/episodic_annotations"),
            statistics_path=str(root / "Annotation/statistics/egoexo4d_angle_statistics.json"),
            video_root=str(root / "Video/EgoExO4D_root"),
        )
    if dataset_name == "epic":
        return dict(
            annotation_file=str(root / "Annotation/epic/episode_frame_index.npz"),
            label_folder=str(root / "Annotation/epic/episodic_annotations"),
            statistics_path=str(root / "Annotation/statistics/epic_angle_statistics.json"),
            video_root=str(root / "Video/Epic-Kitchen_root"),
        )
    if dataset_name == "ssv2":
        return dict(
            annotation_file=str(root / "Annotation/ssv2/episode_frame_index.npz"),
            label_folder=str(root / "Annotation/ssv2/episodic_annotations"),
            statistics_path=str(root / "Annotation/statistics/ssv2_angle_statistics.json"),
            video_root=str(root / "Video/Somethingsomething-v2_root"),
        )
    if dataset_name == "ego4d_other":
        return dict(
            annotation_file=str(root / "Annotation/ego4d_other/episode_frame_index.npz"),
            label_folder=str(root / "Annotation/ego4d_other/episodic_annotations"),
            statistics_path=str(root / "Annotation/statistics/ego4d_other_angle_statistics.json"),
            video_root=str(root / "Video/Ego4D_root"),
        )
    raise ValueError(f"Unknown VITRA dataset_name: {dataset_name}")


def _retarget_paths(dataset_dir: str, dataset_name: str) -> str:
    """Get the retarget annotation folder path for a given dataset."""
    root = Path(dataset_dir)
    # AnnotationRetarget mirrors the Annotation directory structure
    retarget_root = root / "AnnotationRetarget"
    folder = retarget_root / dataset_name / "episodic_annotations"
    if not folder.exists():
        raise ValueError(f"Retarget folder not found: {folder}")
    return str(folder)


class VitraRobotMotusDataset(data.Dataset):
    """
    Wrap VITRA episodes with robot qpos from AnnotationRetarget.

    Output dict matches Motus collate_fn + train_step expectations.
    Action: (F, 36) — left_qpos(18) + right_qpos(18), absolute at t+1
    State:  (36,)   — left_qpos(18) + right_qpos(18), absolute at t0
    """

    def __init__(
        self,
        dataset_dir: str,
        dataset_name: str,
        *,
        retarget_dir: Optional[str] = None,
        num_video_frames: int = 8,
        video_size: Tuple[int, int] = (384, 320),
        clip_len: Optional[int] = None,
        normalization: bool = True,
        qpos_statistics_path: Optional[str] = None,
        # VLM (Qwen3-VL) inputs
        vlm_checkpoint_path: Optional[str] = None,
        # T5 embedding for WAN cross-attn
        t5_mode: str = "disk_cache",
        wan_path: str = "./pretrained_models",
        t5_cache_dir: str = "./t5_cache_vitra_robot",
        t5_text_len: int = 512,
        t5_device: str = "cuda",
        # sampling behavior
        max_attempts: int = 8,
        **kwargs: Any,
    ) -> None:
        super().__init__()
        self.dataset_dir = str(dataset_dir)
        self.dataset_name = str(dataset_name)
        self.num_video_frames = int(num_video_frames)
        self.video_size = video_size
        self.clip_len = clip_len
        self.normalization = bool(normalization)
        self.max_attempts = int(max_attempts)

        # Initialize VITRA EpisodicDatasetCore for episode indexing, video, and instruction
        paths = _vitra_paths(self.dataset_dir, self.dataset_name)
        self.core = EpisodicDatasetCore(
            video_root=paths["video_root"],
            annotation_file=paths["annotation_file"],
            label_folder=paths["label_folder"],
            statistics_path=paths["statistics_path"],
            augmentation=False,
            flip_augmentation=False,
            set_none_ratio=0.0,
            action_type="angle",
            use_rel=False,
            clip_len=self.clip_len,
            action_past_window_size=0,
            action_future_window_size=self.num_video_frames,
            image_past_window_size=0,
            image_future_window_size=0,
            load_images=False,
        )

        if self.normalization and hasattr(self.core, "data_statistics") and getattr(self.core, "data_statistics", None) is not None:
            self.core.set_global_data_statistics(self.core.data_statistics)

        # Retarget folder: either explicitly specified or derived from dataset_dir
        if retarget_dir is not None:
            # retarget_dir is the base dir containing AnnotationRetarget
            self.retarget_folder = Path(retarget_dir) / dataset_name / "episodic_annotations"
        else:
            self.retarget_folder = Path(_retarget_paths(self.dataset_dir, self.dataset_name))

        if not self.retarget_folder.exists():
            raise ValueError(f"Retarget folder not found: {self.retarget_folder}")

        logger.info(f"[VITRA-Robot] Retarget folder: {self.retarget_folder}")

        # Qpos normalization
        self.qpos_normalizer = None
        if qpos_statistics_path is not None and os.path.exists(qpos_statistics_path):
            qpos_stats = load_qpos_statistics(qpos_statistics_path)
            self.qpos_normalizer = RobotQposNormalizer(qpos_stats)
            logger.info(f"[VITRA-Robot] Loaded qpos normalizer from {qpos_statistics_path}")
        elif normalization:
            logger.warning(
                f"[VITRA-Robot] Normalization=True but qpos_statistics_path not found at {qpos_statistics_path}. "
                "Qpos normalization disabled."
            )

        logger.info(
            f"[VITRA-Robot] action_dim={QPOS_DIM_BOTH_HANDS}, state_dim={QPOS_DIM_BOTH_HANDS}"
        )

        # VLM processor (Qwen3-VL)
        self.vlm_processor = None
        if vlm_checkpoint_path:
            self.vlm_processor = AutoProcessor.from_pretrained(vlm_checkpoint_path)
            logger.info(f"[VITRA-Robot] Loaded VLM processor from {vlm_checkpoint_path}")

        # T5 embedding setup (WAN UMT5) — reuse shared singleton
        self.t5_mode = t5_mode
        self.wan_path = str(wan_path)
        self.t5_cache_dir = Path(t5_cache_dir)
        self.t5_cache_dir.mkdir(parents=True, exist_ok=True)

        self.t5_encoder = None
        self.t5_device = t5_device
        if self.t5_mode == "disk_cache":
            self.t5_encoder = _get_shared_t5_encoder(
                wan_path=self.wan_path,
                t5_text_len=t5_text_len,
                t5_device=t5_device,
            )
            logger.info(f"[VITRA-Robot] T5EncoderModel ready (cache={self.t5_cache_dir})")
        elif self.t5_mode == "none":
            logger.warning("[VITRA-Robot] t5_mode=none: language_embedding will be zeros")
        else:
            raise ValueError("t5_mode must be 'disk_cache' or 'none'")

    def __len__(self) -> int:
        return len(self.core)

    @staticmethod
    def _hash_text(text: str) -> str:
        return hashlib.sha1(text.encode("utf-8")).hexdigest()

    def _get_t5_embedding(self, instruction: str) -> torch.Tensor:
        """Return Tensor [seq_len, 4096] (UMT5 encoder output)."""
        if self.t5_mode == "none":
            return torch.zeros((512, 4096), dtype=torch.float32)

        key = self._hash_text(instruction)
        path = self.t5_cache_dir / f"{key}.pt"
        if path.exists():
            emb = torch.load(path, map_location="cpu", weights_only=True)
            return emb.float()

        # cache miss -> encode then atomically write
        assert self.t5_encoder is not None
        out = self.t5_encoder([instruction], self.t5_device)
        if isinstance(out, list):
            emb = out[0]
        elif isinstance(out, torch.Tensor):
            emb = out.squeeze(0)
        else:
            raise TypeError(f"Unexpected T5 encoder output: {type(out)}")
        emb = emb.detach().to("cpu").float()

        tmp = self.t5_cache_dir / f".tmp_{key}_{os.getpid()}.pt"
        torch.save(emb, tmp)
        os.replace(tmp, path)
        return emb

    def _load_retarget_episode(self, episode_id: str) -> dict:
        """Load retarget .npy with robot qpos data."""
        path = self.retarget_folder / f"{episode_id}.npy"
        if not path.exists():
            return None
        return np.load(str(path), allow_pickle=True).item()

    def _load_video_window(self, episode_id: str, frame_id: int) -> torch.Tensor:
        """
        Load frames [t0..tF] using VITRA's episode metadata + path logic.
        Returns: Tensor [F+1, C, H, W] in [0,1], resized with padding.
        """
        epi, _, _ = self.core._load_or_cache_episode(episode_id)
        T = len(epi["extrinsics"])

        idx_win, _ = self.core._window_indices(frame_id, 0, self.num_video_frames, 0, T - 1)
        decode_table = epi["video_decode_frame"]
        decode_ids_full = decode_table[idx_win].tolist()

        dataset_prefix = episode_id.split("_")[0]
        video_name = epi["video_name"]

        part_to_local: Dict[int, List[Tuple[int, int]]] = {}
        for pos, full_idx in enumerate(decode_ids_full):
            if self.clip_len is None:
                part_idx = 0
                frame_in_part = int(full_idx)
            else:
                part_idx = int(full_idx) // int(self.clip_len)
                frame_in_part = int(full_idx) % int(self.clip_len)
            part_to_local.setdefault(part_idx, []).append((pos, frame_in_part))

        images: List[Optional[np.ndarray]] = [None] * len(decode_ids_full)
        for part_idx, pairs in part_to_local.items():
            video_path = self.core._resolve_video_path(dataset_prefix, video_name, part_idx)
            frame_list = [p[1] for p in pairs]
            for attempt in range(3):
                try:
                    imgs, _ = load_video_decord(video_path, frame_index=frame_list, rotation=False)
                    break
                except Exception as e:
                    if attempt == 2:
                        raise
            for (pos, _), img in zip(pairs, imgs):
                images[pos] = img

        assert all(im is not None for im in images)
        resized = [resize_with_padding(im, self.video_size) for im in images]
        arr = np.stack(resized, axis=0)
        ten = torch.from_numpy(arr).permute(0, 3, 1, 2).float() / 255.0
        return ten  # [F+1, C, H, W]

    def _get_robot_sample(
        self,
        episode_id: str,
        frame_id: int,
    ) -> Dict[str, Any]:
        """Get a sample with 36-dimensional robot qpos action/state.

        Action: absolute qpos at t+1 for each frame in [t0..t(F-1)]
        State: absolute qpos at t0
        """
        # Load VITRA episode for indexing and instruction
        epi, R_w2c, t_w2c = self.core._load_or_cache_episode(episode_id)
        T = len(epi["extrinsics"])

        # Build frame window indices
        idx_win, oob = self.core._window_indices(
            frame_id, 0, self.num_video_frames, 0, T - 1
        )

        # Build instruction (reuse VITRA logic)
        main_type = epi["anno_type"]
        instruction, idx_win_left, oob_left, idx_win_right, oob_right, \
            start_left, end_left, start_right, end_right = self.core._build_instruction(
                main_type=main_type,
                text_clip=epi["text"],
                text_rephrase=epi.get("text_rephrase"),
                idx_win=idx_win,
                oob=oob,
                epi_len=T,
                frame_id=frame_id,
                action_past_window_size=0,
                action_future_window_size=self.num_video_frames,
            )

        # Load retarget data
        retarget_data = self._load_retarget_episode(episode_id)
        if retarget_data is None:
            raise ValueError(f"Retarget data not found for episode {episode_id}")

        # Extract robot action/state using the main window indices
        # For robot qpos we use a unified window (both hands share the same frame indices)
        # We use idx_win which covers [t0, t1, ..., tF]
        action, state, valid_mask = extract_robot_action_state(
            retarget_data, idx_win, anchor_idx=0,
        )

        # Apply normalization if available
        if self.qpos_normalizer is not None:
            action = self.qpos_normalizer.normalize_action(action)
            state = self.qpos_normalizer.normalize_state(state)

        # Load video frames
        frames = self._load_video_window(episode_id, frame_id)  # [F+1, C, H, W]
        first_frame = frames[0]
        video_frames = frames[1:]  # [F, C, H, W]

        # Align action_sequence length to F
        action_sequence = torch.tensor(action[:self.num_video_frames], dtype=torch.float32)  # [F, 36]
        current_state = torch.tensor(state, dtype=torch.float32)  # [36]
        action_valid_mask = torch.tensor(valid_mask[:self.num_video_frames], dtype=torch.bool)  # [F, 2]

        # WAN language embedding (UMT5)
        language_embedding = self._get_t5_embedding(instruction)  # [L, 4096]

        # VLM inputs (Qwen3-VL)
        vlm_inputs = None
        if self.vlm_processor is not None:
            first_frame_pil = tensor_to_pil(first_frame)
            vlm_inputs = preprocess_vlm_messages(instruction, first_frame_pil, self.vlm_processor)

        return {
            "first_frame": first_frame,                 # [C, H, W]
            "video_frames": video_frames,               # [F, C, H, W]
            "initial_state": current_state,             # [36]
            "action_sequence": action_sequence,         # [F, 36]
            "action_valid_mask": action_valid_mask,     # [F, 2] per-hand validity
            "language_embedding": language_embedding,   # [L, 4096]
            "vlm_inputs": vlm_inputs,                   # dict or None
        }

    def __getitem__(self, idx: int) -> Optional[Dict[str, Any]]:
        for _ in range(self.max_attempts):
            try:
                data_id = random.randint(0, len(self.core) - 1)
                corr = self.core.index_frame_pair[data_id]
                episode_id = self.core.index_to_episode_id[corr[0]]
                frame_id = int(corr[1])

                return self._get_robot_sample(episode_id, frame_id)
            except Exception as e:
                logger.warning(f"[VITRA-Robot] sample retry due to error: {e}")
                continue

        return None

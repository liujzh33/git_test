"""
unified_eef_action.py

Unified EEF (End-Effector) camera-frame delta wrist action preprocessing.

This module implements the action representation:
    unified_eef_camera_delta_wrist16

Layout (16D):
    [left_delta_xyz_cam(3), left_delta_rotvec_cam(3), 0, 0,
     right_delta_xyz_cam(3), right_delta_rotvec_cam(3), 0, 0]

Per-arm (8D):
    [delta_x_cam, delta_y_cam, delta_z_cam,
     delta_rx_cam, delta_ry_cam, delta_rz_cam,
     reserved_0, reserved_1]

The transformation computes the wrist/EEF delta motion in the reference
camera frame, using SO(3) log map for rotation (axis-angle / rotation vector).

Mathematical definition:
    c      = reference camera frame
    e      = current wrist / EEF frame
    e*     = target wrist / EEF frame
    R_w_e  = current EEF rotation in world (maps EEF-frame vectors to world)
    t_w_e  = current EEF position in world
    R_w_e* = target EEF rotation in world
    t_w_e* = target EEF position in world
    R_w_c  = reference camera rotation in world (maps camera-frame vectors to world)

Step 1: Relative motion in EEF frame
    R_e_e* = R_w_e^T @ R_w_e*
    t_e_e* = R_w_e^T @ (t_w_e* - t_w_e)

Step 2: Project to camera frame
    R_c_e  = R_w_c^T @ R_w_e       (maps EEF-frame vectors to camera frame)
    R_e_c  = R_c_e^T
    R_delta_c = R_c_e @ R_e_e* @ R_e_c
    t_delta_c = R_c_e @ t_e_e*

Step 3: Extract rotation vector
    delta_rotvec_c = log_SO3(R_delta_c)

Step 4: Assemble per-arm action
    per_arm_action_8d = [t_delta_c[0], t_delta_c[1], t_delta_c[2],
                          delta_rotvec_c[0], delta_rotvec_c[1], delta_rotvec_c[2],
                          0, 0]

All quaternion conventions in this file use WXYZ order (scalar first) unless
explicitly noted otherwise.
"""

import numpy as np
from scipy.spatial.transform import Rotation as R
from typing import Optional, Tuple
import logging

logger = logging.getLogger(__name__)

# --- Effective action dimensions for the unified representation ---
# Only dims [0:6] per arm are meaningful for human data; dims [6:8] are reserved (zero, no loss).
# For robot data with gripper: dims [0:6] are delta pose, dim [6] is gripper, dim [7] is reserved.
UNIFIED_EEF_PER_ARM_EFFECTIVE_DIM = 6
UNIFIED_EEF_PER_ARM_TOTAL_DIM = 8
UNIFIED_EEF_ACTION_DIM = 16  # 2 * 8
UNIFIED_EEF_STATE_DIM = 16   # same layout for state

# Mask indices: dims that participate in loss (human data, no gripper)
# Left arm:  [0:6]   (6 dims)
# Right arm: [8:14]  (6 dims)
UNIFIED_EEF_EFFECTIVE_INDICES = list(range(6)) + list(range(8, 14))
# Reserved indices: [6:8] and [14:16]
UNIFIED_EEF_RESERVED_INDICES = list(range(6, 8)) + list(range(14, 16))

# Mask indices for robot data with gripper
# Left arm:  [0:7]   (6 delta + 1 gripper)
# Right arm: [8:15]  (6 delta + 1 gripper)
UNIFIED_EEF_ROBOT_EFFECTIVE_INDICES = list(range(7)) + list(range(8, 15))
UNIFIED_EEF_ROBOT_RESERVED_INDICES = [7, 15]  # dim 7 and 15 are reserved for robots too

# --- Combined qpos + unified EEF (32D) for RobotWin ---
# Layout:
#   [0:16]  abs qpos padded: [L_qpos7, 0, R_qpos7, 0]
#   [16:32] unified EEF:     [L_eef7,  0, R_eef7,  0]
# where eef7 = [delta_xyz_cam(3), delta_rotvec_cam(3), gripper(1)]
# Reserved (masked out of loss): [7, 15, 23, 31]
COMBINED_QPOS_EEF_ACTION_DIM = 32
COMBINED_QPOS_EEF_STATE_DIM = 32
COMBINED_QPOS_EEF_RESERVED_INDICES = [7, 15, 23, 31]
COMBINED_QPOS_EEF_EFFECTIVE_INDICES = [
    i for i in range(COMBINED_QPOS_EEF_ACTION_DIM)
    if i not in COMBINED_QPOS_EEF_RESERVED_INDICES
]
# Qpos block effective (within first 16 dims): [0:7] + [8:15]
COMBINED_QPOS_BLOCK_EFFECTIVE_INDICES = list(range(7)) + list(range(8, 15))
# EEF block effective (absolute indices in 32D): offset robot unified indices by 16
COMBINED_EEF_BLOCK_EFFECTIVE_INDICES = [i + 16 for i in UNIFIED_EEF_ROBOT_EFFECTIVE_INDICES]


def pad_qpos_14_to_16(qpos: np.ndarray) -> np.ndarray:
    """Pad 14D abs qpos to 16D: [L7, 0, R7, 0].

    Supports a single vector [14] or a sequence [T, 14].
    """
    qpos = np.asarray(qpos, dtype=np.float32)
    if qpos.shape[-1] != 14:
        raise ValueError(f"Expected qpos last dim 14, got shape {qpos.shape}")
    out = np.zeros(qpos.shape[:-1] + (16,), dtype=np.float32)
    out[..., :7] = qpos[..., :7]
    out[..., 8:15] = qpos[..., 7:14]
    return out


def pack_combined_qpos_eef_32(
    qpos_14: np.ndarray,
    eef_16: np.ndarray,
) -> np.ndarray:
    """Concatenate padded abs qpos (16) and unified EEF (16) into 32D.

    Args:
        qpos_14: Absolute joint state/action, shape (..., 14).
        eef_16: Unified EEF camera-delta (or state), shape (..., 16).

    Returns:
        Combined vector/sequence, shape (..., 32).
    """
    qpos_14 = np.asarray(qpos_14, dtype=np.float32)
    eef_16 = np.asarray(eef_16, dtype=np.float32)
    if eef_16.shape[-1] != UNIFIED_EEF_ACTION_DIM:
        raise ValueError(f"Expected eef last dim 16, got shape {eef_16.shape}")
    qpos_16 = pad_qpos_14_to_16(qpos_14)
    if qpos_16.shape[:-1] != eef_16.shape[:-1]:
        raise ValueError(
            f"qpos/eef leading shapes must match, got {qpos_16.shape} vs {eef_16.shape}"
        )
    return np.concatenate([qpos_16, eef_16.astype(np.float32, copy=False)], axis=-1)


def build_combined_qpos_eef_valid_mask(
    eef_mask_16: np.ndarray,
    num_frames: Optional[int] = None,
) -> np.ndarray:
    """Build 32D action_valid_mask from a 16D unified EEF robot mask.

    Qpos block: dims [0:7] and [8:15] are always valid; [7] and [15] reserved.
    EEF block: reuse the provided robot unified mask, offset by 16.
    """
    if eef_mask_16 is not None:
        eef_mask_16 = np.asarray(eef_mask_16, dtype=np.float32)
        if eef_mask_16.shape[-1] != UNIFIED_EEF_ACTION_DIM:
            raise ValueError(f"Expected eef mask last dim 16, got {eef_mask_16.shape}")
        leading = eef_mask_16.shape[:-1]
    else:
        if num_frames is None:
            raise ValueError("num_frames is required when eef_mask_16 is None")
        leading = (num_frames,)
        eef_mask_16 = np.zeros(leading + (UNIFIED_EEF_ACTION_DIM,), dtype=np.float32)
        eef_mask_16[..., UNIFIED_EEF_ROBOT_EFFECTIVE_INDICES] = 1.0

    mask = np.zeros(leading + (COMBINED_QPOS_EEF_ACTION_DIM,), dtype=np.float32)
    mask[..., COMBINED_QPOS_BLOCK_EFFECTIVE_INDICES] = 1.0
    mask[..., 16:32] = eef_mask_16
    # Explicitly zero reserved pads
    mask[..., COMBINED_QPOS_EEF_RESERVED_INDICES] = 0.0
    return mask


# --- SO(3) log map (numerically stable) ---

def log_SO3(rot_mat: np.ndarray, eps: float = 1e-7) -> np.ndarray:
    """Compute the SO(3) log map: rotation matrix -> rotation vector (axis-angle).

    Delegates to ``scipy.spatial.transform.Rotation`` for numerical robustness,
    especially near the angle = π singularity where hand-rolled implementations
    tend to lose precision.

    Args:
        rot_mat: Rotation matrix, shape (..., 3, 3).
        eps: Unused, kept for backward-compatible signature.

    Returns:
        Rotation vector (axis * angle), shape (..., 3).
    """
    original_shape = rot_mat.shape[:-2]
    R_flat = rot_mat.reshape(-1, 3, 3)
    rotvecs = R.from_matrix(R_flat).as_rotvec()
    return rotvecs.reshape(original_shape + (3,))


def exp_SO3(rotvec: np.ndarray, eps: float = 1e-7) -> np.ndarray:
    """Compute the SO(3) exponential map: rotation vector -> rotation matrix.

    Inverse of log_SO3. Used for inverse consistency checks.

    Args:
        rotvec: Rotation vector (axis * angle), shape (..., 3).
        eps: Small constant for numerical stability.

    Returns:
        Rotation matrix, shape (..., 3, 3).
    """
    return R.from_rotvec(rotvec.reshape(-1, 3)).as_matrix().reshape(rotvec.shape[:-1] + (3, 3))


# --- Core transformation ---

def compute_camera_delta_action(
    R_w_e: np.ndarray,
    t_w_e: np.ndarray,
    R_w_e_star: np.ndarray,
    t_w_e_star: np.ndarray,
    R_w_c: np.ndarray,
    valid: bool = True,
) -> Tuple[np.ndarray, bool]:
    """Compute per-arm camera-frame delta action.

    This implements the unified EEF camera-delta transformation as defined
    in the module docstring.

    Args:
        R_w_e: Current EEF rotation in world frame, shape (3, 3).
            Maps vectors from EEF frame to world frame.
        t_w_e: Current EEF position in world frame, shape (3,).
        R_w_e_star: Target EEF rotation in world frame, shape (3, 3).
        t_w_e_star: Target EEF position in world frame, shape (3,).
        R_w_c: Reference camera rotation in world frame, shape (3, 3).
            Maps vectors from camera frame to world frame.
        valid: Whether this hand is valid (present in the data).

    Returns:
        action_8d: Per-arm action, shape (8,). Reserved dims are 0.
        valid: Same as input valid flag (or False if NaN detected).
    """
    if not valid:
        return np.zeros(8, dtype=np.float32), False

    # Step 1: Relative motion in EEF frame
    R_e_e_star = R_w_e.T @ R_w_e_star
    t_e_e_star = R_w_e.T @ (t_w_e_star - t_w_e)

    # Step 2: Project to camera frame
    R_c_e = R_w_c.T @ R_w_e
    R_e_c = R_c_e.T

    R_delta_c = R_c_e @ R_e_e_star @ R_e_c
    t_delta_c = R_c_e @ t_e_e_star

    # Step 3: Extract rotation vector via SO(3) log map
    delta_rotvec_c = log_SO3(R_delta_c.reshape(1, 3, 3)).reshape(3)

    # Step 4: Assemble per-arm action
    action_8d = np.zeros(8, dtype=np.float32)
    action_8d[:3] = t_delta_c.astype(np.float32)
    action_8d[3:6] = delta_rotvec_c.astype(np.float32)
    # dims 6,7 remain 0 (reserved)

    # Sanity check: ensure no NaN/Inf
    if not np.all(np.isfinite(action_8d)):
        logger.warning(
            f"Non-finite action detected: "
            f"t_delta_c={t_delta_c}, rotvec={delta_rotvec_c}. "
            f"R_delta_c det={np.linalg.det(R_delta_c):.6f}"
        )
        return np.zeros(8, dtype=np.float32), False

    return action_8d, True


def compute_unified_eef_action_16d(
    R_w_e_left: np.ndarray,
    t_w_e_left: np.ndarray,
    R_w_e_right: np.ndarray,
    t_w_e_right: np.ndarray,
    R_w_e_star_left: np.ndarray,
    t_w_e_star_left: np.ndarray,
    R_w_e_star_right: np.ndarray,
    t_w_e_star_right: np.ndarray,
    R_w_c: np.ndarray,
    left_valid: bool = True,
    right_valid: bool = True,
) -> Tuple[np.ndarray, np.ndarray]:
    """Compute 16D unified EEF camera-delta action.

    Layout: [left_delta_xyz_cam(3), left_delta_rotvec_cam(3), 0, 0,
             right_delta_xyz_cam(3), right_delta_rotvec_cam(3), 0, 0]

    Args:
        R_w_e_left: Current left EEF rotation in world, (3, 3).
        t_w_e_left: Current left EEF position in world, (3,).
        R_w_e_right: Current right EEF rotation in world, (3, 3).
        t_w_e_right: Current right EEF position in world, (3,).
        R_w_e_star_left: Target left EEF rotation in world, (3, 3).
        t_w_e_star_left: Target left EEF position in world, (3,).
        R_w_e_star_right: Target right EEF rotation in world, (3, 3).
        t_w_e_star_right: Target right EEF position in world, (3,).
        R_w_c: Reference camera rotation in world, (3, 3).
        left_valid: Whether left hand data is valid.
        right_valid: Whether right hand data is valid.

    Returns:
        action_16d: Shape (16,), unified action.
        action_mask_16d: Shape (16,), per-dim mask (1 = participate in loss, 0 = skip).
    """
    action_16d = np.zeros(16, dtype=np.float32)
    action_mask_16d = np.zeros(16, dtype=np.float32)

    # Left arm
    left_action_8d, left_ok = compute_camera_delta_action(
        R_w_e=R_w_e_left, t_w_e=t_w_e_left,
        R_w_e_star=R_w_e_star_left, t_w_e_star=t_w_e_star_left,
        R_w_c=R_w_c, valid=left_valid,
    )
    action_16d[:8] = left_action_8d
    if left_ok:
        action_mask_16d[0:6] = 1.0

    # Right arm
    right_action_8d, right_ok = compute_camera_delta_action(
        R_w_e=R_w_e_right, t_w_e=t_w_e_right,
        R_w_e_star=R_w_e_star_right, t_w_e_star=t_w_e_star_right,
        R_w_c=R_w_c, valid=right_valid,
    )
    action_16d[8:16] = right_action_8d
    if right_ok:
        action_mask_16d[8:14] = 1.0

    return action_16d, action_mask_16d


def compute_unified_eef_state_16d(
    R_w_e_left: np.ndarray,
    t_w_e_left: np.ndarray,
    R_w_e_right: np.ndarray,
    t_w_e_right: np.ndarray,
    R_w_c: np.ndarray,
    t_w_c: np.ndarray,
    left_valid: bool = True,
    right_valid: bool = True,
) -> Tuple[np.ndarray, np.ndarray]:
    """Compute 16D unified EEF state (current wrist pose in camera frame).

    Layout: [left_xyz_cam(3), left_rotvec_cam(3), 0, 0,
             right_xyz_cam(3), right_rotvec_cam(3), 0, 0]

    This encodes the *current* wrist pose expressed in the reference camera frame.

    Args:
        R_w_e_left: Current left EEF rotation in world, (3, 3).
        t_w_e_left: Current left EEF position in world, (3,).
        R_w_e_right: Current right EEF rotation in world, (3, 3).
        t_w_e_right: Current right EEF position in world, (3,).
        R_w_c: Reference camera rotation in world, (3, 3).
            Maps vectors from camera frame to world frame.
        t_w_c: Reference camera position in world, (3,).
        left_valid: Whether left hand data is valid.
        right_valid: Whether right hand data is valid.

    Returns:
        state_16d: Shape (16,), unified state.
        state_mask_16d: Shape (16,), per-dim mask.
    """
    state_16d = np.zeros(16, dtype=np.float32)
    state_mask_16d = np.zeros(16, dtype=np.float32)

    R_c_w = R_w_c.T  # maps world-frame vectors to camera frame

    # Left arm
    if left_valid:
        t_cam_left = R_c_w @ (t_w_e_left - t_w_c)
        R_cam_left = R_c_w @ R_w_e_left
        rotvec_cam_left = log_SO3(R_cam_left.reshape(1, 3, 3)).reshape(3)

        state_16d[:3] = t_cam_left.astype(np.float32)
        state_16d[3:6] = rotvec_cam_left.astype(np.float32)
        state_mask_16d[0:6] = 1.0

    # Right arm
    if right_valid:
        t_cam_right = R_c_w @ (t_w_e_right - t_w_c)
        R_cam_right = R_c_w @ R_w_e_right
        rotvec_cam_right = log_SO3(R_cam_right.reshape(1, 3, 3)).reshape(3)

        state_16d[8:11] = t_cam_right.astype(np.float32)
        state_16d[11:14] = rotvec_cam_right.astype(np.float32)
        state_mask_16d[8:14] = 1.0

    return state_16d, state_mask_16d


# --- Adapter helpers for different input formats ---

def quat_wxyz_to_rotmat(quat_wxyz: np.ndarray) -> np.ndarray:
    """Convert quaternion (WXYZ order, scalar first) to 3x3 rotation matrix.

    Handles quaternion canonicalization (q and -q represent the same rotation):
    ensures w >= 0 to avoid discontinuities.

    Args:
        quat_wxyz: Quaternion in WXYZ order, shape (..., 4).

    Returns:
        Rotation matrix, shape (..., 3, 3).
    """
    quat_wxyz = np.asarray(quat_wxyz, dtype=np.float64)

    # Canonicalize: ensure w >= 0 for consistency
    w = quat_wxyz[..., 0:1]
    quat_wxyz = np.where(w < 0, -quat_wxyz, quat_wxyz)

    # Convert WXYZ -> XYZW for scipy
    quat_xyzw = np.roll(quat_wxyz, -1, axis=-1)
    return R.from_quat(quat_xyzw.reshape(-1, 4)).as_matrix().reshape(quat_wxyz.shape[:-1] + (3, 3))


def relative_xyzquat_to_camera_delta(
    R_w_e: np.ndarray,
    t_w_e: np.ndarray,
    rel_xyz: np.ndarray,
    rel_quat_wxyz: np.ndarray,
    R_w_c: np.ndarray,
    relative_in_eef_frame: bool = True,
    valid: bool = True,
) -> Tuple[np.ndarray, bool]:
    """Convert a relative xyzquat action to camera-frame delta.

    This adapter handles datasets that provide pre-computed relative wrist
    actions in xyzquat format, converting them to the unified representation.

    Args:
        R_w_e: Current EEF rotation in world, (3, 3).
        t_w_e: Current EEF position in world, (3,).
        rel_xyz: Relative translation, shape (3,).
        rel_quat_wxyz: Relative quaternion (WXYZ), shape (4,).
        R_w_c: Reference camera rotation in world, (3, 3).
        relative_in_eef_frame: If True, rel_xyzquat is in current EEF frame
            (i.e., t_e_e* and R_e_e*). If False, it's in world/base frame.
        valid: Whether this hand is valid.

    Returns:
        action_8d: Per-arm action, shape (8,).
        valid: Whether the result is valid.
    """
    if not valid:
        return np.zeros(8, dtype=np.float32), False

    # Canonicalize quaternion
    rel_quat_wxyz = rel_quat_wxyz.copy()
    if rel_quat_wxyz[0] < 0:
        rel_quat_wxyz = -rel_quat_wxyz

    if relative_in_eef_frame:
        t_e_e_star = rel_xyz
        R_e_e_star = quat_wxyz_to_rotmat(rel_quat_wxyz)
        R_w_e_star = R_w_e @ R_e_e_star
        t_w_e_star = t_w_e + R_w_e @ t_e_e_star
    else:
        R_delta_world = quat_wxyz_to_rotmat(rel_quat_wxyz)
        R_w_e_star = R_delta_world @ R_w_e
        t_w_e_star = t_w_e + rel_xyz

    return compute_camera_delta_action(
        R_w_e=R_w_e, t_w_e=t_w_e,
        R_w_e_star=R_w_e_star, t_w_e_star=t_w_e_star,
        R_w_c=R_w_c, valid=True,
    )


def build_hand_world_poses_from_xyzquat(
    xyz: np.ndarray,
    quat_wxyz: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray]:
    """Build world-frame hand poses from absolute xyz + quaternion.

    Args:
        xyz: Position, shape (T, 3) or (3,).
        quat_wxyz: Quaternion WXYZ, shape (T, 4) or (4,).

    Returns:
        R_w_e: Rotation in world, shape (T, 3, 3) or (3, 3).
        t_w_e: Position in world, shape (T, 3) or (3,).
    """
    R_w_e = quat_wxyz_to_rotmat(quat_wxyz)
    t_w_e = np.asarray(xyz, dtype=np.float32)
    return R_w_e, t_w_e


def build_hand_world_poses_from_rotmat(
    t_w_e: np.ndarray,
    R_w_e_flat: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray]:
    """Build world-frame hand poses from absolute translation + flat rotation matrix.

    Args:
        t_w_e: Position in world, shape (T, 3) or (3,).
        R_w_e_flat: Rotation matrix flattened to 9, shape (T, 9) or (9,).

    Returns:
        R_w_e: Rotation in world, shape (T, 3, 3) or (3, 3).
        t_w_e: Position in world, shape (T, 3) or (3,).
    """
    if R_w_e_flat.ndim == 1:
        R_w_e = R_w_e_flat.reshape(3, 3)
    else:
        R_w_e = R_w_e_flat.reshape(-1, 3, 3)
    t_w_e = np.asarray(t_w_e, dtype=np.float32)
    return R_w_e, t_w_e


def build_hand_world_poses_from_se3_4x4(
    T_w_e: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray]:
    """Build world-frame hand poses from 4x4 SE(3) matrices.

    Args:
        T_w_e: SE(3) matrices, shape (T, 4, 4) or (4, 4).

    Returns:
        R_w_e: Rotation in world, shape (T, 3, 3) or (3, 3).
        t_w_e: Position in world, shape (T, 3) or (3,).
    """
    R_w_e = T_w_e[..., :3, :3]
    t_w_e = T_w_e[..., :3, 3]
    return R_w_e, t_w_e


def build_camera_world_pose_from_slam(
    slam_trans: np.ndarray,
    slam_quat_wxyz: np.ndarray,
    T_c_b: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray]:
    """Build camera world pose from SLAM head pose + calibration.

    The SLAM system provides the device/body pose in world frame.
    The calibration provides T_c_b (body-to-camera transform:
    p_cam0 = T_c_b @ p_body).
    We need R_w_c and t_w_c (camera pose in world).

    T_w_cam0 = T_w_body @ T_body_cam0 = T_w_body @ inv(T_c_b)

    Args:
        slam_trans: SLAM body position in world, shape (3,).
        slam_quat_wxyz: SLAM body orientation in world (WXYZ), shape (4,).
        T_c_b: Body-to-camera transform, shape (4, 4).
            Maps body-frame points to cam0-frame: p_cam0 = T_c_b @ p_body

    Returns:
        R_w_c: Camera rotation in world, (3, 3).
            Maps camera-frame vectors to world frame.
        t_w_c: Camera position in world, (3,).
    """
    # Build T_w_body from SLAM
    R_w_body = quat_wxyz_to_rotmat(slam_quat_wxyz)  # (3, 3)
    t_w_body = np.asarray(slam_trans, dtype=np.float64)

    # T_body_cam0 = inv(T_c_b)
    T_body_cam0 = np.linalg.inv(T_c_b)
    R_body_cam0 = T_body_cam0[:3, :3]
    t_body_cam0 = T_body_cam0[:3, 3]

    # T_w_cam0 = T_w_body @ T_body_cam0
    R_w_c = R_w_body @ R_body_cam0
    t_w_c = t_w_body + R_w_body @ t_body_cam0

    return R_w_c.astype(np.float32), t_w_c.astype(np.float32)


def build_hand_world_poses_from_camera_frame(
    R_c_e: np.ndarray,
    t_c_e: np.ndarray,
    R_w_c: np.ndarray,
    t_w_c: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray]:
    """Lift hand poses expressed in a (per-frame) camera frame to the world frame.

    Some egocentric datasets (e.g. Xperience-10M) store the hand pose directly in
    the *current camera* frame at every timestamp rather than in a fixed world
    frame.  Given the per-frame camera pose in world (``R_w_c``, ``t_w_c``) this
    converts a camera-frame hand pose ``T_c_e`` into the world-frame pose
    ``T_w_e`` expected by :func:`compute_unified_eef_action_sequence` /
    :func:`compute_unified_eef_state_from_poses`:

        R_w_e = R_w_c @ R_c_e
        t_w_e = R_w_c @ t_c_e + t_w_c

    All inputs may be either single poses ``(3,3)/(3,)`` or time-batched
    ``(T,3,3)/(T,3)`` (with ``R_w_c`` / ``t_w_c`` broadcast per frame).

    Args:
        R_c_e: Hand rotation in the camera frame, (..., 3, 3).
            Maps EEF-frame vectors to the camera frame.
        t_c_e: Hand position in the camera frame, (..., 3).
        R_w_c: Camera rotation in world, (..., 3, 3). Maps camera->world.
        t_w_c: Camera position in world, (..., 3).

    Returns:
        R_w_e: Hand rotation in world, (..., 3, 3).
        t_w_e: Hand position in world, (..., 3).
    """
    R_c_e = np.asarray(R_c_e, dtype=np.float64)
    t_c_e = np.asarray(t_c_e, dtype=np.float64)
    R_w_c = np.asarray(R_w_c, dtype=np.float64)
    t_w_c = np.asarray(t_w_c, dtype=np.float64)

    R_w_e = R_w_c @ R_c_e  # batched matmul: (T,3,3)@(T,3,3) or (3,3)@(3,3)
    t_w_e = np.einsum("...ij,...j->...i", R_w_c, t_c_e) + t_w_c
    return R_w_e, t_w_e


# --- Batch processing for full sequences ---

def compute_unified_eef_action_sequence(
    R_w_e_left: np.ndarray,   # (T+1, 3, 3)
    t_w_e_left: np.ndarray,   # (T+1, 3)
    R_w_e_right: np.ndarray,
    t_w_e_right: np.ndarray,
    R_w_c: np.ndarray,        # (3, 3)
    left_valid: np.ndarray,   # (T+1,) bool
    right_valid: np.ndarray,  # (T+1,) bool
    num_action_frames: int,
) -> Tuple[np.ndarray, np.ndarray]:
    """Compute unified EEF action sequence for a video window.

    For each time step i in [0, num_action_frames), the action is the
    camera-frame delta from the **anchor** frame 0 to frame i+1.

        action[i] = delta(pose[0] -> pose[i+1])

    All actions share the same current EEF frame (pose[0]) and the same
    reference camera frame (frame 0).  This is "anchor-based" semantics,
    matching the old ``relative_wrist_padded16`` horizon convention.

    Args:
        R_w_e_left: Left EEF rotations in world, shape (T+1, 3, 3).
            Frame 0 is the anchor / current frame.
        t_w_e_left: Left EEF positions in world, shape (T+1, 3).
        R_w_e_right: Right EEF rotations in world, shape (T+1, 3, 3).
        t_w_e_right: Right EEF positions in world, shape (T+1, 3).
        R_w_c: Reference camera rotation in world, shape (3, 3).
            The camera at frame 0 (anchor frame).
        left_valid: Left hand validity, shape (T+1,).
        right_valid: Right hand validity, shape (T+1,).
        num_action_frames: Number of action frames (T).

    Returns:
        actions: Shape (T, 16), unified action sequence.
        action_masks: Shape (T, 16), per-dim validity masks.
    """
    actions = np.zeros((num_action_frames, 16), dtype=np.float32)
    action_masks = np.zeros((num_action_frames, 16), dtype=np.float32)

    # Anchor frame is always frame 0.
    # An action[i] is valid only when BOTH the anchor (frame 0) and the
    # target frame (i+1) are valid.
    lv_anchor = bool(left_valid[0]) if left_valid.ndim > 0 else bool(left_valid)
    rv_anchor = bool(right_valid[0]) if right_valid.ndim > 0 else bool(right_valid)

    for i in range(num_action_frames):
        target = i + 1  # target frame index
        lv_tgt = bool(left_valid[target]) if left_valid.ndim > 0 else bool(left_valid)
        rv_tgt = bool(right_valid[target]) if right_valid.ndim > 0 else bool(right_valid)

        action_16d, mask_16d = compute_unified_eef_action_16d(
            # Anchor (current) pose = frame 0
            R_w_e_left=R_w_e_left[0],
            t_w_e_left=t_w_e_left[0],
            R_w_e_right=R_w_e_right[0],
            t_w_e_right=t_w_e_right[0],
            # Target pose = frame i+1
            R_w_e_star_left=R_w_e_left[target],
            t_w_e_star_left=t_w_e_left[target],
            R_w_e_star_right=R_w_e_right[target],
            t_w_e_star_right=t_w_e_right[target],
            R_w_c=R_w_c,
            left_valid=lv_anchor and lv_tgt,
            right_valid=rv_anchor and rv_tgt,
        )

        actions[i] = action_16d
        action_masks[i] = mask_16d

    return actions, action_masks


def compute_unified_eef_state_from_poses(
    R_w_e_left: np.ndarray,
    t_w_e_left: np.ndarray,
    R_w_e_right: np.ndarray,
    t_w_e_right: np.ndarray,
    R_w_c: np.ndarray,
    t_w_c: np.ndarray,
    left_valid: bool = True,
    right_valid: bool = True,
) -> Tuple[np.ndarray, np.ndarray]:
    """Compute unified EEF state for a single frame.

    Returns:
        state_16d: Shape (16,).
        state_mask_16d: Shape (16,).
    """
    return compute_unified_eef_state_16d(
        R_w_e_left=R_w_e_left, t_w_e_left=t_w_e_left,
        R_w_e_right=R_w_e_right, t_w_e_right=t_w_e_right,
        R_w_c=R_w_c, t_w_c=t_w_c,
        left_valid=left_valid, right_valid=right_valid,
    )


# --- Robot variants with gripper state ---

def compute_camera_delta_action_with_gripper(
    R_w_e: np.ndarray,
    t_w_e: np.ndarray,
    R_w_e_star: np.ndarray,
    t_w_e_star: np.ndarray,
    R_w_c: np.ndarray,
    gripper: float = 0.0,
    gripper_star: float = 0.0,
    valid: bool = True,
) -> Tuple[np.ndarray, bool]:
    """Compute per-arm camera-frame delta action with gripper state.

    Same as compute_camera_delta_action, but places gripper value at dim [6]
    instead of leaving it reserved (zero).  Dim [7] remains reserved (zero).

    Layout per arm: [delta_xyz_cam(3), delta_rotvec_cam(3), gripper(1), 0]

    Args:
        R_w_e: Current EEF rotation in world frame, shape (3, 3).
        t_w_e: Current EEF position in world frame, shape (3,).
        R_w_e_star: Target EEF rotation in world frame, shape (3, 3).
        t_w_e_star: Target EEF position in world frame, shape (3,).
        R_w_c: Reference camera rotation in world frame, shape (3, 3).
        gripper: Current gripper state (0=closed, 1=open).
        gripper_star: Target gripper state.
        valid: Whether this hand is valid.

    Returns:
        action_8d: Per-arm action, shape (8,). Dim 6 = gripper, dim 7 = 0.
        valid: Same as input valid flag (or False if NaN detected).
    """
    if not valid:
        return np.zeros(8, dtype=np.float32), False

    # Step 1: Relative motion in EEF frame
    R_e_e_star = R_w_e.T @ R_w_e_star
    t_e_e_star = R_w_e.T @ (t_w_e_star - t_w_e)

    # Step 2: Project to camera frame
    R_c_e = R_w_c.T @ R_w_e
    R_e_c = R_c_e.T

    R_delta_c = R_c_e @ R_e_e_star @ R_e_c
    t_delta_c = R_c_e @ t_e_e_star

    # Step 3: Extract rotation vector via SO(3) log map
    delta_rotvec_c = log_SO3(R_delta_c.reshape(1, 3, 3)).reshape(3)

    # Step 4: Assemble per-arm action with gripper
    action_8d = np.zeros(8, dtype=np.float32)
    action_8d[:3] = t_delta_c.astype(np.float32)
    action_8d[3:6] = delta_rotvec_c.astype(np.float32)
    action_8d[6] = float(gripper_star)  # target gripper state
    # dim 7 remains 0 (reserved)

    # Sanity check: ensure no NaN/Inf
    if not np.all(np.isfinite(action_8d)):
        logger.warning(
            f"Non-finite action detected: "
            f"t_delta_c={t_delta_c}, rotvec={delta_rotvec_c}, gripper={gripper_star}. "
            f"R_delta_c det={np.linalg.det(R_delta_c):.6f}"
        )
        return np.zeros(8, dtype=np.float32), False

    return action_8d, True


def compute_unified_eef_action_16d_with_gripper(
    R_w_e_left: np.ndarray,
    t_w_e_left: np.ndarray,
    R_w_e_right: np.ndarray,
    t_w_e_right: np.ndarray,
    R_w_e_star_left: np.ndarray,
    t_w_e_star_left: np.ndarray,
    R_w_e_star_right: np.ndarray,
    t_w_e_star_right: np.ndarray,
    R_w_c: np.ndarray,
    left_gripper: float = 0.0,
    right_gripper: float = 0.0,
    left_gripper_star: float = 0.0,
    right_gripper_star: float = 0.0,
    left_valid: bool = True,
    right_valid: bool = True,
) -> Tuple[np.ndarray, np.ndarray]:
    """Compute 16D unified EEF camera-delta action with gripper state.

    Layout: [left_delta_xyz_cam(3), left_delta_rotvec_cam(3), left_gripper(1), 0,
             right_delta_xyz_cam(3), right_delta_rotvec_cam(3), right_gripper(1), 0]

    For robot data where gripper state is meaningful.  Dims 7 and 15 are
    reserved (always zero).  The mask covers dims [0:7] and [8:15].

    Args:
        (Same as compute_unified_eef_action_16d, plus gripper values)

    Returns:
        action_16d: Shape (16,), unified action.
        action_mask_16d: Shape (16,), per-dim mask (1 = participate in loss, 0 = skip).
    """
    action_16d = np.zeros(16, dtype=np.float32)
    action_mask_16d = np.zeros(16, dtype=np.float32)

    # Left arm
    left_action_8d, left_ok = compute_camera_delta_action_with_gripper(
        R_w_e=R_w_e_left, t_w_e=t_w_e_left,
        R_w_e_star=R_w_e_star_left, t_w_e_star=t_w_e_star_left,
        R_w_c=R_w_c,
        gripper=left_gripper, gripper_star=left_gripper_star,
        valid=left_valid,
    )
    action_16d[:8] = left_action_8d
    if left_ok:
        action_mask_16d[0:7] = 1.0  # dims 0-6 (including gripper)
        # dim 7 reserved, mask stays 0

    # Right arm
    right_action_8d, right_ok = compute_camera_delta_action_with_gripper(
        R_w_e=R_w_e_right, t_w_e=t_w_e_right,
        R_w_e_star=R_w_e_star_right, t_w_e_star=t_w_e_star_right,
        R_w_c=R_w_c,
        gripper=right_gripper, gripper_star=right_gripper_star,
        valid=right_valid,
    )
    action_16d[8:16] = right_action_8d
    if right_ok:
        action_mask_16d[8:15] = 1.0  # dims 8-14 (including gripper)
        # dim 15 reserved, mask stays 0

    return action_16d, action_mask_16d


def compute_unified_eef_state_16d_with_gripper(
    R_w_e_left: np.ndarray,
    t_w_e_left: np.ndarray,
    R_w_e_right: np.ndarray,
    t_w_e_right: np.ndarray,
    R_w_c: np.ndarray,
    t_w_c: np.ndarray,
    left_gripper: float = 0.0,
    right_gripper: float = 0.0,
    left_valid: bool = True,
    right_valid: bool = True,
) -> Tuple[np.ndarray, np.ndarray]:
    """Compute 16D unified EEF state with gripper (current pose in camera frame).

    Layout: [left_xyz_cam(3), left_rotvec_cam(3), left_gripper(1), 0,
             right_xyz_cam(3), right_rotvec_cam(3), right_gripper(1), 0]

    Args:
        (Same as compute_unified_eef_state_16d, plus gripper values)

    Returns:
        state_16d: Shape (16,), unified state.
        state_mask_16d: Shape (16,), per-dim mask.
    """
    state_16d = np.zeros(16, dtype=np.float32)
    state_mask_16d = np.zeros(16, dtype=np.float32)

    R_c_w = R_w_c.T  # maps world-frame vectors to camera frame

    # Left arm
    if left_valid:
        t_cam_left = R_c_w @ (t_w_e_left - t_w_c)
        R_cam_left = R_c_w @ R_w_e_left
        rotvec_cam_left = log_SO3(R_cam_left.reshape(1, 3, 3)).reshape(3)

        state_16d[:3] = t_cam_left.astype(np.float32)
        state_16d[3:6] = rotvec_cam_left.astype(np.float32)
        state_16d[6] = float(left_gripper)
        state_mask_16d[0:7] = 1.0
        # dim 7 reserved, mask stays 0

    # Right arm
    if right_valid:
        t_cam_right = R_c_w @ (t_w_e_right - t_w_c)
        R_cam_right = R_c_w @ R_w_e_right
        rotvec_cam_right = log_SO3(R_cam_right.reshape(1, 3, 3)).reshape(3)

        state_16d[8:11] = t_cam_right.astype(np.float32)
        state_16d[11:14] = rotvec_cam_right.astype(np.float32)
        state_16d[14] = float(right_gripper)
        state_mask_16d[8:15] = 1.0
        # dim 15 reserved, mask stays 0

    return state_16d, state_mask_16d


def compute_unified_eef_action_sequence_with_gripper(
    R_w_e_left: np.ndarray,   # (T+1, 3, 3)
    t_w_e_left: np.ndarray,   # (T+1, 3)
    R_w_e_right: np.ndarray,
    t_w_e_right: np.ndarray,
    R_w_c: np.ndarray,        # (3, 3)
    left_gripper: np.ndarray,  # (T+1,) float
    right_gripper: np.ndarray, # (T+1,) float
    left_valid: np.ndarray,   # (T+1,) bool
    right_valid: np.ndarray,  # (T+1,) bool
    num_action_frames: int,
) -> Tuple[np.ndarray, np.ndarray]:
    """Compute unified EEF action sequence with gripper for a video window.

    For each time step i in [0, num_action_frames), the action is the
    camera-frame delta from the **anchor** frame 0 to frame i+1.

        action[i] = delta(pose[0] -> pose[i+1])

    Gripper at action[i] is the **target** gripper value at frame i+1
    (anchor-based, same as the pose delta).

    Args:
        R_w_e_left: Left EEF rotations in world, shape (T+1, 3, 3).
        t_w_e_left: Left EEF positions in world, shape (T+1, 3).
        R_w_e_right: Right EEF rotations in world, shape (T+1, 3, 3).
        t_w_e_right: Right EEF positions in world, shape (T+1, 3).
        R_w_c: Reference camera rotation in world, shape (3, 3).
        left_gripper: Left gripper states, shape (T+1,).
        right_gripper: Right gripper states, shape (T+1,).
        left_valid: Left hand validity, shape (T+1,).
        right_valid: Right hand validity, shape (T+1,).
        num_action_frames: Number of action frames (T).

    Returns:
        actions: Shape (T, 16), unified action sequence.
        action_masks: Shape (T, 16), per-dim validity masks.
    """
    actions = np.zeros((num_action_frames, 16), dtype=np.float32)
    action_masks = np.zeros((num_action_frames, 16), dtype=np.float32)

    # Anchor frame is always frame 0.
    lv_anchor = bool(left_valid[0]) if left_valid.ndim > 0 else bool(left_valid)
    rv_anchor = bool(right_valid[0]) if right_valid.ndim > 0 else bool(right_valid)

    for i in range(num_action_frames):
        target = i + 1  # target frame index
        lv_tgt = bool(left_valid[target]) if left_valid.ndim > 0 else bool(left_valid)
        rv_tgt = bool(right_valid[target]) if right_valid.ndim > 0 else bool(right_valid)

        action_16d, mask_16d = compute_unified_eef_action_16d_with_gripper(
            # Anchor (current) pose = frame 0
            R_w_e_left=R_w_e_left[0],
            t_w_e_left=t_w_e_left[0],
            R_w_e_right=R_w_e_right[0],
            t_w_e_right=t_w_e_right[0],
            # Target pose = frame i+1
            R_w_e_star_left=R_w_e_left[target],
            t_w_e_star_left=t_w_e_left[target],
            R_w_e_star_right=R_w_e_right[target],
            t_w_e_star_right=t_w_e_right[target],
            R_w_c=R_w_c,
            # Gripper: anchor vs target
            left_gripper=float(left_gripper[0]),
            right_gripper=float(right_gripper[0]),
            left_gripper_star=float(left_gripper[target]),
            right_gripper_star=float(right_gripper[target]),
            left_valid=lv_anchor and lv_tgt,
            right_valid=rv_anchor and rv_tgt,
        )

        actions[i] = action_16d
        action_masks[i] = mask_16d

    return actions, action_masks


def compute_unified_eef_state_from_poses_with_gripper(
    R_w_e_left: np.ndarray,
    t_w_e_left: np.ndarray,
    R_w_e_right: np.ndarray,
    t_w_e_right: np.ndarray,
    R_w_c: np.ndarray,
    t_w_c: np.ndarray,
    left_gripper: float = 0.0,
    right_gripper: float = 0.0,
    left_valid: bool = True,
    right_valid: bool = True,
) -> Tuple[np.ndarray, np.ndarray]:
    """Compute unified EEF state with gripper for a single frame.

    Returns:
        state_16d: Shape (16,).
        state_mask_16d: Shape (16,).
    """
    return compute_unified_eef_state_16d_with_gripper(
        R_w_e_left=R_w_e_left, t_w_e_left=t_w_e_left,
        R_w_e_right=R_w_e_right, t_w_e_right=t_w_e_right,
        R_w_c=R_w_c, t_w_c=t_w_c,
        left_gripper=left_gripper,
        right_gripper=right_gripper,
        left_valid=left_valid,
        right_valid=right_valid,
    )

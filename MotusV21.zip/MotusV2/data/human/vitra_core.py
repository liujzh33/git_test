import functools
import json
import os
import random
from typing import Optional

import decord
import numpy as np
import torch
from scipy.spatial.transform import Rotation as R


class ActionFeature:
    ALL_FEATURES = (0, 192)


class StateFeature(ActionFeature):
    ALL_FEATURES = (0, 212)


def load_video_decord(name, frame_index=None, rotation=False):
    reader = decord.VideoReader(name, num_threads=1)
    if frame_index is None:
        frame_index = list(range(len(reader)))
    video = reader.get_batch(frame_index).asnumpy()
    if len(video.shape) == 3:
        video = np.stack([np.broadcast_to(frame[..., None], (*frame.shape, 3)) for frame in video])
    if video.shape[-1] == 4:
        video = video[..., :3]
    if rotation:
        video = np.flip(np.transpose(video, (0, 2, 1, 3)), axis=2)
    return video, frame_index


def read_dataset_statistics(statistics_path: str, default_value=1e-4) -> dict:
    with open(statistics_path, "r", encoding="utf-8") as file:
        dataset_stats = json.load(file)

    state_right_mean = np.array(dataset_stats["state_right"]["mean"])
    state_right_std = np.array(dataset_stats["state_right"]["std"])
    action_right_mean = np.array(dataset_stats["action_right"]["mean"])
    action_right_std = np.array(dataset_stats["action_right"]["std"])

    if "state_left" in dataset_stats:
        state_left_mean = np.array(dataset_stats["state_left"]["mean"])
        state_left_std = np.array(dataset_stats["state_left"]["std"])
        action_left_mean = np.array(dataset_stats["action_left"]["mean"])
        action_left_std = np.array(dataset_stats["action_left"]["std"])
    else:
        state_left_mean = np.full_like(state_right_mean, default_value)
        state_left_std = np.full_like(state_right_std, default_value)
        action_left_mean = np.full_like(action_right_mean, default_value)
        action_left_std = np.full_like(action_right_std, default_value)

    return {
        "state_right_mean": state_right_mean,
        "state_right_std": state_right_std,
        "action_right_mean": action_right_mean,
        "action_right_std": action_right_std,
        "state_left_mean": state_left_mean,
        "state_left_std": state_left_std,
        "action_left_mean": action_left_mean,
        "action_left_std": action_left_std,
    }


class GaussianNormalizer:
    def __init__(self, data_statistics: dict):
        self.state_mean = np.concatenate([data_statistics["state_left_mean"], data_statistics["state_right_mean"]])
        self.state_std = np.concatenate([data_statistics["state_left_std"], data_statistics["state_right_std"]])
        self.action_mean = np.concatenate([data_statistics["action_left_mean"], data_statistics["action_right_mean"]])
        self.action_std = np.concatenate([data_statistics["action_left_std"], data_statistics["action_right_std"]])

    def normalize_state(self, state: np.ndarray, epsilon=1e-7) -> np.ndarray:
        return (state - self.state_mean) / (self.state_std + epsilon)

    def normalize_action(self, action: np.ndarray, epsilon=1e-7) -> np.ndarray:
        return (action - self.action_mean) / (self.action_std + epsilon)


def calculate_fov(h, w, intrinsics):
    hfov = 2 * np.arctan(w / (2 * intrinsics[0][0]))
    vfov = 2 * np.arctan(h / (2 * intrinsics[1][1]))
    return np.array([hfov, vfov], dtype=np.float32)


def compute_new_intrinsics_resize(original_intrinsics, resize_size):
    original_fx = original_intrinsics[0][0]
    original_fy = original_intrinsics[1][1]
    original_cx = original_intrinsics[0][2]
    original_cy = original_intrinsics[1][2]
    h, w = resize_size
    scale_x = w / (2 * original_cx)
    scale_y = h / (2 * original_cy)
    return np.array(
        [
            [original_fx * scale_x, 0, original_cx * scale_x],
            [0, original_fy * scale_y, original_cy * scale_y],
            [0, 0, 1],
        ],
        dtype=np.float32,
    )


def pad_state_human(state, state_mask, action_dim, state_dim, unified_state_dim):
    current_state = torch.tensor(state, dtype=torch.float32)
    current_state_mask = torch.tensor(state_mask, dtype=torch.bool)
    expanded_state_mask = current_state_mask.repeat_interleave(state_dim // 2)
    current_state_masked = current_state * expanded_state_mask.to(current_state.dtype)

    padded_state = torch.zeros(unified_state_dim, dtype=current_state.dtype)
    padded_mask = torch.zeros(unified_state_dim, dtype=torch.bool)
    padded_state[: action_dim // 2] = current_state_masked[: action_dim // 2].clone()
    padded_mask[: action_dim // 2] = expanded_state_mask[: action_dim // 2].clone()
    padded_state[action_dim // 2 : action_dim] = current_state_masked[
        state_dim // 2 : state_dim // 2 + action_dim // 2
    ].clone()
    padded_mask[action_dim // 2 : action_dim] = expanded_state_mask[
        state_dim // 2 : state_dim // 2 + action_dim // 2
    ].clone()
    return padded_state, padded_mask


def pad_action(actions=None, action_mask=None, action_dim=None, unified_action_dim=None):
    action_mask = torch.tensor(action_mask, dtype=torch.bool)
    mask_left = action_mask[:, 0].unsqueeze(1).expand(-1, action_dim // 2)
    mask_right = action_mask[:, 1].unsqueeze(1).expand(-1, action_dim // 2)
    expanded_action_mask = torch.cat((mask_left, mask_right), dim=1)

    if actions is None:
        padding_mask = torch.zeros((action_mask.shape[0], unified_action_dim - action_dim), dtype=torch.bool)
        return None, torch.cat((expanded_action_mask, padding_mask), dim=1)

    actions = torch.tensor(actions, dtype=torch.float32)
    padding = torch.zeros((actions.shape[0], unified_action_dim - action_dim), dtype=actions.dtype)
    actions_padded = torch.cat((actions * expanded_action_mask.to(actions.dtype), padding), dim=1)
    action_mask_padded = torch.cat((expanded_action_mask, padding.bool()), dim=1)
    return actions_padded, action_mask_padded


class VitraEpisodeCore:
    """Minimal local replacement for the VITRA episode core used by Motus datasets."""

    def __init__(
        self,
        video_root,
        annotation_file,
        label_folder,
        statistics_path=None,
        action_type="angle",
        use_rel=False,
        upsample_factor=1.0,
        clip_len=2000,
        rel_mode="step",
        **_,
    ):
        self.video_root = video_root
        annotation_dict = np.load(annotation_file, allow_pickle=True)
        self.label_folder = label_folder
        self.index_frame_pair = annotation_dict["index_frame_pair"].copy()
        self.index_to_episode_id = annotation_dict["index_to_episode_id"].copy()
        self.num_valid_frames = len(self.index_frame_pair)
        self.data_statistics = read_dataset_statistics(statistics_path) if statistics_path else None
        self.global_data_statistics = None
        self.clip_len = clip_len
        self.action_type = action_type
        self.use_rel = use_rel
        self.upsample_factor = upsample_factor
        self.rel_mode = rel_mode

    def __len__(self):
        return self.num_valid_frames

    @staticmethod
    @functools.lru_cache(maxsize=256)
    def _load_episode_npy(episode_path: str):
        return np.load(episode_path, allow_pickle=True).item()

    def _load_or_cache_episode(self, episode_id):
        epi_path = os.path.join(self.label_folder, episode_id + ".npy")
        epi = self._load_episode_npy(epi_path)
        extr = epi["extrinsics"]
        return epi, extr[:, :3, :3], extr[:, :3, 3]

    def _mat2euler(self, r_batch: np.ndarray) -> np.ndarray:
        return R.from_matrix(r_batch.reshape(-1, 3, 3)).as_euler("xyz", degrees=False)

    def _window_indices(self, frame_id, past, future, start, end):
        win = np.arange(-past, future + 1) + frame_id
        oob = (win < start) | (win > end)
        return win.clip(start, end), oob

    def _resolve_video_path(self, dataset_name: str = None, video_name: str = None, part_index: int = None) -> str:
        if dataset_name in ("Ego4D", "EgoExo4D"):
            suffix = f"_part{part_index + 1}.mp4" if self.clip_len is not None else ".mp4"
            return os.path.join(self.video_root, video_name + suffix)
        if dataset_name == "epic":
            suffix = f"_part{part_index + 1}.mp4" if self.clip_len is not None else ".MP4"
            return os.path.join(self.video_root, video_name + suffix)
        if dataset_name == "somethingsomethingv2":
            suffix = f"_part{part_index + 1}.mp4" if self.clip_len is not None else ".webm"
            return os.path.join(self.video_root, video_name + suffix)
        raise ValueError(f"Unknown VITRA dataset prefix {dataset_name}")

    def _prepare_side_window(self, side_dict, r_w2c, t_w2c, idx_window, idx_anchor, *, oob=None, start=None, end=None, **_):
        idx_window_extend = np.append(idx_window, np.clip(idx_window[-1] + 1, start, end))
        kept_extend = side_dict["kept_frames"][idx_window_extend].astype(bool)
        r_mano_extend = side_dict["global_orient_worldspace"][idx_window_extend]
        t_mano_extend = side_dict["transl_worldspace"][idx_window_extend]
        hand_p_extend = side_dict["hand_pose"][idx_window_extend]
        joints_worldspace_extend = side_dict["joints_worldspace"][idx_window_extend]

        if oob is not None:
            oob_indices = np.where(oob)[0]
            if len(oob_indices) > 0:
                kept_extend[oob_indices] = False
                if idx_window[-1] + 1 > end:
                    kept_extend[-1] = False

        if not np.all(kept_extend):
            identity = np.eye(3, dtype=hand_p_extend.dtype)
            hand_p_extend[~kept_extend] = np.broadcast_to(identity, (hand_p_extend.shape[1], 3, 3))
            r_mano_extend[~kept_extend] = identity

        r_cam_extend = r_w2c[idx_anchor] @ r_mano_extend
        t_cam_extend = (r_w2c[idx_anchor] @ t_mano_extend[..., None])[..., 0] + t_w2c[idx_anchor]
        pose_euler_extend = R.from_matrix(hand_p_extend.reshape(-1, 3, 3)).as_euler("xyz", degrees=False).reshape(-1, 45)
        joints_manospace_extend = (
            r_mano_extend.transpose(0, 2, 1)
            @ (joints_worldspace_extend.transpose(0, 2, 1) - t_mano_extend[..., None])
        ).transpose(0, 2, 1)

        return {
            "R_cam": r_cam_extend[:-1].astype(np.float32),
            "t_cam": t_cam_extend[:-1].astype(np.float32),
            "pose_euler": pose_euler_extend[:-1].astype(np.float32),
            "hand_P": hand_p_extend[:-1].astype(np.float32),
            "joints_manospace": joints_manospace_extend[:-1].astype(np.float32),
            "kept": kept_extend[:-1],
            "R_cam_next": r_cam_extend[1:].astype(np.float32),
            "t_cam_next": t_cam_extend[1:].astype(np.float32),
            "pose_euler_next": pose_euler_extend[1:].astype(np.float32),
            "hand_P_next": hand_p_extend[1:].astype(np.float32),
            "joints_manospace_next": joints_manospace_extend[1:].astype(np.float32),
            "kept_next": kept_extend[1:],
        }

    def _make_action_window_vec(self, win, anchor_idx: int, *, rel_mode="step", action_type="angle"):
        r_cur, t_cur = win["R_cam"], win["t_cam"]
        r_nxt, t_nxt = win["R_cam_next"], win["t_cam_next"]
        p_cur, p_nxt = win["hand_P"], win["hand_P_next"]
        pose_next = win["pose_euler_next"]
        kpoints_root_next = win["joints_manospace_next"]
        kept, kept_n = win["kept"], win["kept_next"]
        w = len(t_cur)

        abs_next = kpoints_root_next.reshape(w, -1) if action_type == "keypoints" else pose_next
        action_abs = np.concatenate([t_nxt, self._mat2euler(r_nxt), abs_next], axis=-1).astype(np.float32)

        if rel_mode == "step":
            t_rel = t_nxt - t_cur
            r_rel = r_nxt @ r_cur.transpose(0, 2, 1)
            p_rel = np.matmul(p_nxt, p_cur.transpose(0, 1, 3, 2))
            valid = kept & kept_n
        elif rel_mode == "anchor":
            t_rel = t_nxt - t_cur[anchor_idx]
            r_rel = r_nxt @ r_cur[anchor_idx].T
            p_rel = np.matmul(p_nxt, p_cur[anchor_idx].transpose(0, 2, 1))
            valid = kept_n & kept[anchor_idx]
        else:
            raise ValueError('rel_mode must be "step" or "anchor"')

        pose_rel = R.from_matrix(p_rel.reshape(-1, 3, 3)).as_euler("xyz", False).reshape(w, 45)
        action_rel = np.concatenate([t_rel, self._mat2euler(r_rel), pose_rel], axis=-1).astype(np.float32)
        action_abs[~valid] = 0.0
        action_rel[~valid] = 0.0
        return action_abs, action_rel, valid

    def _pack_state(self, r_cam, t_cam, pose_euler, idx):
        return np.concatenate([t_cam[idx], self._mat2euler(r_cam[idx][None, ...])[0], pose_euler[idx]])

    def _find_matching_texts(self, text_list, frame_id):
        matches, ranges = [], []
        for text, (start_frame, end_frame) in text_list:
            if start_frame <= frame_id < end_frame:
                matches.append(text)
                ranges.append((start_frame, end_frame))
        return matches, ranges

    def _random_select_text(self, text, text_rephrase, hand_type, clip_idx):
        text_list = [text]
        if text_rephrase and isinstance(text_rephrase[hand_type][clip_idx][0], list):
            text_list.extend(text_rephrase[hand_type][clip_idx][0])
        selected = random.choice(text_list).strip()
        return selected if selected.endswith(".") else selected + "."

    def _build_instruction(self, main_type, text_clip, text_rephrase, idx_win, oob, epi_len, frame_id, action_past_window_size, action_future_window_size):
        sub_type = "right" if main_type == "left" else "left"
        main_text = self._random_select_text(text_clip[main_type][0][0], text_rephrase, main_type, clip_idx=0)
        sub_text_list = text_clip[sub_type]
        has_sub_text = len(sub_text_list) > 0
        sub_oob, sub_idx_win = oob, idx_win
        sub_text, sub_win = "None.", (0, epi_len)

        if has_sub_text:
            matching_texts, matching_ranges = self._find_matching_texts(sub_text_list, frame_id)
            if matching_texts:
                selected_idx = random.randrange(len(matching_texts))
                sub_win = matching_ranges[selected_idx]
                sub_idx_win, sub_oob = self._window_indices(
                    frame_id, action_past_window_size, action_future_window_size, sub_win[0], sub_win[1] - 1
                )
                sub_text = self._random_select_text(matching_texts[selected_idx].strip(), text_rephrase, sub_type, selected_idx)

        is_main_left = main_type == "left"
        idx_win_left = idx_win if is_main_left else sub_idx_win
        idx_win_right = sub_idx_win if is_main_left else idx_win
        oob_left = oob if is_main_left else sub_oob
        oob_right = sub_oob if is_main_left else oob
        text_left = main_text if is_main_left else sub_text
        text_right = sub_text if is_main_left else main_text
        start_left = 0 if is_main_left else (sub_win[0] if has_sub_text else 0)
        start_right = (sub_win[0] if has_sub_text else 0) if is_main_left else 0
        end_left = epi_len - 1 if is_main_left else (sub_win[1] - 1 if has_sub_text else epi_len - 1)
        end_right = (sub_win[1] - 1 if has_sub_text else epi_len - 1) if is_main_left else epi_len - 1
        return (
            f"Left hand: {text_left} Right hand: {text_right}",
            idx_win_left,
            oob_left,
            idx_win_right,
            oob_right,
            start_left,
            end_left,
            start_right,
            end_right,
        )

    def get_item_frame(self, episode_id, frame_id, action_past_window_size=0, action_future_window_size=0, rel_mode="step", load_images=False, **_):
        epi, r_w2c, t_w2c = self._load_or_cache_episode(episode_id)
        total_frames = len(epi["extrinsics"])
        idx_win, oob = self._window_indices(frame_id, action_past_window_size, action_future_window_size, 0, total_frames - 1)
        main_type = epi["anno_type"]
        instruction, idx_win_left, oob_left, idx_win_right, oob_right, start_left, end_left, start_right, end_right = self._build_instruction(
            main_type, epi["text"], epi.get("text_rephrase"), idx_win, oob, total_frames, frame_id, action_past_window_size, action_future_window_size
        )
        win_left = self._prepare_side_window(epi["left"], r_w2c, t_w2c, idx_win_left, frame_id, oob=oob_left, start=start_left, end=end_left)
        win_right = self._prepare_side_window(epi["right"], r_w2c, t_w2c, idx_win_right, frame_id, oob=oob_right, start=start_right, end=end_right)
        idx_center = action_past_window_size

        abs_l, rel_l, msk_l = self._make_action_window_vec(win_left, idx_center, rel_mode=rel_mode, action_type=self.action_type)
        abs_r, rel_r, msk_r = self._make_action_window_vec(win_right, idx_center, rel_mode=rel_mode, action_type=self.action_type)
        action_abs = np.concatenate([abs_l, abs_r], axis=1)
        action_rel = np.concatenate([rel_l, rel_r], axis=1)
        action_mask = np.stack([msk_l, msk_r], axis=1)

        cur_l = self._pack_state(win_left["R_cam"], win_left["t_cam"], win_left["pose_euler"], idx_center)
        cur_r = self._pack_state(win_right["R_cam"], win_right["t_cam"], win_right["pose_euler"], idx_center)
        current_state = np.concatenate([cur_l, epi["left"]["beta"], cur_r, epi["right"]["beta"]])
        current_state_mask = np.array([win_left["kept"][idx_center], win_right["kept"][idx_center]])

        rel_l_part = action_rel[:, : action_rel.shape[1] // 2]
        rel_r_part = action_rel[:, action_rel.shape[1] // 2 :]
        abs_l_part = action_abs[:, : action_abs.shape[1] // 2]
        abs_r_part = action_abs[:, action_abs.shape[1] // 2 :]
        action_list = action_rel if self.use_rel else np.concatenate(
            [rel_l_part[:, :6], abs_l_part[:, 6:], rel_r_part[:, :6], abs_r_part[:, 6:]], axis=1
        )

        intrinsics = epi["intrinsics"]
        new_intrinsics = compute_new_intrinsics_resize(intrinsics, (2 * intrinsics[1, 2], 2 * intrinsics[0, 2]))
        result = {
            "instruction": instruction,
            "action_list": action_list,
            "action_mask": action_mask,
            "current_state": current_state.astype(np.float32),
            "current_state_mask": current_state_mask,
            "fov": calculate_fov(2 * new_intrinsics[1][2], 2 * new_intrinsics[0][2], new_intrinsics),
            "intrinsics": new_intrinsics,
        }
        if load_images:
            raise NotImplementedError("VitraEpisodeCore image loading is handled by Motus dataset wrappers.")
        return result

    def set_global_data_statistics(self, global_data_statistics):
        self.global_data_statistics = global_data_statistics
        self.gaussian_normalizer = GaussianNormalizer(global_data_statistics)

    def transform_trajectory(self, sample_dict: dict = None, normalization: bool = True):
        action_np = sample_dict["action_list"]
        state_np = sample_dict["current_state"]
        action_dim = action_np.shape[1]
        state_dim = state_np.shape[0]
        if normalization:
            action_np = self.gaussian_normalizer.normalize_action(action_np)
            state_np = self.gaussian_normalizer.normalize_state(state_np)
        sample_dict["current_state"], sample_dict["current_state_mask"] = pad_state_human(
            state_np, sample_dict["current_state_mask"], action_dim, state_dim, StateFeature.ALL_FEATURES[1]
        )
        sample_dict["action_list"], sample_dict["action_mask"] = pad_action(
            action_np, sample_dict["action_mask"], action_dim, ActionFeature.ALL_FEATURES[1]
        )
        return sample_dict

# Latent Action Normalization
# Provides Gaussian normalization for latent-encoded actions and states

from __future__ import annotations
from typing import Dict, Optional
from pathlib import Path
import json
import logging

import torch
import numpy as np

logger = logging.getLogger(__name__)


class LatentNormalizer:
    """
    Gaussian normalizer for latent actions and states.

    Supports two modes:
    1. Per-dimension normalization (default, mode="per_dim"):
       normalized = (x - mean) / std
       WARNING: Can cause issues if std varies significantly across dimensions.

    2. Global normalization (mode="global"):
       Uses global mean/std computed across all dimensions.
       More stable when per-dimension std varies widely.

    3. Center only (mode="center"):
       Only subtract mean, don't divide by std.
       Useful when latent space already has reasonable scale.

    Args:
        action_mean: Mean for action normalization [latent_dim]
        action_std: Std for action normalization [latent_dim]
        state_mean: Mean for state normalization [latent_dim]
        state_std: Std for state normalization [latent_dim]
        mode: Normalization mode ("per_dim", "global", or "center")
    """

    def __init__(
        self,
        action_mean: np.ndarray,
        action_std: np.ndarray,
        state_mean: np.ndarray,
        state_std: np.ndarray,
        mode: str = "global",
    ) -> None:
        self.action_mean = torch.from_numpy(action_mean).float()
        self.action_std = torch.from_numpy(action_std).float()
        self.state_mean = torch.from_numpy(state_mean).float()
        self.state_std = torch.from_numpy(state_std).float()
        self.mode = mode

        # Avoid division by zero for per-dim mode
        self.action_std_per_dim = torch.clamp(self.action_std, min=1e-6)
        self.state_std_per_dim = torch.clamp(self.state_std, min=1e-6)

        # Compute global statistics (single value across all dimensions)
        self.action_mean_global = self.action_mean.mean()
        self.action_std_global = self.action_std.mean()  # Use mean of per-dim stds
        self.state_mean_global = self.state_mean.mean()
        self.state_std_global = self.state_std.mean()

        # Ensure global std is reasonable
        self.action_std_global = max(self.action_std_global.item(), 0.1)
        self.state_std_global = max(self.state_std_global.item(), 0.1)

        logger = logging.getLogger(__name__)
        logger.info(f"LatentNormalizer mode={mode}, "
                    f"action_global_mean={self.action_mean_global:.4f}, "
                    f"action_global_std={self.action_std_global:.4f}")

    def normalize_action(self, action: torch.Tensor) -> torch.Tensor:
        """
        Normalize action tensor.

        Args:
            action: [..., latent_dim] action tensor

        Returns:
            Normalized action tensor
        """
        if self.mode == "per_dim":
            return (action - self.action_mean.to(action.device)) / self.action_std_per_dim.to(action.device)
        elif self.mode == "global":
            return (action - self.action_mean_global.to(action.device)) / self.action_std_global
        else:  # center only
            return action - self.action_mean.to(action.device)

    def denormalize_action(self, action: torch.Tensor) -> torch.Tensor:
        """
        Denormalize action tensor.

        Args:
            action: [..., latent_dim] normalized action tensor

        Returns:
            Denormalized action tensor
        """
        if self.mode == "per_dim":
            return action * self.action_std_per_dim.to(action.device) + self.action_mean.to(action.device)
        elif self.mode == "global":
            return action * self.action_std_global + self.action_mean_global.to(action.device)
        else:  # center only
            return action + self.action_mean.to(action.device)

    def normalize_state(self, state: torch.Tensor) -> torch.Tensor:
        """
        Normalize state tensor.

        Args:
            state: [..., latent_dim] state tensor

        Returns:
            Normalized state tensor
        """
        if self.mode == "per_dim":
            return (state - self.state_mean.to(state.device)) / self.state_std_per_dim.to(state.device)
        elif self.mode == "global":
            return (state - self.state_mean_global.to(state.device)) / self.state_std_global
        else:  # center only
            return state - self.state_mean.to(state.device)

    def denormalize_state(self, state: torch.Tensor) -> torch.Tensor:
        """
        Denormalize state tensor.

        Args:
            state: [..., latent_dim] normalized state tensor

        Returns:
            Denormalized state tensor
        """
        if self.mode == "per_dim":
            return state * self.state_std_per_dim.to(state.device) + self.state_mean.to(state.device)
        elif self.mode == "global":
            return state * self.state_std_global + self.state_mean_global.to(state.device)
        else:  # center only
            return state + self.state_mean.to(state.device)

    @classmethod
    def from_json(cls, json_path: str, mode: str = "global") -> "LatentNormalizer":
        """
        Load normalizer from JSON file.

        Args:
            json_path: Path to statistics JSON file
            mode: Normalization mode ("per_dim", "global", or "center")

        Returns:
            LatentNormalizer instance
        """
        json_path = Path(json_path)
        if not json_path.exists():
            raise FileNotFoundError(f"Statistics file not found: {json_path}")

        with open(json_path, "r") as f:
            stats = json.load(f)

        return cls(
            action_mean=np.array(stats["action_mean"], dtype=np.float32),
            action_std=np.array(stats["action_std"], dtype=np.float32),
            state_mean=np.array(stats["state_mean"], dtype=np.float32),
            state_std=np.array(stats["state_std"], dtype=np.float32),
            mode=mode,
        )

    def to(self, device: str) -> "LatentNormalizer":
        """Move normalizer tensors to device."""
        self.action_mean = self.action_mean.to(device)
        self.action_std = self.action_std.to(device)
        self.state_mean = self.state_mean.to(device)
        self.state_std = self.state_std.to(device)
        return self

"""
EgoVerse (ARIA / human subset) Dataset Adapter for MotusV2.

Supports the ``unified_eef_camera_delta_wrist16`` action mode, producing exactly
the same 16-D action space as the VITRA / EgoDex / Xperience human datasets:

    16D = [left_delta_xyz_cam(3), left_delta_rotvec_cam(3), 0, 0,
           right_delta_xyz_cam(3), right_delta_rotvec_cam(3), 0, 0]

Data layout::

    <data_root>/aria/<timestamp>.mp4        # front_1 video (30 fps)
    <data_root>/aria/<timestamp>.zarr/      # Zarr v3 store (needs zarr>=3)

Zarr root ``attributes``::

    embodiment    : "human_bimanual" | "human_right_arm" | "human_left_arm"
    total_frames  : int   -- authoritative frame count (arrays may be zero-padded longer)
    fps           : 30
    task_name / task_description
    features      : {name: {dtype, shape}}
    intrinsics    : {"front_1": 3x4 K}   -- fx, fy, cx, cy for the 640x480 image

Per-frame arrays used here (all world frame, quaternion order configurable)::

    left.obs_wrist_pose  / right.obs_wrist_pose : (N, 7) [x,y,z, qx,qy,qz,qw]
    left.obs_ee_pose     / right.obs_ee_pose    : (N, 7) same layout
    obs_head_pose                               : (N, 7) same layout

COORDINATE FRAMES (verified on real ARIA episodes; see the fill-in section of
docs/prompt_verify_EgoVerse_OpenAoE.md):

  * Hand poses and the head pose are absolute poses in a shared world frame,
    so this feeds the shared unified-EEF math directly (like EgoDex):
        R_w_e, t_w_e  <- hand pose        (EEF -> world)
        R_w_c, t_w_c  <- head/camera pose (camera -> world), at the anchor frame
  * ``obs_head_pose`` IS the pose of the ``front_1`` camera in world: with the
    correct quaternion order the wrist lands at positive camera-frame depth
    (0.15-0.42 m) and inside the image, so the head->camera offset is identity.
    A non-identity rigid offset can still be supplied via ``head_to_camera``
    (4x4, head->camera):  T_w_cam = T_w_head @ T_head_cam.
  * QUATERNION ORDER IS ``wxyz`` (scalar first), NOT the ``xyzw`` the field
    documentation states.  Decoding as ``xyzw`` puts the wrist behind the
    camera on ~100% of frames (negative depth); ``wxyz`` gives positive depth
    and in-frame projections.  ``quat_order`` stays configurable but defaults
    to the verified ``wxyz``.
  * ``obs_wrist_pose`` and ``obs_keypoints`` share the same world frame;
    ``obs_keypoints[0]`` sits ~1 cm from the wrist origin (different anatomical
    landmark).  ``obs_ee_pose`` is the same hand offset by ~7.5 cm and ~87 deg
    (EVA tool frame) -- prefer ``obs_wrist_pose`` to match EgoDex / VITRA.

  The unified-EEF action itself never uses the intrinsics; the intrinsics are
  only needed by the offline re-projection tool.

ZARR DEPENDENCY / POSE CACHE: these are Zarr v3 stores, which need ``zarr>=3``
and therefore Python >= 3.11.  Training environments on Python 3.10 cannot
install it, so ``tools/prepare_egoverse_pose_cache.py`` (run once in any
env that does have zarr) writes the few pose arrays out as small ``.npz``
sidecars.  When a sidecar is present this dataset reads it and never imports
zarr; video always comes from the mp4.

NOTE ON THE ``eva`` SUBSET: it is deliberately NOT supported here.  EVA episodes
publish ``extrinsics`` only for the two wrist cameras, so there is no
world-frame pose for ``front_1`` and therefore no reference camera for the
camera-frame delta representation.  See the verification prompt doc.
"""

import hashlib
import io
import json
import logging
import os
import random
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.utils.data as data
from scipy.spatial.transform import Rotation as R

from data.utils.image_utils import load_video_frames, resize_with_padding, tensor_to_pil
from data.human.unified_eef_action import (
    compute_unified_eef_action_sequence,
    compute_unified_eef_state_from_poses,
    UNIFIED_EEF_ACTION_DIM,
    UNIFIED_EEF_STATE_DIM,
)

logger = logging.getLogger(__name__)

HUMAN_EMBODIMENTS = ("human_bimanual", "human_right_arm", "human_left_arm")


def _get_shared_t5_encoder(wan_path: str, t5_text_len: int, t5_device: str):
    from data import get_global_t5_encoder
    return get_global_t5_encoder(wan_path, t5_text_len, t5_device)


def quat_to_rotmat(quat: np.ndarray, order: str = "xyzw") -> np.ndarray:
    """Convert a quaternion array to rotation matrices.

    Args:
        quat: (..., 4) quaternion in ``order``.
        order: "xyzw" (scipy native) or "wxyz" (scalar first).
    Returns:
        (..., 3, 3) rotation matrices.
    """
    q = np.asarray(quat, dtype=np.float64)
    if order == "wxyz":
        q = np.roll(q, -1, axis=-1)  # -> xyzw
    elif order != "xyzw":
        raise ValueError(f"quat_order must be 'xyzw' or 'wxyz', got '{order}'")
    flat = q.reshape(-1, 4)
    norms = np.linalg.norm(flat, axis=1, keepdims=True)
    safe = norms[:, 0] > 1e-8
    flat = np.where(safe[:, None], flat / np.where(norms > 1e-8, norms, 1.0), np.array([0.0, 0.0, 0.0, 1.0]))
    return R.from_quat(flat).as_matrix().reshape(q.shape[:-1] + (3, 3))


def _pose7_to_Rt(pose7: np.ndarray, quat_order: str) -> Tuple[np.ndarray, np.ndarray]:
    """(N,7) [xyz, quat] -> (R (N,3,3), t (N,3)).  Frame semantics: pose -> world."""
    pose7 = np.asarray(pose7, dtype=np.float64)
    t = pose7[..., 0:3]
    Rm = quat_to_rotmat(pose7[..., 3:7], order=quat_order)
    return Rm, t


class EgoVerseMotusDataset(data.Dataset):
    """EgoVerse ARIA (human) adapter producing Motus-compatible unified-EEF samples.

    action_mode="unified_eef_camera_delta_wrist16":
        action_sequence: [F, 16], initial_state: [16], action_valid_mask: [F, 16]
    """

    def __init__(
        self,
        dataset_dir: str,
        *,
        num_video_frames: int = 8,
        video_size: Tuple[int, int] = (384, 320),
        action_mode: str = "unified_eef_camera_delta_wrist16",
        # Subset / episode selection
        subset: str = "aria",
        # Which hand pose stream to use as the EEF frame.
        hand_pose_key: str = "obs_wrist_pose",
        # Camera / convention configuration (see module docstring).
        camera_key: str = "front_1",
        head_pose_key: str = "obs_head_pose",
        # VERIFIED on real data: ARIA obs_*_pose quaternions are scalar-first.
        quat_order: str = "wxyz",
        head_to_camera: Optional[List[List[float]]] = None,
        # Optional dir of .npz pose sidecars (see prepare_egoverse_pose_cache.py).
        # Defaults to looking for "<episode>.poses.npz" next to the .zarr store.
        pose_cache_dir: Optional[str] = None,
        require_pose_cache: bool = False,
        # Frame sampling
        frame_stride: int = 1,
        # Video source: "mp4" (default) or "zarr" (decode JPEG from images.<camera_key>)
        video_source: str = "mp4",
        # VLM
        vlm_checkpoint_path: Optional[str] = None,
        # T5 embedding
        t5_mode: str = "disk_cache",
        wan_path: str = "./pretrained_models",
        t5_cache_dir: str = "./t5_cache_egoverse",
        t5_text_len: int = 512,
        t5_device: str = "cuda",
        # Indexing
        max_episodes: Optional[int] = None,
        index_cache_path: Optional[str] = None,
        max_attempts: int = 8,
        val: bool = False,
        **kwargs: Any,
    ) -> None:
        super().__init__()
        self.dataset_dir = str(dataset_dir)
        self.num_video_frames = int(num_video_frames)
        self.video_size = video_size
        self.action_mode = action_mode
        self.subset = subset
        self.hand_pose_key = hand_pose_key
        self.camera_key = camera_key
        self.head_pose_key = head_pose_key
        self.quat_order = quat_order
        self.pose_cache_dir = str(pose_cache_dir) if pose_cache_dir else None
        self.require_pose_cache = bool(require_pose_cache)
        self.frame_stride = max(1, int(frame_stride))
        self.video_source = video_source
        self.max_attempts = int(max_attempts)
        self.val = val

        if self.action_mode != "unified_eef_camera_delta_wrist16":
            raise ValueError(
                f"EgoVerse dataset currently only supports "
                f"action_mode='unified_eef_camera_delta_wrist16', got '{self.action_mode}'"
            )
        if self.subset != "aria":
            raise NotImplementedError(
                "Only the 'aria' (human) subset supports unified EEF: EVA episodes "
                "publish extrinsics for the wrist cameras only, so there is no "
                "world-frame pose for front_1 to use as the reference camera."
            )
        if self.hand_pose_key not in ("obs_wrist_pose", "obs_ee_pose"):
            raise ValueError(f"hand_pose_key must be 'obs_wrist_pose' or 'obs_ee_pose', got '{self.hand_pose_key}'")
        if self.video_source not in ("mp4", "zarr"):
            raise ValueError(f"video_source must be 'mp4' or 'zarr', got '{self.video_source}'")

        # T_head_cam: rigid head->camera offset, identity by default.
        if head_to_camera is None:
            self.T_head_cam = np.eye(4, dtype=np.float64)
        else:
            self.T_head_cam = np.asarray(head_to_camera, dtype=np.float64).reshape(4, 4)
            if not np.allclose(self.T_head_cam[3], [0, 0, 0, 1], atol=1e-6):
                raise ValueError("head_to_camera must be a homogeneous 4x4 with last row [0,0,0,1]")

        self._action_dim = UNIFIED_EEF_ACTION_DIM  # 16
        self._state_dim = UNIFIED_EEF_STATE_DIM    # 16

        self._skipped_missing_files = 0
        self._skipped_bad_embodiment = 0
        self._skipped_too_short = 0
        self._skipped_other_error = 0
        self._skipped_other_error_samples: List[str] = []
        self._skipped_no_hand_data = 0
        self._skipped_nan_hand = 0
        self._total_samples = 0

        self.episodes: List[Dict[str, Any]] = []
        self._index_cache_path = index_cache_path
        self._index_episodes(max_episodes)

        if len(self.episodes) == 0:
            raise RuntimeError(f"No valid EgoVerse episodes found in {dataset_dir}/{self.subset}")

        logger.info(
            f"[EgoVerse->Motus] Indexed {len(self.episodes)} '{self.subset}' episodes "
            f"(skipped missing={self._skipped_missing_files}, "
            f"embodiment={self._skipped_bad_embodiment}, too_short={self._skipped_too_short}, "
            f"other={self._skipped_other_error}), hand_pose_key={self.hand_pose_key}, "
            f"quat_order={self.quat_order}, video_source={self.video_source}, "
            f"frame_stride={self.frame_stride}"
        )
        for p in self._skipped_other_error_samples[:3]:
            logger.warning(f"[EgoVerse->Motus] Example indexing error: {p}")

        self.vlm_processor = None
        if vlm_checkpoint_path:
            from transformers import AutoProcessor
            self.vlm_processor = AutoProcessor.from_pretrained(vlm_checkpoint_path)

        self.t5_mode = t5_mode
        self.t5_cache_dir = Path(t5_cache_dir)
        self.t5_cache_dir.mkdir(parents=True, exist_ok=True)
        self.t5_encoder = None
        self.t5_device = t5_device
        if self.t5_mode == "disk_cache":
            self.t5_encoder = _get_shared_t5_encoder(wan_path, t5_text_len, t5_device)
        elif self.t5_mode == "none":
            logger.warning("[EgoVerse->Motus] t5_mode=none: language_embedding will be zeros")

    # ------------------------------------------------------------------
    # Zarr helpers (zarr>=3 is required for these Zarr v3 stores; imported
    # lazily so the module can be imported in environments without it)
    # ------------------------------------------------------------------
    @staticmethod
    def _zarr():
        try:
            import zarr
        except ImportError as exc:
            raise ImportError(
                "EgoVerse requires the 'zarr' package (>=3, Zarr v3 stores). "
                "Install with: pip install 'zarr>=3'"
            ) from exc
        return zarr

    @staticmethod
    def _read_root_attrs(zarr_path: str) -> Dict[str, Any]:
        """Read the root group's attributes straight from zarr.json (no zarr dep)."""
        with open(os.path.join(zarr_path, "zarr.json"), "r", encoding="utf-8") as f:
            meta = json.load(f)
        return meta.get("attributes", {}) or {}

    def _read_array(self, zarr_path: str, name: str) -> np.ndarray:
        zarr = self._zarr()
        arr = zarr.open(os.path.join(zarr_path, name), mode="r")
        return np.asarray(arr[:])

    # ------------------------------------------------------------------
    # Episode indexing
    # ------------------------------------------------------------------
    def _default_index_cache_path(self) -> Path:
        key = f"{self.dataset_dir}:{self.subset}:{self.num_video_frames}:{self.frame_stride}:{self.video_source}"
        h = hashlib.md5(key.encode()).hexdigest()[:12]
        return Path(self.dataset_dir) / f".egoverse_index_cache_{h}.json"

    def _min_required_frames(self) -> int:
        return (self.num_video_frames * self.frame_stride) + 1

    def _index_episodes(self, max_episodes: Optional[int]):
        cache_path = Path(self._index_cache_path) if self._index_cache_path else self._default_index_cache_path()
        if cache_path.exists():
            try:
                with open(cache_path, "r") as f:
                    cached = json.load(f)
                if (cached.get("min_frames") == self._min_required_frames()
                        and cached.get("subset") == self.subset
                        and cached.get("video_source") == self.video_source):
                    self.episodes = cached["episodes"]
                    if max_episodes is not None and len(self.episodes) > max_episodes:
                        self.episodes = self.episodes[:max_episodes]
                    logger.info(f"[EgoVerse->Motus] Loaded {len(self.episodes)} episodes from cache {cache_path}")
                    return
                logger.info("[EgoVerse->Motus] Index cache config mismatch, re-indexing...")
            except Exception as e:
                logger.warning(f"[EgoVerse->Motus] Failed to read index cache ({e}), re-indexing...")

        subset_dir = Path(self.dataset_dir) / self.subset
        if not subset_dir.is_dir():
            # Allow pointing dataset_dir straight at the subset directory.
            subset_dir = Path(self.dataset_dir)
        if not subset_dir.is_dir():
            raise RuntimeError(f"EgoVerse subset dir does not exist: {subset_dir}")

        for zarr_dir in sorted(subset_dir.glob("*.zarr")):
            try:
                name = zarr_dir.name[: -len(".zarr")]
                mp4_path = subset_dir / f"{name}.mp4"
                if self.video_source == "mp4" and not mp4_path.exists():
                    # The known bad episode (no mp4, total_frames=0) lands here.
                    self._skipped_missing_files += 1
                    continue

                attrs = self._read_root_attrs(str(zarr_dir))
                embodiment = str(attrs.get("embodiment", ""))
                if embodiment not in HUMAN_EMBODIMENTS:
                    # e.g. the stale 'aria_bimanual' episode, or an eva_* store.
                    self._skipped_bad_embodiment += 1
                    continue

                total_frames = int(attrs.get("total_frames", 0) or 0)
                if total_frames < self._min_required_frames():
                    self._skipped_too_short += 1
                    continue

                features = attrs.get("features", {}) or {}
                has_left = f"left.{self.hand_pose_key}" in features
                has_right = f"right.{self.hand_pose_key}" in features
                if not (has_left or has_right):
                    self._skipped_missing_files += 1
                    continue
                if self.head_pose_key not in features:
                    # Without a camera pose there is no reference frame.
                    self._skipped_missing_files += 1
                    continue

                self.episodes.append({
                    "zarr_path": str(zarr_dir),
                    "mp4_path": str(mp4_path),
                    "episode_name": name,
                    "embodiment": embodiment,
                    "has_left": bool(has_left),
                    "has_right": bool(has_right),
                    "n_frames": total_frames,
                    "task_name": str(attrs.get("task_name", "egoverse")),
                    "task_description": str(attrs.get("task_description", "")),
                })
                if max_episodes is not None and len(self.episodes) >= max_episodes:
                    break
            except Exception as e:
                self._skipped_other_error += 1
                if len(self._skipped_other_error_samples) < 3:
                    self._skipped_other_error_samples.append(f"{zarr_dir}: {e}")

        if self.episodes:
            try:
                with open(cache_path, "w") as f:
                    json.dump({
                        "min_frames": self._min_required_frames(),
                        "subset": self.subset,
                        "video_source": self.video_source,
                        "episodes": self.episodes,
                    }, f)
                logger.info(f"[EgoVerse->Motus] Cached {len(self.episodes)} episodes to {cache_path}")
            except Exception as e:
                logger.warning(f"[EgoVerse->Motus] Failed to write index cache: {e}")

    # ------------------------------------------------------------------
    # Pose reading
    # ------------------------------------------------------------------
    def pose_cache_path(self, ep: Dict[str, Any]) -> Path:
        """Location of the ``.npz`` pose sidecar for an episode."""
        name = f"{ep['episode_name']}.poses.npz"
        if self.pose_cache_dir:
            return Path(self.pose_cache_dir) / name
        return Path(ep["zarr_path"]).parent / name

    def read_episode_poses(self, ep: Dict[str, Any]) -> Dict[str, Optional[np.ndarray]]:
        """Read the head pose and available hand poses, truncated to total_frames.

        Prefers the ``.npz`` pose sidecar (written by
        tools/prepare_egoverse_pose_cache.py) so that training environments
        without ``zarr>=3`` still work; falls back to reading the Zarr store.

        Returns raw (N,7) arrays; frame semantics are resolved in
        :meth:`compute_unified_eef_from_poses`.
        """
        n = int(ep["n_frames"])
        cache = self.pose_cache_path(ep)
        if cache.exists():
            with np.load(cache) as f:
                def _get(key: str) -> Optional[np.ndarray]:
                    if key not in f.files:
                        return None
                    arr = np.asarray(f[key])
                    return arr[:n] if arr.size else None
                head = _get("head_pose")
                if head is None:
                    raise KeyError(f"pose cache {cache} is missing 'head_pose'")
                return {"head_pose": head, "left_pose": _get("left_pose"), "right_pose": _get("right_pose")}

        if self.require_pose_cache:
            raise FileNotFoundError(
                f"require_pose_cache=True but no pose sidecar at {cache}. "
                f"Generate it with tools/prepare_egoverse_pose_cache.py."
            )

        zp = ep["zarr_path"]
        head = self._read_array(zp, self.head_pose_key)[:n]
        left = self._read_array(zp, f"left.{self.hand_pose_key}")[:n] if ep["has_left"] else None
        right = self._read_array(zp, f"right.{self.hand_pose_key}")[:n] if ep["has_right"] else None
        return {"head_pose": head, "left_pose": left, "right_pose": right}

    # ------------------------------------------------------------------
    # Unified EEF (pure geometry; separated from I/O so it is unit-testable)
    # ------------------------------------------------------------------
    def compute_unified_eef_from_poses(
        self,
        head_pose: np.ndarray,
        left_pose: Optional[np.ndarray],
        right_pose: Optional[np.ndarray],
        window_indices: np.ndarray,
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray, Dict[str, np.ndarray]]:
        """Build the unified-EEF action/state for one window from raw (N,7) poses.

        Args:
            head_pose: (N,7) head/camera pose in world  [xyz, quat].
            left_pose / right_pose: (N,7) hand pose in world, or None if absent.
            window_indices: (W,) frame indices, W = num_video_frames + 1,
                already clipped/padded; index 0 is the anchor.

        Returns:
            actions (F,16), state (16,), action_masks (F,16), debug dict.
        """
        W = len(window_indices)
        assert W == self.num_video_frames + 1, (W, self.num_video_frames)

        # --- camera (head) pose over the window: camera -> world ---
        head_win = np.asarray(head_pose, dtype=np.float64)[window_indices]      # (W,7)
        R_w_head, t_w_head = _pose7_to_Rt(head_win, self.quat_order)            # head -> world
        head_finite = (np.all(np.isfinite(head_win), axis=1)
                       & (np.linalg.norm(head_win[:, 3:7], axis=1) > 1e-6))

        # Apply the optional fixed head->camera offset: T_w_cam = T_w_head @ T_head_cam
        R_hc = self.T_head_cam[:3, :3]
        t_hc = self.T_head_cam[:3, 3]
        R_w_c_win = R_w_head @ R_hc                                             # (W,3,3) cam -> world
        t_w_c_win = np.einsum("wij,j->wi", R_w_head, t_hc) + t_w_head           # (W,3)

        if not bool(head_finite[0]):
            raise ValueError("non-finite head/camera pose at anchor frame")

        # --- hand poses over the window: EEF -> world ---
        def _hand(pose: Optional[np.ndarray]):
            if pose is None:
                return (np.tile(np.eye(3), (W, 1, 1)), np.zeros((W, 3)), np.zeros(W, dtype=bool))
            p = np.asarray(pose, dtype=np.float64)[window_indices]              # (W,7)
            finite = np.all(np.isfinite(p), axis=1)
            qnorm = np.linalg.norm(p[:, 3:7], axis=1)
            valid = finite & (qnorm > 1e-6) & head_finite
            # Zero-filled padding rows in the store are all-zero -> invalid.
            nonzero = np.any(np.abs(p) > 1e-12, axis=1)
            valid = valid & nonzero
            p_safe = np.where(valid[:, None], p, np.array([0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0]))
            Rm, t = _pose7_to_Rt(p_safe, self.quat_order)
            return Rm, t, valid

        left_R_w, left_t_w, left_valid = _hand(left_pose)
        right_R_w, right_t_w, right_valid = _hand(right_pose)

        if not (bool(left_valid[0]) or bool(right_valid[0])):
            raise ValueError("no valid hand at anchor frame")

        # Reference camera = anchor-frame camera (camera -> world).
        R_w_c = R_w_c_win[0]
        t_w_c = t_w_c_win[0]

        actions, action_masks = compute_unified_eef_action_sequence(
            R_w_e_left=left_R_w,
            t_w_e_left=left_t_w,
            R_w_e_right=right_R_w,
            t_w_e_right=right_t_w,
            R_w_c=R_w_c,
            left_valid=left_valid,
            right_valid=right_valid,
            num_action_frames=self.num_video_frames,
        )
        if not np.any(action_masks):
            raise ValueError("no valid hand action pairs in window")

        state, _ = compute_unified_eef_state_from_poses(
            R_w_e_left=left_R_w[0],
            t_w_e_left=left_t_w[0],
            R_w_e_right=right_R_w[0],
            t_w_e_right=right_t_w[0],
            R_w_c=R_w_c,
            t_w_c=t_w_c,
            left_valid=bool(left_valid[0]),
            right_valid=bool(right_valid[0]),
        )

        if not np.all(np.isfinite(actions)) or not np.all(np.isfinite(state)):
            raise ValueError("non-finite unified EEF action/state")

        debug = {
            "R_w_c_win": R_w_c_win, "t_w_c_win": t_w_c_win,
            "left_t_w_win": left_t_w, "right_t_w_win": right_t_w,
            "left_valid_win": left_valid, "right_valid_win": right_valid,
        }
        return actions, state, action_masks, debug

    def _extract_unified_eef_action_state(
        self, ep: Dict[str, Any], frame_start: int
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray, str]:
        self._total_samples += 1
        poses = self.read_episode_poses(ep)
        win = self._window_indices(ep, frame_start)
        try:
            actions, state, masks, _ = self.compute_unified_eef_from_poses(
                poses["head_pose"], poses["left_pose"], poses["right_pose"], win)
        except ValueError as e:
            msg = str(e)
            if "hand" in msg:
                self._skipped_no_hand_data += 1
            elif "non-finite" in msg:
                self._skipped_nan_hand += 1
            raise
        instruction = ep.get("task_description") or ep.get("task_name", "")
        return actions, state, masks, instruction

    # ------------------------------------------------------------------
    # Video
    # ------------------------------------------------------------------
    def _window_indices(self, ep: Dict[str, Any], frame_start: int) -> np.ndarray:
        n = int(ep["n_frames"])
        W = self.num_video_frames + 1
        return np.asarray([min(frame_start + i * self.frame_stride, n - 1) for i in range(W)], dtype=np.int64)

    def _load_frames_window(self, ep: Dict[str, Any], frame_start: int) -> torch.Tensor:
        idx = self._window_indices(ep, frame_start).tolist()
        if self.video_source == "mp4":
            return load_video_frames(ep["mp4_path"], idx, target_size=self.video_size)
        return self._load_frames_from_zarr(ep, idx)

    def _load_frames_from_zarr(self, ep: Dict[str, Any], indices: List[int]) -> torch.Tensor:
        """Decode JPEG frames stored in ``images.<camera_key>`` (variable-length bytes)."""
        from PIL import Image
        zarr = self._zarr()
        arr = zarr.open(os.path.join(ep["zarr_path"], f"images.{self.camera_key}"), mode="r")
        frames = []
        for i in indices:
            raw = arr[i:i + 1][0]
            if not isinstance(raw, (bytes, bytearray)):
                raw = bytes(np.asarray(raw).item())
            img = np.asarray(Image.open(io.BytesIO(raw)).convert("RGB"))
            frames.append(resize_with_padding(img, self.video_size))
        stacked = np.stack(frames, axis=0)
        return torch.from_numpy(stacked).permute(0, 3, 1, 2).float() / 255.0

    # ------------------------------------------------------------------
    # T5 embedding
    # ------------------------------------------------------------------
    @staticmethod
    def _hash_text(text: str) -> str:
        return hashlib.sha1(text.encode("utf-8")).hexdigest()

    def _get_t5_embedding(self, instruction: str) -> torch.Tensor:
        if self.t5_mode == "none":
            return torch.zeros((512, 4096), dtype=torch.float32)

        key = self._hash_text(instruction)
        path = self.t5_cache_dir / f"{key}.pt"
        if path.exists():
            return torch.load(path, map_location="cpu", weights_only=True).float()

        assert self.t5_encoder is not None
        out = self.t5_encoder([instruction], self.t5_device)
        if isinstance(out, list):
            emb = out[0]
        elif isinstance(out, torch.Tensor):
            emb = out.squeeze(0)
        else:
            raise TypeError(f"Unexpected T5 encoder output: {type(out)}")
        emb = emb.detach().to("cpu").float()

        tmp = self.t5_cache_dir / f".tmp_{key}_{os.getpid()}.pt"
        torch.save(emb, tmp)
        os.replace(tmp, path)
        return emb

    # ------------------------------------------------------------------
    # Debug interface (offline tools only; not used by training)
    # ------------------------------------------------------------------
    def get_debug_sample(self, episode_index: int, frame_start: int,
                         load_video: bool = False) -> Dict[str, Any]:
        ep = self.episodes[episode_index]
        win = self._window_indices(ep, frame_start)
        poses = self.read_episode_poses(ep)

        action = state = mask = None
        error = None
        debug: Dict[str, np.ndarray] = {}
        try:
            action, state, mask, debug = self.compute_unified_eef_from_poses(
                poses["head_pose"], poses["left_pose"], poses["right_pose"], win)
        except Exception as e:
            error = f"{type(e).__name__}: {e}"

        attrs = self._read_root_attrs(ep["zarr_path"])
        K = None
        intr = (attrs.get("intrinsics") or {}).get(self.camera_key)
        if intr is not None:
            K_full = np.asarray(intr, dtype=np.float64)
            K = K_full[:3, :3]  # the stores publish a 3x4 [K|0]

        out: Dict[str, Any] = {
            "episode_index": int(episode_index),
            "frame_start": int(frame_start),
            "num_video_frames": int(self.num_video_frames),
            "frame_stride": int(self.frame_stride),
            "window_indices": win,
            "episode_name": ep["episode_name"],
            "embodiment": ep["embodiment"],
            "zarr_path": ep["zarr_path"],
            "video_path": ep["mp4_path"],
            "n_frames": int(ep["n_frames"]),
            "K": K,
            "R_w_c_win": debug.get("R_w_c_win"),
            "t_w_c_win": debug.get("t_w_c_win"),
            "R_w_c_ref": None if "R_w_c_win" not in debug else debug["R_w_c_win"][0].copy(),
            "t_w_c_ref": None if "t_w_c_win" not in debug else debug["t_w_c_win"][0].copy(),
            "left_wrist_world_win": debug.get("left_t_w_win"),
            "right_wrist_world_win": debug.get("right_t_w_win"),
            "left_valid_win": debug.get("left_valid_win"),
            "right_valid_win": debug.get("right_valid_win"),
            "action": None if action is None else np.asarray(action, dtype=np.float64),
            "state": None if state is None else np.asarray(state, dtype=np.float64),
            "action_valid_mask": None if mask is None else np.asarray(mask, dtype=bool),
            "error": error,
            "instruction": ep.get("task_description") or ep.get("task_name", ""),
        }
        if load_video:
            out["frames"] = self._load_frames_window(ep, frame_start)
        return out

    # ------------------------------------------------------------------
    # __len__ / __getitem__
    # ------------------------------------------------------------------
    def __len__(self) -> int:
        return len(self.episodes)

    @property
    def effective_len(self) -> int:
        return len(self.episodes)

    def get_dataset_stats(self) -> Dict[str, Any]:
        return {
            "total_samples": self._total_samples,
            "skipped_no_hand_data": self._skipped_no_hand_data,
            "skipped_nan_hand": self._skipped_nan_hand,
        }

    def __getitem__(self, idx: int) -> Optional[Dict[str, Any]]:
        for _ in range(self.max_attempts):
            try:
                ep = self.episodes[random.randint(0, len(self.episodes) - 1)]
                max_start = max(0, int(ep["n_frames"]) - self._min_required_frames())
                frame_start = random.randint(0, max_start)

                frames = self._load_frames_window(ep, frame_start)
                first_frame = frames[0]
                video_frames = frames[1:]

                action, state, action_valid_mask, instruction = \
                    self._extract_unified_eef_action_state(ep, frame_start)

                action_sequence = torch.tensor(action, dtype=torch.float32)
                current_state = torch.tensor(state, dtype=torch.float32)
                action_valid_mask_tensor = torch.tensor(action_valid_mask, dtype=torch.bool)

                language_embedding = self._get_t5_embedding(instruction)

                vlm_inputs = None
                if self.vlm_processor is not None:
                    from utils.vlm_utils import preprocess_vlm_messages
                    first_frame_pil = tensor_to_pil(first_frame)
                    vlm_inputs = preprocess_vlm_messages(instruction, first_frame_pil, self.vlm_processor)

                return {
                    "first_frame": first_frame,
                    "video_frames": video_frames,
                    "initial_state": current_state,
                    "action_sequence": action_sequence,
                    "language_embedding": language_embedding,
                    "vlm_inputs": vlm_inputs,
                    "action_valid_mask": action_valid_mask_tensor,
                    "task_name": ep.get("task_name", "egoverse"),
                }
            except Exception as e:
                logger.warning(f"[EgoVerse->Motus] sample retry due to error: {e}")
                continue
        return None

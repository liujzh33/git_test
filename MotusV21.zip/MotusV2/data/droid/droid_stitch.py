"""Shared camera-stitching geometry for DROID training and inference.

The WAN VAE has no prior on spatial layout, so the exact arrangement of cameras
in the stitched frame is part of the train/serve contract: a checkpoint served
with a different layout sees an image it was never trained on.  Keeping one
implementation here (rather than a copy in the dataset and another in
``robolab_motusv2/adapter.py``) makes drift impossible.

Layouts
-------
``t_shape`` (3 cameras, legacy default for DROID)
    top    : exterior_2, full width
    bottom : exterior_1 | wrist, half width each

``v_stack`` (2 cameras)
    top    : one exterior, full width
    bottom : wrist, full width

Why v_stack matters: the WAN VAE compresses 16x spatially and the transformer
patchifies 2x on top, so a 288x320 frame becomes a 9x10 = 90-token grid.  Under
t_shape the wrist camera occupies a quarter of that -- roughly 15 tokens, which
cannot resolve a graspable object.  Splitting two cameras evenly at 384x320
gives each ~60 tokens, and openpi's DROID policy likewise conditions on a single
exterior view plus the wrist rather than two exteriors.

Every camera is resized exactly once, straight into its slot; the older
two-step "resize to full frame, concatenate, resize back" path wasted ~75% of
the pixels on padding.
"""

from __future__ import annotations

import logging
from typing import List, Sequence, Tuple

import numpy as np

logger = logging.getLogger(__name__)

LAYOUTS = ("t_shape", "v_stack")

# Cameras each layout consumes, in slot order.
LAYOUT_SLOTS = {
    "t_shape": ("top", "bottom_left", "bottom_right"),
    "v_stack": ("top", "bottom"),
}


def _natural_h(h: int, w: int, target_w: int) -> int:
    """Height that keeps the aspect ratio when scaled to ``target_w``."""
    return int(round(h * target_w / w))


def plan_layout(
    layout: str,
    shapes: Sequence[Tuple[int, int]],
    video_height: int,
    video_width: int,
) -> dict:
    """Resolve slot rectangles for one frame.

    Args:
        layout: "t_shape" or "v_stack".
        shapes: native ``(H, W)`` of each camera, in slot order.
        video_height / video_width: stitched output size.

    Returns:
        ``{"natural_h", "pad_top", "rects"}`` where ``rects`` is a list of
        ``(y, x, h, w)`` in canvas coordinates, in slot order.
    """
    if layout not in LAYOUTS:
        raise ValueError(f"camera_layout must be one of {LAYOUTS}, got {layout!r}")
    expected = len(LAYOUT_SLOTS[layout])
    if len(shapes) != expected:
        raise ValueError(f"{layout} needs {expected} cameras, got {len(shapes)}")

    th, tw = video_height, video_width
    if layout == "t_shape":
        split_w = tw // 2
        right_w = tw - split_w
        top_h = _natural_h(shapes[0][0], shapes[0][1], tw)
        bot_h = max(_natural_h(shapes[1][0], shapes[1][1], split_w),
                    _natural_h(shapes[2][0], shapes[2][1], right_w))
        natural_h = top_h + bot_h
        clamped = natural_h > th
        if clamped:
            natural_h = th
            top_h = natural_h // 2
            bot_h = natural_h - top_h
        rects = [(0, 0, top_h, tw),
                 (top_h, 0, bot_h, split_w),
                 (top_h, split_w, bot_h, right_w)]
    else:  # v_stack
        top_h = _natural_h(shapes[0][0], shapes[0][1], tw)
        bot_h = _natural_h(shapes[1][0], shapes[1][1], tw)
        natural_h = top_h + bot_h
        clamped = natural_h > th
        if clamped:
            # Preserve the ratio between the two views while fitting the frame.
            natural_h = th
            top_h = max(1, round(th * top_h / (top_h + bot_h)))
            bot_h = natural_h - top_h
        rects = [(0, 0, top_h, tw), (top_h, 0, bot_h, tw)]

    return {
        "natural_h": natural_h,
        "pad_top": (th - natural_h) // 2,
        "rects": rects,
        "clamped": clamped,
    }


def stitch_frame(
    layout: str,
    images: Sequence[np.ndarray],
    video_height: int,
    video_width: int,
) -> np.ndarray:
    """Stitch one frame per camera into ``[video_height, video_width, 3]`` uint8.

    ``images`` are native-resolution HWC uint8 frames in slot order.
    """
    import cv2

    shapes = [(im.shape[0], im.shape[1]) for im in images]
    plan = plan_layout(layout, shapes, video_height, video_width)
    if plan["clamped"]:
        logger.warning(
            "%s natural height exceeds video_height=%d; clamping. Raise "
            "video_height (multiple of 32) to avoid squashing the cameras.",
            layout, video_height,
        )

    canvas = np.zeros((plan["natural_h"], video_width, 3), dtype=np.uint8)
    for im, (y, x, h, w) in zip(images, plan["rects"]):
        canvas[y:y + h, x:x + w, :] = cv2.resize(im, (w, h), interpolation=cv2.INTER_LINEAR)

    pad_top = plan["pad_top"]
    if pad_top > 0 or plan["natural_h"] < video_height:
        padded = np.zeros((video_height, video_width, 3), dtype=np.uint8)
        padded[pad_top:pad_top + plan["natural_h"], :, :] = canvas
        canvas = padded
    return canvas


def stitch_sequence(
    layout: str,
    raws: Sequence[np.ndarray],
    video_height: int,
    video_width: int,
) -> List[np.ndarray]:
    """Stitch ``[T, H, W, 3]`` uint8 stacks (one per camera) into T frames."""
    T = raws[0].shape[0]
    return [stitch_frame(layout, [r[i] for r in raws], video_height, video_width)
            for i in range(T)]


def describe_token_budget(layout: str, video_height: int, video_width: int,
                          vae_downsample: int = 16, patch: int = 2) -> str:
    """Human-readable token split, for logging the visual budget once at init.

    Undersized wrist views are the kind of thing that silently caps performance,
    so make the number visible rather than implicit in the geometry.
    """
    rows = video_height // vae_downsample // patch
    cols = video_width // vae_downsample // patch
    cam_h = _natural_h(180, 320, video_width)  # DROID cameras are 180x320
    parts = []
    if layout == "t_shape":
        parts.append(f"top~{round(rows * cam_h / video_height) * cols}")
        half = round(rows * (cam_h // 2) / video_height) * (cols // 2)
        parts += [f"bottom_left~{half}", f"wrist~{half}"]
    else:
        per = round(rows * cam_h / video_height) * cols
        parts += [f"exterior~{per}", f"wrist~{per}"]
    return f"{video_height}x{video_width} -> {rows}x{cols}={rows*cols} tokens/frame ({', '.join(parts)})"

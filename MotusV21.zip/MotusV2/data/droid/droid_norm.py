"""Shared DROID state/action normalization for training and inference.

Both ``DroidLeRobotDataset`` (training) and ``robolab_motusv2/adapter.py``
(RoboLab inference) import this module, so the forward and inverse transforms
can never drift apart.

Why this exists
---------------
DROID actions are absolute Panda joint angles.  Regressing them directly gives
the action expert a trivial shortcut: the state token already contains the
answer to within ~0.15 rad, so a flow-matching model converges to "copy the
state" and the visually-grounded part of the signal is worth <2% of the action
loss.  Empirically the resulting policy does not beat a hold-current-pose
baseline on its own training data.

The fix mirrors openpi's ``pi05_droid_jointpos`` recipe:

  1. Arm dims (0..6) are converted to a **delta** w.r.t. the state at the
     condition frame, which removes the shortcut entirely -- the delta carries
     no state information, so every predictable bit must come from vision and
     language.  The gripper dim (7) stays **absolute** because it is a binary
     command, not a displacement.
  2. State and (delta-)actions are **quantile normalized** to [-1, 1] with
     q01/q99, so the regression target is O(1) and comparable to the unit
     Gaussian noise it is mixed with during flow matching.

Values outside [q01, q99] are deliberately *not* clipped (openpi does the same).
Clipping would truncate exactly the fast reaching motions that matter most, and
would make the transform non-invertible; ~2% of values simply land outside
[-1, 1], which flow matching handles fine.

Stats are produced by ``scripts/compute_droid_norm_stats.py``.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Dict, Sequence

import numpy as np

logger = logging.getLogger(__name__)

# Arm dims are predicted as deltas; the gripper command stays absolute.
# Mirrors openpi's ``make_bool_mask(7, -1)`` for pi05_droid_jointpos.
DEFAULT_DELTA_MASK = (True,) * 7 + (False,)

STATS_VERSION = 1
_EPS = 1e-6


class DroidNormalizer:
    """Quantile normalizer for DROID 8-dim state / action chunks."""

    def __init__(
        self,
        state_q01: Sequence[float],
        state_q99: Sequence[float],
        action_q01: Sequence[float],
        action_q99: Sequence[float],
        delta_mask: Sequence[bool] = DEFAULT_DELTA_MASK,
    ) -> None:
        self.state_q01 = np.asarray(state_q01, dtype=np.float32)
        self.state_q99 = np.asarray(state_q99, dtype=np.float32)
        self.action_q01 = np.asarray(action_q01, dtype=np.float32)
        self.action_q99 = np.asarray(action_q99, dtype=np.float32)
        self.delta_mask = np.asarray(delta_mask, dtype=bool)

        for name, arr in (
            ("state_q01", self.state_q01), ("state_q99", self.state_q99),
            ("action_q01", self.action_q01), ("action_q99", self.action_q99),
            ("delta_mask", self.delta_mask),
        ):
            if arr.shape != (8,):
                raise ValueError(f"DROID {name} must have shape (8,), got {arr.shape}")

        self._state_range = np.maximum(self.state_q99 - self.state_q01, _EPS)
        self._action_range = np.maximum(self.action_q99 - self.action_q01, _EPS)
        if np.any(self.state_q99 - self.state_q01 <= 0) or np.any(self.action_q99 - self.action_q01 <= 0):
            raise ValueError("DROID norm stats contain a non-positive q99-q01 range")

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------
    @classmethod
    def from_stats_file(cls, path: str | Path) -> "DroidNormalizer":
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(
                f"DROID norm stats not found: {path}. Run "
                f"scripts/compute_droid_norm_stats.py to generate it."
            )
        with open(path, "r", encoding="utf-8") as f:
            stats = json.load(f)
        return cls.from_dict(stats)

    @classmethod
    def from_dict(cls, stats: Dict[str, Any]) -> "DroidNormalizer":
        version = int(stats.get("version", 0))
        if version != STATS_VERSION:
            raise ValueError(
                f"DROID norm stats version {version} != expected {STATS_VERSION}; "
                f"regenerate with scripts/compute_droid_norm_stats.py"
            )
        mask = stats.get("delta_mask", list(DEFAULT_DELTA_MASK))
        norm = cls(
            state_q01=stats["state"]["q01"],
            state_q99=stats["state"]["q99"],
            action_q01=stats["action"]["q01"],
            action_q99=stats["action"]["q99"],
            delta_mask=mask,
        )
        logger.info(
            "DROID normalizer loaded (delta_mask=%s, action q01=%s, q99=%s)",
            norm.delta_mask.tolist(),
            np.round(norm.action_q01, 4).tolist(),
            np.round(norm.action_q99, 4).tolist(),
        )
        return norm

    def to_dict(self) -> Dict[str, Any]:
        return {
            "version": STATS_VERSION,
            "delta_mask": self.delta_mask.tolist(),
            "state": {"q01": self.state_q01.tolist(), "q99": self.state_q99.tolist()},
            "action": {"q01": self.action_q01.tolist(), "q99": self.action_q99.tolist()},
        }

    # ------------------------------------------------------------------
    # State
    # ------------------------------------------------------------------
    def normalize_state(self, state: np.ndarray) -> np.ndarray:
        """[8] raw state -> [8] roughly in [-1, 1] (tails are not clipped)."""
        state = np.asarray(state, dtype=np.float32)
        return ((state - self.state_q01) / self._state_range * 2.0 - 1.0).astype(np.float32)

    # ------------------------------------------------------------------
    # Actions
    # ------------------------------------------------------------------
    def to_model_actions(self, actions: np.ndarray, state: np.ndarray) -> np.ndarray:
        """[T, 8] raw absolute actions -> [T, 8] normalized model targets.

        Masked (arm) dims become ``action[t] - state``; the gripper stays
        absolute.  Both are then quantile-normalized to [-1, 1].
        """
        actions = np.asarray(actions, dtype=np.float32)
        state = np.asarray(state, dtype=np.float32).reshape(-1)
        if actions.ndim != 2 or actions.shape[-1] != 8:
            raise ValueError(f"actions must be [T, 8], got {actions.shape}")
        if state.shape != (8,):
            raise ValueError(f"state must be [8], got {state.shape}")

        target = actions - np.where(self.delta_mask, state, 0.0)[None, :]
        return ((target - self.action_q01) / self._action_range * 2.0 - 1.0).astype(np.float32)

    def from_model_actions(self, norm_actions: np.ndarray, state: np.ndarray) -> np.ndarray:
        """[T, 8] normalized model output -> [T, 8] raw absolute actions."""
        norm_actions = np.asarray(norm_actions, dtype=np.float32)
        state = np.asarray(state, dtype=np.float32).reshape(-1)
        if norm_actions.ndim != 2 or norm_actions.shape[-1] != 8:
            raise ValueError(f"norm_actions must be [T, 8], got {norm_actions.shape}")
        if state.shape != (8,):
            raise ValueError(f"state must be [8], got {state.shape}")

        target = (norm_actions + 1.0) / 2.0 * self._action_range + self.action_q01
        return (target + np.where(self.delta_mask, state, 0.0)[None, :]).astype(np.float32)

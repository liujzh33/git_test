"""DROID LeRobot dataset adapter for MotusV2 post-training."""

from .droid_norm import DroidNormalizer

__all__ = ["DroidLeRobotDataset", "DroidNormalizer"]


def __getattr__(name):
    """Import the dataset lazily.

    ``DroidLeRobotDataset`` pulls in PyAV and OpenCV, which the RoboLab
    inference venv does not have.  Serving only needs ``droid_norm``, so keep
    importing it cheap while ``from data.droid import DroidLeRobotDataset``
    keeps working for training.
    """
    if name == "DroidLeRobotDataset":
        from .droid_lerobot_dataset import DroidLeRobotDataset

        return DroidLeRobotDataset
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

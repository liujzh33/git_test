"""
DROID (LeRobot v3.0) dataset adapter for MotusV2 post-training.

This dataset reads the HuggingFace LeRobot-format DROID dataset at
``/cache/wx1469573/data/droid1.0.1-lerobot`` and produces Motus-compatible
training samples (same contract as ``RobotWinTaskDataset`` /
``EgoDexMotusDataset``):

    first_frame:        [C, H, W]               (condition frame, stitched ext+wrist)
    video_frames:       [T, C, H, W]           (target video frames)
    initial_state:      [8]                   (7 joint pos + 1 gripper, qpos)
    action_sequence:    [chunk, 8]            (7 joint pos + 1 gripper, qpos)
    language_embedding: [S, 4096]           (UMT5-XXL for WAN cross-attn)
    vlm_inputs:         dict                 (Qwen3-VL processor output)
    task_name:          str

Action / state schema (aligned with RoboLab Pi0.5 ``pi05_droid_jointpos``):
    [panda_joint1..7, gripper]
    - 7-dim absolute joint position (radians)
    - 1-dim gripper in [0, 1]  (0=open, 1=close, thresholded at 0.5 at inference)

    With ``action_normalization=True`` (default, and required to reproduce the
    pi05_droid_jointpos recipe) the arm dims are converted to a delta w.r.t. the
    condition-frame state and both state and actions are quantile-normalized to
    [-1, 1].  See ``data/droid/droid_norm.py`` for why raw absolute qpos does not
    train: it lets the action expert solve the flow-matching objective by copying
    the state token, leaving <2% of the action loss for visual grounding.
    ``action_normalization=False`` reproduces the legacy raw-qpos behaviour.

Cameras (T-shape stitch into a single WAN video stream, default):
    observation.images.exterior_2_left  -> top          (full width)
    observation.images.exterior_1_left  -> bottom-left  (half width)
    observation.images.wrist_left       -> bottom-right (half width)
    Reconstructs the same T layout as ``LeRobotMotusDataset.has_three_cam``
    and the G1-D dataset, then resize-pads each sub-region once (no second
    resize), minimizing black borders.  Legacy ``vertical`` / ``horizontal``
    two-camera layouts are still supported via ``camera_layout``.

The dataset is self-contained: it reads parquet frames directly (pandas) and
decodes AV1 video with PyAV, so it does NOT depend on the ``lerobot`` runtime
library (which is heavy and not always available).
"""

import os
import json
import random
import logging
import hashlib
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.utils.data as data

# Video decoding via PyAV (AV1 codec, which decord cannot decode)
import av

# Image / VLM utils (shared with other datasets)
from data.utils.image_utils import resize_with_padding
from data.droid.droid_norm import DroidNormalizer
from data.droid.droid_filter import (
    DEFAULT_MIN_IDLE_LEN,
    DEFAULT_MIN_NON_IDLE_LEN,
    DEFAULT_TRIM_LAST_N,
    compute_keep_ranges,
    sampleable_windows,
)
from data.droid.droid_stitch import describe_token_budget, stitch_sequence
from utils.vlm_utils import preprocess_vlm_messages

logger = logging.getLogger(__name__)
warnings_filter = lambda *a, **kw: None  # placeholder; real filter set below
try:
    import warnings as _warnings
    _warnings.filterwarnings("ignore", category=FutureWarning, message=".*multichannel.*")
except Exception:
    pass


# Minimum valid mp4 file size.  The DROID distribution contains a few
# ~3.5 KB placeholder mp4 files (missing moov atom, undecodable by PyAV);
# real videos are hundreds of MB.  1 MB cleanly separates them.
_CORRUPT_VIDEO_MIN_BYTES = 1 * 1024 * 1024  # 1 MB


class _NoValidWindow(Exception):
    """Episode has no non-idle segment long enough for one action chunk."""


# ---------------------------------------------------------------------------
# PyAV video decoding helper
# ---------------------------------------------------------------------------
def _decode_video_frames_pyav(
    video_path: str,
    frame_indices: List[int],
    fps: float,
) -> np.ndarray:
    """Decode specific frames (by global index within the concatenated mp4).

    DROID videos are AV1-encoded and concatenated per parquet file (multiple
    episodes share one mp4).  ``frame_indices`` are global frame indices within
    the mp4, computed as ``start_frame + offset`` where ``start_frame`` comes
    from ``round(from_timestamp * fps)``.

    Returns ``[len(frame_indices), H, W, 3]`` uint8 RGB.  Frames are collected
    by presentation timestamp; seeking jumps to the nearest keyframe before the
    first requested index, then frames are decoded forward.
    """
    if not frame_indices:
        return np.zeros((0, 180, 320, 3), dtype=np.uint8)

    wanted = sorted(set(int(i) for i in frame_indices))
    first_wanted = wanted[0]
    last_wanted = wanted[-1]

    container = av.open(str(video_path))
    try:
        stream = container.streams.video[0]
        if stream is None:
            raise ValueError(f"No video stream in {video_path}")
        time_base = float(stream.time_base) if stream.time_base else 1.0

        # Seek to just before the first wanted frame (keyframe-based seek).
        seek_sec = max(0.0, first_wanted / float(fps) - 1.0 / float(fps))
        seek_pts = int(seek_sec / time_base)
        try:
            container.seek(seek_pts, stream=stream)
        except Exception:
            container.seek(0, stream=stream)

        idx_to_arr: Dict[int, np.ndarray] = {}
        last_arr = None
        for frame in container.decode(stream):
            pts = float(frame.pts) * time_base if frame.pts is not None else 0.0
            fidx = int(round(pts * float(fps)))
            if fidx > last_wanted + 2:
                break
            arr = frame.to_ndarray(format="rgb24")  # [H, W, 3] uint8
            last_arr = arr
            if fidx in wanted:
                idx_to_arr[fidx] = arr

        if last_arr is None:
            raise ValueError(f"Decoded 0 frames from {video_path}")
        out = []
        for i in frame_indices:
            if i in idx_to_arr:
                out.append(idx_to_arr[i])
            else:
                nearest = min(idx_to_arr.keys(), key=lambda k: abs(k - i)) if idx_to_arr else None
                out.append(idx_to_arr.get(nearest, last_arr) if nearest is not None else last_arr)
        return np.stack(out, axis=0)
    finally:
        container.close()


# ---------------------------------------------------------------------------
# Dataset
# ---------------------------------------------------------------------------
class DroidLeRobotDataset(data.Dataset):
    """MotusV2 dataset for the DROID LeRobot dataset (qpos joint-position action)."""

    # DROID info.json constants
    DROID_FPS = 15
    ACTION_DIM = 8   # 7 panda joints + 1 gripper
    STATE_DIM = 8

    # Fallback instruction used when an episode has no (non-empty)
    # language_instruction / _2 / _3.  MUST stay in sync with the T5 cache
    # prepopulation script, which has to encode this string too (otherwise
    # empty-instruction episodes trigger a cache miss in DataLoader workers).
    DEFAULT_INSTRUCTION = "manipulate the object"

    # Default camera selection for the T-shape layout (all three DROID cameras):
    #   top          : exterior_2_left  (over-shoulder, full width)
    #   bottom-left  : exterior_1_left  (over-shoulder, half width)
    #   bottom-right : wrist_left       (wrist camera, half width)
    TOP_CAM = "observation.images.exterior_2_left"
    BOTTOM_LEFT_CAM = "observation.images.exterior_1_left"
    BOTTOM_RIGHT_CAM = "observation.images.wrist_left"
    # Legacy two-camera defaults (kept for vertical/horizontal backward compat).
    EXTERIOR_KEY = "observation.images.exterior_1_left"
    WRIST_KEY = "observation.images.wrist_left"

    # Default location of the delta-action / state quantile stats produced by
    # scripts/compute_droid_norm_stats.py.
    DEFAULT_NORM_STATS_PATH = str(Path(__file__).resolve().parent / "droid_norm_stats.json")

    def __init__(
        self,
        dataset_dir: str,
        *,
        # Sampling parameters (match RoboTwin stage-2 defaults)
        num_video_frames: int = 8,
        video_size: Tuple[int, int] = (384, 320),
        global_downsample_rate: int = 1,
        video_action_freq_ratio: int = 2,
        max_episodes: Optional[int] = None,
        image_aug: bool = False,
        val: bool = False,
        # VLM processing
        vlm_checkpoint_path: Optional[str] = None,
        vlm_type: str = "qwen3_vl",
        # T5 embedding (UMT5-XXL for WAN cross-attention)
        t5_mode: str = "disk_cache",      # "disk_cache" or "none"
        wan_path: Optional[str] = None,
        t5_cache_dir: str = "./t5_cache_droid",
        t5_text_len: int = 512,
        t5_device: str = "cuda",
        # "float32" makes encoding batch-invariant so the cache can be built in
        # large batches while inference still encodes one at a time; "bfloat16"
        # is the legacy setting.  Must match at inference -- see
        # data/__init__.py::get_global_t5_encoder.
        t5_precision: str = "float32",
        allow_t5_cache_miss_zero: bool = False,
        # Instruction source
        instruction_field: str = "language_instruction",
        # Which cameras to use.  For the default T-shape layout, all three are
        # used (top / bottom-left / bottom-right).  For legacy vertical/horizontal
        # layouts only exterior_camera_key + wrist_camera_key are used.
        exterior_camera_key: str = EXTERIOR_KEY,
        wrist_camera_key: str = WRIST_KEY,
        top_camera_key: str = TOP_CAM,
        bottom_left_camera_key: str = BOTTOM_LEFT_CAM,
        bottom_right_camera_key: str = BOTTOM_RIGHT_CAM,
        # Camera stitching layout (see data/droid/droid_stitch.py):
        #   "v_stack"    -> one exterior on top, wrist on bottom, full width each.
        #                   Recommended: at 384x320 the wrist gets ~60 of the 120
        #                   visual tokens instead of ~15 under t_shape, and openpi's
        #                   DROID policy likewise uses one exterior + wrist.
        #   "t_shape"    -> exterior_2 full width on top, exterior_1 | wrist below.
        #                   Fits 3 cameras but starves the wrist.
        #   "vertical"   -> legacy 2-cam path with a wasteful double resize.
        #   "horizontal" -> legacy 2-cam path, side by side.
        # WAN VAE has no prior on spatial layout; training and inference must agree.
        camera_layout: str = "t_shape",
        # v_stack only.  During training the exterior view is drawn at random from
        # these keys (openpi does the same, which buys a free viewpoint
        # augmentation); inference always uses the first one.
        exterior_camera_keys: Optional[List[str]] = None,
        random_exterior: bool = True,
        # Action/state normalization.  True (default) = delta arm actions +
        # q01/q99 scaling to [-1, 1], matching openpi's pi05_droid_jointpos.
        # False = legacy raw absolute qpos (does not train, kept only so old
        # checkpoints can still be reproduced).
        action_normalization: bool = True,
        norm_stats_path: Optional[str] = None,
        # Data filtering, ported from openpi's DROID recipe.
        #   require_success: keep only episodes flagged is_episode_successful.
        #   filter_idle: restrict condition-frame sampling to non-idle segments.
        require_success: bool = True,
        filter_idle: bool = True,
        idle_min_len: int = DEFAULT_MIN_IDLE_LEN,
        idle_min_non_idle_len: int = DEFAULT_MIN_NON_IDLE_LEN,
        idle_trim_last_n: int = DEFAULT_TRIM_LAST_N,
        **kwargs: Any,
    ) -> None:
        super().__init__()

        if camera_layout not in ("v_stack", "t_shape", "vertical", "horizontal"):
            raise ValueError(
                f"camera_layout must be 'v_stack', 't_shape', 'vertical', or "
                f"'horizontal', got {camera_layout!r}"
            )
        if camera_layout in ("vertical", "horizontal"):
            logger.warning(
                "camera_layout=%r uses the legacy two-step stitch, which resizes each "
                "camera to the full frame and then shrinks the concatenation back "
                "down -- about 75%% of the pixels end up black. Use 'v_stack' for a "
                "two-camera layout.", camera_layout,
            )
        self.camera_layout = camera_layout
        self.dataset_dir = str(dataset_dir)
        self.root = Path(dataset_dir)
        self.num_video_frames = int(num_video_frames)
        self.video_size = video_size
        self.global_downsample_rate = int(global_downsample_rate)
        self.video_action_freq_ratio = int(video_action_freq_ratio)
        self.action_chunk_size = self.num_video_frames * self.video_action_freq_ratio
        self.max_episodes = max_episodes
        # NOTE: image augmentation is not implemented for DROID. Accepting the
        # flag silently would suggest sim-transfer augmentation is active when
        # it is not, so reject it instead of pretending.
        if bool(image_aug) and not val:
            raise NotImplementedError(
                "image_aug is not implemented for the DROID dataset; set "
                "dataset.image_aug=false. (openpi applies random-resized-crop + "
                "colour jitter here, which is worth adding for sim transfer.)"
            )
        self.image_aug = False
        self.val = bool(val)
        self.instruction_field = instruction_field
        # v_stack: exterior views to draw from, plus the wrist.
        self.exterior_camera_keys = list(exterior_camera_keys or
                                         [self.EXTERIOR_KEY, self.TOP_CAM])
        self.random_exterior = bool(random_exterior) and not val
        # Legacy two-camera keys (vertical/horizontal).
        self.exterior_camera_key = exterior_camera_key
        self.wrist_camera_key = wrist_camera_key
        # Three-camera keys (t_shape).
        self.top_camera_key = top_camera_key
        self.bottom_left_camera_key = bottom_left_camera_key
        self.bottom_right_camera_key = bottom_right_camera_key

        # Load info.json (fps, features)
        self.fps = self.DROID_FPS
        info_path = self.root / "meta" / "info.json"
        if info_path.exists():
            try:
                with open(info_path, "r") as f:
                    info = json.load(f)
                self.fps = float(info.get("fps", self.DROID_FPS))
            except Exception:
                pass
        self.action_dim = self.ACTION_DIM
        self.state_dim = self.STATE_DIM

        # Action/state normalization (shared with the RoboLab inference adapter
        # via data/droid/droid_norm.py so the two can never drift apart).
        self.action_normalization = bool(action_normalization)
        self.norm_stats_path = str(norm_stats_path or self.DEFAULT_NORM_STATS_PATH)
        self.normalizer: Optional[DroidNormalizer] = None
        if self.action_normalization:
            self.normalizer = DroidNormalizer.from_stats_file(self.norm_stats_path)
            logger.info(f"DROID action normalization ON (stats: {self.norm_stats_path})")
        else:
            logger.warning(
                "DROID action_normalization=False: training on raw absolute qpos. "
                "The action expert can solve this by copying the state token, which "
                "collapses visual grounding -- only use this to reproduce old runs."
            )

        # Data filtering (openpi DROID recipe; see data/droid/droid_filter.py).
        self.require_success = bool(require_success)
        self.filter_idle = bool(filter_idle)
        self.idle_min_len = int(idle_min_len)
        self.idle_min_non_idle_len = int(idle_min_non_idle_len)
        self.idle_trim_last_n = int(idle_trim_last_n)
        # episode_index -> condition-frame windows, computed on first use.
        self._keep_window_cache: Dict[int, List[Tuple[int, int]]] = {}
        self._keep_window_order: List[int] = []
        self._keep_window_cache_max = 4096

        # Episode index (built from meta/episodes parquet)
        self.episodes: List[Dict[str, Any]] = []
        self._index_episodes()

        if len(self.episodes) == 0:
            cams = (self.top_camera_key, self.bottom_left_camera_key, self.bottom_right_camera_key) \
                if self.camera_layout == "t_shape" \
                else (self.exterior_camera_key, self.wrist_camera_key)
            raise RuntimeError(
                f"No valid DROID episodes found in {dataset_dir} "
                f"(checked meta/episodes, data/, and videos/ for {cams})"
            )
        logger.info(
            f"DroidLeRobotDataset: {len(self.episodes)} episodes indexed "
            f"(fps={self.fps}, chunk={self.action_chunk_size}, ds={self.global_downsample_rate})"
        )
        # An undersized wrist view silently caps how well the policy can grasp,
        # so state the visual budget rather than leaving it implicit.
        logger.info(
            f"DROID camera layout={self.camera_layout}: "
            f"{describe_token_budget(self.camera_layout, *self.video_size)}"
        )

        # Parquet DataFrame cache (LRU-ish: keep last N files)
        self._parquet_cache: Dict[Tuple[int, int], "pd.DataFrame"] = {}
        self._parquet_cache_order: List[Tuple[int, int]] = []
        self._parquet_cache_max = 8

        # VLM processor (Qwen3-VL), same pattern as RoboTwin / EgoDex
        self.vlm_processor = None
        self.vlm_type = vlm_type
        if vlm_checkpoint_path is not None:
            try:
                from transformers import AutoProcessor
                if self.vlm_type == "molmo2":
                    self.vlm_processor = AutoProcessor.from_pretrained(
                        vlm_checkpoint_path, trust_remote_code=True
                    )
                else:
                    self.vlm_processor = AutoProcessor.from_pretrained(vlm_checkpoint_path)
                logger.info(f"DROID VLM processor loaded from {vlm_checkpoint_path}")
            except Exception as e:
                logger.warning(f"Failed to load VLM processor from {vlm_checkpoint_path}: {e}")

        # T5 encoder (shared singleton, disk-cached per instruction hash)
        self.t5_mode = t5_mode
        self.t5_cache_dir = Path(t5_cache_dir)
        self.t5_cache_dir.mkdir(parents=True, exist_ok=True)
        self.t5_text_len = int(t5_text_len)
        self.t5_device = t5_device
        self.t5_precision = str(t5_precision)
        self.allow_t5_cache_miss_zero = bool(allow_t5_cache_miss_zero)
        self.wan_path = wan_path or os.environ.get("WAN_PATH") or os.environ.get("WAN_ROOT")
        self._t5_encoder = None
        if self.t5_mode == "disk_cache":
            if self.wan_path is None:
                if self.allow_t5_cache_miss_zero:
                    logger.warning(
                        "DROID t5_mode=disk_cache but wan_path is None; "
                        "T5 will be zero embeddings because "
                        "allow_t5_cache_miss_zero=True. Set dataset.params.wan_path."
                    )
                    self.t5_mode = "none"
                else:
                    raise ValueError(
                        "DROID t5_mode=disk_cache requires dataset.params.wan_path "
                        "or WAN_PATH/WAN_ROOT. Set t5_mode='none' or "
                        "allow_t5_cache_miss_zero=True explicitly to use zero embeddings."
                    )
        if self.t5_mode == "none":
            logger.warning("DROID t5_mode=none: language_embedding will be zeros (WAN T5 disabled)")

    # ------------------------------------------------------------------
    # Episode indexing
    # ------------------------------------------------------------------
    def _video_path(self, video_key: str, chunk_index: int, file_index: int) -> Path:
        return (
            self.root
            / "videos"
            / video_key
            / f"chunk-{chunk_index:03d}"
            / f"file-{file_index:03d}.mp4"
        )

    def _data_path(self, chunk_index: int, file_index: int) -> Path:
        return self.root / "data" / f"chunk-{chunk_index:03d}" / f"file-{file_index:03d}.parquet"

    def _index_episodes(self) -> None:
        import pandas as pd

        meta_dir = self.root / "meta" / "episodes"
        if not meta_dir.exists():
            raise FileNotFoundError(f"meta/episodes not found in {self.root}")
        ep_files = sorted(meta_dir.rglob("*.parquet"))
        if not ep_files:
            raise FileNotFoundError(f"No episode parquet files under {meta_dir}")

        # Pre-scan video files and skip corrupt/truncated mp4 files.
        # The DROID distribution contains a handful of ~3.5 KB placeholder mp4
        # files (missing moov atom) that PyAV cannot open.  Real videos are
        # hundreds of MB, so a 1 MB size threshold reliably separates them.
        # We cache results per (camera_key, file_path) to avoid re-stat'ing.
        corrupt_files: set = set()
        skipped_corrupt = 0
        skipped_failed = 0
        # is_episode_successful is constant within an episode, and meta/episodes
        # already carries its per-episode stats, so success filtering costs no
        # extra IO -- no need to touch the data parquets here.
        success_col = "stats/is_episode_successful/mean"
        success_col_missing = False

        def _is_successful(row) -> bool:
            nonlocal success_col_missing
            if success_col not in row.index:
                success_col_missing = True
                return True
            try:
                return float(np.asarray(row[success_col]).ravel()[0]) >= 0.5
            except (TypeError, ValueError, IndexError):
                success_col_missing = True
                return True

        def _is_valid_video(path: Path) -> bool:
            key = str(path)
            if key in corrupt_files:
                return False
            try:
                if not path.exists() or path.stat().st_size < _CORRUPT_VIDEO_MIN_BYTES:
                    corrupt_files.add(key)
                    return False
            except OSError:
                corrupt_files.add(key)
                return False
            return True

        all_eps: List[Dict[str, Any]] = []
        # Camera keys to index per episode, depending on layout.  v_stack indexes
        # every candidate exterior so one can be drawn per sample.
        if self.camera_layout == "v_stack":
            cam_keys = (*self.exterior_camera_keys, self.wrist_camera_key)
            n_ext = len(self.exterior_camera_keys)
            cam_fields = (*(f"ext{i}_video" for i in range(n_ext)), "wrist_video",
                          *(f"ext{i}_start_frame" for i in range(n_ext)), "wrist_start_frame")
        elif self.camera_layout == "t_shape":
            cam_keys = (self.top_camera_key, self.bottom_left_camera_key, self.bottom_right_camera_key)
            cam_fields = ("top_video", "bottom_left_video", "bottom_right_video",
                          "top_start_frame", "bottom_left_start_frame", "bottom_right_start_frame")
        else:
            cam_keys = (self.exterior_camera_key, self.wrist_camera_key)
            cam_fields = ("ext_video", "wrist_video", "ext_start_frame", "wrist_start_frame")
        for epf in ep_files:
            try:
                ep = pd.read_parquet(epf)
            except Exception as e:
                logger.warning(f"Failed to read episode meta {epf}: {e}")
                continue
            for _, row in ep.iterrows():
                if self.require_success and not _is_successful(row):
                    skipped_failed += 1
                    continue
                # Resolve each camera's video file + start frame for this episode.
                cam_paths: List[str] = []
                cam_starts: List[int] = []
                missing = False
                for cam in cam_keys:
                    chunk_idx = int(row[f"videos/{cam}/chunk_index"])
                    file_idx = int(row[f"videos/{cam}/file_index"])
                    from_ts = float(row[f"videos/{cam}/from_timestamp"])
                    vpath = self._video_path(cam, chunk_idx, file_idx)
                    if not vpath.exists() or not _is_valid_video(vpath):
                        missing = True
                        break
                    cam_paths.append(str(vpath))
                    cam_starts.append(int(round(from_ts * self.fps)))
                if missing:
                    skipped_corrupt += 1
                    continue
                data_chunk = int(row["data/chunk_index"])
                data_file = int(row["data/file_index"])
                data_path = self._data_path(data_chunk, data_file)
                if not data_path.exists():
                    continue
                length = int(row["length"])
                episode_index = int(row["episode_index"])
                ep_entry: Dict[str, Any] = {
                    "episode_index": episode_index,
                    "length": length,
                    "data_chunk": data_chunk,
                    "data_file": data_file,
                }
                # Map resolved cameras onto the layout-specific field names.
                for fname, vpath, start in zip(cam_fields[:len(cam_keys)], cam_paths, cam_starts):
                    ep_entry[fname] = vpath
                for fname, start in zip(cam_fields[len(cam_keys):], cam_starts):
                    ep_entry[fname] = start
                all_eps.append(ep_entry)

        if skipped_corrupt > 0:
            logger.info(
                f"DROID: skipped {skipped_corrupt} episodes with corrupt/truncated "
                f"video files ({len(corrupt_files)} unique bad mp4s)"
            )
        if self.require_success:
            if success_col_missing:
                logger.warning(
                    "DROID require_success=True but meta/episodes has no usable "
                    f"'{success_col}'; NO success filtering was applied."
                )
            else:
                logger.info(f"DROID: skipped {skipped_failed} episodes with is_episode_successful=False")

        if self.max_episodes is not None and self.max_episodes > 0:
            all_eps = all_eps[: int(self.max_episodes)]
        self.episodes = all_eps

    # ------------------------------------------------------------------
    # Parquet frame access
    # ------------------------------------------------------------------
    def _load_parquet_rows(self, data_chunk: int, data_file: int, episode_index: int) -> "pd.DataFrame":
        import pandas as pd
        key = (data_chunk, data_file)
        df = self._parquet_cache.get(key)
        if df is None:
            path = self._data_path(data_chunk, data_file)
            df = pd.read_parquet(path)
            self._parquet_cache[key] = df
            self._parquet_cache_order.append(key)
            if len(self._parquet_cache_order) > self._parquet_cache_max:
                old = self._parquet_cache_order.pop(0)
                self._parquet_cache.pop(old, None)
        sub = df[df["episode_index"] == episode_index]
        return sub.reset_index(drop=True)

    # ------------------------------------------------------------------
    # Sampling indices (same logic as RoboTwin / LeRobotMotusDataset)
    # ------------------------------------------------------------------
    def _condition_windows(self, episode_index: int, rows: "pd.DataFrame") -> Optional[List[Tuple[int, int]]]:
        """Valid condition-frame windows for this episode, or None if unfiltered.

        Cached per episode; ``rows`` comes from the already-loaded parquet, so
        this costs no extra IO.
        """
        if not self.filter_idle:
            return None
        cached = self._keep_window_cache.get(episode_index)
        if cached is not None:
            return cached
        if "action.joint_velocity" not in rows.columns:
            if not getattr(self, "_warned_no_jv", False):
                logger.warning(
                    "DROID filter_idle=True but 'action.joint_velocity' is absent; "
                    "idle filtering disabled."
                )
                self._warned_no_jv = True
            self.filter_idle = False
            return None
        jv = np.stack(rows["action.joint_velocity"].to_numpy()).astype(np.float32)
        keep = compute_keep_ranges(
            jv,
            min_idle_len=self.idle_min_len,
            min_non_idle_len=self.idle_min_non_idle_len,
            trim_last_n=self.idle_trim_last_n,
        )
        windows = sampleable_windows(keep, self.action_chunk_size * self.global_downsample_rate)
        self._keep_window_cache[episode_index] = windows
        self._keep_window_order.append(episode_index)
        if len(self._keep_window_order) > self._keep_window_cache_max:
            self._keep_window_cache.pop(self._keep_window_order.pop(0), None)
        return windows

    def _calculate_sampling_indices(
        self, total_frames: int, condition_windows: Optional[List[Tuple[int, int]]] = None
    ) -> Tuple[int, List[int], List[int]]:
        physical_chunk_size = self.action_chunk_size * self.global_downsample_rate
        max_condition_idx = total_frames - physical_chunk_size - 1
        if condition_windows is not None:
            # Draw uniformly over valid condition frames, not over windows, so
            # long moving segments are not under-sampled relative to short ones.
            spans = [(lo, min(hi, max_condition_idx + 1)) for lo, hi in condition_windows]
            spans = [(lo, hi) for lo, hi in spans if hi > lo]
            if not spans:
                raise _NoValidWindow(f"no non-idle window fits a {physical_chunk_size}-frame chunk")
            widths = [hi - lo for lo, hi in spans]
            lo, hi = random.choices(spans, weights=widths, k=1)[0]
            condition_frame_idx = random.randrange(lo, hi)
        elif max_condition_idx < 0:
            condition_frame_idx = 0
        else:
            condition_frame_idx = random.randint(0, max_condition_idx)
        action_indices = []
        for i in range(self.action_chunk_size):
            action_idx = condition_frame_idx + (i + 1) * self.global_downsample_rate
            action_indices.append(min(action_idx, total_frames - 1))
        video_indices = []
        for i in range(self.num_video_frames):
            action_step = (i + 1) * self.video_action_freq_ratio - 1
            if action_step < len(action_indices):
                video_indices.append(action_indices[action_step])
            else:
                video_indices.append(action_indices[-1])
        return condition_frame_idx, video_indices, action_indices

    # ------------------------------------------------------------------
    # T5 embedding (disk-cached, shared singleton encoder)
    # ------------------------------------------------------------------
    def _ensure_t5_encoder(self):
        if self._t5_encoder is not None:
            return self._t5_encoder
        if self.t5_mode != "disk_cache":
            return None
        if self.wan_path is None:
            return None
        from data import get_global_t5_encoder
        self._t5_encoder = get_global_t5_encoder(
            self.wan_path, self.t5_text_len, self.t5_device, self.t5_precision
        )
        return self._t5_encoder

    @staticmethod
    def _hash_text(text: str) -> str:
        return hashlib.sha1(text.encode("utf-8")).hexdigest()

    def _zero_t5_embedding(self) -> torch.Tensor:
        return torch.zeros((self.t5_text_len, 4096), dtype=torch.float32)

    def _validate_t5_embedding(self, emb: torch.Tensor, path: Path) -> torch.Tensor:
        """Return a [t5_text_len, 4096] float32 embedding from a cache file.

        Two on-disk layouts are accepted:
          * compact (current): the raw ``[num_tokens, 4096]`` encoder output, in
            bfloat16.  A typical instruction is ~12 tokens, so this is ~98 KB.
          * legacy: pre-padded ``[t5_text_len, 4096]`` float32, i.e. 8 MB each.
            Padding to 512 on disk inflated the cache to ~1 TB for DROID's 123k
            instructions and made cache writes, not the encoder, the bottleneck.

        Padding is re-applied here, so consumers see an unchanged contract.
        """
        if emb.ndim != 2 or emb.shape[1] != 4096:
            raise ValueError(
                f"DROID T5 cache file has shape {tuple(emb.shape)}, "
                f"expected [<={self.t5_text_len}, 4096]: {path}"
            )
        if emb.shape[0] > self.t5_text_len:
            raise ValueError(
                f"DROID T5 cache file has {emb.shape[0]} tokens, "
                f"more than t5_text_len={self.t5_text_len}: {path}"
            )
        emb = emb.float()
        if emb.shape[0] < self.t5_text_len:
            emb = torch.cat([emb, emb.new_zeros(self.t5_text_len - emb.shape[0], emb.shape[1])])
        return emb

    def _get_t5_embedding(self, instruction: str) -> torch.Tensor:
        if self.t5_mode == "none":
            return self._zero_t5_embedding()
        key = self._hash_text(instruction)
        path = self.t5_cache_dir / f"{key}.pt"
        if path.exists():
            try:
                return self._validate_t5_embedding(
                    torch.load(path, map_location="cpu", weights_only=True),
                    path,
                )
            except Exception as exc:
                raise RuntimeError(f"Failed to load DROID T5 cache file {path}") from exc
        # DataLoader worker processes cannot safely initialize the heavy T5
        # encoder (CUDA fork restriction).  Cache misses in workers are
        # correctness errors by default; pre-populate the cache before
        # multi-worker training.  A legacy zero fallback is available only
        # through allow_t5_cache_miss_zero=True.
        import multiprocessing
        if multiprocessing.current_process().name != "MainProcess":
            if self.allow_t5_cache_miss_zero:
                logger.warning(
                    "DROID T5 cache miss in worker; returning zeros because "
                    "allow_t5_cache_miss_zero=True (key=%s, cache=%s)",
                    key,
                    path,
                )
                return self._zero_t5_embedding()
            raise RuntimeError(
                "DROID T5 cache miss in DataLoader worker. Run "
                "scripts/prepopulate_droid_t5_cache.py before multi-worker "
                f"training, or set allow_t5_cache_miss_zero=True explicitly. "
                f"key={key}, cache={path}"
            )
        encoder = self._ensure_t5_encoder()
        if encoder is None:
            if self.allow_t5_cache_miss_zero:
                logger.warning(
                    "DROID T5 encoder unavailable; returning zeros because "
                    "allow_t5_cache_miss_zero=True"
                )
                return self._zero_t5_embedding()
            raise RuntimeError(
                "DROID t5_mode=disk_cache but no T5 encoder is available. "
                "Set dataset.params.wan_path/WAN_PATH correctly, use "
                "t5_mode='none', or set allow_t5_cache_miss_zero=True explicitly."
            )
        with torch.no_grad():
            out = encoder([instruction], self.t5_device)
        if isinstance(out, list):
            emb = out[0]
        elif isinstance(out, torch.Tensor):
            emb = out.squeeze(0)
        else:
            raise TypeError(f"Unexpected T5 encoder output: {type(out)}")
        if emb.ndim == 3 and emb.shape[0] == 1:
            emb = emb.squeeze(0)
        return self.write_t5_cache_entry(instruction, emb)

    def write_t5_cache_entry(self, instruction: str, emb: torch.Tensor) -> torch.Tensor:
        """Persist one encoder output and return it padded to the usual shape.

        Stored compactly: the raw ``[num_tokens, 4096]`` output in bfloat16, not
        padded to t5_text_len.  Zero padding is trivially reconstructible at load
        time, and writing it out made the cache ~85x larger than it needs to be
        (8 MB vs ~98 KB per instruction), which dominated prepopulation time on
        network storage.
        """
        emb = emb.detach().to("cpu")
        if emb.shape[0] > self.t5_text_len:
            emb = emb[: self.t5_text_len]
        # Round first, then both save and return the same tensor: returning the
        # un-rounded value would make the encoding run disagree with every later
        # cache hit. bfloat16 loses nothing the model can use -- it consumes the
        # embedding in bfloat16 regardless.
        emb = emb.to(torch.bfloat16)
        key = self._hash_text(instruction)
        path = self.t5_cache_dir / f"{key}.pt"
        tmp = self.t5_cache_dir / f".tmp_{key}_{os.getpid()}.pt"
        torch.save(emb, tmp)
        os.replace(tmp, path)
        return self._validate_t5_embedding(emb, path)

    def has_t5_cache_entry(self, instruction: str) -> bool:
        """Cheap existence check -- avoids loading the tensor just to skip it."""
        return (self.t5_cache_dir / f"{self._hash_text(instruction)}.pt").exists()

    # ------------------------------------------------------------------
    # Video decoding (stitched exterior + wrist)
    # ------------------------------------------------------------------
    def _decode_stacked_frames(self, video_path: str, start_frame: int, frame_offsets: List[int]) -> torch.Tensor:
        """Decode frames at ``start_frame + frame_offsets`` from one camera, return [T, C, H, W] in [0,1]."""
        if not frame_offsets:
            return torch.zeros((0, 3, self.video_size[0], self.video_size[1]))
        abs_indices = [int(start_frame + off) for off in frame_offsets]
        raw = _decode_video_frames_pyav(video_path, abs_indices, self.fps)  # [T, H, W, 3] uint8
        th, tw = self.video_size
        out = torch.zeros((len(frame_offsets), 3, th, tw), dtype=torch.float32)
        for i in range(len(frame_offsets)):
            arr = raw[i]  # [H, W, 3] uint8
            resized = resize_with_padding(arr, self.video_size)  # [th, tw, 3] uint8
            out[i] = torch.from_numpy(resized).permute(2, 0, 1).float() / 255.0
        return out

    def _decode_raw_frames(self, video_path: str, start_frame: int, frame_offsets: List[int]) -> np.ndarray:
        """Decode frames at ``start_frame + frame_offsets`` from one camera.

        Returns the RAW ``[T, H, W, 3]`` uint8 array at native camera resolution
        (no resize-pad).  Used by the T-shape stitcher, which resize-pads each
        camera directly into its sub-region to avoid a wasteful double resize.
        """
        if not frame_offsets:
            return np.zeros((0, 0, 0, 3), dtype=np.uint8)
        abs_indices = [int(start_frame + off) for off in frame_offsets]
        return _decode_video_frames_pyav(video_path, abs_indices, self.fps)  # [T, H, W, 3] uint8

    def _stitch_raw(self, raws: List[np.ndarray]) -> torch.Tensor:
        """Stitch one raw ``[T, H, W, 3]`` uint8 stack per camera into the frame.

        Geometry lives in ``data/droid/droid_stitch.py`` so that the RoboLab
        inference adapter lays the cameras out identically -- the WAN VAE has no
        layout prior, so a mismatch would be unrecoverable and silent.

        Returns ``[T, C, H, W]`` float in [0, 1] at ``video_size``.
        """
        th, tw = self.video_size
        frames = stitch_sequence(self.camera_layout, raws, th, tw)
        out = torch.zeros((len(frames), 3, th, tw), dtype=torch.float32)
        for i, canvas in enumerate(frames):
            out[i] = torch.from_numpy(canvas).permute(2, 0, 1).float() / 255.0
        return out


    def _stitch_ext_wrist(self, ext_frames: torch.Tensor, wrist_frames: torch.Tensor) -> torch.Tensor:
        """Stitch exterior + wrist frames, then resize-pad to ``video_size``.

        Layout:
            - ``vertical``:   exterior on top,    wrist on bottom  -> [C, 2*H, W]
            - ``horizontal``: exterior on left,   wrist on right   -> [C, H, 2*W]

        Inputs are [T, C, H, W] in [0,1] (each camera already resize-padded
        to ``video_size``).  Returns [T, C, H, W] at ``video_size``.
        """
        T = ext_frames.shape[0]
        c = ext_frames.shape[1]
        th, tw = self.video_size
        if self.camera_layout == "vertical":
            stacked = torch.zeros((T, c, th * 2, tw), dtype=ext_frames.dtype)
            stacked[:, :, :th, :] = ext_frames
            stacked[:, :, th:, :] = wrist_frames
        else:  # horizontal
            stacked = torch.zeros((T, c, th, tw * 2), dtype=ext_frames.dtype)
            stacked[:, :, :, :tw] = ext_frames
            stacked[:, :, :, tw:] = wrist_frames
        # Resize-pad each stacked frame back to video_size (preserves aspect ratio).
        # Inputs are float32 [0,1]; convert to uint8 for resize_with_padding (which
        # uses cv2.resize + zero-padding), then back to float [0,1].
        out = torch.zeros((T, c, th, tw), dtype=torch.float32)
        for i in range(T):
            arr = stacked[i].permute(1, 2, 0).cpu().numpy()  # [H', W', 3] float32 [0,1]
            arr_uint8 = (arr * 255.0).clip(0, 255).astype("uint8")
            resized = resize_with_padding(arr_uint8, self.video_size)  # [th, tw, 3] uint8
            out[i] = torch.from_numpy(resized).permute(2, 0, 1).float() / 255.0
        return out

    # ------------------------------------------------------------------
    # __len__ / __getitem__
    # ------------------------------------------------------------------
    def __len__(self) -> int:
        return len(self.episodes) * 10

    def _tensor_to_pil(self, frame_chw: torch.Tensor):
        from PIL import Image
        arr = (frame_chw.permute(1, 2, 0).cpu().numpy() * 255.0).clip(0, 255).astype("uint8")
        return Image.fromarray(arr)

    def __getitem__(self, idx: int) -> Optional[Dict[str, Any]]:
        max_attempts = 8
        for _ in range(max_attempts):
            try:
                ep = self.episodes[random.randint(0, len(self.episodes) - 1)]
                length = ep["length"]
                if length < self.action_chunk_size * self.global_downsample_rate + 2:
                    continue

                # Parquet rows come first: the idle filter derives its non-idle
                # windows from action.joint_velocity in this same frame.
                rows = self._load_parquet_rows(ep["data_chunk"], ep["data_file"], ep["episode_index"])
                windows = self._condition_windows(ep["episode_index"], rows)
                cond_idx, video_indices, action_indices = self._calculate_sampling_indices(
                    min(length, len(rows)), windows
                )
                if len(rows) <= action_indices[-1]:
                    continue

                # State at condition frame (8-dim qpos: 7 joints + 1 gripper)
                cond_row = rows.iloc[cond_idx]
                state = np.array(cond_row["observation.state"], dtype=np.float32)
                # Action chunk (8-dim qpos: 7 joints + 1 gripper)
                acts = np.stack(
                    [np.array(rows.iloc[ai]["action"], dtype=np.float32) for ai in action_indices],
                    axis=0,
                )
                # Instruction (aligned with RoboLab Pi0.5 `prompt`)
                instr = str(cond_row[self.instruction_field])
                if not instr.strip():
                    instr = str(cond_row.get("language_instruction_2", "") or "")
                if not instr.strip():
                    instr = str(cond_row.get("language_instruction_3", "") or "")
                if not instr.strip():
                    instr = self.DEFAULT_INSTRUCTION
                task_name = instr[:64]

                # Video decoding: offsets relative to episode start (cond + targets).
                offsets = [cond_idx] + video_indices
                if self.camera_layout == "v_stack":
                    # Draw one exterior view per sample: the two DROID exteriors
                    # are placed arbitrarily per scene, so alternating between
                    # them is a free viewpoint augmentation (openpi does the
                    # same).  Inference always feeds the first key.
                    k = (random.randrange(len(self.exterior_camera_keys))
                         if self.random_exterior else 0)
                    ext_raw = self._decode_raw_frames(
                        ep[f"ext{k}_video"], ep[f"ext{k}_start_frame"], offsets)
                    wrist_raw = self._decode_raw_frames(
                        ep["wrist_video"], ep["wrist_start_frame"], offsets)
                    video_all = self._stitch_raw([ext_raw, wrist_raw])  # [T+1, C, H, W]
                elif self.camera_layout == "t_shape":
                    # Decode at native resolution, then resize-pad each camera
                    # directly into its T-shape sub-region (no double resize).
                    top_raw = self._decode_raw_frames(ep["top_video"], ep["top_start_frame"], offsets)
                    bl_raw = self._decode_raw_frames(ep["bottom_left_video"], ep["bottom_left_start_frame"], offsets)
                    br_raw = self._decode_raw_frames(ep["bottom_right_video"], ep["bottom_right_start_frame"], offsets)
                    # T-shape: top (exterior_2) + bottom-left (exterior_1) + bottom-right (wrist)
                    video_all = self._stitch_raw([top_raw, bl_raw, br_raw])  # [T+1, C, H, W]
                else:
                    ext_frames = self._decode_stacked_frames(ep["ext_video"], ep["ext_start_frame"], offsets)
                    wrist_frames = self._decode_stacked_frames(ep["wrist_video"], ep["wrist_start_frame"], offsets)
                    # Legacy: stitch exterior + wrist (vertical or horizontal)
                    video_all = self._stitch_ext_wrist(ext_frames, wrist_frames)  # [T+1, C, H, W]
                first_frame = video_all[0]
                video_frames = video_all[1:]

                # T5 language embedding (disk-cached)
                language_embedding = self._get_t5_embedding(instr)

                # VLM inputs (Qwen3-VL)
                vlm_inputs = None
                if self.vlm_processor is not None:
                    first_pil = self._tensor_to_pil(first_frame)
                    vlm_inputs = preprocess_vlm_messages(instr, first_pil, self.vlm_processor)

                if self.normalizer is not None:
                    # acts must be transformed against the RAW state before the
                    # state itself is normalized.
                    acts = self.normalizer.to_model_actions(acts, state)
                    state = self.normalizer.normalize_state(state)

                initial_state = torch.from_numpy(state).float()
                action_sequence = torch.from_numpy(acts).float()

                return {
                    "first_frame": first_frame,
                    "video_frames": video_frames,
                    "initial_state": initial_state,
                    "action_sequence": action_sequence,
                    "language_embedding": language_embedding,
                    "vlm_inputs": vlm_inputs,
                    "task_name": task_name,
                }
            except _NoValidWindow:
                # Expected for episodes that are idle throughout; just resample.
                continue
            except Exception as e:
                logger.warning(f"DROID sample retry (ep {ep.get('episode_index','?')}): {e}")
                continue
        return None

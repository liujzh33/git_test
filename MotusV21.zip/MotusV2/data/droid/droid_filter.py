"""DROID idle-segment filtering, ported from openpi.

Reference: ``openpi/examples/droid/compute_droid_nonidle_ranges.py``.  openpi
ships a precomputed ``droid_sample_ranges_v1_0_1.json`` keyed by
``{recording_folderpath}--{file_path}``, but the LeRobot v3.0 conversion drops
both of those columns, so the ranges cannot be joined and are recomputed here
from ``action.joint_velocity`` instead (which the parquet does carry).

Why filter at all
-----------------
Roughly a tenth of DROID frames are teleop-idle.  Training on them teaches the
policy to emit stationary actions, i.e. exactly the "hold the current pose"
behaviour that a joint-position action space already tempts it into.

The idle test
-------------
Note that idleness is defined by the *commanded joint velocity not changing*
between consecutive frames, NOT by the velocity being near zero::

    is_idle[t] = all(|joint_velocity[t] - joint_velocity[t-1]| < 1e-3)

When a DROID operator lets go of the controller the command freezes at its last
value, which may well be non-zero.  Thresholding ``|joint_velocity|`` instead
would select a completely different (and wrong) set of frames.
"""

from __future__ import annotations

import logging
from typing import List, Tuple

import numpy as np

logger = logging.getLogger(__name__)

# openpi defaults (compute_droid_nonidle_ranges.py lines 36-38).
DEFAULT_MIN_IDLE_LEN = 7        # >= this many consecutive idle frames -> drop them
DEFAULT_MIN_NON_IDLE_LEN = 16   # keep-runs shorter than this are dropped entirely
DEFAULT_TRIM_LAST_N = 10        # trim this many frames off the end of every keep-run
IDLE_EPS = 1e-3


def _runs(mask: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """Start/end (exclusive) indices of the True runs in a boolean mask."""
    padded = np.concatenate([[False], mask, [False]])
    diff = np.diff(padded.astype(np.int8))
    return np.where(diff == 1)[0], np.where(diff == -1)[0]


def compute_keep_ranges(
    joint_velocity: np.ndarray,
    *,
    min_idle_len: int = DEFAULT_MIN_IDLE_LEN,
    min_non_idle_len: int = DEFAULT_MIN_NON_IDLE_LEN,
    trim_last_n: int = DEFAULT_TRIM_LAST_N,
) -> List[Tuple[int, int]]:
    """Non-idle ``[start, end)`` frame ranges of one episode.

    Args:
        joint_velocity: ``[T, 7]`` commanded joint velocities.

    Returns:
        Half-open ranges of contiguous, significant movement.  May be empty.
    """
    jv = np.asarray(joint_velocity, dtype=np.float32)
    if jv.ndim != 2:
        raise ValueError(f"joint_velocity must be [T, D], got {jv.shape}")
    T = jv.shape[0]
    if T < 2:
        return []

    # The first frame has no predecessor, so it is never idle (matches openpi).
    is_idle = np.concatenate([[False], np.all(np.abs(jv[1:] - jv[:-1]) < IDLE_EPS, axis=1)])

    keep = np.ones(T, dtype=bool)
    starts, ends = _runs(is_idle)
    long_enough = (ends - starts) >= min_idle_len
    for s, e in zip(starts[long_enough], ends[long_enough]):
        keep[s:e] = False

    out: List[Tuple[int, int]] = []
    starts, ends = _runs(keep)
    long_enough = (ends - starts) >= min_non_idle_len
    for s, e in zip(starts[long_enough], ends[long_enough]):
        # Frames near the end of a run produce chunks full of idle actions.
        e -= trim_last_n
        if e > s:
            out.append((int(s), int(e)))
    return out


def sampleable_windows(
    keep_ranges: List[Tuple[int, int]], span: int
) -> List[Tuple[int, int]]:
    """Condition-frame ranges whose full ``span``-frame chunk stays inside a keep range.

    MotusV2 samples one condition frame and then reads ``span`` frames of actions
    after it, so per-frame filtering (what openpi does) is not enough: the whole
    chunk has to land inside a single non-idle range, otherwise idle actions leak
    back into the target.

    Returns half-open ``[lo, hi)`` ranges of valid condition-frame indices.
    """
    out = []
    for s, e in keep_ranges:
        hi = e - span
        if hi > s:
            out.append((int(s), int(hi)))
    return out

"""Dataset registry and collate utilities for MotusV2.

All datasets return the same training sample contract:
first_frame, video_frames, action_sequence, optional initial_state,
language_embedding/text_embedding, vlm_inputs, and optional masks/metadata.
"""

import logging
import random
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)

import torch
from omegaconf import OmegaConf


class MultipleWeightedDataset(torch.utils.data.Dataset):
    """Combine datasets with per-sample weighted random selection."""

    def __init__(
        self,
        datasets: List[torch.utils.data.Dataset],
        weights: Optional[List[float]] = None,
        length: Optional[int] = None,
    ):
        if not datasets:
            raise ValueError("MultipleWeightedDataset requires at least one dataset")
        self.datasets = datasets
        self.weights = weights or [1.0] * len(datasets)
        total_weight = float(sum(self.weights))
        if total_weight <= 0:
            raise ValueError(f"Dataset weights must sum to a positive value, got {self.weights}")
        self._normalized_weights = [w / total_weight for w in self.weights]
        self._dataset_lengths = [len(dataset) for dataset in datasets]
        self._length = int(length) if length is not None else sum(self._dataset_lengths)

    def __len__(self) -> int:
        return self._length

    def __getitem__(self, index: int):
        dataset_id = random.choices(range(len(self.datasets)), weights=self._normalized_weights, k=1)[0]
        local_idx = index % self._dataset_lengths[dataset_id]
        return self.datasets[dataset_id][local_idx]

    def get_dataset_info(self) -> Dict[str, Any]:
        return {
            "num_datasets": len(self.datasets),
            "weights": self.weights,
            "lengths": self._dataset_lengths,
            "total_length": self._length,
        }


def _to_object(value):
    return OmegaConf.to_object(value) if OmegaConf.is_config(value) else value


def _common_params(config: OmegaConf, *, include_downsample: bool = True) -> Dict[str, Any]:
    params: Dict[str, Any] = {}
    if not hasattr(config, "common"):
        return params
    params.update(
        {
            "num_video_frames": config.common.num_video_frames,
            "video_size": (config.common.video_height, config.common.video_width),
        }
    )
    if include_downsample:
        params.update(
            {
                "global_downsample_rate": config.common.global_downsample_rate,
                "video_action_freq_ratio": config.common.video_action_freq_ratio,
            }
        )
    return params


def _copy_dataset_keys(config: OmegaConf, params: Dict[str, Any], keys: List[str]) -> None:
    for key in keys:
        if hasattr(config.dataset, key):
            params[key] = _to_object(config.dataset.get(key))


def _add_vlm_params(config: OmegaConf, params: Dict[str, Any], *, include_type: bool = True) -> None:
    if hasattr(config.model, "vlm") and hasattr(config.model.vlm, "checkpoint_path"):
        params["vlm_checkpoint_path"] = config.model.vlm.checkpoint_path
        if include_type:
            params["vlm_type"] = config.model.vlm.get("vlm_type", "qwen3_vl")


def _add_extra_params(config: OmegaConf, params: Dict[str, Any]) -> None:
    if hasattr(config.dataset, "params"):
        params.update(_to_object(config.dataset.params))


def _finalize_params(config: OmegaConf, params: Dict[str, Any], val: bool, *, include_vlm_type: bool = True) -> Dict[str, Any]:
    _add_vlm_params(config, params, include_type=include_vlm_type)
    _add_extra_params(config, params)
    params["val"] = val
    return params


def _robotwin(config: OmegaConf, val: bool):
    from .robotwin2.robotwin_agilex_dataset import RobotWinTaskDataset

    params = _common_params(config)
    _copy_dataset_keys(
        config,
        params,
        [
            "dataset_dir",
            "data_mode",
            "task_mode",
            "task_name",
            "max_episodes",
            "validation_split",
            "validation_seed",
            "randomized_limit_per_task",
            "task_sampling",
            "action_mode",
            "storage_mode",
            "obs_base_path",
        ],
    )
    params["image_aug"] = bool(config.dataset.get("image_aug", False)) and not val
    if config.dataset.get("normalization", False):
        stats_path = config.dataset.get("normalization_stats_path", None)
        if stats_path is None:
            raise ValueError("normalization_stats_path is required when dataset.normalization=True")
        params["normalization"] = True
        params["normalization_stats_path"] = stats_path
    # Motion token prediction config
    if hasattr(config.model, 'motion_token_prediction') and config.model.motion_token_prediction.get('enabled', False):
        mt_config = _to_object(config.model.motion_token_prediction)
        mt_config['vlm_checkpoint_path'] = config.model.vlm.checkpoint_path
        params['motion_token_prediction'] = mt_config
    return RobotWinTaskDataset(**_finalize_params(config, params, val))


def _multi_source_pretrain(config: OmegaConf, val: bool):
    from .multi_source_pretrain_dataset import MultiSourcePretrainDataset

    params = _common_params(config)
    params["max_action_dim"] = config.common.get("max_action_dim", config.common.action_dim)
    _copy_dataset_keys(config, params, ["sources", "max_episodes"])
    params["image_aug"] = bool(config.dataset.get("image_aug", False)) and not val
    if hasattr(config.dataset, "human_vae"):
        hcfg = config.dataset.human_vae
        params.update(
            {
                "human_vae_checkpoint_path": hcfg.get("checkpoint_path", None),
                "human_vae_latent_dim": hcfg.get("latent_dim", 16),
                "human_vae_hidden_dim": hcfg.get("hidden_dim", 256),
                "human_vae_action_dim": hcfg.get("action_dim", 450),
                "human_vae_device": hcfg.get("device", "cuda"),
                "human_latent_scale": hcfg.get("latent_scale", 0.3),
            }
        )
    return MultiSourcePretrainDataset(**_finalize_params(config, params, val, include_vlm_type=False))


def _latent_action(config: OmegaConf, val: bool):
    from .latent_action.latent_action_dataset import LatentActionDataset

    params = _common_params(config, include_downsample=False)
    _copy_dataset_keys(config, params, ["dataset_dir", "max_episodes"])
    if "dataset_dir" in params:
        params["dataset_dir"] = [str(p) for p in params["dataset_dir"]]
    params["image_aug"] = bool(config.dataset.get("image_aug", False)) and not val
    return LatentActionDataset(**_finalize_params(config, params, val))


def _lerobot(config: OmegaConf, val: bool):
    from .lerobot.lerobot_dataset import LeRobotMotusDataset

    params = _common_params(config)
    _copy_dataset_keys(config, params, ["dataset_dir", "task_mode", "task_name", "max_episodes"])
    params["image_aug"] = bool(config.dataset.get("image_aug", False)) and not val
    return LeRobotMotusDataset(**_finalize_params(config, params, val))


def _droid(config: OmegaConf, val: bool):
    """DROID (LeRobot v3.0) dataset — qpos joint-position action, aligned with
    RoboLab Pi0.5 ``pi05_droid_jointpos`` inference settings."""
    from .droid.droid_lerobot_dataset import DroidLeRobotDataset

    params = _common_params(config)
    _copy_dataset_keys(
        config,
        params,
        [
            "dataset_dir",
            "max_episodes",
            "instruction_field",
            "exterior_camera_key",
            "wrist_camera_key",
            # T-shape (3-camera) keys — previously not forwarded, so the YAML
            # values were silently ignored in favour of the class defaults.
            "top_camera_key",
            "bottom_left_camera_key",
            "bottom_right_camera_key",
            "exterior_camera_keys",
            "random_exterior",
            "camera_layout",
            "t5_mode",
            "t5_cache_dir",
            "t5_text_len",
            "t5_device",
            "t5_precision",
            "allow_t5_cache_miss_zero",
            "action_normalization",
            "norm_stats_path",
            "require_success",
            "filter_idle",
            "idle_min_len",
            "idle_min_non_idle_len",
            "idle_trim_last_n",
        ],
    )
    params["image_aug"] = bool(config.dataset.get("image_aug", False)) and not val
    # wan_path is passed via dataset.params (same convention as EgoDex/Xperience)
    return DroidLeRobotDataset(**_finalize_params(config, params, val))


def _vitra_params(config: OmegaConf, val: bool) -> Dict[str, Any]:
    params = _common_params(config, include_downsample=False)
    _copy_dataset_keys(
        config,
        params,
        [
            "dataset_dir",
            "dataset_name",
            "action_mode",
            "wrist_mode",
            "wrist_statistics_path",
            "latent_mode",
            "latent_checkpoint_path",
            "latent_dim",
            "latent_hidden_dim",
            "latent_device",
            "latent_normalization",
            "latent_statistics_path",
            "use_fov",
            "retarget_dir",
            "qpos_statistics_path",
        ],
    )
    return _finalize_params(config, params, val)


def _vitra_human(config: OmegaConf, val: bool):
    from .human.vitra_dataset import VitraHumanMotusDataset

    return VitraHumanMotusDataset(**_vitra_params(config, val))


def _wiyh(config: OmegaConf, val: bool):
    from .wiyh.wiyh_dataset import WIYHMotusDataset

    params = _common_params(config, include_downsample=False)
    _copy_dataset_keys(config, params, ["dataset_dir", "action_mode", "wrist_statistics_path"])
    return WIYHMotusDataset(**_finalize_params(config, params, val))


def _egodex(config: OmegaConf, val: bool):
    from .egodex.egodex_dataset import EgoDexMotusDataset

    params = _common_params(config, include_downsample=False)
    _copy_dataset_keys(config, params, ["dataset_dir", "action_mode", "wrist_statistics_path", "splits", "confidence_threshold"])
    return EgoDexMotusDataset(**_finalize_params(config, params, val))


_EGOVERSE_KEYS = [
    "dataset_dir", "action_mode", "subset", "hand_pose_key", "camera_key",
    "head_pose_key", "quat_order", "head_to_camera", "frame_stride",
    "video_source", "max_episodes", "index_cache_path",
    "pose_cache_dir", "require_pose_cache",
]

_OPENAOE_KEYS = [
    "dataset_dir", "action_mode", "frame_stride", "video_source",
    "allow_video_fallback", "instruction_mode", "default_instruction",
    "max_episodes", "index_cache_path",
]


def _egoverse(config: OmegaConf, val: bool):
    from .egoverse.egoverse_dataset import EgoVerseMotusDataset

    params = _common_params(config, include_downsample=False)
    _copy_dataset_keys(config, params, _EGOVERSE_KEYS)
    return EgoVerseMotusDataset(**_finalize_params(config, params, val))


def _openaoe(config: OmegaConf, val: bool):
    from .openaoe.openaoe_dataset import OpenAoEMotusDataset

    params = _common_params(config, include_downsample=False)
    _copy_dataset_keys(config, params, _OPENAOE_KEYS)
    return OpenAoEMotusDataset(**_finalize_params(config, params, val))


def _resolve_vitra_entries(config: OmegaConf):
    if hasattr(config.dataset, "datasets") and config.dataset.datasets:
        return [(ds.get("name"), ds.get("weight", 1.0), ds.get("dataset_dir", config.dataset.dataset_dir)) for ds in config.dataset.datasets]

    from .human.data_mixture import get_mixture_config

    mixture_name = config.dataset.get("data_mix", config.dataset.get("dataset_name", None))
    if mixture_name is None:
        raise ValueError("VITRA mixed datasets require dataset.data_mix, dataset.dataset_name, or dataset.datasets")
    return [(name, weight, config.dataset.dataset_dir) for name, weight in get_mixture_config(mixture_name)]


def _vitra_human_mixed(config: OmegaConf, val: bool):
    from .human.vitra_dataset import VitraHumanMotusDataset

    base_params = _vitra_params(config, val)
    base_params.pop("dataset_name", None)
    base_params.pop("dataset_dir", None)
    datasets, weights = [], []
    for name, weight, dataset_dir in _resolve_vitra_entries(config):
        datasets.append(VitraHumanMotusDataset(dataset_dir=dataset_dir, dataset_name=name, **base_params))
        weights.append(float(weight))
    return MultipleWeightedDataset(datasets, weights)


def _vitra_robot_mixed(config: OmegaConf, val: bool):
    from .human.vitra_robot_dataset import VitraRobotMotusDataset

    base_params = _vitra_params(config, val)
    base_params.pop("dataset_name", None)
    base_params.pop("dataset_dir", None)
    datasets, weights = [], []
    for name, weight, dataset_dir in _resolve_vitra_entries(config):
        datasets.append(VitraRobotMotusDataset(dataset_dir=dataset_dir, dataset_name=name, **base_params))
        weights.append(float(weight))
    return MultipleWeightedDataset(datasets, weights)


def _cross_dataset_mixed(config: OmegaConf, val: bool):
    if not hasattr(config.dataset, "datasets") or not config.dataset.datasets:
        raise ValueError("cross_dataset_mixed requires dataset.datasets")

    common_params = _common_params(config, include_downsample=False)
    _add_vlm_params(config, common_params)
    _add_extra_params(config, common_params)
    common_params["action_mode"] = config.dataset.get("action_mode", "wrist")
    wrist_statistics_path = config.dataset.get("wrist_statistics_path", None)
    if wrist_statistics_path:
        common_params["wrist_statistics_path"] = wrist_statistics_path

    datasets, weights = [], []
    for ds_cfg in config.dataset.datasets:
        ds_type = ds_cfg.get("type")
        params = dict(common_params)
        params["dataset_dir"] = ds_cfg.get("dataset_dir")
        params["val"] = val
        if params["dataset_dir"] is None:
            raise ValueError(f"cross_dataset_mixed entry is missing dataset_dir: {ds_cfg}")

        if ds_type == "vitra_human":
            from .human.vitra_dataset import VitraHumanMotusDataset

            params["dataset_name"] = ds_cfg.get("name", "ssv2")
            if params["action_mode"] == "wrist":
                params["wrist_mode"] = True
            for key in ["clip_len", "t5_mode", "wan_path", "t5_cache_dir", "t5_device", "t5_text_len"]:
                if key in ds_cfg:
                    params[key] = ds_cfg[key]
            dataset = VitraHumanMotusDataset(**params)
        elif ds_type == "wiyh":
            from .wiyh.wiyh_dataset import WIYHMotusDataset

            for key in ["camera_name", "max_episodes", "t5_mode", "wan_path", "t5_cache_dir", "t5_device", "t5_text_len"]:
                if key in ds_cfg:
                    params[key] = ds_cfg[key]
            dataset = WIYHMotusDataset(**params)
        elif ds_type == "egodex":
            from .egodex.egodex_dataset import EgoDexMotusDataset

            for key in ["splits", "confidence_threshold", "max_episodes", "t5_mode", "wan_path", "t5_cache_dir", "t5_device", "t5_text_len"]:
                if key in ds_cfg:
                    params[key] = ds_cfg[key]
            dataset = EgoDexMotusDataset(**params)
        elif ds_type == "xperience":
            from .xperience.xperience_dataset import XperienceMotusDataset

            for key in ["max_episodes", "t5_mode", "wan_path", "t5_cache_dir", "t5_device", "t5_text_len",
                         "reference_camera_key", "require_camera_extrinsics", "allow_base_relative_fallback"]:
                if key in ds_cfg:
                    params[key] = ds_cfg[key]
            dataset = XperienceMotusDataset(**params)
        elif ds_type == "egoverse":
            from .egoverse.egoverse_dataset import EgoVerseMotusDataset

            for key in ["t5_mode", "wan_path", "t5_cache_dir", "t5_device", "t5_text_len"] + _EGOVERSE_KEYS:
                if key in ds_cfg and key != "dataset_dir":
                    params[key] = _to_object(ds_cfg[key])
            dataset = EgoVerseMotusDataset(**params)
        elif ds_type == "openaoe":
            from .openaoe.openaoe_dataset import OpenAoEMotusDataset

            for key in ["t5_mode", "wan_path", "t5_cache_dir", "t5_device", "t5_text_len"] + _OPENAOE_KEYS:
                if key in ds_cfg and key != "dataset_dir":
                    params[key] = _to_object(ds_cfg[key])
            dataset = OpenAoEMotusDataset(**params)
        else:
            raise ValueError(f"Unsupported cross_dataset_mixed sub-dataset type: {ds_type}")

        datasets.append(dataset)
        weights.append(float(ds_cfg.get("weight", 1.0)))

    # Auto-weight: set each dataset's weight proportional to its effective
    # episode count.  ``effective_len`` accounts for episodes that are
    # indexed but may be skipped at sample-time due to missing calibration
    # or other data quality issues (e.g. Xperience).  Falls back to
    # ``len(ds)`` for datasets that don't expose ``effective_len``.
    if config.dataset.get("auto_weight", False):
        lengths = [getattr(ds, "effective_len", len(ds)) for ds in datasets]
        weights = [float(l) for l in lengths]
        for ds_cfg, w, l in zip(config.dataset.datasets, weights, lengths):
            logger.info(f"  auto_weight: {ds_cfg.get('type', '?')}/{ds_cfg.get('name', '?')} "
                        f"episodes={l}, weight={w:.1f}")

    return MultipleWeightedDataset(datasets, weights)


def _g1d(config: OmegaConf, val: bool):
    """G1-D (Unitree G1 Dex1, LeRobot v3.0) dataset — 16-dim action, T-shape
    stitched cameras (cam_left_high on top, cam_left/right_wrist on bottom).
    Self-collected ``pick-kettle-and-cup`` data.

    ``dataset.stitch_mode`` selects the stitch: "aspect" (default,
    aspect-preserving single resize) or "legacy" (the old double resize, only
    for serving checkpoints trained before the switch).

    ``dataset.action_mode`` selects the representation: "qpos" (default, joint
    angles) or "eef" (Cartesian, needs the precomputed columns).  ``eef`` pairs
    with ``dataset.normalization`` because its translation and rotation dims
    differ in scale by ~6x."""
    from .g1d.g1d_dataset import G1DLeRobotDataset

    params = _common_params(config)
    _copy_dataset_keys(
        config,
        params,
        [
            "dataset_dir",
            "max_episodes",
            "t5_mode",
            "t5_cache_dir",
            "t5_text_len",
            "t5_device",
            "allow_t5_cache_miss_zero",
            "stitch_mode",
            "action_mode",
            "normalization",
            "normalization_stats_path",
            # The inference adapter reads this key out of the same yaml and
            # treats it as authoritative, so dropping it here would scale the
            # targets one way in training and the other on the robot.
            "normalization_mode",
        ],
    )
    params["image_aug"] = bool(config.dataset.get("image_aug", False)) and not val
    # wan_path is passed via dataset.params (same convention as DROID/EgoDex/Xperience)
    return G1DLeRobotDataset(**_finalize_params(config, params, val))


def _g1d_ego_mixed(config: OmegaConf, val: bool):
    """G1-D robot data mixed with retargeted FastEgo human-hand data.

    The two share one Cartesian action space, one set of normalization
    statistics (G1-D's -- the ego retarget was aligned onto that distribution)
    and one instruction, so samples from either are interchangeable in a batch.

    What must differ is the frame stride: ego is 60 Hz against G1-D's 30 Hz, so
    ``ego.global_downsample_rate`` should be twice G1-D's for a chunk to cover
    the same wall-clock span. The ego side refuses to build if the resulting
    span has too few stretches with both hands tracked.

    ``max_episodes`` plus ``episode_seed`` fixes how many episodes each side
    contributes, drawn once and identically in every worker and rank.

    With ``holdout_val: true`` that draw becomes a split: training sees exactly
    the drawn episodes and validation sees the G1-D episodes left over, so a
    validation number reflects unseen robot data. Ego is excluded from
    validation -- the question being asked is how well the policy does on the
    robot, and human demonstrations cannot answer it.
    """
    from .ego.ego_dataset import EgoRetargetDataset
    from .g1d.g1d_dataset import G1DLeRobotDataset

    shared = _common_params(config, include_downsample=False)
    _add_vlm_params(config, shared)
    ds_cfg = config.dataset
    shared["video_action_freq_ratio"] = config.common.video_action_freq_ratio
    shared["val"] = val
    for key in ("action_mode", "normalization", "normalization_stats_path",
                "normalization_mode"):
        if hasattr(ds_cfg, key):
            shared[key] = _to_object(ds_cfg.get(key))
    for key in ("t5_mode", "t5_cache_dir", "t5_text_len", "t5_device",
                "allow_t5_cache_miss_zero"):
        if hasattr(ds_cfg, key):
            shared[key] = _to_object(ds_cfg.get(key))
    if hasattr(ds_cfg, "params") and hasattr(ds_cfg.params, "wan_path"):
        shared["wan_path"] = ds_cfg.params.wan_path

    default_seed = _to_object(ds_cfg.get("episode_seed", None))
    instruction = _to_object(ds_cfg.get("instruction", ""))
    image_aug = bool(ds_cfg.get("image_aug", False)) and not val

    if shared.get("normalization") and not shared.get("normalization_stats_path"):
        # Resolve here rather than letting each side default to its own root: the
        # ego retarget was aligned onto G1-D's distribution, so both must use
        # G1-D's constants, and the ego package has no statistics of its own.
        g1d_dir = ds_cfg.get("g1d", {}).get("dataset_dir")
        if not g1d_dir:
            raise ValueError(
                "normalization=True needs either dataset.normalization_stats_path or "
                "dataset.g1d.dataset_dir to resolve it from"
            )
        shared["normalization_stats_path"] = str(Path(g1d_dir) / "meta" / "eef_stats.json")

    holdout_val = bool(ds_cfg.get("holdout_val", False))
    # Validation on held-out robot episodes only; ego never enters it.
    sources = ("g1d",) if (val and holdout_val) else ("g1d", "ego")
    if holdout_val:
        subset = "val" if val else "train"
    else:
        subset = "all"

    datasets, weights, info = [], [], []
    for name, builder in (("g1d", G1DLeRobotDataset), ("ego", EgoRetargetDataset)):
        if name not in sources or not hasattr(ds_cfg, name):
            continue
        sub = ds_cfg.get(name)
        if int(sub.get("max_episodes", 0) or 0) < 0:
            raise ValueError(f"{name}.max_episodes must be >= 0")
        params = dict(shared)
        params["dataset_dir"] = sub.get("dataset_dir")
        params["global_downsample_rate"] = int(sub.get("global_downsample_rate", 1))
        params["max_episodes"] = _to_object(sub.get("max_episodes", None))
        params["episode_seed"] = _to_object(sub.get("episode_seed", default_seed))
        params["episode_subset"] = subset
        params["image_aug"] = image_aug
        if name == "g1d":
            params["stitch_mode"] = _to_object(ds_cfg.get("stitch_mode", "aspect"))
        else:
            params["instruction"] = instruction
        dataset = builder(**params)
        datasets.append(dataset)
        weights.append(float(sub.get("weight", 1.0)))
        info.append(f"{name}={len(dataset.episodes)}ep w={weights[-1]}")

    if not datasets:
        raise ValueError("g1d_ego_mixed needs at least one of dataset.g1d / dataset.ego")
    if config.dataset.get("auto_weight", False):
        weights = [float(len(d.episodes)) for d in datasets]
        info = [i.rsplit(" w=", 1)[0] + f" w={w}" for i, w in zip(info, weights)]
    logger.info(f"g1d_ego_mixed[{'val' if val else 'train'}]: " + ", ".join(info))

    # Both sides draw a random episode and a random window per __getitem__ and
    # ignore the index, so the reported length only decides how many steps an
    # epoch lasts.  Left at episodes*10 an epoch ends every step or two, and the
    # training loop rebuilds the iterator that often -- which throws away the
    # dataloader's prefetch queue each time and makes every step wait on a cold
    # decode.  samples_per_epoch buys back the overlap.
    length = _to_object(ds_cfg.get("samples_per_epoch", None)) if not val else None
    if length is not None:
        length = int(length)
    if len(datasets) == 1 and length is None:
        return datasets[0]
    return MultipleWeightedDataset(datasets, weights, length=length)


DATASET_REGISTRY: Dict[str, Callable[[OmegaConf, bool], torch.utils.data.Dataset]] = {
    "robotwin": _robotwin,
    "multi_source_pretrain": _multi_source_pretrain,
    "latent_action": _latent_action,
    "lerobot": _lerobot,
    "droid": _droid,
    "g1d": _g1d,
    "g1d_ego_mixed": _g1d_ego_mixed,
    "vitra_human": _vitra_human,
    "vitra_human_mixed": _vitra_human_mixed,
    "vitra_robot_mixed": _vitra_robot_mixed,
    "wiyh": _wiyh,
    "egodex": _egodex,
    "egoverse": _egoverse,
    "openaoe": _openaoe,
    "cross_dataset_mixed": _cross_dataset_mixed,
}


def create_dataset(config: OmegaConf, val: bool = False):
    dataset_type = config.dataset.get("type", "robotwin")
    try:
        builder = DATASET_REGISTRY[dataset_type]
    except KeyError as exc:
        available = ", ".join(sorted(DATASET_REGISTRY))
        raise ValueError(f"Unknown dataset type: {dataset_type}. Available types: {available}") from exc
    return builder(config, val)


def _process_vlm_inputs_batch(vlm_inputs: List[Dict[str, Any]]) -> Dict[str, torch.Tensor]:
    input_ids_list = [vlm_input["input_ids"] for vlm_input in vlm_inputs]
    pixel_values_list = [vlm_input.get("pixel_values") for vlm_input in vlm_inputs]
    image_grid_thw_list = [vlm_input.get("image_grid_thw") for vlm_input in vlm_inputs]
    attention_mask_list = [vlm_input.get("attention_mask") for vlm_input in vlm_inputs]

    max_seq_len = max(ids.shape[1] for ids in input_ids_list)
    sequence_optional_keys = ["assistant_token_mask", "assistant_loss_mask"]
    padded_input_ids, padded_attention_masks = [], []
    padded_sequence_values = {key: [] for key in sequence_optional_keys}
    for ids, mask in zip(input_ids_list, attention_mask_list):
        input_index = len(padded_input_ids)
        if ids.shape[1] < max_seq_len:
            padding_size = max_seq_len - ids.shape[1]
            padded_ids = torch.cat([ids, torch.zeros(ids.shape[0], padding_size, dtype=ids.dtype, device=ids.device)], dim=1)
            padded_mask = None
            if mask is not None:
                padded_mask = torch.cat(
                    [mask, torch.zeros(mask.shape[0], padding_size, dtype=mask.dtype, device=mask.device)],
                    dim=1,
                )
        else:
            padded_ids = ids
            padded_mask = mask
        padded_input_ids.append(padded_ids)
        padded_attention_masks.append(padded_mask)

        # Review Blocker-1/2: keep assistant masks aligned with padded
        # input_ids so the model can block leakage and apply causal VLM MoT.
        for key in sequence_optional_keys:
            value = vlm_inputs[input_index].get(key)
            if value is None:
                padded_sequence_values[key].append(
                    torch.zeros(ids.shape[0], max_seq_len, dtype=torch.bool, device=ids.device)
                )
            elif value.shape[1] < max_seq_len:
                padding_size = max_seq_len - value.shape[1]
                padding = torch.zeros(value.shape[0], padding_size, dtype=value.dtype, device=value.device)
                padded_sequence_values[key].append(torch.cat([value, padding], dim=1))
            else:
                padded_sequence_values[key].append(value)

    result = {
        "input_ids": torch.cat(padded_input_ids, dim=0),
        "pixel_values": torch.cat([pv for pv in pixel_values_list if pv is not None], dim=0)
        if any(pv is not None for pv in pixel_values_list)
        else None,
        "image_grid_thw": torch.cat([igt for igt in image_grid_thw_list if igt is not None], dim=0)
        if any(igt is not None for igt in image_grid_thw_list)
        else None,
        "attention_mask": torch.cat([mask for mask in padded_attention_masks if mask is not None], dim=0)
        if any(mask is not None for mask in padded_attention_masks)
        else None,
    }

    for optional_key in ["image_token_pooling", "image_grids", "image_num_crops"]:
        values = [vlm_input.get(optional_key) for vlm_input in vlm_inputs]
        if any(value is not None for value in values):
            result[optional_key] = torch.cat([value for value in values if value is not None], dim=0)
    for optional_key, values in padded_sequence_values.items():
        original_values = [vlm_input.get(optional_key) for vlm_input in vlm_inputs]
        if any(value is not None for value in original_values):
            result[optional_key] = torch.cat(values, dim=0)
    return result


def _process_language_embeddings_batch(language_embeddings: List[Optional[torch.Tensor]], text_len: int = 512) -> Optional[torch.Tensor]:
    if not language_embeddings or all(emb is None for emb in language_embeddings):
        return None

    valid_emb = next(emb for emb in language_embeddings if emb is not None)
    padded_embeddings = []
    for emb in language_embeddings:
        if emb is None:
            padded = valid_emb.new_zeros(text_len, valid_emb.shape[-1])
        elif emb.shape[0] < text_len:
            padded = torch.cat([emb, emb.new_zeros(text_len - emb.shape[0], emb.shape[1])])
        else:
            padded = emb[:text_len]
        padded_embeddings.append(padded)
    return torch.stack(padded_embeddings, dim=0)


def collate_fn(batch: List[Optional[Dict[str, Any]]]) -> Optional[Dict[str, Any]]:
    batch = [sample for sample in batch if sample is not None]
    if not batch:
        return None

    result = {
        "first_frame": torch.stack([sample["first_frame"] for sample in batch]),
        "video_frames": torch.stack([sample["video_frames"] for sample in batch]),
        "action_sequence": torch.stack([sample["action_sequence"] for sample in batch]),
        "vlm_inputs": None,
        "text_embedding": _process_language_embeddings_batch([sample.get("text_embedding") for sample in batch]),
        "language_embedding": _process_language_embeddings_batch([sample.get("language_embedding") for sample in batch]),
        "text_prompts": [sample.get("text_instruction") for sample in batch]
        if any(sample.get("text_instruction") is not None for sample in batch)
        else None,
        "task_names": [sample.get("task_name") for sample in batch]
        if any(sample.get("task_name") is not None for sample in batch)
        else None,
    }

    if all(sample.get("initial_state") is not None for sample in batch):
        result["initial_state"] = torch.stack([sample["initial_state"] for sample in batch])

    vlm_inputs = [sample.get("vlm_inputs") for sample in batch]
    if vlm_inputs and all(vlm_input is not None for vlm_input in vlm_inputs):
        result["vlm_inputs"] = _process_vlm_inputs_batch(vlm_inputs)

    vlm_user_inputs = [sample.get("vlm_user_inputs") for sample in batch]
    if vlm_user_inputs and all(vlm_input is not None for vlm_input in vlm_user_inputs):
        # Review Blocker-3: validation/inference should consume prompt-only
        # VLM inputs, never ground-truth assistant motion tokens.
        result["vlm_user_inputs"] = _process_vlm_inputs_batch(vlm_user_inputs)

    if all("fov" in sample and sample["fov"] is not None for sample in batch):
        result["fov"] = torch.stack([sample["fov"] for sample in batch])

    if all("action_valid_mask" in sample for sample in batch):
        result["action_valid_mask"] = torch.stack([sample["action_valid_mask"] for sample in batch])

    # Motion token labels: padded with -100
    motion_labels_list = [sample.get("motion_token_labels") for sample in batch]
    if any(label is not None for label in motion_labels_list):
        max_label_len = max(label.shape[-1] for label in motion_labels_list if label is not None)
        padded_labels = []
        for label in motion_labels_list:
            if label is None:
                padded_labels.append(torch.full((1, max_label_len), -100, dtype=torch.long))
            elif label.shape[-1] < max_label_len:
                pad_size = max_label_len - label.shape[-1]
                padding = torch.full((1, pad_size), -100, dtype=torch.long)
                padded_labels.append(torch.cat([label, padding], dim=-1))
            else:
                padded_labels.append(label)
        result["motion_token_labels"] = torch.cat(padded_labels, dim=0)  # [B, max_seq_len]

    return result

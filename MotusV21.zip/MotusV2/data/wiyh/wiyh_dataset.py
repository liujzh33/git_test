"""
WIYH (World In Your Hands) Dataset Adapter for Motus.

Supports two action modes:
1. "wrist" (default): 14-dim = [left_xyz(3), left_quat_WXYZ(4),
                                right_xyz(3), right_quat_WXYZ(4)]
2. "padded_per_hand":  per-hand features padded to MAX_PER_HAND_DIM,
   layout = [left_pad(max), right_pad(max)]
   WIYH per-hand: eef_pose(7) + hand_joints(75) = 82 dims

Data layout (per scene):
    <scene_dir>/
        task.json
        action_000/
            dataset.hdf5
            camera/
                lf_chest_fisheye/*.jpg
            visualization.mp4
"""

import os
import json
import random
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import cv2
import h5py
import numpy as np
import torch
import torch.utils.data as data
from scipy.spatial.transform import Rotation as R

from data.utils.image_utils import resize_with_padding, tensor_to_pil
from data.human.wrist_feature import WristGaussianNormalizer
from data.per_hand_dims import (
    WIYH_PER_HAND_ACTION_DIM, WIYH_PER_HAND_STATE_DIM,
    MAX_PER_HAND_ACTION_DIM, MAX_PER_HAND_STATE_DIM,
    PADDED_ACTION_DIM, PADDED_STATE_DIM,
    concat_per_hand,
)

logger = logging.getLogger(__name__)

_SHARED_T5_ENCODER = None
_SHARED_T5_CONFIG = None


def _get_shared_t5_encoder(wan_path: str, t5_text_len: int, t5_device: str):
    global _SHARED_T5_ENCODER, _SHARED_T5_CONFIG
    import sys
    BAK_ROOT = str((Path(__file__).resolve().parents[2] / "bak").resolve())
    if BAK_ROOT not in sys.path:
        sys.path.insert(0, BAK_ROOT)
    from wan.modules.t5 import T5EncoderModel

    config_key = (wan_path, t5_text_len, t5_device)
    if _SHARED_T5_ENCODER is None or _SHARED_T5_CONFIG != config_key:
        if _SHARED_T5_ENCODER is not None:
            del _SHARED_T5_ENCODER
            torch.cuda.empty_cache()
        ckpt = os.path.join(wan_path, "Wan2.2-TI2V-5B", "models_t5_umt5-xxl-enc-bf16.pth")
        tok = os.path.join(wan_path, "Wan2.2-TI2V-5B", "google/umt5-xxl")
        _SHARED_T5_ENCODER = T5EncoderModel(
            text_len=t5_text_len, dtype=torch.bfloat16,
            device=t5_device, checkpoint_path=ckpt, tokenizer_path=tok,
        )
        _SHARED_T5_CONFIG = config_key
    return _SHARED_T5_ENCODER


def _se3_to_xyzquat(pose7: np.ndarray) -> np.ndarray:
    """[x,y,z, qx,qy,qz,qw] -> [x,y,z, qw,qx,qy,qz] (WXYZ)."""
    xyz = pose7[:3]
    quat_xyzw = pose7[3:7]
    quat_wxyz = np.roll(quat_xyzw, 1)
    return np.concatenate([xyz, quat_wxyz]).astype(np.float32)


def _rotation_matrix_to_rot6d(rot_mat: np.ndarray) -> np.ndarray:
    """Convert 3x3 rotation matrix to 6D rotation representation (Zhou et al.)."""
    return rot_mat[:, :2].flatten().astype(np.float32)  # first two columns


def _find_closest_timestamp(target: int, timestamps: np.ndarray) -> int:
    idx = np.argmin(np.abs(timestamps - target))
    return int(idx)


class WIYHMotusDataset(data.Dataset):
    """
    WIYH dataset adapter producing Motus-compatible samples.

    action_mode="wrist" (default):
        action_sequence: [F, 14],  initial_state: [14]
    action_mode="padded_per_hand":
        action_sequence: [F, 450], initial_state: [450]
        layout: [left_per_hand(max225), right_per_hand(max225)]
        WIYH per-hand = eef(7) + joints(75) = 82, padded to 225
    """

    def __init__(
        self,
        dataset_dir: str,
        *,
        num_video_frames: int = 8,
        video_size: Tuple[int, int] = (384, 320),
        camera_name: str = "lf_chest_fisheye",
        # Action mode: "wrist" (14-dim) or "padded_per_hand" (450-dim)
        action_mode: str = "wrist",
        # Wrist normalization (only for action_mode="wrist")
        wrist_statistics_path: Optional[str] = None,
        # VLM
        vlm_checkpoint_path: Optional[str] = None,
        # T5 embedding
        t5_mode: str = "disk_cache",
        wan_path: str = "./pretrained_models",
        t5_cache_dir: str = "./t5_cache_wiyh",
        t5_text_len: int = 512,
        t5_device: str = "cuda",
        # Sampling
        max_episodes: Optional[int] = None,
        max_attempts: int = 8,
        val: bool = False,
        **kwargs: Any,
    ) -> None:
        super().__init__()
        self.dataset_dir = str(dataset_dir)
        self.num_video_frames = int(num_video_frames)
        self.video_size = video_size
        self.camera_name = camera_name
        self.action_mode = action_mode
        self.max_attempts = int(max_attempts)
        self.val = val

        assert self.action_mode in ("wrist", "padded_per_hand"), \
            f"action_mode must be 'wrist' or 'padded_per_hand', got '{self.action_mode}'"

        self._action_dim = 14 if self.action_mode == "wrist" else PADDED_ACTION_DIM
        self._state_dim = 14 if self.action_mode == "wrist" else PADDED_STATE_DIM

        # Index all episodes
        self.episodes: List[Dict[str, Any]] = []
        self._index_episodes(max_episodes)

        if len(self.episodes) == 0:
            raise RuntimeError(f"No valid WIYH episodes found in {dataset_dir}")

        logger.info(f"[WIYH->Motus] Indexed {len(self.episodes)} episodes, "
                     f"action_mode={self.action_mode}, "
                     f"action_dim={self._action_dim}, state_dim={self._state_dim}")

        # Wrist normalizer (only for wrist mode)
        self.wrist_normalizer: Optional[WristGaussianNormalizer] = None
        if self.action_mode == "wrist" and wrist_statistics_path is not None and os.path.exists(wrist_statistics_path):
            from data.human.wrist_feature import load_wrist_statistics
            stats = load_wrist_statistics(wrist_statistics_path)
            self.wrist_normalizer = WristGaussianNormalizer(stats)
            logger.info(f"[WIYH->Motus] Loaded wrist normalizer from {wrist_statistics_path}")

        # VLM processor
        self.vlm_processor = None
        if vlm_checkpoint_path:
            from transformers import AutoProcessor
            self.vlm_processor = AutoProcessor.from_pretrained(vlm_checkpoint_path)

        # T5 embedding
        self.t5_mode = t5_mode
        self.t5_cache_dir = Path(t5_cache_dir)
        self.t5_cache_dir.mkdir(parents=True, exist_ok=True)
        self.t5_encoder = None
        self.t5_device = t5_device
        if self.t5_mode == "disk_cache":
            self.t5_encoder = _get_shared_t5_encoder(wan_path, t5_text_len, t5_device)
        elif self.t5_mode == "none":
            logger.warning("[WIYH->Motus] t5_mode=none: language_embedding will be zeros")

    # ------------------------------------------------------------------
    # Episode indexing
    # ------------------------------------------------------------------
    def _index_episodes(self, max_episodes: Optional[int]):
        root = Path(self.dataset_dir)
        for scene_dir in sorted(root.iterdir()):
            if not scene_dir.is_dir():
                continue
            if not (scene_dir / "task.json").exists() and not any(
                (scene_dir / d).is_dir() and d.startswith("action_")
                for d in os.listdir(scene_dir)
            ):
                continue

            for action_dir in sorted(scene_dir.iterdir()):
                if not action_dir.is_dir() or not action_dir.name.startswith("action_"):
                    continue
                h5_path = action_dir / "dataset.hdf5"
                if not h5_path.exists():
                    continue

                try:
                    n_frames = self._get_frame_count(str(h5_path))
                    if n_frames < self.num_video_frames + 1:
                        continue
                    self.episodes.append({
                        "h5_path": str(h5_path),
                        "scene_dir": str(scene_dir),
                        "action_dir": str(action_dir),
                        "n_frames": n_frames,
                    })
                    if max_episodes is not None and len(self.episodes) >= max_episodes:
                        return
                except Exception as e:
                    logger.warning(f"[WIYH->Motus] Skipping {h5_path}: {e}")

    def _get_frame_count(self, h5_path: str) -> int:
        with h5py.File(h5_path, "r") as f:
            key = f"observation/camera/{self.camera_name}/filepath"
            if key in f:
                return len(f[key])
            key_ts = f"observation/camera/{self.camera_name}/timestamp"
            if key_ts in f:
                return len(f[key_ts])
            return 0

    # ------------------------------------------------------------------
    # Data loading helpers
    # ------------------------------------------------------------------
    def _load_image(self, image_path: str) -> np.ndarray:
        img = cv2.imread(image_path)
        if img is None:
            raise FileNotFoundError(f"Image not found: {image_path}")
        return cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

    def _load_frames_window(self, h5_path: str, action_dir: str, frame_start: int) -> torch.Tensor:
        frames = []
        with h5py.File(h5_path, "r") as f:
            filepaths = f[f"observation/camera/{self.camera_name}/filepath"]
            for i in range(self.num_video_frames + 1):
                fi = min(frame_start + i, len(filepaths) - 1)
                rel_path = filepaths[fi].decode("utf-8") if isinstance(filepaths[fi], bytes) else filepaths[fi]
                img = self._load_image(os.path.join(action_dir, rel_path))
                img = resize_with_padding(img, self.video_size)
                frames.append(img)
        arr = np.stack(frames, axis=0)
        return torch.from_numpy(arr).permute(0, 3, 1, 2).float() / 255.0

    def _read_raw_data(self, h5_path: str, frame_idx: int):
        """Read raw arm + hand data from HDF5.

        Returns:
            cam_timestamps, arm_ts,
            left_poses, right_poses, left_arm_mask, right_arm_mask,
            left_hand_joints, right_hand_joints, left_hand_mask, right_hand_mask,
            instruction
        """
        with h5py.File(h5_path, "r") as f:
            cam_key = f"observation/camera/{self.camera_name}"
            cam_timestamps = f[f"{cam_key}/timestamp"][:]

            arm_ts = f["action/arm_status_feedback/timestamp"][:]
            left_poses = f["action/arm_status_feedback/left_eef_pose_in_chest"][:]
            right_poses = f["action/arm_status_feedback/right_eef_pose_in_chest"][:]
            left_arm_mask = f["action/arm_status_feedback/left_eef_pose_mask"][:]
            right_arm_mask = f["action/arm_status_feedback/right_eef_pose_mask"][:]

            # Hand joint angles (75-dim per hand, 25 bones x 3D positions)
            left_hand_joints = None
            right_hand_joints = None
            left_hand_mask = None
            right_hand_mask = None
            hand_ts = None
            if "action/hand_status_feedback/left_hand_joint_angle" in f:
                left_hand_joints = f["action/hand_status_feedback/left_hand_joint_angle"][:]
                right_hand_joints = f["action/hand_status_feedback/right_hand_joint_angle"][:]
                left_hand_mask = f["action/hand_status_feedback/left_hand_joint_angle_mask"][:]
                right_hand_mask = f["action/hand_status_feedback/right_hand_joint_angle_mask"][:]
                hand_ts = f["action/hand_status_feedback/timestamp"][:]

            instruction = ""
            if "meta/task_description" in f:
                td = f["meta/task_description"][0]
                instruction = td.decode("utf-8") if isinstance(td, bytes) else str(td)
            elif "annotation/atomic_task_description/atomic_task_description" in f:
                ann = f["annotation/atomic_task_description/atomic_task_description"][0]
                instruction = ann.decode("utf-8") if isinstance(ann, bytes) else str(ann)

        return (cam_timestamps, arm_ts,
                left_poses, right_poses, left_arm_mask, right_arm_mask,
                left_hand_joints, right_hand_joints, left_hand_mask, right_hand_mask,
                hand_ts, instruction)

    def _extract_wrist_action_state(self, h5_path: str, frame_idx: int):
        """Extract 14-dim wrist action/state."""
        (cam_timestamps, arm_ts,
         left_poses, right_poses, left_arm_mask, right_arm_mask,
         *_, instruction) = self._read_raw_data(h5_path, frame_idx)

        actions, valid_masks = [], []
        for i in range(self.num_video_frames):
            fi = min(frame_idx + i + 1, len(cam_timestamps) - 1)
            arm_idx = _find_closest_timestamp(cam_timestamps[fi], arm_ts)

            left_valid = (left_arm_mask[arm_idx] == 0) if arm_idx < len(left_arm_mask) else False
            right_valid = (right_arm_mask[arm_idx] == 0) if arm_idx < len(right_arm_mask) else False

            left_feat = _se3_to_xyzquat(left_poses[arm_idx]) if left_valid else np.zeros(7, dtype=np.float32)
            right_feat = _se3_to_xyzquat(right_poses[arm_idx]) if right_valid else np.zeros(7, dtype=np.float32)

            actions.append(np.concatenate([left_feat, right_feat]))
            valid_masks.append([left_valid, right_valid])

        action_arr = np.stack(actions, axis=0).astype(np.float32)
        valid_arr = np.array(valid_masks, dtype=bool)

        cur_arm_idx = _find_closest_timestamp(cam_timestamps[frame_idx], arm_ts)
        cur_lv = (left_arm_mask[cur_arm_idx] == 0) if cur_arm_idx < len(left_arm_mask) else False
        cur_rv = (right_arm_mask[cur_arm_idx] == 0) if cur_arm_idx < len(right_arm_mask) else False
        cur_left = _se3_to_xyzquat(left_poses[cur_arm_idx]) if cur_lv else np.zeros(7, dtype=np.float32)
        cur_right = _se3_to_xyzquat(right_poses[cur_arm_idx]) if cur_rv else np.zeros(7, dtype=np.float32)
        state = np.concatenate([cur_left, cur_right]).astype(np.float32)

        return action_arr, state, valid_arr, instruction

    def _extract_padded_per_hand_action_state(self, h5_path: str, frame_idx: int):
        """Extract padded_per_hand action/state (per-hand: eef(7) + joints(75) = 82 -> pad to 126)."""
        (cam_timestamps, arm_ts,
         left_poses, right_poses, left_arm_mask, right_arm_mask,
         left_hand_joints, right_hand_joints, left_hand_mask, right_hand_mask,
         hand_ts, instruction) = self._read_raw_data(h5_path, frame_idx)

        has_hand_data = left_hand_joints is not None and hand_ts is not None

        def _get_per_hand(arm_idx, hand_idx, is_left: bool):
            """Get per-hand feature: eef_pose(7) + hand_joints(75) = 82."""
            arm_mask = left_arm_mask if is_left else right_arm_mask
            arm_pose = left_poses if is_left else right_poses
            arm_valid = (arm_mask[arm_idx] == 0) if arm_idx < len(arm_mask) else False

            # EEF pose (7-dim, WXYZ quaternion)
            eef = _se3_to_xyzquat(arm_pose[arm_idx]) if arm_valid else np.zeros(7, dtype=np.float32)

            # Hand joints (75-dim)
            joints = np.zeros(WIYH_PER_HAND_ACTION_DIM - 7, dtype=np.float32)  # 75
            joints_valid = False
            if has_hand_data:
                h_mask = left_hand_mask if is_left else right_hand_mask
                h_joints = left_hand_joints if is_left else right_hand_joints
                if hand_idx < len(h_mask):
                    joints_valid = (h_mask[hand_idx] == 0)
                    if joints_valid:
                        joints = h_joints[hand_idx].astype(np.float32)

            # Combined: [eef(7), joints(75)] = 82
            if not arm_valid:
                eef = np.zeros(7, dtype=np.float32)
            feat = np.concatenate([eef, joints])  # [82]

            overall_valid = arm_valid  # arm must be valid; joints are best-effort
            return feat, overall_valid

        actions, valid_masks = [], []
        for i in range(self.num_video_frames):
            fi = min(frame_idx + i + 1, len(cam_timestamps) - 1)
            arm_idx = _find_closest_timestamp(cam_timestamps[fi], arm_ts)
            hand_idx = _find_closest_timestamp(cam_timestamps[fi], hand_ts) if has_hand_data else 0

            left_feat, left_valid = _get_per_hand(arm_idx, hand_idx, is_left=True)
            right_feat, right_valid = _get_per_hand(arm_idx, hand_idx, is_left=False)

            # Pad and concat: [left_pad(126), right_pad(126)]
            action = concat_per_hand(left_feat, right_feat, MAX_PER_HAND_ACTION_DIM)  # [450]
            actions.append(action)
            valid_masks.append([left_valid, right_valid])

        action_arr = np.stack(actions, axis=0).astype(np.float32)  # [F, 450]
        valid_arr = np.array(valid_masks, dtype=bool)

        # Current state
        cur_arm_idx = _find_closest_timestamp(cam_timestamps[frame_idx], arm_ts)
        cur_hand_idx = _find_closest_timestamp(cam_timestamps[frame_idx], hand_ts) if has_hand_data else 0
        cur_left, cur_lv = _get_per_hand(cur_arm_idx, cur_hand_idx, is_left=True)
        cur_right, cur_rv = _get_per_hand(cur_arm_idx, cur_hand_idx, is_left=False)
        state = concat_per_hand(cur_left, cur_right, MAX_PER_HAND_STATE_DIM).astype(np.float32)  # [450]

        return action_arr, state, valid_arr, instruction

    # ------------------------------------------------------------------
    # T5 embedding
    # ------------------------------------------------------------------
    @staticmethod
    def _hash_text(text: str) -> str:
        import hashlib
        return hashlib.sha1(text.encode("utf-8")).hexdigest()

    def _get_t5_embedding(self, instruction: str) -> torch.Tensor:
        if self.t5_mode == "none":
            return torch.zeros((512, 4096), dtype=torch.float32)

        key = self._hash_text(instruction)
        path = self.t5_cache_dir / f"{key}.pt"
        if path.exists():
            return torch.load(path, map_location="cpu", weights_only=True).float()

        assert self.t5_encoder is not None
        out = self.t5_encoder([instruction], self.t5_device)
        if isinstance(out, list):
            emb = out[0]
        elif isinstance(out, torch.Tensor):
            emb = out.squeeze(0)
        else:
            raise TypeError(f"Unexpected T5 encoder output: {type(out)}")
        emb = emb.detach().to("cpu").float()

        tmp = self.t5_cache_dir / f".tmp_{key}_{os.getpid()}.pt"
        torch.save(emb, tmp)
        os.replace(tmp, path)
        return emb

    # ------------------------------------------------------------------
    # __len__ / __getitem__
    # ------------------------------------------------------------------
    def __len__(self) -> int:
        return len(self.episodes)

    def __getitem__(self, idx: int) -> Optional[Dict[str, Any]]:
        for _ in range(self.max_attempts):
            try:
                ep_idx = random.randint(0, len(self.episodes) - 1)
                ep = self.episodes[ep_idx]
                n_frames = ep["n_frames"]
                frame_start = random.randint(0, n_frames - self.num_video_frames - 1)

                # Video frames
                frames = self._load_frames_window(ep["h5_path"], ep["action_dir"], frame_start)
                first_frame = frames[0]
                video_frames = frames[1:]

                # Action/state based on mode
                if self.action_mode == "wrist":
                    action, state, valid_mask, instruction = self._extract_wrist_action_state(
                        ep["h5_path"], frame_start)
                    if self.wrist_normalizer is not None:
                        action = self.wrist_normalizer.normalize_action(action)
                        state = self.wrist_normalizer.normalize_state(state)
                else:  # padded_per_hand
                    action, state, valid_mask, instruction = self._extract_padded_per_hand_action_state(
                        ep["h5_path"], frame_start)

                action_sequence = torch.tensor(action, dtype=torch.float32)
                current_state = torch.tensor(state, dtype=torch.float32)
                action_valid_mask = torch.tensor(valid_mask, dtype=torch.bool)

                language_embedding = self._get_t5_embedding(instruction)

                vlm_inputs = None
                if self.vlm_processor is not None:
                    from utils.vlm_utils import preprocess_vlm_messages
                    first_frame_pil = tensor_to_pil(first_frame)
                    vlm_inputs = preprocess_vlm_messages(instruction, first_frame_pil, self.vlm_processor)

                return {
                    "first_frame": first_frame,
                    "video_frames": video_frames,
                    "initial_state": current_state,
                    "action_sequence": action_sequence,
                    "language_embedding": language_embedding,
                    "vlm_inputs": vlm_inputs,
                    "action_valid_mask": action_valid_mask,
                }

            except Exception as e:
                logger.warning(f"[WIYH->Motus] sample retry due to error: {e}")
                continue

        return None

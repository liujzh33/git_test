#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Multi-Source Pre-training Dataset for Motus
Unified loader for: RoboCoin, RoboTwin2.0, GM-100, RC1.0, RDT, RoboMIND, RoboMIND2.0, RC2.0
+ Human datasets (VITRA, WIYH, EgoDex) via latent action encoding (450-dim -> 16-dim)
"""

import os
import sys
import random
import hashlib
import numpy as np
import torch
import torch.utils.data as data
from typing import Dict, Any, List, Optional, Tuple
import logging
from pathlib import Path
import warnings
import h5py

from data.utils.image_utils import (
    tensor_to_pil, apply_image_augmentation,
    load_video_frames, get_video_frame_count,
    resize_with_padding,
)
from utils.vlm_utils import preprocess_vlm_messages
from transformers import AutoProcessor

warnings.filterwarnings("ignore", category=FutureWarning, message=".*multichannel.*")

logger = logging.getLogger(__name__)


def unify_action_to_16(action: np.ndarray) -> np.ndarray:
    """
    统一 action 到 16 维: [left_joints(6) + pad(1) + left_grip(1) + right_joints(6) + pad(1) + right_grip(1)]

    | 原始 dim | 输入 layout              | 输出 16 维 layout              |
    |----------|-------------------------|--------------------------------|
    | 7        | [j0..j5, grip]          | [j0..j5, 0, grip, 0*8]         |
    | 8        | [j0..j6, grip]          | [j0..j6, grip, 0*8]            |
    | 14       | [j0..j5, g0, j7..j12, g1] | [j0..j5, 0, g0, j7..j12, 0, g1] |
    | 16       | 不变                    | 不变                           |
    """
    dim = action.shape[1]
    if dim == 16:
        return action
    elif dim == 14:
        # [j0..j5, g0, j6..j11, g1] -> [j0..j5, 0, g0, j6..j11, 0, g1]
        left_joints = action[:, :6]        # 6
        g0 = action[:, 6:7]                # 1
        right_joints = action[:, 7:13]     # 6 (j7..j12)
        g1 = action[:, 13:14]              # 1
        pad = np.zeros((action.shape[0], 1))
        return np.concatenate([left_joints, pad, g0, right_joints, pad, g1], axis=1)
    elif dim == 7:
        # [j0..j5, grip] -> [j0..j5, 0, grip, 0*8]
        left_joints = action[:, :6]        # 6
        grip = action[:, 6:7]              # 1
        pad1 = np.zeros((action.shape[0], 1))  # 1 pad after left joints
        right_pad = np.zeros((action.shape[0], 8))  # 8 zeros at end
        return np.concatenate([left_joints, pad1, grip, right_pad], axis=1)
    elif dim == 8:
        # [j0..j6, grip] -> [j0..j6, grip, 0*8]
        left_joints = action[:, :7]        # 7 joints
        grip = action[:, 7:8]              # 1 gripper
        right_pad = np.zeros((action.shape[0], 8))  # 8 zeros at end
        return np.concatenate([left_joints, grip, right_pad], axis=1)
    else:
        # 通用方式: 整体 pad 到 16
        return np.pad(action, ((0, 0), (0, 16 - dim)), mode='constant')


# =============================================================================
# Scanner functions for different data source patterns
# =============================================================================

def scan_robotwin2(source_dir: Path, robot_type: Optional[str] = None) -> List[Dict[str, str]]:
    """
    Pattern: RoboTwin2.0, RC1.0
    Structure: {split}/{task}/{metas,qpos,umt5_wan,videos}/episode_id.pt
    Meta file: {split}/{task}/metas/episode_id.txt
    For RoboTwin2.0: each dataset_dir is already robot-specific (ur5, franka, etc.)
    For RC1.0: use scan_rc2 instead (has robot_type filtering)
    robot_type param for API consistency (prefixes task_name when set)
    """
    episodes = []
    for split_dir in source_dir.iterdir():
        if not split_dir.is_dir():
            continue
        split_name = split_dir.name
        for task_dir in split_dir.iterdir():
            if not task_dir.is_dir():
                continue
            task_name = task_dir.name
            qpos_dir = task_dir / "qpos"
            videos_dir = task_dir / "videos"
            umt5_dir = task_dir / "umt5_wan"
            metas_dir = task_dir / "metas"

            if not (qpos_dir.exists() and videos_dir.exists() and umt5_dir.exists()):
                continue

            for qpos_file in qpos_dir.glob("*.pt"):
                ep_name = qpos_file.stem
                video_file = videos_dir / f"{ep_name}.mp4"
                lang_file = umt5_dir / f"{ep_name}.pt"
                meta_file = metas_dir / f"{ep_name}.txt" if metas_dir.exists() else None

                if video_file.exists() and lang_file.exists():
                    episodes.append({
                        'episode_name': ep_name,
                        'task_name': task_name,
                        'split': split_name,
                        'qpos_path': str(qpos_file),
                        'video_path': str(video_file),
                        'lang_path': str(lang_file),
                        'meta_path': str(meta_file) if meta_file and meta_file.exists() else None,
                    })
    return episodes


def scan_robocoin(source_dir: Path, robot_type: Optional[str] = None) -> List[Dict[str, str]]:
    """
    Pattern: RoboCoin
    Structure: {task}/{episode_id}/{metas,qpos,umt5_wan,videos}/episode_id.*
    T5 file: trajectory.pt (not {episode_id}.pt)

    robot_type: if set, only collect episodes where task name starts with robot_type prefix
    e.g., robot_type='AgiBot-g1' -> only tasks like 'AgiBot-g1_battery_storage_b'
    """
    episodes = []
    for task_dir in source_dir.iterdir():
        if not task_dir.is_dir():
            continue
        task_name = task_dir.name
        # Filter by robot_type if specified (e.g., only 'AgiBot-g1_*' tasks)
        if robot_type and not task_name.startswith(robot_type):
            continue
        for ep_dir in task_dir.iterdir():
            if not ep_dir.is_dir():
                continue
            ep_name = ep_dir.name
            qpos_dir = ep_dir / "qpos"
            videos_dir = ep_dir / "videos"
            umt5_dir = ep_dir / "umt5_wan"
            metas_dir = ep_dir / "metas"

            if not (qpos_dir.exists() and videos_dir.exists() and umt5_dir.exists()):
                continue

            # RoboCoin: files inside subdirs named same as episode, T5 is trajectory.pt
            qpos_file = qpos_dir / f"{ep_name}.pt"
            video_file = videos_dir / f"{ep_name}.mp4"
            lang_file = umt5_dir / "trajectory.pt"  # RoboCoin uses trajectory.pt
            meta_file = metas_dir / f"{ep_name}.txt" if metas_dir.exists() else None

            if qpos_file.exists() and video_file.exists() and lang_file.exists():
                episodes.append({
                    'episode_name': ep_name,
                    'task_name': task_name,
                    'split': 'default',
                    'robot_type': task_name.split('_')[0],  # e.g., 'Galaxea', 'AgiBot-g1', 'Cobot', etc.
                    'qpos_path': str(qpos_file),
                    'video_path': str(video_file),
                    'lang_path': str(lang_file),
                    'meta_path': str(meta_file) if meta_file and meta_file.exists() else None,
                })
    return episodes


def scan_gm100(source_dir: Path, robot_type: Optional[str] = None) -> List[Dict[str, str]]:
    """
    Pattern: GM-100
    Structure: {task}/{episode_id}/{metas,action,umt5_wan,videos}/episode_id.*
    Note: uses 'action' subdir instead of 'qpos'
    Each dataset_dir is already robot-specific subdir (e.g., GM-100_AgiBotG1_converted)
    """
    episodes = []
    for task_dir in source_dir.iterdir():
        if not task_dir.is_dir():
            continue
        task_name = task_dir.name
        for ep_dir in task_dir.iterdir():
            if not ep_dir.is_dir():
                continue
            ep_name = ep_dir.name
            # GM-100: some use 'action', some use 'qpos' subdir
            action_dir = ep_dir / "action"
            qpos_dir = ep_dir / "qpos"
            videos_dir = ep_dir / "videos"
            umt5_dir = ep_dir / "umt5_wan"
            metas_dir = ep_dir / "metas"

            # Determine which subdir exists for action/qpos data
            if action_dir.exists():
                state_dir = action_dir
                state_file = state_dir / f"{ep_name}.pt"
            elif qpos_dir.exists():
                state_dir = qpos_dir
                state_file = state_dir / f"{ep_name}.pt"
            else:
                continue

            if not (state_dir.exists() and videos_dir.exists() and umt5_dir.exists()):
                continue

            video_file = videos_dir / f"{ep_name}.mp4"
            lang_file = umt5_dir / "trajectory.pt"  # GM-100 uses trajectory.pt
            meta_file = metas_dir / f"{ep_name}.txt" if metas_dir.exists() else None

            if state_file.exists() and video_file.exists() and lang_file.exists():
                episodes.append({
                    'episode_name': ep_name,
                    'task_name': task_name,
                    'split': 'default',
                    'robot_type': robot_type,
                    'qpos_path': str(state_file),  # reuse qpos_path field for state (action/qpos)
                    'video_path': str(video_file),
                    'lang_path': str(lang_file),
                    'meta_path': str(meta_file) if meta_file and meta_file.exists() else None,
                })
    return episodes


def scan_rdt(source_dir: Path, robot_type: Optional[str] = None) -> List[Dict[str, str]]:
    """
    Pattern: RDT
    Structure: {task}/{episode_id}/{metas,qpos,umt5_wan,videos}/episode_id.*
    Single robot type (robot_type='default'), robot_type param for API consistency only
    """
    episodes = []
    for task_dir in source_dir.iterdir():
        if not task_dir.is_dir():
            continue
        task_name = task_dir.name
        for ep_dir in task_dir.iterdir():
            if not ep_dir.is_dir():
                continue
            ep_name = ep_dir.name
            qpos_dir = ep_dir / "qpos"
            videos_dir = ep_dir / "videos"
            umt5_dir = ep_dir / "umt5_wan"
            metas_dir = ep_dir / "metas"

            if not (qpos_dir.exists() and videos_dir.exists() and umt5_dir.exists()):
                continue

            qpos_file = qpos_dir / f"{ep_name}.pt"
            video_file = videos_dir / f"{ep_name}.mp4"
            lang_file = umt5_dir / "trajectory.pt"  # RDT uses trajectory.pt
            meta_file = metas_dir / f"{ep_name}.txt" if metas_dir.exists() else None

            if qpos_file.exists() and video_file.exists() and lang_file.exists():
                episodes.append({
                    'episode_name': ep_name,
                    'task_name': task_name,
                    'split': 'default',
                    'qpos_path': str(qpos_file),
                    'video_path': str(video_file),
                    'lang_path': str(lang_file),
                    'meta_path': str(meta_file) if meta_file and meta_file.exists() else None,
                })
    return episodes


def scan_robomind(source_dir: Path, robot_type: Optional[str] = None) -> List[Dict[str, str]]:
    """
    Pattern: RoboMIND
    Structure: {robot_type}/{task}/{task}/success_episodes/{train,val}/{episode_id}/{metas,qpos,umt5_wan,videos}/

    robot_type: if set, only collect episodes from this robot type (e.g., 'agilex_3rgb')
    """
    episodes = []
    for robot_dir in source_dir.iterdir():
        if not robot_dir.is_dir():
            continue
        # Filter by robot_type if specified
        if robot_type and robot_dir.name != robot_type:
            continue
        for task_dir in robot_dir.iterdir():
            if not task_dir.is_dir():
                continue
            episodes_dir = task_dir / task_dir.name / "success_episodes"
            if not episodes_dir.exists():
                continue
            for split_dir in episodes_dir.iterdir():
                if not split_dir.is_dir():
                    continue
                split_name = split_dir.name
                for ep_dir in split_dir.iterdir():
                    if not ep_dir.is_dir():
                        continue
                    ep_name = ep_dir.name
                    qpos_dir = ep_dir / "qpos"
                    videos_dir = ep_dir / "videos"
                    umt5_dir = ep_dir / "umt5_wan"
                    metas_dir = ep_dir / "metas"

                    if not (qpos_dir.exists() and videos_dir.exists() and umt5_dir.exists()):
                        continue

                    qpos_file = qpos_dir / f"{ep_name}.pt"
                    video_file = videos_dir / f"{ep_name}.mp4"
                    lang_file = umt5_dir / "trajectory.pt"  # RoboMIND uses trajectory.pt
                    meta_file = metas_dir / f"{ep_name}.txt" if metas_dir.exists() else None

                    if qpos_file.exists() and video_file.exists() and lang_file.exists():
                        episodes.append({
                            'episode_name': ep_name,
                            'task_name': task_dir.name,
                            'split': split_name,
                            'robot_type': robot_dir.name,
                            'qpos_path': str(qpos_file),
                            'video_path': str(video_file),
                            'lang_path': str(lang_file),
                            'meta_path': str(meta_file) if meta_file and meta_file.exists() else None,
                        })
    return episodes


def scan_robomind2(source_dir: Path, robot_type: Optional[str] = None) -> List[Dict[str, str]]:
    """
    Pattern: RoboMIND2.0
    Structure: {dataset}/{task}/{episode_id}/{metas,qpos,umt5_wan,videos}/
    Single robot type (Franka-sim), robot_type param for API consistency only
    """
    episodes = []
    for dataset_dir in source_dir.iterdir():
        if not dataset_dir.is_dir():
            continue
        for task_dir in dataset_dir.iterdir():
            if not task_dir.is_dir():
                continue
            task_name = task_dir.name
            for ep_dir in task_dir.iterdir():
                if not ep_dir.is_dir():
                    continue
                ep_name = ep_dir.name
                qpos_dir = ep_dir / "qpos"
                videos_dir = ep_dir / "videos"
                umt5_dir = ep_dir / "umt5_wan"
                metas_dir = ep_dir / "metas"

                if not (qpos_dir.exists() and videos_dir.exists() and umt5_dir.exists()):
                    continue

                qpos_file = qpos_dir / f"{ep_name}.pt"
                video_file = videos_dir / f"{ep_name}.mp4"
                lang_file = umt5_dir / "trajectory.pt"  # RoboMIND2.0 uses trajectory.pt
                meta_file = metas_dir / f"{ep_name}.txt" if metas_dir.exists() else None

                if qpos_file.exists() and video_file.exists() and lang_file.exists():
                    episodes.append({
                        'episode_name': ep_name,
                        'task_name': task_name,
                        'split': 'default',
                        'qpos_path': str(qpos_file),
                        'video_path': str(video_file),
                        'lang_path': str(lang_file),
                        'meta_path': str(meta_file) if meta_file and meta_file.exists() else None,
                    })
    return episodes


def scan_rc2(source_dir: Path, robot_type: Optional[str] = None) -> List[Dict[str, str]]:
    """
    Pattern: RC2.0 (RoboChallenge 2.0)
    Structure: {robot_type}/{task}/{episode_id}/{metas,qpos,umt5_wan,videos}/
    e.g., RoboChallenge2.0_ALOHA/pack_the_items/episode_000102/
    NOTE: T5 embedding is trajectory.pt (not {episode_id}.pt)
    """
    episodes = []
    for robot_dir in source_dir.iterdir():
        if not robot_dir.is_dir():
            continue
        robot_name = robot_dir.name  # e.g., RoboChallenge2.0_ALOHA
        if robot_type and robot_type not in robot_name:
            continue
        for task_dir in robot_dir.iterdir():
            if not task_dir.is_dir():
                continue
            task_name = task_dir.name
            for ep_dir in task_dir.iterdir():
                if not ep_dir.is_dir():
                    continue
                ep_name = ep_dir.name  # e.g., episode_000102
                qpos_dir = ep_dir / "qpos"
                videos_dir = ep_dir / "videos"
                umt5_dir = ep_dir / "umt5_wan"
                metas_dir = ep_dir / "metas"

                if not (qpos_dir.exists() and videos_dir.exists() and umt5_dir.exists()):
                    continue

                qpos_file = qpos_dir / f"{ep_name}.pt"
                video_file = videos_dir / f"{ep_name}.mp4"
                lang_file = umt5_dir / "trajectory.pt"  # RC2.0 uses trajectory.pt
                meta_file = metas_dir / f"{ep_name}.txt" if metas_dir.exists() else None

                if qpos_file.exists() and video_file.exists() and lang_file.exists():
                    episodes.append({
                        'episode_name': ep_name,
                        'task_name': f"{robot_name}_{task_name}",
                        'split': 'default',
                        'qpos_path': str(qpos_file),
                        'video_path': str(video_file),
                        'lang_path': str(lang_file),
                        'meta_path': str(meta_file) if meta_file and meta_file.exists() else None,
                    })
    return episodes


# Scanner registry
SCANNERS = {
    'robotwin2': scan_robotwin2,
    'robocoin': scan_robocoin,
    'gm100': scan_gm100,
    'rdt': scan_rdt,
    'robomind': scan_robomind,
    'robomind2': scan_robomind2,
    'rc2': scan_rc2,
}


# =============================================================================
# Human Episode Scanners
# =============================================================================

def _ensure_motus_imports():
    """Add MotusV2 paths to enable VITRA and wan.module imports.

    Since per_hand_dims.py now lives in MotusV2/data/, and VITRA is
    pip-installed from MotusV2/VITRA/, and bak/wan lives in MotusV2/bak/,
    this function adds:
      - MotusV2 root (parents[1]) for `from data.xxx import ...`
      - MotusV2/bak for `from wan.modules.t5 import ...`
    """
    motusv2_root = str(Path(__file__).resolve().parents[1])
    if motusv2_root not in sys.path:
        sys.path.append(motusv2_root)
    bak_root = os.path.join(motusv2_root, "bak")
    if bak_root not in sys.path:
        sys.path.append(bak_root)


def _vitra_paths(dataset_dir: str, dataset_name: str) -> Dict[str, str]:
    """Mirror VITRA's FrameDataset path mapping."""
    root = Path(dataset_dir)
    if dataset_name == "ego4d_cooking_and_cleaning":
        return dict(
            annotation_file=str(root / "Annotation/ego4d_cooking_and_cleaning/episode_frame_index.npz"),
            label_folder=str(root / "Annotation/ego4d_cooking_and_cleaning/episodic_annotations"),
            statistics_path=str(root / "Annotation/statistics/ego4d_cooking_and_cleaning_angle_statistics.json"),
            video_root=str(root / "Video/Ego4D_root"),
        )
    if dataset_name == "egoexo4d":
        return dict(
            annotation_file=str(root / "Annotation/egoexo4d/episode_frame_index.npz"),
            label_folder=str(root / "Annotation/egoexo4d/episodic_annotations"),
            statistics_path=str(root / "Annotation/statistics/egoexo4d_angle_statistics.json"),
            video_root=str(root / "Video/EgoExo4D_root"),
        )
    if dataset_name == "epic":
        return dict(
            annotation_file=str(root / "Annotation/epic/episode_frame_index.npz"),
            label_folder=str(root / "Annotation/epic/episodic_annotations"),
            statistics_path=str(root / "Annotation/statistics/epic_angle_statistics.json"),
            video_root=str(root / "Video/Epic-Kitchen_root"),
        )
    if dataset_name == "ssv2":
        return dict(
            annotation_file=str(root / "Annotation/ssv2/episode_frame_index.npz"),
            label_folder=str(root / "Annotation/ssv2/episodic_annotations"),
            statistics_path=str(root / "Annotation/statistics/ssv2_angle_statistics.json"),
            video_root=str(root / "Video/Somethingsomething-v2_root"),
        )
    if dataset_name == "ego4d_other":
        return dict(
            annotation_file=str(root / "Annotation/ego4d_other/episode_frame_index.npz"),
            label_folder=str(root / "Annotation/ego4d_other/episodic_annotations"),
            statistics_path=str(root / "Annotation/statistics/ego4d_other_angle_statistics.json"),
            video_root=str(root / "Video/Ego4D_root"),
        )
    raise ValueError(f"Unknown VITRA dataset_name: {dataset_name}")


def scan_vitra(dataset_dir: Path, name: str = '', clip_len=None,
               wan_path: str = './pretrained_models',
               t5_cache_dir: str = './t5_cache_human',
               min_frames: int = 10) -> Tuple[Dict, Any]:
    """
    Scan VITRA dataset: create EpisodicDatasetCore once (fast — only loads .npz index),
    return a virtual entry that represents the entire sub-dataset.

    VITRA uses frame-level indexing (index_frame_pair), so we keep a single virtual entry
    and randomly sample a frame pair at runtime, then use _calculate_sampling_indices
    with the episode's total_frames.

    Returns:
        (virtual_entry_dict, core_instance)
    """
    _ensure_motus_imports()
    from data.human.vitra_core import VitraEpisodeCore

    paths = _vitra_paths(str(dataset_dir), name)
    core = VitraEpisodeCore(
        video_root=paths["video_root"],
        annotation_file=paths["annotation_file"],
        label_folder=paths["label_folder"],
        statistics_path=paths["statistics_path"],
        augmentation=False,
        flip_augmentation=False,
        set_none_ratio=0.0,
        action_type="angle",
        use_rel=False,
        clip_len=clip_len,
        action_past_window_size=0,
        action_future_window_size=0,
        image_past_window_size=0,
        image_future_window_size=0,
        load_images=False,
    )

    # Ensure normalizer exists
    if hasattr(core, 'data_statistics') and core.data_statistics is not None:
        core.set_global_data_statistics(core.data_statistics)

    # Virtual entry — represents all frames in this sub-dataset
    virtual_entry = {
        'is_human': True,
        'human_type': 'vitra',
        'dataset_dir': str(dataset_dir),
        'name': name,
        'clip_len': clip_len,
        'wan_path': wan_path,
        't5_cache_dir': t5_cache_dir,
        'total_frames': len(core),  # number of valid (episode, frame) pairs
        'episode_name': f'vitra_{name}',
    }

    return virtual_entry, core


def scan_wiyh(dataset_dir: Path, camera_name: str = 'lf_chest_fisheye',
              wan_path: str = './pretrained_models',
              t5_cache_dir: str = './t5_cache_human_wiyh',
              min_frames: int = 10) -> List[Dict]:
    """Scan WIYH dataset and return per-episode entries."""
    episodes = []
    root = Path(dataset_dir)
    for scene_dir in sorted(root.iterdir()):
        if not scene_dir.is_dir():
            continue
        if not (scene_dir / "task.json").exists() and not any(
            (scene_dir / d).is_dir() and d.startswith("action_")
            for d in os.listdir(scene_dir)
        ):
            continue

        for action_dir in sorted(scene_dir.iterdir()):
            if not action_dir.is_dir() or not action_dir.name.startswith("action_"):
                continue
            h5_path = action_dir / "dataset.hdf5"
            if not h5_path.exists():
                continue

            try:
                with h5py.File(str(h5_path), "r") as f:
                    key = f"observation/camera/{camera_name}/filepath"
                    if key in f:
                        n_frames = len(f[key])
                    else:
                        key_ts = f"observation/camera/{camera_name}/timestamp"
                        if key_ts in f:
                            n_frames = len(f[key_ts])
                        else:
                            continue

                if n_frames < min_frames:
                    continue

                episodes.append({
                    'is_human': True,
                    'human_type': 'wiyh',
                    'h5_path': str(h5_path),
                    'action_dir': str(action_dir),
                    'scene_dir': str(scene_dir),
                    'total_frames': n_frames,
                    'camera_name': camera_name,
                    'wan_path': wan_path,
                    't5_cache_dir': t5_cache_dir,
                    'episode_name': f'wiyh_{scene_dir.name}_{action_dir.name}',
                })
            except Exception as e:
                logger.warning(f"[scan_wiyh] Skipping {h5_path}: {e}")

    return episodes


def scan_egodex(dataset_dir: Path, splits: List[str] = None,
                wan_path: str = './pretrained_models',
                t5_cache_dir: str = './t5_cache_human_egodex',
                min_frames: int = 10) -> Tuple[List[Dict], Dict[str, List[str]]]:
    """
    Scan EgoDex dataset and return per-episode entries + cached joint names.

    Returns:
        (episodes_list, joint_names_dict) with keys 'left' and 'right'
    """
    if splits is None:
        splits = ["part1", "part2", "part3", "part4", "part5", "extra", "test"]

    episodes = []
    joint_names = {'left': [], 'right': []}

    root = Path(dataset_dir)
    for split_name in splits:
        split_dir = root / split_name
        if not split_dir.exists():
            continue
        for task_dir in sorted(split_dir.iterdir()):
            if not task_dir.is_dir():
                continue
            for h5_file in sorted(task_dir.glob("*.hdf5")):
                mp4_file = h5_file.with_suffix(".mp4")
                if not mp4_file.exists():
                    continue
                try:
                    with h5py.File(str(h5_file), "r") as f:
                        n_frames = f["/transforms/leftHand"].shape[0]

                        # Cache joint names from first episode
                        if not joint_names['left']:
                            all_keys = list(f["transforms"].keys())
                            joint_names['left'] = sorted(
                                [k for k in all_keys if k.startswith("left") and
                                 ("Hand" in k or "Finger" in k or "Thumb" in k)]
                            )
                            joint_names['right'] = sorted(
                                [k for k in all_keys if k.startswith("right") and
                                 ("Hand" in k or "Finger" in k or "Thumb" in k)]
                            )

                    if n_frames < min_frames:
                        continue

                    episodes.append({
                        'is_human': True,
                        'human_type': 'egodex',
                        'h5_path': str(h5_file),
                        'mp4_path': str(mp4_file),
                        'task_name': task_dir.name,
                        'total_frames': n_frames,
                        'wan_path': wan_path,
                        't5_cache_dir': t5_cache_dir,
                        'episode_name': f'egodex_{task_dir.name}_{h5_file.stem}',
                    })
                except Exception as e:
                    logger.warning(f"[scan_egodex] Skipping {h5_file}: {e}")

    return episodes, joint_names


# =============================================================================
# Dataset Class
# =============================================================================

class MultiSourcePretrainDataset(data.Dataset):
    """
    Unified multi-source pre-training dataset.

    Supported sources:
    - RoboCoin: {task}/{episode}/{metas,qpos,umt5_wan,videos}/
    - RoboTwin2.0, RC1.0: {split}/{task}/{metas,qpos,umt5_wan,videos}/episode_id.pt
    - GM-100: {task}/{episode}/{metas,action,umt5_wan,videos}/
    - RDT: {task}/{episode}/{metas,qpos,umt5_wan,videos}/
    - RoboMIND: {robot}/{task}/{task}/success_episodes/{train,val}/{episode}/
    - RoboMIND2.0: {dataset}/{task}/{episode}/

    Output format (compatible with existing datasets):
    {
        'first_frame':       # [C, H, W] tensor
        'video_frames':      # [F, C, H, W] tensor
        'action_sequence':   # [F*ratio, 16] tensor (unified to 16-dim)
        'language_embedding':# [seq_len, 4096] tensor
        'initial_state':     # [16] tensor
    }
    """

    def __init__(
        self,
        sources: List[Dict[str, Any]],
        global_downsample_rate: int = 3,
        video_action_freq_ratio: int = 5,
        num_video_frames: int = 3,
        video_size: Tuple[int, int] = (360, 320),
        max_episodes: Optional[int] = None,
        val: bool = False,
        image_aug: bool = False,
        max_action_dim: int = 16,
        vlm_checkpoint_path: Optional[str] = None,
        # Human data VAE encoder configuration
        human_vae_checkpoint_path: Optional[str] = None,
        human_vae_latent_dim: int = 16,
        human_vae_hidden_dim: int = 256,
        human_vae_action_dim: int = 450,
        human_vae_device: str = "cuda",
        human_latent_scale: float = 0.3,
    ):
        """
        Args:
            sources: List of source configs, each containing:
                - dataset_dir: str
                - pattern: str ('robotwin2', 'robocoin', 'gm100', 'rdt', 'robomind', 'robomind2')
                - weight: float (sampling weight)
                For human sources, additionally:
                - pattern: 'human'
                - human_type: 'vitra' | 'wiyh' | 'egodex'
                - name: str (for vitra: 'ssv2', 'epic', etc.)
                - clip_len: int (optional, for vitra video splitting)
            global_downsample_rate: e.g. 3 for 30Hz->10Hz
            video_action_freq_ratio: Video:Action frequency ratio
            num_video_frames: Number of video frames to predict
            video_size: (H, W)
            max_episodes: Max total episodes to load (for debugging)
            val: Validation mode (no augmentation)
            image_aug: Apply image augmentation
            max_action_dim: Target action dimension (default 16)
            human_vae_checkpoint_path: Path to pretrained VAE for 450->16 encoding
            human_vae_latent_dim: VAE latent dimension
            human_vae_hidden_dim: VAE hidden dimension
            human_vae_action_dim: VAE input action dimension (450 for padded_per_hand)
            human_vae_device: Device for VAE encoder
            human_latent_scale: Scale factor for VAE latent outputs to match robot action range.
                VAE latent values (abs_mean~1.0) are larger than robot actions (abs_mean~0.5),
                so scaling down prevents human action loss from dominating training.
        """
        self.global_downsample_rate = global_downsample_rate
        self.video_action_freq_ratio = video_action_freq_ratio
        self.num_video_frames = num_video_frames
        self.video_size = video_size
        self.val = val
        self.image_aug = image_aug and not val
        self.max_action_dim = max_action_dim

        self.action_chunk_size = num_video_frames * video_action_freq_ratio

        # Store VLM checkpoint path (optional, for human datasets too)
        self.vlm_checkpoint_path_opt = vlm_checkpoint_path

        # Human VAE encoder configuration
        self.human_vae_checkpoint_path = human_vae_checkpoint_path
        self.human_vae_latent_dim = human_vae_latent_dim
        self.human_vae_hidden_dim = human_vae_hidden_dim
        self.human_vae_action_dim = human_vae_action_dim
        self.human_vae_device = human_vae_device
        self.human_latent_scale = human_latent_scale
        self.human_vae_encoder = None

        # Initialize VLM processor for complete VLM processing in dataset
        self.vlm_processor = None
        if vlm_checkpoint_path is not None:
            try:
                self.vlm_processor = AutoProcessor.from_pretrained(vlm_checkpoint_path)
                logger.info(f"VLM processor loaded from {vlm_checkpoint_path}")
            except Exception as e:
                logger.warning(f"Failed to load VLM processor from {vlm_checkpoint_path}: {e}")
                logger.warning("VLM processing will be disabled for this dataset instance")
        else:
            logger.info("VLM checkpoint path not provided, VLM processing disabled")

        # Collect all episodes from all sources
        self.episodes = []  # List of (episode_data, source_weight)
        self._has_human_sources = False
        total_found = 0

        # Registry for shared human dataset objects (VITRA cores, EgoDex joint names, etc.)
        self._human_data_registry = {}

        for source in sources:
            dataset_dir = Path(source['dataset_dir'])
            pattern = source.get('pattern', 'robotwin2')
            weight = source.get('weight', 1.0)
            robot_type = source.get('robot_type', None)

            # Handle human data sources — scan real episodes
            if pattern == 'human':
                self._has_human_sources = True
                human_type = source.get('human_type', 'vitra')
                name = source.get('name', '')
                wan_path = source.get('wan_path', './pretrained_models')
                t5_cache_dir = source.get('t5_cache_dir', f'./t5_cache_human_{human_type}')
                camera_name = source.get('camera_name', 'lf_chest_fisheye')

                try:
                    if human_type == 'vitra':
                        virtual_entry, core = scan_vitra(
                            dataset_dir, name=name,
                            clip_len=source.get('clip_len'),
                            wan_path=wan_path, t5_cache_dir=t5_cache_dir,
                            min_frames=self.action_chunk_size * self.global_downsample_rate + 2,
                        )
                        # Store core instance for later data access
                        reg_key = f"vitra_{dataset_dir}_{name}"
                        self._human_data_registry[reg_key] = {
                            'type': 'vitra',
                            'core': core,
                            'dataset_dir': str(dataset_dir),
                            'name': name,
                        }
                        # Add virtual entry — represents all frames in this sub-dataset
                        # Entry count will be adjusted by _rebalance_human_robot_ratio()
                        self.episodes.append((virtual_entry, 1.0))
                        logger.info(f"[human/vitra] {dataset_dir} (name={name}): "
                                     f"{len(core)} frame pairs")
                    elif human_type == 'wiyh':
                        eps = scan_wiyh(
                            dataset_dir, camera_name=camera_name,
                            wan_path=wan_path, t5_cache_dir=t5_cache_dir,
                            min_frames=self.action_chunk_size * self.global_downsample_rate + 2,
                        )
                        # Add entries proportional to total_frames per episode
                        # (so longer episodes get sampled more within WIYH's allocation)
                        # Total count will be adjusted by _rebalance_human_robot_ratio()
                        physical_chunk = self.action_chunk_size * self.global_downsample_rate
                        total_human_frames = 0
                        for ep in eps:
                            n_chunks = max(1, ep['total_frames'] // physical_chunk)
                            total_human_frames += ep['total_frames']
                            for _ in range(n_chunks):
                                self.episodes.append((ep, 1.0))
                        logger.info(f"[human/wiyh] {dataset_dir}: found {len(eps)} episodes, "
                                     f"~{total_human_frames} frames")
                    elif human_type == 'egodex':
                        eps, joint_names = scan_egodex(
                            dataset_dir,
                            splits=source.get('splits'),
                            wan_path=wan_path, t5_cache_dir=t5_cache_dir,
                            min_frames=self.action_chunk_size * self.global_downsample_rate + 2,
                        )
                        # Store joint names for later data access
                        self._human_data_registry['egodex_joint_names'] = joint_names
                        # Add entries proportional to total_frames per episode
                        # Total count will be adjusted by _rebalance_human_robot_ratio()
                        physical_chunk = self.action_chunk_size * self.global_downsample_rate
                        total_human_frames = 0
                        for ep in eps:
                            n_chunks = max(1, ep['total_frames'] // physical_chunk)
                            total_human_frames += ep['total_frames']
                            for _ in range(n_chunks):
                                self.episodes.append((ep, 1.0))
                        logger.info(f"[human/egodex] {dataset_dir}: found {len(eps)} episodes, "
                                     f"~{total_human_frames} frames")
                    else:
                        logger.warning(f"Unknown human_type: {human_type}, skipping")
                        continue
                except Exception as e:
                    logger.warning(f"Failed to scan human dataset {human_type} at {dataset_dir}: {e}")
                continue

            if not dataset_dir.exists():
                logger.warning(f"Source dir not found: {dataset_dir}")
                continue

            scanner = SCANNERS.get(pattern)
            if scanner is None:
                logger.warning(f"Unknown pattern '{pattern}' for {dataset_dir}, skipping")
                continue

            eps = scanner(dataset_dir, robot_type=robot_type)
            logger.info(f"[{pattern}] {dataset_dir.name} (robot_type={robot_type}): found {len(eps)} episodes, weight={weight}")
            for ep in eps:
                self.episodes.append((ep, weight))
            total_found += len(eps)

        if max_episodes is not None and total_found > max_episodes:
            # Weighted sampling to limit
            weights = [w for _, w in self.episodes]
            total_w = sum(weights)
            probs = [w / total_w for w in weights]
            indices = np.random.choice(len(self.episodes), max_episodes, replace=False, p=probs)
            self.episodes = [self.episodes[i] for i in indices]
            logger.info(f"Limited to {max_episodes} episodes (from {total_found})")

        # Initialize human VAE encoder if human sources exist
        # Always use CPU — the encoder runs inside DataLoader forked workers
        # where CUDA cannot be re-initialized. The model is tiny (450→256→16)
        # and CPU encoding is negligible.
        if self._has_human_sources and human_vae_checkpoint_path is not None:
            from data.latent_action.human_latent_action_encoder import get_shared_human_encoder
            self.human_vae_encoder = get_shared_human_encoder(
                checkpoint_path=human_vae_checkpoint_path,
                latent_dim=human_vae_latent_dim,
                hidden_dim=human_vae_hidden_dim,
                action_dim=human_vae_action_dim,
                freeze=True,
                device="cpu",
            )
            logger.info(f"Human VAE encoder loaded from {human_vae_checkpoint_path} (CPU mode for DataLoader workers)")
        elif self._has_human_sources:
            logger.warning("Human sources present but no VAE checkpoint path provided!")

        # Re-weight human entries so that human:robot = 1:1 overall,
        # and within human: VITRA:EgoDex:WIYH = 4:2:1.
        # Robot entry counts are left untouched.
        if self._has_human_sources:
            self._rebalance_human_robot_ratio()

        # Lazy-init for T5 encoder (shared singleton for human language embeddings)
        self._t5_encoder = None
        self._t5_encoder_config = None

        self.total_episodes = len(self.episodes)
        logger.info(f"Total episodes: {self.total_episodes} (has_human={self._has_human_sources})")

    def _rebalance_human_robot_ratio(self):
        """Re-weight human entries so that human:robot = 1:1 overall sampling,
        and within human: VITRA:EgoDex:WIYH = 4:2:1.

        Since __getitem__ uses random.choice (uniform over entries),
        sampling probability = entry_count / total_entries.
        We adjust human entry counts to achieve the desired ratios.
        Robot entries are never modified.
        """
        robot_entries = [(ep, w) for ep, w in self.episodes if not ep.get('is_human')]
        human_entries = [(ep, w) for ep, w in self.episodes if ep.get('is_human')]

        n_robot = len(robot_entries)
        n_human = len(human_entries)

        if n_robot == 0 or n_human == 0:
            logger.warning(f"Cannot rebalance: robot={n_robot}, human={n_human}")
            return

        logger.info(f"Before rebalance: robot entries={n_robot}, human entries={n_human}, "
                     f"ratio human:robot = {n_human/n_robot:.4f}")

        # --- Step 1: Within human, group by sub-type ---
        vitra_entries = [e for e in human_entries if e[0].get('human_type') == 'vitra']
        egodex_entries = [e for e in human_entries if e[0].get('human_type') == 'egodex']
        wiyh_entries = [e for e in human_entries if e[0].get('human_type') == 'wiyh']
        other_human = [e for e in human_entries if e[0].get('human_type') not in ('vitra', 'egodex', 'wiyh')]

        n_vitra = len(vitra_entries)
        n_egodex = len(egodex_entries)
        n_wiyh = len(wiyh_entries)

        logger.info(f"  Human breakdown: VITRA={n_vitra}, EgoDex={n_egodex}, WIYH={n_wiyh}")

        # Target internal ratios: VITRA:EgoDex:WIYH = 4:2:1
        # We need to rescale each group so that:
        #   n_vitra_new / n_human_new = 4/7
        #   n_egodex_new / n_human_new = 2/7
        #   n_wiyh_new / n_human_new = 1/7
        # where n_human_new = n_robot (to achieve 1:1 overall)

        target_human_total = n_robot  # 1:1 ratio
        target_vitra = int(target_human_total * 4 / 7)
        target_egodex = int(target_human_total * 2 / 7)
        target_wiyh = int(target_human_total * 1 / 7)

        def _resample(entries, target_count):
            """Resample entry list to target_count by duplication or subsampling."""
            n = len(entries)
            if n == 0 or target_count == 0:
                return []
            if target_count <= n:
                # Subsample uniformly
                indices = np.random.choice(n, target_count, replace=False)
                return [entries[i] for i in indices]
            else:
                # Duplicate with random offsets
                result = list(entries)  # keep all originals
                extra = target_count - n
                indices = np.random.choice(n, extra, replace=True)
                result.extend(entries[i] for i in indices)
                return result

        new_vitra = _resample(vitra_entries, target_vitra)
        new_egodex = _resample(egodex_entries, target_egodex)
        new_wiyh = _resample(wiyh_entries, target_wiyh)

        # Rebuild self.episodes: robot (unchanged) + resampled human
        self.episodes = robot_entries + new_vitra + new_egodex + new_wiyh + other_human

        actual_human = len(new_vitra) + len(new_egodex) + len(new_wiyh) + len(other_human)
        logger.info(f"After rebalance: robot={n_robot}, human={actual_human} "
                     f"(VITRA={len(new_vitra)}, EgoDex={len(new_egodex)}, WIYH={len(new_wiyh)}), "
                     f"ratio human:robot = {actual_human/n_robot:.4f}")

    def _calculate_sampling_indices(self, total_frames: int) -> Tuple[int, List[int], List[int]]:
        """Calculate condition frame, video indices, action indices."""
        physical_chunk_size = self.action_chunk_size * self.global_downsample_rate
        max_condition_idx = total_frames - physical_chunk_size - 1

        if max_condition_idx < 0:
            condition_frame_idx = 0
        else:
            condition_frame_idx = random.randint(0, max_condition_idx)

        # Action indices
        action_indices = []
        for i in range(self.action_chunk_size):
            action_idx = condition_frame_idx + (i + 1) * self.global_downsample_rate
            action_indices.append(min(action_idx, total_frames - 1))

        # Video indices
        video_indices = []
        for i in range(self.num_video_frames):
            action_step = (i + 1) * self.video_action_freq_ratio - 1
            if action_step < len(action_indices):
                video_indices.append(action_indices[action_step])
            else:
                video_indices.append(action_indices[-1])

        return condition_frame_idx, video_indices, action_indices

    def _load_action(self, qpos_path: str, action_indices: List[int], initial_state_idx: int, robot_type: Optional[str] = None) -> Tuple[torch.Tensor, torch.Tensor]:
        """Load and unify action data to 16-dim."""
        qpos_data = torch.load(qpos_path, map_location='cpu').numpy()  # [T, D]

        # Unify to 16-dim
        qpos_data = unify_action_to_16(qpos_data)

        # Binarize gripper for RoboMIND/agilex_3rgb: >2.5 -> 1, <2.5 -> 0
        # After unify_action_to_16, gripper positions are at index 7 (left) and 15 (right)
        if robot_type == 'agilex_3rgb':
            gripper_indices = [7, 15]  # left_grip, right_grip in 16-dim layout
            for idx in gripper_indices:
                qpos_data[:, idx] = (qpos_data[:, idx] > 2.5).astype(np.float32)

        # Scale gripper for GM-100 variants (gripper at index 7 and 15 in 16-dim layout)
        if robot_type == 'AgileX':
            # dim6/13 [0, 0.08] -> *10 -> [0, 0.8]
            for idx in [7, 15]:
                qpos_data[:, idx] = qpos_data[:, idx] * 10.0
        elif robot_type == 'GalaxeaR1Pro':
            # dim7/15 [0, 80] -> /100 -> [0, 0.8]
            for idx in [7, 15]:
                qpos_data[:, idx] = qpos_data[:, idx] / 100.0

        # Normalize gripper for RoboCoin/Galaxea (dual-arm, gripper at index 7 and 15 after 14->16 dim unification)
        # Original 14-dim: [j0..j5, g0, j7..j12, g1] -> g0 at index 6, g1 at index 13
        # After unify: g0 -> index 7, g1 -> index 15
        # Range [0, 100] with some negative values, normalize by /100
        if robot_type == 'Galaxea' or robot_type == 'R1':
            for idx in [7, 15]:
                qpos_data[:, idx] = qpos_data[:, idx] / 100.0

        if initial_state_idx >= len(qpos_data):
            initial_state_idx = len(qpos_data) - 1
        initial_state = torch.from_numpy(qpos_data[initial_state_idx]).float()

        actions = []
        for idx in action_indices:
            if idx >= len(qpos_data):
                actions.append(qpos_data[-1])
            else:
                actions.append(qpos_data[idx])
        action_sequence = torch.from_numpy(np.stack(actions)).float()
        return initial_state, action_sequence

    def _load_language_embedding(self, lang_path: str) -> torch.Tensor:
        """Load pre-encoded T5 language embedding."""
        try:
            emb_data = torch.load(lang_path, map_location='cpu')
            # emb_data may be a list of tensors or a single tensor
            if isinstance(emb_data, list):
                emb = emb_data[0]  # Take first
            else:
                emb = emb_data
            if emb.dim() == 3:
                emb = emb.squeeze(0)
            return emb
        except Exception as e:
            logger.error(f"Error loading T5 embedding from {lang_path}: {e}")
            # Return zeros as fallback
            return torch.zeros(512, 4096)

    def _load_meta_text(self, meta_path: str) -> str:
        """Load text instruction from meta file (first non-empty line)."""
        try:
            with open(meta_path, 'r', encoding='utf-8') as f:
                lines = [line.strip() for line in f if line.strip()]
            return lines[0] if lines else ""
        except Exception as e:
            logger.warning(f"Error loading meta text from {meta_path}: {e}")
            return ""

    # Human instruction prefixes (matching robot prompt style)
    _HUMAN_INSTRUCTION_PREFIX = {
        'vitra': (
            "The whole scene is in a realistic style captured from a head-mounted camera "
            "that naturally shakes and moves with the person. "
            "This is human hand demonstration data. "
            "The human hand is currently performing the following task: "
        ),
        'egodex': (
            "The whole scene is in a realistic style captured from a head-mounted camera "
            "that naturally shakes and moves with the person. "
            "This is human hand demonstration data. "
            "The human hand is currently performing the following task: "
        ),
        'wiyh': (
            "The whole scene is in a realistic style captured from a chest-mounted fisheye camera "
            "with a wide-angle distorted perspective. "
            "This is human hand demonstration data. "
            "The human hand is currently performing the following task: "
        ),
    }

    def _format_human_instruction(self, instruction: str, human_type: str) -> str:
        """Prepend human-specific context prefix to the raw instruction."""
        prefix = self._HUMAN_INSTRUCTION_PREFIX.get(human_type, "")
        return f"{prefix}{instruction}"

    def _load_vlm_inputs(self, text_instruction: str, first_frame: torch.Tensor) -> Optional[Dict[str, Any]]:
        """Generate VLM inputs from text instruction and first frame."""
        if self.vlm_processor is None:
            return None
        # Use a placeholder if no instruction — model requires vlm_inputs
        if not text_instruction:
            text_instruction = "perform the task"
        try:
            first_frame_pil = tensor_to_pil(first_frame)
            return preprocess_vlm_messages(text_instruction, first_frame_pil, self.vlm_processor)
        except Exception as e:
            logger.warning(f"Error generating VLM inputs: {e}")
            return None

    def __len__(self) -> int:
        return self.total_episodes * 10

    def __getitem__(self, idx: int) -> Optional[Dict[str, Any]]:
        """Get a training sample (robot or human)."""
        max_attempts = 8
        for _ in range(max_attempts):
            if not self.episodes:
                return None
            episode_data, weight = random.choice(self.episodes)

            # Dispatch to human data loader if this is a human episode
            if episode_data.get('is_human'):
                sample = self._get_human_sample(episode_data)
                if sample is not None:
                    return sample
                continue

            try:
                total_frames = get_video_frame_count(episode_data['video_path'])
                if total_frames < 2:
                    continue

                condition_frame_idx, video_indices, action_indices = self._calculate_sampling_indices(total_frames)

                first_frame = load_video_frames(episode_data['video_path'], [condition_frame_idx], self.video_size)
                video_frames = load_video_frames(episode_data['video_path'], video_indices, self.video_size)
                initial_state, action_sequence = self._load_action(episode_data['qpos_path'], action_indices, condition_frame_idx, episode_data.get('robot_type'))
                language_embedding = self._load_language_embedding(episode_data['lang_path'])

                # VLM processing: load meta text and generate vlm_inputs
                meta_text = ""
                vlm_inputs = None
                if episode_data.get('meta_path'):
                    meta_text = self._load_meta_text(episode_data['meta_path'])
                if self.vlm_processor is not None:
                    vlm_inputs = self._load_vlm_inputs(meta_text, first_frame.squeeze(0))

                return {
                    'first_frame': first_frame.squeeze(0),
                    'video_frames': video_frames,
                    'initial_state': initial_state,
                    'action_sequence': action_sequence,
                    'language_embedding': language_embedding,
                    'vlm_inputs': vlm_inputs,
                }

            except Exception as e:
                logger.warning(f"Retry ({episode_data.get('episode_name', '?')}): {e}")
                continue

        return None

    # =========================================================================
    # Human Data Loading (VITRA / WIYH / EgoDex via Latent Action Encoding)
    # Uses _calculate_sampling_indices for consistent sampling with robot data
    # =========================================================================

    def _get_human_sample(self, episode_data: Dict) -> Optional[Dict[str, Any]]:
        """Load a human data sample using _calculate_sampling_indices, then VAE encode 450→16."""
        human_type = episode_data.get('human_type', '')

        if human_type == 'vitra':
            # VITRA uses virtual entries — need to pick a random frame pair first,
            # then get the episode's total_frames for _calculate_sampling_indices
            return self._get_vitra_sample_with_sampling(episode_data)

        # WIYH / EgoDex: per-episode entries with total_frames already known
        total_frames = episode_data['total_frames']
        condition_idx, video_indices, action_indices = self._calculate_sampling_indices(total_frames)

        try:
            if human_type == 'wiyh':
                sample = self._load_wiyh_sample(episode_data, condition_idx, video_indices, action_indices)
            elif human_type == 'egodex':
                sample = self._load_egodex_sample(episode_data, condition_idx, video_indices, action_indices)
            else:
                logger.warning(f"Unknown human_type: {human_type}")
                return None
        except Exception as e:
            logger.warning(f"Human sample retry ({episode_data.get('episode_name', '?')}): {e}")
            return None

        if sample is None:
            return None

        # VAE encode 450→16
        sample = self._encode_human_sample(sample)
        return sample

    def _get_vitra_sample_with_sampling(self, episode_data: Dict) -> Optional[Dict[str, Any]]:
        """VITRA-specific: pick random frame pair, then use _calculate_sampling_indices."""
        _ensure_motus_imports()

        # Get the cached EpisodicDatasetCore
        reg_key = f"vitra_{episode_data['dataset_dir']}_{episode_data['name']}"
        if reg_key not in self._human_data_registry:
            logger.error(f"VITRA core not found in registry: {reg_key}")
            return None
        core = self._human_data_registry[reg_key]['core']

        for _ in range(8):  # retry
            try:
                # Randomly pick a frame pair (like old adapter)
                data_id = random.randint(0, len(core) - 1)
                corr = core.index_frame_pair[data_id]
                episode_id = core.index_to_episode_id[corr[0]]
                frame_id = int(corr[1])

                # Get this episode's total_frames
                epi, _, _ = core._load_or_cache_episode(episode_id)
                total_frames = len(epi["extrinsics"])

                # Apply the SAME sampling logic as robot data
                condition_idx, video_indices, action_indices = self._calculate_sampling_indices(total_frames)

                sample = self._load_vitra_sample(
                    episode_data, episode_id, core,
                    condition_idx, video_indices, action_indices,
                )
                if sample is not None:
                    sample = self._encode_human_sample(sample)
                    return sample
            except Exception as e:
                logger.warning(f"VITRA sample retry: {e}")
                continue

        return None

    def _encode_human_sample(self, sample: Dict) -> Dict:
        """
        Encode a human sample's 450-dim action/state to 16-dim latent
        using the VAE encoder, then scale to match robot action range.
        """
        action_sequence = sample['action_sequence']  # [F, 450]
        initial_state = sample.get('initial_state')  # [450] or None

        # Encode action sequence: [F, 450] -> [F, 16]
        # Encoder is on CPU (DataLoader workers are forked — no CUDA allowed)
        if self.human_vae_encoder is not None:
            action_sequence = self.human_vae_encoder.encode_batch(action_sequence)  # [F, 16]

        # Encode initial state: [450] -> [16]
        if initial_state is not None and self.human_vae_encoder is not None:
            initial_state = self.human_vae_encoder.encode_batch(
                initial_state.unsqueeze(0)
            ).squeeze(0)  # [16]
        elif initial_state is None:
            initial_state = torch.zeros(self.max_action_dim)

        # Scale latent to match robot action magnitude.
        # VAE latent abs_mean ~ 1.0, robot action abs_mean ~ 0.5.
        # Without scaling, human action MSE >> robot action MSE.
        if self.human_latent_scale != 1.0:
            action_sequence = action_sequence * self.human_latent_scale
            initial_state = initial_state * self.human_latent_scale

        sample['action_sequence'] = action_sequence
        sample['initial_state'] = initial_state
        return sample

    # -------------------------------------------------------------------------
    # VITRA
    # -------------------------------------------------------------------------
    def _load_vitra_sample(self, episode_data: Dict, episode_id: str, core,
                           condition_idx: int, video_indices: List[int],
                           action_indices: List[int]) -> Optional[Dict[str, Any]]:
        """Load VITRA sample using _calculate_sampling_indices."""
        clip_len = episode_data.get('clip_len')

        # Load action/state: call get_item_frame with a large enough window
        # that covers all action_indices. The window returns consecutive frames,
        # then we index into it at the non-consecutive positions.
        physical_chunk_size = self.action_chunk_size * self.global_downsample_rate
        sample = core.get_item_frame(
            episode_id,
            condition_idx,
            action_past_window_size=0,
            action_future_window_size=physical_chunk_size,
            image_past_window_size=0,
            image_future_window_size=0,
            rel_mode=core.rel_mode,
            load_images=False,
        )

        if core.global_data_statistics is not None:
            sample = core.transform_trajectory(sample, normalization=True)

        instruction = self._format_human_instruction(sample["instruction"], 'vitra')
        action_list = sample["action_list"]          # [physical_chunk_size+1, 192]
        current_state = sample["current_state"]      # [212]

        if isinstance(action_list, np.ndarray):
            action_list = torch.tensor(action_list, dtype=torch.float32)
        if isinstance(current_state, np.ndarray):
            current_state = torch.tensor(current_state, dtype=torch.float32)

        # Convert to padded_per_hand (450-dim)
        _ensure_motus_imports()
        from data.per_hand_dims import (
            VITRA_PER_HAND_ACTION_DIM,
            MAX_PER_HAND_ACTION_DIM, MAX_PER_HAND_STATE_DIM,
            concat_per_hand,
        )

        # Extract action_sequence at non-consecutive indices
        # action_list[i] corresponds to frame (condition_idx + i) in the episode
        actions_padded = []
        for action_idx in action_indices:
            local_idx = action_idx - condition_idx
            local_idx = min(local_idx, len(action_list) - 1)
            frame_action = action_list[local_idx]  # [192]
            left_action = frame_action[:VITRA_PER_HAND_ACTION_DIM].numpy() if isinstance(frame_action, torch.Tensor) else frame_action[:VITRA_PER_HAND_ACTION_DIM]
            right_action = frame_action[51:51 + VITRA_PER_HAND_ACTION_DIM].numpy() if isinstance(frame_action, torch.Tensor) else frame_action[51:51 + VITRA_PER_HAND_ACTION_DIM]
            padded = concat_per_hand(left_action, right_action, MAX_PER_HAND_ACTION_DIM)  # [450]
            actions_padded.append(padded)
        action_sequence = torch.tensor(np.stack(actions_padded), dtype=torch.float32)  # [F, 450]

        # Convert initial_state [212] → [450]
        # After transform_trajectory, the unified state layout is:
        #   [0:51] = left hand state, [51:102] = right hand state, [102:212] = padding
        # (beta is dropped by pad_state_human; only action-relevant state is kept)
        cs = current_state.numpy() if isinstance(current_state, torch.Tensor) else current_state
        left_state = cs[:VITRA_PER_HAND_ACTION_DIM]
        right_state = cs[VITRA_PER_HAND_ACTION_DIM:VITRA_PER_HAND_ACTION_DIM * 2]
        state_padded = concat_per_hand(left_state, right_state, MAX_PER_HAND_STATE_DIM)  # [450]
        initial_state = torch.tensor(state_padded, dtype=torch.float32)

        # Load video frames at condition_idx and video_indices
        epi, _, _ = core._load_or_cache_episode(episode_id)
        all_frame_indices = [condition_idx] + video_indices
        frames = self._load_vitra_video_frames(core, episode_id, epi, all_frame_indices, clip_len)
        first_frame = frames[0]    # [C, H, W]
        video_frames = frames[1:]  # [F, C, H, W]

        # Language embedding
        language_embedding = self._get_human_t5_embedding(
            instruction, episode_data.get('t5_cache_dir', './t5_cache_human'),
            episode_data.get('wan_path', './pretrained_models'),
        )

        # VLM inputs (same as robot data — needed for Qwen3-VL module)
        vlm_inputs = None
        if self.vlm_processor is not None:
            vlm_inputs = self._load_vlm_inputs(instruction, first_frame)

        return {
            'first_frame': first_frame,
            'video_frames': video_frames,
            'initial_state': initial_state,
            'action_sequence': action_sequence,
            'language_embedding': language_embedding,
            'vlm_inputs': vlm_inputs,
        }

    def _load_vitra_video_frames(self, core, episode_id: str, epi: dict,
                                  frame_indices: List[int],
                                  clip_len) -> torch.Tensor:
        """Load VITRA video frames at arbitrary indices. Returns [N, C, H, W]."""
        from data.human.vitra_core import load_video_decord

        decode_table = epi["video_decode_frame"]
        T = len(decode_table)
        dataset_prefix = episode_id.split("_")[0]
        video_name = epi["video_name"]

        # Map frame indices to video decode IDs, group by part
        part_to_local: Dict[int, List[Tuple[int, int]]] = {}
        for pos, frame_idx in enumerate(frame_indices):
            frame_idx = min(frame_idx, T - 1)
            full_idx = decode_table[frame_idx]
            if clip_len is None:
                part_idx = 0
                frame_in_part = int(full_idx)
            else:
                part_idx = int(full_idx) // int(clip_len)
                frame_in_part = int(full_idx) % int(clip_len)
            part_to_local.setdefault(part_idx, []).append((pos, frame_in_part))

        # Decode frames per part
        images: List[Optional[np.ndarray]] = [None] * len(frame_indices)
        for part_idx, pairs in part_to_local.items():
            video_path = core._resolve_video_path(dataset_prefix, video_name, part_idx)
            frame_list = [p[1] for p in pairs]
            for attempt in range(3):
                try:
                    imgs, _ = load_video_decord(video_path, frame_index=frame_list, rotation=False)
                    break
                except Exception:
                    if attempt == 2:
                        raise
            for (pos, _), img in zip(pairs, imgs):
                images[pos] = img

        # Resize and convert to tensor
        resized = [resize_with_padding(im, self.video_size) for im in images]
        arr = np.stack(resized, axis=0)
        return torch.from_numpy(arr).permute(0, 3, 1, 2).float() / 255.0

    # -------------------------------------------------------------------------
    # WIYH
    # -------------------------------------------------------------------------
    def _load_wiyh_sample(self, episode_data: Dict,
                          condition_idx: int, video_indices: List[int],
                          action_indices: List[int]) -> Optional[Dict[str, Any]]:
        """Load WIYH sample using _calculate_sampling_indices."""
        import cv2

        h5_path = episode_data['h5_path']
        action_dir = episode_data['action_dir']
        camera_name = episode_data.get('camera_name', 'lf_chest_fisheye')

        # --- Video ---
        all_frame_indices = [condition_idx] + video_indices
        frames = []
        with h5py.File(h5_path, "r") as f:
            filepaths = f[f"observation/camera/{camera_name}/filepath"]
            for idx in all_frame_indices:
                idx = min(idx, len(filepaths) - 1)
                rel_path = filepaths[idx]
                if isinstance(rel_path, bytes):
                    rel_path = rel_path.decode("utf-8")
                img_path = os.path.join(action_dir, rel_path)
                img = cv2.imread(img_path)
                if img is None:
                    raise FileNotFoundError(f"Image not found: {img_path}")
                img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
                img = resize_with_padding(img, self.video_size)
                frames.append(img)

        arr = np.stack(frames, axis=0)
        frames_tensor = torch.from_numpy(arr).permute(0, 3, 1, 2).float() / 255.0
        first_frame = frames_tensor[0]    # [C, H, W]
        video_frames = frames_tensor[1:]  # [F, C, H, W]

        # --- Action/State ---
        _ensure_motus_imports()
        from data.per_hand_dims import (
            WIYH_PER_HAND_ACTION_DIM,
            MAX_PER_HAND_ACTION_DIM, MAX_PER_HAND_STATE_DIM,
            concat_per_hand,
        )

        action_sequence, initial_state, instruction = self._extract_wiyh_actions(
            h5_path, camera_name, condition_idx, action_indices,
            WIYH_PER_HAND_ACTION_DIM, MAX_PER_HAND_ACTION_DIM, MAX_PER_HAND_STATE_DIM,
        )
        instruction = self._format_human_instruction(instruction, 'wiyh')

        # --- Language ---
        language_embedding = self._get_human_t5_embedding(
            instruction, episode_data.get('t5_cache_dir', './t5_cache_human_wiyh'),
            episode_data.get('wan_path', './pretrained_models'),
        )

        # --- VLM inputs ---
        vlm_inputs = None
        if self.vlm_processor is not None:
            vlm_inputs = self._load_vlm_inputs(instruction, first_frame)

        return {
            'first_frame': first_frame,
            'video_frames': video_frames,
            'initial_state': initial_state,
            'action_sequence': action_sequence,
            'language_embedding': language_embedding,
            'vlm_inputs': vlm_inputs,
        }

    @staticmethod
    def _extract_wiyh_actions(h5_path: str, camera_name: str,
                              condition_idx: int, action_indices: List[int],
                              per_hand_dim: int, max_action_dim: int,
                              max_state_dim: int) -> Tuple[torch.Tensor, torch.Tensor, str]:
        """Extract WIYH padded_per_hand actions at arbitrary indices."""
        from scipy.spatial.transform import Rotation as R
        _ensure_motus_imports()
        from data.per_hand_dims import concat_per_hand

        def _se3_to_xyzquat(pose7):
            xyz = pose7[:3]
            quat_xyzw = pose7[3:7]
            quat_wxyz = np.roll(quat_xyzw, 1)
            return np.concatenate([xyz, quat_wxyz]).astype(np.float32)

        def _find_closest_timestamp(target, timestamps):
            return int(np.argmin(np.abs(timestamps - target)))

        with h5py.File(h5_path, "r") as f:
            cam_key = f"observation/camera/{camera_name}"
            cam_timestamps = f[f"{cam_key}/timestamp"][:]
            arm_ts = f["action/arm_status_feedback/timestamp"][:]
            left_poses = f["action/arm_status_feedback/left_eef_pose_in_chest"][:]
            right_poses = f["action/arm_status_feedback/right_eef_pose_in_chest"][:]
            left_arm_mask = f["action/arm_status_feedback/left_eef_pose_mask"][:]
            right_arm_mask = f["action/arm_status_feedback/right_eef_pose_mask"][:]

            has_hand = "action/hand_status_feedback/left_hand_joint_angle" in f
            if has_hand:
                left_hand_joints = f["action/hand_status_feedback/left_hand_joint_angle"][:]
                right_hand_joints = f["action/hand_status_feedback/right_hand_joint_angle"][:]
                left_hand_mask = f["action/hand_status_feedback/left_hand_joint_angle_mask"][:]
                right_hand_mask = f["action/hand_status_feedback/right_hand_joint_angle_mask"][:]
                hand_ts = f["action/hand_status_feedback/timestamp"][:]
            else:
                left_hand_joints = right_hand_joints = None
                hand_ts = None

            instruction = ""
            if "meta/task_description" in f:
                td = f["meta/task_description"][0]
                instruction = td.decode("utf-8") if isinstance(td, bytes) else str(td)
            elif "annotation/atomic_task_description/atomic_task_description" in f:
                ann = f["annotation/atomic_task_description/atomic_task_description"][0]
                instruction = ann.decode("utf-8") if isinstance(ann, bytes) else str(ann)

        def _get_per_hand(arm_idx, hand_idx, is_left):
            arm_mask_arr = left_arm_mask if is_left else right_arm_mask
            arm_pose_arr = left_poses if is_left else right_poses
            arm_valid = (arm_mask_arr[arm_idx] == 0) if arm_idx < len(arm_mask_arr) else False
            eef = _se3_to_xyzquat(arm_pose_arr[arm_idx]) if arm_valid else np.zeros(7, dtype=np.float32)

            joints = np.zeros(per_hand_dim - 7, dtype=np.float32)
            if has_hand:
                h_mask = left_hand_mask if is_left else right_hand_mask
                h_joints = left_hand_joints if is_left else right_hand_joints
                if hand_idx < len(h_mask):
                    joints_valid = (h_mask[hand_idx] == 0)
                    if joints_valid:
                        joints = h_joints[hand_idx].astype(np.float32)

            if not arm_valid:
                eef = np.zeros(7, dtype=np.float32)
            return np.concatenate([eef, joints]), arm_valid

        # Extract actions at non-consecutive indices
        actions_padded = []
        for action_idx in action_indices:
            fi = min(action_idx, len(cam_timestamps) - 1)
            arm_idx = _find_closest_timestamp(cam_timestamps[fi], arm_ts)
            hand_idx = _find_closest_timestamp(cam_timestamps[fi], hand_ts) if has_hand else 0

            left_feat, _ = _get_per_hand(arm_idx, hand_idx, is_left=True)
            right_feat, _ = _get_per_hand(arm_idx, hand_idx, is_left=False)
            action = concat_per_hand(left_feat, right_feat, max_action_dim)  # [450]
            actions_padded.append(action)

        action_sequence = torch.tensor(np.stack(actions_padded), dtype=torch.float32)  # [F, 450]

        # Initial state at condition_idx
        cur_fi = min(condition_idx, len(cam_timestamps) - 1)
        cur_arm_idx = _find_closest_timestamp(cam_timestamps[cur_fi], arm_ts)
        cur_hand_idx = _find_closest_timestamp(cam_timestamps[cur_fi], hand_ts) if has_hand else 0
        cur_left, _ = _get_per_hand(cur_arm_idx, cur_hand_idx, is_left=True)
        cur_right, _ = _get_per_hand(cur_arm_idx, cur_hand_idx, is_left=False)
        state = concat_per_hand(cur_left, cur_right, max_state_dim).astype(np.float32)
        initial_state = torch.tensor(state, dtype=torch.float32)

        return action_sequence, initial_state, instruction

    # -------------------------------------------------------------------------
    # EgoDex
    # -------------------------------------------------------------------------
    def _load_egodex_sample(self, episode_data: Dict,
                            condition_idx: int, video_indices: List[int],
                            action_indices: List[int]) -> Optional[Dict[str, Any]]:
        """Load EgoDex sample using _calculate_sampling_indices."""
        mp4_path = episode_data['mp4_path']
        h5_path = episode_data['h5_path']

        # --- Video: use MotusV2's load_video_frames ---
        all_frame_indices = [condition_idx] + video_indices
        frames_tensor = load_video_frames(mp4_path, all_frame_indices, self.video_size)
        first_frame = frames_tensor[0]    # [C, H, W]
        video_frames = frames_tensor[1:]  # [F, C, H, W]

        # --- Action/State ---
        _ensure_motus_imports()
        from data.per_hand_dims import (
            EGODEX_PER_HAND_ACTION_DIM,
            MAX_PER_HAND_ACTION_DIM, MAX_PER_HAND_STATE_DIM,
            concat_per_hand,
        )

        # Get cached joint names
        joint_names = self._human_data_registry.get('egodex_joint_names', {'left': [], 'right': []})

        action_sequence, initial_state, instruction = self._extract_egodex_actions(
            h5_path, condition_idx, action_indices,
            joint_names, MAX_PER_HAND_ACTION_DIM, MAX_PER_HAND_STATE_DIM,
        )
        instruction = self._format_human_instruction(instruction, 'egodex')

        # --- Language ---
        language_embedding = self._get_human_t5_embedding(
            instruction, episode_data.get('t5_cache_dir', './t5_cache_human_egodex'),
            episode_data.get('wan_path', './pretrained_models'),
        )

        # --- VLM inputs ---
        vlm_inputs = None
        if self.vlm_processor is not None:
            vlm_inputs = self._load_vlm_inputs(instruction, first_frame)

        return {
            'first_frame': first_frame,
            'video_frames': video_frames,
            'initial_state': initial_state,
            'action_sequence': action_sequence,
            'language_embedding': language_embedding,
            'vlm_inputs': vlm_inputs,
        }

    @staticmethod
    def _extract_egodex_actions(h5_path: str, condition_idx: int,
                                action_indices: List[int],
                                joint_names: Dict[str, List[str]],
                                max_action_dim: int,
                                max_state_dim: int) -> Tuple[torch.Tensor, torch.Tensor, str]:
        """Extract EgoDex padded_per_hand actions at arbitrary indices."""
        from scipy.spatial.transform import Rotation as R
        _ensure_motus_imports()
        from data.per_hand_dims import concat_per_hand

        def _rotation_matrix_to_rot6d(rot_mat):
            return rot_mat[:, :2].flatten().astype(np.float32)

        confidence_threshold = 0.3
        left_joint_names = joint_names.get('left', [])
        right_joint_names = joint_names.get('right', [])

        with h5py.File(h5_path, "r") as f:
            left_tfs = f["/transforms/leftHand"][:]
            right_tfs = f["/transforms/rightHand"][:]
            cam_tfs = f["/transforms/camera"][:]

            has_conf = "confidences" in f
            left_conf = f["/confidences/leftHand"][:] if has_conf else None
            right_conf = f["/confidences/rightHand"][:] if has_conf else None

            left_hand_tfs = {}
            right_hand_tfs = {}
            for name in left_joint_names:
                key = f"/transforms/{name}"
                if key in f:
                    left_hand_tfs[name] = f[key][:]
            for name in right_joint_names:
                key = f"/transforms/{name}"
                if key in f:
                    right_hand_tfs[name] = f[key][:]

            instruction = ""
            llm_type = f.attrs.get("llm_type", "single")
            if isinstance(llm_type, bytes):
                llm_type = llm_type.decode("utf-8")
            if llm_type == "reversible":
                direction = f.attrs.get("which_llm_description", "1")
                if isinstance(direction, bytes):
                    direction = direction.decode("utf-8")
                key = "llm_description" if direction == "1" else "llm_description2"
                instruction = f.attrs.get(key, "")
            else:
                instruction = f.attrs.get("llm_description", "")
            if isinstance(instruction, bytes):
                instruction = instruction.decode("utf-8")

        def _get_per_hand_feat(fi, hand_tfs, is_left):
            """Extract per-hand features for one frame: all joints in camera frame, xyz + rot6d."""
            cam_world_inv = np.linalg.inv(cam_tfs[fi])
            features = []
            joint_names_list = left_joint_names if is_left else right_joint_names

            for jname in joint_names_list:
                if jname not in hand_tfs:
                    features.extend(np.zeros(9, dtype=np.float32))
                    continue
                tf_world = hand_tfs[jname][fi]
                tf_cam = cam_world_inv @ tf_world
                xyz = tf_cam[:3, 3]
                rot6d = _rotation_matrix_to_rot6d(tf_cam[:3, :3])
                features.extend(xyz)
                features.extend(rot6d)

            return np.array(features, dtype=np.float32)  # [25*9 = 225] or variable

        # Extract actions at non-consecutive indices
        actions_padded = []
        for action_idx in action_indices:
            fi = min(action_idx, len(left_tfs) - 1)
            left_feat = _get_per_hand_feat(fi, left_hand_tfs, is_left=True)
            right_feat = _get_per_hand_feat(fi, right_hand_tfs, is_left=False)
            action = concat_per_hand(left_feat, right_feat, max_action_dim)  # [450]
            actions_padded.append(action)

        action_sequence = torch.tensor(np.stack(actions_padded), dtype=torch.float32)  # [F, 450]

        # Initial state at condition_idx
        cur_fi = min(condition_idx, len(left_tfs) - 1)
        cur_left = _get_per_hand_feat(cur_fi, left_hand_tfs, is_left=True)
        cur_right = _get_per_hand_feat(cur_fi, right_hand_tfs, is_left=False)
        state = concat_per_hand(cur_left, cur_right, max_state_dim).astype(np.float32)
        initial_state = torch.tensor(state, dtype=torch.float32)

        return action_sequence, initial_state, instruction

    # -------------------------------------------------------------------------
    # Shared T5 Embedding for Human Datasets
    # -------------------------------------------------------------------------
    def _get_human_t5_embedding(self, instruction: str, t5_cache_dir: str,
                                wan_path: str) -> torch.Tensor:
        """Get T5 language embedding for human datasets with disk caching."""
        if not instruction:
            return torch.zeros((512, 4096), dtype=torch.float32)

        cache_dir = Path(t5_cache_dir)
        cache_dir.mkdir(parents=True, exist_ok=True)

        key = hashlib.sha1(instruction.encode("utf-8")).hexdigest()
        path = cache_dir / f"{key}.pt"
        if path.exists():
            return torch.load(path, map_location="cpu", weights_only=True).float()

        # Lazy init T5 encoder
        if self._t5_encoder is None:
            self._init_t5_encoder(wan_path)

        if self._t5_encoder is None:
            return torch.zeros((512, 4096), dtype=torch.float32)

        out = self._t5_encoder([instruction], self._t5_encoder_device)
        if isinstance(out, list):
            emb = out[0]
        elif isinstance(out, torch.Tensor):
            emb = out.squeeze(0)
        else:
            return torch.zeros((512, 4096), dtype=torch.float32)

        emb = emb.detach().to("cpu").float()
        tmp = cache_dir / f".tmp_{key}_{os.getpid()}.pt"
        torch.save(emb, tmp)
        os.replace(tmp, path)
        return emb

    def _init_t5_encoder(self, wan_path: str):
        """Lazy-initialize the shared T5 encoder.

        IMPORTANT: This method is called from DataLoader worker processes
        (forked subprocesses). CUDA cannot be re-initialized after fork, so
        we must use CPU. However, UMT5-XXL is ~10GB — loading it in every
        worker would exhaust CPU RAM. Therefore we skip T5 init inside
        workers and rely on disk cache; cache misses return zeros.
        """
        if self._t5_encoder is not None:
            return

        # Detect if we're inside a DataLoader worker process
        import torch.utils.data
        worker_info = torch.utils.data.get_worker_info()
        if worker_info is not None:
            # We're inside a forked worker — skip T5 init entirely
            # (disk cache should cover most instructions; misses return zeros)
            logger.debug("Skipping T5 encoder init inside DataLoader worker (relying on disk cache)")
            self._t5_encoder = None
            return

        # Main process — safe to use CUDA
        try:
            bak_root = str(Path(__file__).resolve().parents[1] / "bak")
            if bak_root not in sys.path:
                sys.path.append(bak_root)
            from wan.modules.t5 import T5EncoderModel

            ckpt = os.path.join(wan_path, "Wan2.2-TI2V-5B", "models_t5_umt5-xxl-enc-bf16.pth")
            tok = os.path.join(wan_path, "Wan2.2-TI2V-5B", "google/umt5-xxl")

            self._t5_encoder_device = "cuda" if torch.cuda.is_available() else "cpu"
            self._t5_encoder = T5EncoderModel(
                text_len=512,
                dtype=torch.bfloat16,
                device=self._t5_encoder_device,
                checkpoint_path=ckpt,
                tokenizer_path=tok,
            )
            logger.info("Shared T5 encoder initialized for human datasets")
        except Exception as e:
            logger.warning(f"Failed to initialize T5 encoder: {e}. Language embeddings will be zeros.")
            self._t5_encoder = None

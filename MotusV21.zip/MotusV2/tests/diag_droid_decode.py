#!/usr/bin/env python3
"""Verify DROID video decoding: seek accuracy, cache-miss fallbacks, camera sync.

_decode_video_frames_pyav seeks to a keyframe before the first wanted index and
decodes forward, silently substituting a *different* frame when a wanted index
is never produced.  A silent substitution corrupts the visual conditioning while
leaving state/action intact — which is exactly the failure signature we see.

Checks per episode:
  1. exact-hit rate: is every requested global frame index actually decoded?
  2. seek invariance: does frame X decode identically when requested alone vs.
     as part of a longer window (different seek target)?
  3. camera sync: do the three cameras share the same episode start timestamp?

Run:
  PYTHONPATH=/tmp/diag_pkgs python tests/diag_droid_decode.py
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO))
sys.path.insert(0, str(REPO / "tests"))

DATA = "/home/work/cache/wx1469573/data/droid_1.0.1-lerobot"
FPS = 15.0


def decode_with_hitmap(video_path, frame_indices):
    """Copy of _decode_video_frames_pyav that also reports which indices were
    real hits versus silent substitutions."""
    import av

    wanted = sorted(set(int(i) for i in frame_indices))
    first_wanted, last_wanted = wanted[0], wanted[-1]
    container = av.open(str(video_path))
    try:
        stream = container.streams.video[0]
        time_base = float(stream.time_base) if stream.time_base else 1.0
        seek_sec = max(0.0, first_wanted / FPS - 1.0 / FPS)
        try:
            container.seek(int(seek_sec / time_base), stream=stream)
        except Exception:
            container.seek(0, stream=stream)
        idx_to_arr, last_arr, n_decoded = {}, None, 0
        first_decoded_idx = None
        for frame in container.decode(stream):
            pts = float(frame.pts) * time_base if frame.pts is not None else 0.0
            fidx = int(round(pts * FPS))
            if first_decoded_idx is None:
                first_decoded_idx = fidx
            if fidx > last_wanted + 2:
                break
            n_decoded += 1
            arr = frame.to_ndarray(format="rgb24")
            last_arr = arr
            if fidx in wanted:
                idx_to_arr[fidx] = arr
        out, hits = [], []
        for i in frame_indices:
            if i in idx_to_arr:
                out.append(idx_to_arr[i]); hits.append(True)
            else:
                nearest = min(idx_to_arr.keys(), key=lambda k: abs(k - i)) if idx_to_arr else None
                out.append(idx_to_arr.get(nearest, last_arr) if nearest is not None else last_arr)
                hits.append(False)
        return np.stack(out, 0), np.array(hits), n_decoded, first_decoded_idx
    finally:
        container.close()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--num-episodes", type=int, default=12)
    args = ap.parse_args()

    import pandas as pd

    cams = ["observation.images.exterior_2_left",
            "observation.images.exterior_1_left",
            "observation.images.wrist_left"]
    root = Path(DATA)
    epf = sorted((root / "meta" / "episodes").rglob("*.parquet"))[0]
    ep = pd.read_parquet(epf)
    print(f"meta file: {epf.name}, {len(ep)} episodes\n")

    n_hit_tot = n_req_tot = 0
    seek_mismatch = 0
    seek_tested = 0
    start_desync = []

    for row_i in range(min(args.num_episodes, len(ep))):
        row = ep.iloc[row_i]
        length = int(row["length"])
        if length < 40:
            continue
        starts, paths = [], []
        ok = True
        for cam in cams:
            p = root / "videos" / cam / f"chunk-{int(row[f'videos/{cam}/chunk_index']):03d}" / f"file-{int(row[f'videos/{cam}/file_index']):03d}.mp4"
            if not p.exists():
                ok = False
                break
            paths.append(p)
            starts.append(int(round(float(row[f"videos/{cam}/from_timestamp"]) * FPS)))
        if not ok:
            continue
        start_desync.append(max(starts) - min(starts))

        # mimic __getitem__: cond_idx + 16 action frames -> 9 sampled offsets
        cond = length // 3
        offsets = [cond] + [cond + 2 * (k + 1) for k in range(8)]

        for cam_i, (p, s) in enumerate(zip(paths, starts)):
            idxs = [s + o for o in offsets]
            arrs, hits, ndec, first_dec = decode_with_hitmap(p, idxs)
            n_hit_tot += int(hits.sum()); n_req_tot += len(hits)
            if cam_i == 0:
                # seek invariance: same target index, different seek origin
                target = idxs[len(idxs) // 2]
                a1, h1, _, _ = decode_with_hitmap(p, [target])
                a2, h2, _, _ = decode_with_hitmap(p, [target - 120, target])
                if h1[0] and h2[-1]:
                    seek_tested += 1
                    if not np.array_equal(a1[0], a2[-1]):
                        seek_mismatch += 1
                        d = float(np.abs(a1[0].astype(int) - a2[-1].astype(int)).mean())
                        print(f"  ep{row_i} SEEK MISMATCH mean|Δpx|={d:.2f}")
                print(f"  ep{row_i} len={length:5d} start={s:7d} "
                      f"hits={int(hits.sum())}/{len(hits)} decoded={ndec} first_decoded={first_dec} "
                      f"(seek landed {first_dec - idxs[0]:+d} frames from target)")

    print(f"\n=== exact-hit rate: {n_hit_tot}/{n_req_tot} = {100*n_hit_tot/max(n_req_tot,1):.2f}%")
    print(f"=== seek invariance mismatches: {seek_mismatch}/{seek_tested}")
    print(f"=== camera start-frame desync (max-min over 3 cams): "
          f"mean={np.mean(start_desync):.2f} max={np.max(start_desync)} frames")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
"""Contract tests for the DROID idle-segment filter.

Ported from openpi's compute_droid_nonidle_ranges.py; these pin the exact
semantics, in particular that idleness means "the commanded velocity stopped
changing", not "the velocity is small".

Run:
  python -m pytest tests/test_droid_filter.py -q
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pytest

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO))

from data.droid.droid_filter import (  # noqa: E402
    DEFAULT_MIN_IDLE_LEN,
    compute_keep_ranges,
    sampleable_windows,
)


def _moving(n, seed=0):
    """Frames whose command changes every step."""
    rng = np.random.default_rng(seed)
    return rng.normal(0, 0.2, (n, 7)).astype(np.float32)


def _frozen(n, value=0.0):
    """Frames whose command is held constant (operator let go)."""
    return np.full((n, 7), value, dtype=np.float32)


def test_idle_means_frozen_command_not_small_velocity():
    """A large but constant command is idle; a small but changing one is not."""
    frozen_large = _frozen(60, value=0.9)
    assert compute_keep_ranges(frozen_large) == []

    moving_small = (_moving(60, seed=1) * 0.01).astype(np.float32)
    assert compute_keep_ranges(moving_small), "changing commands must not be idle"


def test_long_idle_run_is_removed_and_splits_the_episode():
    jv = np.concatenate([_moving(40), _frozen(30, 0.5), _moving(40, seed=2)])
    ranges = compute_keep_ranges(jv, trim_last_n=0)
    assert len(ranges) == 2
    (s0, e0), (s1, e1) = ranges
    assert s0 == 0 and e0 <= 41          # first moving block (frozen run starts at 40)
    assert s1 >= 69 and e1 == len(jv)     # second moving block


def test_short_idle_run_is_tolerated():
    """Fewer than min_idle_len frozen frames must not split the episode."""
    jv = np.concatenate([_moving(40), _frozen(DEFAULT_MIN_IDLE_LEN - 1, 0.5), _moving(40, seed=3)])
    ranges = compute_keep_ranges(jv, trim_last_n=0)
    assert len(ranges) == 1
    assert ranges[0] == (0, len(jv))


def test_short_moving_runs_are_dropped():
    """A 5-frame twitch between long idle stretches is below min_non_idle_len."""
    jv = np.concatenate([_frozen(30, 0.1), _moving(5), _frozen(30, 0.4)])
    assert compute_keep_ranges(jv, trim_last_n=0) == []


def test_trim_last_n_shortens_each_range():
    jv = _moving(100)
    untrimmed = compute_keep_ranges(jv, trim_last_n=0)
    trimmed = compute_keep_ranges(jv, trim_last_n=10)
    assert untrimmed == [(0, 100)]
    assert trimmed == [(0, 90)]


def test_ranges_never_exceed_the_episode():
    for n in (20, 37, 128):
        for r in compute_keep_ranges(_moving(n)):
            assert 0 <= r[0] < r[1] <= n


def test_sampleable_windows_guarantee_the_whole_chunk_fits():
    """The point of this helper: no sampled chunk may run past its keep range."""
    span = 16
    ranges = [(0, 40), (60, 70), (100, 117)]
    windows = sampleable_windows(ranges, span)
    # (60, 70) is only 10 long, so it cannot host a 16-frame chunk.
    assert windows == [(0, 24), (100, 101)]
    for lo, hi in windows:
        for cond in range(lo, hi):
            assert any(s <= cond and cond + span <= e for s, e in ranges)


def test_degenerate_inputs():
    assert compute_keep_ranges(np.zeros((0, 7), np.float32)) == []
    assert compute_keep_ranges(np.zeros((1, 7), np.float32)) == []
    with pytest.raises(ValueError):
        compute_keep_ranges(np.zeros(7, np.float32))


def test_matches_openpi_reference_implementation():
    """Byte-for-byte agreement with the upstream algorithm on random episodes."""
    def openpi_reference(jv, min_idle_len=7, min_non_idle_len=16, filter_last_n=10):
        is_idle_array = np.hstack(
            [np.array([False]), np.all(np.abs(jv[1:] - jv[:-1]) < 1e-3, axis=1)]
        )
        is_idle_padded = np.concatenate([[False], is_idle_array, [False]])
        d = np.diff(is_idle_padded.astype(int))
        starts, ends = np.where(d == 1)[0], np.where(d == -1)[0]
        m = (ends - starts) >= min_idle_len
        starts, ends = starts[m], ends[m]
        keep = np.ones(len(jv), dtype=bool)
        for s, e in zip(starts, ends):
            keep[s:e] = False
        kp = np.concatenate([[False], keep, [False]])
        d = np.diff(kp.astype(int))
        ks, ke = np.where(d == 1)[0], np.where(d == -1)[0]
        m = (ke - ks) >= min_non_idle_len
        ks, ke = ks[m], ke[m]
        return [(int(s), int(e) - filter_last_n) for s, e in zip(ks, ke)]

    rng = np.random.default_rng(42)
    for trial in range(50):
        blocks = []
        for _ in range(rng.integers(1, 6)):
            blocks.append(_moving(int(rng.integers(5, 60)), seed=int(rng.integers(0, 1000))))
            blocks.append(_frozen(int(rng.integers(1, 25)), value=float(rng.normal())))
        jv = np.concatenate(blocks).astype(np.float32)
        ref = [r for r in openpi_reference(jv) if r[1] > r[0]]
        assert compute_keep_ranges(jv) == ref, f"trial {trial} diverged"


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-q"]))

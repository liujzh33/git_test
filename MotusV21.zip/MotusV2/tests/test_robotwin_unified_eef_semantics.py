import numpy as np

from data.human.unified_eef_action import (
    UNIFIED_EEF_ROBOT_EFFECTIVE_INDICES,
    UNIFIED_EEF_ROBOT_RESERVED_INDICES,
    build_hand_world_poses_from_xyzquat,
    compute_unified_eef_action_16d_with_gripper,
    compute_unified_eef_action_sequence_with_gripper,
    compute_unified_eef_state_from_poses_with_gripper,
    exp_SO3,
    quat_wxyz_to_rotmat,
)


ROBOTWIN_HEAD_R_W_C = np.array(
    [
        [1.0, 0.0, 0.0],
        [0.0, -0.8, 0.6],
        [0.0, -0.6, -0.8],
    ],
    dtype=np.float64,
)
ROBOTWIN_HEAD_T_W_C = np.array([-0.032, -0.45, 1.35], dtype=np.float64)


def _rot_x(angle):
    c, s = np.cos(angle), np.sin(angle)
    return np.array([[1, 0, 0], [0, c, -s], [0, s, c]], dtype=np.float64)


def _rot_y(angle):
    c, s = np.cos(angle), np.sin(angle)
    return np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]], dtype=np.float64)


def _rot_z(angle):
    c, s = np.cos(angle), np.sin(angle)
    return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]], dtype=np.float64)


def _rotmat_to_quat_wxyz(rotmat):
    from scipy.spatial.transform import Rotation

    quat_xyzw = Rotation.from_matrix(rotmat).as_quat()
    quat_wxyz = np.roll(quat_xyzw, 1)
    if quat_wxyz[0] < 0:
        quat_wxyz = -quat_wxyz
    return quat_wxyz


def _unified_delta_arm_to_absolute(anchor_R_w_e, anchor_t_w_e, delta_8d, R_w_c):
    R_c_e = R_w_c.T @ anchor_R_w_e
    R_delta_c = exp_SO3(delta_8d[3:6]).reshape(3, 3)
    R_e_e_star = R_c_e.T @ R_delta_c @ R_c_e
    t_e_e_star = R_c_e.T @ delta_8d[:3]
    target_R_w_e = anchor_R_w_e @ R_e_e_star
    target_t_w_e = anchor_t_w_e + anchor_R_w_e @ t_e_e_star
    return target_R_w_e, target_t_w_e


def _make_eepos_frame(left_t, left_R, left_grip, right_t, right_R, right_grip):
    return np.concatenate(
        [
            np.asarray(left_t, dtype=np.float64),
            _rotmat_to_quat_wxyz(left_R),
            np.array([left_grip], dtype=np.float64),
            np.asarray(right_t, dtype=np.float64),
            _rotmat_to_quat_wxyz(right_R),
            np.array([right_grip], dtype=np.float64),
        ]
    )


def test_robot_gripper_dims_reserved_dims_and_mask():
    left_R = _rot_z(0.2)
    right_R = _rot_y(-0.3)
    target_left_R = left_R @ _rot_x(0.1)
    target_right_R = right_R @ _rot_z(-0.2)

    action, mask = compute_unified_eef_action_16d_with_gripper(
        R_w_e_left=left_R,
        t_w_e_left=np.array([0.1, -0.2, 0.3]),
        R_w_e_right=right_R,
        t_w_e_right=np.array([-0.3, 0.2, 0.4]),
        R_w_e_star_left=target_left_R,
        t_w_e_star_left=np.array([0.2, -0.1, 0.35]),
        R_w_e_star_right=target_right_R,
        t_w_e_star_right=np.array([-0.25, 0.15, 0.5]),
        R_w_c=ROBOTWIN_HEAD_R_W_C,
        left_gripper=1.0,
        right_gripper=0.0,
        left_gripper_star=0.25,
        right_gripper_star=0.75,
    )

    assert action.shape == (16,)
    assert mask.shape == (16,)
    assert action[6] == np.float32(0.25)
    assert action[14] == np.float32(0.75)
    assert action[7] == 0.0
    assert action[15] == 0.0
    assert np.where(mask == 1.0)[0].tolist() == UNIFIED_EEF_ROBOT_EFFECTIVE_INDICES
    assert np.where(mask == 0.0)[0].tolist() == UNIFIED_EEF_ROBOT_RESERVED_INDICES


def test_robot_action_sequence_is_anchor_based_and_gripper_is_target_absolute():
    num_actions = 4
    left_R = np.stack([np.eye(3)] * (num_actions + 1))
    right_R = np.stack([np.eye(3)] * (num_actions + 1))
    left_t = np.zeros((num_actions + 1, 3), dtype=np.float64)
    right_t = np.zeros((num_actions + 1, 3), dtype=np.float64)
    left_t[:, 0] = np.arange(num_actions + 1) * 0.1
    right_t[:, 1] = np.arange(num_actions + 1) * -0.2
    left_grip = np.array([1.0, 0.9, 0.7, 0.4, 0.1], dtype=np.float64)
    right_grip = np.array([0.0, 0.2, 0.5, 0.8, 1.0], dtype=np.float64)
    valid = np.ones(num_actions + 1, dtype=bool)

    actions, masks = compute_unified_eef_action_sequence_with_gripper(
        R_w_e_left=left_R,
        t_w_e_left=left_t,
        R_w_e_right=right_R,
        t_w_e_right=right_t,
        R_w_c=np.eye(3),
        left_gripper=left_grip,
        right_gripper=right_grip,
        left_valid=valid,
        right_valid=valid,
        num_action_frames=num_actions,
    )

    for i in range(num_actions):
        assert np.allclose(actions[i, :3], left_t[i + 1] - left_t[0])
        assert np.allclose(actions[i, 8:11], right_t[i + 1] - right_t[0])
        assert actions[i, 6] == np.float32(left_grip[i + 1])
        assert actions[i, 14] == np.float32(right_grip[i + 1])
    assert np.allclose(actions[:, [7, 15]], 0.0)
    assert np.allclose(masks[:, [6, 14]], 1.0)
    assert np.allclose(masks[:, [7, 15]], 0.0)


def test_robotwin_head_camera_extrinsic_direction_matches_hdf5_convention():
    R_w2c = np.array(
        [
            [1.0, 0.0, 0.0],
            [0.0, -0.8, -0.6],
            [0.0, 0.6, -0.8],
        ],
        dtype=np.float64,
    )
    t_w2c = np.array([0.032, 0.45, 1.35], dtype=np.float64)
    expected_R_w_c = R_w2c.T
    expected_t_w_c = -expected_R_w_c @ t_w2c

    assert np.allclose(ROBOTWIN_HEAD_R_W_C, expected_R_w_c)
    assert np.allclose(ROBOTWIN_HEAD_T_W_C, expected_t_w_c)

    world_point = np.array([0.3, -0.2, 0.9], dtype=np.float64)
    via_camera_pose = ROBOTWIN_HEAD_R_W_C.T @ (world_point - ROBOTWIN_HEAD_T_W_C)
    via_hdf5_extrinsic = R_w2c @ world_point + t_w2c
    assert np.allclose(via_camera_pose, via_hdf5_extrinsic)


def test_eepos_wxyz_quaternion_conversion_and_round_trip_unified_eef():
    anchor_left_R = _rot_z(0.4) @ _rot_x(-0.2)
    anchor_right_R = _rot_y(-0.3) @ _rot_z(0.1)
    target_left_R = anchor_left_R @ exp_SO3(np.array([0.12, -0.04, 0.08])).reshape(3, 3)
    target_right_R = anchor_right_R @ exp_SO3(np.array([-0.05, 0.07, 0.03])).reshape(3, 3)
    anchor_left_t = np.array([0.15, -0.25, 0.55], dtype=np.float64)
    anchor_right_t = np.array([-0.12, -0.20, 0.52], dtype=np.float64)
    target_left_t = anchor_left_t + anchor_left_R @ np.array([0.03, -0.01, 0.02])
    target_right_t = anchor_right_t + anchor_right_R @ np.array([-0.02, 0.025, 0.01])

    eepos = np.stack(
        [
            _make_eepos_frame(anchor_left_t, anchor_left_R, 1.0, anchor_right_t, anchor_right_R, 0.0),
            _make_eepos_frame(target_left_t, target_left_R, 0.35, target_right_t, target_right_R, 0.85),
        ]
    )

    left_R_w, left_t_w = build_hand_world_poses_from_xyzquat(eepos[:, 0:3], eepos[:, 3:7])
    right_R_w, right_t_w = build_hand_world_poses_from_xyzquat(eepos[:, 8:11], eepos[:, 11:15])
    assert np.allclose(left_R_w[0], anchor_left_R)
    assert np.allclose(right_R_w[1], target_right_R)

    state, state_mask = compute_unified_eef_state_from_poses_with_gripper(
        R_w_e_left=left_R_w[0],
        t_w_e_left=left_t_w[0],
        R_w_e_right=right_R_w[0],
        t_w_e_right=right_t_w[0],
        R_w_c=ROBOTWIN_HEAD_R_W_C,
        t_w_c=ROBOTWIN_HEAD_T_W_C,
        left_gripper=eepos[0, 7],
        right_gripper=eepos[0, 15],
    )
    assert state.shape == (16,)
    assert state[6] == np.float32(1.0)
    assert state[14] == np.float32(0.0)
    assert state_mask[7] == 0.0
    assert state_mask[15] == 0.0

    actions, masks = compute_unified_eef_action_sequence_with_gripper(
        R_w_e_left=left_R_w,
        t_w_e_left=left_t_w,
        R_w_e_right=right_R_w,
        t_w_e_right=right_t_w,
        R_w_c=ROBOTWIN_HEAD_R_W_C,
        left_gripper=eepos[:, 7],
        right_gripper=eepos[:, 15],
        left_valid=np.ones(2, dtype=bool),
        right_valid=np.ones(2, dtype=bool),
        num_action_frames=1,
    )
    assert masks[0, 6] == 1.0
    assert masks[0, 14] == 1.0
    assert masks[0, 7] == 0.0
    assert masks[0, 15] == 0.0

    recovered_left_R, recovered_left_t = _unified_delta_arm_to_absolute(
        left_R_w[0], left_t_w[0], actions[0, :8], ROBOTWIN_HEAD_R_W_C
    )
    recovered_right_R, recovered_right_t = _unified_delta_arm_to_absolute(
        right_R_w[0], right_t_w[0], actions[0, 8:16], ROBOTWIN_HEAD_R_W_C
    )

    assert np.allclose(recovered_left_t, target_left_t, atol=1e-6)
    assert np.allclose(recovered_right_t, target_right_t, atol=1e-6)
    assert np.allclose(recovered_left_R, target_left_R, atol=1e-6)
    assert np.allclose(recovered_right_R, target_right_R, atol=1e-6)
    assert actions[0, 6] == np.float32(0.35)
    assert actions[0, 14] == np.float32(0.85)


def test_quaternion_canonicalization_does_not_change_rotation():
    quat_wxyz = _rotmat_to_quat_wxyz(_rot_z(0.7) @ _rot_y(-0.1))
    assert np.allclose(quat_wxyz_to_rotmat(quat_wxyz), quat_wxyz_to_rotmat(-quat_wxyz))

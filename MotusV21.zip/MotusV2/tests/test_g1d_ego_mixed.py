"""Checks for mixing G1-D robot data with retargeted FastEgo human data.

Run directly (no pytest needed):
    python tests/test_g1d_ego_mixed.py
"""

import sys
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from data.dataset import collate_fn, create_dataset  # noqa: E402
from data.ego.ego_dataset import EgoRetargetDataset  # noqa: E402
from data.g1d.eef_actions import select_episodes  # noqa: E402

EGO_ROOT = "/home/work/wenjj/data/egoself-pour-water-eps84"
G1D_ROOT = "/home/work/wenjj/data/G1-D/pick-kettle-and-cup"
STATS = f"{G1D_ROOT}/meta/eef_stats.json"

EGO_COMMON = dict(
    dataset_dir=EGO_ROOT,
    num_video_frames=8,
    video_action_freq_ratio=8,
    global_downsample_rate=1,
    t5_mode="none",
    allow_t5_cache_miss_zero=True,
    instruction="拿起水杯和茶壶，并倒水",
)


def test_windows_are_both_hands_valid():
    """Every indexed window must have both hands tracked end to end, condition
    frame included -- eef_delta references it, so it cannot be untracked."""
    ds = EgoRetargetDataset(**EGO_COMMON, action_mode="eef_delta")
    span = ds._required_span()
    assert span == 65, span  # 64 actions * stride 1, plus the condition frame

    checked = 0
    for ep in ds.episodes[:10]:
        with np.load(ep["npz_path"]) as d:
            arm_valid = d["arm_valid"]
        both = arm_valid[:, 0] & arm_valid[:, 1]
        for start in ep["starts"][:50]:
            assert both[start:start + span].all(), (ep["session_id"], start)
            checked += 1
    total = sum(len(e["starts"]) for e in ds.episodes)
    print(f"validity: {len(ds.episodes)} sessions, {total} windows, spot-checked {checked}, "
          f"span {span} frames = {span / ds.fps:.2f}s")


def test_rejects_windows_that_straddle_invalid_frames():
    """The index must not merely subsample valid frames -- a window containing
    any untracked frame has to be excluded outright."""
    arm_valid = np.ones((20, 2), dtype=bool)
    arm_valid[10] = [True, False]  # one hand drops out mid-way
    # A window [s, s+5) contains index 10 exactly when 6 <= s <= 10.
    starts = EgoRetargetDataset._valid_window_starts(arm_valid, span=5)
    assert starts == [0, 1, 2, 3, 4, 5, 11, 12, 13, 14, 15], starts
    assert all(not (6 <= s <= 10) for s in starts), starts
    print("validity: windows straddling an untracked frame are excluded")


def test_ego_matches_g1d_scale_under_shared_stats():
    """Both sides must land in the same normalized range, or the retarget's
    distribution alignment is undone by the normalizer."""
    from data.g1d.g1d_dataset import G1DLeRobotDataset

    shared = dict(num_video_frames=8, video_action_freq_ratio=8, t5_mode="none",
                  allow_t5_cache_miss_zero=True, action_mode="eef_delta",
                  normalization=True, normalization_stats_path=STATS)
    ego = EgoRetargetDataset(dataset_dir=EGO_ROOT, global_downsample_rate=1,
                             instruction="x", **shared)
    g1d = G1DLeRobotDataset(dataset_dir=G1D_ROOT, global_downsample_rate=1,
                            max_episodes=6, **shared)
    live = [i for i in range(16) if i not in (6, 14)]

    def actions(ds, n=25):
        return np.concatenate([ds[0]["action_sequence"].numpy() for _ in range(n)])[:, live]

    e, g = actions(ego), actions(g1d)
    # The claim is that the two sources coincide after scaling, not that they hit
    # any particular interval -- that depends on normalization_mode.
    assert abs(e.mean() - g.mean()) < 0.25, (e.mean(), g.mean())
    # Ego is expected to be the narrower of the two -- the retarget report puts
    # its per-dim std at 0.17-0.83 of G1-D's, because a 6 s human reach covers
    # less range than a 24 s robot demonstration. The bound only has to catch a
    # scale mismatch, not that difference.
    assert 0.25 < e.std() / max(g.std(), 1e-9) < 3.0, (e.std(), g.std())
    print(f"scale[{ego.normalization_mode}]: ego mean {e.mean():+.3f} std {e.std():.3f} vs "
          f"g1d mean {g.mean():+.3f} std {g.std():.3f}")


def test_ego_frame_occupies_the_g1d_head_camera_slot():
    """The fisheye must land in the same pixels the T-shape gives cam_left_high,
    with the wrist sub-regions black."""
    ds = EgoRetargetDataset(**EGO_COMMON, action_mode="eef_delta")
    geo = ds._top_slot_geometry()
    frame = ds[0]["first_frame"]
    y0, top_h, bot_h = geo["pad_top"], geo["top_h"], geo["bot_h"]

    assert (y0, top_h, bot_h) == (12, 240, 120), geo
    assert frame[:, y0:y0 + top_h].abs().sum() > 0, "top slot is empty"
    wrists = frame[:, y0 + top_h: y0 + top_h + bot_h]
    assert wrists.abs().sum() == 0, "wrist slots must stay black for ego"
    assert frame[:, :y0].abs().sum() == 0, "top padding strip must stay black"
    print(f"video: fisheye in rows {y0}..{y0 + top_h}, wrist rows "
          f"{y0 + top_h}..{y0 + top_h + bot_h} black")


def test_episode_subset_is_seeded_and_reproducible():
    items = list(range(100))
    a = select_episodes(items, 20, seed=0)
    b = select_episodes(items, 20, seed=0)
    c = select_episodes(items, 20, seed=1)
    assert a == b, "same seed must give the same draw"
    assert a != c, "different seeds must give different draws"
    assert len(a) == 20 and len(set(a)) == 20
    assert select_episodes(items, 20, seed=None) == items[:20], "unseeded stays first-N"
    assert select_episodes(items, None, seed=0) == items
    assert select_episodes(items, 500, seed=0) == items, "cap above size is a no-op"

    one = EgoRetargetDataset(**EGO_COMMON, action_mode="eef_delta",
                             max_episodes=12, episode_seed=7)
    two = EgoRetargetDataset(**EGO_COMMON, action_mode="eef_delta",
                             max_episodes=12, episode_seed=7)
    ids = [e["session_id"] for e in one.episodes]
    assert ids == [e["session_id"] for e in two.episodes]
    assert len(ids) == 12
    print(f"subset: seeded draw is reproducible, e.g. {ids[:3]} ...")


def test_normalization_stats_resolve_to_g1d_for_both_sides():
    """With normalization on and no explicit path, both sides must land on G1-D's
    statistics. Letting each default to its own root sends the ego side looking
    for a file that does not and should not exist there."""
    from omegaconf import OmegaConf

    cfg = OmegaConf.load("configs/g1d_ego_mixed_eef_delta.yaml")
    cfg.dataset.g1d.dataset_dir = G1D_ROOT
    cfg.dataset.ego.dataset_dir = EGO_ROOT
    cfg.dataset.g1d.max_episodes = 6
    cfg.dataset.ego.max_episodes = 6
    cfg.dataset.normalization = True
    cfg.dataset.normalization_stats_path = None
    cfg.dataset.t5_mode = "none"
    cfg.dataset.allow_t5_cache_miss_zero = True
    del cfg.model.vlm.checkpoint_path

    g1d, ego = create_dataset(cfg, val=False).datasets
    for ds in (g1d, ego):
        assert ds.action_normalizer is not None, f"{type(ds).__name__} has no normalizer"
    assert np.allclose(g1d.action_normalizer.offset, ego.action_normalizer.offset)
    assert np.allclose(g1d.action_normalizer.scale, ego.action_normalizer.scale)
    assert np.allclose(g1d.state_normalizer.offset, ego.state_normalizer.offset)
    print("stats: both sides resolved to G1-D's eef_stats.json and agree")


def test_mixed_batches_are_interchangeable():
    """A batch must survive samples from either source, which means both have to
    agree on every optional key -- collate drops action_valid_mask entirely if
    even one sample in the batch lacks it."""
    from omegaconf import OmegaConf
    from torch.utils.data import DataLoader

    cfg = OmegaConf.load("configs/g1d_ego_mixed_eef_delta.yaml")
    cfg.dataset.g1d.dataset_dir = G1D_ROOT
    cfg.dataset.ego.dataset_dir = EGO_ROOT
    cfg.dataset.g1d.max_episodes = 6
    cfg.dataset.ego.max_episodes = 8
    cfg.dataset.t5_mode = "none"
    cfg.dataset.allow_t5_cache_miss_zero = True
    del cfg.model.vlm.checkpoint_path

    ds = create_dataset(cfg, val=False)
    sub = ds.datasets
    assert len(sub) == 2, sub
    assert len(sub[0].episodes) == 6 and len(sub[1].episodes) == 8

    keys = [set(s.keys()) for s in (sub[0][0], sub[1][0])]
    assert keys[0] == keys[1], f"sample key mismatch: {keys[0] ^ keys[1]}"

    batch = next(iter(DataLoader(ds, batch_size=8, collate_fn=collate_fn, num_workers=0)))
    assert "action_valid_mask" in batch, "mask dropped -- sources disagree on optional keys"
    assert batch["action_sequence"].shape == (8, 64, 16), batch["action_sequence"].shape
    assert batch["initial_state"].shape == (8, 16)
    assert batch["video_frames"].shape == (8, 8, 3, 384, 320)
    print(f"mixed: batch {tuple(batch['action_sequence'].shape)}, keys agree, mask survives collate")


def test_chunk_is_64_frames_on_both_sides():
    """Both sides take 64 frames at stride 1. They match on frame count, not on
    wall clock -- ego is 60 Hz, so its chunk covers half the seconds G1-D's does."""
    from omegaconf import OmegaConf

    cfg = OmegaConf.load("configs/g1d_ego_mixed_eef_delta.yaml")
    chunk = cfg.common.num_video_frames * cfg.common.video_action_freq_ratio
    assert chunk == 64, chunk
    g1d_frames = chunk * cfg.dataset.g1d.global_downsample_rate
    ego_frames = chunk * cfg.dataset.ego.global_downsample_rate
    assert g1d_frames == ego_frames == 64, (g1d_frames, ego_frames)
    print(f"timing: {chunk} actions over {g1d_frames} frames both sides "
          f"(g1d {g1d_frames / 30:.2f}s, ego {ego_frames / 60:.2f}s)")


def test_train_and_val_episodes_are_disjoint():
    """The held-out episodes must be exactly the ones training never sees."""
    from omegaconf import OmegaConf

    cfg = OmegaConf.load("configs/g1d_ego_mixed_eef_delta.yaml")
    cfg.dataset.g1d.dataset_dir = G1D_ROOT
    cfg.dataset.ego.dataset_dir = EGO_ROOT
    cfg.dataset.t5_mode = "none"
    cfg.dataset.allow_t5_cache_miss_zero = True
    del cfg.model.vlm.checkpoint_path

    train = create_dataset(cfg, val=False)
    val = create_dataset(cfg, val=True)

    g1d_train = train.datasets[0]
    assert len(train.datasets) == 2, "training should mix both sources"
    assert not hasattr(val, "datasets"), "validation should be the g1d dataset alone"
    assert type(val).__name__ == "G1DLeRobotDataset", type(val).__name__

    tr = {e["episode_index"] for e in g1d_train.episodes}
    va = {e["episode_index"] for e in val.episodes}
    assert len(tr) == cfg.dataset.g1d.max_episodes, len(tr)
    assert not (tr & va), f"{len(tr & va)} episodes leaked into validation"
    assert len(tr) + len(va) == 89, (len(tr), len(va))
    print(f"holdout: train {len(tr)} / val {len(va)} g1d episodes, disjoint, "
          f"val has no ego")


def test_holdout_split_is_stable_across_seeds():
    from data.g1d.eef_actions import select_episodes as sel

    items = list(range(89))
    tr = sel(items, 60, seed=0, subset="train")
    va = sel(items, 60, seed=0, subset="val")
    assert len(tr) == 60 and len(va) == 29
    assert not (set(tr) & set(va))
    assert sorted(tr + va) == items
    assert sel(items, 60, seed=1, subset="train") != tr, "seed must move the split"

    for bad, kwargs in (
        ("no seed", dict(max_episodes=60, seed=None, subset="train")),
        ("no cap", dict(max_episodes=None, seed=0, subset="val")),
        ("cap takes all", dict(max_episodes=89, seed=0, subset="val")),
    ):
        try:
            sel(items, **kwargs)
        except ValueError:
            continue
        raise AssertionError(f"expected ValueError for {bad}")
    print("holdout: split is seed-stable and rejects degenerate settings")


if __name__ == "__main__":
    test_windows_are_both_hands_valid()
    test_rejects_windows_that_straddle_invalid_frames()
    test_ego_matches_g1d_scale_under_shared_stats()
    test_ego_frame_occupies_the_g1d_head_camera_slot()
    test_episode_subset_is_seeded_and_reproducible()
    test_chunk_is_64_frames_on_both_sides()
    test_holdout_split_is_stable_across_seeds()
    test_train_and_val_episodes_are_disjoint()
    test_normalization_stats_resolve_to_g1d_for_both_sides()
    test_mixed_batches_are_interchangeable()
    print("\nall g1d+ego mixed checks passed")

#!/usr/bin/env python3
"""Check Xperience dataset for shape-anomalous samples.

Root-cause probe for the 16-node training crash:
  CUDA device-side assert at IndexKernel.cu:93 (index out of bounds),
  surfacing at rope_apply -> torch.unique sync point.

Hypothesis: a sample whose VAE latent is NOT [B, 48, 3, 12, 10] reaches the
model. Since grid_sizes is fixed to [3,12,10] (= [1+8//4, 384//32, 320//32]),
any video tensor that is not [9, 3, 384, 320] (8 predicted frames + 1 condition)
will, after VAE encode, mismatch grid_sizes and trigger an out-of-bounds index
in rope_apply.

This script reuses the REAL XperienceMotusDataset loading path (does not
re-implement parsing) so the check mirrors what training sees. It:
  1. Indexes episodes exactly as training does.
  2. For each episode, samples several frame_start positions.
  3. Runs _load_frames_window + _extract_unified_eef_action_state.
  4. Asserts exact shapes: first_frame [3,384,320], video_frames [8,3,384,320],
     action_sequence [8,16], initial_state [16], action_valid_mask [8,16].
  5. Additionally decodes the video independently with decord to verify the
     REAL video frame count vs the HDF5-derived n_frames (the prime suspect:
     n_frames comes from hand_mocap, NOT from the mp4).
  6. Tries a real VAE encode on a subset to catch latent-shape anomalies that
     only surface at encode time (optional, if VAE weights are available).

Usage:
    python tests/check_xperience_shapes.py \
        --dataset_dir /cache/wx1469573/data/xperience-10m-clean \
        --num_episodes 0 \
        --samples_per_episode 5 \
        --workers 8

    --num_episodes 0  => scan ALL episodes
    --vae_ckpt /path/to/Wan2.2-TI2V-5B  => also run VAE encode on a subset

Output: prints a summary + writes a JSON report of every anomalous sample
with its path, frame_start, and the specific check that failed.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import traceback
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# Make the repo importable when run from anywhere
REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

#torch late import so the fork warning is per-process clean
import numpy as np


# ---- Expected shapes (must match config: num_video_frames=8, H=384, W=320) ----
NUM_VIDEO_FRAMES = 8
VIDEO_H, VIDEO_W = 384, 320
EXPECTED_FIRST_FRAME = (3, VIDEO_H, VIDEO_W)          # condition frame
EXPECTED_VIDEO_FRAMES = (NUM_VIDEO_FRAMES, 3, VIDEO_H, VIDEO_W)  # predicted frames
EXPECTED_ACTION = (NUM_VIDEO_FRAMES, 16)              # unified 16-dim action
EXPECTED_STATE = (16,)                                # unified 16-dim state
EXPECTED_ACTION_MASK = (NUM_VIDEO_FRAMES, 16)


def _check_tensor(name: str, t: Any, expected: Tuple[int, ...], path: str,
                  frame_start: int, anomalies: List[Dict[str, Any]]):
    """Check a tensor's shape and finiteness; record anomalies."""
    import torch
    if t is None:
        anomalies.append({"path": path, "frame_start": frame_start,
                          "check": name, "error": "tensor is None"})
        return
    if not isinstance(t, torch.Tensor):
        anomalies.append({"path": path, "frame_start": frame_start,
                          "check": name, "error": f"not a tensor: {type(t)}",
                          "value": str(t)[:200]})
        return
    if tuple(t.shape) != expected:
        anomalies.append({"path": path, "frame_start": frame_start,
                          "check": f"{name}_shape",
                          "error": f"expected {expected}, got {tuple(t.shape)}"})
        # Don't return: still check dtype below
    if t.dtype not in (torch.float32, torch.float16, torch.bfloat16, torch.bool, torch.uint8):
        anomalies.append({"path": path, "frame_start": frame_start,
                          "check": f"{name}_dtype",
                          "error": f"unexpected dtype {t.dtype}"})
    # Finiteness only for float tensors
    if t.dtype.is_floating_point:
        n_nan = int(torch.isnan(t).sum().item())
        n_inf = int(torch.isinf(t).sum().item())
        if n_nan or n_inf:
            anomalies.append({"path": path, "frame_start": frame_start,
                              "check": f"{name}_finite",
                              "error": f"{n_nan} NaN, {n_inf} Inf",
                              "shape": str(tuple(t.shape))})


def _verify_video_frame_count(mp4_path: str, h5_n_frames: int,
                              path: str) -> List[Dict[str, Any]]:
    """Independently decode the mp4 and compare real frame count to HDF5 n_frames.

    This is the prime suspect for the crash: training computes n_frames from
    hand_mocap/right_translation.shape[0], but the mp4 may have fewer (or more)
    decodable frames. If the mp4 is shorter than h5_n_frames, frame_start
    sampled against h5_n_frames can exceed the real video length.
    """
    import torch  # noqa
    anomalies: List[Dict[str, Any]] = []
    try:
        from decord import VideoReader, cpu
        vr = VideoReader(mp4_path, ctx=cpu(0), num_threads=1)
        real_n = len(vr)
        if real_n != h5_n_frames:
            anomalies.append({
                "path": path,
                "check": "video_vs_h5_frame_count",
                "error": (f"mp4 has {real_n} frames but HDF5 n_frames="
                          f"{h5_n_frames} (mismatch! sampling against HDF5 "
                          f"count can request out-of-range video frames)"),
                "mp4_frames": real_n, "h5_frames": h5_n_frames,
            })
        # Probe: try to read the LAST frame training could request.
        # Training samples frame_start in [0, n_frames - num_video_frames - 1]
        # and reads frames [frame_start .. frame_start + 8].
        if h5_n_frames > NUM_VIDEO_FRAMES + 1:
            worst_start = h5_n_frames - NUM_VIDEO_FRAMES - 1
            req = list(range(worst_start, worst_start + NUM_VIDEO_FRAMES + 1))
            try:
                batch = vr.get_batch(req)
                arr = batch.asnumpy()
                if arr.shape[0] != len(req):
                    anomalies.append({
                        "path": path, "check": "get_batch_short_read",
                        "error": (f"requested {len(req)} frames, got {arr.shape[0]}"),
                    })
                if arr.ndim != 4 or arr.shape[-1] != 3:
                    anomalies.append({
                        "path": path, "check": "get_batch_shape",
                        "error": f"unexpected decord shape {arr.shape}",
                    })
            except Exception as e:
                anomalies.append({
                    "path": path, "check": "get_batch_failed",
                    "error": f"{type(e).__name__}: {e}",
                    "requested_start": worst_start,
                })
        del vr
    except Exception as e:
        anomalies.append({"path": path, "check": "video_open",
                          "error": f"{type(e).__name__}: {e}"})
    return anomalies


def _build_dataset(dataset_dir: str, num_episodes: int, samples_per_episode: int):
    """Build a real XperienceMotusDataset (reuses training code path)."""
    from data.xperience.xperience_dataset import XperienceMotusDataset

    # Build with vlm_processor=None and t5_mode='none' so we don't need the
    # VLM/T5 checkpoints to run the shape check. We exercise the video +
    # action loading paths, which are where shape anomalies would originate.
    ds = XperienceMotusDataset(
        dataset_dir=dataset_dir,
        num_video_frames=NUM_VIDEO_FRAMES,
        video_size=(VIDEO_H, VIDEO_W),
        vlm_processor=None,
        t5_mode="none",
        max_attempts=1,  # fail fast on bad samples instead of retrying
    )
    return ds


def _check_episode(args: Tuple[str, Dict, int, int]) -> Dict[str, Any]:
    """Worker process: check one episode at several frame_start positions.

    Uses the dataset's internal helpers directly so we test the exact code
    path training uses, but with deterministic frame_start sampling (not
    random) so we cover edge positions (start, middle, end).
    """
    dataset_dir, episode, samples_per_episode, pid = args
    import torch  # noqa
    from data.xperience.xperience_dataset import XperienceMotusDataset

    # Build a lightweight dataset just to reuse its methods; we call helpers
    # directly rather than __getitem__ (which randomizes frame_start).
    # NOTE: building per-process is cheap because t5_mode='none' skips T5 load.
    ds = XperienceMotusDataset(
        dataset_dir=dataset_dir,
        num_video_frames=NUM_VIDEO_FRAMES,
        video_size=(VIDEO_H, VIDEO_W),
        vlm_processor=None,
        t5_mode="none",
        max_attempts=1,
    )

    ep = episode
    path = ep["h5_path"]
    mp4 = ep["mp4_path"]
    n_frames = ep["n_frames"]
    anomalies: List[Dict[str, Any]] = []

    # 1) Independently verify mp4 frame count vs HDF5 n_frames
    anomalies.extend(_verify_video_frame_count(mp4, n_frames, path))

    # 2) Deterministic frame_start positions: start, 1/4, mid, 3/4, end
    max_start = n_frames - NUM_VIDEO_FRAMES - 1
    if max_start < 0:
        anomalies.append({"path": path, "check": "n_frames_too_small",
                          "error": f"n_frames={n_frames} < {NUM_VIDEO_FRAMES+1}"})
        return {"path": path, "anomalies": anomalies}
    positions = np.linspace(0, max_start, samples_per_episode, dtype=int)

    for fs in positions:
        try:
            # --- video path (exact training code) ---
            frames = ds._load_frames_window(mp4, int(fs))
            first_frame = frames[0]
            video_frames = frames[1:]

            _check_tensor("first_frame", first_frame, EXPECTED_FIRST_FRAME,
                          path, int(fs), anomalies)
            _check_tensor("video_frames", video_frames, EXPECTED_VIDEO_FRAMES,
                          path, int(fs), anomalies)

            # value range sanity (frames normalized to [0,1])
            if first_frame.dtype.is_floating_point:
                mn, mx = float(first_frame.min()), float(first_frame.max())
                if mn < -0.01 or mx > 1.01:
                    anomalies.append({
                        "path": path, "frame_start": int(fs),
                        "check": "first_frame_range",
                        "error": f"frame values out of [0,1]: min={mn:.3f} max={mx:.3f}",
                    })

            # --- action/state path (exact training code) ---
            action, state, action_valid_mask, instruction = \
                ds._extract_unified_eef_action_state(path, int(fs))

            import torch as _t
            action_t = _t.as_tensor(action) if not isinstance(action, _t.Tensor) else action
            state_t = _t.as_tensor(state) if not isinstance(state, _t.Tensor) else state
            mask_t = _t.as_tensor(action_valid_mask) if not isinstance(action_valid_mask, _t.Tensor) else action_valid_mask

            _check_tensor("action_sequence", action_t, EXPECTED_ACTION,
                          path, int(fs), anomalies)
            _check_tensor("initial_state", state_t, EXPECTED_STATE,
                          path, int(fs), anomalies)
            _check_tensor("action_valid_mask", mask_t, EXPECTED_ACTION_MASK,
                          path, int(fs), anomalies)

            # action finiteness (NaN/Inf in action -> NaN loss, not the crash,
            # but worth flagging)
            if action_t.dtype.is_floating_point:
                n_nan = int(_t.isnan(action_t).sum())
                n_inf = int(_t.isinf(action_t).sum())
                if n_nan or n_inf:
                    anomalies.append({"path": path, "frame_start": int(fs),
                                      "check": "action_finite",
                                      "error": f"{n_nan} NaN, {n_inf} Inf in action"})

        except Exception as e:
            anomalies.append({
                "path": path, "frame_start": int(fs),
                "check": "load_exception",
                "error": f"{type(e).__name__}: {e}",
                "traceback": traceback.format_exc().splitlines()[-1],
            })

    return {"path": path, "n_anomalies": len(anomalies), "anomalies": anomalies}


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--dataset_dir", required=True,
                    help="xperience-10m-clean root")
    ap.add_argument("--num_episodes", type=int, default=0,
                    help="0 = scan all episodes; else cap at N")
    ap.add_argument("--samples_per_episode", type=int, default=5,
                    help="frame_start positions to probe per episode")
    ap.add_argument("--workers", type=int, default=8,
                    help="parallel processes")
    ap.add_argument("--output", default="xperience_shape_report.json",
                    help="JSON report path")
    args = ap.parse_args()

    print(f"[check] Building dataset index from {args.dataset_dir} ...")
    ds = _build_dataset(args.dataset_dir, args.num_episodes, args.samples_per_episode)
    episodes = list(ds.episodes)
    if args.num_episodes and args.num_episodes > 0:
        episodes = episodes[:args.num_episodes]
    print(f"[check] {len(episodes)} episodes indexed. "
          f"(dataset skipped: no_extrinsics={ds._skipped_no_extrinsics}, "
          f"no_hand={ds._skipped_no_hand_data}, nan_hand={ds._skipped_nan_hand})")
    if not episodes:
        print("[check] No episodes found. Check --dataset_dir.")
        return

    # Distribute episodes across workers
    tasks = [(args.dataset_dir, ep, args.samples_per_episode, i)
             for i, ep in enumerate(episodes)]

    all_anomalies: List[Dict[str, Any]] = []
    eps_with_anomaly = 0
    checked = 0
    import torch
    torch.set_num_threads(1)  # per-process; avoid oversubscription

    with ProcessPoolExecutor(max_workers=args.workers) as ex:
        futures = {ex.submit(_check_episode, t): t for t in tasks}
        for fut in as_completed(futures):
            checked += 1
            try:
                res = fut.result()
            except Exception as e:
                all_anomalies.append({"path": futures[fut][1]["h5_path"],
                                      "anomalies": [{"check": "worker_crash",
                                                     "error": f"{type(e).__name__}: {e}"}]})
                eps_with_anomaly += 1
                continue
            if res["n_anomalies"]:
                eps_with_anomaly += 1
                all_anomalies.extend(res["anomalies"])
            if checked % 50 == 0 or checked == len(tasks):
                print(f"[check] {checked}/{len(tasks)} episodes done, "
                      f"{eps_with_anomaly} with anomalies so far", flush=True)

    # ---- Summary ----
    from collections import Counter
    check_counts = Counter(a["check"] for a in all_anomalies)
    print("\n" + "=" * 70)
    print(f"[RESULT] Checked {checked} episodes "
          f"({args.samples_per_episode} positions each)")
    print(f"[RESULT] {eps_with_anomaly} episodes had at least one anomaly")
    print(f"[RESULT] {len(all_anomalies)} total anomaly records")
    print("[RESULT] Breakdown by check type:")
    for check, cnt in check_counts.most_common():
        print(f"    {cnt:6d}  {check}")

    # List the most suspicious category in detail (video frame-count mismatch)
    mismatches = [a for a in all_anomalies
                  if a.get("check") == "video_vs_h5_frame_count"]
    if mismatches:
        print("\n" + "-" * 70)
        print(f"[SUSPECT] {len(mismatches)} episodes with mp4/HDF5 frame-count "
              f"mismatch (most likely crash cause). First 20:")
        for a in mismatches[:20]:
            print(f"    {a['path']}")
            print(f"        {a['error']}")

    report = {
        "dataset_dir": args.dataset_dir,
        "episodes_checked": checked,
        "samples_per_episode": args.samples_per_episode,
        "episodes_with_anomaly": eps_with_anomaly,
        "total_anomalies": len(all_anomalies),
        "breakdown_by_check": dict(check_counts),
        "anomalies": all_anomalies,
    }
    with open(args.output, "w") as f:
        json.dump(report, f, indent=2)
    print(f"\n[check] Full report -> {args.output}")

    if all_anomalies:
        print("\n[VERDICT] Anomalies found. These are strong candidates for the "
              "CUDA index-out-of-bounds crash:")
        print("  -> Samples whose video tensor shape != [9,3,384,320] would "
              "produce a VAE latent != [48,3,12,10],")
        print("     mismatching the fixed grid_sizes=[3,12,10] in rope_apply "
              "and triggering IndexKernel.cu:93.")
        sys.exit(1)
    else:
        print("\n[VERDICT] No shape anomalies found via the dataset path. "
              "Crash may originate elsewhere (e.g. VAE encode on specific "
              "pixel values, or a race in multi-worker loading). Consider "
              "running with --vae_ckpt to also probe VAE latent shapes.")


if __name__ == "__main__":
    main()

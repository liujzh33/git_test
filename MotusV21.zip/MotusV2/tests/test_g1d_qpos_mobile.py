"""G1D-mobile 19/23-dim qpos maps onto the Dex1 16-dim [L7, LG, R7, RG] layout."""

import numpy as np

from data.g1d.g1d_dataset import G1DLeRobotDataset


def test_dex1_16_unchanged():
    raw = np.arange(16, dtype=np.float32)
    out = G1DLeRobotDataset._to_arm_interleaved(raw)
    # [L7, R7, LG, RG] -> [L7, LG, R7, RG]
    np.testing.assert_array_equal(
        out, np.array([0, 1, 2, 3, 4, 5, 6, 14, 7, 8, 9, 10, 11, 12, 13, 15], dtype=np.float32)
    )


def test_mobile_19_drops_chassis_keeps_grippers():
    # action: L7, R7, HighLift, MoveX, MoveYaw, LG, RG
    raw = np.arange(19, dtype=np.float32)
    out = G1DLeRobotDataset._to_arm_interleaved(raw)
    expected = np.array(
        [0, 1, 2, 3, 4, 5, 6, 17, 7, 8, 9, 10, 11, 12, 13, 18], dtype=np.float32
    )
    np.testing.assert_array_equal(out, expected)
    assert out.shape == (16,)


def test_mobile_23_state_also_drops_base_pose():
    raw = np.arange(23, dtype=np.float32)
    out = G1DLeRobotDataset._to_arm_interleaved(raw)
    expected = np.array(
        [0, 1, 2, 3, 4, 5, 6, 17, 7, 8, 9, 10, 11, 12, 13, 18], dtype=np.float32
    )
    np.testing.assert_array_equal(out, expected)
    assert 14 not in out  # HighLift
    assert 15 not in out  # MoveX
    assert 16 not in out  # MoveYaw
    assert 19 not in out  # base


def test_bad_dim_raises():
    try:
        G1DLeRobotDataset._to_arm_interleaved(np.arange(18, dtype=np.float32))
    except ValueError as e:
        assert "18" in str(e)
    else:
        raise AssertionError("expected ValueError for dim 18")

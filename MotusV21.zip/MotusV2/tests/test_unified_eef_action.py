"""
Unit tests for unified EEF camera-delta wrist16 action representation.

Tests cover:
1. Identity camera + identity wrist -> output equals e->e* delta
2. Pure translation -> rotvec near 0
3. Pure rotation -> translation near 0
4. Inverse consistency -> can recover target pose from action
5. Missing hand mask -> block is zero, mask is zero
6. Old script compatibility -> old action modes still work
"""

import numpy as np
import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from data.human.unified_eef_action import (
    log_SO3,
    exp_SO3,
    compute_camera_delta_action,
    compute_unified_eef_action_16d,
    compute_unified_eef_state_16d,
    compute_unified_eef_action_sequence,
    compute_unified_eef_state_from_poses,
    quat_wxyz_to_rotmat,
    build_camera_world_pose_from_slam,
    UNIFIED_EEF_ACTION_DIM,
    UNIFIED_EEF_STATE_DIM,
    UNIFIED_EEF_EFFECTIVE_INDICES,
    UNIFIED_EEF_RESERVED_INDICES,
)


def _rot_x(angle):
    """Rotation matrix around X axis."""
    c, s = np.cos(angle), np.sin(angle)
    return np.array([[1, 0, 0], [0, c, -s], [0, s, c]], dtype=np.float64)


def _rot_y(angle):
    """Rotation matrix around Y axis."""
    c, s = np.cos(angle), np.sin(angle)
    return np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]], dtype=np.float64)


def _rot_z(angle):
    """Rotation matrix around Z axis."""
    c, s = np.cos(angle), np.sin(angle)
    return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]], dtype=np.float64)


def test_log_exp_roundtrip():
    """log(exp(v)) = v and exp(log(R)) = R."""
    print("Test: log/exp roundtrip")
    # Random rotation vectors
    np.random.seed(42)
    for _ in range(100):
        rotvec = np.random.randn(3) * 0.5  # small-medium rotations
        R_mat = exp_SO3(rotvec)
        recovered = log_SO3(R_mat.reshape(1, 3, 3)).reshape(3)
        # rotvec and -rotvec give the same rotation when angle ~ pi
        # For small angles, they should match closely
        if np.linalg.norm(rotvec) > 1e-6:
            # Check that the rotation matrices match
            R_recovered = exp_SO3(recovered)
            assert np.allclose(R_mat, R_recovered, atol=1e-5), \
                f"exp(log(R)) != R: max diff = {np.abs(R_mat - R_recovered).max()}"

    # Test near-identity
    for _ in range(10):
        rotvec = np.random.randn(3) * 1e-8
        R_mat = exp_SO3(rotvec)
        recovered = log_SO3(R_mat.reshape(1, 3, 3)).reshape(3)
        R_recovered = exp_SO3(recovered)
        assert np.allclose(R_mat, R_recovered, atol=1e-4), \
            f"Near-identity roundtrip failed: max diff = {np.abs(R_mat - R_recovered).max()}"

    print("  PASSED")


def test_identity_camera_identity_wrist():
    """When R_w_c = I and R_w_e = I, output equals e->e* delta directly."""
    print("Test: identity camera + identity wrist")
    R_w_c = np.eye(3)
    t_w_c = np.zeros(3)

    R_w_e = np.eye(3)
    t_w_e = np.array([0.1, 0.2, 0.3])

    # Target: translate by (0.01, 0.02, 0.03) and rotate by 10 degrees around z
    delta_t = np.array([0.01, 0.02, 0.03])
    delta_R = _rot_z(np.deg2rad(10))

    R_w_e_star = delta_R @ R_w_e
    t_w_e_star = t_w_e + delta_t

    action_8d, valid = compute_camera_delta_action(
        R_w_e=R_w_e, t_w_e=t_w_e,
        R_w_e_star=R_w_e_star, t_w_e_star=t_w_e_star,
        R_w_c=R_w_c, valid=True,
    )

    assert valid, "Action should be valid"
    # With identity camera and identity wrist, t_delta_c should equal t_e_e*
    # t_e_e* = R_w_e^T @ (t_w_e* - t_w_e) = (t_w_e* - t_w_e) = delta_t
    expected_t = R_w_e.T @ delta_t  # = delta_t when R_w_e = I
    assert np.allclose(action_8d[:3], expected_t, atol=1e-5), \
        f"Translation mismatch: got {action_8d[:3]}, expected {expected_t}"

    # rotvec should represent the same rotation
    expected_rotvec = log_SO3(delta_R.reshape(1, 3, 3)).reshape(3)
    # But R_delta_c = R_c_e @ R_e_e* @ R_e_c
    # With R_w_c = I: R_c_e = I, R_e_c = I
    # So R_delta_c = R_e_e* = delta_R
    assert np.allclose(action_8d[3:6], expected_rotvec, atol=1e-5), \
        f"Rotation mismatch: got {action_8d[3:6]}, expected {expected_rotvec}"

    # Reserved dims should be zero
    assert np.allclose(action_8d[6:8], 0), "Reserved dims should be zero"

    print("  PASSED")


def test_pure_translation():
    """Only translation: rotvec should be near 0."""
    print("Test: pure translation")
    R_w_c = _rot_y(np.deg2rad(30))
    R_w_e = _rot_x(np.deg2rad(15))
    t_w_e = np.array([0.5, 0.3, 0.1])

    # Pure translation: same rotation, different position
    R_w_e_star = R_w_e.copy()
    t_w_e_star = t_w_e + np.array([0.02, -0.01, 0.03])

    action_8d, valid = compute_camera_delta_action(
        R_w_e=R_w_e, t_w_e=t_w_e,
        R_w_e_star=R_w_e_star, t_w_e_star=t_w_e_star,
        R_w_c=R_w_c, valid=True,
    )

    assert valid, "Action should be valid"
    assert np.allclose(action_8d[3:6], 0, atol=1e-5), \
        f"Rotvec should be near 0 for pure translation, got {action_8d[3:6]}"

    print("  PASSED")


def test_pure_rotation():
    """Only rotation: translation should be near 0."""
    print("Test: pure rotation")
    R_w_c = _rot_z(np.deg2rad(45))
    R_w_e = _rot_y(np.deg2rad(20))
    t_w_e = np.array([0.5, 0.3, 0.1])

    # Pure rotation: same position, different rotation
    R_w_e_star = _rot_x(np.deg2rad(30)) @ R_w_e
    t_w_e_star = t_w_e.copy()

    action_8d, valid = compute_camera_delta_action(
        R_w_e=R_w_e, t_w_e=t_w_e,
        R_w_e_star=R_w_e_star, t_w_e_star=t_w_e_star,
        R_w_c=R_w_c, valid=True,
    )

    assert valid, "Action should be valid"
    assert np.allclose(action_8d[:3], 0, atol=1e-5), \
        f"Translation should be near 0 for pure rotation, got {action_8d[:3]}"

    print("  PASSED")


def test_inverse_consistency():
    """From action_16d, recover target pose should approximately match."""
    print("Test: inverse consistency")
    np.random.seed(42)
    for _ in range(50):
        # Random poses
        R_w_c = _rot_z(0.5) @ _rot_y(0.3)
        R_w_e = _rot_x(0.4) @ _rot_z(0.2)
        t_w_e = np.random.randn(3) * 0.3

        # Random target
        delta_rotvec = np.random.randn(3) * 0.2
        delta_t_eef = np.random.randn(3) * 0.05

        R_e_e_star = exp_SO3(delta_rotvec).reshape(3, 3)
        R_w_e_star = R_w_e @ R_e_e_star
        t_w_e_star = t_w_e + R_w_e @ delta_t_eef

        action_8d, valid = compute_camera_delta_action(
            R_w_e=R_w_e, t_w_e=t_w_e,
            R_w_e_star=R_w_e_star, t_w_e_star=t_w_e_star,
            R_w_c=R_w_c, valid=True,
        )

        assert valid

        # Recover: from camera-delta action, reconstruct target pose
        R_c_e = R_w_c.T @ R_w_e
        R_e_c = R_c_e.T

        # t_delta_c -> t_e_e*
        t_delta_c = action_8d[:3]
        t_e_e_star = R_c_e.T @ t_delta_c  # R_e_c @ t_delta_c
        # Note: R_c_e.T = R_e_c, but let me be explicit
        t_e_e_star_recovered = R_e_c @ t_delta_c
        t_w_e_star_recovered = t_w_e + R_w_e @ t_e_e_star_recovered

        # R_delta_c -> R_e_e*
        rotvec_c = action_8d[3:6]
        R_delta_c = exp_SO3(rotvec_c).reshape(3, 3)
        R_e_e_star_recovered = R_e_c @ R_delta_c @ R_c_e
        R_w_e_star_recovered = R_w_e @ R_e_e_star_recovered

        # Check
        assert np.allclose(t_w_e_star, t_w_e_star_recovered, atol=1e-4), \
            f"Position recovery failed: diff = {np.abs(t_w_e_star - t_w_e_star_recovered).max()}"
        assert np.allclose(R_w_e_star, R_w_e_star_recovered, atol=1e-4), \
            f"Rotation recovery failed: diff = {np.abs(R_w_e_star - R_w_e_star_recovered).max()}"

    print("  PASSED")


def test_missing_hand_mask():
    """When a hand is missing, its block should be 0 and mask should be 0."""
    print("Test: missing hand mask")
    R_w_c = np.eye(3)
    R_w_e_left = np.eye(3)
    t_w_e_left = np.array([0.1, 0.2, 0.3])
    R_w_e_right = _rot_x(0.5)
    t_w_e_right = np.array([-0.1, 0.2, -0.3])
    R_w_e_star_left = _rot_z(0.1) @ R_w_e_left
    t_w_e_star_left = t_w_e_left + np.array([0.01, 0, 0])
    R_w_e_star_right = _rot_y(0.1) @ R_w_e_right
    t_w_e_star_right = t_w_e_right + np.array([0, 0.01, 0])

    # Left hand missing
    action_16d, mask_16d = compute_unified_eef_action_16d(
        R_w_e_left=R_w_e_left, t_w_e_left=t_w_e_left,
        R_w_e_right=R_w_e_right, t_w_e_right=t_w_e_right,
        R_w_e_star_left=R_w_e_star_left, t_w_e_star_left=t_w_e_star_left,
        R_w_e_star_right=R_w_e_star_right, t_w_e_star_right=t_w_e_star_right,
        R_w_c=R_w_c,
        left_valid=False, right_valid=True,
    )

    # Left block should be 0
    assert np.allclose(action_16d[:8], 0), f"Left block should be 0, got {action_16d[:8]}"
    # Left mask should be 0 for effective dims
    assert np.allclose(mask_16d[0:6], 0), f"Left mask should be 0, got {mask_16d[0:6]}"
    # Right block should have data
    assert not np.allclose(action_16d[8:], 0), "Right block should have data"
    # Right mask should be 1 for effective dims
    assert np.allclose(mask_16d[8:14], 1), f"Right mask should be 1, got {mask_16d[8:14]}"
    # Reserved dims mask should be 0
    assert np.allclose(mask_16d[6:8], 0), "Reserved dim mask should be 0"
    assert np.allclose(mask_16d[14:16], 0), "Reserved dim mask should be 0"

    print("  PASSED")


def test_action_sequence_shape():
    """Test that action sequence has correct shape and anchor-based semantics."""
    print("Test: action sequence shape & anchor-based semantics")
    T = 8
    R_w_c = np.eye(3)

    # Create T+1 frames of hand poses with known translations
    np.random.seed(42)
    left_R = np.stack([np.eye(3)] * (T + 1))
    right_R = np.stack([np.eye(3)] * (T + 1))
    # Frame 0 is anchor, each subsequent frame moves further in +x
    left_t = np.zeros((T + 1, 3))
    left_t[:, 0] = np.arange(T + 1) * 0.01  # [0, 0.01, 0.02, ..., 0.08]
    right_t = np.zeros((T + 1, 3))
    right_t[:, 1] = np.arange(T + 1) * 0.02
    left_valid = np.ones(T + 1, dtype=bool)
    right_valid = np.ones(T + 1, dtype=bool)

    actions, masks = compute_unified_eef_action_sequence(
        R_w_e_left=left_R, t_w_e_left=left_t,
        R_w_e_right=right_R, t_w_e_right=right_t,
        R_w_c=R_w_c,
        left_valid=left_valid, right_valid=right_valid,
        num_action_frames=T,
    )

    assert actions.shape == (T, 16), f"Expected shape ({T}, 16), got {actions.shape}"
    assert masks.shape == (T, 16), f"Expected mask shape ({T}, 16), got {masks.shape}"

    # No NaN or Inf
    assert np.all(np.isfinite(actions)), "Actions should be finite"
    assert np.all(np.isfinite(masks)), "Masks should be finite"

    # Reserved dims should be 0
    assert np.allclose(actions[:, 6:8], 0), "Reserved dims should be 0"
    assert np.allclose(actions[:, 14:16], 0), "Reserved dims should be 0"

    # --- Verify anchor-based semantics ---
    # action[i] = delta(pose[0] -> pose[i+1])
    # With identity rotation and R_w_c = I:
    #   t_delta_c = R_w_e^T @ (t_w_e* - t_w_e) = t_w_e[i+1] - t_w_e[0]
    #   rotvec should be 0 (no rotation change)
    for i in range(T):
        # Left hand xyz delta (dims 0:3)
        expected_left_xyz = left_t[i + 1] - left_t[0]
        assert np.allclose(actions[i, :3], expected_left_xyz, atol=1e-5), \
            f"action[{i}] left xyz: expected {expected_left_xyz}, got {actions[i, :3]}"
        # Left hand rotvec (dims 3:6) should be ~0
        assert np.allclose(actions[i, 3:6], 0, atol=1e-5), \
            f"action[{i}] left rotvec should be ~0, got {actions[i, 3:6]}"
        # Right hand xyz delta (dims 8:11)
        expected_right_xyz = right_t[i + 1] - right_t[0]
        assert np.allclose(actions[i, 8:11], expected_right_xyz, atol=1e-5), \
            f"action[{i}] right xyz: expected {expected_right_xyz}, got {actions[i, 8:11]}"

    # Specifically: action[0] = pose[0] -> pose[1] (same as step mode for i=0)
    # action[1] = pose[0] -> pose[2] (NOT pose[1] -> pose[2])
    assert np.allclose(actions[1, :3], left_t[2] - left_t[0], atol=1e-5), \
        f"action[1] should be anchor-based (pose[0]->pose[2]), not step (pose[1]->pose[2])"

    print("  PASSED")


def test_quat_wxyz_to_rotmat():
    """Test quaternion to rotation matrix conversion."""
    print("Test: quaternion to rotmat")
    from scipy.spatial.transform import Rotation as Rot

    # Identity quaternion
    q_wxyz = np.array([1, 0, 0, 0])
    R_mat = quat_wxyz_to_rotmat(q_wxyz)
    assert np.allclose(R_mat, np.eye(3), atol=1e-6), "Identity quaternion should give identity rotation"

    # Random quaternion
    np.random.seed(42)
    for _ in range(10):
        q_xyzw = np.random.randn(4)
        q_xyzw = q_xyzw / np.linalg.norm(q_xyzw)
        q_wxyz = np.array([q_xyzw[3], q_xyzw[0], q_xyzw[1], q_xyzw[2]])

        R_mat = quat_wxyz_to_rotmat(q_wxyz)
        R_expected = Rot.from_quat(q_xyzw).as_matrix()
        assert np.allclose(R_mat, R_expected, atol=1e-6), \
            f"Quaternion conversion mismatch: max diff = {np.abs(R_mat - R_expected).max()}"

    print("  PASSED")


def test_build_camera_world_pose_from_slam():
    """Test SLAM + calibration -> camera world pose."""
    print("Test: SLAM camera world pose")
    # When SLAM is at origin with identity rotation, camera pose = inv(T_c_b)
    slam_trans = np.array([0.0, 0.0, 0.0])
    slam_quat_wxyz = np.array([1.0, 0.0, 0.0, 0.0])  # identity rotation

    T_c_b = np.eye(4)
    T_c_b[:3, :3] = _rot_y(np.deg2rad(90))

    R_w_c, t_w_c = build_camera_world_pose_from_slam(
        slam_trans=slam_trans,
        slam_quat_wxyz=slam_quat_wxyz,
        T_c_b=T_c_b,
    )

    # inv(T_c_b) = T_body_cam0
    T_body_cam0 = np.linalg.inv(T_c_b)
    R_expected = T_body_cam0[:3, :3]
    t_expected = T_body_cam0[:3, 3]

    assert np.allclose(R_w_c, R_expected, atol=1e-6), \
        f"R_w_c mismatch: max diff = {np.abs(R_w_c - R_expected).max()}"
    assert np.allclose(t_w_c, t_expected, atol=1e-6), \
        f"t_w_c mismatch: max diff = {np.abs(t_w_c - t_expected).max()}"

    print("  PASSED")


def test_no_nan_inf():
    """Test that no NaN or Inf is produced for various inputs."""
    print("Test: no NaN/Inf in outputs")
    np.random.seed(42)
    for _ in range(100):
        R_w_c = _rot_z(np.random.randn()) @ _rot_y(np.random.randn())
        R_w_e = _rot_x(np.random.randn()) @ _rot_z(np.random.randn())
        t_w_e = np.random.randn(3)
        delta_rotvec = np.random.randn(3) * 0.5
        delta_t = np.random.randn(3) * 0.1

        R_e_e_star = exp_SO3(delta_rotvec).reshape(3, 3)
        R_w_e_star = R_w_e @ R_e_e_star
        t_w_e_star = t_w_e + R_w_e @ delta_t

        action_8d, valid = compute_camera_delta_action(
            R_w_e=R_w_e, t_w_e=t_w_e,
            R_w_e_star=R_w_e_star, t_w_e_star=t_w_e_star,
            R_w_c=R_w_c, valid=True,
        )

        if valid:
            assert np.all(np.isfinite(action_8d)), \
                f"Non-finite action: {action_8d}"

    print("  PASSED")


def test_effective_indices():
    """Verify that effective and reserved indices are correct."""
    print("Test: effective indices")
    assert UNIFIED_EEF_EFFECTIVE_INDICES == [0, 1, 2, 3, 4, 5, 8, 9, 10, 11, 12, 13], \
        f"Unexpected effective indices: {UNIFIED_EEF_EFFECTIVE_INDICES}"
    assert UNIFIED_EEF_RESERVED_INDICES == [6, 7, 14, 15], \
        f"Unexpected reserved indices: {UNIFIED_EEF_RESERVED_INDICES}"
    print("  PASSED")


def test_state_camera_translation():
    """State xyz must be camera-frame position, i.e. R_w_c^T @ (t_w_e - t_w_c).

    With R_w_c = I, t_w_c = [10, 0, 0], t_w_e = [11, 2, 3],
    expected state xyz = [1, 2, 3], NOT [11, 2, 3].
    """
    print("Test: state camera translation")
    R_w_c = np.eye(3)
    t_w_c = np.array([10.0, 0.0, 0.0])
    R_w_e = np.eye(3)
    t_w_e = np.array([11.0, 2.0, 3.0])

    state, mask = compute_unified_eef_state_16d(
        R_w_e_left=R_w_e, t_w_e_left=t_w_e,
        R_w_e_right=R_w_e, t_w_e_right=t_w_e,
        R_w_c=R_w_c, t_w_c=t_w_c,
        left_valid=True, right_valid=True,
    )

    # Left xyz (dims 0:3) should be [1, 2, 3]
    assert np.allclose(state[:3], [1, 2, 3], atol=1e-5), \
        f"Left xyz should be [1, 2, 3], got {state[:3]}"
    # Right xyz (dims 8:11) should be [1, 2, 3]
    assert np.allclose(state[8:11], [1, 2, 3], atol=1e-5), \
        f"Right xyz should be [1, 2, 3], got {state[8:11]}"
    # Mask should be 1 for effective dims
    assert np.allclose(mask[0:6], 1.0), f"Left mask should be 1, got {mask[0:6]}"
    assert np.allclose(mask[8:14], 1.0), f"Right mask should be 1, got {mask[8:14]}"
    # Reserved dims should be 0
    assert np.allclose(state[6:8], 0), "Reserved dims should be 0"
    assert np.allclose(state[14:16], 0), "Reserved dims should be 0"

    # Test with non-identity camera
    R_w_c = _rot_y(np.deg2rad(90))
    t_w_c = np.array([1.0, 0.0, 0.0])
    t_w_e = np.array([2.0, 0.0, 0.0])  # 1 unit in front of camera in world x

    state2, _ = compute_unified_eef_state_16d(
        R_w_e_left=np.eye(3), t_w_e_left=t_w_e,
        R_w_e_right=np.eye(3), t_w_e_right=t_w_e,
        R_w_c=R_w_c, t_w_c=t_w_c,
        left_valid=True, right_valid=True,
    )
    # t_w_e - t_w_c = [1, 0, 0]
    # R_c_w = R_w_c^T = rot_y(-90) maps [1,0,0] -> [0, 0, -1]
    expected = R_w_c.T @ (t_w_e - t_w_c)
    assert np.allclose(state2[:3], expected, atol=1e-5), \
        f"Left xyz with rotated camera: expected {expected}, got {state2[:3]}"

    print("  PASSED")


def test_near_pi_so3_log():
    """log_SO3 should accurately reconstruct rotations near pi.

    Test angles: pi - 1e-7, pi - 1e-6, pi - 1e-5.
    """
    print("Test: near-pi SO(3) log")
    from scipy.spatial.transform import Rotation as Rot

    for angle_offset in [1e-7, 1e-6, 1e-5, 1e-4]:
        angle = np.pi - angle_offset
        # Random axis
        np.random.seed(42)
        axis = np.random.randn(3)
        axis = axis / np.linalg.norm(axis)
        rotvec = axis * angle
        R_mat = Rot.from_rotvec(rotvec).as_matrix()

        recovered = log_SO3(R_mat.reshape(1, 3, 3)).reshape(3)
        R_recovered = exp_SO3(recovered)

        # Check rotation matrix reconstruction
        max_diff = np.abs(R_mat - R_recovered).max()
        assert max_diff < 1e-4, \
            f"Near-pi reconstruction failed for angle={angle}: " \
            f"max diff = {max_diff} (offset={angle_offset})"

    print("  PASSED")


if __name__ == "__main__":
    print("=" * 60)
    print("Running unified EEF action unit tests")
    print("=" * 60)

    test_log_exp_roundtrip()
    test_identity_camera_identity_wrist()
    test_pure_translation()
    test_pure_rotation()
    test_inverse_consistency()
    test_missing_hand_mask()
    test_action_sequence_shape()
    test_quat_wxyz_to_rotmat()
    test_build_camera_world_pose_from_slam()
    test_no_nan_inf()
    test_effective_indices()
    test_state_camera_translation()
    test_near_pi_so3_log()

    print()
    print("=" * 60)
    print("All tests PASSED!")
    print("=" * 60)

#!/usr/bin/env python3
"""Contract tests for the adapter's instruction-level T5 cache.

An episode re-sends the same instruction with every action chunk, so the encoder
was being run ~450 times per episode on identical text -- about 20% of inference
time, and the reason T5 needed a GPU of its own. Caching is only sound if a
cached lookup is indistinguishable from a fresh encode, which is what this pins.

Run:
  python -m pytest tests/test_t5_instruction_cache.py -q
"""
from __future__ import annotations

import sys
from collections import OrderedDict
from pathlib import Path

import pytest
import torch

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO))


class _FakeEncoder:
    """Deterministic stand-in that counts how often it actually runs."""

    def __init__(self):
        self.calls = []

    def __call__(self, texts, device):
        self.calls.append(list(texts))
        out = []
        for t in texts:
            g = torch.Generator().manual_seed(abs(hash(t)) % (2 ** 31))
            out.append(torch.randn(len(t.split()) + 2, 4096, generator=g))
        return out


@pytest.fixture
def policy():
    """The cache logic of MotusV2DroidJointposPolicy, without the 22 GB model."""
    from robolab_motusv2.adapter import MotusV2DroidJointposPolicy

    p = MotusV2DroidJointposPolicy.__new__(MotusV2DroidJointposPolicy)
    p.torch = torch
    p.device = "cpu"
    p.dtype = torch.float32
    p.t5_device = "cpu"
    p.t5_encoder = _FakeEncoder()
    p._t5_cache = OrderedDict()
    p._t5_cache_max = 3
    p._encode_t5 = MotusV2DroidJointposPolicy._encode_t5.__get__(p)
    return p


def test_repeated_instruction_is_encoded_once(policy):
    text = "Pick up the mustard bottle and place it in the bin on the left side"
    first = policy._encode_t5(text)
    for _ in range(20):
        again = policy._encode_t5(text)
        assert torch.equal(again[0], first[0]), "cached embedding differs from the first"
    assert len(policy.t5_encoder.calls) == 1, \
        f"encoder ran {len(policy.t5_encoder.calls)} times for one instruction"


def test_distinct_instructions_get_distinct_embeddings(policy):
    a = policy._encode_t5("put the banana in the bowl")[0]
    b = policy._encode_t5("close the top drawer")[0]
    assert not torch.equal(a, b[: a.shape[0]]) or a.shape != b.shape
    assert len(policy.t5_encoder.calls) == 2


def test_cache_is_bounded_and_evicts_least_recently_used(policy):
    for i in range(policy._t5_cache_max):
        policy._encode_t5(f"instruction {i}")
    assert len(policy._t5_cache) == policy._t5_cache_max

    policy._encode_t5("instruction 0")          # refresh the oldest
    policy._encode_t5("something new")          # forces one eviction
    assert len(policy._t5_cache) == policy._t5_cache_max
    assert "instruction 0" in policy._t5_cache, "LRU evicted a recently used entry"
    assert "instruction 1" not in policy._t5_cache, "LRU kept the least recent entry"


def test_caller_cannot_corrupt_the_cache(policy):
    """The list is fresh per call, so downstream code cannot swap the entry."""
    text = "wipe the table"
    got = policy._encode_t5(text)
    got.append(torch.zeros(1))
    got2 = policy._encode_t5(text)
    assert len(got2) == 1, "cached entry was mutated by a previous caller"


def test_returned_value_matches_the_uncached_path(policy):
    """A cache hit must equal what a fresh encode would have produced."""
    text = "put the lid on the pot"
    cached = policy._encode_t5(text)[0]
    policy._t5_cache.clear()
    fresh = policy._encode_t5(text)[0]
    assert torch.equal(cached, fresh)


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-q"]))

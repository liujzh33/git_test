#!/usr/bin/env python3
"""Contract tests for the DROID T5 cache format.

The cache used to store every embedding zero-padded to [512, 4096] float32 --
8 MB each, ~1 TB for DROID's instruction set, and slow enough on network storage
that writing dominated prepopulation.  It now stores the raw [num_tokens, 4096]
bfloat16 output and re-pads on load.  These tests pin that the change is
invisible to consumers and that pre-existing caches still load.

Run:
  python -m pytest tests/test_droid_t5_cache.py -q
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest
import torch

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO))


class _Cache:
    """Just the cache logic of DroidLeRobotDataset, without the dataset."""

    def __init__(self, tmp: Path, text_len: int = 512):
        from data.droid.droid_lerobot_dataset import DroidLeRobotDataset

        self.t5_cache_dir = tmp
        self.t5_text_len = text_len
        self._hash_text = DroidLeRobotDataset._hash_text
        for name in ("_validate_t5_embedding", "write_t5_cache_entry", "has_t5_cache_entry"):
            setattr(self, name, getattr(DroidLeRobotDataset, name).__get__(self))


@pytest.fixture
def cache(tmp_path):
    return _Cache(tmp_path)


def test_roundtrip_preserves_values_and_shape(cache):
    emb = torch.randn(13, 4096, dtype=torch.bfloat16).float()
    out = cache.write_t5_cache_entry("pick up the red block", emb)
    assert out.shape == (512, 4096) and out.dtype == torch.float32
    assert torch.equal(out[:13], emb)
    assert out[13:].abs().max() == 0, "tail must be exactly zero padding"


def test_written_file_is_compact(cache, tmp_path):
    cache.write_t5_cache_entry("close the drawer", torch.randn(12, 4096))
    size = next(tmp_path.glob("*.pt")).stat().st_size
    # legacy layout was 512*4096*4 = 8 MB
    assert size < 200 * 1024, f"cache entry is {size/1024:.0f} KB, expected ~98 KB"


def test_legacy_padded_float32_files_still_load(cache, tmp_path):
    """Caches written before this change must keep working."""
    text = "wipe the table"
    emb = torch.randn(9, 4096)
    legacy = torch.cat([emb, torch.zeros(512 - 9, 4096)])
    torch.save(legacy, tmp_path / f"{cache._hash_text(text)}.pt")

    loaded = cache._validate_t5_embedding(
        torch.load(tmp_path / f"{cache._hash_text(text)}.pt", weights_only=True),
        tmp_path,
    )
    assert loaded.shape == (512, 4096)
    assert torch.allclose(loaded[:9], emb)


def test_existence_check_does_not_load(cache):
    text = "put the bowl on the shelf"
    assert not cache.has_t5_cache_entry(text)
    cache.write_t5_cache_entry(text, torch.randn(7, 4096))
    assert cache.has_t5_cache_entry(text)


def test_overlong_instruction_is_truncated(cache):
    out = cache.write_t5_cache_entry("very long", torch.randn(600, 4096))
    assert out.shape == (512, 4096)


def test_rejects_wrong_hidden_size(cache, tmp_path):
    with pytest.raises(ValueError, match="4096"):
        cache._validate_t5_embedding(torch.randn(10, 2048), tmp_path)


def test_prepopulate_resolves_like_the_dataset():
    """The script must request exactly the strings __getitem__ would produce."""
    sys.path.insert(0, str(REPO / "scripts"))
    from prepopulate_droid_t5_cache import resolve_instruction

    f = "language_instruction"
    assert resolve_instruction({f: "wipe the table"}, f, "D") == "wipe the table"
    assert resolve_instruction({f: "  ", "language_instruction_2": "b"}, f, "D") == "b"
    assert resolve_instruction({f: "", "language_instruction_2": None,
                                "language_instruction_3": "c"}, f, "D") == "c"
    assert resolve_instruction({f: "", "language_instruction_2": ""}, f, "D") == "D"


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-q"]))

"""G1-D action chunk time base: sampling stride vs. playback speed.

The model emits a bare ``[action_chunk_size, action_dim]`` tensor with no time
scale attached.  Its wall-clock meaning comes entirely from
``common.global_downsample_rate``, the frame stride the dataset sampled with.
Three things must agree or the robot replays the demonstration at the wrong speed:

  * ``common.global_downsample_rate``                     (what training sampled at)
  * ``G1DLeRobotDataset._calculate_sampling_indices``     (the stride it applies)
  * ``MotusV2PolicyAdapter.resolve_action_interp_factor`` (how serving stretches it back)

A gdr=4 checkpoint served with interpolation factor 1 replays 2.13s of motion in
0.53s.  That is silent in software and destructive on hardware, hence these tests.

The adapter lives in a separate repo; those checks skip if it is not present
(override its location with ``INFERENCE_MOTUS_ROOT``).
"""

import random
import sys
from pathlib import Path

import pytest
import yaml

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

# Reuse the dependency stubbing / cross-repo adapter loader already written for
# the stitch parity tests rather than duplicating it.
from test_g1d_stitch_geometry import _load_inference_adapter  # noqa: E402

from data.g1d.g1d_dataset import G1DLeRobotDataset  # noqa: E402

FPS = 30.0                      # verified against the dataset: info.json, mp4 PTS,
                                # and length/video_span all agree on exactly 30.0
CONFIG = REPO_ROOT / "configs" / "g1d_pick_kettle_wan_vlm_mask.yaml"
EPISODE_LEN = 614               # shortest real episode in pick-kettle-and-cup


def _sample(gdr, num_video_frames=8, video_action_freq_ratio=2, condition_idx=100,
            total_frames=800):
    """Run the real sampler with a pinned condition frame."""
    ds = object.__new__(G1DLeRobotDataset)
    ds.num_video_frames = num_video_frames
    ds.video_action_freq_ratio = video_action_freq_ratio
    ds.global_downsample_rate = gdr
    ds.action_chunk_size = num_video_frames * video_action_freq_ratio

    saved = random.randint
    random.randint = lambda a, b: max(a, min(b, condition_idx))
    try:
        cond, video_idx, action_idx = ds._calculate_sampling_indices(total_frames)
    finally:
        random.randint = saved
    return cond, [v - cond for v in video_idx], [a - cond for a in action_idx]


# --------------------------------------------------------------------------- #
# Dataset side: what the stride does
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize("gdr", [1, 2, 3, 4])
def test_stride_does_not_change_any_tensor_shape(gdr):
    """action_chunk_size = nvf * ratio, independent of the stride.

    This is why the stride is safe to retune: every checkpoint tensor keeps its
    shape, so pretrained weights stay loadable.
    """
    _, video_offsets, action_offsets = _sample(gdr)
    assert len(action_offsets) == 16
    assert len(video_offsets) == 8


@pytest.mark.parametrize("gdr, seconds", [(1, 16 / FPS), (2, 32 / FPS), (4, 64 / FPS)])
def test_stride_scales_the_horizon(gdr, seconds):
    _, _, action_offsets = _sample(gdr)
    assert action_offsets == [(i + 1) * gdr for i in range(16)]
    assert action_offsets[-1] / FPS == pytest.approx(seconds)


@pytest.mark.parametrize("gdr", [1, 2, 4])
def test_video_frames_cover_the_same_window_as_the_actions(gdr):
    """The video and action heads must describe the same slice of time."""
    _, video_offsets, action_offsets = _sample(gdr)
    assert video_offsets[-1] == action_offsets[-1]
    assert video_offsets == [(i + 1) * 2 * gdr for i in range(8)]


def test_shortest_real_episode_still_yields_samples_at_the_shipped_stride():
    """physical_chunk = 16 * gdr must fit inside the shortest episode."""
    gdr = yaml.safe_load(CONFIG.read_text())["common"]["global_downsample_rate"]
    physical_chunk = 16 * gdr
    assert physical_chunk + 2 <= EPISODE_LEN, (
        f"stride {gdr} needs {physical_chunk + 2} frames but the shortest G1-D "
        f"episode is {EPISODE_LEN}; episodes would be silently dropped"
    )


def test_shipped_config_targets_a_two_second_horizon():
    """Pin the intent of the shipped config, not just its internal consistency."""
    common = yaml.safe_load(CONFIG.read_text())["common"]
    chunk = common["num_video_frames"] * common["video_action_freq_ratio"]
    horizon = chunk * common["global_downsample_rate"] / FPS
    assert horizon == pytest.approx(2.13, abs=0.05), (
        f"action horizon drifted to {horizon:.2f}s; update this test deliberately "
        f"if the target duration changed"
    )


# --------------------------------------------------------------------------- #
# Serving side: stretching the chunk back to real time
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize("gdr", [1, 2, 3, 4])
def test_auto_interp_factor_restores_the_demonstrated_duration(gdr):
    """factor=0 must reproduce the sampled span when executed one step per tick."""
    resolve = _load_inference_adapter().resolve_action_interp_factor
    factor = resolve(0, gdr)

    _, _, action_offsets = _sample(gdr)
    demonstrated = action_offsets[-1] / FPS
    executed = len(action_offsets) * factor / FPS

    assert factor == gdr
    assert executed == pytest.approx(demonstrated), (
        f"gdr={gdr}: chunk spans {demonstrated:.2f}s but would execute in "
        f"{executed:.2f}s ({demonstrated / executed:.2f}x speed)"
    )


def test_auto_interp_factor_matches_the_shipped_config():
    """The two repos' defaults must line up for the config we actually train with."""
    resolve = _load_inference_adapter().resolve_action_interp_factor
    gdr = yaml.safe_load(CONFIG.read_text())["common"]["global_downsample_rate"]
    assert resolve(0, gdr) == gdr


@pytest.mark.parametrize("factor", [1, 4, 5])
def test_explicit_interp_factor_overrides_auto(factor):
    """A positive value is taken verbatim, e.g. to buy async continuity."""
    resolve = _load_inference_adapter().resolve_action_interp_factor
    assert resolve(factor, 4) == factor


def test_missing_stride_key_falls_back_to_no_interpolation():
    """Older configs without the key must behave exactly as before."""
    resolve = _load_inference_adapter().resolve_action_interp_factor
    assert resolve(0, 1) == 1

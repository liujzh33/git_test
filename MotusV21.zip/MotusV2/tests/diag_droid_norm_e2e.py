#!/usr/bin/env python3
"""End-to-end check of the new DROID normalization on real data.

Pulls real samples through the *actual* training dataset, then applies the
*actual* inference-side inverse, and verifies the absolute joint targets that
RoboLab would receive match the ground-truth parquet actions.

Also reports the target statistics that motivated the change, so the effect is
visible rather than assumed.

Run:
  PYTHONPATH=/tmp/diag_pkgs python tests/diag_droid_norm_e2e.py
"""
from __future__ import annotations

import argparse
import random
import sys
from pathlib import Path

import numpy as np

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO))
sys.path.insert(0, str(REPO / "tests"))

DATA = "/home/work/cache/wx1469573/data/droid_1.0.1-lerobot"
VLM = "/cache/wx1469573/pretrained_models/Qwen3-VL-2B-Instruct"


def build(num_meta_files: int, normalize: bool):
    from diag_droid_replay import _stub_decord

    _stub_decord()
    from data.droid.droid_lerobot_dataset import DroidLeRobotDataset

    class _Fast(DroidLeRobotDataset):
        def _index_episodes(self):
            import pandas as pd

            cams = (self.top_camera_key, self.bottom_left_camera_key, self.bottom_right_camera_key)
            fields = ("top_video", "bottom_left_video", "bottom_right_video")
            starts = ("top_start_frame", "bottom_left_start_frame", "bottom_right_start_frame")
            eps = []
            for epf in sorted((self.root / "meta" / "episodes").rglob("*.parquet"))[:num_meta_files]:
                for _, row in pd.read_parquet(epf).iterrows():
                    paths, offs, bad = [], [], False
                    for cam in cams:
                        p = self._video_path(cam, int(row[f"videos/{cam}/chunk_index"]),
                                             int(row[f"videos/{cam}/file_index"]))
                        if not p.exists() or p.stat().st_size < 1024 * 1024:
                            bad = True
                            break
                        paths.append(str(p))
                        offs.append(int(round(float(row[f"videos/{cam}/from_timestamp"]) * self.fps)))
                    if bad or not self._data_path(int(row["data/chunk_index"]), int(row["data/file_index"])).exists():
                        continue
                    e = {"episode_index": int(row["episode_index"]), "length": int(row["length"]),
                         "data_chunk": int(row["data/chunk_index"]), "data_file": int(row["data/file_index"])}
                    e.update(dict(zip(fields, paths)))
                    e.update(dict(zip(starts, offs)))
                    eps.append(e)
            self.episodes = eps

    return _Fast(
        dataset_dir=DATA, num_video_frames=8, video_size=(288, 320),
        global_downsample_rate=1, video_action_freq_ratio=2,
        vlm_checkpoint_path=None, t5_mode="none", camera_layout="t_shape",
        action_normalization=normalize,
    )


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--num-samples", type=int, default=24)
    args = ap.parse_args()

    from data.droid.droid_norm import DroidNormalizer

    norm = DroidNormalizer.from_stats_file(REPO / "data/droid/droid_norm_stats.json")

    # Same seed -> same episodes/frames from both datasets, so raw and
    # normalized samples correspond one-to-one.
    def collect(normalize: bool):
        random.seed(7)
        np.random.seed(7)
        ds = build(1, normalize)
        out = []
        while len(out) < args.num_samples:
            s = ds[len(out)]
            if s is not None:
                out.append((s["initial_state"].numpy(), s["action_sequence"].numpy()))
        return out

    raw = collect(False)
    normed = collect(True)

    worst = 0.0
    for (raw_state, raw_act), (n_state, n_act) in zip(raw, normed):
        # Adapter path: normalize the raw state in, denormalize the output back.
        assert np.allclose(n_state, norm.normalize_state(raw_state), atol=1e-5), "state transform drift"
        recovered = norm.from_model_actions(n_act, raw_state)
        worst = max(worst, float(np.abs(recovered - raw_act).max()))

    R = np.concatenate([a for _, a in raw], 0)
    N = np.concatenate([a for _, a in normed], 0)
    S = np.stack([s for s, _ in raw], 0)

    np.set_printoptions(precision=4, suppress=True, linewidth=200)
    print(f"samples: {len(raw)}")
    print(f"\nmax |recovered - ground truth| over all dims: {worst:.6f} rad")

    print("\n=== OLD target (raw absolute qpos, what the 0%-checkpoint regressed) ===")
    print("  mean          ", R.mean(0))
    print("  std           ", R.std(0))
    hold = np.abs(R[:, :7] - np.repeat(S[:, :7], R.shape[0] // S.shape[0], axis=0)[: len(R)]).mean()
    print(f"  |action-state| / std(target)  = {hold / R[:, :7].std(0).mean():.3f}"
          "   <- fraction of the target the policy actually has to predict")

    print("\n=== NEW target (delta + q01/q99 -> [-1,1]) ===")
    print("  mean          ", N.mean(0))
    print("  std           ", N.std(0))
    print("  min/max       ", N.min(), N.max())
    print(f"  arm |target| mean = {np.abs(N[:, :7]).mean():.4f}"
          "   <- now O(0.1-0.3) against unit-Gaussian flow noise")

    ok = worst < 1e-4
    print("\nRESULT:", "PASS — train encode / infer decode are exact inverses" if ok else "FAIL")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
"""End-to-end check of DROID success + idle filtering on real data.

Verifies three things that unit tests cannot:
  1. require_success actually removes episodes at index time.
  2. Sampled chunks really do land inside non-idle segments.
  3. Filtered sampling yields chunks with more motion -- the whole point, since
     idle chunks are what teach the policy to stand still.

Run:
  PYTHONPATH=/tmp/diag_pkgs python tests/diag_droid_filter_e2e.py
"""
from __future__ import annotations

import argparse
import random
import sys
from pathlib import Path

import numpy as np

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO))
sys.path.insert(0, str(REPO / "tests"))

DATA = "/home/work/cache/wx1469573/data/droid_1.0.1-lerobot"


def build(num_meta_files: int, **kw):
    from diag_droid_replay import _stub_decord

    _stub_decord()
    from data.droid.droid_lerobot_dataset import DroidLeRobotDataset

    class _Fast(DroidLeRobotDataset):
        """Same behaviour, but only scans a slice of the episode metadata."""

        def _index_episodes(self):
            import pandas as pd

            cams = (self.top_camera_key, self.bottom_left_camera_key, self.bottom_right_camera_key)
            fields = ("top_video", "bottom_left_video", "bottom_right_video")
            starts = ("top_start_frame", "bottom_left_start_frame", "bottom_right_start_frame")
            eps, self.n_scanned, self.n_failed = [], 0, 0
            for epf in sorted((self.root / "meta" / "episodes").rglob("*.parquet"))[:num_meta_files]:
                for _, row in pd.read_parquet(epf).iterrows():
                    self.n_scanned += 1
                    col = "stats/is_episode_successful/mean"
                    if self.require_success and float(np.asarray(row[col]).ravel()[0]) < 0.5:
                        self.n_failed += 1
                        continue
                    paths, offs, bad = [], [], False
                    for cam in cams:
                        p = self._video_path(cam, int(row[f"videos/{cam}/chunk_index"]),
                                             int(row[f"videos/{cam}/file_index"]))
                        if not p.exists() or p.stat().st_size < 1024 * 1024:
                            bad = True
                            break
                        paths.append(str(p))
                        offs.append(int(round(float(row[f"videos/{cam}/from_timestamp"]) * self.fps)))
                    if bad or not self._data_path(int(row["data/chunk_index"]), int(row["data/file_index"])).exists():
                        continue
                    e = {"episode_index": int(row["episode_index"]), "length": int(row["length"]),
                         "data_chunk": int(row["data/chunk_index"]), "data_file": int(row["data/file_index"])}
                    e.update(dict(zip(fields, paths)))
                    e.update(dict(zip(starts, offs)))
                    eps.append(e)
            self.episodes = eps

    return _Fast(
        dataset_dir=DATA, num_video_frames=8, video_size=(288, 320),
        global_downsample_rate=1, video_action_freq_ratio=2,
        vlm_checkpoint_path=None, t5_mode="none", camera_layout="t_shape", **kw
    )


def sample_chunk_motion(ds, n, seed=0):
    """Bypass video decoding: replay the sampler and measure motion in the chunk."""
    from data.droid.droid_filter import compute_keep_ranges

    random.seed(seed)
    motions, inside, total = [], 0, 0
    span = ds.action_chunk_size * ds.global_downsample_rate
    guard = 0
    while len(motions) < n and guard < n * 40:
        guard += 1
        ep = ds.episodes[random.randint(0, len(ds.episodes) - 1)]
        if ep["length"] < span + 2:
            continue
        rows = ds._load_parquet_rows(ep["data_chunk"], ep["data_file"], ep["episode_index"])
        try:
            windows = ds._condition_windows(ep["episode_index"], rows)
            cond, _, action_idx = ds._calculate_sampling_indices(min(ep["length"], len(rows)), windows)
        except Exception:
            continue
        if len(rows) <= action_idx[-1]:
            continue
        acts = np.stack([np.asarray(rows.iloc[i]["action"], dtype=np.float32) for i in action_idx])
        motions.append(float(np.abs(acts[:, :7] - acts[0, :7]).max()))

        jv = np.stack(rows["action.joint_velocity"].to_numpy()).astype(np.float32)
        keep = compute_keep_ranges(jv)
        total += 1
        inside += any(s <= cond and cond + span <= e for s, e in keep)
    return np.array(motions), inside, total


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--num-samples", type=int, default=400)
    ap.add_argument("--num-meta-files", type=int, default=1)
    args = ap.parse_args()

    print("=== 1. index-time success filtering ===")
    ds_on = build(args.num_meta_files, require_success=True, filter_idle=True)
    ds_off = build(args.num_meta_files, require_success=False, filter_idle=False)
    print(f"  episodes scanned              : {ds_off.n_scanned}")
    print(f"  indexed without filtering     : {len(ds_off.episodes)}")
    print(f"  indexed with require_success  : {len(ds_on.episodes)}"
          f"   (dropped {ds_on.n_failed} failed episodes)")

    print("\n=== 2 & 3. chunk sampling ===")
    m_off, in_off, tot_off = sample_chunk_motion(ds_off, args.num_samples, seed=1)
    m_on, in_on, tot_on = sample_chunk_motion(ds_on, args.num_samples, seed=1)

    print(f"  chunks fully inside a non-idle segment:")
    print(f"    unfiltered : {in_off}/{tot_off}  ({100*in_off/max(tot_off,1):.1f}%)")
    print(f"    filtered   : {in_on}/{tot_on}  ({100*in_on/max(tot_on,1):.1f}%)")

    dead = lambda m: float((m < 0.02).mean())
    print(f"\n  max |Δq| within the 16-step chunk (rad):")
    print(f"    unfiltered : mean {m_off.mean():.4f}   median {np.median(m_off):.4f}"
          f"   near-static chunks (<0.02) {100*dead(m_off):.1f}%")
    print(f"    filtered   : mean {m_on.mean():.4f}   median {np.median(m_on):.4f}"
          f"   near-static chunks (<0.02) {100*dead(m_on):.1f}%")

    ok = in_on == tot_on and dead(m_on) < dead(m_off)
    print("\nRESULT:", "PASS" if ok else "FAIL")
    if in_on != tot_on:
        print("  -> some sampled chunks escaped their non-idle segment")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())

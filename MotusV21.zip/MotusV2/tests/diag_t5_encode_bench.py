#!/usr/bin/env python3
"""Benchmark UMT5-XXL instruction encoding and verify optimizations are lossless.

prepopulate_droid_t5_cache.py encodes one instruction per forward pass, padded
to 512 tokens, for ~123k instructions -- about 5 hours.  This measures what
batching and dynamic-length tokenization actually buy, and checks that both
produce the same embeddings as the current path (they must, or existing cache
entries would silently disagree with new ones).

Run:
  CUDA_VISIBLE_DEVICES=0 PYTHONPATH=/tmp/diag_pkgs python tests/diag_t5_encode_bench.py
"""
from __future__ import annotations

import os
import sys
import time
from pathlib import Path

import torch

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO))
sys.path.insert(0, str(REPO / "bak"))
# bak/wan pulls in diffusers, which the RoboLab venv does not carry.
for _p in os.environ.get("MOTUS_EXTRA_SITE_PACKAGES", "").split(os.pathsep):
    if _p and _p not in sys.path:
        sys.path.append(_p)

WAN = "/cache/wx1469573/pretrained_models/Wan2.2-TI2V-5B"

SAMPLES = [
    "Put the blue block in the green bowl",
    "Move the bottom right tip of the duvet to the left",
    "Pick up the longer upright white container from the table and put it in the orange plastic bag",
    "Close the open drawer",
    "Use the white cloth to wipe the table",
    "manipulate the object",
    "Take the white plate off of the can and place it on the blue bowl",
    "Open the storage bin, then place the blue bottle inside it",
]


def encode_batched(enc, texts, device, dynamic=False):
    """Same math as T5EncoderModel.__call__, optionally padding to the batch's
    longest sequence instead of the tokenizer's fixed 512.

    HuggingfaceTokenizer hardcodes padding='max_length' from its own seq_len, so
    the override has to be passed explicitly -- omitting it silently keeps 512.
    """
    kwargs = {"padding": True, "truncation": True, "max_length": 512} if dynamic else {}
    ids, mask = enc.tokenizer(texts, return_mask=True, add_special_tokens=True, **kwargs)
    ids, mask = ids.to(device), mask.to(device)
    seq_lens = mask.gt(0).sum(dim=1).long()
    ctx = enc.model(ids, mask)
    return [u[:v] for u, v in zip(ctx, seq_lens)]


def main() -> int:
    from wan.modules.t5 import T5EncoderModel

    device = "cuda"
    print("loading UMT5-XXL ...", flush=True)
    enc = T5EncoderModel(
        text_len=512, dtype=torch.bfloat16, device=device,
        checkpoint_path=str(Path(WAN) / "models_t5_umt5-xxl-enc-bf16.pth"),
        tokenizer_path=str(Path(WAN) / "google" / "umt5-xxl"),
    )

    texts = (SAMPLES * 64)[:512]

    # token length reality check
    ids, mask = enc.tokenizer(SAMPLES, return_mask=True, add_special_tokens=True)
    lens = mask.gt(0).sum(1).tolist()
    print(f"\nreal token lengths: {lens}  (tokenizer pads every one of them to 512)")

    print("\n=== reference: current path, batch=1, pad=512 ===", flush=True)
    with torch.no_grad():
        ref = [enc([t], device)[0].float().cpu() for t in SAMPLES]
    torch.cuda.synchronize()
    t0 = time.time()
    with torch.no_grad():
        for t in texts[:64]:
            enc([t], device)
    torch.cuda.synchronize()
    base = (time.time() - t0) / 64
    print(f"  {base*1000:.1f} ms/instruction  ->  {1/base:.1f} instr/s")
    print(f"  projected for 123,263 instructions: {123263*base/3600:.2f} h")

    # Batching alone does not help: T5 materializes a [B, H, L, L] fp32 attention
    # matrix, so at L=512 the GPU is already saturated by one sample and larger
    # batches simply OOM.  The length is the lever, not the batch.
    for bs in (8, 32):
        torch.cuda.synchronize()
        t0 = time.time()
        with torch.no_grad():
            for i in range(0, len(texts), bs):
                encode_batched(enc, texts[i:i + bs], device, dynamic=False)
        torch.cuda.synchronize()
        per = (time.time() - t0) / len(texts)
        print(f"\n=== batch={bs}, pad=512 ===")
        print(f"  {per*1000:.2f} ms/instruction  ->  {1/per:.0f} instr/s   ({base/per:.1f}x)")
        print(f"  projected for 123,263: {123263*per/3600:.3f} h")

    for bs in (32, 128, 256):
        torch.cuda.synchronize()
        t0 = time.time()
        with torch.no_grad():
            for i in range(0, len(texts), bs):
                encode_batched(enc, texts[i:i + bs], device, dynamic=True)
        torch.cuda.synchronize()
        per = (time.time() - t0) / len(texts)
        print(f"\n=== batch={bs}, dynamic length ===")
        print(f"  {per*1000:.2f} ms/instruction  ->  {1/per:.0f} instr/s   ({base/per:.1f}x)")
        print(f"  projected for 123,263: {123263*per/3600:.3f} h")

    print("\n=== losslessness vs the current path ===")
    for label, dyn in [("batch=8, pad=512", False), ("batch=8, dynamic", True)]:
        with torch.no_grad():
            got = encode_batched(enc, SAMPLES, device, dynamic=dyn)
        worst = max(
            float((g.float().cpu() - r).abs().max()) for g, r in zip(got, ref)
        )
        shapes_ok = all(g.shape == r.shape for g, r in zip(got, ref))
        print(f"  {label:18s} shapes match={shapes_ok}  max|Δ|={worst:.3e}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

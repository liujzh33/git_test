#!/usr/bin/env python3
"""Ablate each conditioning input to see what the DROID checkpoint actually uses.

For real training samples, run inference_step with:
  base    : correct image + correct instruction + correct state
  repeat  : identical inputs again (measures the sampler's own noise floor)
  blackim : all-black condition frame
  otherim : condition frame from a different episode
  badtext : unrelated instruction
  jitstate: state perturbed by +0.3 rad on every arm joint

If `blackim`/`otherim`/`badtext` deltas are at the level of `repeat` (the noise
floor), the model is ignoring that input.  If `jitstate` tracks the perturbation,
the model is a state-copier.

Run:
  CUDA_VISIBLE_DEVICES=5,6 PYTHONPATH=/tmp/diag_pkgs python tests/diag_droid_ablation.py
"""
from __future__ import annotations

import argparse
import json
import random
import sys
from pathlib import Path

import numpy as np
import torch

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO))
sys.path.insert(0, str(REPO / "tests"))

from diag_droid_replay import CFG, CKPT, DATA, VLM, WAN, build_dataset  # noqa: E402

JOINT_NAMES = [f"j{i}" for i in range(7)] + ["grip"]


def run(policy, frame_chw, state_np, instr):
    ff = frame_chw.unsqueeze(0).to(policy.device, dtype=policy.dtype)
    st = torch.from_numpy(state_np).unsqueeze(0).to(policy.device, dtype=policy.dtype)
    lang = policy._encode_t5(instr)
    vlm_inputs = policy._build_vlm_inputs(instr, ff[0])
    with torch.no_grad():
        _, pred = policy.model.inference_step(
            first_frame=ff, state=st,
            num_inference_steps=policy.contract.num_inference_timesteps,
            language_embeddings=lang, vlm_inputs=vlm_inputs,
        )
    return pred.squeeze(0).float().cpu().numpy()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--num-samples", type=int, default=10)
    ap.add_argument("--num-meta-files", type=int, default=1)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--out", default="/tmp/diag_droid_ablation.json")
    args = ap.parse_args()

    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)

    from robolab_motusv2.adapter import MotusV2DroidJointposPolicy

    policy = MotusV2DroidJointposPolicy(
        checkpoint_path=CKPT, config_path=CFG, wan_path=WAN, vlm_path=VLM,
        device="cuda:0", t5_device="cuda:1",
    )
    ds = build_dataset(args.num_meta_files)
    print(f"episodes indexed: {len(ds.episodes)}", flush=True)

    samples = []
    while len(samples) < args.num_samples:
        s = ds[len(samples)]
        if s is not None:
            samples.append(s)
    print(f"collected {len(samples)} samples", flush=True)

    conds = ["repeat", "blackim", "otherim", "badtext", "jitstate"]
    acc = {c: [] for c in conds}
    acc_gt, acc_hold, acc_deltacorr, acc_jit_track = [], [], [], []

    for i, s in enumerate(samples):
        frame = s["first_frame"]
        state = s["initial_state"].numpy()
        gt = s["action_sequence"].numpy()
        instr = s["task_name"]
        other = samples[(i + 1) % len(samples)]["first_frame"]

        base = run(policy, frame, state, instr)
        variants = {
            "repeat": run(policy, frame, state, instr),
            "blackim": run(policy, torch.zeros_like(frame), state, instr),
            "otherim": run(policy, other, state, instr),
            "badtext": run(policy, frame, state, "close the refrigerator door"),
            "jitstate": run(policy, frame, state + np.r_[np.full(7, 0.3, np.float32), 0.0], instr),
        }
        for c, v in variants.items():
            acc[c].append(np.abs(v[:, :7] - base[:, :7]).mean())

        hold = np.tile(state[None, :], (gt.shape[0], 1))
        acc_gt.append(np.abs(base[:, :7] - gt[:, :7]).mean())
        acc_hold.append(np.abs(hold[:, :7] - gt[:, :7]).mean())
        # Does the predicted motion point the same way as the true motion?
        pd_ = (base[:, :7] - state[None, :7]).ravel()
        gd_ = (gt[:, :7] - state[None, :7]).ravel()
        denom = np.linalg.norm(pd_) * np.linalg.norm(gd_)
        acc_deltacorr.append(float(pd_ @ gd_ / denom) if denom > 0 else 0.0)
        # How much of a +0.3 rad state shift is copied into the output?
        acc_jit_track.append(float((variants["jitstate"][:, :7] - base[:, :7]).mean() / 0.3))

        print(f"[{i}] {instr[:45]!r:48s} " + " ".join(f"{c}={acc[c][-1]:.4f}" for c in conds), flush=True)

    print("\n================ ABLATION (mean |Δ arm action| vs base, rad) ================")
    for c in conds:
        print(f"  {c:10s} {np.mean(acc[c]):.4f}")
    print("\n================ SKILL ================")
    print(f"  MAE base vs GT        : {np.mean(acc_gt):.4f} rad")
    print(f"  MAE hold-state vs GT  : {np.mean(acc_hold):.4f} rad   <- trivial baseline")
    print(f"  cos(pred-Δ, GT-Δ)     : {np.mean(acc_deltacorr):+.4f}   <- 0 means no directional skill")
    print(f"  state-shift passthru  : {np.mean(acc_jit_track):+.4f}   <- 1.0 means pure state copy")

    to_list = lambda xs: [float(x) for x in xs]
    json.dump({
        "ablation": {c: to_list(acc[c]) for c in conds},
        "mae_gt": to_list(acc_gt), "mae_hold": to_list(acc_hold),
        "delta_cos": to_list(acc_deltacorr), "jit_track": to_list(acc_jit_track),
    }, open(args.out, "w"), indent=2)
    print("\nwrote", args.out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

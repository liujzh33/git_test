#!/usr/bin/env python3
"""End-to-end check of the v_stack layout on real DROID data.

Verifies on actual episodes that:
  1. the dataset produces v_stack frames of the configured size,
  2. the RoboLab inference adapter lays the same cameras out identically,
  3. t_shape still produces exactly what it did before the refactor,
and dumps a side-by-side image so the wrist view can be judged by eye.

Run:
  PYTHONPATH=/tmp/diag_pkgs python tests/diag_droid_vstack_e2e.py
"""
from __future__ import annotations

import argparse
import random
import sys
from pathlib import Path

import numpy as np

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO))
sys.path.insert(0, str(REPO / "tests"))

DATA = "/home/work/cache/wx1469573/data/droid_1.0.1-lerobot"


def build(layout, size, num_meta_files=1, **kw):
    from diag_droid_replay import _stub_decord

    _stub_decord()
    from data.droid.droid_lerobot_dataset import DroidLeRobotDataset

    class _Fast(DroidLeRobotDataset):
        def _index_episodes(self):
            import pandas as pd

            if self.camera_layout == "v_stack":
                cams = (*self.exterior_camera_keys, self.wrist_camera_key)
                n = len(self.exterior_camera_keys)
                vf = (*(f"ext{i}_video" for i in range(n)), "wrist_video")
                sf = (*(f"ext{i}_start_frame" for i in range(n)), "wrist_start_frame")
            else:
                cams = (self.top_camera_key, self.bottom_left_camera_key, self.bottom_right_camera_key)
                vf = ("top_video", "bottom_left_video", "bottom_right_video")
                sf = ("top_start_frame", "bottom_left_start_frame", "bottom_right_start_frame")
            eps = []
            for epf in sorted((self.root / "meta" / "episodes").rglob("*.parquet"))[:num_meta_files]:
                for _, row in pd.read_parquet(epf).iterrows():
                    col = "stats/is_episode_successful/mean"
                    if self.require_success and float(np.asarray(row[col]).ravel()[0]) < 0.5:
                        continue
                    paths, offs, bad = [], [], False
                    for cam in cams:
                        p = self._video_path(cam, int(row[f"videos/{cam}/chunk_index"]),
                                             int(row[f"videos/{cam}/file_index"]))
                        if not p.exists() or p.stat().st_size < 1024 * 1024:
                            bad = True
                            break
                        paths.append(str(p))
                        offs.append(int(round(float(row[f"videos/{cam}/from_timestamp"]) * self.fps)))
                    if bad or not self._data_path(int(row["data/chunk_index"]), int(row["data/file_index"])).exists():
                        continue
                    e = {"episode_index": int(row["episode_index"]), "length": int(row["length"]),
                         "data_chunk": int(row["data/chunk_index"]), "data_file": int(row["data/file_index"])}
                    e.update(dict(zip(vf, paths)))
                    e.update(dict(zip(sf, offs)))
                    eps.append(e)
            self.episodes = eps

    params = dict(dataset_dir=DATA, num_video_frames=8, video_size=size,
                  global_downsample_rate=1, video_action_freq_ratio=2,
                  vlm_checkpoint_path=None, t5_mode="none", camera_layout=layout)
    params.update(kw)
    return _Fast(**params)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--num-samples", type=int, default=4)
    ap.add_argument("--out", default="/tmp/vstack_compare.png")
    args = ap.parse_args()

    from PIL import Image

    from data.droid.droid_stitch import describe_token_budget
    from robolab_motusv2.adapter import DroidInferenceContract, build_first_frame

    print("=== 视觉预算 ===")
    print("  t_shape 288x320:", describe_token_budget("t_shape", 288, 320))
    print("  v_stack 384x320:", describe_token_budget("v_stack", 384, 320))

    # --- dataset side --------------------------------------------------
    random.seed(11); np.random.seed(11)
    ds_v = build("v_stack", (384, 320), random_exterior=False)
    print(f"\nepisodes indexed (v_stack): {len(ds_v.episodes)}")
    frames_v = []
    while len(frames_v) < args.num_samples:
        s = ds_v[len(frames_v)]
        if s is not None:
            frames_v.append(s["first_frame"].numpy())

    random.seed(11); np.random.seed(11)
    ds_t = build("t_shape", (288, 320))
    frames_t = []
    while len(frames_t) < args.num_samples:
        s = ds_t[len(frames_t)]
        if s is not None:
            frames_t.append(s["first_frame"].numpy())

    for f in frames_v:
        assert f.shape == (3, 384, 320), f"v_stack frame is {f.shape}"
    print("v_stack frames have the configured size")

    # --- inference side must match the dataset -------------------------
    cfg = REPO / "configs/droid_wan_vlm_mask_2cam.yaml"
    contract = DroidInferenceContract.from_config(cfg)
    print(f"\n推理契约: layout={contract.camera_layout} "
          f"{contract.video_height}x{contract.video_width}")
    assert contract.camera_layout == "v_stack"

    rng = np.random.default_rng(0)
    ext = rng.integers(0, 256, (720, 1280, 3), dtype=np.uint8)
    wrist = rng.integers(0, 256, (720, 1280, 3), dtype=np.uint8)
    infer = build_first_frame({"exterior_image": ext, "wrist_image": wrist}, contract)

    from data.droid.droid_stitch import stitch_frame
    train_equiv = stitch_frame("v_stack", [ext, wrist], 384, 320).astype(np.float32) / 255.0
    err = float(np.abs(infer - train_equiv).max())
    print(f"训练端 vs 推理端 同一几何: max|Δ|={err:.2e}")
    assert err == 0.0, "dataset and adapter disagree on the v_stack layout"

    # missing camera must fail loudly rather than silently mis-stitch
    try:
        build_first_frame({"exterior_image": ext}, contract)
        print("!! 缺相机没有报错")
        return 1
    except ValueError as e:
        print(f"缺相机会明确报错: {str(e)[:70]}...")

    # --- visual dump ---------------------------------------------------
    def to_img(chw):
        return (chw.transpose(1, 2, 0) * 255).clip(0, 255).astype(np.uint8)

    H = 384
    tiles = []
    for a, b in zip(frames_t, frames_v):
        ta, tb = to_img(a), to_img(b)
        pad = np.zeros((H - ta.shape[0], ta.shape[1], 3), dtype=np.uint8)
        tiles.append(np.concatenate([np.concatenate([ta, pad], 0), tb], axis=1))
    Image.fromarray(np.concatenate(tiles, axis=1)).save(args.out)
    print(f"\n对比图已写出: {args.out}  (每组左=t_shape 288, 右=v_stack 384)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

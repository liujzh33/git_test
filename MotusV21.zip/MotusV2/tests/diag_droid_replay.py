#!/usr/bin/env python3
"""Replay real DROID training samples through the RoboLab inference adapter.

Answers one question: does the trained checkpoint reproduce its own training
distribution when driven by the inference code path?  If it does, the 0%
RoboLab score is a sim/domain or eval-side problem.  If it does not, the bug is
in the train<->inference contract.

Run:
  CUDA_VISIBLE_DEVICES=5,6 python tests/diag_droid_replay.py --num-samples 8
"""
from __future__ import annotations

import argparse
import json
import random
import sys
from pathlib import Path

import numpy as np
import torch

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO))

DATA = "/home/work/cache/wx1469573/data/droid_1.0.1-lerobot"
WAN = "/cache/wx1469573/pretrained_models/Wan2.2-TI2V-5B"
VLM = "/cache/wx1469573/pretrained_models/Qwen3-VL-2B-Instruct"
CKPT = "/home/work/wenjj/ckpt/MotusV2Droid_v2_3W"
CFG = str(REPO / "configs/droid_wan_vlm_mask_stage2_15w.yaml")

JOINT_NAMES = [f"j{i}" for i in range(7)] + ["grip"]


def _stub_decord() -> None:
    """data/utils/image_utils.py imports decord at module scope; the DROID
    dataset decodes with PyAV and never touches it."""
    if "decord" in sys.modules:
        return
    import types

    mod = types.ModuleType("decord")
    mod.VideoReader = None
    mod.cpu = lambda *a, **k: None
    sys.modules["decord"] = mod


def build_dataset(num_meta_files: int, layout: str = "t_shape",
                  video_size=(288, 320), **overrides):
    _stub_decord()
    from data.droid.droid_lerobot_dataset import DroidLeRobotDataset

    class _FastIndexDroid(DroidLeRobotDataset):
        """Same sampling logic, but only scans the first N meta parquet files."""

        _num_meta_files = num_meta_files

        def _index_episodes(self):
            import pandas as pd

            meta_dir = self.root / "meta" / "episodes"
            ep_files = sorted(meta_dir.rglob("*.parquet"))[: self._num_meta_files]
            # Mirror the real indexer's per-layout camera slots, so this fast
            # path works for v_stack as well as t_shape.
            if self.camera_layout == "v_stack":
                cam_keys = (*self.exterior_camera_keys, self.wrist_camera_key)
                n_ext = len(self.exterior_camera_keys)
                video_fields = (*(f"ext{i}_video" for i in range(n_ext)), "wrist_video")
                start_fields = (*(f"ext{i}_start_frame" for i in range(n_ext)), "wrist_start_frame")
            else:
                cam_keys = (self.top_camera_key, self.bottom_left_camera_key, self.bottom_right_camera_key)
                video_fields = ("top_video", "bottom_left_video", "bottom_right_video")
                start_fields = ("top_start_frame", "bottom_left_start_frame", "bottom_right_start_frame")
            success_col = "stats/is_episode_successful/mean"
            all_eps = []
            for epf in ep_files:
                ep = pd.read_parquet(epf)
                for _, row in ep.iterrows():
                    if self.require_success and success_col in row.index:
                        if float(np.asarray(row[success_col]).ravel()[0]) < 0.5:
                            continue
                    cam_paths, cam_starts, missing = [], [], False
                    for cam in cam_keys:
                        vpath = self._video_path(cam, int(row[f"videos/{cam}/chunk_index"]),
                                                 int(row[f"videos/{cam}/file_index"]))
                        if not vpath.exists() or vpath.stat().st_size < 1024 * 1024:
                            missing = True
                            break
                        cam_paths.append(str(vpath))
                        cam_starts.append(int(round(float(row[f"videos/{cam}/from_timestamp"]) * self.fps)))
                    if missing:
                        continue
                    dpath = self._data_path(int(row["data/chunk_index"]), int(row["data/file_index"]))
                    if not dpath.exists():
                        continue
                    entry = {
                        "episode_index": int(row["episode_index"]),
                        "length": int(row["length"]),
                        "data_chunk": int(row["data/chunk_index"]),
                        "data_file": int(row["data/file_index"]),
                    }
                    entry.update(dict(zip(video_fields, cam_paths)))
                    entry.update(dict(zip(start_fields, cam_starts)))
                    all_eps.append(entry)
            self.episodes = all_eps

    params = dict(
        dataset_dir=DATA,
        camera_layout=layout,
        video_size=video_size,
        num_video_frames=8,
        global_downsample_rate=1,
        video_action_freq_ratio=2,
        vlm_checkpoint_path=VLM,
        t5_mode="none",           # T5 comes from the policy's own encoder below
        instruction_field="language_instruction",
    )
    params.update(overrides)
    return _FastIndexDroid(**params)


def dataset_params_from_config(config_path: str) -> dict:
    """Sampling/filtering contract from a config.

    ``action_normalization`` is deliberately forced off: this script keeps ground
    truth in raw radians and instead pushes the model's output back through the
    adapter's own inverse transform.  Every checkpoint is then scored in the same
    physical units RoboLab actually receives, so raw-qpos and normalized-delta
    checkpoints are directly comparable.
    """
    import yaml

    with open(config_path, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    ds, common = cfg["dataset"], cfg["common"]
    params = {
        "action_normalization": False,
        "require_success": bool(ds.get("require_success", True)),
        "filter_idle": bool(ds.get("filter_idle", True)),
        "layout": str(ds.get("camera_layout", "t_shape")),
        "video_size": (int(common["video_height"]), int(common["video_width"])),
    }
    if params["layout"] == "v_stack":
        # Inference always feeds the first exterior; keep the replay in step.
        params["random_exterior"] = False
        if ds.get("exterior_camera_keys"):
            params["exterior_camera_keys"] = list(ds["exterior_camera_keys"])
        if ds.get("wrist_camera_key"):
            params["wrist_camera_key"] = str(ds["wrist_camera_key"])
    return params


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--num-samples", type=int, default=8)
    ap.add_argument("--num-meta-files", type=int, default=2)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--checkpoint", default=CKPT)
    ap.add_argument("--config", default=CFG)
    ap.add_argument("--out", default="/tmp/diag_droid_replay.json")
    args = ap.parse_args()

    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)

    print(f"=== loading policy ===\n  checkpoint: {args.checkpoint}\n  config:     {args.config}", flush=True)
    from robolab_motusv2.adapter import MotusV2DroidJointposPolicy

    policy = MotusV2DroidJointposPolicy(
        checkpoint_path=args.checkpoint, config_path=args.config, wan_path=WAN, vlm_path=VLM,
        device="cuda:0", t5_device="cuda:1",
    )
    print("model.training =", policy.model.training, flush=True)

    print("=== indexing dataset ===", flush=True)
    ds_params = dataset_params_from_config(args.config)
    print(f"  dataset contract: {ds_params}", flush=True)
    ds = build_dataset(args.num_meta_files, **ds_params)
    print(f"episodes indexed: {len(ds.episodes)}", flush=True)

    stats = json.load(open(f"{DATA}/meta/stats.json"))
    ds_mean = np.asarray(stats["action"]["mean"], dtype=np.float32)

    records = []
    for n in range(args.num_samples):
        sample = ds[n]
        if sample is None:
            print(f"[{n}] sample is None, skip", flush=True)
            continue
        first_frame = sample["first_frame"]          # [3,288,320] float32 [0,1]
        state = sample["initial_state"].numpy()      # [8] raw radians
        gt = sample["action_sequence"].numpy()       # [16,8] raw absolute radians
        instr = sample["task_name"]

        # Exactly the adapter's serving path: normalize in, denormalize out.
        model_state = policy.normalizer.normalize_state(state) if policy.normalizer else state
        ff = first_frame.unsqueeze(0).to(policy.device, dtype=policy.dtype)
        st = torch.from_numpy(model_state).unsqueeze(0).to(policy.device, dtype=policy.dtype)
        lang = policy._encode_t5(instr)
        vlm_inputs = policy._build_vlm_inputs(instr, ff[0])
        with torch.no_grad():
            _, pred = policy.model.inference_step(
                first_frame=ff, state=st,
                num_inference_steps=policy.contract.num_inference_timesteps,
                language_embeddings=lang, vlm_inputs=vlm_inputs,
            )
        pred = pred.squeeze(0).float().cpu().numpy()  # [16,8]
        if policy.normalizer is not None:
            pred = policy.normalizer.from_model_actions(pred, state)

        hold = np.tile(state[None, :], (gt.shape[0], 1))     # baseline: hold current state
        meanb = np.tile(ds_mean[None, :], (gt.shape[0], 1))  # baseline: dataset mean

        rec = {
            "instruction": instr,
            "state": state.tolist(),
            "gt_first": gt[0].tolist(),
            "pred_first": pred[0].tolist(),
            "gt_last": gt[-1].tolist(),
            "pred_last": pred[-1].tolist(),
            "mae_pred_vs_gt": np.abs(pred - gt).mean(0).tolist(),
            "mae_hold_vs_gt": np.abs(hold - gt).mean(0).tolist(),
            "mae_mean_vs_gt": np.abs(meanb - gt).mean(0).tolist(),
            "mae_pred_vs_hold": np.abs(pred - hold).mean(0).tolist(),
            "mae_pred_vs_mean": np.abs(pred - meanb).mean(0).tolist(),
            "gt_motion_range": (gt[:, :7].max(0) - gt[:, :7].min(0)).tolist(),
            "pred_motion_range": (pred[:, :7].max(0) - pred[:, :7].min(0)).tolist(),
        }
        records.append(rec)

        print(f"\n--- sample {n}: {instr!r}", flush=True)
        print("  state     ", np.round(state, 3).tolist())
        print("  gt[0]     ", np.round(gt[0], 3).tolist())
        print("  pred[0]   ", np.round(pred[0], 3).tolist())
        print("  gt[15]    ", np.round(gt[-1], 3).tolist())
        print("  pred[15]  ", np.round(pred[-1], 3).tolist())
        print("  MAE pred-gt   ", np.round(rec["mae_pred_vs_gt"], 4).tolist())
        print("  MAE hold-gt   ", np.round(rec["mae_hold_vs_gt"], 4).tolist())
        print("  MAE mean-gt   ", np.round(rec["mae_mean_vs_gt"], 4).tolist())

    if not records:
        print("no samples")
        return 1

    arr = lambda k: np.asarray([r[k] for r in records], dtype=np.float64).mean(0)
    print("\n================ AGGREGATE over", len(records), "samples ================")
    hdr = "            " + "".join(f"{n:>9s}" for n in JOINT_NAMES) + f"{'ARM_AVG':>10s}"
    print(hdr)
    for key, label in [
        ("mae_pred_vs_gt", "pred vs GT"),
        ("mae_hold_vs_gt", "hold vs GT"),
        ("mae_mean_vs_gt", "mean vs GT"),
        ("mae_pred_vs_hold", "pred vs hold"),
        ("mae_pred_vs_mean", "pred vs mean"),
        ("gt_motion_range", "GT range"),
        ("pred_motion_range", "PRED range"),
    ]:
        v = arr(key)
        armavg = v[:7].mean()
        print(f"{label:<12s}" + "".join(f"{x:9.4f}" for x in v) + f"{armavg:10.4f}")

    json.dump(records, open(args.out, "w"), indent=2)
    print("\nwrote", args.out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

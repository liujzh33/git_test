"""Unit tests for 32D abs-qpos + unified-EEF combined packing."""

import numpy as np

from data.human.unified_eef_action import (
    COMBINED_QPOS_EEF_ACTION_DIM,
    COMBINED_QPOS_EEF_EFFECTIVE_INDICES,
    COMBINED_QPOS_EEF_RESERVED_INDICES,
    UNIFIED_EEF_ROBOT_EFFECTIVE_INDICES,
    UNIFIED_EEF_ROBOT_RESERVED_INDICES,
    build_combined_qpos_eef_valid_mask,
    pack_combined_qpos_eef_32,
    pad_qpos_14_to_16,
)


def test_pad_qpos_14_to_16_layout():
    qpos = np.arange(14, dtype=np.float32)
    padded = pad_qpos_14_to_16(qpos)
    assert padded.shape == (16,)
    np.testing.assert_array_equal(padded[:7], qpos[:7])
    assert padded[7] == 0.0
    np.testing.assert_array_equal(padded[8:15], qpos[7:14])
    assert padded[15] == 0.0


def test_pack_combined_qpos_eef_32_layout():
    qpos = np.arange(14, dtype=np.float32) + 1.0
    eef = np.arange(16, dtype=np.float32) + 100.0
    eef[[7, 15]] = 0.0

    combined = pack_combined_qpos_eef_32(qpos, eef)
    assert combined.shape == (COMBINED_QPOS_EEF_ACTION_DIM,)
    np.testing.assert_array_equal(combined[:7], qpos[:7])
    assert combined[7] == 0.0
    np.testing.assert_array_equal(combined[8:15], qpos[7:14])
    assert combined[15] == 0.0
    np.testing.assert_array_equal(combined[16:32], eef)
    np.testing.assert_array_equal(combined[COMBINED_QPOS_EEF_RESERVED_INDICES], 0.0)


def test_pack_combined_sequence_batch():
    qpos = np.random.randn(5, 14).astype(np.float32)
    eef = np.random.randn(5, 16).astype(np.float32)
    eef[:, [7, 15]] = 0.0
    combined = pack_combined_qpos_eef_32(qpos, eef)
    assert combined.shape == (5, 32)
    np.testing.assert_allclose(combined[:, :7], qpos[:, :7])
    np.testing.assert_allclose(combined[:, 8:15], qpos[:, 7:14])
    np.testing.assert_allclose(combined[:, 16:32], eef)


def test_combined_mask_reserved_and_effective():
    eef_mask = np.zeros((4, 16), dtype=np.float32)
    eef_mask[:, UNIFIED_EEF_ROBOT_EFFECTIVE_INDICES] = 1.0

    mask = build_combined_qpos_eef_valid_mask(eef_mask)
    assert mask.shape == (4, 32)
    assert set(COMBINED_QPOS_EEF_RESERVED_INDICES) == {7, 15, 23, 31}
    np.testing.assert_array_equal(mask[:, COMBINED_QPOS_EEF_RESERVED_INDICES], 0.0)
    np.testing.assert_array_equal(mask[:, COMBINED_QPOS_EEF_EFFECTIVE_INDICES], 1.0)

    # EEF reserved offset by 16 must match robot unified reserved.
    for idx in UNIFIED_EEF_ROBOT_RESERVED_INDICES:
        assert mask[0, idx + 16] == 0.0
    for idx in UNIFIED_EEF_ROBOT_EFFECTIVE_INDICES:
        assert mask[0, idx + 16] == 1.0


def test_effective_count_is_28():
    # 14 qpos + 14 eef effective dims (grippers included, 4 pads excluded)
    assert len(COMBINED_QPOS_EEF_EFFECTIVE_INDICES) == 28
    assert len(COMBINED_QPOS_EEF_RESERVED_INDICES) == 4

#!/usr/bin/env python3
"""Is batched / dynamic-length T5 encoding equivalent to the current one-at-a-time path?

The speed benchmark showed max|Δ| up to 0.7 between batch=1 and batch=8, which
would be alarming if the embeddings were O(1).  This separates the two possible
causes -- bf16 kernel nondeterminism vs. an actual semantic change from padding
-- by reporting magnitudes, relative error and cosine similarity, and by
checking whether the reference path is even deterministic against itself.

Run:
  CUDA_VISIBLE_DEVICES=0 PYTHONPATH=/tmp/diag_pkgs python tests/diag_t5_equivalence.py
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

import torch

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO))
sys.path.insert(0, str(REPO / "bak"))
for _p in os.environ.get("MOTUS_EXTRA_SITE_PACKAGES", "").split(os.pathsep):
    if _p and _p not in sys.path:
        sys.path.append(_p)

from diag_t5_encode_bench import SAMPLES, WAN, encode_batched  # noqa: E402


def compare(label, got, ref):
    mags, abs_err, rel_err, cos = [], [], [], []
    for g, r in zip(got, ref):
        g = g.float().cpu()
        assert g.shape == r.shape, f"{label}: shape {g.shape} != {r.shape}"
        mags.append(float(r.abs().max()))
        abs_err.append(float((g - r).abs().max()))
        denom = r.norm()
        rel_err.append(float((g - r).norm() / denom) if denom > 0 else 0.0)
        cos.append(float(torch.nn.functional.cosine_similarity(
            g.flatten(), r.flatten(), dim=0)))
    print(f"  {label:28s} |ref|max={max(mags):8.2f}  max|Δ|={max(abs_err):7.4f}  "
          f"relL2={max(rel_err):.2e}  min cos={min(cos):.8f}")
    return max(rel_err), min(cos)


def main() -> int:
    from wan.modules.t5 import T5EncoderModel

    device = "cuda"
    print("loading UMT5-XXL ...", flush=True)
    enc = T5EncoderModel(
        text_len=512, dtype=torch.bfloat16, device=device,
        checkpoint_path=str(Path(WAN) / "models_t5_umt5-xxl-enc-bf16.pth"),
        tokenizer_path=str(Path(WAN) / "google" / "umt5-xxl"),
    )

    with torch.no_grad():
        ref = [enc([t], device)[0].float().cpu() for t in SAMPLES]

    print("\nEach row compares against the current path (batch=1, pad=512).")
    print("relL2 = ||Δ|| / ||ref||;  cos = cosine similarity of the flattened embedding\n")

    with torch.no_grad():
        # (a) Is the reference even reproducible against itself?
        again = [enc([t], device)[0] for t in SAMPLES]
        compare("batch=1 pad=512 (rerun)", again, ref)

        # (b) Padding effect alone, batch size held at 1.
        one_dyn = []
        for t in SAMPLES:
            one_dyn.append(encode_batched(enc, [t], device, dynamic=True)[0])
        compare("batch=1 dynamic", one_dyn, ref)

        # (c) Batching effect alone, padding held at 512.
        compare("batch=8 pad=512", encode_batched(enc, SAMPLES, device, dynamic=False), ref)

        # (d) Both, i.e. the proposed fast path.
        rel, cos = compare("batch=8 dynamic  (proposed)",
                           encode_batched(enc, SAMPLES, device, dynamic=True), ref)

    print("\nbf16 has an 8-bit mantissa, so ~4e-3 relative error per op is expected.")
    verdict = rel < 5e-2 and cos > 0.999
    print("VERDICT:", "differences are numerical, not semantic" if verdict
          else "NOT equivalent -- do not adopt")
    return 0 if verdict else 1


if __name__ == "__main__":
    raise SystemExit(main())

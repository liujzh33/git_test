import unittest

from data.task_sampling import resolve_task_sampling_weights


class TaskSamplingTest(unittest.TestCase):
    def setUp(self):
        self.tasks = [f"task_{index:02d}" for index in range(50)]
        self.config = {
            "enabled": True,
            "validation_mode": "uniform",
            "strict": True,
            "uniform_mass": 0.60,
            "groups": [
                {
                    "name": "regression",
                    "mass": 0.25,
                    "tasks": self.tasks[:10],
                },
                {
                    "name": "late",
                    "mass": 0.10,
                    "tasks": self.tasks[10:15],
                },
                {
                    "name": "anchor",
                    "mass": 0.05,
                    "tasks": self.tasks[15:20],
                },
            ],
        }

    def test_additive_mixture_is_normalized(self):
        weights = resolve_task_sampling_weights(self.tasks, self.config)

        self.assertAlmostEqual(sum(weights.values()), 1.0)
        self.assertAlmostEqual(weights["task_00"], 0.60 / 50 + 0.25 / 10)
        self.assertAlmostEqual(weights["task_10"], 0.60 / 50 + 0.10 / 5)
        self.assertAlmostEqual(weights["task_15"], 0.60 / 50 + 0.05 / 5)
        self.assertAlmostEqual(weights["task_30"], 0.60 / 50)

    def test_validation_defaults_to_uniform(self):
        weights = resolve_task_sampling_weights(
            self.tasks,
            self.config,
            is_validation=True,
        )

        for probability in weights.values():
            self.assertAlmostEqual(probability, 1.0 / 50)

    def test_unknown_task_fails_in_strict_mode(self):
        config = dict(self.config)
        config["groups"] = [
            {"name": "bad", "mass": 0.1, "tasks": ["missing_task"]}
        ]

        with self.assertRaisesRegex(ValueError, "unknown tasks"):
            resolve_task_sampling_weights(self.tasks, config)

    def test_disabled_config_preserves_uniform_sampling(self):
        weights = resolve_task_sampling_weights(
            self.tasks,
            {"enabled": False},
        )

        for probability in weights.values():
            self.assertAlmostEqual(probability, 1.0 / 50)


if __name__ == "__main__":
    unittest.main()


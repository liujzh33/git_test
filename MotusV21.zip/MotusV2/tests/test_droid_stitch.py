#!/usr/bin/env python3
"""Contract tests for the shared DROID camera stitching.

Two things are pinned here:

  1. The refactored t_shape geometry reproduces the previous dataset and adapter
     implementations *exactly*. The v3 checkpoint was trained on t_shape frames,
     so any pixel-level drift would silently invalidate it.
  2. Training and inference produce identical frames for every layout -- the WAN
     VAE has no layout prior, so a mismatch is unrecoverable and invisible.

Run:
  python -m pytest tests/test_droid_stitch.py -q
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pytest

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO))

from data.droid.droid_stitch import (  # noqa: E402
    LAYOUTS,
    plan_layout,
    stitch_frame,
)

DROID_CAM = (180, 320)  # native DROID camera resolution


def _img(seed, shape=DROID_CAM):
    rng = np.random.default_rng(seed)
    return rng.integers(0, 256, (*shape, 3), dtype=np.uint8)


def _legacy_t_shape(top, bl, br, th, tw):
    """The implementation that produced the v3 training frames, inlined."""
    import cv2

    split_w = tw // 2
    right_w = tw - split_w

    def nat(h, w, target_w):
        return int(round(h * target_w / w))

    top_h = nat(top.shape[0], top.shape[1], tw)
    bot_h = max(nat(bl.shape[0], bl.shape[1], split_w),
                nat(br.shape[0], br.shape[1], right_w))
    natural_h = top_h + bot_h
    if natural_h > th:
        natural_h = th
        top_h = natural_h // 2
        bot_h = natural_h - top_h
    pad_top = (th - natural_h) // 2

    canvas = np.zeros((natural_h, tw, 3), dtype=np.uint8)
    canvas[:top_h, :, :] = cv2.resize(top, (tw, top_h), interpolation=cv2.INTER_LINEAR)
    canvas[top_h:top_h + bot_h, :split_w, :] = cv2.resize(bl, (split_w, bot_h), interpolation=cv2.INTER_LINEAR)
    canvas[top_h:top_h + bot_h, split_w:split_w + right_w, :] = cv2.resize(br, (right_w, bot_h), interpolation=cv2.INTER_LINEAR)
    if pad_top > 0 or natural_h < th:
        padded = np.zeros((th, tw, 3), dtype=np.uint8)
        padded[pad_top:pad_top + natural_h, :, :] = canvas
        canvas = padded
    return canvas


@pytest.mark.parametrize("size", [(288, 320), (384, 320), (256, 256)])
def test_t_shape_matches_legacy_exactly(size):
    """No pixel may move: v3 was trained on the legacy output."""
    th, tw = size
    imgs = [_img(0), _img(1), _img(2)]
    got = stitch_frame("t_shape", imgs, th, tw)
    want = _legacy_t_shape(*imgs, th, tw)
    assert got.shape == want.shape
    assert np.array_equal(got, want), f"t_shape drifted at {size}"


def test_t_shape_matches_legacy_on_odd_camera_shapes():
    for shape in [(720, 1280), (180, 320), (240, 320), (100, 300)]:
        imgs = [_img(3, shape), _img(4, shape), _img(5, shape)]
        assert np.array_equal(
            stitch_frame("t_shape", imgs, 288, 320),
            _legacy_t_shape(*imgs, 288, 320),
        ), f"drift at camera shape {shape}"


def test_v_stack_splits_the_frame_evenly():
    """Both cameras must get the same number of rows, unlike t_shape."""
    plan = plan_layout("v_stack", [DROID_CAM, DROID_CAM], 384, 320)
    (y0, x0, h0, w0), (y1, x1, h1, w1) = plan["rects"]
    assert (h0, w0) == (h1, w1) == (180, 320), "each camera should keep 180x320"
    assert y0 == 0 and y1 == 180 and x0 == x1 == 0
    assert plan["natural_h"] == 360
    assert plan["pad_top"] == 12  # (384-360)//2


def test_v_stack_gives_the_wrist_far_more_area_than_t_shape():
    """The whole point of the layout change."""
    t = plan_layout("t_shape", [DROID_CAM] * 3, 288, 320)
    v = plan_layout("v_stack", [DROID_CAM] * 2, 384, 320)
    wrist_t = t["rects"][2][2] * t["rects"][2][3]
    wrist_v = v["rects"][1][2] * v["rects"][1][3]
    assert wrist_v > 3 * wrist_t, f"wrist area only grew {wrist_v/wrist_t:.1f}x"


def test_black_border_stays_small():
    """384x320 v_stack must not be worse than 288x320 t_shape on wasted pixels."""
    for layout, shapes, th in [("t_shape", [DROID_CAM] * 3, 288),
                               ("v_stack", [DROID_CAM] * 2, 384)]:
        plan = plan_layout(layout, shapes, th, 320)
        black = 1 - plan["natural_h"] / th
        assert black < 0.07, f"{layout} wastes {black:.1%} on padding"


@pytest.mark.parametrize("layout", LAYOUTS)
def test_output_is_exact_size_and_padding_is_black(layout):
    n = 3 if layout == "t_shape" else 2
    out = stitch_frame(layout, [_img(i) for i in range(n)], 384, 320)
    assert out.shape == (384, 320, 3) and out.dtype == np.uint8
    plan = plan_layout(layout, [DROID_CAM] * n, 384, 320)
    top_pad = plan["pad_top"]
    if top_pad:
        assert out[:top_pad].max() == 0, "top padding must be black"
        assert out[top_pad + plan["natural_h"]:].max() == 0, "bottom padding must be black"


@pytest.mark.parametrize("layout", LAYOUTS)
def test_oversized_frame_is_clamped_not_crashed(layout):
    n = 3 if layout == "t_shape" else 2
    out = stitch_frame(layout, [_img(i, (1000, 320)) for i in range(n)], 288, 320)
    assert out.shape == (288, 320, 3)


def test_rejects_unknown_layout_and_wrong_camera_count():
    with pytest.raises(ValueError, match="camera_layout"):
        plan_layout("diagonal", [DROID_CAM] * 2, 384, 320)
    with pytest.raises(ValueError, match="needs 2 cameras"):
        plan_layout("v_stack", [DROID_CAM] * 3, 384, 320)


def test_dataset_and_adapter_share_one_implementation():
    ds = (REPO / "data/droid/droid_lerobot_dataset.py").read_text()
    ad = (REPO / "robolab_motusv2/adapter.py").read_text()
    assert "droid_stitch import" in ds
    assert "droid_stitch import" in ad


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-q"]))

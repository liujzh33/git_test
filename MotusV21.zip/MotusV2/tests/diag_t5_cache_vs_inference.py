#!/usr/bin/env python3
"""The whole point of fp32: a batched cache must equal what inference computes.

Builds cache entries the way scripts/prepopulate_droid_t5_cache.py does (large
batches) and compares against the way robolab_motusv2/adapter.py encodes at
serving time (one instruction, on its own).  If these disagree, training and
evaluation are conditioned on different language embeddings.

Also re-checks that bfloat16 still fails this test, so the config comment does
not become folklore.

Run:
  CUDA_VISIBLE_DEVICES=0 PYTHONPATH=/tmp/diag_pkgs python tests/diag_t5_cache_vs_inference.py
"""
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

import torch

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO))
sys.path.insert(0, str(REPO / "bak"))
sys.path.insert(0, str(REPO / "tests"))
for _p in os.environ.get("MOTUS_EXTRA_SITE_PACKAGES", "").split(os.pathsep):
    if _p and _p not in sys.path:
        sys.path.append(_p)

from diag_t5_encode_bench import SAMPLES, WAN  # noqa: E402

TEXTS = (SAMPLES * 16)[:128]


def run(precision: str) -> tuple[float, float]:
    from data import release_global_t5_encoder
    from data.droid.droid_lerobot_dataset import DroidLeRobotDataset
    from wan.modules.t5 import T5EncoderModel

    tmp = Path(tempfile.mkdtemp())

    class _Cache:
        t5_cache_dir = tmp
        t5_text_len = 512
        # staticmethod, so it must not be re-bound as an instance method here
        _hash_text = staticmethod(DroidLeRobotDataset._hash_text)

    cache = _Cache()
    for name in ("_validate_t5_embedding", "write_t5_cache_entry"):
        setattr(cache, name, getattr(DroidLeRobotDataset, name).__get__(cache))

    enc = T5EncoderModel(
        text_len=512, dtype=getattr(torch, precision), device="cuda",
        checkpoint_path=str(Path(WAN) / "models_t5_umt5-xxl-enc-bf16.pth"),
        tokenizer_path=str(Path(WAN) / "google" / "umt5-xxl"),
    )

    # (a) cache generation: big batches + dynamic padding, as the script does
    from data import encode_texts

    cached = {}
    with torch.no_grad():
        for i in range(0, len(TEXTS), 64):
            chunk = TEXTS[i:i + 64]
            for text, emb in zip(chunk, encode_texts(enc, chunk, "cuda", dynamic=True)):
                cached[text] = cache.write_t5_cache_entry(text, emb)

    # (b) serving: MotusV2DroidJointposPolicy._encode_t5 -> encoder([one], device)
    worst_rel, worst_cos = 0.0, 1.0
    with torch.no_grad():
        for text in dict.fromkeys(TEXTS):
            live = enc([text], "cuda")[0]
            # the model receives bf16 either way, so compare at that precision
            live = live.to(torch.bfloat16).float().cpu()
            cached_vec = cached[text][: live.shape[0]]
            denom = cached_vec.norm()
            worst_rel = max(worst_rel, float((live - cached_vec).norm() / denom))
            worst_cos = min(worst_cos, float(torch.nn.functional.cosine_similarity(
                live.flatten(), cached_vec.flatten(), dim=0)))

    del enc
    release_global_t5_encoder()
    torch.cuda.empty_cache()
    for f in tmp.glob("*.pt"):
        f.unlink()
    tmp.rmdir()
    return worst_rel, worst_cos


def main() -> int:
    # The cache stores bfloat16 (the model consumes bfloat16 anyway), so ~2e-3
    # relative is the storage floor -- two fp32 values that agree to 1e-6 can
    # still land on different sides of a bfloat16 rounding boundary.  Anything
    # at that floor means the encoders agree; bfloat16 encoding sits ~100x above.
    BF16_FLOOR = 4e-3

    print("comparing: cache built at batch=64 + dynamic padding")
    print("     vs.:  inference encoding one instruction at a time, padded to 512\n")
    results = {}
    for precision in ("bfloat16", "float32"):
        rel, cos = run(precision)
        results[precision] = rel
        verdict = "at bfloat16 storage floor" if rel < BF16_FLOOR else "MISMATCH"
        print(f"  t5_precision={precision:9s}  max relL2={rel:.3e}   "
              f"min cos={cos:.8f}   -> {verdict}")

    ok = results["float32"] < BF16_FLOOR < results["bfloat16"]
    print("\nRESULT:", "PASS - fp32 makes the batched cache match inference"
          if ok else "FAIL - unexpected; do not batch the cache")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())

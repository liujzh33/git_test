#!/usr/bin/env python3
"""Can we afford fp32 T5, and is there a cheaper way to get batch invariance?

Switching UMT5 to fp32 makes encoding batch-invariant (relL2 ~1e-6 vs ~0.2 in
bf16), which is what lets the cache be built in large batches while inference
still encodes one instruction at a time.  Two things need checking first:

  1. Memory. The RoboLab server puts T5 on its own 32 GB card. fp32 doubles the
     weights to ~19 GB, so the headroom has to be verified, not assumed.
  2. Whether full fp32 is even necessary. The instability comes from UMT5
     omitting the 1/sqrt(d) attention scaling, so the q@k logits are huge and
     bf16 resolves them poorly. Computing just that einsum in fp32 -- the
     softmax already runs in fp32 -- might buy the same invariance at bf16 cost.

Run:
  CUDA_VISIBLE_DEVICES=0 PYTHONPATH=/tmp/diag_pkgs python tests/diag_t5_fp32_feasibility.py
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

import torch

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO))
sys.path.insert(0, str(REPO / "bak"))
sys.path.insert(0, str(REPO / "tests"))
for _p in os.environ.get("MOTUS_EXTRA_SITE_PACKAGES", "").split(os.pathsep):
    if _p and _p not in sys.path:
        sys.path.append(_p)

from diag_t5_encode_bench import SAMPLES, WAN, encode_batched  # noqa: E402

GB = 1024 ** 3


def rel(a, b):
    a, b = a.float().cpu(), b.float().cpu()
    return float((a - b).norm() / b.norm())


def load(dtype):
    from wan.modules.t5 import T5EncoderModel

    return T5EncoderModel(
        text_len=512, dtype=dtype, device="cuda",
        checkpoint_path=str(Path(WAN) / "models_t5_umt5-xxl-enc-bf16.pth"),
        tokenizer_path=str(Path(WAN) / "google" / "umt5-xxl"),
    )


def report(tag, enc, batches):
    print(f"\n=== {tag} ===")
    print(f"  weights on GPU              : {torch.cuda.memory_allocated()/GB:5.2f} GB")
    with torch.no_grad():
        for bs in batches:
            torch.cuda.reset_peak_memory_stats()
            encode_batched(enc, (SAMPLES * 64)[:bs], "cuda", dynamic=True)
            torch.cuda.synchronize()
            print(f"  peak during batch={bs:<4d}      : {torch.cuda.max_memory_allocated()/GB:5.2f} GB")


def main() -> int:
    total = torch.cuda.get_device_properties(0).total_memory / GB
    print(f"GPU: {torch.cuda.get_device_name(0)}  {total:.1f} GB total")

    enc = load(torch.bfloat16)
    report("bf16 (current)", enc, [1, 64, 256])
    with torch.no_grad():
        ref_bf16 = encode_batched(enc, [SAMPLES[2]], "cuda", dynamic=True)[0].clone()

    # Patch only the attention logits to fp32 and re-check batch invariance.
    import wan.modules.t5 as t5mod

    orig_forward = t5mod.T5Attention.forward

    def fp32_logits_forward(self, x, context=None, mask=None, pos_bias=None):
        import torch.nn.functional as F

        context = x if context is None else context
        b, n, c = x.size(0), self.num_heads, self.head_dim
        q = self.q(x).view(b, -1, n, c)
        k = self.k(context).view(b, -1, n, c)
        v = self.v(context).view(b, -1, n, c)
        attn_bias = x.new_zeros(b, n, q.size(1), k.size(1)).float()
        if pos_bias is not None:
            attn_bias += pos_bias.float()
        if mask is not None:
            m = mask.view(b, 1, 1, -1) if mask.ndim == 2 else mask.unsqueeze(1)
            attn_bias.masked_fill_(m == 0, torch.finfo(torch.float32).min)
        attn = torch.einsum("binc,bjnc->bnij", q.float(), k.float()) + attn_bias
        attn = F.softmax(attn, dim=-1).type_as(v)
        x = torch.einsum("bnij,bjnc->binc", attn, v)
        return self.dropout(self.o(x.reshape(b, -1, n * c)))

    t5mod.T5Attention.forward = fp32_logits_forward
    print("\n=== bf16 weights + fp32 attention logits ===")
    with torch.no_grad():
        alone = encode_batched(enc, [SAMPLES[2]], "cuda", dynamic=True)[0]
        for bs in (4, 8, 64):
            got = encode_batched(enc, [SAMPLES[2]] * bs, "cuda", dynamic=True)[0]
            print(f"  batch={bs:<3d} vs batch=1: relL2={rel(got, alone):.2e}")
        print(f"  vs unpatched bf16 batch=1 : relL2={rel(alone, ref_bf16):.2e}")
    t5mod.T5Attention.forward = orig_forward

    del enc
    torch.cuda.empty_cache()

    enc32 = load(torch.float32)
    report("fp32", enc32, [1, 64, 256])
    print(f"\n  headroom on a 32 GB card at batch=1 (inference): "
          f"{total - torch.cuda.max_memory_allocated()/GB:.2f} GB")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

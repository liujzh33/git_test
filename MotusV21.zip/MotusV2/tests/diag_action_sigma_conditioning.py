#!/usr/bin/env python3
"""Split the action loss by noise level to find where its training signal comes from.

Training averages the action loss over uniformly sampled sigma and hides *where*
the loss comes from. Two things are measured here.

Experiment A -- what the action expert conditions on. At each action sigma, the
same batch is re-run with one conditioning stream rolled across the batch so it
no longer matches the target. The rise in loss is that stream's contribution.
``future`` is separated from ``first``: the first frame is a legitimate
observation available at inference, whereas ``video_frames`` are the *future*
frames, which at inference do not exist yet and must be generated.

Experiment B -- the train/inference gap. ``training_step`` draws the video and
action timesteps from two independent ``randint`` calls, so training covers
combinations like "video almost clean, action pure noise" where the future is
sitting in plain sight. ``inference_step`` instead ties them together
(``video_t_scaled = action_t_scaled = t``) and walks both down from pure noise,
so that combination never occurs when serving. This sweeps the action sigma
under three video regimes:

  matched   video sigma = action sigma      what inference actually does
  random    video sigma ~ U                 what training actually does
  clean     video sigma = min               upper bound on future-frame leakage

If ``random`` and ``clean`` sit far below ``matched``, the low training loss is
being earned in a regime that inference can never reach, and the sampler is left
with nothing but the marginal mean -- whose MSE is printed for comparison.

Run (the RoboLab venv owns the working torch build; bak/wan needs diffusers,
which only the openpi venv carries, hence the extra site-packages):

  CUDA_VISIBLE_DEVICES=0,1 \
  MOTUS_EXTRA_SITE_PACKAGES=/home/work/mnt_data/wenjj_migrated/openpi/.venv/lib/python3.11/site-packages \
  /home/work/wenjj/RoboLab/.venv/bin/python tests/diag_action_sigma_conditioning.py
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO))
sys.path.insert(0, str(REPO / "tests"))

from diag_droid_replay import VLM, WAN, build_dataset  # noqa: E402

CKPT_V4 = "/home/work/wenjj/ckpt/CKPT_WamVlmMask_droid_v4_2cams_9w_steps"
CFG_V4 = str(REPO / "configs/droid_wan_vlm_mask_2cam.yaml")
NORM_STATS = REPO / "data/droid/droid_norm_stats.json"

# Conditioning streams each ablation takes from the neighbouring sample. The
# target actions always stay with their own slot, so a rolled stream no longer
# corresponds to what the model has to predict.
CONDITIONS = {
    "full": (),
    "first": ("first",),      # condition frame (available at inference)
    "future": ("future",),    # target frames  (NOT available at inference)
    "text": ("text",),
    "state": ("state",),
    "all": ("first", "future", "text", "state"),
}

VIDEO_REGIMES = ("matched", "random", "clean")


def marginal_variance() -> float:
    """MSE of always predicting the dataset mean, in the normalized action space
    the model is trained in. Derived from the quantiles the dataset normalizes
    with, so it is directly comparable to the measured loss."""
    stats = json.loads(NORM_STATS.read_text())
    q01 = np.asarray(stats["action"]["q01"], dtype=np.float64)
    q99 = np.asarray(stats["action"]["q99"], dtype=np.float64)
    std = np.asarray(stats["action"]["std"], dtype=np.float64)
    return float(((std * (2.0 / (q99 - q01))) ** 2).mean())


def unconditional_loss(sigma: float, var: float) -> float:
    """Best loss achievable at this sigma from the marginal distribution alone.

    Closed form for Gaussian data: the target ``eps - x1`` regressed on the
    observation ``x_s``. Real actions are heavier tailed, so this is a reference
    line rather than a strict bound.
    """
    cov = sigma - (1.0 - sigma) * var
    var_x = (1.0 - sigma) ** 2 * var + sigma**2
    return (1.0 + var) - cov**2 / max(var_x, 1e-12)


def source_indices(i: int, n: int, rolled: tuple[str, ...]) -> dict[str, int]:
    """Sample index feeding each conditioning stream for one slot of the batch."""
    donor = (i + 1) % n
    return {s: (donor if s in rolled else i)
            for s in ("first", "future", "text", "state")}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--checkpoint", default=CKPT_V4)
    ap.add_argument("--config", default=CFG_V4)
    ap.add_argument("--batch-size", type=int, default=8)
    ap.add_argument("--num-batches", type=int, default=4)
    ap.add_argument("--num-meta-files", type=int, default=2)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--out", default="/tmp/diag_action_sigma_conditioning.json")
    args = ap.parse_args()

    torch.manual_seed(args.seed)
    np.random.seed(args.seed)

    from data.dataset import _process_language_embeddings_batch
    from robolab_motusv2.adapter import MotusV2DroidJointposPolicy

    policy = MotusV2DroidJointposPolicy(
        checkpoint_path=args.checkpoint, config_path=args.config,
        wan_path=WAN, vlm_path=VLM, device="cuda:0", t5_device="cuda:1",
    )
    model = policy.model
    model.eval()

    var = marginal_variance()
    a_sigmas = model.fm_train_scheduler_action.sigmas.detach().float().cpu().numpy()
    v_sigmas = model.fm_train_scheduler.sigmas.detach().float().cpu().numpy()
    n_v = model.fm_train_scheduler.num_train_timesteps
    print(f"mean-predictor MSE (normalized action variance) = {var:.4f}")
    print(f"action sigmas in [{a_sigmas.min():.4f}, {a_sigmas.max():.4f}], "
          f"video sigmas in [{v_sigmas.min():.4f}, {v_sigmas.max():.4f}]")

    ds = build_dataset(
        args.num_meta_files, layout="v_stack", video_size=(384, 320),
        action_normalization=True, require_success=True, filter_idle=True,
        random_exterior=False,
    )
    print(f"episodes indexed: {len(ds.episodes)}", flush=True)

    need = args.batch_size * args.num_batches
    samples: list[dict] = []
    idx = 0
    while len(samples) < need and idx < need * 20:
        s = ds[idx]
        idx += 1
        if s is None:
            continue
        s = dict(s)
        # The dataset is built with t5_mode="none"; the policy owns the encoder.
        s["language_embedding"] = policy._encode_t5(s["task_name"])[0].cpu()
        samples.append(s)
    if len(samples) < need:
        raise SystemExit(f"only collected {len(samples)}/{need} samples")
    print(f"collected {len(samples)} samples", flush=True)

    # The processor is not cheap and each (text, image) pair recurs at every
    # sigma, so build each pair once. Only four pairings per slot are needed.
    vlm_cache: dict[tuple[int, int], dict] = {}

    def vlm_for(text_idx: int, img_idx: int) -> dict:
        key = (text_idx, img_idx)
        if key not in vlm_cache:
            vlm_cache[key] = policy._build_vlm_inputs(
                samples[text_idx]["task_name"], samples[img_idx]["first_frame"]
            )
        return vlm_cache[key]

    targets = [0.2, 0.4, 0.6, 0.8, 0.9, 0.95, 0.99]
    tids = [int(np.argmin(np.abs(a_sigmas - t))) for t in targets]

    def run_batch(chunk, lo, rolled, a_tid, v_tid, seed) -> float:
        n = len(chunk)
        src = [source_indices(i, n, rolled) for i in range(n)]
        inputs = {
            "first_frame": torch.stack([chunk[s["first"]]["first_frame"] for s in src]),
            "video_frames": torch.stack([chunk[s["future"]]["video_frames"] for s in src]),
            "state": torch.stack([chunk[s["state"]]["initial_state"] for s in src]),
            "actions": torch.stack([s["action_sequence"] for s in chunk]),
        }
        inputs = {k: v.to(model.device, model.dtype) for k, v in inputs.items()}
        inputs["language_embeddings"] = _process_language_embeddings_batch(
            [chunk[s["text"]]["language_embedding"] for s in src]
        ).to(model.device, model.dtype)
        inputs["vlm_inputs"] = [vlm_for(lo + s["text"], lo + s["first"]) for s in src]

        # Reseeding makes every noise draw identical across conditions, so the
        # comparison is paired and the ablation gap is not swamped by variance.
        torch.manual_seed(seed)
        kwargs = {"action_timestep_id": torch.full((n,), a_tid, dtype=torch.long)}
        if v_tid is not None:
            kwargs["video_timestep_id"] = torch.full((n,), v_tid, dtype=torch.long)
        with torch.no_grad():
            out = model.training_step(**inputs, **kwargs)
        return float(out["action_loss"])

    def batches():
        for b in range(args.num_batches):
            lo = b * args.batch_size
            yield b, lo, samples[lo:lo + args.batch_size]

    # ---------------- Experiment A: conditioning attribution ----------------
    # Video noise is tied to the action noise, i.e. the regime inference uses.
    print("\n=========== A. conditioning ablation (video sigma = action sigma) ===========")
    print("sigma  " + "".join(f"{c:>10s}" for c in CONDITIONS) + f"{'marginal':>10s}")
    exp_a: dict[str, dict[str, float]] = {}
    for tid in tids:
        sigma = float(a_sigmas[tid])
        v_tid = int(np.argmin(np.abs(v_sigmas - sigma)))
        row = {}
        for cond, rolled in CONDITIONS.items():
            vals = [run_batch(ch, lo, rolled, tid, v_tid, args.seed * 100003 + tid * 997 + b)
                    for b, lo, ch in batches()]
            row[cond] = float(np.mean(vals))
        exp_a[f"{sigma:.4f}"] = row
        print(f"{sigma:5.3f}  " + "".join(f"{row[c]:10.4f}" for c in CONDITIONS)
              + f"{var:10.4f}", flush=True)

    # ---------------- Experiment B: train vs inference video regime ----------
    print("\n=========== B. action loss vs video noise regime (full conditioning) ===========")
    print(f"{'sigma':>5s}  {'matched':>10s}{'random':>10s}{'clean':>10s}"
          f"{'marginal':>10s}{'uncond_ref':>12s}")
    exp_b: dict[str, dict[str, float]] = {}
    for tid in tids:
        sigma = float(a_sigmas[tid])
        row = {}
        for regime in VIDEO_REGIMES:
            if regime == "matched":
                v_tid = int(np.argmin(np.abs(v_sigmas - sigma)))
            elif regime == "clean":
                v_tid = int(np.argmin(v_sigmas))
            else:
                v_tid = None  # let training_step draw it, as training does
            vals = [run_batch(ch, lo, (), tid, v_tid, args.seed * 100003 + tid * 997 + b)
                    for b, lo, ch in batches()]
            row[regime] = float(np.mean(vals))
        exp_b[f"{sigma:.4f}"] = row
        print(f"{sigma:5.3f}  " + "".join(f"{row[r]:10.4f}" for r in VIDEO_REGIMES)
              + f"{var:10.4f}{unconditional_loss(sigma, var):12.4f}", flush=True)

    # ---------------- Experiment C: does the sampler deliver? ----------------
    # Experiments A and B measure the training objective. What the policy
    # actually emits is the result of the full denoising loop, so run it exactly
    # as the adapter does (one sample at a time, dict-form VLM inputs) and score
    # it against the same marginal baseline.
    print("\n=========== C. sampled actions vs ground truth ===========")
    n_steps = policy.contract.num_inference_timesteps
    sq_err, sq_mean, sq_hold = [], [], []
    for i, s in enumerate(samples):
        ff = s["first_frame"].unsqueeze(0).to(model.device, model.dtype)
        st = s["initial_state"].unsqueeze(0).to(model.device, model.dtype)
        gt = s["action_sequence"].to(model.device, model.dtype)
        with torch.no_grad():
            _, pred = model.inference_step(
                first_frame=ff, state=st, num_inference_steps=n_steps,
                language_embeddings=[s["language_embedding"].to(model.device, model.dtype)],
                vlm_inputs=vlm_for(i, i),
            )
        pred = pred.squeeze(0)[: gt.shape[0]].float()
        gt = gt[: pred.shape[0]].float()
        sq_err.append(float(((pred - gt) ** 2).mean()))
        # Two references in the same space: the dataset mean is 0 after
        # normalization, and "hold the current state" is the trivial policy.
        sq_mean.append(float((gt**2).mean()))
        hold = st.squeeze(0).float().unsqueeze(0).expand_as(gt)
        sq_hold.append(float(((hold - gt) ** 2).mean()))
    sampled_mse = float(np.mean(sq_err))
    print(f"  sampled MSE vs GT      : {sampled_mse:.4f}   ({n_steps} denoising steps)")
    print(f"  predict-the-mean MSE   : {float(np.mean(sq_mean)):.4f}")
    print(f"  hold-current-state MSE : {float(np.mean(sq_hold)):.4f}")
    print(f"  R^2 vs mean-predictor  : {1 - sampled_mse / float(np.mean(sq_mean)):.3f}")

    Path(args.out).write_text(json.dumps({
        "checkpoint": args.checkpoint,
        "config": args.config,
        "marginal_variance": var,
        "conditioning_ablation": exp_a,
        "video_regime": exp_b,
        "sampled": {
            "num_inference_steps": n_steps,
            "mse": sampled_mse,
            "mse_mean_predictor": float(np.mean(sq_mean)),
            "mse_hold_state": float(np.mean(sq_hold)),
            "per_sample_mse": sq_err,
        },
    }, indent=2))

    hi = f"{float(a_sigmas[tids[-1]]):.4f}"
    a_hi, b_hi = exp_a[hi], exp_b[hi]
    print("\n================ READING ================")
    print(f"at action sigma = {hi} (what the sampler starts from):")
    print(f"  A. full={a_hi['full']:.4f}  no-future={a_hi['future']:.4f}  "
          f"no-text={a_hi['text']:.4f}  no-first={a_hi['first']:.4f}")
    print(f"     -> future frames are worth {a_hi['future'] - a_hi['full']:+.4f}, "
          f"language {a_hi['text'] - a_hi['full']:+.4f}")
    print(f"  B. matched={b_hi['matched']:.4f}  random={b_hi['random']:.4f}  "
          f"clean={b_hi['clean']:.4f}   marginal={var:.4f}")
    print(f"     -> training regime is {b_hi['matched'] - b_hi['random']:+.4f} "
          f"easier than what inference sees")
    print(f"  C. sampled MSE={sampled_mse:.4f} vs marginal {float(np.mean(sq_mean)):.4f}")
    print(f"     -> a denoiser this well conditioned should sample well; if C is "
          f"near the marginal, the gap is in the sampler, not the model.")
    print(f"\nwrote {args.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

"""G1-D T-shape stitch geometry, and train/inference parity.

The G1-D camera stitch is duplicated in three places that must agree exactly,
or a deployed policy silently sees a different camera layout than it was
trained on:

  * ``G1DLeRobotDataset._stitch_t_shape``            (MotusV2, training)
  * ``G1DLeRobotDataset._stitch_t_shape_legacy``     (MotusV2, old checkpoints)
  * ``MotusV2PolicyAdapter.build_stitched_image``    (InferenceMotusV2, serving)

These tests pin the aspect-preserving geometry for G1-D's 480x640 cameras at
384x320 and assert the inference adapter reproduces the dataset's pixels
bit-for-bit.  The adapter lives in a separate repo; that check skips if it is
not present (override its location with ``INFERENCE_MOTUS_ROOT``).
"""

import importlib
import importlib.machinery
import os
import sys
import types
from pathlib import Path

import numpy as np
import pytest
import torch

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))


def _stub_module(name: str, **attrs) -> types.ModuleType:
    """Register an importable stub (a real __spec__ keeps importlib happy)."""
    module = types.ModuleType(name)
    module.__spec__ = importlib.machinery.ModuleSpec(name, None)
    module.__loader__ = None
    for key, value in attrs.items():
        setattr(module, key, value)
    return module


# Heavy optional deps pulled in by the dataset import chain but unused here.
if "qwen_vl_utils" not in sys.modules:
    sys.modules["qwen_vl_utils"] = _stub_module(
        "qwen_vl_utils", process_vision_info=lambda *a, **k: (None, None)
    )
if "decord" not in sys.modules:
    sys.modules["decord"] = _stub_module("decord", VideoReader=object, cpu=lambda *a, **k: None)

from data.g1d.g1d_dataset import G1DLeRobotDataset  # noqa: E402

NATIVE_H, NATIVE_W = 480, 640      # every G1-D camera
CANVAS_H, CANVAS_W = 384, 320      # common.video_height / video_width
NATIVE_ASPECT = NATIVE_W / NATIVE_H


def _bare_dataset(video_size=(CANVAS_H, CANVAS_W), stitch_mode="aspect"):
    """A G1DLeRobotDataset with only the attributes the stitcher touches."""
    ds = object.__new__(G1DLeRobotDataset)
    ds.video_size = video_size
    ds.stitch_mode = stitch_mode
    return ds


def _fake_cams(n=2, seed=0):
    """Distinct non-black frames per camera, so misplacement is detectable."""
    rng = np.random.default_rng(seed)
    return tuple(
        rng.integers(40, 255, size=(n, NATIVE_H, NATIVE_W, 3), dtype=np.uint8)
        for _ in range(3)
    )


# --------------------------------------------------------------------------- #
# Geometry
# --------------------------------------------------------------------------- #
def test_aspect_geometry_is_the_documented_optimum():
    geo = _bare_dataset().t_shape_geometry(
        (NATIVE_H, NATIVE_W), (NATIVE_H, NATIVE_W), (NATIVE_H, NATIVE_W)
    )
    # cam_left_high spans the full canvas width at native 4:3 -> 240x320.
    assert (geo["top_h"], geo["canvas_w"]) == (240, 320)
    # Wrists take only the height they need at half width.
    assert (geo["bot_h"], geo["split_w"], geo["right_w"]) == (120, 160, 160)
    # 240 + 120 = 360 of 384 rows used; the remainder is split evenly.
    assert geo["natural_h"] == 360
    assert (geo["pad_top"], geo["pad_bottom"]) == (12, 12)


def test_top_camera_is_as_large_as_the_canvas_allows():
    """240x320 is the largest 4:3 image that fits a 320-wide canvas."""
    geo = _bare_dataset().t_shape_geometry(
        (NATIVE_H, NATIVE_W), (NATIVE_H, NATIVE_W), (NATIVE_H, NATIVE_W)
    )
    top_h, top_w = geo["top_h"], geo["canvas_w"]
    assert top_w == CANVAS_W, "top row must span the full canvas width"
    assert top_h == round(CANVAS_W / NATIVE_ASPECT)
    # Growing it any further would overflow the canvas width.
    assert round((top_h + 1) * NATIVE_ASPECT) > CANVAS_W
    # ...and it still leaves room for the wrist row.
    assert top_h + geo["bot_h"] <= CANVAS_H


def test_aspect_stitch_preserves_every_camera_aspect_ratio():
    top, bl, br = _fake_cams(n=1)
    ds = _bare_dataset()
    out = ds._stitch_t_shape(top, bl, br)
    assert out.shape == (1, 3, CANVAS_H, CANVAS_W)

    geo = ds.t_shape_geometry(top.shape[1:3], bl.shape[1:3], br.shape[1:3])
    for name, (h, w) in (
        ("top", (geo["top_h"], geo["canvas_w"])),
        ("wrist_l", (geo["bot_h"], geo["split_w"])),
        ("wrist_r", (geo["bot_h"], geo["right_w"])),
    ):
        assert w / h == pytest.approx(NATIVE_ASPECT, rel=1e-9), name


def test_aspect_stitch_fills_93_75_percent_of_the_canvas():
    top, bl, br = _fake_cams(n=1)
    canvas = _bare_dataset()._stitch_t_shape(top, bl, br)[0]
    nonblack = (canvas.amax(dim=0) > 0).float().mean().item()
    assert nonblack == pytest.approx(0.9375, abs=1e-4)

    # The only black pixels are the top and bottom padding strips.
    filled_rows = (canvas.amax(dim=0) > 0).any(dim=1)
    assert not filled_rows[:12].any()
    assert filled_rows[12:372].all()
    assert not filled_rows[372:].any()


def test_aspect_stitch_places_each_camera_in_its_region():
    """Each camera must land in its own T-shape slot, not a neighbour's."""
    top = np.full((1, NATIVE_H, NATIVE_W, 3), 60, dtype=np.uint8)
    bl = np.full((1, NATIVE_H, NATIVE_W, 3), 130, dtype=np.uint8)
    br = np.full((1, NATIVE_H, NATIVE_W, 3), 220, dtype=np.uint8)
    canvas = (_bare_dataset()._stitch_t_shape(top, bl, br)[0] * 255).round().to(torch.uint8)
    assert canvas[:, 12:252, :].unique().tolist() == [60]
    assert canvas[:, 252:372, :160].unique().tolist() == [130]
    assert canvas[:, 252:372, 160:].unique().tolist() == [220]


def test_legacy_stitch_still_reproduces_the_old_wasteful_layout():
    """The legacy path must stay byte-stable for pre-switch checkpoints."""
    from data.utils.image_utils import resize_with_padding

    top, bl, br = _fake_cams(n=1, seed=7)
    ds = _bare_dataset(stitch_mode="legacy")
    padded = []
    for raw in (top, bl, br):
        p = resize_with_padding(raw[0], (CANVAS_H, CANVAS_W))
        padded.append(torch.from_numpy(p).permute(2, 0, 1).float().unsqueeze(0) / 255.0)
    canvas = ds._stitch_t_shape_legacy(*padded)[0]

    assert canvas.shape == (3, CANVAS_H, CANVAS_W)
    nonblack = (canvas.amax(dim=0) > 0).float().mean().item()
    assert nonblack == pytest.approx(0.469, abs=2e-3)
    # cam_left_high shrinks to 120x160 in its 192x320 region.
    top_region = canvas[:, :192, :].amax(dim=0) > 0
    rows = torch.nonzero(top_region.any(dim=1)).flatten()
    cols = torch.nonzero(top_region.any(dim=0)).flatten()
    assert (rows[-1] - rows[0] + 1).item() == 120
    assert (cols[-1] - cols[0] + 1).item() == 160


def test_stitch_mode_is_validated():
    with pytest.raises(ValueError, match="stitch_mode"):
        G1DLeRobotDataset(dataset_dir="/nonexistent", stitch_mode="bogus")


# --------------------------------------------------------------------------- #
# Train / inference parity
# --------------------------------------------------------------------------- #
def _load_inference_adapter():
    """Import MotusV2PolicyAdapter with its heavy model deps stubbed out."""
    root = Path(os.environ.get("INFERENCE_MOTUS_ROOT", REPO_ROOT.parent / "InferenceMotusV2"))
    adapter_py = root / "scripts" / "motusv2_adapter" / "adapter.py"
    if not adapter_py.exists():
        pytest.skip(f"inference adapter not found at {adapter_py}")

    stubs = {
        "models": {},
        "models.motus_wan_vlm_direct_mask": {
            "MotusWanVlmDirectMask": object,
            "MotusWanVlmDirectMaskConfig": object,
        },
        "wan": {},
        "wan.modules": {},
        "wan.modules.t5": {"T5EncoderModel": object},
    }
    saved = {name: sys.modules.get(name) for name in stubs}
    for name, attrs in stubs.items():
        sys.modules[name] = _stub_module(name, **attrs)

    # MotusV2's own ``utils`` package is already imported and would shadow the
    # inference bundle's ``utils.image_utils``.  Evict it for the duration of
    # the import so the adapter binds to ITS real resize_with_padding -- that is
    # the whole point of the comparison.
    evicted = {n: m for n, m in sys.modules.items() if n == "utils" or n.startswith("utils.")}
    for name in evicted:
        del sys.modules[name]
    saved.update(evicted)

    saved_path = list(sys.path)
    sys.path.insert(0, str(adapter_py.parent))
    try:
        import importlib.util

        spec = importlib.util.spec_from_file_location("_g1d_infer_adapter", adapter_py)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module.MotusV2PolicyAdapter
    except Exception as exc:  # pragma: no cover - environment dependent
        pytest.skip(f"could not import inference adapter: {exc}")
    finally:
        sys.path[:] = saved_path
        for name in [n for n in sys.modules if n == "utils" or n.startswith("utils.")]:
            del sys.modules[name]
        for name, previous in saved.items():
            if previous is None:
                sys.modules.pop(name, None)
            else:
                sys.modules[name] = previous


@pytest.mark.parametrize("mode", ["aspect", "legacy"])
def test_inference_adapter_matches_training_pixel_for_pixel(mode):
    adapter_cls = _load_inference_adapter()
    adapter = object.__new__(adapter_cls)
    adapter._video_height = CANVAS_H
    adapter._video_width = CANVAS_W
    adapter._stitch_mode = mode

    top, bl, br = _fake_cams(n=1, seed=11)

    ds = _bare_dataset(stitch_mode=mode)
    if mode == "aspect":
        train = ds._stitch_t_shape(top, bl, br)[0]
    else:
        from data.utils.image_utils import resize_with_padding

        padded = [
            torch.from_numpy(resize_with_padding(raw[0], (CANVAS_H, CANVAS_W)))
            .permute(2, 0, 1).float().unsqueeze(0) / 255.0
            for raw in (top, bl, br)
        ]
        train = ds._stitch_t_shape_legacy(*padded)[0]

    infer_hwc = adapter.build_stitched_image(top[0], bl[0], br[0])
    infer = torch.from_numpy(infer_hwc).permute(2, 0, 1)

    assert infer.shape == train.shape
    max_abs = (infer - train).abs().max().item()
    assert max_abs == 0.0, f"{mode}: train/inference stitch differs by {max_abs}"

#!/usr/bin/env python3
"""Does gradient_checkpointing change what the model learns?

The DROID configs leave ``model.gradient_checkpointing`` at its default (True)
while two RoboTwin configs set it False, so it is a fair question whether the
DROID runs were handicapped by it.

Gradient checkpointing trades memory for recomputation and is mathematically an
identity -- *provided* the checkpointed function is deterministic and the call
pattern is sound.  This exercises the two things that can actually go wrong in
``MotusWanVlmDirectMask._run_mot_layer``:

  * its signature mixes tensors with a plain ``int`` layer index and optional
    ``None`` masks, which older reentrant checkpointing mishandles;
  * it returns three tensors that are fed back in on the next iteration,
    forming a chain 30 layers deep.

The real model is too large to instantiate here, so this reproduces the call
pattern on a small stand-in.  Randomness inside the checkpointed region is the
other classic breaker; ``test_no_randomness_in_checkpointed_path`` asserts the
real module tree has none.

Run:
  python -m pytest tests/test_grad_checkpoint_equivalence.py -q
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest
import torch
import torch.nn as nn
import torch.utils.checkpoint  # noqa: F401  (needed for torch.utils.checkpoint.checkpoint)

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO))


class _Layer(nn.Module):
    """Same shape of interface as _run_mot_layer: 3 streams in, 3 out, plus
    non-tensor args and optional masks."""

    def __init__(self, dim, n_layers):
        super().__init__()
        self.qkv = nn.ModuleList(nn.Linear(dim, 3 * dim) for _ in range(n_layers))
        self.out = nn.ModuleList(nn.Linear(dim, dim) for _ in range(n_layers))
        self.ffn = nn.ModuleList(nn.Sequential(nn.Linear(dim, 4 * dim), nn.GELU(),
                                               nn.Linear(4 * dim, dim))
                                 for _ in range(n_layers))
        self.modulation = nn.Parameter(torch.randn(1, 2, dim) / dim ** 0.5)

    def run(self, v, a, u, adaln, layer_idx: int, mask):
        """Mirrors _run_mot_layer: tensors + int + Optional[Tensor] -> 3 tensors."""
        x = torch.cat([v, a, u], dim=1)
        q, k, val = self.qkv[layer_idx](x).chunk(3, dim=-1)
        attn = torch.softmax(q @ k.transpose(-1, -2) / q.shape[-1] ** 0.5, dim=-1)
        if mask is not None:
            attn = attn * mask
        x = x + self.out[layer_idx](attn @ val) * (1 + self.modulation[:, :1]) + adaln
        x = x + self.ffn[layer_idx](x)
        lv, la = v.shape[1], a.shape[1]
        return x[:, :lv], x[:, lv:lv + la], x[:, lv + la:]


def _run(model, use_ckpt, n_layers, seed=0, mask=None):
    torch.manual_seed(seed)
    dt = next(model.parameters()).dtype
    dim = model.modulation.shape[-1]
    v = torch.randn(2, 7, dim, dtype=dt)
    a = torch.randn(2, 3, dim, dtype=dt)
    u = torch.randn(2, 5, dim, dtype=dt)
    adaln = torch.randn(2, 1, dim, dtype=dt)
    for i in range(n_layers):
        if use_ckpt:
            v, a, u = torch.utils.checkpoint.checkpoint(
                model.run, v, a, u, adaln, i, mask, use_reentrant=False)
        else:
            v, a, u = model.run(v, a, u, adaln, i, mask)
    loss = (v.square().mean() + a.square().mean() + u.square().mean())
    model.zero_grad(set_to_none=True)
    loss.backward()
    grads = {n: p.grad.detach().clone() for n, p in model.named_parameters() if p.grad is not None}
    return float(loss), grads


@pytest.mark.parametrize("mask_kind", ["none", "tensor"])
def test_gradients_are_identical_with_and_without_checkpointing(mask_kind):
    n_layers = 6
    torch.manual_seed(1234)
    model = _Layer(32, n_layers).double()
    mask = None if mask_kind == "none" else torch.rand(2, 15, 15).double()

    loss_off, g_off = _run(model, False, n_layers, mask=mask)
    loss_on, g_on = _run(model, True, n_layers, mask=mask)

    assert loss_off == loss_on, f"loss differs: {loss_off} vs {loss_on}"
    assert set(g_off) == set(g_on), "different parameters received gradients"
    for name in g_off:
        assert torch.equal(g_off[name], g_on[name]), f"gradient differs for {name}"


def test_every_parameter_still_receives_a_gradient():
    """A silently missing gradient is the failure mode that would matter."""
    n_layers = 4
    torch.manual_seed(7)
    model = _Layer(16, n_layers).double()
    _, g = _run(model, True, n_layers)
    missing = [n for n, _ in model.named_parameters() if n not in g]
    assert not missing, f"no gradient reached: {missing}"


def test_no_randomness_in_checkpointed_path():
    """Recomputation only matches if the checkpointed region is deterministic.

    Dropout is the usual culprit; assert the modules _run_mot_layer touches
    declare none. (torch.randn appears only in parameter initialisers.)
    """
    import ast

    RANDOM = {"randn", "rand", "rand_like", "randn_like", "bernoulli", "randint"}

    for rel in ("bak/wan/modules/model.py", "models/action_expert.py",
                "models/qwen3_module_wan.py"):
        src = (REPO / rel).read_text()
        assert "nn.Dropout" not in src, f"{rel} introduces dropout"
        tree = ast.parse(src)
        # Draws inside __init__ are parameter initialisers and run once; only a
        # draw reached during forward would make recomputation diverge.
        for fn in ast.walk(tree):
            if not isinstance(fn, ast.FunctionDef) or fn.name == "__init__":
                continue
            for node in ast.walk(fn):
                if (isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                        and node.func.attr in RANDOM):
                    pytest.fail(f"{rel}:{node.lineno} draws randomness inside "
                                f"{fn.name}(); checkpointed recomputation would diverge")


def test_config_default_is_documented():
    """gradient_checkpointing defaults to True, so configs that omit it get it."""
    src = (REPO / "models/motus_wan_vlm_direct_mask.py").read_text()
    assert "gradient_checkpointing: bool = True" in src


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-q"]))

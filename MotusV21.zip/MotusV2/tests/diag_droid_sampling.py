#!/usr/bin/env python3
"""Is the 0.1 rad jitter a discretization artifact or a genuinely wide posterior?

Compares, against ground-truth training actions:
  - 1 draw / 10 Euler steps   (what the RoboLab server currently does)
  - 1 draw / 50 Euler steps   (finer integration of the same flow)
  - mean of N draws / 10 steps (Monte-Carlo posterior mean)
  - hold-current-state         (trivial baseline)

If 50 steps does not help but averaging does, the flow's learned conditional
distribution is genuinely wide and averaging is a cheap inference-side mitigation.

Run:
  CUDA_VISIBLE_DEVICES=5,6 PYTHONPATH=/tmp/diag_pkgs python tests/diag_droid_sampling.py
"""
from __future__ import annotations

import argparse
import random
import sys
from pathlib import Path

import numpy as np
import torch

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO))
sys.path.insert(0, str(REPO / "tests"))

from diag_droid_replay import CFG, CKPT, VLM, WAN, build_dataset  # noqa: E402


def run(policy, ff, st, lang, vlm_inputs, steps, seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    with torch.no_grad():
        _, pred = policy.model.inference_step(
            first_frame=ff, state=st, num_inference_steps=steps,
            language_embeddings=lang, vlm_inputs=vlm_inputs,
        )
    return pred.squeeze(0).float().cpu().numpy()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--num-samples", type=int, default=8)
    ap.add_argument("--num-draws", type=int, default=8)
    ap.add_argument("--checkpoint", default=CKPT)
    ap.add_argument("--config", default=CFG)
    args = ap.parse_args()

    random.seed(0); np.random.seed(0); torch.manual_seed(0)
    from diag_droid_replay import dataset_params_from_config
    from robolab_motusv2.adapter import MotusV2DroidJointposPolicy

    policy = MotusV2DroidJointposPolicy(
        checkpoint_path=args.checkpoint, config_path=args.config, wan_path=WAN, vlm_path=VLM,
        device="cuda:0", t5_device="cuda:1",
    )
    ds = build_dataset(1, **dataset_params_from_config(args.config))

    res = {k: [] for k in ["s10", "s50", "avg", "hold", "spread"]}
    for i in range(args.num_samples):
        s = ds[i]
        if s is None:
            continue
        frame, state, gt, instr = (s["first_frame"], s["initial_state"].numpy(),
                                   s["action_sequence"].numpy(), s["task_name"])
        # Ground truth stays in raw radians; push the model output back through
        # the adapter's inverse so every checkpoint is scored in the same units.
        model_state = policy.normalizer.normalize_state(state) if policy.normalizer else state
        ff = frame.unsqueeze(0).to(policy.device, dtype=policy.dtype)
        st = torch.from_numpy(model_state).unsqueeze(0).to(policy.device, dtype=policy.dtype)
        lang = policy._encode_t5(instr)
        vlm_inputs = policy._build_vlm_inputs(instr, ff[0])
        denorm = ((lambda a: policy.normalizer.from_model_actions(a, state))
                  if policy.normalizer else (lambda a: a))

        draws = [denorm(run(policy, ff, st, lang, vlm_inputs, 10, 1000 + k))
                 for k in range(args.num_draws)]
        p10 = draws[0]
        p50 = denorm(run(policy, ff, st, lang, vlm_inputs, 50, 1000))
        pavg = np.mean(draws, axis=0)
        hold = np.tile(state[None, :], (gt.shape[0], 1))

        mae = lambda x: float(np.abs(x[:, :7] - gt[:, :7]).mean())
        res["s10"].append(mae(p10)); res["s50"].append(mae(p50))
        res["avg"].append(mae(pavg)); res["hold"].append(mae(hold))
        res["spread"].append(float(np.stack(draws)[:, :, :7].std(0).mean()))
        print(f"[{i}] 10step={res['s10'][-1]:.4f} 50step={res['s50'][-1]:.4f} "
              f"avg{args.num_draws}={res['avg'][-1]:.4f} hold={res['hold'][-1]:.4f} "
              f"draw_std={res['spread'][-1]:.4f}", flush=True)

    print("\n===== MAE vs ground-truth action (arm joints, rad) =====")
    for k, label in [("s10", "1 draw, 10 steps  (current server)"),
                     ("s50", "1 draw, 50 steps"),
                     ("avg", f"mean of {args.num_draws} draws, 10 steps"),
                     ("hold", "hold current state (trivial)")]:
        print(f"  {label:<38s} {np.mean(res[k]):.4f}")
    print(f"\n  per-draw std across {args.num_draws} draws: {np.mean(res['spread']):.4f} rad "
          f"(posterior width)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

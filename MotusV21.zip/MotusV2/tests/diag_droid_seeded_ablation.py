#!/usr/bin/env python3
"""Seeded ablation: hold the sampler's noise fixed, vary one input at a time.

diag_droid_ablation.py showed input deltas at the level of the sampler's own
run-to-run noise (~0.10 rad), which is too coarse to prove anything.  Here every
variant re-seeds the RNG identically, so `repeat` must be exactly 0 and any
non-zero delta is pure input sensitivity.

Also dumps the generated video frames so the video branch can be judged
independently of the action branch.

Run:
  CUDA_VISIBLE_DEVICES=5,6 PYTHONPATH=/tmp/diag_pkgs python tests/diag_droid_seeded_ablation.py
"""
from __future__ import annotations

import argparse
import random
import sys
from pathlib import Path

import numpy as np
import torch

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO))
sys.path.insert(0, str(REPO / "tests"))

from diag_droid_replay import CFG, CKPT, VLM, WAN, build_dataset  # noqa: E402


def run(policy, frame_chw, state_np, instr, seed: int, want_frames=False):
    ff = frame_chw.unsqueeze(0).to(policy.device, dtype=policy.dtype)
    st = torch.from_numpy(state_np).unsqueeze(0).to(policy.device, dtype=policy.dtype)
    lang = policy._encode_t5(instr)
    vlm_inputs = policy._build_vlm_inputs(instr, ff[0])
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    with torch.no_grad():
        frames, pred = policy.model.inference_step(
            first_frame=ff, state=st,
            num_inference_steps=policy.contract.num_inference_timesteps,
            language_embeddings=lang, vlm_inputs=vlm_inputs,
        )
    a = pred.squeeze(0).float().cpu().numpy()
    return (a, frames.squeeze(0).float().cpu().numpy()) if want_frames else (a, None)


def save_strip(path, cond_chw, frames_cthw):
    from PIL import Image

    cond = (cond_chw.numpy().transpose(1, 2, 0) * 255).clip(0, 255).astype(np.uint8)
    gen = [(frames_cthw[:, t].transpose(1, 2, 0) * 255).clip(0, 255).astype(np.uint8)
           for t in range(frames_cthw.shape[1])]
    strip = np.concatenate([cond] + gen, axis=1)
    Image.fromarray(strip).save(path)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--num-samples", type=int, default=6)
    ap.add_argument("--num-meta-files", type=int, default=1)
    ap.add_argument("--seed", type=int, default=1234)
    ap.add_argument("--dump-dir", default="/tmp/diag_video")
    args = ap.parse_args()

    random.seed(0)
    np.random.seed(0)
    torch.manual_seed(0)
    Path(args.dump_dir).mkdir(parents=True, exist_ok=True)

    from robolab_motusv2.adapter import MotusV2DroidJointposPolicy

    policy = MotusV2DroidJointposPolicy(
        checkpoint_path=CKPT, config_path=CFG, wan_path=WAN, vlm_path=VLM,
        device="cuda:0", t5_device="cuda:1",
    )
    ds = build_dataset(args.num_meta_files)

    samples = []
    while len(samples) < args.num_samples:
        s = ds[len(samples)]
        if s is not None:
            samples.append(s)

    conds = ["repeat", "blackim", "otherim", "badtext", "jitstate"]
    acc = {c: [] for c in conds}
    scale = []

    for i, s in enumerate(samples):
        frame, state, instr = s["first_frame"], s["initial_state"].numpy(), s["task_name"]
        other = samples[(i + 1) % len(samples)]["first_frame"]

        base, frames = run(policy, frame, state, instr, args.seed, want_frames=True)
        save_strip(f"{args.dump_dir}/sample{i}_video.png", frame, frames)

        variants = {
            "repeat": run(policy, frame, state, instr, args.seed)[0],
            "blackim": run(policy, torch.zeros_like(frame), state, instr, args.seed)[0],
            "otherim": run(policy, other, state, instr, args.seed)[0],
            "badtext": run(policy, frame, state, "close the refrigerator door", args.seed)[0],
            "jitstate": run(policy, frame, state + np.r_[np.full(7, 0.3, np.float32), 0.0], instr, args.seed)[0],
        }
        for c, v in variants.items():
            acc[c].append(float(np.abs(v[:, :7] - base[:, :7]).mean()))
        scale.append(float(np.abs(base[:, :7] - state[None, :7]).mean()))
        print(f"[{i}] {instr[:40]!r:44s} " + " ".join(f"{c}={acc[c][-1]:.4f}" for c in conds), flush=True)

    print("\n===== SEEDED ABLATION: mean |Δ arm action| vs base (rad) =====")
    for c in conds:
        print(f"  {c:10s} {np.mean(acc[c]):.5f}")
    print(f"\n  reference: mean |pred - state| = {np.mean(scale):.5f} rad "
          f"(the total motion the policy commands)")
    print(f"\n  video strips written to {args.dump_dir}/")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
"""Contract tests for the DROID state/action normalization.

The training dataset and the RoboLab inference adapter must be exact inverses.
If they ever drift, the policy silently emits garbage joint targets, which is
indistinguishable from "the model didn't learn" at eval time -- so pin it here.

Run:
  python -m pytest tests/test_droid_norm.py -q
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pytest

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO))

from data.droid.droid_norm import DEFAULT_DELTA_MASK, DroidNormalizer  # noqa: E402

STATS_PATH = REPO / "data/droid/droid_norm_stats.json"


@pytest.fixture(scope="module")
def norm() -> DroidNormalizer:
    if not STATS_PATH.exists():
        pytest.skip(f"{STATS_PATH} missing; run scripts/compute_droid_norm_stats.py")
    return DroidNormalizer.from_stats_file(STATS_PATH)


def _sample(rng, n=16):
    """A plausible DROID state plus an action chunk near it."""
    state = np.concatenate([
        rng.uniform(-1.5, 1.5, 3),
        rng.uniform(-2.5, -0.5, 1),
        rng.uniform(-1.5, 1.5, 1),
        rng.uniform(1.3, 3.3, 1),
        rng.uniform(-1.5, 1.5, 1),
        rng.uniform(0.0, 1.0, 1),
    ]).astype(np.float32)
    actions = state[None, :] + rng.normal(0, 0.05, (n, 8)).astype(np.float32)
    actions[:, 7] = np.clip(actions[:, 7], 0.0, 1.0)
    return state, actions.astype(np.float32)


def test_roundtrip_is_identity(norm):
    """encode -> decode recovers the original absolute actions."""
    rng = np.random.default_rng(0)
    worst = 0.0
    for _ in range(200):
        state, actions = _sample(rng)
        recovered = norm.from_model_actions(norm.to_model_actions(actions, state), state)
        worst = max(worst, float(np.abs(recovered - actions).max()))
    assert worst < 1e-4, f"round-trip error {worst} rad"


def test_targets_are_well_scaled(norm):
    """Normalized targets must actually use the [-1, 1] range.

    This is the whole point of the change: raw absolute qpos put the useful
    signal at ~3% of the target's dynamic range.
    """
    rng = np.random.default_rng(1)
    outs = [norm.to_model_actions(a, s) for s, a in (_sample(rng) for _ in range(300))]
    y = np.concatenate(outs, 0)
    # arm dims: a typical ~0.05 rad chunk motion should be a visible fraction of
    # the [-1, 1] target range, not a rounding error.
    assert np.abs(y[:, :7]).mean() > 0.02
    # Tails are intentionally left unclipped, but the bulk must still be in range.
    assert np.mean(np.abs(y) <= 1.0) > 0.95


def test_tails_are_not_clipped(norm):
    """A motion beyond q99 must survive the round trip.

    Clipping would silently teach the model to undershoot fast reaches.
    """
    state = np.array([0, -0.6, 0, -2.5, 0, 1.9, 0, 0.0], dtype=np.float32)
    actions = np.tile(state, (4, 1))
    actions[:, 0] += 2.0  # far outside q99 (~0.31 rad)
    back = norm.from_model_actions(norm.to_model_actions(actions, state), state)
    assert np.abs(back - actions).max() < 1e-4


def test_gripper_is_absolute_not_delta(norm):
    """Dim 7 is a binary command; subtracting the state would break thresholding."""
    assert list(norm.delta_mask) == list(DEFAULT_DELTA_MASK)
    assert norm.delta_mask[7] == False  # noqa: E712

    state = np.array([0, -0.6, 0, -2.5, 0, 1.9, 0, 1.0], dtype=np.float32)
    actions = np.tile(state, (4, 1))
    actions[:, 7] = 0.0  # commanded open while currently closed
    y = norm.to_model_actions(actions, state)
    back = norm.from_model_actions(y, state)
    assert np.allclose(back[:, 7], 0.0, atol=1e-4)


def test_delta_removes_the_state_shortcut(norm):
    """Same motion from different arm poses must give the same target.

    If it did not, the state would still leak into the target and the action
    expert could keep solving the task by copying it.
    """
    rng = np.random.default_rng(2)
    motion = rng.normal(0, 0.05, (16, 8)).astype(np.float32)
    motion[:, 7] = 0.5
    ys = []
    for _ in range(5):
        state, _ = _sample(rng)
        actions = state[None, :] + motion
        actions[:, 7] = 0.5
        ys.append(norm.to_model_actions(actions, state))
    for y in ys[1:]:
        assert np.abs(y - ys[0]).max() < 1e-5


def test_adapter_and_dataset_share_one_implementation():
    """The adapter must not re-implement the transform."""
    adapter_src = (REPO / "robolab_motusv2/adapter.py").read_text()
    dataset_src = (REPO / "data/droid/droid_lerobot_dataset.py").read_text()
    assert "droid_norm import DroidNormalizer" in adapter_src
    assert "droid_norm import DroidNormalizer" in dataset_src


def test_rejects_stale_stats_version(norm):
    stats = norm.to_dict()
    stats["version"] = 999
    with pytest.raises(ValueError, match="version"):
        DroidNormalizer.from_dict(stats)


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-q"]))

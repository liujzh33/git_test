"""Checks that action_mode="eef" feeds the model what the parquet actually holds.

Run directly (no pytest needed):
    python tests/test_g1d_eef_mode.py
"""

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from data.g1d.g1d_dataset import G1DLeRobotDataset  # noqa: E402

ROOT = Path("/home/work/wenjj/data/G1-D/pick-kettle-and-cup")
COMMON = dict(
    dataset_dir=str(ROOT),
    num_video_frames=8,
    video_action_freq_ratio=8,
    global_downsample_rate=1,
    t5_mode="none",
    allow_t5_cache_miss_zero=True,
    max_episodes=4,
)


def build(**kw):
    return G1DLeRobotDataset(**COMMON, **kw)


def test_qpos_unchanged():
    """The default path must behave exactly as before the action_mode split."""
    ds = build(action_mode="qpos")
    s = ds[0]
    assert s is not None, "qpos sample came back None"
    assert s["action_sequence"].shape == (64, 16), s["action_sequence"].shape
    assert s["initial_state"].shape == (16,)
    assert "action_valid_mask" not in s, "qpos mode must not emit a mask"
    print("qpos mode: shapes ok, no mask emitted")


def test_eef_matches_parquet():
    """Every action row must equal the stored eef column for some frame."""
    ds = build(action_mode="eef")
    s = ds[0]
    assert s is not None, "eef sample came back None"
    assert s["action_sequence"].shape == (64, 16), s["action_sequence"].shape

    df = pd.read_parquet(ROOT / "data" / "chunk-000" / "file-000.parquet")
    stored = np.stack(df["action.eef"].to_numpy())
    acts = s["action_sequence"].numpy()
    # Each emitted row has to exist verbatim in the column (the sampler picks a
    # random episode and offset, so match by value rather than by index).
    for row in acts[:8]:
        d = np.abs(stored - row).max(axis=1)
        assert d.min() < 1e-6, f"row not found in action.eef column, closest {d.min():.2e}"
    print(f"eef mode: {len(acts)} action rows trace back to the parquet column")


def test_mask_covers_reserved_dims():
    ds = build(action_mode="eef")
    s = ds[0]
    mask = s["action_valid_mask"]
    assert mask.shape == (64, 16), mask.shape
    assert torch.all(mask[:, [6, 14]] == 0.0), "reserved dims must be masked out"
    keep = [i for i in range(16) if i not in (6, 14)]
    assert torch.all(mask[:, keep] == 1.0), "non-reserved dims must be kept"
    assert torch.all(s["action_sequence"][:, [6, 14]] == 0.0), "reserved dims must be zero"
    print("eef mode: mask zeroes dims 6/14 and keeps the other 14")


def test_normalization_is_invertible():
    df = pd.read_parquet(ROOT / "data" / "chunk-000" / "file-000.parquet")
    stored = np.stack(df["action.eef"].to_numpy())
    live_dims = [i for i in range(16) if i not in (6, 14)]

    for mode in ("minmax", "standard"):
        ds = build(action_mode="eef", normalization=True, normalization_mode=mode)
        acts = ds[0]["action_sequence"].numpy()
        raw = ds.action_normalizer.denormalize(acts)
        for row in raw[:8]:
            assert np.abs(stored - row).max(axis=1).min() < 1e-4, f"{mode}: not invertible"
        # Reserved dims must survive normalisation as exact zeros, never 0.5.
        assert np.all(acts[:, [6, 14]] == 0.0), (mode, acts[:, [6, 14]].max())

        live = acts[:, live_dims]
        if mode == "minmax":
            assert live.min() >= -1e-6 and live.max() <= 1 + 1e-6, (live.min(), live.max())
        else:
            # The action expert's prior is N(0,1); standardised targets have to
            # sit at that scale, which is the whole point of the mode.
            assert abs(live.mean()) < 0.4, live.mean()
            assert 0.4 < live.std() < 2.5, live.std()
        print(f"normalization[{mode}]: invertible, reserved dims 0, live "
              f"mean {live.mean():+.3f} std {live.std():.3f}")


def test_delta_is_relative_and_invertible():
    """eef_delta actions must be offsets from the condition frame, and the
    absolute targets must be recoverable from them."""
    from data.g1d.eef_actions import from_delta

    ds = build(action_mode="eef_delta")
    absolute = build(action_mode="eef")

    df = pd.read_parquet(ROOT / "data" / "chunk-000" / "file-000.parquet")
    rows = df[df.episode_index == 0].reset_index(drop=True)
    cond_idx, idxs = 200, [200 + i + 1 for i in range(64)]
    cond = rows.iloc[cond_idx]

    deltas = ds._read_actions(rows, idxs, cond)
    abs_acts = absolute._read_actions(rows, idxs, cond)

    # A delta chunk starting at the condition frame must begin near zero, while
    # the absolute one sits wherever the arm happens to be.
    assert np.linalg.norm(deltas[0, :3]) < 0.05, deltas[0, :3]
    assert np.linalg.norm(abs_acts[0, :3]) > 0.1, abs_acts[0, :3]

    # Same target frames, different condition frame -> different deltas.
    other = ds._read_actions(rows, idxs, rows.iloc[400])
    assert np.abs(other[:, :3] - deltas[:, :3]).max() > 0.01

    recovered = from_delta(ds._raw_vec(cond, "state"), deltas)
    err = np.abs(recovered - abs_acts).max()
    assert err < 1e-5, f"from_delta did not recover the absolute actions ({err:.2e})"
    print(f"eef_delta: relative to condition frame, round-trips to absolute within {err:.2e}")


def test_delta_state_stays_absolute():
    """If the state were also made relative it would be identically zero."""
    ds = build(action_mode="eef_delta")
    absolute = build(action_mode="eef")
    df = pd.read_parquet(ROOT / "data" / "chunk-000" / "file-000.parquet")
    rows = df[df.episode_index == 0].reset_index(drop=True)
    cond = rows.iloc[200]
    assert np.allclose(ds._read_state(cond), absolute._read_state(cond))
    assert np.linalg.norm(ds._read_state(cond)[:3]) > 0.05, "state collapsed to zero"
    print("eef_delta: state is still the absolute pose, as the repo's delta modes do")


def test_delta_normalization_uses_delta_stats():
    stats = json.load(open(ROOT / "meta" / "eef_stats.json"))
    ds = build(action_mode="eef_delta", normalization=True)
    assert ds.state_normalizer is not ds.action_normalizer, "delta mode needs two normalizers"
    assert np.allclose(ds.action_normalizer.offset, np.asarray(stats["delta_mean"], dtype=np.float32))
    assert np.allclose(ds.state_normalizer.offset, np.asarray(stats["mean"], dtype=np.float32))

    df = pd.read_parquet(ROOT / "data" / "chunk-000" / "file-000.parquet")
    rows = df[df.episode_index == 0].reset_index(drop=True)
    acts = ds._read_actions(rows, [200 + i + 1 for i in range(64)], rows.iloc[200])
    live = acts[:, [i for i in range(16) if i not in (6, 14)]]
    assert np.all(acts[:, [6, 14]] == 0.0)
    # One chunk covers horizons 1..64 while the statistics pool every horizon, so
    # a single window is narrower than the population it was scaled by.
    assert abs(live.mean()) < 0.5 and live.std() < 2.5, (live.mean(), live.std())
    print(f"eef_delta: action normalizer uses delta stats, live mean "
          f"{live.mean():+.3f} std {live.std():.3f}")


def test_delta_stats_horizon_guard():
    """Stats generated for a shorter horizon must be rejected, not silently used."""
    import shutil, tempfile

    with tempfile.TemporaryDirectory() as td:
        bad = Path(td) / "eef_stats.json"
        stats = json.load(open(ROOT / "meta" / "eef_stats.json"))
        stats["delta_horizon"] = 8
        bad.write_text(json.dumps(stats))
        try:
            build(action_mode="eef_delta", normalization=True,
                  normalization_stats_path=str(bad))
        except ValueError as e:
            assert "cover horizons up to 8" in str(e), e
            print("eef_delta: short-horizon stats are rejected at construction")
            return
        raise AssertionError("expected ValueError for too-short delta horizon")


def test_missing_columns_fail_fast(tmp_root=None):
    """A dataset without the eef columns must raise at construction."""
    import tempfile, shutil

    with tempfile.TemporaryDirectory() as td:
        fake = Path(td) / "ds"
        shutil.copytree(ROOT / "meta", fake / "meta")
        (fake / "data" / "chunk-000").mkdir(parents=True)
        df = pd.read_parquet(ROOT / "data" / "chunk-000" / "file-000.parquet")
        df.drop(columns=["observation.state.eef", "action.eef"]).to_parquet(
            fake / "data" / "chunk-000" / "file-000.parquet"
        )
        for cam in ("cam_left_high", "cam_left_wrist", "cam_right_wrist"):
            src = ROOT / "videos" / f"observation.images.{cam}"
            if src.exists():
                (fake / "videos" / f"observation.images.{cam}").parent.mkdir(parents=True, exist_ok=True)
                (fake / "videos" / f"observation.images.{cam}").symlink_to(src)
        try:
            G1DLeRobotDataset(**{**COMMON, "dataset_dir": str(fake)}, action_mode="eef")
        except RuntimeError as e:
            assert "action_mode='eef' needs columns" in str(e), e
            print("missing columns: construction fails fast with a pointed message")
            return
        raise AssertionError("expected RuntimeError for missing eef columns")


if __name__ == "__main__":
    test_qpos_unchanged()
    test_eef_matches_parquet()
    test_mask_covers_reserved_dims()
    test_normalization_is_invertible()
    test_delta_is_relative_and_invertible()
    test_delta_state_stays_absolute()
    test_delta_normalization_uses_delta_stats()
    test_delta_stats_horizon_guard()
    test_missing_columns_fail_fast()
    print("\nall g1d eef checks passed")

#!/usr/bin/env python3
"""Why does batching change UMT5 embeddings? Contamination or bf16 kernels?

If encoding the SAME text 8 times in one batch already disagrees with encoding
it alone, nothing leaked between samples and the difference is purely how cuBLAS
reduces at a different batch size (UMT5 skips the 1/sqrt(d) attention scaling,
so bf16 logits are large and poorly conditioned).

If instead identical-text batches agree but mixed-text batches do not, samples
are contaminating each other and batching must not be used.

Run:
  CUDA_VISIBLE_DEVICES=0 PYTHONPATH=/tmp/diag_pkgs python tests/diag_t5_batch_cause.py
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

import torch

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO))
sys.path.insert(0, str(REPO / "bak"))
for _p in os.environ.get("MOTUS_EXTRA_SITE_PACKAGES", "").split(os.pathsep):
    if _p and _p not in sys.path:
        sys.path.append(_p)

from diag_t5_encode_bench import SAMPLES, WAN, encode_batched  # noqa: E402


def rel(a, b):
    a, b = a.float().cpu(), b.float().cpu()
    return float((a - b).norm() / b.norm())


def main() -> int:
    from wan.modules.t5 import T5EncoderModel

    device = "cuda"
    print("loading UMT5-XXL ...", flush=True)
    enc = T5EncoderModel(
        text_len=512, dtype=torch.bfloat16, device=device,
        checkpoint_path=str(Path(WAN) / "models_t5_umt5-xxl-enc-bf16.pth"),
        tokenizer_path=str(Path(WAN) / "google" / "umt5-xxl"),
    )
    probe = SAMPLES[2]  # a longer instruction

    with torch.no_grad():
        alone = enc([probe], device)[0]

        print("\n--- 1. same text repeated N times in one batch, vs encoded alone ---")
        print("    (any difference here cannot be cross-sample leakage)")
        for n in (2, 4, 8, 32):  # pad=512 attention OOMs beyond this
            out = encode_batched(enc, [probe] * n, device, dynamic=False)
            spread = max(rel(o, out[0]) for o in out)
            print(f"      batch={n:4d}: vs alone relL2={rel(out[0], alone):.2e}   "
                  f"disagreement within the batch={spread:.2e}")

        print("\n--- 2. same text inside batches of DIFFERENT neighbours ---")
        print("    (if the neighbours matter, that IS contamination)")
        base = encode_batched(enc, [probe] * 8, device, dynamic=False)[0]
        for i, tag in enumerate(["short neighbours", "long neighbours", "mixed"]):
            if tag == "short neighbours":
                others = [SAMPLES[5]] * 7
            elif tag == "long neighbours":
                others = [SAMPLES[2]] * 7
            else:
                others = SAMPLES[:7]
            out = encode_batched(enc, [probe] + others, device, dynamic=False)[0]
            print(f"      {tag:18s}: relL2 vs same-text batch = {rel(out, base):.2e}")

        print("\n--- 3. does the padding length alone change a single sample? ---")
        d = encode_batched(enc, [probe], device, dynamic=True)[0]
        print(f"      batch=1 dynamic vs batch=1 pad512: relL2={rel(d, alone):.2e}")

        print("\n--- 4. magnitude of the logits UMT5 feeds to softmax ---")
        ids, mask = enc.tokenizer([probe], return_mask=True, add_special_tokens=True)
        x = enc.model.token_embedding(ids.to(device))
        print(f"      token embedding absmax={float(x.abs().max()):.1f}  "
              f"(UMT5 omits 1/sqrt(d) scaling, so attention logits scale with this squared)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

import multiprocessing
import sys
import types

import pytest
import torch

qwen_vl_utils = types.ModuleType("qwen_vl_utils")
qwen_vl_utils.process_vision_info = lambda *args, **kwargs: (None, None)
sys.modules.setdefault("qwen_vl_utils", qwen_vl_utils)

from data.droid.droid_lerobot_dataset import DroidLeRobotDataset
from data.robotwin2.robotwin_agilex_dataset import MinMaxNormalizer, RobotWinTaskDataset


def test_robotwin_unified_eef_normalization_keeps_reserved_dims_zero():
    ds = RobotWinTaskDataset.__new__(RobotWinTaskDataset)
    ds.action_mode = "unified_eef_camera_delta_wrist16"
    ds.normalizer = MinMaxNormalizer(
        action_min=torch.full((16,), -1.0),
        action_max=torch.full((16,), 1.0),
    )

    initial_state = torch.zeros(16)
    action_sequence = torch.zeros(3, 16)

    norm_state, norm_actions = ds._normalize_robot_data(initial_state, action_sequence)

    assert torch.allclose(norm_state[[7, 15]], torch.zeros(2))
    assert torch.allclose(norm_actions[:, [7, 15]], torch.zeros(3, 2))
    assert torch.allclose(norm_state[[0, 6, 8, 14]], torch.full((4,), 0.5))
    assert torch.allclose(norm_actions[:, [0, 6, 8, 14]], torch.full((3, 4), 0.5))


def test_droid_t5_worker_cache_miss_raises_by_default(tmp_path, monkeypatch):
    ds = DroidLeRobotDataset.__new__(DroidLeRobotDataset)
    ds.t5_mode = "disk_cache"
    ds.t5_text_len = 512
    ds.t5_cache_dir = tmp_path
    ds.allow_t5_cache_miss_zero = False

    class WorkerProcess:
        name = "DataLoaderWorker"

    monkeypatch.setattr(multiprocessing, "current_process", lambda: WorkerProcess())

    with pytest.raises(RuntimeError, match="DROID T5 cache miss"):
        ds._get_t5_embedding("pick up the cup")


def test_droid_t5_worker_cache_miss_zero_requires_explicit_opt_in(tmp_path, monkeypatch):
    ds = DroidLeRobotDataset.__new__(DroidLeRobotDataset)
    ds.t5_mode = "disk_cache"
    ds.t5_text_len = 512
    ds.t5_cache_dir = tmp_path
    ds.allow_t5_cache_miss_zero = True

    class WorkerProcess:
        name = "DataLoaderWorker"

    monkeypatch.setattr(multiprocessing, "current_process", lambda: WorkerProcess())

    emb = ds._get_t5_embedding("pick up the cup")

    assert emb.shape == (512, 4096)
    assert torch.count_nonzero(emb) == 0

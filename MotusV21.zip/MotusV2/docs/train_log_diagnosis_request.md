# 训练日志诊断 — 信息收集请求

**目标权重**：`CKPT_WamVlmMask_droid_v4_2cams_9w_steps`（DROID 后训练，90000 步）
**配置**：`configs/droid_wan_vlm_mask_2cam.yaml`
**背景**：该权重在 RoboLab 64 个 simple 任务上成功率 6.88%（22/320）。已从 step 1000 的日志片段中发现疑点，需要完整日志来确认。

请在存有完整训练日志的集群上执行本文档，把产出的文件回传。

---

## 一、为什么需要完整日志

从 step 1000 的片段已经能算出两个数字，它们互相矛盾：

- **训练 action loss ≈ 0.11**。这是 flow-matching 的速度预测损失。如果模型完全不用条件（图像/状态/语言），只知道动作的边缘分布，该损失约为 **0.63**；条件信息完美时趋于 0。实测 0.11 说明去噪器拿到了大量有效信息。
- **验证 action_mse_loss = 0.186**。这是完整多步采样后的动作 MSE。而"永远输出数据集均值"这个常数预测器的 MSE 基线是 **0.195**（由 `droid_norm_stats.json` 的 q01/q99/std 算得）。也就是说采样结果的 **R² 只有 0.046**。

去噪器很强，采样输出却几乎等于均值。**这是一个需要解释的矛盾**，而 step 1000 太早，无法判断它在后续 89000 步里是收敛了还是一直存在。完整日志的验证曲线可以直接回答。

其余待确认的疑点见第四节。

---

## 二、必做：运行日志摘要脚本

脚本已在仓库中：`tools/summarize_train_log.py`。它只依赖 Python 标准库，不需要 torch 或任何环境。

```bash
cd <MotusV2 仓库路径>
python3 tools/summarize_train_log.py <完整训练日志路径> -o /tmp/train_log_summary.md
```

要点：

- 日志分散在多个文件（例如断点续训产生的多份）时，**按时间顺序全部传入**，支持通配符和 `.gz`/`.bz2`/`.xz`：
  ```bash
  python3 tools/summarize_train_log.py 'logs/train_*.log*' -o /tmp/train_log_summary.md
  ```
- 只取 rank 0 的行即可，其他 rank 不需要。
- 默认按 1000 步分桶。若日志只覆盖部分区间，可用 `--bucket 200` 提高分辨率。
- 若脚本报告 `No step lines matched`，说明日志格式与预期不同，请把连续 30 行原始日志贴进回传文件，我来调整正则。

产出的 `/tmp/train_log_summary.md` 通常只有几十 KB，是回传的**主要文件**。

---

## 三、必做：补充以下信息

把下面每一项的命令输出，追加到一个 `train_log_extra.md` 里回传。**每项都标注清楚对应第几条。**

### 1. 实际生效的配置

训练启动时会把配置拷贝一份到 checkpoint 目录。请提供：

```bash
cat <checkpoint_dir>/config.json          # 训练脚本写入的契约文件
ls <checkpoint_dir>                        # 看看有哪些 checkpoint / best_action_l2
```

以及启动时拷贝的那份 yaml（日志里有 `Config File: <路径>` 一行指明位置）。

### 2. 并行规模与真实 batch

```bash
grep -m5 -E "Trainer initialized on rank|Gradient accumulation steps|world_size|num_processes" <日志>
```

需要明确：**world_size（总卡数）、每卡 batch_size、梯度累积步数**。三者决定了全局 batch 和「每个 epoch 多少步」。

### 3. 数据集规模

```bash
grep -m10 -E "episodes|Dataset:|Dataloader creation took|indexed|samples" <日志> | head -20
```

需要明确：**过滤后实际索引到的 episode 数量和 dataset `__len__`**。

日志片段显示 step 1000 时已是 Epoch 15，即约 67 步/epoch。若属实，90000 步意味着在同一批数据上跑了 **约 1350 个 epoch**，这需要数据集规模来确认（见第四节第 1 条）。

### 4. 是否发生过断点续训

```bash
grep -n -E "Loading checkpoint from|Resetting scheduler|Checkpoint loaded successfully" <日志>
```

### 5. 最优 action L2 出现在哪一步

```bash
grep -n "best_action_l2\|Best action L2" <日志> | head -40
```

如果最优值出现在很早的步数（例如 5000 步之前）而后再没刷新，说明后续 8 万多步没有带来动作精度提升，这一点很关键。

### 6. 最后一次验证的原始输出

请把日志**最末尾**的完整验证块原样贴出（从 `Validation - Step` 到下一条 `Step` 行之间的全部内容），约 15 行。这是最接近所交付权重的状态。

### 7. 训练是否正常结束

日志最后 50 行原样贴出。需要确认 90000 步是正常保存退出，还是中断后取的最近 checkpoint。

---

## 四、我会用这些信息回答的问题

回传后我会重点看以下几条，你也可以先自行对照：

1. **是否严重过拟合。** 若 67 步/epoch 属实，90000 步 ≈ 1350 个 epoch。DROID 完整数据集约 76k episodes，而我们下载的子集在归一化统计时显示只有 7566 个 episode（过滤后 6205）。在约 6000 个场景上重复 1350 遍，视觉分支极易记住训练场景，而 RoboLab 仿真场景完全是分布外的。

2. **验证指标是否根本测不出过拟合。** 已确认代码中 `DroidLeRobotDataset` 的 `val` 参数只控制数据增强开关（`image_aug`、`random_exterior`），**从未用于划分 episode**——验证集和训练集是同一批数据。加上 `num_eval_batches` 默认只有 2 个 batch，且 `DistributedSampler` 未调用 `set_epoch`，等于每次都在同样的少量训练样本上评估。所以现有的 `action_mse_loss` 曲线反映的是**训练集拟合程度**，不是泛化能力。这条基本可以确定，日志只是用来看拟合曲线本身的形状。

3. **采样路径是否与训练不一致。** 第一节的矛盾有一个很自然的解释：动作 chunk 有 15+ 个时间步且高度时间相关，模型在中等噪声下可以靠「在 chunk 内部做时间平滑」把速度预测做得很准，从而拿到低训练损失，**却没有真正学会依赖视觉/语言条件**。而采样从纯噪声开始，此时 chunk 内部没有任何信号，只能靠条件——条件通路弱，采样就退化成输出边缘均值。这与「把视觉 token 预算提上去后成功率从 0 涨到 6.88%」的现象一致。

4. **token loss 恒为 0。** 片段中 `Token: 0.0000` 是精确的 0，不是小数值。需要确认这是配置上有意关闭，还是 VLM 的 token 预测头没有接上。

5. **学习率与训练时长。** step 1000 时三组 LR 均为 4.95e-05，`warmup_steps: 200` 已结束。需要看后续是否按计划衰减。

---

## 五、可选：一个能直接验证第 3 条的离线实验

第 3 条（条件通路弱）不需要完整日志也能验证，只要有权重和少量数据即可，**我可以在本地这台机器上跑**，因为权重 `/home/work/wenjj/ckpt/CKPT_WamVlmMask_droid_v4_2cams_9w_steps` 已经在本地。

做法：在若干固定噪声水平 σ 上分别统计 action loss（而不是像训练时那样对 σ 平均）。判读方式：

- σ→1（接近纯噪声）时，chunk 内部没有信息，损失只能靠条件降下来。若此处损失接近边缘方差 0.195，说明**条件通路几乎没起作用**，这就坐实了第 3 条。
- σ→0（接近干净数据）时损失应接近 1.0（噪声本身的方差），这是理论值，可用来校验实验实现是否正确。

如果你同意，我可以直接开始做这个实验，它比等日志更快给出结论。

---

## 六、回传清单

- [ ] `/tmp/train_log_summary.md`（第二节脚本产出，主要文件）
- [ ] `train_log_extra.md`（第三节 7 项）
- [ ] 若脚本未能解析，附 30 行原始日志

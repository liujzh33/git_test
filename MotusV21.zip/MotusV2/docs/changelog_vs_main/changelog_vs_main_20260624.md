# MotusV2 vs MotusV2-main 完整改动记录

> 生成日期：2026-06-24
> 对比目录：
> - 原版项目：`/home/ma-user/work/wx1469573/MotusV2-main`
> - 修改版项目：`/home/ma-user/work/wx1469573/MotusV2`

---

## 一、总览

| 统计项 | 数量 |
|--------|------|
| 新增文件（源代码/配置） | 7 |
| 新增文件（文档/辅助） | 4 |
| 修改文件 | 10 |
| 未修改文件 | 312 |

改动核心主题：

1. **新增 `unified_eef_camera_delta_wrist16` 动作表示** — 统一 EEF camera-frame delta wrist 动作，使用 rotation vector (axis-angle) 代替 quaternion
2. **新增 Xperience-10M 数据集支持** — 适配器类 + 跨数据集混合训练配置
3. **Masked Action Loss** — 支持 per-dim 有效性掩码，无效手的 block 和 reserved dims 不参与 loss
4. **训练配置/脚本调整** — checkpoint 路径、训练步数、GPU 配置等

---

## 二、新增文件

| # | 文件路径 | 说明 | 约行数 |
|---|---------|------|--------|
| 1 | `data/human/unified_eef_action.py` | **核心模块**：统一 EEF camera-frame delta wrist 动作表示。含 `log_SO3`、`exp_SO3`、`compute_camera_delta_action`、`compute_unified_eef_action_16d`、`compute_unified_eef_state_16d`、`compute_unified_eef_action_sequence`、`compute_unified_eef_state_from_poses`、`quat_wxyz_to_rotmat`、`build_hand_world_poses_from_xyzquat`、`build_hand_world_poses_from_rotmat`、`build_hand_world_poses_from_se3_4x4`、`build_camera_world_pose_from_slam`、`relative_xyzquat_to_camera_delta` 等函数及常量 | ~595 |
| 2 | `data/xperience/__init__.py` | Xperience 数据集包初始化文件（空文件） | 1 |
| 3 | `data/xperience/xperience_dataset.py` | **Xperience-10M 数据集适配器**：`XperienceMotusDataset` 类，支持 `unified_eef_camera_delta_wrist16` action mode，从 HDF5 读取 hand\_mocap/SLAM/calibration 数据，计算 camera world pose，返回含 `action_valid_mask` 和 `task_name` 的样本 | ~442 |
| 4 | `configs/motusv1_adapted/cross_dataset_mixed_unified_eef_wrist16_xperience10m.yaml` | **新训练配置**：`action_mode: unified_eef_camera_delta_wrist16`，6 个子数据集（4×VITRA + EgoDex + Xperience），`require_camera_extrinsics: true`，独立 T5 cache 和 checkpoint 目录 | ~156 |
| 5 | `scripts/train_ADS_MotusV2_cross_unified_eef_wrist16_xperience10m.sh` | **新启动脚本**：指向新配置文件，8 卡 torchrun + DeepSpeed ZeRO-1 | ~65 |
| 6 | `tests/test_unified_eef_action.py` | **单元测试**：11 个测试用例（log/exp roundtrip、identity camera+wrist、pure translation/rotation、inverse consistency、missing hand mask、action sequence shape、quaternion conversion、SLAM camera pose、no NaN/Inf、effective indices） | ~415 |
| 7 | `CLAUDE.md` | 项目根目录 Claude Code 指引文档，描述架构、训练命令、约定等 | ~126 |
| 8 | `.claude/settings.json` | Claude Code 工具配置文件 | — |
| 9 | `.claude/settings.local.json` | Claude Code 本地配置文件 | — |
| 10 | `docs/session_log_20260622_vlm_prompt_mode_fix.md` | **VLM prompt 不匹配修复记录**：分析 34.3% 性能差距根因（训练用 simple prompt，推理硬编码 motion-token prompt），修复方案（deploy\_policy.py 新增 `vlm_prompt_mode` 参数，paths\_config.yml 新增配置字段，新增 `_preprocess_vlm_messages_simple()` 方法） | ~326 |
| 11 | `docs/session_log_20260624_unified_eef_camera_delta_wrist16_implementation_notes.md` | **本次 unified\_eef 实现详细记录**：数学定义、关键决策、代码修改记录、验收测试结果、TODO 列表 | ~552 |

---

## 三、修改文件详细差异

### 3.1 `configs/motusv1_adapted/cross_dataset_mixed_wrist16.yaml`

| 项目 | 内容 |
|------|------|
| 变更类型 | ✏️ 修改 |
| 改动行数 | 1 行 |

```diff
- training_mode: "finetune"
+ # training_mode: "finetune"
```

**影响：** `training_mode` 被注释掉，将依赖代码中的默认值。

---

### 3.2 `configs/robotwin_wan_vlm_mask_stage2_15w.yaml`

| 项目 | 内容 |
|------|------|
| 变更类型 | ✏️ 修改 |
| 改动行数 | 1 行 |

```diff
- checkpoint_path: null  # Path to pre-trained model
+ checkpoint_path: "/cache/wx1469573/ckpts/best_action_l2_92000"  # Path to pre-trained model
```

**影响：** 训练时自动加载指定预训练 checkpoint，不再为 null。

---

### 3.3 `configs/robotwin_wan_vlm_mask_stage2_reweight_posttrain.yaml`

| 项目 | 内容 |
|------|------|
| 变更类型 | ✏️ 修改 |
| 改动行数 | 6 行 |

| # | 改动 | 原值 | 新值 |
|---|------|------|------|
| 1 | 存储模式注释掉 | `storage_mode: "obs"` | `# storage_mode: "obs"` |
| 2 | OBS 路径注释掉 | `obs_base_path: "obs://..."` | `# obs_base_path: "obs://..."` |
| 3 | 训练步数翻倍 | `max_steps: 40000` | `max_steps: 80000` |
| 4 | 保存间隔变大 | `save_interval: 2000` | `save_interval: 10000` |
| 5 | TensorBoard 路径变更 | `.../motus/tensorboard_...` | `.../ckpts/tensorboard_...` |
| 6 | 指定 checkpoint 路径 | `checkpoint_path: null` | `checkpoint_path: "/cache/wx1469573/pretrained_models/ckpt"` |

---

### 3.4 `data/dataset.py`

| 项目 | 内容 |
|------|------|
| 变更类型 | ✏️ 修改 |
| 改动行数 | +8 行 |

在 `_cross_dataset_mixed()` 函数中新增 `xperience` 数据集类型分支：

```python
elif ds_type == "xperience":
    from .xperience.xperience_dataset import XperienceMotusDataset

    for key in ["max_episodes", "t5_mode", "wan_path", "t5_cache_dir", "t5_device", "t5_text_len",
                 "reference_camera_key", "require_camera_extrinsics", "allow_base_relative_fallback"]:
        if key in ds_cfg:
            params[key] = ds_cfg[key]
    dataset = XperienceMotusDataset(**params)
```

**影响：** 仅当 config 中 `datasets[].type == "xperience"` 时生效，不影响其他数据集类型。

---

### 3.5 `data/egodex/egodex_dataset.py`

| 项目 | 内容 |
|------|------|
| 变更类型 | ✏️ 修改 |
| 改动行数 | +82 行 |

#### 改动 1：新增 import

```python
from data.human.unified_eef_action import (
    build_hand_world_poses_from_se3_4x4,
    compute_unified_eef_action_sequence,
    compute_unified_eef_state_from_poses,
    UNIFIED_EEF_ACTION_DIM,
    UNIFIED_EEF_STATE_DIM,
)
```

#### 改动 2：扩展 action\_mode 白名单

```diff
- assert self.action_mode in ("wrist", "wrist_padded16", "relative_wrist_padded16", "padded_per_hand"), ...
+ assert self.action_mode in ("wrist", "wrist_padded16", "relative_wrist_padded16", "unified_eef_camera_delta_wrist16", "padded_per_hand"), ...
```

#### 改动 3：新增 \_action\_dim / \_state\_dim 分支

```python
elif self.action_mode == "unified_eef_camera_delta_wrist16":
    self._action_dim = UNIFIED_EEF_ACTION_DIM  # 16
    self._state_dim = UNIFIED_EEF_STATE_DIM    # 16
```

#### 改动 4：新增方法 `_extract_unified_eef_action_state()`（~70 行）

- 从 HDF5 读取 `leftHand`/`rightHand`/`camera` 4×4 SE(3) transforms
- `cam_tfs[frame_idx, :3, :3]` 作为 `R_w_c`（camera rotation in world）
- 遍历窗口帧，基于 confidence 判断有效性
- 调用 `compute_unified_eef_action_sequence()` 和 `compute_unified_eef_state_from_poses()`
- 返回 `actions, state, action_masks, instruction`

#### 改动 5：`__getitem__` 新增 dispatch

```python
elif self.action_mode == "unified_eef_camera_delta_wrist16":
    action, state, valid_mask, instruction = self._extract_unified_eef_action_state(
        ep["h5_path"], frame_start)
```

**影响：** 仅当 `action_mode == "unified_eef_camera_delta_wrist16"` 时走新路径，旧 action\_mode 完全不受影响。

---

### 3.6 `data/human/vitra_dataset.py`

| 项目 | 内容 |
|------|------|
| 变更类型 | ✏️ 修改 |
| 改动行数 | +157 行 |

#### 改动 1：新增 import

```python
from data.human.unified_eef_action import (
    compute_unified_eef_action_sequence,
    compute_unified_eef_state_from_poses,
    quat_wxyz_to_rotmat,
    UNIFIED_EEF_ACTION_DIM,
    UNIFIED_EEF_STATE_DIM,
)
```

#### 改动 2：扩展 action\_mode 白名单

```diff
- assert self.action_mode in ("default", "wrist", "wrist_padded16", "relative_wrist_padded16", "padded_per_hand", "latent"), ...
+ assert self.action_mode in ("default", "wrist", "wrist_padded16", "relative_wrist_padded16", "unified_eef_camera_delta_wrist16", "padded_per_hand", "latent"), ...
```

#### 改动 3：新增标志

```python
self.unified_eef_mode = self.action_mode == "unified_eef_camera_delta_wrist16"
```

#### 改动 4：新增方法 `_get_unified_eef_sample()`（~145 行）

- 从 `epi["left/right"]["global_orient_worldspace"]` 和 `transl_worldspace` 获取 world-frame 手腕 poses
- 从 `R_w2c[frame_id].T` 获取 reference camera rotation in world
- 从 `epi["left/right"]["kept_frames"]` 获取有效性
- 调用 `compute_unified_eef_action_sequence()` 和 `compute_unified_eef_state_from_poses()`
- 返回包含 `action_valid_mask` 的样本字典

#### 改动 5：`__getitem__` 新增 dispatch

```python
elif self.action_mode == "unified_eef_camera_delta_wrist16":
    return self._get_unified_eef_sample(episode_id, frame_id)
```

**影响：** 仅当 `action_mode == "unified_eef_camera_delta_wrist16"` 时走新路径，旧 action\_mode 完全不受影响。

---

### 3.7 `models/motus_wan_vlm_direct_mask.py`

| 项目 | 内容 |
|------|------|
| 变更类型 | ✏️ 修改 |
| 改动行数 | +18 / -2 行 |

#### 改动 1：`training_step()` 新增参数

```diff
  def training_step(
      self, ...,
+     action_valid_mask: Optional[torch.Tensor] = None,  # [B, chunk_size, action_dim] per-dim mask
      return_dict: bool = True
  ) -> Dict[str, torch.Tensor]:
```

#### 改动 2：Action loss 计算改为 masked loss

```diff
- # Action loss
- action_loss = torch.nn.functional.mse_loss(action_pred, action_target, reduction='mean')
+ # Action loss (with optional per-dim mask for unified_eef_camera_delta_wrist16)
+ if action_valid_mask is not None:
+     action_valid_mask = action_valid_mask.to(action_pred.device).float()
+     if action_valid_mask.shape != action_pred.shape:
+         if action_valid_mask.ndim == action_pred.ndim - 1:
+             action_valid_mask = action_valid_mask.unsqueeze(-1).expand_as(action_pred)
+     sq_diff = (action_pred - action_target) ** 2
+     masked_sq_diff = sq_diff * action_valid_mask
+     n_valid = action_valid_mask.sum().clamp(min=1.0)
+     action_loss = masked_sq_diff.sum() / n_valid
+ else:
+     action_loss = torch.nn.functional.mse_loss(action_pred, action_target, reduction='mean')
```

**影响：** `action_valid_mask` 默认为 None，不传时行为与原版完全一致。仅在 unified\_eef 模式下才传递此参数。

---

### 3.8 `train/train_wan_vlm_mask.py`

| 项目 | 内容 |
|------|------|
| 变更类型 | ✏️ 修改 |
| 改动行数 | +87 / -2 行 |

#### 改动 1：新增 import

```python
import numpy as np
```

#### 改动 2：配置解析新增 `unified_eef_camera_delta_wrist16`

```diff
- elif action_mode in ('wrist_padded16', 'relative_wrist_padded16'):
+ elif action_mode in ('wrist_padded16', 'relative_wrist_padded16', 'unified_eef_camera_delta_wrist16'):
      config.common.action_dim = 16
      config.common.state_dim = 16
```

#### 改动 3：`train_step()` 传递 `action_valid_mask`

```python
# Action valid mask (for unified_eef_camera_delta_wrist16 and similar)
action_valid_mask = batch.get('action_valid_mask')
if action_valid_mask is not None:
    action_valid_mask = action_valid_mask.to(self.device)

# ...
loss_dict = model.training_step(
    ...,
    action_valid_mask=action_valid_mask,
    return_dict=True
)
```

#### 改动 4：新增 First Batch Debug / Sanity Check（~80 行）

在 dataloader 创建后、`accelerator.prepare()` 前，仅 rank 0 执行：

- 打印 `action_mode`、`action_sequence`/`initial_state`/`action_valid_mask` 的 shape
- 打印 action mean/std/min/max，NaN/Inf 检测
- 对 `unified_eef_camera_delta_wrist16` 模式额外打印：
  - left/right delta\_xyz 和 delta\_rotvec 的 mean/std
  - rotvec max abs（应 ≤ π）
  - reserved dims 是否全零
  - left/right valid frame ratio
  - camera extrinsics 使用情况
- 打印 task\_names 分布

---

### 3.9 `scripts/train_ADS_MotusV2_robotwin.sh`

| 项目 | 内容 |
|------|------|
| 变更类型 | ✏️ 修改 |
| 改动行数 | 4 行 |

默认 GPU 配置从 4 卡改 8 卡：

```diff
- # NPROC_PER_NODE=${NPROC_PER_NODE:-8}
+ NPROC_PER_NODE=${NPROC_PER_NODE:-8}

- export CUDA_VISIBLE_DEVICES=4,5,6,7
- NPROC_PER_NODE=${NPROC_PER_NODE:-4}
+ # export CUDA_VISIBLE_DEVICES=4,5,6,7
+ # NPROC_PER_NODE=${NPROC_PER_NODE:-4}
```

---

### 3.10 `scripts/train_ADS_MotusV2_robotwin_reweight_posttrain.sh`

| 项目 | 内容 |
|------|------|
| 变更类型 | ✏️ 修改 |
| 改动行数 | 1 行（末尾缺少换行符） |

```diff
-     2>&1 | tee "$LOG_FILE"
+     2>&1 | tee "$LOG_FILE"   ← 无末尾换行符
```

**影响：** 微小的文件格式差异，无功能影响。

---

## 四、核心功能变更详解

### 4.1 新增 `unified_eef_camera_delta_wrist16` 动作表示

这是最重要的改动。新增了一种统一 EEF (End-Effector) camera-frame delta 动作表示。

#### 16D 布局

```
[left_delta_xyz_cam(3), left_delta_rotvec_cam(3), 0, 0,
 right_delta_xyz_cam(3), right_delta_rotvec_cam(3), 0, 0]
```

每 arm 8D 结构：`[delta_x, delta_y, delta_z, delta_rx, delta_ry, delta_rz, reserved_0, reserved_1]`

- 有效 loss 维度：左臂 `[0:6]`，右臂 `[8:14]`
- Reserved 维度：`[6:8]` 和 `[14:16]`，始终为 0，不参与 loss

#### 数学定义

对于每个样本、每只手：

```
c      = reference camera frame
e      = 当前 wrist / EEF frame
e*     = 目标 wrist / EEF frame
R_w_e  = 当前 EEF rotation in world
t_w_e  = 当前 EEF position in world
R_w_e* = 目标 EEF rotation in world
t_w_e* = 目标 EEF position in world
R_w_c  = reference camera rotation in world
```

Step 1 — EEF frame 下的相对运动：

```
R_e_e* = R_w_e^T @ R_w_e*
t_e_e* = R_w_e^T @ (t_w_e* - t_w_e)
```

Step 2 — 投影到 camera frame：

```
R_c_e  = R_w_c^T @ R_w_e
R_e_c  = R_c_e^T
R_delta_c = R_c_e @ R_e_e* @ R_e_c
t_delta_c = R_c_e @ t_e_e*
```

Step 3 — 提取 rotation vector：

```
delta_rotvec_c = log_SO3(R_delta_c)
```

Step 4 — 组装 per-arm action：

```
per_arm_action_8d = [t_delta_c[0], t_delta_c[1], t_delta_c[2],
                      delta_rotvec_c[0], delta_rotvec_c[1], delta_rotvec_c[2],
                      0, 0]
```

#### 与旧模式对比

| 对比项 | `relative_wrist_padded16`（旧） | `unified_eef_camera_delta_wrist16`（新） |
|--------|-------------------------------|---------------------------------------|
| 布局 | `[left_xyzquat(7), 0, right_xyzquat(7), 0]` | `[left_delta_xyz(3), left_delta_rotvec(3), 0, 0, right_...]` |
| 旋转表示 | Quaternion (WXYZ) | Rotation vector (axis-angle / SO(3) log map) |
| 参考坐标系 | 初始手腕 frame | Reference camera frame |
| 有效维度 | 每 arm 7D | 每 arm 6D |
| Reserved 维度 | 每 arm 1D | 每 arm 2D |
| 总维度 | 16 | 16 |

### 4.2 Reference Camera 选择

| 数据集 | Reference Camera | 获取方式 |
|--------|-----------------|----------|
| VITRA | Episode extrinsics 中 anchor frame 的 camera | `R_w_c = R_w2c[frame_id].T`，其中 `R_w2c` 来自 `epi["extrinsics"][:, :3, :3]` |
| EgoDex | HDF5 `/transforms/camera` 中 anchor frame | `R_w_c = cam_tfs[frame_idx, :3, :3]` |
| Xperience | SLAM body pose + calibration `T_c_b` | `R_w_c, t_w_c = build_camera_world_pose_from_slam(slam_trans, slam_quat_wxyz, T_c_b)` |

### 4.3 新增 Xperience-10M 数据集支持

**数据格式：**

```
<data_root>/<uuid>/epN/
    annotation.hdf5
    stereo_left.mp4
```

**HDF5 字段：**

| 字段 | Shape | 说明 |
|------|-------|------|
| `hand_mocap/left_translation` | (N, 3) | 左手腕在 world frame 的绝对位置 |
| `hand_mocap/left_mano_hand_global_orient` | (N, 9) | 左手腕 3×3 rotation matrix flattened |
| `hand_mocap/right_translation` | (N, 3) | 右手腕位置 |
| `hand_mocap/right_mano_hand_global_orient` | (N, 9) | 右手腕旋转 |
| `slam/trans_xyz` | (N, 3) | SLAM body 在 world frame 的位置 |
| `slam/quat_wxyz` | (N, 4) | SLAM body 四元数 (WXYZ) |
| `calibration/cam0/T_c_b` | (4, 4) | cam0 外参：body → cam0 |
| `caption` | scalar (JSON) | 任务描述 |

**有效性判断：**
- 手腕数据 translation 全零或 NaN → 无效
- Camera extrinsics 不可用 → 根据 `require_camera_extrinsics` 决定跳过或 fallback

### 4.4 Masked Action Loss

模型训练新增 per-dim action valid mask 机制：

- 仅对有效维度计算 MSE loss
- 无效手的 block 填 0、mask 填 0，不参与 loss
- Reserved dims (6:8, 14:16) mask 始终为 0
- 对旧模式完全向后兼容（`mask=None` 时退化为普通 MSE loss）

### 4.5 First Batch Debug Logging

训练脚本新增首个 batch 的详细统计日志，便于调试新动作模式的数值健康性。

---

## 五、完整文件改动总表

| # | 文件路径 | 变更类型 | 改动内容摘要 | 影响范围 |
|---|---------|---------|-------------|---------|
| 1 | `CLAUDE.md` | 🆕 新增 | 项目根目录 Claude Code 指引文档 | 项目文档 |
| 2 | `.claude/settings.json` | 🆕 新增 | Claude Code 工具配置 | 工具配置 |
| 3 | `.claude/settings.local.json` | 🆕 新增 | Claude Code 本地配置 | 工具配置 |
| 4 | `data/human/unified_eef_action.py` | 🆕 新增 | 核心：统一 EEF camera-frame delta wrist 动作表示模块，含 SO(3) log/exp map、camera delta 计算、quaternion 转换、SLAM camera pose 构建、序列批处理等（~595 行） | 核心功能 |
| 5 | `data/xperience/__init__.py` | 🆕 新增 | Xperience 数据集包初始化文件 | 数据集 |
| 6 | `data/xperience/xperience_dataset.py` | 🆕 新增 | Xperience-10M 适配器 `XperienceMotusDataset`，支持 unified\_eef camera delta wrist16，从 HDF5 读取 hand\_mocap/SLAM/calibration（~442 行） | 数据集 |
| 7 | `configs/motusv1_adapted/cross_dataset_mixed_unified_eef_wrist16_xperience10m.yaml` | 🆕 新增 | 新训练配置：6 子数据集混合，action\_mode=unified\_eef\_camera\_delta\_wrist16 | 训练配置 |
| 8 | `scripts/train_ADS_MotusV2_cross_unified_eef_wrist16_xperience10m.sh` | 🆕 新增 | 新启动脚本，指向新配置文件 | 训练脚本 |
| 9 | `tests/test_unified_eef_action.py` | 🆕 新增 | 11 个单元测试用例（~415 行） | 测试 |
| 10 | `docs/session_log_20260622_vlm_prompt_mode_fix.md` | 🆕 新增 | VLM prompt 训练-推理不匹配修复记录，34.3% 性能差距分析 | 文档 |
| 11 | `docs/session_log_20260624_unified_eef_camera_delta_wrist16_implementation_notes.md` | 🆕 新增 | unified\_eef 实现详细记录，含数学定义、关键决策、验收结果、TODO | 文档 |
| 12 | `configs/motusv1_adapted/cross_dataset_mixed_wrist16.yaml` | ✏️ 修改 | 注释掉 `training_mode: "finetune"` | 训练配置 |
| 13 | `configs/robotwin_wan_vlm_mask_stage2_15w.yaml` | ✏️ 修改 | `checkpoint_path: null` → 指定预训练路径 | 训练配置 |
| 14 | `configs/robotwin_wan_vlm_mask_stage2_reweight_posttrain.yaml` | ✏️ 修改 | 6 处改动：存储模式注释、步数 4w→8w、保存间隔 2k→10k、TB 路径变更、checkpoint 指定路径、末尾缺换行 | 训练配置 |
| 15 | `data/dataset.py` | ✏️ 修改 | 新增 `xperience` 数据集类型分支（+8 行） | 数据集注册 |
| 16 | `data/egodex/egodex_dataset.py` | ✏️ 修改 | 5 处改动：import、action\_mode 白名单、dim 分支、新增 `_extract_unified_eef_action_state()` 方法（+82 行） | 数据集 |
| 17 | `data/human/vitra_dataset.py` | ✏️ 修改 | 5 处改动：import、action\_mode 白名单、unified\_eef\_mode 标志、新增 `_get_unified_eef_sample()` 方法（+157 行） | 数据集 |
| 18 | `models/motus_wan_vlm_direct_mask.py` | ✏️ 修改 | 2 处改动：`training_step()` 新增 `action_valid_mask` 参数、action loss 改为 masked loss（+18/-2 行） | 模型训练 |
| 19 | `train/train_wan_vlm_mask.py` | ✏️ 修改 | 4 处改动：import numpy、配置解析扩展、传递 mask、新增 First Batch Debug 日志（+87/-2 行） | 训练脚本 |
| 20 | `scripts/train_ADS_MotusV2_robotwin.sh` | ✏️ 修改 | 默认 GPU 配置从 4 卡改 8 卡 | 训练脚本 |
| 21 | `scripts/train_ADS_MotusV2_robotwin_reweight_posttrain.sh` | ✏️ 修改 | 文件末尾缺少换行符（功能无影响） | 训练脚本 |

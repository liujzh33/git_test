# MotusV2 vs MotusV2-main 完整改动记录（2026-07-02）

> 生成日期：2026-07-02
> 对比目录：
> - 原版项目：`/home/ma-user/work/wx1469573/MotusV2-main`
> - 修改版项目：`/home/ma-user/work/wx1469573/MotusV2`
> 对比方法：`diff -rq` 全量目录比较 + 逐文件 `diff -u`，已剔除 `__pycache__`、`*.pyc`、`outputs/`、`t5_cache_*`、`xperience_shape_report.json` 等运行时产物。

> 说明：仓库中已存在 `docs/changelog_vs_main.md`（截至 2026-06-24），但未覆盖 06-26 之后的 RoboTwin gripper 适配、DROID 接入、`vlm_causal_attention`、`grid_sizes` 修复、`action_valid_mask` 推理透传等改动。本报告补齐这些内容，作为完整的最新改动记录。

---

## 一、总览

| 类别 | 数量 |
|------|------|
| 新增源码/配置/脚本/测试 | 9 |
| 新增文档 | 3（另含已存在的 `changelog_vs_main.md`，仅记录到 06-24） |
| 删除文件（原版有、新版无） | 2 个旧规划文档 |
| 实质修改的代码文件 | 7 |
| 实质修改的配置/脚本 | 5 |
| 仅末尾换行差异（无意义） | 6 |

改动核心主题（按时间从早到晚）：

1. **`unified_eef_camera_delta_wrist16` 动作表示** —— 已在原版基础上扩展出**带 gripper 的机器人变体**（`*_with_gripper` 系列函数）。
2. **RoboTwin 适配 unified_eef** —— `robotwin_agilex_dataset.py` 接入统一 EEF 动作 + 固定头部相机外参 + per-dim mask。
3. **DROID 数据集接入** —— 新增 `data/droid/`、配置、训练脚本、T5 cache 预填充脚本。
4. **VLM 因果注意力可配置化** —— 新增 `vlm_causal_attention` 开关（默认双向，motion-token CE 时开启）。
5. **`grid_sizes` batch size 适配 bug 修复** —— 部分样本被 collate 丢弃时避免 CUDA OOB。
6. **推理时 `action_valid_mask` 透传** —— reserved 维度在推理每步 Euler 后清零。
7. 训练超参/路径/GPU 数等运行配置调整。

---

## 二、新增文件

| 文件 | 说明 | 约行数 |
|------|------|--------|
| `data/droid/droid_lerobot_dataset.py` | DROID (LeRobot v3.0) 数据集适配器，qpos 关节动作，对齐 RoboLab Pi0.5 `pi05_droid_jointpos` | ~700 |
| `data/droid/__init__.py` | 包初始化 | 1 |
| `configs/droid_wan_vlm_mask_stage2_15w.yaml` | DROID 训练配置 | 139 |
| `configs/robotwin_unified_eef_WanVlmMask.yaml` | RoboTwin unified_eef 训练配置 | 130 |
| `scripts/train_ADS_MotusV2_droid.sh` | DROID 训练启动脚本 | 59 |
| `scripts/train_ADS_MotusV2_robotwin_unified_eef.sh` | RoboTwin unified_eef 训练启动脚本 | 49 |
| `scripts/prepopulate_droid_t5_cache.py` | 预填充 DROID T5 文本 embedding 缓存 | 87 |
| `tests/check_xperience_shapes.py` | Xperience 数据形状检查脚本 | 384 |
| `docs/changelog_vs_main.md` | 上一版改动记录（截至 06-24） | 506 |
| `docs/DROID_post_training_implementation_notes.md` | DROID post-training 实现笔记 | 393 |
| `docs/session_log_20260626_robotwin_unified_eef_adaptation.md` | RoboTwin unified_eef 适配会话日志 | 650 |
| `CLAUDE.md` | 项目根 Claude Code 指引 | ~126 |
| `.claude/` | Claude Code 配置目录 | — |

---

## 三、删除文件（原版有、新版无）

- `docs/unified_eef_camera_delta_wrist16_checking_goal.md`
- `docs/unified_eef_camera_delta_wrist16_coding_goal.md`

这两个是 unified_eef 的早期规划/检查目标文档，新版中已移除（功能已实现，规划文档不再需要）。

---

## 四、实质修改的代码文件

### 1. `models/motus_wan_vlm_direct_mask.py`（核心模型，+90 行）

- **新增 `vlm_causal_attention: bool = False` 配置项**：控制 MoT 循环中 VLM 自注意力方向。默认 `False`=双向（legacy，用于 robotwin finetune 及无 motion-token CE 的场景）；`True`=因果下三角（motion-token CE loss 激活时必需，用于自回归 next-token 预测）。原来硬编码为因果。
- **`_runtime_grid_sizes(batch_size)` 新方法**：`self.grid_sizes` 在 init 时按 `config.batch_size` 预计算，但 `collate_fn` 会丢弃 `None` 样本（如 Xperience 重试耗尽的 episode），导致运行时 batch size `B` 可能小于预计算值，`rope_apply` 索引越界触发 CUDA `IndexKernel` assert。修复为 `self.grid_sizes[:1].expand(batch_size, -1)`。`apply_output_head` 和 `process_joint_attention` 两处调用都改用此方法。
- **`inference_step` 新增 `action_valid_mask` 参数**：传入 `[B, T, D]` per-dim 有效性掩码，在初始化 `action_latent` 和每个 Euler 步后将 reserved/padding 维度（如 unified_eef 的 dim 7/15）清零，使推理输出与训练（输入和目标都对这些维清零）一致。
- mask 打印日志根据模式动态显示 `causal-VLM` / `bidirectional-VLM`。

### 2. `data/human/unified_eef_action.py`（+306 行，纯新增函数）

原版只有人类双手（无 gripper）变体。新版追加**机器人带 gripper 变体**：

- 常量 `UNIFIED_EEF_ROBOT_EFFECTIVE_INDICES = [0:7]+[8:15]`、`UNIFIED_EEF_ROBOT_RESERVED_INDICES = [7, 15]`（机器人 dim 6/14 是 gripper，dim 7/15 仍 reserved）。
- `compute_camera_delta_action_with_gripper()` —— 单臂 8D 动作，dim 6=gripper（目标值），dim 7=0。
- `compute_unified_eef_action_16d_with_gripper()` —— 双手 16D + 16D mask。
- `compute_unified_eef_state_16d_with_gripper()` —— 当前位姿状态。
- `compute_unified_eef_action_sequence_with_gripper()` —— **anchor-based** 序列：`action[i] = delta(pose[0] -> pose[i+1])`，gripper 取目标帧值。
- `compute_unified_eef_state_from_poses_with_gripper()` —— 单帧状态包装。

### 3. `data/robotwin2/robotwin_agilex_dataset.py`（+236 行）

- 导入 unified_eef 相关函数。
- `MinMaxNormalizer` 支持 `unified_eef_camera_delta_wrist16` 模式（读 `unified_eef_min/max` 统计量）。
- `action_mode` 校验从 `assert` 改为 `ValueError`，新增 `unified_eef_camera_delta_wrist16`；`action_dim` 对 eepos 和 unified_eef 都设 16。
- episode_data 的 key：unified_eef 模式下原始数据是 eepos，故 key 固定为 `eepos_path`（原来用 `f'{self.action_mode}_path'` 会出错）。验证集划分 key 也改为 `eepos_path`/`qpos_path` 回退。
- 新增 `_load_raw_eepos()`：支持 local / OBS 读取 eepos `.pt`。
- 新增**固定头部相机外参** `_HEAD_CAMERA_R_W_C` / `_HEAD_CAMERA_T_W_C`（从 HDF5 `head_camera/extrinsic_cv` 验证，所有 episode 一致），及 `_get_head_camera_extrinsics()`。
- 新增 `_extract_unified_eef_action_state()`：把 eepos（xyz+quat_wxyz+gripper）转为 camera-delta 动作序列 + state + per-dim mask。
- `__getitem__`：unified_eef 模式走新转换路径并跳过 min-max 归一化；结果 dict 新增 `action_valid_mask`。

### 4. `data/dataset.py`（+28 行）

- 在 `DATASET_REGISTRY` 注册 `"droid": _droid`。
- 新增 `_droid()` builder：拷贝 `dataset_dir`、`instruction_field`、`exterior_camera_key`、`wrist_camera_key`、`camera_layout`、`t5_*` 等 key，构造 `DroidLeRobotDataset`。

### 5. `train/train_wan_vlm_mask.py`（+28 行）

- 维度推导：robotwin 下 `unified_eef_camera_delta_wrist16` 和 `eepos` 都设 dim=16；新增 `droid` 分支设 action_dim/state_dim=8（7 panda 关节 + 1 gripper）。
- 模型构造透传 `vlm_causal_attention` 配置；新增日志行。
- reserved 维度检查：robotwin 数据 reserved 是 `[7]`/`[15]`（单维，gripper 旁），其它（人类）数据仍是 `[6:8]`/`[14:16]`；robotwin 时额外打印左右 gripper 范围/均值。

### 6. `train/sample.py`（+15 行）

- 推理路径从 batch 取 `action_valid_mask`，移到 device 后透传给 `model.inference_step(...)`，使验证指标的 `action_l2_error` 不被未学习的 padding 维主导。

### 7. `tests/test_unified_eef_action.py`（+36 行）

- `test_action_sequence_shape` 增强为 **anchor-based 语义验证**：构造已知平移序列，断言 `action[i] = pose[0]->pose[i+1]`（而非 step 模式 `pose[i]->pose[i+1]`），并验证旋转分量为 0。

---

## 五、实质修改的配置/脚本

| 文件 | 改动 |
|------|------|
| `configs/robotwin_wan_vlm_mask_stage2_15w.yaml` | `storage_mode`/`obs_base_path` 注释掉（改本地）；`data_mode: both→clean`；`max_steps: 120000→80000`；`save_interval: 20000→10000`；checkpoint/tensorboard 目录改名加 `pretrained_12w`；`finetune.checkpoint_path` 指向预训练 ckpt |
| `configs/robotwin_eepos_WanVlmMask_motion_token_on.yaml` | 新增 `vlm_causal_attention: true`（motion-token CE 激活时必需） |
| `scripts/train_ADS_MotusV2_cross_unified_eef_wrist16_xperience10m.sh` | `NPROC_PER_NODE` 默认从 2 改回 8（恢复全卡训练），注释掉手动 `CUDA_VISIBLE_DEVICES` |
| `configs/robotwin_wan_vlm_mask_stage2_reweight_posttrain.yaml` | 仅末尾换行 |
| `scripts/train_ADS_MotusV2_robotwin_reweight_posttrain.sh` | 仅末尾换行 |
| `scripts/train_ADS_MotusV2_robotwin.sh` | 仅末尾换行 |
| `configs/motusv1_adapted/cross_dataset_mixed_unified_eef_wrist16_xperience10m.yaml` | 仅末尾换行 |
| `configs/motusv1_adapted/cross_dataset_mixed_wrist16.yaml` | 仅末尾换行 |
| `data/xperience/__init__.py` | 删除一个空行（原版多一空行） |
| `docs/RoboLab/260629_pi05_robolab_inference_config_for_training.md` | 仅末尾换行 |
| `docs/session_log_20260624_01_..._code_review_for_claude.md` | 仅末尾换行（2 行差异） |

---

## 六、要点与注意

- **`vlm_causal_attention` 行为变化（破坏性）**：原版模型中 VLM 自注意力**硬编码为因果**；新版默认改为**双向**，仅在显式配置 `vlm_causal_attention: true`（如 motion-token-on 配置）时才因果。这是行为层面的破坏性变化 —— 任何未设此项的旧配置在数学上与原版不同。若要复现原版行为，需在配置里显式加上 `vlm_causal_attention: true`。
- **`grid_sizes` 修复**对应 memory 中已记录的 `grid-sizes-batch-size-bug`：collate 丢弃 `None` 样本导致运行时 batch size 小于 `config.batch_size`，原 `self.grid_sizes` 索引在 `rope_apply` 越界触发 CUDA `IndexKernel` assert。
- **anchor-based 动作语义**：unified_eef 序列以 frame 0 为锚，`action[i] = delta(pose[0] -> pose[i+1])`，gripper 取目标帧值；与逐帧 step 模式不同，单测已覆盖。
- **DROID 维度**：action_dim/state_dim=8（7 panda 关节 + 1 gripper），对齐 RoboLab Pi0.5 `pi05_droid_jointpos`。
- `t5_cache_droid/`、`t5_cache_xperience/`、`outputs/`、`xperience_shape_report.json` 为运行时产物，未纳入对比。

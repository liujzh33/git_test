# MotusV2 相对原版 (MotusV2-main) 的改动记录

> 生成时间：2026-07-09
> 对比方式：`diff -rq MotusV2-main MotusV2`（已过滤 `__pycache__` 等噪声）
> 基线：`/home/ma-user/work/wx1469573/MotusV2-main`（原版项目文件）
> 目标：`/home/ma-user/work/wx1469573/MotusV2`（当前工作目录）
>
> 审查与订正（2026-07-09）：本文件已按当前仓库实际状态订正了 4 处路径漂移（见下方注记）；逐项审查结论见 [review_20260709.md](review_20260709.md)。同日另做了一次目录整理：`docs/` 按主题拆分为 `session_logs/ notes/ eval_results/ reference/`，`CLAUDE.md` 移至仓库根，部分 config 由 CamelCase 统一为 snake_case（`robotwin_eepos_WanVlmMask*` → `robotwin_eepos_wan_vlm_mask*`，`robotwin_unified_eef_WanVlmMask` → `robotwin_unified_eef_wan_vlm_mask`，`_vitra_human_mixed_` → `vitra_human_mixed_base`），相关训练脚本引用已同步更新。

本次对比共发现 **19 处改动**（含纯新增文件/目录 9 项，修改文件 7 项，项目元数据 2 项，新增数据集文档 1 目录）。改动围绕三条主线：

1. **DROID 相机布局重构** —— 由 2 路垂直/水平拼接改为 **3 路 T 字形拼接**，并将 `video_height` 由 384 降至 288（黑边从 ~29.7% 降至 6.25%）。
2. **新增 G1-D（Unitree G1 Dex1）数据集支持** —— 新增 `data/g1d/` 模块、配置、训练脚本与 T5 缓存预热脚本。
3. **Xperience 数据集索引日志收敛** —— 将逐文件 WARNING 汇总为单行 INFO，并细化跳过原因计数。

---

## 一、改动总表

| # | 路径 | 类型 | 一句话摘要 |
|---|------|------|-----------|
| 1 | `CLAUDE.md` | 新增 | 项目级 Claude Code 指引文档（架构、命令、不变量） |
| 2 | `.claude/` | 新增 | Claude Code 会话/权限/记忆配置目录（注：本 checkout 未包含此目录） |
| 3 | `configs/droid_wan_vlm_mask_stage2_15w.yaml` | 修改 | DROID：相机布局 `horizontal→t_shape`，`video_height 384→288`，注释重写 |
| 4 | `configs/g1d_pick_kettle_wan_vlm_mask.yaml` | 新增 | G1-D pick-kettle 训练配置（16 维 qpos，T 字形，finetune） |
| 5 | `configs/motusv1_adapted/cross_dataset_mixed_unified_eef_wrist16_xperience10m.yaml` | 修改 | `gradient_checkpointing true→false`，`batch_size 16→8` |
| 6 | `data/dataset.py` | 修改 | 注册 `g1d` 数据集类型，新增 `_g1d()` 构建函数 |
| 7 | `data/droid/droid_lerobot_dataset.py` | 修改 | 实现 T 字形 3 路拼接（`_stitch_t_shape` / `_decode_raw_frames`），保留旧布局 |
| 8 | `data/g1d/__init__.py` | 新增 | G1-D 模块导出 |
| 9 | `data/g1d/g1d_dataset.py` | 新增 | `G1DLeRobotDataset`：LeRobot v3.0 + AV1/PyAV + T5 磁盘缓存 + T 字形拼接 |
| 10 | `data/xperience/xperience_dataset.py` | 修改 | 跳过原因计数前置 + 单行汇总日志；`KeyError`/`too_short` 分类统计 |
| 11 | `docs/session_logs/session_log_20260709_droid_visual_review.md` | 新增 | DROID 画面处理对话回顾与变更记录（整理后位于 `session_logs/`） |
| 12 | `docs/DataReadme/` | 新增 | 数据集说明文档目录（egodex、g1d_pick_kettle）（注：本 checkout 未包含此目录） |
| 13 | `scripts/diag_xperience_align.py` | 新增 | Xperience 相机/手部世界坐标系对齐诊断脚本 |
| 14 | `scripts/diag_xperience_skeleton.py` | 新增 | Xperience cam0 投影约定诊断脚本（骨架投影） |
| 15 | `scripts/prepopulate_g1d_t5_cache.py` | 新增 | 预热 G1-D T5 (UMT5-XXL) 语言嵌入缓存 |
| 16 | `scripts/train_ADS_MotusV2_g1d.sh` | 新增 | G1-D 训练启动脚本 |
| 17 | `scripts/train_ADS_MotusV2_cross_unified_eef_wrist16_xperience10m.sh` | 修改 | 恢复默认 `NPROC_PER_NODE=8`（原注释掉的 2），其余注释微调 |
| 18 | `scripts/train_ADS_MotusV2_robotwin_unified_eef.sh` | 修改 | 仅注释中的 `CUDA_VISIBLE_DEVICES` 设备号微调（4,5,6,7→1,6,7） |
| 19 | `scripts/visualize_unified_eef_samples.py` | 新增 | 可视化各数据集 unified_eef 样本：重建 EEF 轨迹并叠加到视频帧 |

> 注：`bak/wan/`、各模块 `__pycache__/` 等均为运行时生成，已排除，不计入改动。

---

## 二、逐项明细

### 1. `CLAUDE.md`（新增）— 项目指引文档
新增项目级 Claude Code 指引文件，内容涵盖：项目概述（三模态 UniDiffuser）、训练/测试命令、模型/数据/训练/配置模块说明、关键不变量（partial-batch invariant、精度、16 维动作格式、视频规格、学习率分组、`training_mode`）。详见文件本身。

### 2. `.claude/`（新增）— 会话配置
Claude Code 工作目录配置（settings / memory 等），属工具元数据，非模型代码。（注：本 checkout 未包含此目录。）

---

### 3. `configs/droid_wan_vlm_mask_stage2_15w.yaml`（修改）
**核心变更：DROID 相机布局由 2 路改为 3 路 T 字形，分辨率降至 288。**

| 字段 | 原版 (main) | 当前 (V2) |
|------|------------|----------|
| `video_height` | `384` | `288`（=32×9，匹配 T 字形自然高度 270，仅 9px 上下黑边≈6.25%；原 384 黑边≈29.7%） |
| `camera_layout` | `horizontal` | `t_shape` |
| 相机分派 | exterior_1_left + wrist_left（2 路） | top=`exterior_2_left`，bottom_left=`exterior_1_left`，bottom_right=`wrist_left`（3 路） |
| 新增字段 | — | `top_camera_key` / `bottom_left_camera_key` / `bottom_right_camera_key` |
| 注释 | 对齐 RoboLab Pi0.5 客户端（2 路） | 重写为 T 字形 3 路拼接说明，强调“训练与推理必须使用相同 video_height/video_width” |

---

### 4. `configs/g1d_pick_kettle_wan_vlm_mask.yaml`（新增）
G1-D pick-kettle-and-cup 数据集训练配置：
- 数据集：`/cache/wx1469573/data/G1-D/pick-kettle-and-cup`（89 episodes / 72330 frames / 30fps / AV1 / 4 cameras / 单任务）。
- 动作/状态：16 维 qpos（7 左关节 + 7 右关节 + 2 夹爪，绝对量，无归一化）。
- 相机：cam_left_high（顶）+ cam_left_wrist（底左）+ cam_right_wrist（底右），T 字形拼接到 384×320；cam_right_high 未用。
- 语言：`t5_mode=disk_cache`，`t5_cache_dir` 指向数据集目录内 `t5_cache`，`allow_t5_cache_miss_zero=false`（worker 缓存未命中即报错，需先跑预热脚本）。
- 训练：`batch_size=8`，`max_steps=80000`，LR=5e-5，`training_mode=finetune`，`finetune.checkpoint_path` 指向 `multi_source_pretrained`。

### 5. `configs/motusv1_adapted/cross_dataset_mixed_unified_eef_wrist16_xperience10m.yaml`（修改）
| 字段 | 原版 | 当前 |
|------|------|------|
| `gradient_checkpointing` | `true` | `false` |
| `batch_size` | `16` | `8` |

（推测：关闭梯度检查点以提速，配合 batch 下调为 8。）

---

### 6. `data/dataset.py`（修改）
- 在 `DATASET_REGISTRY` 中注册 `"g1d": _g1d`。
- 新增 `_g1d(config, val)` 构建函数：调用 `G1DLeRobotDataset`，复用 `_common_params` / `_copy_dataset_keys` / `_finalize_params`，拷贝 `dataset_dir / max_episodes / t5_mode / t5_cache_dir / t5_text_len / t5_device / allow_t5_cache_miss_zero`，并按惯例传 `image_aug`（验证集关闭）。

### 7. `data/droid/droid_lerobot_dataset.py`（修改）— DROID T 字形重构（本次最大代码改动）
**新增 3 路 T 字形相机拼接路径，保留旧 2 路布局作向后兼容。**

- **模块 docstring** 重写：说明 T 字形布局（top=`exterior_2_left` 全宽，bottom-left=`exterior_1_left` 半宽，bottom-right=`wrist_left` 半宽），单次 resize-pad 最小化黑边。
- **类常量**：新增 `TOP_CAM / BOTTOM_LEFT_CAM / BOTTOM_RIGHT_CAM` 默认相机键。
- **`__init__` 参数**：新增 `top_camera_key / bottom_left_camera_key / bottom_right_camera_key`；`camera_layout` 默认改为 `"t_shape"`，校验集增加 `"t_shape"`。
- **索引逻辑 `_index_episodes`**：按布局选择相机键集合与字段名（`top_video/bottom_left_video/bottom_right_video` 或 `ext_video/wrist_video`），对每路相机独立校验视频存在性与有效性（`_is_valid_video`），任一缺失则跳过该 episode。
- **新增 `_decode_raw_frames`**：按绝对索引从单路相机解码**原生分辨率**帧（不经 resize-pad），供 T 字形拼接直接 resize 进子区域，避免旧实现“先 resize-pad 到 384×320 再二次 resize”的双重 resize（旧路径产生 ~65% 黑边）。
- **新增 `_stitch_t_shape(top_raw, bl_raw, br_raw)`**：保持各相机原生长宽比，顶部全宽、底部左右各半宽，拼成自然高度画布后**垂直 center-pad** 到 `video_height`（须为 32 的倍数且 ≥ 自然高度）。对 DROID 16:9 相机：自然高 270，`video_height=288` ⇒ 上下各 pad 9px（黑边 6.25%）。
- **`__getitem__` 解码分支**：`camera_layout=="t_shape"` 走三路原生解码 + `_stitch_t_shape`；否则走旧 `_decode_stacked_frames` + `_stitch_ext_wrist`。

### 8–9. `data/g1d/__init__.py` + `data/g1d/g1d_dataset.py`（新增）— G1-D 数据集适配器
`G1DLeRobotDataset`（自包含，不依赖 lerobot 运行时）契约：
- 输出 `first_frame [C,H,W]` / `video_frames [T,C,H,W]` / `initial_state [16]` / `action_sequence [chunk,16]` / `language_embedding [S,4096]` / `vlm_inputs` / `task_name`。
- **动作/状态维度重排**：原始 `[L7,R7,LG,RG]`（夹爪在 14/15）→ 训练用 `[L7,LG,R7,RG]`（夹爪紧跟各自手臂，7/15），与 `multi_source_pretrain_dataset.unify_action_to_16` 的 per-arm 结构对齐，利于跨数据集联训。重排索引 `_REORDER_FROM_RAW = [0..6, 14, 7..13, 15]`。
- **相机**：T 字形（cam_left_high 顶 / cam_left_wrist 底左 / cam_right_wrist 底右），cam_right_high 不用；`_stitch_t_shape` 实现。注：G1-D 用的是**旧版 `has_three_cam` 双重 resize 拼接**（固定 50/50、`video_height=384`），**不是** DROID 的保长宽比原生单次 resize / 288 方案，黑边较大但当前有意保留（详见 [review_20260709.md](review_20260709.md) 结论 B2）。
- **视频解码**：`_decode_video_frames_pyav`（PyAV，因 AV1 编码 decord 无法解码）；多 episode 共享同一 mp4，按全局帧索引 `start_frame + offset` 取帧。
- **任务文本**：从 `meta/tasks.parquet`（index=任务文本，列 `task_index`）读取，单任务。
- **T5 语言嵌入**：`disk_cache` 模式按 SHA1(instruction) 缓存到 `t5_cache_dir`；worker 进程缓存未命中默认报错（CUDA fork 限制无法初始化重型 encoder），需先跑 `prepopulate_g1d_t5_cache.py`；`allow_t5_cache_miss_zero=True` 可回退零向量。短中文指令的 encoder 输出会 zero-pad/截断到 `[t5_text_len, 4096]` 以保证缓存形状统一。
- **采样**：与 RoboTwin/DROID 一致的 `_calculate_sampling_indices`；`__len__ = episodes * 10`；`__getitem__` 最多重试 8 次，失败返回 `None`（被 `collate_fn` 丢弃）。

### 10. `data/xperience/xperience_dataset.py`（修改）— 日志收敛
- 跳过原因计数器（`_skipped_no_extrinsics / _skipped_missing_keys / _skipped_too_short / _skipped_other_error` 等）**前置到 `_index_episodes` 之前**，使其可在索引过程中累计。
- 新增 `_skipped_missing_keys`（`KeyError`，如无 SLAM 轨迹的 episode 缺 `slam/*`，属预期比例，静默计数）、`_skipped_too_short`、`_skipped_other_error`（+ 保留最多 3 条样本路径供调试）。
- 索引结束后输出**单行汇总 INFO**（`kept N/total` + 各类跳过数），替代原逐文件 WARNING（多卡训练时刷屏）；`other_error` 样本仍以 WARNING 输出前 3 条。

### 11. `docs/session_logs/session_log_20260709_droid_visual_review.md`（新增）
DROID 画面处理完整对话回顾与决策记录（中文），涵盖：DROID 数据特性、模型 `grid_sizes` 固定约束、黑边来源本质（自然高 270 → 需 pad 到 32 倍数 288）、视觉模型判断黑边不可靠（以像素级逐行全黑统计为准），以及 D1–D8 八项关键决策（T 字形布局、分派、288 分辨率、保持长宽比、原生解码、单数据集训练、推理同分辨率、保留旧布局兼容）。

### 12. `docs/DataReadme/`（新增）
（注：本 checkout 未包含此目录；以下为原始生成环境中的内容说明。）
数据集说明文档目录：
- `egodex_readme.md`（≈39KB）：EgoDex 数据集字段/格式约定（338,234 episodes / 89.5M 帧 / ≈2TB / 1920×1080@30fps）。
- `g1d_pick_kettle_readme.md`（≈26KB）：pick-kettle-and-cup 数据集说明（LeRobot v3.0 / Unitree G1 Dex1 / 89 episodes / 72330 frames / 30Hz）。

### 13. `scripts/diag_xperience_align.py`（新增）
诊断脚本：用 SLAM 相机位姿 + cam0 内参，将 `hand_mocap` 腕部世界坐标投影到 `stereo_left.mp4` 帧，保存标注 PNG，测试多种坐标约定以找出对齐正确者。复用 `data/human/unified_eef_action` 的 `build_camera_world_pose_from_slam` / `quat_wxyz_to_rotmat`。

### 14. `scripts/diag_xperience_skeleton.py`（新增）
诊断脚本：`full_body_mocap/keypoints`（52 关节）已在 cam0 坐标系（z 全负，场景在 backward-z 相机前方），在 4 种符号约定 `(sx,sy)` 下投影骨架到 `stereo_left` 帧，能贴合人体者即为正确投影约定。

### 15. `scripts/prepopulate_g1d_t5_cache.py`（新增）
单进程预热 G1-D T5 (UMT5-XXL) 语言嵌入缓存：从 `meta/tasks.parquet` 收集唯一指令（G1-D 单任务，通常 1 条），逐条编码并写入 `t5_cache_dir`。多 worker 训练前必须运行一次（worker 内缓存未命中会报错）。调用后 `release_global_t5_encoder()` 释放单例。

### 16. `scripts/train_ADS_MotusV2_g1d.sh`（新增）
G1-D 训练启动脚本：`torchrun` + `configs/zero1.json` + `configs/g1d_pick_kettle_wan_vlm_mask.yaml`，默认 `NPROC_PER_NODE=4`、`CUDA_VISIBLE_DEVICES=0,1,2,3`，支持 `--max_steps` 等透传参数（冒烟测试）。

### 17. `scripts/train_ADS_MotusV2_cross_unified_eef_wrist16_xperience10m.sh`（修改）
| 行 | 原版 | 当前 |
|----|------|------|
| NPROC_PER_NODE | 注释掉默认值，硬编码 `=2` | 恢复 `NPROC_PER_NODE=${NPROC_PER_NODE:-8}`（默认 8） |
| 其他 | — | 注释掉的 `=3` 与 `CUDA_VISIBLE_DEVICES=2,3,5` 备注行 |

### 18. `scripts/train_ADS_MotusV2_robotwin_unified_eef.sh`（修改）
仅注释行微调：`CUDA_VISIBLE_DEVICES=4,5,6,7` → `1,6,7`，`NPROC_PER_NODE=4` → `3`（均为注释，非生效配置）。

### 19. `scripts/visualize_unified_eef_samples.py`（新增）
可视化脚本：对 VITRA(×4)、EgoDex、Xperience-10M 各数据集，用真实实验 config 构建数据集（`t5_mode='none'` 跳过 T5），取首帧，调用数据集自身提取方法得到 state/action/action_valid_mask，再从原始逐帧相机位姿+内参+原生视频重建 frame-0 相机系下的手部 EEF 轨迹并投影到每一帧，渲染叠加轨迹 mp4 + 16 维动作/状态侧栏；含数值自检（state+action 重建 vs 原始世界位姿投影，应匹配到 ~1e-5）。

---

## 三、与既有记忆/不变量的关联

- **partial-batch 不变量**：G1-D 与 DROID 的 `__getitem__` 均会在失败时返回 `None`，由 `collate_fn` 丢弃——与新数据集路径一致，未引入违反不变量的代码。
- **`grid_sizes` 固定约束**：DROID `video_height` 由 384 改 288 是“固定 32 倍数分辨率”约束下的合理调整，但**训练与推理必须使用相同 video_height/video_width/camera_layout**（已写入 config 与 docstring 注释）。
- **Xperience z 轴向后**：`diag_xperience_align.py` / `diag_xperience_skeleton.py` 正是对该坐标系约定的诊断工具（骨架 z 全负，场景在 backward-z 相机前方）。

# EgoVerse 数据集详细文档

> **OBS 路径**: `obs://yw-2030-gy/data/opensource/EgoVerse/`
>
> **总大小**: ~1.09 TB (ARIA: 0.59 TB, EVA: 0.50 TB)
>
> **数据格式**: Zarr v3 + MP4 视频
>
> **本文档目的**: 供开发者参考，编写 EgoVerse 数据集的 Dataset 加载脚本。

---

## 1. 顶层目录结构

```
obs://yw-2030-gy/data/opensource/EgoVerse/
├── aria/                              # 人类遥操作数据（佩戴 ARIA 眼镜采集）
│   ├── <timestamp>.mp4                # 2537 个 MP4 视频文件
│   └── <timestamp>.zarr/              # 2538 个 Zarr 目录（含 1 个无对应 MP4 的空 episode）
│
└── eva/                               # 机器人数据（EVA 机器人平台采集）
    ├── <timestamp>.mp4                # 3079 个 MP4 视频文件
    └── <timestamp>.zarr/              # 3079 个 Zarr 目录
```

每个 episode 的命名规则为时间戳格式：

| 子集 | 格式 | 示例 |
|------|------|------|
| ARIA | `YYYY-MM-DD-HH-MM-SS-NNNNNN` | `2025-09-20-17-42-51-000000` |
| EVA  | `YYYY-MM-DD-HH-MM-SS-NNNNNN` | `2025-11-26-21-07-35-274000` |

每个 episode 由一对文件组成：
- `<timestamp>.mp4` — 视频文件（ARIA ~7-9MB, EVA ~2-3MB）
- `<timestamp>.zarr/` — Zarr v3 格式的结构化数据目录

> **注意**: ARIA 子集中有 1 个异常 episode `2025-11-22-23-48-44-123000.zarr`，它没有对应的 MP4 文件，且 `total_frames=0`，embodiment 为 `aria_bimanual`（非标准的 `human_bimanual`），应跳过。

---

## 2. ARIA 子集 — 人类遥操作数据

### 2.1 概述

ARIA 子集记录了人类佩戴 ARIA 智能眼镜进行双手（或单手）操作的数据。数据包含手部姿态、头部姿态、眼动注视等人体追踪信息，以及前向摄像头视频。

| 属性 | 值 |
|------|-----|
| Episode 数量 | 2537（有效的 mp4+zarr 对） |
| 日期范围 | 2025-09-20 至 2026-07-21 |
| FPS | 30 |
| 帧数范围 | 423 ~ 13,294 帧/episode |
| 平均帧数 | ~4,304 帧/episode |
| MP4 平均大小 | ~8 MB |

### 2.2 Embodiment 类型

通过采样 50 个 episode 统计：

| Embodiment | 占比（采样） | 特征 |
|------------|-------------|------|
| `human_bimanual` | ~78% (39/50) | 双手数据，含 left.* 和 right.* |
| `human_right_arm` | ~18% (9/50) | 仅右手数据，仅含 right.* |
| `human_left_arm` | ~4% (2/50) | 仅左手数据，仅含 left.* |

**关键**: 需根据 embodiment 判断哪些 `left.*` / `right.*` 数组存在。

### 2.3 任务类型

采样 50 个 episode 中发现的任务名（实际可能更多）：

| 任务名 | 说明 |
|--------|------|
| `fold_clothes` | 折叠衣物 |
| `fold_clothes_indomain` | 折叠衣物（域内变体） |
| `fold_clothes_success` | 折叠衣物（成功） |
| `cup_on_saucer` | 杯子放碟上 |
| `cup_on_saucer_static_cam` | 杯子放碟上（静态相机） |
| `pick_place` | 抓取放置 |
| `bag_groceries` | 装袋 |
| `bag_groceries_in_domain` | 装袋（域内变体） |
| `bag_groceries_success` | 装袋（成功） |
| `bag_groceries_success_3` | 装袋（成功变体3） |
| `object_in_container` | 物体放入容器 |
| `object_in_container_indomain` | 物体放入容器（域内变体） |
| `scoop_granular` | 舀取颗粒物 |
| `sort` | 分拣 |
| `sort_utensils` | 分拣餐具 |

### 2.4 Zarr 内部结构（human_bimanual 为例）

```
<timestamp>.zarr/
├── zarr.json                                    # 根 group 元数据（含所有特征的 schema 定义）
├── annotations/
│   └── zarr.json                                # 标注数组元数据（shape=[0]，当前为空）
├── images.front_1/
│   ├── zarr.json                                # 图像数组元数据
│   └── c/0                                      # 图像数据块（单 chunk，所有帧）
├── left.obs_ee_pose/
│   ├── zarr.json
│   └── c/0/0                                    # 左手末端执行器姿态数据块
├── left.obs_wrist_pose/
│   ├── zarr.json
│   └── c/0/0                                    # 左手腕部姿态数据块
├── left.obs_keypoints/
│   ├── zarr.json
│   └── c/0/0                                    # 左手关键点数据块
├── left.obs_aria_keypoints/
│   ├── zarr.json
│   └── c/0/0                                    # 左手 ARIA 关键点数据块
├── right.obs_ee_pose/                           # 同 left.*
├── right.obs_wrist_pose/
├── right.obs_keypoints/
├── right.obs_aria_keypoints/
├── obs_head_pose/
│   ├── zarr.json
│   └── c/0/0                                    # 头部姿态数据块
├── obs_eye_gaze/
│   ├── zarr.json
│   └── c/0/0                                    # 眼动注视数据块
└── obs_rgb_timestamps_ns/
    ├── zarr.json
    └── c/0                                      # RGB 时间戳数据块
```

> **human_right_arm** embodiment 只包含 `right.*` + 公共特征（无 `left.*`）
>
> **human_left_arm** embodiment 只包含 `left.*` + 公共特征（无 `right.*`）

### 2.5 各特征详细说明

| 特征名 | dtype | Shape | 维度说明 | 说明 |
|--------|-------|-------|---------|------|
| `images.front_1` | variable_length_bytes (JPEG) | [N_frames] | 每帧为 JPEG 字节串 | 前向摄像头图像，480×640×3 RGB |
| `left.obs_ee_pose` | float64 | [N, 7] | [x, y, z, qx, qy, qz, qw] | 左手末端执行器位姿（世界坐标系），7D = 3D 位置 + 4D 四元数 |
| `left.obs_wrist_pose` | float64 | [N, 7] | [x, y, z, qx, qy, qz, qw] | 左手腕部位姿（世界坐标系） |
| `left.obs_keypoints` | float64 | [N, 63] | 21×3 (x,y,z) | 左手 21 个关键点的 3D 坐标（世界坐标系） |
| `left.obs_aria_keypoints` | float64 | [N, 63] | 21×3 (x,y,z) | 左手 ARIA 追踪的 21 个关键点 3D 坐标 |
| `right.obs_ee_pose` | float64 | [N, 7] | 同 left | 右手末端执行器位姿 |
| `right.obs_wrist_pose` | float64 | [N, 7] | 同 left | 右手腕部位姿 |
| `right.obs_keypoints` | float64 | [N, 63] | 同 left | 右手关键点 |
| `right.obs_aria_keypoints` | float64 | [N, 63] | 同 left | 右手 ARIA 关键点 |
| `obs_head_pose` | float64 | [N, 7] | [x, y, z, qx, qy, qz, qw] | 头部位姿（世界坐标系） |
| `obs_eye_gaze` | float64 | [N, 3] | [gx, gy, gz/conf] | 眼动注视方向（前2维为方向，第3维可能为置信度/质量指标，范围 0-4） |
| `obs_rgb_timestamps_ns` | int64 | [N] | 纳秒时间戳 | RGB 帧时间戳，间隔 ~33.33ms（对应 30fps） |
| `annotations` | variable_length_bytes | [0] | JSON | 标注数据，当前为空（shape=[0]） |

### 2.6 ARIA 根 zarr.json 元数据结构

```json
{
  "attributes": {
    "embodiment": "human_bimanual",       // 或 "human_right_arm", "human_left_arm"
    "total_frames": 2808,                  // 实际有效帧数
    "fps": 30,
    "task_name": "fold_clothes",
    "task_description": "folding clothes",
    "features": {
      "left.obs_ee_pose": {
        "dtype": "float64", "shape": [7], "names": ["dim_0"]
      },
      "left.obs_wrist_pose": {
        "dtype": "float64", "shape": [7], "names": ["dim_0"]
      },
      "left.obs_aria_keypoints": {
        "dtype": "float64", "shape": [63], "names": ["dim_0"]
      },
      "left.obs_keypoints": {
        "dtype": "float64", "shape": [63], "names": ["dim_0"]
      },
      "right.obs_ee_pose": { "dtype": "float64", "shape": [7], ... },
      "right.obs_wrist_pose": { "dtype": "float64", "shape": [7], ... },
      "right.obs_aria_keypoints": { "dtype": "float64", "shape": [63], ... },
      "right.obs_keypoints": { "dtype": "float64", "shape": [63], ... },
      "obs_head_pose": { "dtype": "float64", "shape": [7], ... },
      "obs_eye_gaze": { "dtype": "float64", "shape": [3], ... },
      "obs_rgb_timestamps_ns": { "dtype": "int64", "shape": [], "names": [] },
      "images.front_1": {
        "dtype": "jpeg", "shape": [480, 640, 3], "names": ["height", "width", "channel"]
      },
      "annotations": {
        "dtype": "json", "shape": [0], "names": ["json"], "format": "annotation_v1"
      }
    },
    "intrinsics": {
      "front_1": [
        [266.50860444, 0.0, 320.0, 0.0],
        [0.0, 266.50860444, 240.0, 0.0],
        [0.0, 0.0, 1.0, 0.0]
      ]
    }
  },
  "zarr_format": 3,
  "node_type": "group"
}
```

### 2.7 数据值示例

#### obs_ee_pose（左手末端位姿，前5帧）
```
[[ 0.067, -0.194, -0.437,  0.517, -0.402, -0.586,  0.478],
 [ 0.066, -0.195, -0.437,  0.516, -0.407, -0.587,  0.472],
 [ 0.066, -0.194, -0.437,  0.513, -0.407, -0.591,  0.471],
 [ 0.066, -0.194, -0.437,  0.514, -0.407, -0.591,  0.470],
 [ 0.066, -0.195, -0.437,  0.512, -0.404, -0.593,  0.473]]
```
- 前3维为位置（米），范围约 [-0.3, 0.25] × [-0.4, 0] × [-0.7, 0.01]
- 后4维为四元数（xyzw 格式），范数 ≈ 1

#### obs_keypoints（左手21关键点，第一帧，reshape 为 21×3）
```
[[ 0.132, -0.184, -0.440],   # 关键点 0
 [ 0.104, -0.160, -0.450],   # 关键点 1
 ...
 [ 0.008, -0.258, -0.467]]   # 关键点 20
```
- 21 个关键点覆盖手掌、拇指、食指、中指、无名指、小指
- 坐标为世界坐标系下的 3D 位置

#### obs_eye_gaze（前5帧）
```
[[ 0.037, -0.542,  0.786],
 [ 0.037, -0.542,  0.786],
 ...]
```
- 前两维为注视方向向量，第三维可能为置信度/质量（0-4）

#### obs_rgb_timestamps_ns（前10帧）
```
[2821467145112, 2821500472450, 2821533799787, 2821567127075,
 2821600458162, 2821633785487, 2821667112787, 2821700440112,
 2821733767450, 2821767098487]
```
- 纳秒级时间戳，平均间隔 33.33ms（30fps）

---

## 3. EVA 子集 — 机器人数据

### 3.1 概览

EVA 子集记录了 EVA 双臂机器人执行操作任务的数据。包含机器人关节角、末端位姿、夹爪状态等观测和控制指令，以及多个摄像头视频。

| 属性 | 值 |
|------|-----|
| Episode 数量 | 3079 |
| 日期范围 | 2025-11-26 至 2026-06-16 |
| FPS | 30 |
| 帧数范围 | 290 ~ 3,000 帧/episode |
| 平均帧数 | ~1,104 帧/episode |
| MP4 平均大小 | ~2.7 MB |

### 3.2 Embodiment 类型

| Embodiment | 占比（采样） | 特征 |
|------------|-------------|------|
| `eva_bimanual` | ~94% (47/50) | 双臂数据，含 left.* 和 right.* |
| `eva_right_arm` | ~6% (3/50) | 仅右臂数据，仅含 right.* |

### 3.3 任务类型

| 任务名 | 说明 |
|--------|------|
| `cup_on_saucer` | 杯子放碟上 |
| `cup_on_saucer_success` | 杯子放碟上（成功） |
| `cup_on_saucer_success_1` | 杯子放碟上（成功变体1） |
| `cup_on_saucer_failure_1` | 杯子放碟上（失败变体1） |
| `fold_clothes` | 折叠衣物 |
| `fold_clothes_success_1` | 折叠衣物（成功变体1） |
| `pick_place` | 抓取放置 |
| `bag_groceries` | 装袋 |
| `bag_groceries_success` | 装袋（成功） |
| `object_in_container` | 物体放入容器 |

### 3.4 Zarr 内部结构（eva_bimanual 为例）

```
<timestamp>.zarr/
├── zarr.json                                    # 根 group 元数据
├── annotations/
│   └── zarr.json                                # 标注元数据（当前为空）
├── images.front_1/
│   ├── zarr.json
│   └── c/0                                      # 前置相机图像（JPEG）
├── images.left_wrist/
│   ├── zarr.json
│   └── c/0                                      # 左手腕相机图像（JPEG）
├── images.right_wrist/
│   ├── zarr.json
│   └── c/0                                      # 右手腕相机图像（JPEG）
├── left.obs_ee_pose/
│   ├── zarr.json
│   └── c/0/0                                    # 左臂末端观测位姿
├── left.cmd_ee_pose/
│   ├── zarr.json
│   └── c/0/0                                    # 左臂末端指令位姿
├── left.obs_joints/
│   ├── zarr.json
│   └── c/0/0                                    # 左臂观测关节角
├── left.cmd_joints/
│   ├── zarr.json
│   └── c/0/0                                    # 左臂指令关节角
├── left.obs_gripper/
│   ├── zarr.json
│   └── c/0/0                                    # 左夹爪观测状态
├── left.cmd_gripper/
│   ├── zarr.json
│   └── c/0/0                                    # 左夹爪指令状态
├── right.obs_ee_pose/                           # 同 left.*
├── right.cmd_ee_pose/
├── right.obs_joints/
├── right.cmd_joints/
├── right.obs_gripper/
└── right.cmd_gripper/
```

> **eva_right_arm** embodiment 只包含 `right.*` 特征（无 `left.*`），但包含全部 3 个图像流。

### 3.5 各特征详细说明

| 特征名 | dtype | Shape | 维度说明 | 说明 |
|--------|-------|-------|---------|------|
| `images.front_1` | variable_length_bytes (JPEG) | [N_frames] | 每帧 JPEG 字节串 | 前置相机，480×640×3 RGB |
| `images.left_wrist` | variable_length_bytes (JPEG) | [N_frames] | 每帧 JPEG 字节串 | 左手腕相机，480×640×3 RGB |
| `images.right_wrist` | variable_length_bytes (JPEG) | [N_frames] | 每帧 JPEG 字节串 | 右手腕相机，480×640×3 RGB |
| `left.obs_ee_pose` | float64 | [N, 7] | [x, y, z, qx, qy, qz, qw] | 左臂末端观测位姿 |
| `left.cmd_ee_pose` | float64 | [N, 7] | [x, y, z, qx, qy, qz, qw] | 左臂末端指令位姿 |
| `left.obs_joints` | float32 | [N, 6] | 6-DOF 关节角 | 左臂观测关节角度（弧度） |
| `left.cmd_joints` | float32 | [N, 6] | 6-DOF 关节角 | 左臂指令关节角度 |
| `left.obs_gripper` | float32 | [N, 1] | [gripper_position] | 左夹爪观测状态，范围 0~1（0=闭合, 1=张开） |
| `left.cmd_gripper` | float32 | [N, 1] | [gripper_position] | 左夹爪指令状态，范围 0~1 |
| `right.*` | 同 left | 同 left | 同 left | 右臂对应数据 |
| `annotations` | variable_length_bytes | [0] | JSON | 标注数据，当前为空 |

### 3.6 EVA 根 zarr.json 元数据结构

```json
{
  "attributes": {
    "embodiment": "eva_bimanual",
    "total_frames": 1408,
    "fps": 30,
    "task_name": "bag_groceries",
    "task_description": "pick up the bag and make it upright, place the objects into the bag",
    "features": {
      "right.obs_ee_pose":    { "dtype": "float64", "shape": [7], ... },
      "right.cmd_ee_pose":    { "dtype": "float64", "shape": [7], ... },
      "right.obs_joints":     { "dtype": "float32", "shape": [6], ... },
      "right.obs_gripper":    { "dtype": "float32", "shape": [1], ... },
      "right.cmd_joints":     { "dtype": "float32", "shape": [6], ... },
      "right.cmd_gripper":    { "dtype": "float32", "shape": [1], ... },
      "left.*":               { ... },  // bimanual 时存在
      "images.front_1":       { "dtype": "jpeg", "shape": [480, 640, 3], ... },
      "images.left_wrist":    { "dtype": "jpeg", "shape": [480, 640, 3], ... },
      "images.right_wrist":   { "dtype": "jpeg", "shape": [480, 640, 3], ... },
      "annotations":          { "dtype": "json", "shape": [0], "format": "annotation_v1" }
    },
    "intrinsics": {
      "front_1": [
        [266.50860444, 0.0, 320.0, 0.0],
        [0.0, 266.50860444, 240.0, 0.0],
        [0.0, 0.0, 1.0, 0.0]
      ]
    },
    "extrinsics": {
      "left":  [[...4×4 SE(3) 矩阵...]],   // 左手腕相机外参
      "right": [[...4×4 SE(3) 矩阵...]]     // 右手腕相机外参
    }
  },
  "zarr_format": 3,
  "node_type": "group"
}
```

### 3.7 数据值示例

#### right.obs_ee_pose（第一个 EVA episode 的前5帧）
```
[[ 0.0,  0.0,  0.0, -0.5,  0.5, -0.5,  0.5],
 [ 0.0,  0.0,  0.0, -0.5,  0.5, -0.5,  0.5],
 ...]
```
> 注意：某些 episode 的前若干帧可能为零填充（padding），有效帧数由 `total_frames` 指定，zarr shape 可能大于 `total_frames`。

#### right.obs_ee_pose（bimanual episode，有效帧）
```
Min: [ 0.088, -0.077,  0.155, -0.618, -0.508, -0.648, -0.609]
Max: [ 0.454,  0.335,  0.541,  0.712,  0.575,  0.610,  0.898]
```
- 位置单位为米，范围约 [0, 0.5] × [-0.1, 0.3] × [0.15, 0.5]
- 四元数范数 ≈ 1

#### right.obs_joints（bimanual episode，有效帧）
```
Min: [-0.350,  0.020,  0.012, -1.161, -0.224, -0.151]
Max: [ 1.267,  2.286,  2.144,  0.305,  0.825,  1.253]
```
- 6-DOF 关节角度（弧度），范围约 [-1.3, 2.3]

#### right.obs_gripper / right.cmd_gripper
```
obs_gripper: Min=0.0001, Max=1.0   (范围 0~1, 0=闭合, 1=张开)
cmd_gripper: Min=0.163,  Max=1.0
```

#### obs vs cmd 差异
- `obs_ee_pose` 与 `cmd_ee_pose` 在初始帧相同，之后有差异（cmd 为目标位姿，obs 为实际位姿）
- `obs_joints` 与 `cmd_joints` 类似
- `obs_gripper` 与 `cmd_gripper` 可能有较多 NaN（某些帧无指令）

---

## 4. Zarr v3 格式技术细节

### 4.1 Zarr v3 存储规范

所有数组使用 **Zarr v3** 格式（`zarr_format: 3`），采用 **sharding_indexed** 编解码器：

| 组件 | 说明 |
|------|------|
| `chunk_grid` | `regular` — 规则分块 |
| `chunk_key_encoding` | `default` — 分隔符 `/` |
| `codecs` | `sharding_indexed` — 分片索引编码 |
| 内部编码 | 数值数据: `bytes`(little-endian) + `zstd`(level=0)；图像: `vlen-bytes` + `zstd` |
| `index_codecs` | `bytes`(little-endian) + `crc32c` |
| `index_location` | `end` — 索引位于分片末尾 |
| `fill_value` | 数值: 0.0 / 0；字节: "" |

### 4.2 分块策略

| 数据类型 | Chunk Shape | 分片子块 Shape | 说明 |
|----------|------------|---------------|------|
| 数值数组 (ee_pose, joints 等) | [N_total, D] | [100, D] | 每 100 帧一个子块 |
| 时间戳 (timestamps) | [N_total] | [100] | 每 100 帧一个子块 |
| 图像 (images) | [N_total] | [1] | 每帧一个子块（单帧 JPEG） |
| 标注 (annotations) | [0] | [1] | 空数组 |

### 4.3 数据文件路径规则

Zarr v3 的数据文件路径遵循 `c/{chunk_index}/{sub_chunk_index}` 格式：

- **2D 数组** (如 `[2900, 7]`): `c/0/0`（单一 chunk，单一子块）
- **1D 数组** (如 `[2900]`): `c/0`（单一 chunk）
- **图像数组** (如 `[2900]` with shard per-frame): `c/0`（单一 chunk，内含所有帧的 JPEG 分片）

### 4.4 图像数据读取方式

图像以 `variable_length_bytes` 存储，每帧为一个 JPEG 字节串。

**使用 zarr Python 库读取**:
```python
import zarr
from PIL import Image
import io

# 打开图像数组
z = zarr.open("/path/to/episode.zarr/images.front_1", mode='r')
# 读取单帧 — 返回 0-d numpy object array
img_bytes = z[:1][0]  # bytes 对象，直接可用
# 或: img_bytes = z[0].item()  # 需进一步解包嵌套 array
img = Image.open(io.BytesIO(img_bytes))
# img.size = (640, 480), img.mode = "RGB"
```

> **注意**: `z[0]` 返回嵌套的 numpy object array（0-d），需要用 `z[:1][0]` 或多层 `.item()` 解包获取原始 bytes。

---

## 5. 数据访问方法

### 5.1 通过 moxing 访问 OBS

```python
import os
os.environ['S3_ENDPOINT'] = '10.170.30.79:80'
os.environ['S3_USE_HTTPS'] = '0'
os.environ['ACCESS_KEY_ID'] = 'l00609438'
os.environ['SECRET_ACCESS_KEY'] = '9c24d3232bb14e188ca6e1757f7af470'

import moxing as mox

base = 'obs://yw-2030-gy/data/opensource/EgoVerse'

# 列举顶层目录（非递归）
items = mox.file.list_directory(f"{base}/aria")  # 返回 list of str

# 递归列举 zarr 内部
zarr_items = mox.file.list_directory(
    f"{base}/aria/2025-09-20-17-42-51-000000.zarr",
    recursive=True
)

# 判断是否为目录
mox.file.is_directory(f"{base}/aria/2025-09-20-17-42-51-000000.zarr")  # True

# 获取文件大小
mox.file.get_size(f"{base}/aria/2025-09-20-17-42-51-000000.mp4")  # bytes

# 递归获取目录总大小
mox.file.get_size(f"{base}/aria", recursive=True)  # bytes

# 下载单个文件到本地
mox.file.copy(
    f"{base}/aria/2025-09-20-17-42-51-000000.zarr/zarr.json",
    "/tmp/episode_root_zarr.json"
)

# 下载整个目录到本地
mox.file.copy_parallel(
    f"{base}/aria/2025-09-20-17-42-51-000000.zarr",
    "/tmp/local_episode.zarr"
)

# 判断文件/目录是否存在
mox.file.exists(f"{base}/aria/2025-09-20-17-42-51-000000.mp4")  # True
```

### 5.2 使用 zarr Python 库读取本地 Zarr

```python
import zarr
import numpy as np

# 打开 episode 的 zarr group
root = zarr.open("/tmp/local_episode.zarr", mode='r')

# 读取根元数据
import json
with open("/tmp/local_episode.zarr/zarr.json") as f:
    meta = json.load(f)
attrs = meta["attributes"]
embodiment = attrs["embodiment"]    # "human_bimanual" / "eva_bimanual" 等
task_name = attrs["task_name"]      # "fold_clothes" 等
total_frames = attrs["total_frames"]  # 实际有效帧数
fps = attrs["fps"]                  # 30

# 读取数值数组
ee_pose = zarr.open("/tmp/local_episode.zarr/left.obs_ee_pose", mode='r')
data = ee_pose[:]  # numpy array, shape (N, 7), dtype float64

# 读取图像数组
img_array = zarr.open("/tmp/local_episode.zarr/images.front_1", mode='r')
# 读取单帧 JPEG bytes
img_bytes = img_array[:1][0]  # bytes 对象
from PIL import Image
import io
img = Image.open(io.BytesIO(img_bytes))  # PIL Image, 640x480 RGB
```

### 5.3 推荐的 Episode 遍历策略

```python
import moxing as mox
import json

base = 'obs://yw-2030-gy/data/opensource/EgoVerse'

def list_episodes(subset="aria"):
    """列举所有有效 episode，返回 (episode_name, has_mp4, has_zarr) 列表"""
    items = mox.file.list_directory(f"{base}/{subset}")
    mp4_set = {x.replace('.mp4', '') for x in items if x.endswith('.mp4')}
    zarr_set = {x.replace('.zarr', '') for x in items if x.endswith('.zarr')}
    
    episodes = []
    for name in sorted(mp4_set & zarr_set):
        episodes.append(name)
    return episodes

def get_episode_metadata(subset, episode_name):
    """下载并解析 episode 的根 zarr.json 元数据"""
    zarr_path = f"{base}/{subset}/{episode_name}.zarr"
    tmp_path = f"/tmp/meta_{subset}_{episode_name}.json"
    mox.file.copy(f"{zarr_path}/zarr.json", tmp_path)
    with open(tmp_path) as f:
        meta = json.load(f)
    os.remove(tmp_path)
    return meta["attributes"]

def get_features(subset, episode_name):
    """获取 episode 的特征列表"""
    attrs = get_episode_metadata(subset, episode_name)
    return list(attrs.get("features", {}).keys())
```

---

## 6. 数据关键注意事项

### 6.1 帧数 vs Zarr Shape

Zarr 数组的 shape 的第 0 维可能大于 `total_frames`。例如某 EVA episode 的 `total_frames=1810`，但 zarr shape 为 `[1900, 7]`。多出的帧为零填充（fill_value=0）。

**处理方式**: 只使用前 `total_frames` 帧的数据。

### 6.2 Embodiment 决定可用特征

不同 embodiment 的 episode 包含不同的特征集。**必须先读取根 zarr.json 的 `embodiment` 字段和 `features` 字典**，判断哪些特征存在：

| Embodiment | 包含的特征 |
|------------|-----------|
| `human_bimanual` | left.*, right.*, obs_head_pose, obs_eye_gaze, obs_rgb_timestamps_ns, images.front_1, annotations |
| `human_right_arm` | right.*, obs_head_pose, obs_eye_gaze, obs_rgb_timestamps_ns, images.front_1, annotations |
| `human_left_arm` | left.*, obs_head_pose, obs_eye_gaze, obs_rgb_timestamps_ns, images.front_1, annotations |
| `eva_bimanual` | left.*, right.*, images.front_1, images.left_wrist, images.right_wrist, annotations |
| `eva_right_arm` | right.*, images.front_1, images.left_wrist, images.right_wrist, annotations |

### 6.3 NaN 值

- EVA 数据的 `obs_gripper` / `cmd_gripper` 中可能出现 NaN（部分帧无有效数据）
- EVA 数据的 `cmd_joints` / `cmd_gripper` 可能比 `obs_*` 有更多的零或 NaN（仅在有指令的帧有值）
- ARIA 数据中未发现 NaN

### 6.4 ARIA vs EVA 的本质区别

| 方面 | ARIA | EVA |
|------|------|-----|
| 数据来源 | 人类遥操作（ARIA 眼镜） | EVA 机器人 |
| 动作数据 | **无 cmd/action** — 仅观测 | 有 obs（观测）和 cmd（指令） |
| 相机 | 1 个（前向 front_1） | 3 个（front_1 + left_wrist + right_wrist） |
| 手部表示 | 关键点(63D) + 腕位姿(7D) + EE位姿(7D) | 关节角(6D) + EE位姿(7D) + 夹爪(1D) |
| 相机标定 | 仅 intrinsics | intrinsics + extrinsics |
| 用途 | 人类手部追踪 -> 需重定向到机器人动作空间 | 直接可用作机器人动作数据 |

### 6.5 异常 Episode

- ARIA 子集中的 `2025-11-22-23-48-44-123000.zarr`：无对应 MP4，`total_frames=0`，embodiment 为 `aria_bimanual`（非标准），应跳过。

---

## 7. 与 MotusV2 现有代码的对接参考

### 7.1 现有 Dataset 注册机制

MotusV2 使用注册表模式管理数据集（`data/dataset.py`）:

```python
DATASET_REGISTRY = {
    "robotwin": _robotwin,
    "multi_source_pretrain": _multi_source_pretrain,
    "latent_action": _latent_action,
    "lerobot": _lerobot,
    "droid": _droid,
    "g1d": _g1d,
    "g1d_ego_mixed": _g1d_ego_mixed,
    "vitra_human": _vitra_human,
    "vitra_human_mixed": _vitra_human_mixed,
    "vitra_robot_mixed": _vitra_robot_mixed,
    "wiyh": _wiyh,
    "egodex": _egodex,
    "cross_dataset_mixed": _cross_dataset_mixed,
}
```

新增 EgoVerse 数据集需要：
1. 在 `data/` 下创建 `egoverse/egoverse_dataset.py`
2. 实现 `EgoVerseDataset` 类，返回标准 sample 格式
3. 在 `data/dataset.py` 中注册

### 7.2 标准 Sample 输出格式

所有 MotusV2 数据集的 `__getitem__` 返回以下 dict：

```python
{
    "first_frame": torch.Tensor,          # [3, H, W] float32, 视频第一帧
    "video_frames": torch.Tensor,         # [F, 3, H, W] float32, 后续视频帧
    "initial_state": torch.Tensor,        # [D_state] float32, 初始状态
    "action_sequence": torch.Tensor,      # [F, D_action] float32, 动作序列
    "language_embedding": torch.Tensor,   # [seq_len, 4096] float32, T5 文本嵌入
    "vlm_inputs": dict or None,           # VLM 输入（Qwen3-VL）
    "action_valid_mask": torch.Tensor,    # [F, D_action] bool, 动作有效性掩码
}
```

### 7.3 动作维度统一

MotusV2 使用 16 维统一动作格式：

```
[left_joints(6), pad(1), left_gripper(1), right_joints(6), pad(1), right_gripper(1)]
```

**EVA 数据映射**:
- `right.cmd_joints` (6D) + `right.cmd_gripper` (1D) → 右臂 7D
- `left.cmd_joints` (6D) + `left.cmd_gripper` (1D) → 左臂 7D
- 拼接并 pad 到 16D

**ARIA 数据映射**:
- ARIA 仅有人类手部观测数据，无 cmd/action
- 需要类似 EgoDex 的重定向流程（将人类手部姿态映射到机器人动作空间）
- 可参考 `data/ego/ego_dataset.py` 的 `EgoRetargetDataset` 模式
- 或参考 `data/egodex/egodex_dataset.py` 的 wrist / unified_eef 模式

### 7.4 视频帧加载

MotusV2 标准视频参数：
- `video_size`: (384, 320) — 高 × 宽
- `num_video_frames`: 8 — 预测帧数
- EgoVerse 图像原始尺寸: 480 × 640，需要 resize/padding 到 384 × 320

两种视频源：
1. **MP4 文件**: 可使用 `data/utils/image_utils.py` 中的 `load_video_frames()` 按帧索引解码
2. **Zarr images**: JPEG 字节串，需用 PIL 解码后 resize

### 7.5 T5 文本嵌入

- `task_description` 字段作为语言指令
- 使用全局共享的 T5 编码器（`data/__init__.py` 的 `get_global_t5_encoder()`）
- 支持 `disk_cache` 模式，将嵌入缓存到磁盘

### 7.6 相似的现有数据集参考

| 现有数据集 | 相似点 | 参考文件 |
|-----------|--------|---------|
| **EgoDex** | 人类手部数据 + MP4，需重定向到机器人动作空间 | `data/egodex/egodex_dataset.py` |
| **EgoRetarget** | 人类 ego 数据重定向到 G1-D 动作空间 | `data/ego/ego_dataset.py` |
| **Xperience** | 机器人数据，有 obs/cmd 分离 | `data/xperience/xperience_dataset.py` |
| **VITRA** | 人类视频数据 + 手部追踪 | `data/human/vitra_dataset.py` |

---

## 8. 快速验证脚本

以下脚本可用于验证数据读取是否正确：

```python
import os
os.environ['S3_ENDPOINT'] = '10.170.30.79:80'
os.environ['S3_USE_HTTPS'] = '0'
os.environ['ACCESS_KEY_ID'] = 'l00609438'
os.environ['SECRET_ACCESS_KEY'] = '9c24d3232bb14e188ca6e1757f7af470'

import moxing as mox
import json
import zarr
import numpy as np
from PIL import Image
import io

base = 'obs://yw-2030-gy/data/opensource/EgoVerse'

# 1. 验证 EVA episode
print("=== EVA bimanual episode ===")
episode = "2026-01-26-20-50-59-558000"
zarr_path = f"{base}/eva/{episode}.zarr"
local_path = f"/tmp/verify_eva.zarr"

# 下载元数据
mox.file.copy(f"{zarr_path}/zarr.json", f"{local_path}/zarr.json")
with open(f"{local_path}/zarr.json") as f:
    attrs = json.load(f)["attributes"]
print(f"  embodiment: {attrs['embodiment']}")
print(f"  task: {attrs['task_name']} — {attrs['task_description']}")
print(f"  total_frames: {attrs['total_frames']}, fps: {attrs['fps']}")
print(f"  features: {list(attrs['features'].keys())}")

# 下载并读取 ee_pose
mox.file.copy(f"{zarr_path}/right.obs_ee_pose/zarr.json", f"{local_path}/right.obs_ee_pose/zarr.json")
mox.file.copy(f"{zarr_path}/right.obs_ee_pose/c/0/0", f"{local_path}/right.obs_ee_pose/c/0/0")
z = zarr.open(f"{local_path}/right.obs_ee_pose", mode='r')
print(f"  right.obs_ee_pose: shape={z.shape}, dtype={z.dtype}")
print(f"  First valid frame: {z[0]}")

# 2. 验证 ARIA episode
print("\n=== ARIA bimanual episode ===")
episode = "2025-09-20-17-42-51-000000"
zarr_path = f"{base}/aria/{episode}.zarr"
local_path = f"/tmp/verify_aria.zarr"

mox.file.copy(f"{zarr_path}/zarr.json", f"{local_path}/zarr.json")
with open(f"{local_path}/zarr.json") as f:
    attrs = json.load(f)["attributes"]
print(f"  embodiment: {attrs['embodiment']}")
print(f"  task: {attrs['task_name']} — {attrs['task_description']}")
print(f"  total_frames: {attrs['total_frames']}, fps: {attrs['fps']}")
print(f"  features: {list(attrs['features'].keys())}")

# 下载并读取 keypoints
mox.file.copy(f"{zarr_path}/left.obs_keypoints/zarr.json", f"{local_path}/left.obs_keypoints/zarr.json")
mox.file.copy(f"{zarr_path}/left.obs_keypoints/c/0/0", f"{local_path}/left.obs_keypoints/c/0/0")
z = zarr.open(f"{local_path}/left.obs_keypoints", mode='r')
print(f"  left.obs_keypoints: shape={z.shape}, dtype={z.dtype}")
print(f"  First frame (21x3): {z[0].reshape(21, 3)[:5]}")  # 前5个关键点
```

---

## 9. 统计汇总

| 指标 | ARIA | EVA | 合计 |
|------|------|-----|------|
| Episode 数量 | 2,537 | 3,079 | 5,616 |
| 总大小 | ~0.59 TB | ~0.50 TB | ~1.09 TB |
| 日期范围 | 2025-09 ~ 2026-07 | 2025-11 ~ 2026-06 | — |
| FPS | 30 | 30 | 30 |
| 平均帧数/episode | ~4,304 | ~1,104 | — |
| Embodiment 类型 | 3 种 | 2 种 | 5 种 |
| 任务类型 | 14+ 种 | 10+ 种 | — |
| 相机数量 | 1 (front_1) | 3 (front_1, left_wrist, right_wrist) | — |
| 动作类型 | 仅观测（无 cmd） | obs + cmd | — |
| 图像分辨率 | 480×640 | 480×640 | 480×640 |
| 图像编码 | JPEG | JPEG | JPEG |
| 数据格式 | Zarr v3 + MP4 | Zarr v3 + MP4 | Zarr v3 + MP4 |

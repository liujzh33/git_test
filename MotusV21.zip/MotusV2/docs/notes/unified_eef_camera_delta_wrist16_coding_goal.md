你好，请帮我在现有 MotusV2 代码库中实现一个新的训练模式，用于在现有 `MotusV2/scripts/train_ADS_MotusV2_cross_relative_wrist16.sh` 基础上，引入新的数据集：

`/cache/wx1469573/data/xperience-10m-clean`

当前已有脚本使用 vitra、egodex 人类数据集进行训练，动作监督信号是手腕相对值：

```text
[left_relative_xyzquat(7), 0, right_relative_xyzquat(7), 0] = 16 dims
```

现在我希望实现一个新的 **Unified EEF Pose / camera-frame relative wrist action** 设定。请注意，这不是简单把 xperience-10m-clean 加到旧的 `relative_wrist16` 训练里，而是新增一个与 Unified EEF Pose 思路一致的动作表示，并让 vitra、egodex、xperience 三个数据集在该训练模式下都输出一致语义的 action label。

## 目标

新增一个训练脚本和配置，使模型使用以下统一动作监督信号：

```text
[left_camera_delta_wrist/eef_action(8), right_camera_delta_wrist/eef_action(8)] = 16 dims
```

每只手 / 每个 wrist-EFF block 的 8 维定义为：

```text
[delta_x_cam, delta_y_cam, delta_z_cam, delta_rx_cam, delta_ry_cam, delta_rz_cam, reserved_0, reserved_1]
```

其中：

* 前 3 维是 reference camera frame 下的相对平移 delta；
* 中间 3 维是 reference camera frame 下的相对旋转 delta，使用 rotation vector / axis-angle log map，而不是 quaternion；
* 最后 2 维保留为 0，用于保持当前 16D action 接口兼容；
* 如果现有 dataloader / model 强依赖原来的 `[xyzquat(7), 0]` 结构，请不要破坏旧逻辑，而是新增 action representation，例如：

  * `relative_wrist16`
  * `unified_eef_camera_delta_wrist16`

旧脚本 `train_ADS_MotusV2_cross_relative_wrist16.sh` 必须保持行为不变。请新增新脚本，例如：

```text
MotusV2/scripts/train_ADS_MotusV2_cross_unified_eef_wrist16_xperience10m.sh
```

并新增对应 config 文件，而不是直接覆盖旧配置。

## Unified EEF Pose 的动作变换定义

对于每个样本、每只手，设：

```text
c      = reference camera frame
e      = 当前 wrist / EEF frame
e*     = 下一帧或目标帧 wrist / EEF frame
R_w_e  = 当前 wrist / EEF 在 world/base frame 下的 rotation
t_w_e  = 当前 wrist / EEF 在 world/base frame 下的位置
R_w_e* = 目标 wrist / EEF 在 world/base frame 下的 rotation
t_w_e* = 目标 wrist / EEF 在 world/base frame 下的位置
R_w_c  = reference camera 在 world/base frame 下的 rotation
```

先计算当前 wrist / EEF 到目标 wrist / EEF 的相对运动：

```text
R_e_e* = R_w_e^T @ R_w_e*
t_e_e* = R_w_e^T @ (t_w_e* - t_w_e)
```

再把这个相对运动投影到 reference camera frame：

```text
R_c_e = R_w_c^T @ R_w_e
R_e_c = R_c_e^T

R_delta_c = R_c_e @ R_e_e* @ R_e_c
t_delta_c = R_c_e @ t_e_e*
```

最终 action 为：

```text
delta_rotvec_c = log_SO3(R_delta_c)

per_arm_action_8d = [
    t_delta_c[0],
    t_delta_c[1],
    t_delta_c[2],
    delta_rotvec_c[0],
    delta_rotvec_c[1],
    delta_rotvec_c[2],
    0,
    0
]
```

左右手拼接后得到 16D：

```text
action_16d = [
    left_delta_xyz_cam(3),
    left_delta_rotvec_cam(3),
    0,
    0,
    right_delta_xyz_cam(3),
    right_delta_rotvec_cam(3),
    0,
    0
]
```

如果某个样本缺少左手或右手，请对应 block 填 0，并通过 action mask / valid mask 屏蔽 loss。不要让不存在的手参与训练 loss。

## 输入数据的兼容逻辑

请先检查 vitra、egodex 和 `/cache/wx1469573/data/xperience-10m-clean` 的数据格式，确认每个数据集提供的是以下哪一种：

1. 当前帧和目标帧的 absolute wrist pose；
2. 已经计算好的 relative wrist xyzquat；
3. camera extrinsics / camera pose；
4. reference camera 名称或多相机列表。

请实现一个统一的 preprocessing / adapter 层，保证三个数据集最终都输出相同语义的 `unified_eef_camera_delta_wrist16`。

### 如果数据集提供 absolute wrist pose

按上面的公式从 absolute pose 计算 camera-frame delta。

### 如果数据集只提供 relative xyzquat

请确认这个 relative xyzquat 的坐标系语义：

* 如果 relative translation / quaternion 是在当前 wrist frame `e` 下表达的，则可以把它视作 `t_e_e*` 和 `R_e_e*`，再用当前 wrist pose 与 camera pose 转到 camera frame；
* 如果 relative xyzquat 是在 world/base frame 或其他 frame 下表达的，请先转换到 `e -> e*` 的相对运动，再投影到 camera frame。

不要盲目假设 quaternion 顺序。请显式处理并注释：

```text
xyzw vs wxyz
```

并在代码里做 canonicalization，避免 quaternion 正负号导致不连续。

### 如果缺少 camera extrinsics

为了和 Unified EEF Pose 设定一致，默认不要静默 fallback 到 base-relative。建议：

* 在 config 中提供参数：

  * `require_camera_extrinsics: true`
  * `allow_base_relative_fallback: false`
* 默认情况下，如果样本缺少有效 camera extrinsics，则跳过该样本或标记 invalid；
* 只有当 config 显式设置 `allow_base_relative_fallback: true` 时，才允许退回旧的 base/local relative wrist action；
* fallback 样本必须打日志统计数量，避免训练时混入不一致语义的数据。

## Reference camera 选择

请为新配置增加参数，例如：

```yaml
action_representation: unified_eef_camera_delta_wrist16
reference_camera_key: <dataset_specific_default>
require_camera_extrinsics: true
allow_base_relative_fallback: false
```

对于多相机数据：

* 优先使用 egocentric / head / primary camera；
* 如果 xperience-10m-clean 有明确的 reference camera metadata，请使用它；
* 如果没有统一命名，请在 dataset adapter 中做 dataset-specific mapping，并在配置或注释中写清楚。

所有 image token / wrist action 的 reference camera 语义要保持一致：action delta 必须表达在同一个 reference camera frame 中。

## 需要新增或修改的内容

请尽量保持最小侵入式修改，新增功能不要破坏旧训练。

请完成以下内容：

1. 新增 xperience-10m-clean 的 dataset adapter / config entry

   * 路径：`/cache/wx1469573/data/xperience-10m-clean`
   * 支持读取 image、wrist pose/action、camera extrinsics、valid mask 等字段；
   * 如果字段名和现有数据集不同，请做清晰的 schema mapping。

2. 新增 unified EEF camera delta wrist action preprocessing

   * 实现独立 helper function，避免把变换逻辑散落在 dataset 代码里；
   * 支持 left/right wrist；
   * 支持 absolute pose 输入；
   * 支持 relative xyzquat 输入；
   * 输出固定 16D action 和对应 action mask；
   * 所有输出必须是 finite tensor，没有 NaN/Inf。

3. 新增训练配置

   * 以现有 cross relative wrist16 配置为模板；
   * 数据集包含 vitra、egodex、xperience-10m-clean；
   * action representation 设置为 `unified_eef_camera_delta_wrist16`；
   * 明确保留旧 `relative_wrist16` 逻辑。

4. 新增训练脚本

   * 参考：
     `MotusV2/scripts/train_ADS_MotusV2_cross_relative_wrist16.sh`
   * 新脚本建议命名：
     `MotusV2/scripts/train_ADS_MotusV2_cross_unified_eef_wrist16_xperience10m.sh`
   * 不要覆盖旧脚本。

5. 新增 debug / sanity check 工具或日志
   在 dataloader 前几个 batch 打印：

   * dataset name；
   * action shape；
   * action representation；
   * left/right valid mask 占比；
   * 是否使用 camera extrinsics；
   * skipped / invalid samples 数量；
   * action mean/std/min/max；
   * rotvec 范围是否异常。

## 关键实现细节

请注意以下几点：

### 1. 16D shape 保持不变，但语义改变

旧表示：

```text
[left_relative_xyzquat(7), 0, right_relative_xyzquat(7), 0]
```

新表示：

```text
[left_delta_xyz_cam(3), left_delta_rotvec_cam(3), 0, 0,
 right_delta_xyz_cam(3), right_delta_rotvec_cam(3), 0, 0]
```

因此新模式下不要再把第 4-7 维当 quaternion 解释。请在代码、config 和注释中明确区分。

### 2. rotation action 使用 rotvec

Unified EEF Pose 中 action rotation delta 应使用 3D rotation vector，而不是 4D quaternion。请实现：

```text
SO3 log map: R_delta_c -> rotvec
```

并做好数值稳定处理，尤其是接近 0 rotation 和接近 pi rotation 的情况。

### 3. 坐标系方向必须明确

请在 helper function docstring 里明确每个矩阵的含义，例如：

```text
R_w_e: maps vector from EEF frame to world/base frame
R_w_c: maps vector from camera frame to world/base frame
```

不要混用 `camera_to_world` 和 `world_to_camera` 而不写清楚。

### 4. mask 和 loss

如果某只手无效：

```text
action block = 0
action mask block = 0
```

如果有效：

```text
action mask for first 6 dims = 1
reserved dims mask = 0
```

也就是说，新模式下每只手只有前 6 维参与 loss，reserved dims 不参与 loss。

### 5. normalization / statistics

请检查现有 action normalization 是否假设 quaternion 维度。如果有，请为新 action representation 单独计算或加载 stats。

新 action 的有效维度只有：

```text
left: 0:6
right: 8:14
```

reserved 维度：

```text
6:8, 14:16
```

不应该参与 mean/std 统计和 loss。

## 建议增加单元测试 / sanity tests

请至少实现或手动验证以下 case：

1. identity camera + identity wrist

   * 当 `R_w_c = I`、`R_w_e = I` 时，输出应等于原始 `e -> e*` delta。

2. pure translation

   * 只有平移时，rotvec 应接近 0。

3. pure rotation

   * 只有旋转时，translation 应接近 0。

4. inverse consistency

   * 从 `action_16d` 还原目标 pose，应能近似恢复 `R_w_e*`、`t_w_e*`。

5. missing hand mask

   * 缺失左手或右手时，对应 block 为 0，mask 为 0。

6. old script compatibility

   * 旧的 `train_ADS_MotusV2_cross_relative_wrist16.sh` 行为不变，仍然输出旧语义的 `[xyzquat, 0, xyzquat, 0]`。

## 验收标准

完成后请确保：

1. 新训练脚本可以启动；
2. dataloader 能成功混合 vitra、egodex、xperience-10m-clean；
3. 一个 batch 的 action shape 为 `[B, T, 16]` 或代码现有约定下的等价 shape；
4. 新 action representation 明确为 `unified_eef_camera_delta_wrist16`；
5. reserved dims 不参与 loss；
6. 无 NaN / Inf；
7. 旧训练脚本和旧配置不受影响；
8. 日志中能看到每个 dataset 的样本数、有效样本数、camera extrinsics 使用情况、action 统计信息。

请先 inspect 现有代码结构，再按最小侵入原则修改。实现完成后，请总结修改了哪些文件、每个文件的作用，以及如何运行新脚本。

你好，我将需求 docs\unified_eef_camera_delta_wrist16_coding_goal.md 丢给 Claude Code 帮我完成代码实现，它顺利地帮我完成了代码的编写，并且能跑通训练流程，相应的文档在 D:\Jun_Lab\MotusV2\docs\session_log_20260624_unified_eef_camera_delta_wrist16_implementation_notes.md 中有记录。但是我不确定代码中是否存在逻辑错误和漏洞，所以请你作为严格的代码审查官，帮我审核当前 MotusV2 代码库中 Claude Code 新实现的 **Unified EEF Pose / camera-frame relative wrist action** 训练设定是否正确。

背景如下：

原有训练脚本：

```text
MotusV2/scripts/train_ADS_MotusV2_cross_relative_wrist16.sh
```

原有动作监督信号是：

```text
[left_relative_xyzquat(7), 0, right_relative_xyzquat(7), 0] = 16 dims
```

现在新增了一个训练模式，引入新数据集：

```text
/cache/wx1469573/data/xperience-10m-clean
```

并希望实现和 Qwen-RobotManip 论文中 Unified EEF Pose 类似的设定，即所有数据集，包括 vitra、egodex、xperience-10m-clean，都统一输出 **reference-camera-frame relative wrist / EEF delta action**。

请注意：我现在不是要你重新实现功能，而是要你系统检查现有实现是否有逻辑错误、坐标系错误、mask 错误、normalization 错误、训练接口兼容性问题、旧逻辑被破坏等问题。

---

## 一、请先理解目标动作格式

新的 16D action 语义应该是：

```text
[left_delta_xyz_cam(3), left_delta_rotvec_cam(3), 0, 0,
 right_delta_xyz_cam(3), right_delta_rotvec_cam(3), 0, 0]
```

也就是每只手 8 维：

```text
[delta_x_cam, delta_y_cam, delta_z_cam,
 delta_rx_cam, delta_ry_cam, delta_rz_cam,
 reserved_0, reserved_1]
```

要求：

1. 前 3 维是 reference camera frame 下的相对平移 delta；
2. 中间 3 维是 reference camera frame 下的相对旋转 delta；
3. 旋转必须使用 rotation vector / axis-angle log map，而不是 quaternion；
4. 每只手最后 2 维只是 reserved 0，不参与 loss；
5. 旧的 `[xyzquat(7), 0]` 语义不能被误用于新 action representation；
6. 新旧模式必须通过明确的 `action_representation` 或类似字段区分。

---

## 二、请重点检查坐标变换公式是否正确

请找到项目中实现 unified EEF / camera-frame relative wrist action 的 helper function、dataset preprocessing 或 adapter 代码，逐行检查是否符合下面的数学定义。

设：

```text
c      = reference camera frame
e      = 当前 wrist / EEF frame
e*     = 下一帧或目标帧 wrist / EEF frame

R_w_e  = 当前 wrist / EEF 到 world/base frame 的旋转
t_w_e  = 当前 wrist / EEF 在 world/base frame 下的位置

R_w_e* = 目标 wrist / EEF 到 world/base frame 的旋转
t_w_e* = 目标 wrist / EEF 在 world/base frame 下的位置

R_w_c  = reference camera 到 world/base frame 的旋转
```

理论上应先计算：

```text
R_e_e* = R_w_e^T @ R_w_e*
t_e_e* = R_w_e^T @ (t_w_e* - t_w_e)
```

然后投影到 camera frame：

```text
R_c_e = R_w_c^T @ R_w_e
R_e_c = R_c_e^T

R_delta_c = R_c_e @ R_e_e* @ R_e_c
t_delta_c = R_c_e @ t_e_e*
```

最后：

```text
delta_rotvec_c = log_SO3(R_delta_c)

per_arm_action_8d = [
    t_delta_c[0],
    t_delta_c[1],
    t_delta_c[2],
    delta_rotvec_c[0],
    delta_rotvec_c[1],
    delta_rotvec_c[2],
    0,
    0
]
```

请严查以下潜在错误：

1. 是否把 `R_w_c` 和 `R_c_w` 混用了；
2. 是否把 `camera_to_world` 当成 `world_to_camera` 使用；
3. 是否把 translation 直接用 world/base delta，而没有转到 camera frame；
4. 是否把 rotation delta 仍然保留为 quaternion；
5. 是否错误使用了 `R_c_e @ R_e_e*` 而漏掉右侧 conjugation `@ R_e_c`；
6. 是否错误地把 `t_w_e* - t_w_e` 直接乘 `R_w_c^T`，而不是先进入 EEF local 再按公式投影；
7. 是否 quaternion 顺序 `xyzw` / `wxyz` 处理清楚；
8. 是否对 quaternion 做了 canonicalization；
9. 是否 rotation matrix / quaternion / rotvec 之间转换存在左右乘、主动/被动旋转混淆；
10. 是否多相机情况下 reference camera 的选择和 image 输入是一致的。

如果发现实现和上述公式不同，请判断是合理等价变换还是明确 bug，并给出理由。

---

## 三、请检查 temporal alignment 是否正确

新的 action 应该表达当前帧 wrist / EEF 到下一帧或目标帧 wrist / EEF 的相对运动。

请检查：

1. 当前 frame 和 target frame 是否对齐；
2. 是否存在 off-by-one 错误；
3. 是否把当前 wrist pose 当成 target pose；
4. 是否把未来多步 action chunk 的每一步都相对于当前帧，还是相对于前一步；
5. 当前训练代码期望的是哪种 action horizon 语义；
6. xperience-10m-clean、vitra、egodex 三个数据集的 temporal sampling 是否一致；
7. 如果存在 stride / downsample / window slicing，action label 是否仍然对应正确目标帧。

请明确指出当前实现到底是：

```text
pose[t] -> pose[t+1]
```

还是：

```text
pose[t] -> pose[t+k]
```

或者：

```text
pose[t+i] -> pose[t+i+1]
```

并判断是否和训练目标一致。

---

## 四、请检查 left/right hand 的语义和 mask

请重点检查 16D action 和 mask：

新模式下有效维度应该是：

```text
left valid dims:  0:6
left reserved:    6:8

right valid dims: 8:14
right reserved:   14:16
```

要求：

1. 如果某只手有效，该手前 6 维 mask = 1；
2. reserved dims mask 必须始终为 0；
3. 如果某只手不存在或该样本无效，该手整个 8D block 应该填 0，mask 也应该为 0；
4. left/right 不应交换；
5. 不应让 reserved 0 参与 loss；
6. 不应沿用旧模式中 quaternion 7D 的 mask；
7. dataloader、collate_fn、loss function、normalization 都必须理解新 action 的有效维度只有每只手前 6D。

请检查代码里是否存在以下问题：

```text
- 新 action 是 16D，但 loss 仍然把 0:7 和 8:15 当成有效；
- rotvec 的第 6 维之后 reserved 0 被纳入 loss；
- action mask shape 和 action shape broadcast 后静默错误；
- left/right valid mask 只在 dataset 中生成，但训练 loss 没有使用；
- 某些 dataset 没有 hand valid 信息时默认两只手都 valid；
- xperience 的 handedness / camera convention 和 vitra、egodex 不一致。
```

---

## 五、请检查 normalization / statistics

请检查现有 action normalization 是否仍然沿用旧的 `[xyzquat, 0, xyzquat, 0]` 统计。

新模式下应该注意：

1. rotvec 不是 quaternion，不能使用旧 quaternion 维度的 mean/std；
2. reserved dims 不应该参与 mean/std 统计；
3. invalid hand / invalid sample 不应该参与统计；
4. 左右手统计是否共享，需要看代码原本设计，但不能把 reserved 维度混进去；
5. 如果有 action scale、clip、standardization，请确认对 xyz 和 rotvec 的量纲合理；
6. 如果 stats 是从旧 cache 加载的，请检查是否会误加载旧 relative_wrist16 的 stats；
7. config 中最好明确区分新旧 action stats 文件。

请输出当前实现是否存在 stats 泄漏、错误复用旧 stats、mask 没参与统计等问题。

---

## 六、请检查 xperience-10m-clean dataset adapter

请检查新 dataset adapter 是否真的正确接入：

```text
/cache/wx1469573/data/xperience-10m-clean
```

请重点确认：

1. 数据路径是否写死，还是可通过 config 修改；
2. schema mapping 是否清晰；
3. image、wrist pose/action、camera extrinsics、hand valid mask 是否都读对；
4. wrist pose 是 absolute pose 还是 relative pose；
5. wrist pose 坐标系是 world/base、camera、local wrist，还是其他；
6. quaternion 顺序是否明确；
7. 单位是否一致，例如 meter vs millimeter；
8. camera extrinsics 是 camera-to-world 还是 world-to-camera；
9. 多相机时 reference camera key 是否正确；
10. 缺失 camera extrinsics 的样本是 skip、invalid，还是 fallback；
11. fallback 是否会污染 unified action 语义；
12. dataset length、sample index、window slicing 是否和其他数据集一致；
13. 数据集中无效样本是否会导致 dataloader 死循环或 batch 为空。

请不要只看是否能跑通，要判断 xperience 输出的 action 是否和 vitra、egodex 具有一致语义。

---

## 七、请检查旧逻辑是否被破坏

旧脚本：

```text
MotusV2/scripts/train_ADS_MotusV2_cross_relative_wrist16.sh
```

必须保持旧行为：

```text
[left_relative_xyzquat(7), 0, right_relative_xyzquat(7), 0]
```

请检查：

1. 旧脚本是否仍然调用旧 config；
2. 旧 config 是否仍然设置旧 action representation；
3. 旧 dataloader 是否仍然输出 xyzquat；
4. 旧 loss / stats 是否不受新模式影响；
5. 新 helper function 是否没有改变旧 dataset 默认行为；
6. 是否有全局默认值被改成了 `unified_eef_camera_delta_wrist16`，导致旧训练静默改变；
7. 是否存在新旧 stats cache 混用。

请给出旧脚本兼容性结论。

---

## 八、请运行或建议运行 sanity checks

如果环境允许，请直接运行轻量级 sanity check。优先不要跑完整训练，而是检查 dataloader 和若干 batch。

建议执行或构造以下测试：

### 1. Dataloader smoke test

检查新脚本对应 config 能否加载 batch，并打印：

```text
dataset_name
action.shape
action_mask.shape
action_representation
left/right valid ratio
action mean/std/min/max
NaN/Inf count
reference_camera_key
camera extrinsics valid ratio
```

### 2. Identity case

构造：

```text
R_w_c = I
R_w_e = I
```

此时输出应等价于原始 `e -> e*` delta。

### 3. Pure translation

只改变 `t_w_e*`，不改变旋转。rotvec 应接近 0。

### 4. Pure rotation

只改变 `R_w_e*`，不改变位置。translation 应接近 0。

### 5. Inverse consistency

从 action 还原目标 pose，检查是否接近原始 `R_w_e*`、`t_w_e*`。

### 6. Missing hand

缺失左手或右手时：

```text
action block = 0
mask block = 0
```

### 7. Old script smoke test

旧脚本仍能加载旧格式 action，并且 action representation 未被改变。

如果没有现成测试，请你可以临时写最小化测试脚本或 Python snippet，但请不要大规模重构代码。

---

## 九、输出格式要求

请按以下格式输出审核结果：

```text
# Unified EEF Pose Code Review Report

## 总体结论

- 是否通过审核：
- 最大风险点：
- 是否建议直接开始正式训练：

## Critical Issues

列出会导致训练目标错误、坐标系错误、loss 错误、数据语义不一致的严重问题。

每个问题请包含：

- 文件：
- 代码位置：
- 问题描述：
- 为什么是问题：
- 可能后果：
- 建议修复：

## Major Issues

列出不会立刻崩溃，但会显著影响训练质量或实验可信度的问题。

## Minor Issues

列出日志、命名、注释、健壮性、可维护性问题。

## 坐标系与公式核查

请明确说明当前实现是否符合：

R_e_e* = R_w_e^T @ R_w_e*
t_e_e* = R_w_e^T @ (t_w_e* - t_w_e)
R_c_e = R_w_c^T @ R_w_e
R_delta_c = R_c_e @ R_e_e* @ R_e_c
t_delta_c = R_c_e @ t_e_e*

## Action / Mask / Loss 核查

说明 16D action、valid dims、reserved dims、mask、loss 是否正确。

## Normalization / Stats 核查

说明是否正确区分新旧 stats，是否排除 invalid/reserved dims。

## Dataset Adapter 核查

分别说明 vitra、egodex、xperience-10m-clean 的实现是否输出同一语义的 action。

## 旧脚本兼容性核查

说明旧 relative_wrist16 训练是否保持不变。

## 建议的最小修复 Patch

如果有 bug，请给出最小修改建议。除非非常确定，否则不要直接大规模重构。

## 建议补充的测试

列出最值得加入的 3-5 个测试。
```

请你一定要从“实验语义是否正确”的角度审查，而不是只看代码是否能跑通。这个功能即使能顺利训练，也可能因为坐标系、mask、normalization 或 temporal alignment 错误而导致实验结论不可信。

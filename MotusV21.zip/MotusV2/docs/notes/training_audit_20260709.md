# MotusV2 训练链路 Bug 审计（2026-07-09）

> 目的：审核当前仓库，判断模型训练是否存在 bug。
> 方法：4 路并行审查（训练循环 / 模型前向 / 数据管线 / 文档不变量）+ 关键点人工复核。
> 标注：**[已复核]** = 本人读代码确认；**[审计报告]** = 子审查发现、合理但未逐行复核，落地前需再确认。
> 结论先行：**没有发现会让当前 finetune 训练（robotwin / droid / g1d）立即崩溃或明显训练错误的 bug**；但存在若干**分布式健壮性隐患**、**配置项形同虚设**、以及**仅在特定模式/数据组合下才触发的隐藏 bug**。

---

## 一、先澄清一个误报（重要）

**flow-matching 训练/推理调度"不一致" —— 经复核不是 bug。**
训练 scheduler `FlowMatchScheduler(shift=5.0)` 里 `timesteps = sigmas * 1000`（[bak/wan/utils/fm.py:54](../../bak/wan/utils/fm.py)），因此 `t_embed / 1000 == sigma` 这一关系在训练与推理里完全一致：
- 训练（[models/motus_wan_vlm_direct_mask.py:930-940](../../models/motus_wan_vlm_direct_mask.py)）：`noisy = (1-σ)·clean + σ·noise`，`t_embed = σ·1000`，target=`noise-clean`。
- 推理（同文件 1280-1347）：`t = linspace(1,0)`（即 σ），`t_embed = t·1000`，Euler `latent += velocity·dt`。

`shift=5.0` 只改变**训练时对 σ 的采样密度**（偏向高噪声段），并不改变 `t_embed↔σ` 映射，推理用均匀 σ 步进积分同一速度场是标准且正确的做法。故此项排除。

---

## 二、确认的问题（按优先级）

### P1 — 分布式健壮性隐患（✅ 已于 2026-07-09 修复）

> 修复：两处跳步均改为**集合决策**——`None` batch 用 `dist.all_reduce(MIN)`、NaN/Inf loss 用 `dist.all_reduce(MAX)`，任一 rank 命中则所有 rank 一致跳过，保证 `global_step` 与 backward/barrier 严格对齐；NaN 分支不再在累积窗口内 `zero_grad`。见 [train/train_wan_vlm_mask.py](../../train/train_wan_vlm_mask.py) 约 633-655、740-751 行。

1. **[已复核 → 已修复] 整批为 None 时 `continue` 会导致多卡挂死 / 步数错位**
   [train/train_wan_vlm_mask.py:724-725](../../train/train_wan_vlm_mask.py)：`if batch is None: continue`。
   当某个 rank 的 `collate_fn` 因该 rank 上所有样本都被丢弃而返回 `None` 时，该 rank 直接跳过、不进入 `train_step`，而其他 rank 会执行 `accelerator.backward` + 梯度 all-reduce → **该 rank 缺席集合通信，训练挂起或各卡 `global_step` 错位**。触发条件较罕见（需某 rank 整个 micro-batch 全部失败，如持续 T5 cache miss / 数据分片损坏），但一旦发生就是难排查的 hang。
   - 建议：把"是否有有效 batch"做一次 all-reduce，任一 rank 为空则所有 rank 一起跳过（或喂一个 dummy/上一个 batch）。

2. **[已复核] loss 为 NaN/Inf 时提前 return 同样会挂死多卡，且累积期清梯度**
   [train/train_wan_vlm_mask.py:634-639](../../train/train_wan_vlm_mask.py)：NaN 时不调用 `backward` 直接 `return`。分布式下若只有个别 rank 出 NaN，则该 rank 跳过 backward，其余 rank 正常 all-reduce → 挂起。此外该分支在 `accelerator.accumulate` 上下文里调用 `optimizer.zero_grad()`，当 `gradient_accumulation_steps>1` 时会清掉本累积窗口内前几个 micro-batch 的梯度。
   - 建议：NaN 判定也做跨 rank 归约，一致地跳过整步；累积期不要单独 `zero_grad`。

### P2 — 配置项形同虚设 / 误导（不崩，但与预期不符）

3. **[已复核] `time_distribution.timestep_sample_method: "logit_normal"` 未被使用**
   [models/motus_wan_vlm_direct_mask.py:930](../../models/motus_wan_vlm_direct_mask.py) 用 `torch.randint`（在 shift=5 的离散 σ 上**均匀**取样），`get_t_distribution` 虽被 import 但训练里从未调用。所有写着 `logit_normal` 的 config 实际拿到的是"shift=5 均匀"分布。
   - 建议：要么实现 logit_normal，要么把 config 注释/字段改为如实描述。

4. **[已复核] `training.use_amp` 被忽略、`mixed_precision="bf16"` 硬编码**
   [train/train_wan_vlm_mask.py:1061 附近](../../train/train_wan_vlm_mask.py)。`use_amp: false` 不会真的关闭 bf16。

5. **[审计报告] `config.resume.checkpoint_path`、`config.model.ema.*`、`training.find_unused_parameters` 三处 config 均未接线**
   - `resume.checkpoint_path`：只有 CLI `--resume` 生效，YAML 里写了不会自动续训。
   - `ema.enabled: true`：无 EMA 实现，开了也没用。
   - `find_unused_parameters`：从未传给 Accelerator/DDP。
   建议：要么实现，要么从 config 与文档中移除，避免误以为生效。

6. **[已复核] `scheduler.step()` 未随梯度累积门控**
   [train/train_wan_vlm_mask.py:676-677](../../train/train_wan_vlm_mask.py)：`optimizer.step()`/`zero_grad()` 由 Accelerate 的 accumulate 包装自动门控，但自定义 `LambdaLinearScheduler.step()` 每个 micro-step 都走，`gradient_accumulation_steps>1` 时学习率调度会快 `grad_accum` 倍。**当前所有 config `gradient_accumulation_steps=1`，暂不受影响。**

7. **[审计报告] 续训 + `--reset_scheduler` 时 `global_step` 与调度器步数不一致**
   `global_step` 从 checkpoint 目录名解析恢复，但 `LambdaLinearScheduler.step_count` 被重置为 0 → warmup/衰减从 0 重新开始而训练步数仍是大数，LR 曲线错乱。仅影响"带 reset_scheduler 的续训"场景。

### P3 — 潜伏 bug（当前 finetune 配置不触发，换模式/数据会触发）

8. **[已复核] `training_mode='pretrain'` 的推理/验证会崩**
   [models/motus_wan_vlm_direct_mask.py:1291-1293,1343](../../models/motus_wan_vlm_direct_mask.py) `inference_step` 硬编码 finetune 布局：`state.unsqueeze(1)`、`self.action_expert.registers.expand(...)`（pretrain 下 `registers=None` → AttributeError）、`action_pred_full[:, 1:-num_registers]`（`num_registers=0` 时切片为空）。**训练前向已正确区分 pretrain/finetune（973-977），只有推理路径没区分。** 当前 droid/g1d/robotwin 都是 finetune，不触发；但 `pretrain_*` 配置跑验证会崩。

9. **[审计报告] 单个 batch 混合不同 `action_dim` 会在 collate 处 `torch.stack` 失败**
   [data/dataset.py:513](../../data/dataset.py)。`cross_dataset_mixed`/`MultipleWeightedDataset` 随机抽子数据集，若同一 config 混入 action_dim 不同的数据集（如 DROID-8 与 16 维）会崩。现有 cross 配置都强制统一 `action_mode`/`action_dim`，属**footgun**而非当前 bug。

10. **[审计报告] EgoDex/WIYH 的 `action_valid_mask` 形状为 `[F,2]`，与模型要求的 `[B,T,action_dim]` 不符**
    模型侧已在 [models/motus_wan_vlm_direct_mask.py:960-964](../../models/motus_wan_vlm_direct_mask.py) 对形状不符**主动抛 ValueError**（这是 20260624 的修复）。因此若 EgoDex/WIYH 以带 `[F,2]` mask 的模式参与训练，会直接报错；若与不带 mask 的数据集混合，collate 只在"全部样本都有 mask"时才 stack，于是**整批静默丢弃 mask**。需结合具体 config 确认是否命中。

11. **[审计报告] `multi_source_pretrain` 的 per-source `weight` 未生效**
    `random.choice(self.episodes)` 均匀采样，config 里各机器人源的权重被忽略；且 `max_episodes` 只按机器人源计数、`_rebalance_human_robot_ratio` 在截断后又可能扩张索引。仅影响 pretrain 数据配比。

12. **[审计报告] `unify_action_to_16` 对 `dim==8`（7 关节+夹爪）的映射把第 7 关节放进了 pad 槽**
    [data/multi_source_pretrain_dataset.py:64-69](../../data/multi_source_pretrain_dataset.py)。与"6+pad+grip"的规范布局不符；把 7-DOF 单臂源混进 multi_source 联训时语义错位。DROID 自己是独立 dataset（不走这条路径），当前不触发。

13. **[审计报告] LeRobot 数据集 `__getitem__` 无重试、异常直接抛出**
    可能打挂 DataLoader worker（其他数据集均返回 `None` 重试）。仅影响 `lerobot` 类型。

14. **[审计报告] EgoDex/WIYH/VITRA 的 T5 cache miss 用 `assert` 且无 worker 守护**
    多 worker 且缓存不全时 worker 断言失败（被各自的重试循环吞掉变成 None）。运维层面需先跑 prepopulate 预热。

### P4 — 低优先 / 一致性

15. **[审计报告] collate 的语言嵌入 padding 硬编码 `text_len=512`**（[data/dataset.py:515](../../data/dataset.py)）：若某 config 设 `t5_text_len≠512` 会截断/错填。当前均为 512。
16. **[审计报告] 各数据集 T5 磁盘缓存的落盘长度不统一**：DROID/G1-D 固定 `[t5_text_len,4096]`，EgoDex/Xperience/VITRA 按实际 token 长度落盘。跨数据集缓存契约不一致。
17. **[审计报告] EgoDex/Xperience 采样用连续窗口 `randint`，与 DROID/RoboTwin 的 `_calculate_sampling_indices`（下采样+chunk 对齐）不同**：同样的 `video_action_freq_ratio` 下时序对齐语义不一致。
18. **[审计报告] EgoDex 缺失关节 padding 用 `np.zeros(6)`，但每关节应为 9 维（xyz3+rot6d6）** ([data/egodex/egodex_dataset.py:506-508](../../data/egodex/egodex_dataset.py))：会错位 225→450 维 per-hand 布局。

---

## 三、文档层面

- 文档整体信息丰富，但存在多处**新旧记录相互矛盾**（属历史演进，非代码 bug），典型：DROID "2 路 384" vs "T 字形 3 路 288"、`vlm_causal_attention` 默认值的前后翻转、G1-D 与 DROID 拼接是否等价。建议以最新的 `session_log_20260709` + `changelog/review_20260709` 为准，旧 session log 保留作历史。
- `CLAUDE.md` 的关键不变量（float32 时间嵌入/AdaLN、16 维布局、train==infer 分辨率、LR 分组）与代码基本对得上；其中"VLM 只做因果自注意"这一条**仅在 `vlm_causal_attention: true` 时成立**，默认是双向——motion-token CE 训练必须开该开关（`robotwin_eepos_wan_vlm_mask_motion_token_on.yaml` 已开）。

---

## 四、修复建议优先级

| 级别 | 项 | 建议 |
|------|----|------|
| ✅ 已修 | #1 None-batch、#2 NaN 的多卡跳步 | 已加跨 rank 归约，一致跳步 |
| 次之 | #3 logit_normal、#4 use_amp、#5 三处空接线 config | 实现或从 config/文档移除，消除误导 |
| 按需 | #8 pretrain 推理、#7 reset_scheduler、#6 grad-accum 调度 | 用到对应模式前修 |
| 数据 | #9-#18 | 结合实际 config 逐个确认后修（多为特定模式/组合触发） |

> 本报告仅审查，未改动任何训练代码。

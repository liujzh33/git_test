# MotusV2 VLM 模块架构理解笔记

> 基于对代码阅读与讨论整理。原始笔记整理于 2026-06-08，本版补充了 `vlm_per_layer`、teacher forcing、GT 泄漏、训推一致性与 motion-token generation 动机之间的关系。

---

## 0. 总结结论

当前架构中，训练阶段的 `vlm_inputs` 在 motion-token 模式下包含完整的 GT assistant motion token sequence，因此：

1. `extract_per_layer_features(vlm_inputs)` 得到的 `vlm_per_layer` 确实来自包含 GT motion tokens 的完整 VLM 序列。
2. `vlm_tokens = (vlm_base + vlm_tokens) / 2` 会持续把 teacher-forced VLM hidden states 混入 MoT 更新后的 VLM tokens。
3. 对 **Action/Video loss** 来说，当前 mask 设计基本阻止了 GT assistant motion tokens 泄漏给 Action/Video 分支。
4. 对 **token CE loss** 来说，只要 VLM 与 MoT 的 VLM self-attention 都保持 causal，这不是非法泄漏，而是标准 autoregressive teacher forcing。
5. 但当前推理阶段并没有实现 autoregressive motion-token generation loop，因此当前版本更准确地说是：**使用 motion-token prediction 作为训练辅助监督**，而不是已经实现了完整的 `image + prompt -> motion token sequence` 推理闭环。

一句话判断：

> 当前方案可以作为联合训练中的 VLM token auxiliary supervision；如果最初目标是让 VLM 在推理阶段独立生成未来 motion token sequence，则还需要新增完整的 autoregressive decoding 接口与推理路径。

---

## 1. `extract_per_layer_features(vlm_inputs)` 在计算什么？

### 1.1 一句话概括

`extract_per_layer_features(vlm_inputs)` 对 Qwen3-VL-2B 做一次完整前向传播，提取全部 28 层 language model hidden states，并映射到 WAN 的 30 层结构，最终返回长度为 30 的 tensor 列表：

```text
vlm_per_layer: List[Tensor]
len(vlm_per_layer) = 30
vlm_per_layer[i].shape = [B, seq_len, 2048]
```

这些 hidden states 后续作为每一层 MoT 联合注意力中 VLM 分支的初始 token / anchor。

### 1.2 三步计算流程

#### Step 1：`_process_vlm_inputs_to_tokens`

将 processor 输出转为 Qwen3-VL language model 可用的 embeddings：

```text
input_ids
  → text embedding lookup
  → inputs_embeds [B, seq_len, 2048]

pixel_values
  → vision encoder, no_grad
  → image_embeds + deepstack_image_embeds

inputs_embeds + image placeholder positions
  → masked_scatter 替换图像占位符
  → final inputs_embeds
  → visual_pos_masks [B, seq_len]
  → position_ids [B, seq_len]
```

注意：vision encoder 在 `torch.no_grad()` 下运行，因此当前主要训练 language model / MoT 相关部分，而不是训练 Qwen3-VL vision encoder。

#### Step 2：Qwen3-VL language model 前向

关键参数是 `output_hidden_states=True`：

```python
vlm_output = self.vlm_model.model.language_model(
    inputs_embeds=inputs_embeds,
    attention_mask=attention_mask,
    position_ids=position_ids,
    visual_pos_masks=visual_pos_masks,
    deepstack_visual_embeds=deepstack_visual_embeds,
    output_hidden_states=True,
)
```

返回的 `hidden_states` 语义为：

```text
hidden_states[0]      embedding 层输出
hidden_states[1:29]   28 个 Qwen3-VL decoder layer 输出
```

实际作为 VLM per-layer features 使用的是 `hidden_states[1:]`，即跳过 embedding 层。

#### Step 3：层数映射 28 → 30

WAN 有 30 层，Qwen3-VL language model 有 28 层，因此代码将最后两层通过复用方式补齐：

```python
result = list(hidden_states[1:])     # 28 个 tensor: VLM Layer 0..27
result.append(result[-2].clone())    # VLM Layer 26 → WAN Layer 28
result.append(result[-1].clone())    # VLM Layer 27 → WAN Layer 29
```

最终每个 WAN block 都能获得一个对应的 VLM hidden state anchor。

---

## 2. `vlm_inputs` 的结构与两种构造模式

### 2.1 基础字段

两种模式下，`vlm_inputs` 都包含以下字段：

| Key | 形状 | 说明 |
|---|---:|---|
| `input_ids` | `[B, seq_len]` | 文本 token ids，包含图像占位符 `<|image_pad|>` 与 special tokens |
| `pixel_values` | `[B, num_patches, C, H, W]` | processor 从第一帧 PIL 图像生成的图像输入 |
| `image_grid_thw` | `[B, 3]` | Qwen3-VL 用于视觉 RoPE 的 temporal / height / width grid 信息 |
| `attention_mask` | `[B, seq_len]` | 1 表示有效 token，0 表示 padding |

### 2.2 Motion-token 模式额外字段

motion-token 模式下额外包含：

| Key | 形状 | 说明 |
|---|---:|---|
| `assistant_token_mask` | `[B, seq_len]` | True 表示 GT assistant 回复区域，用于 MoT 阻止 Action 看到 GT motion tokens |
| `assistant_loss_mask` | `[B, seq_len]` | True 表示参与 token CE loss 的位置 |

`labels` 不保留在 `vlm_inputs` 中，而是在 dataset / collate 过程中被单独取出，作为 `motion_token_labels` 传入训练逻辑。

### 2.3 标准模式 vs motion-token 模式

| 对比项 | 标准模式 | Motion-token 模式 |
|---|---|---|
| 构建函数 | `preprocess_vlm_messages()` | `preprocess_vlm_messages_with_motion_tokens()` |
| VLM 序列内容 | user prompt + image | user prompt + image + GT assistant motion token reply |
| assistant mask | 无 | 有：`assistant_token_mask`, `assistant_loss_mask` |
| chat template | `add_generation_prompt=True` | `add_generation_prompt=False`，因为 assistant 回复已经包含在序列中 |
| 主要用途 | prompt-only 推理 / 普通 VLM 条件 | teacher-forced token supervision |

---

## 3. 核心疑问：`vlm_per_layer` 是否包含 GT motion token 真值？

### 3.1 结论

是的，训练 motion-token 模式下，`vlm_per_layer` 来自完整序列：

```text
user: image + prompt
assistant: Left:<motion tokens> Right:<motion tokens>
```

因此，`vlm_base = vlm_per_layer[layer_idx]` 本身已经是 teacher-forced hidden states：它是在完整 `input_ids` 上做 causal LM forward 后得到的每层表示。

后续 MoT 中的混合：

```python
vlm_tokens = (vlm_base + vlm_tokens) / 2
```

确实会持续把 `vlm_base` 中的信息混入更新后的 `vlm_tokens`。

### 3.2 关键区分：包含 GT token 不等于非法泄漏

需要区分三种不同含义的“看到真值”：

| 场景 | 是否看到 GT motion token | 是否一定是问题 | 解释 |
|---|---:|---:|---|
| VLM 自回归 token loss 训练 | 是，看到历史真值 token | 否 | 标准 teacher forcing：位置 `t` 用历史 token 预测 `t+1` |
| Action/Video 分支训练 | 不应该看到 assistant GT token | 是，如果看到就是目标泄漏 | 需要通过 mask 阻止 Action/Video 访问 GT assistant token 的 K/V |
| 推理阶段 motion-token 生成 | 不会有 GT token | 不是泄漏问题，而是是否实现生成闭环的问题 | 需要 autoregressive decoding loop |

因此：

> 对 token CE loss，关键问题不是“输入里有没有 GT motion tokens”，而是位置 `t` 的 hidden state 是否只能看到 `<= t` 的 token，不能看到未来 token。

只要 Qwen3-VL language model 自带 causal mask，且 MoT 中 VLM self-attention 也显式使用 causal mask，那么 token logits 不应看到未来 GT token。

---

## 4. GT 信息泄漏问题：Action/Video 与 token loss 分开判断

### 4.1 对 Action/Video loss：通过 mask 防止目标泄漏

motion-token 模式下，GT assistant 回复存在于 VLM 序列中。风险是 Action/Video 分支可能通过联合注意力读到这些 GT token 的 hidden states，从而造成训练目标泄漏。

当前代码用三层注意力约束降低这个风险。

#### 防线 A：Action 不能看 assistant GT tokens

```python
action_to_vlm_allowed = (vlm_valid & ~vlm_assistant).unsqueeze(1)
attn_mask[:, L_v:L_v + L_a, L_v + L_a:] &= action_to_vlm_allowed
```

语义：

```text
Action query 只能 attend 到 VLM 中的 user/image prompt 部分，不能 attend 到 assistant motion token 部分。
```

其中：

```text
vlm_valid       = attention_mask == 1
vlm_assistant   = assistant_token_mask == True
~vlm_assistant  = 非 assistant 回复区域，即 user/image/system/prompt 区域
```

#### 防线 B：Video 完全隔离

```python
attn_mask[:, :L_v, L_v:] = False
```

语义：

```text
Video query 不看 Action，也不看 VLM。
```

因此 Video 分支不会从 VLM assistant GT token 中获得信息。

#### 防线 C：VLM 分支使用 causal mask

```python
vlm_causal = torch.tril(torch.ones((L_vlm, L_vlm), ...))
attn_mask[:, L_v + L_a:, L_v + L_a:] &= vlm_causal.unsqueeze(0)
```

语义：

```text
VLM query position t 只能看 VLM key positions <= t。
```

这保证了 token prediction 的 autoregressive 性质。

### 4.2 Attention mask 总体结构

motion-token 模式下，可以理解为：

```text
Query \ Key          Video   Action   VLM(prompt)   VLM(assistant)
Video                 ✅      ❌        ❌              ❌
Action                ✅      ✅        ✅              ❌
VLM(prompt)           ❌      ❌        causal          causal 限制下通常不可看未来
VLM(assistant)        ❌      ❌        causal          causal
```

更精确地说，VLM prompt token 是否能看 assistant token 由相对位置决定。由于 assistant token 在 prompt 之后，在 causal mask 下 prompt positions 不能看未来的 assistant positions。

### 4.3 对 token logits：不是非法泄漏，而是 teacher forcing

训练时：

```python
token_logits = self.vlm_model.lm_head(vlm_tokens)
```

如果 labels 做了标准 shift，那么训练形式就是：

```text
输入:  token_0, token_1, token_2, ..., token_t
预测: token_1, token_2, token_3, ..., token_{t+1}
```

这意味着模型在预测下一个 token 时可以看到历史真实 token。这是 autoregressive SFT / LM 训练的常规做法。

真正需要避免的是：

```text
position t 的 hidden state 看到 token_{t+1}, token_{t+2}, ...
```

当前修复后的 VLM causal mask 目标就是阻止这种未来信息泄漏。

---

## 5. `attention_mask` 与 `assistant_token_mask` 的含义

### 5.1 `attention_mask`

`attention_mask` 由 Qwen3-VL processor 自动生成：

```text
1 = 有效 token
0 = padding token
```

它用于阻止模型 attend 到 padding 区域。

### 5.2 `assistant_token_mask`

`assistant_token_mask` 是 motion-token 模式下手动构建的 bool mask。

构造逻辑：

1. 初始化全 False。
2. 在 `input_ids` 中搜索 `<|im_start|>assistant\n` 对应的 token 子序列。
3. 找到 assistant 起点后，将 assistant 回复内容区域标记为 True。
4. padding 区域保持 False。

示意：

```text
VLM positions:       [system] [user+image] [asst_marker] [GT_motion_tokens] [pad]
attention_mask:        1         1            1               1               0
assistant_mask:        0         0            0               1               0

vlm_valid:            ✅        ✅           ✅              ✅               ❌
vlm_valid & ~asst:    ✅        ✅           ✅              ❌               ❌
vlm_valid &  asst:    ❌        ❌           ❌              ✅               ❌
```

### 5.3 在 MoT 中的使用

| 表达式 | 选中区域 | 用途 |
|---|---|---|
| `vlm_valid` | 所有非 padding 的 VLM tokens | 所有分支都不应看 padding key |
| `vlm_valid & ~vlm_assistant` | system / user / image / prompt 区域 | Action 允许看的 VLM key |
| `vlm_valid & vlm_assistant` | GT assistant motion token 区域 | Action 明确禁止看的 VLM key |

### 5.4 推理阶段 fallback

推理时使用 `vlm_user_inputs`，其中没有 GT assistant 回复，也没有 `assistant_token_mask`。代码 fallback 为：

```python
if vlm_assistant_mask is not None:
    vlm_assistant = vlm_assistant_mask[:, :L_vlm]
else:
    vlm_assistant = torch.zeros(...)  # 全 False
```

这表示推理时所有有效 VLM tokens 都属于 prompt/image 条件，Action 可以看全部有效 VLM tokens。

---

## 6. Train-Test 一致性：当前一致在哪里，不一致在哪里？

### 6.1 表面不一致

| 对比项 | 训练 | 推理 |
|---|---|---|
| VLM 输入来源 | `preprocess_vlm_messages_with_motion_tokens()` | `preprocess_vlm_messages_motion_prompt_only()` |
| VLM 序列内容 | user prompt + image + GT assistant motion tokens | user prompt + image |
| `vlm_per_layer` 语义 | 包含 teacher-forced assistant token hidden states | 只包含 prompt/image hidden states |
| `assistant_token_mask` | 有 | 无 |
| token logits | 用于 token CE loss | 当前基本未形成 generation 输出 |

因此，如果把当前训练目标理解为“训练一个能在推理阶段自动生成 motion tokens 的 VLM”，那么当前代码确实还没有闭环。

### 6.2 对 Action/Video 推理来说，问题较小

如果当前模型推理主要目标仍是 video/action 输出，而不是输出 motion token sequence，那么不一致性相对可控，原因是：

1. Action 训练时已经被 mask 限制，只能看 VLM 的 prompt/image 部分，不能看 assistant GT motion token 部分。
2. Video 分支训练时与 VLM/Action 隔离，不读 assistant GT token。
3. 推理时 `vlm_user_inputs` 只包含 prompt/image，这与 Action 训练时允许看到的 VLM key 范围基本一致。
4. token CE loss 更像辅助监督，用来增强 VLM/MoT 对动作语义和 motion-token 结构的建模。

所以：

> 对 action/video branch，当前设计意图是避免 GT token 直接作为条件输入；motion-token 序列更多是训练期辅助信号。

### 6.3 对 motion-token generation 来说，当前尚不完整

如果目标是：

```text
image + user prompt → future motion token sequence
```

那么推理阶段应当具备如下 autoregressive loop：

```text
1. 输入 user prompt + image + <|im_start|>assistant\n
2. 运行 Qwen3-VL / MoT，得到当前最后位置 logits

3. 从 logits 中 sample 或 argmax 得到下一个 motion token

4. append 新 token 到 input_ids

5. 重新构造/更新 VLM inputs 与必要的 cache

6. 重复生成 Left / Right motion token sequence

7. 将 motion tokens decode 成轨迹，或作为后续 action/video 模块条件
```

当前 `inference_step()` 主要是 joint inference for video/action：

```text
- 优先使用 vlm_user_inputs，而不是包含 GT motion tokens 的 vlm_inputs
- 只做一次 extract_per_layer_features
- 没有逐 token autoregressive decoding
- token prediction head 在推理阶段没有形成独立输出路径
```

因此当前不能宣称已经实现完整的 Route A：

```text
VLM generates motion tokens at inference time.
```

更准确的表述是：

```text
VLM receives motion-token teacher-forcing supervision during training.
The trained token head is not yet connected to an inference-time AR generation pipeline.
```

---

## 7. 当前设计是否符合最初动机？

### 7.1 最初动机

最初动机可以表述为：

```text
利用 user prompt + image 两类信息，预测未来 motion token sequences。
```

这包含两个层次：

1. **训练层面**：让模型学习 motion token 的 next-token distribution。
2. **推理层面**：给定 prompt/image，无 GT motion tokens，自回归地产生完整 motion token sequence。

### 7.2 当前已经符合的部分

当前训练逻辑符合第一层目标：

- dataset 构造了 `user prompt + image + assistant motion tokens` 的完整序列。
- Qwen3-VL / MoT 在 causal 约束下学习 next-token prediction。
- token CE loss 对 motion token 序列提供直接监督。
- teacher forcing 是训练 autoregressive token model 的标准方法。

因此，当前做法可以训练模型理解：

```text
prompt/image context 下，motion token sequence 应该长什么样。
```

### 7.3 当前尚未符合的部分

当前推理逻辑还没有实现第二层目标：

- 没有 `generate_motion_tokens()` 之类的接口。
- 没有从 prompt-only 输入开始逐 token 生成 motion token。
- 没有将生成的 motion tokens decode / feed into 后续 action 或 video pipeline 的闭环。
- 当前 `inference_step()` 主要仍服务于 video/action 推理。

因此，当前版本更适合描述为：

```text
使用 motion-token prediction 作为辅助训练目标，增强 VLM/MoT 的动作语义表征。
```

而不是：

```text
已经完成了 VLM motion-token generation pipeline。
```

### 7.4 设计判断

当前实现“部分符合”最初动机：

| 目标 | 当前状态 | 判断 |
|---|---|---|
| 让 VLM 学习 motion token sequence 的分布 | 已有 token CE loss | 符合 |
| 防止 Action/Video 直接看到 GT motion tokens | 已有 assistant mask / causal mask / video isolation | 基本符合 |
| 推理时从 prompt/image 生成 motion tokens | 尚未实现 AR decoding loop | 不完整 |
| 将生成 motion tokens 接入 action/video pipeline | 尚未闭环 | 不完整 |

---

## 8. 推荐的后续工程整理方向

### 8.1 如果 motion-token loss 只是辅助监督

如果设计目标只是让 motion-token prediction 作为 auxiliary loss，则当前思路可以保留，但建议在代码和文档里明确：

```text
motion-token sequence is used only for teacher-forced auxiliary supervision during training;
inference does not rely on generated motion tokens.
```

同时建议检查 / 明确：

- token loss shift 是否正确。
- `assistant_loss_mask` 是否只覆盖需要预测的 motion token 内容，不覆盖无关 special tokens。
- Qwen3-VL 原始 LM forward 是否确实 causal。
- MoT 中 VLM self-attention 是否始终 causal。
- `(vlm_base + vlm_tokens) / 2` 是否会让 prompt/image anchor 与 assistant token anchor 的作用边界变模糊。

### 8.2 如果目标是完整 motion-token generation pipeline

如果目标是推理时真的生成 motion tokens，则需要新增：

```python
def generate_motion_tokens(
    image,
    prompt,
    max_new_tokens,
    temperature=1.0,
    top_p=1.0,
    ...
):
    ...
```

核心工程点包括：

1. 构造 prompt-only VLM inputs，并追加 assistant generation prefix。
2. 每一步运行 VLM/MoT/token head 得到 next-token logits。
3. 维护 generated token history。
4. 设计停止条件，例如 EOS、固定 token 长度、Left/Right 分隔符完整性。
5. 将生成的 token ids decode 为 motion token sequence。
6. 决定生成的 motion tokens 如何进入 action/video 模块。
7. 优化 KV cache，否则逐 token 重新跑 30 层 MoT 成本可能很高。

### 8.3 当前最需要实验验证的问题

- `(vlm_base + vlm_tokens) / 2` 混合策略是否优于 residual、gating、cross-attention-only 或 no-mix？
- token CE loss weight = 0.2 是否合理？是否做过消融？
- VLM 28 层映射到 WAN 30 层时复用最后两层是否最优？
- motion-token auxiliary loss 是否真的提升 action/video 指标？
- 如果移除 assistant GT tokens，仅用 prompt/image 做 VLM anchor，action/video 性能是否变化？
- 如果实现 autoregressive generation，生成质量与计算成本是否可接受？

---

## 9. 关键代码位置索引

| 内容 | 文件 | 行号 |
|---|---|---:|
| `extract_per_layer_features` | `models/qwen3_module_wan.py` | 106-185 |
| `_process_vlm_inputs_to_tokens` | `models/qwen3_module_wan.py` | 187-288 |
| `process_joint_attention` / MoT mask | `models/motus_wan_vlm_direct_mask.py` | 182-301 |
| `training_step` / VLM 提取 + MoT 循环 | `models/motus_wan_vlm_direct_mask.py` | 662-860 |
| `inference_step` | `models/motus_wan_vlm_direct_mask.py` | 891-1023 |
| `preprocess_vlm_messages_with_motion_tokens` | `utils/vlm_utils.py` | 55-182 |
| `preprocess_vlm_messages_motion_prompt_only` | `utils/vlm_utils.py` | 185-226 |
| RoboTwin dataset VLM inputs 构建 | `data/robotwin2/robotwin_agilex_dataset.py` | 870-932 |
| `_process_vlm_inputs_batch` / collate | `data/dataset.py` | 354-417 |
| 验证时 `vlm_inputs` 选择 | `train/sample.py` | 114 |

---

## 10. 复习时的核心判断链

可以按下面这条链路快速复盘：

```text
训练 motion-token 模式下，vlm_inputs 包含 GT assistant motion tokens
        ↓
extract_per_layer_features 得到的 vlm_per_layer 是 teacher-forced hidden states
        ↓
vlm_base 会通过 (vlm_base + vlm_tokens) / 2 混入 MoT 的 VLM tokens
        ↓
Action/Video 是否泄漏？看 MoT attention mask
        ↓
Action 只能看 prompt/image，Video 完全隔离，因此 action/video loss 基本不直接泄漏 GT
        ↓
token logits 是否泄漏？看 causal mask 和 label shift
        ↓
如果 position t 只能看 <=t token，则是标准 teacher forcing，不是非法未来泄漏
        ↓
推理阶段没有 GT motion tokens，因此需要 prompt-only 输入
        ↓
当前 inference_step 没有 AR generation loop
        ↓
所以当前是 auxiliary token supervision，不是完整 motion-token generation pipeline
```

最终结论：

> 当前代码在训练上可以支持 motion-token teacher-forced auxiliary supervision；在 action/video 分支上通过 mask 基本规避了 GT token 直接泄漏；但如果研究目标是让 VLM 根据 image + prompt 在推理阶段生成完整 motion token sequence，则还需要补充 autoregressive generation 与后处理闭环。

# RoboTwin Task-Reweighted Stage2 Training

This experiment initializes model parameters from a pre-trained weights
directory, creates a fresh optimizer and scheduler, and trains RoboTwin Stage2
from global step 0 to 40,000 with a task-reweighted mixture.

Both the weighted and uniform-control YAML files are self-contained. They do
not inherit from the original Stage2 configuration.

## Weight Directory

The input directory must contain:

```text
pretrained_weights_dir/
  mp_rank_00_model_states.pt
  config.json
```

Only model parameters are loaded. Optimizer state, scheduler state, and global
step are not restored. All same-name, same-shape parameters are loaded.
Pretrain/finetune layers with different shapes remain initialized by the
current model. Training aborts if less than 80% of model parameter volume is
compatible.

## Recommended Run

Validate paths, task names, sampling probabilities, and distributed settings:

```bash
DRY_RUN=1 bash scripts/train_ADS_MotusV2_robotwin_reweight_posttrain.sh \
  /path/to/pretrained_weights_dir
```

Start the 40k run:

```bash
bash scripts/train_ADS_MotusV2_robotwin_reweight_posttrain.sh \
  /path/to/pretrained_weights_dir
```

Common overrides:

```bash
CUDA_VISIBLE_DEVICES=0,1,2,3 \
NPROC_PER_NODE=4 \
RUN_NAME=robotwin_reweight_40k_seed_a \
bash scripts/train_ADS_MotusV2_robotwin_reweight_posttrain.sh \
  /path/to/pretrained_weights_dir
```

## Sampling Definition

The additive mixture is:

- 60% uniform over all 50 tasks.
- 25% replay mass over tasks with robust early-to-late regression.
- 10% over late-learning tasks.
- 5% over stable anchor tasks.

Every task retains non-zero probability through the uniform component. Group
masses are distributed uniformly over each group's tasks. Validation sampling
remains uniform.

Inspect exact probabilities without loading model weights:

```bash
python scripts/inspect_robotwin_task_sampling.py \
  --config configs/robotwin_wan_vlm_mask_stage2_reweight_posttrain.yaml \
  --tasks-file policy/MotusWanVlmDirectMaskMotion/tasks_all_new.txt
```

## Uniform Control

Use identical initialization and optimization settings with uniform task
sampling:

```bash
CONFIG_FILE=configs/robotwin_wan_vlm_mask_stage2_uniform_posttrain.yaml \
RUN_NAME=robotwin_uniform_40k \
bash scripts/train_ADS_MotusV2_robotwin_reweight_posttrain.sh \
  /path/to/pretrained_weights_dir
```

Evaluate the 10k, 20k, 30k, and 40k checkpoints using identical RoboTwin seeds.
The weighted run is useful only if regression tasks improve without reducing
the stable-anchor average or the overall 50-task mean.

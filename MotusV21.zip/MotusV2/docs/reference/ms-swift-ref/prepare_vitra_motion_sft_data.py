#!/usr/bin/env python3
# Copyright (c) VITRA Motion SFT Experiment Contributors. All rights reserved.
"""Prepare VITRA-1M npy episodes into ms-swift Qwen3-VL image-only SFT data.

Each episode is expanded into multiple SFT samples by (episode, hand, text segment).
Wrist trajectories are transformed to first-frame camera coordinate system,
then discretized into motion tokens.

Usage:
    # Inspect mode
    python scripts/prepare_vitra_motion_sft_data.py \
        --data_root /cache/wx1469573/data/VITRA-1M \
        --output_dir /cache/wx1469573/data/VITRA-1M-ms-swift-motion-sft \
        --inspect_only --max_inspect 20

    # Smoke test (with video first-frame extraction)
    python scripts/prepare_vitra_motion_sft_data.py \
        --data_root /cache/wx1469573/data/VITRA-1M \
        --video_root /cache/wx1469573/data/VITRA-1M/Video \
        --output_dir /cache/wx1469573/data/VITRA-1M-ms-swift-motion-sft-smoke \
        --max_files 100

    # Smoke test (text-only, no video extraction)
    python scripts/prepare_vitra_motion_sft_data.py \
        --data_root /cache/wx1469573/data/VITRA-1M \
        --output_dir /cache/wx1469573/data/VITRA-1M-ms-swift-motion-sft-smoke \
        --max_files 100 --allow_text_only true

    # Full processing
python scripts/prepare_vitra_motion_sft_data.py \
    --data_root /cache/wx1469573/data/VITRA-1M \
    --video_root /cache/wx1469573/data/VITRA-1M/Video \
    --output_dir /cache/wx1469573/data/VITRA-1M-ms-swift-motion-sft \
    --num_workers 8
"""

import argparse
import json
import logging
import os
import random
import sys
import time
from collections import defaultdict
from functools import partial
from multiprocessing import Pool
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

# Add scripts dir to path for imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from motion_tokenizer import WristMotionTokenizer, transform_points_world_to_first_cam

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)


# ------------------------------------------------------------------
# Video first-frame extraction
# ------------------------------------------------------------------

# Mapping from npy path dataset prefix to Video subdirectory
_DATASET_TO_VIDEO_SUBDIR = {
    "ego4d": "Ego4D_root",
    "egoexo4d": "Ego4D_root",
    "epic": "Epic-Kitchen_root",
    "somethingsomething": "Somethingsomething-v2_root",
    "ssv2": "Somethingsomething-v2_root",
}


def _resolve_video_subdir(npy_path: str) -> Optional[str]:
    """Determine which Video subdirectory an npy file belongs to.

    Uses the dataset prefix in the npy filename or parent directory name.
    """
    # Try from npy filename prefix (e.g. Ego4D_xxx.npy, epic_kitchens_xxx.npy)
    basename = os.path.basename(npy_path).lower()
    for prefix, subdir in _DATASET_TO_VIDEO_SUBDIR.items():
        if basename.startswith(prefix):
            return subdir

    # Try from parent directory name (e.g. ego4d_cooking_and_cleaning)
    parent = os.path.basename(os.path.dirname(npy_path)).lower()
    for prefix, subdir in _DATASET_TO_VIDEO_SUBDIR.items():
        if parent.startswith(prefix):
            return subdir

    # Try from grandparent directory name (e.g. ego4d_other)
    grandparent = os.path.basename(os.path.dirname(os.path.dirname(npy_path))).lower()
    for prefix, subdir in _DATASET_TO_VIDEO_SUBDIR.items():
        if grandparent.startswith(prefix):
            return subdir

    return None


def _find_video_part_path(
    video_root: str,
    video_subdir: str,
    video_name: str,
    first_frame_idx: int,
    frames_per_part: int = 2000,
) -> Tuple[Optional[str], int]:
    """Find the video clip part file and the frame index within that part.

    Videos were split into clips of at most `frames_per_part` frames each,
    named as {video_name}_part{part_index}.mp4 where part_index starts from 1.

    Args:
        video_root: Root directory of videos (e.g. .../VITRA-1M/Video).
        video_subdir: Subdirectory name (e.g. Ego4D_root).
        video_name: Original video name from npy metadata.
        first_frame_idx: Frame index in the original (unsplit) video.
        frames_per_part: Max frames per part clip.

    Returns:
        (video_part_path, frame_index_within_part) or (None, 0) if not found.
    """
    part_index = first_frame_idx // frames_per_part + 1  # 1-indexed
    frame_in_part = first_frame_idx % frames_per_part

    part_filename = f"{video_name}_part{part_index}.mp4"
    part_path = os.path.join(video_root, video_subdir, part_filename)

    if os.path.isfile(part_path):
        return part_path, frame_in_part

    return None, 0


class FirstFrameExtractor:
    """Extracts and caches first-frame images from VITRA-1M video clips.

    Extracted images are saved to {output_dir}/first_frame_images/ with naming:
        {video_name}_part{N}_frame{M:06d}.jpg

    The cache avoids re-extracting the same frame across episodes that share
    a video clip.
    """

    def __init__(self, video_root: str, output_dir: str):
        self.video_root = video_root
        self.images_dir = os.path.join(output_dir, "first_frame_images")
        os.makedirs(self.images_dir, exist_ok=True)
        # Cache: (video_name, first_frame_idx) -> image_path
        self._cache: Dict[Tuple[str, int], Optional[str]] = {}
        self._extract_count = 0
        self._cache_hit_count = 0

    def extract(
        self,
        npy_path: str,
        video_name: str,
        first_frame_idx: int,
    ) -> Optional[str]:
        """Extract first-frame image, using cache if available.

        Returns:
            Absolute path to the extracted image, or None if extraction fails.
        """
        cache_key = (video_name, first_frame_idx)
        if cache_key in self._cache:
            self._cache_hit_count += 1
            return self._cache[cache_key]

        # Check if image already exists on disk (from a previous run)
        img_filename = f"{video_name}_frame{first_frame_idx:06d}.jpg"
        img_path = os.path.join(self.images_dir, img_filename)
        if os.path.isfile(img_path):
            self._cache_hit_count += 1
            self._cache[cache_key] = os.path.abspath(img_path)
            return self._cache[cache_key]

        # Resolve which Video subdir and which part clip
        video_subdir = _resolve_video_subdir(npy_path)
        if video_subdir is None:
            logger.warning(f"Cannot resolve video subdir for npy: {npy_path}")
            self._cache[cache_key] = None
            return None

        part_path, frame_in_part = _find_video_part_path(
            self.video_root, video_subdir, video_name, first_frame_idx,
        )
        if part_path is None:
            logger.debug(
                f"Video part not found: {video_name} frame={first_frame_idx} "
                f"subdir={video_subdir}"
            )
            self._cache[cache_key] = None
            return None

        # Extract frame using cv2
        try:
            import cv2
            cap = cv2.VideoCapture(part_path)
            cap.set(cv2.CAP_PROP_POS_FRAMES, frame_in_part)
            ret, frame = cap.read()
            cap.release()

            if not ret or frame is None:
                logger.warning(
                    f"Failed to read frame {frame_in_part} from {part_path}"
                )
                self._cache[cache_key] = None
                return None

            cv2.imwrite(img_path, frame)
            self._extract_count += 1
            self._cache[cache_key] = os.path.abspath(img_path)
            return self._cache[cache_key]

        except Exception as e:
            logger.warning(f"Error extracting frame from {part_path}: {e}")
            self._cache[cache_key] = None
            return None

    @property
    def stats(self) -> Dict[str, int]:
        return {
            "frames_extracted": self._extract_count,
            "cache_hits": self._cache_hit_count,
        }


# ------------------------------------------------------------------
# NPY loading
# ------------------------------------------------------------------

def load_episode(npy_path: str) -> Optional[Dict[str, Any]]:
    """Load a single npy episode file.

    Args:
        npy_path: Path to .npy file.

    Returns:
        Episode dict if successful, None otherwise.
    """
    try:
        raw = np.load(npy_path, allow_pickle=True)
        if isinstance(raw, dict):
            return raw
        # numpy object array -> .item()
        if hasattr(raw, "item"):
            obj = raw.item()
            if isinstance(obj, dict):
                return obj
        logger.warning(f"Cannot parse as dict: {npy_path} (type={type(raw).__name__})")
        return None
    except Exception as e:
        logger.warning(f"Failed to load {npy_path}: {e}")
        return None


# ------------------------------------------------------------------
# Inspect mode
# ------------------------------------------------------------------

def inspect_episodes(npy_files: List[str], max_inspect: int) -> None:
    """Print summary info for the first N npy files."""
    for i, path in enumerate(npy_files[:max_inspect]):
        print(f"\n--- [{i + 1}/{min(max_inspect, len(npy_files))}] {path} ---")
        ep = load_episode(path)
        if ep is None:
            print("  FAILED to load")
            continue

        print(f"  Top-level keys: {list(ep.keys())}")
        print(f"  video_name: {ep.get('video_name', 'N/A')}")
        print(f"  anno_type: {ep.get('anno_type', 'N/A')}")

        ext = ep.get("extrinsics")
        if hasattr(ext, "shape"):
            print(f"  extrinsics shape: {ext.shape}")
        else:
            print(f"  extrinsics: {type(ext).__name__}")

        intr = ep.get("intrinsics")
        if hasattr(intr, "shape"):
            print(f"  intrinsics shape: {intr.shape}")

        vdf = ep.get("video_decode_frame")
        if hasattr(vdf, "shape"):
            print(f"  video_decode_frame: shape={vdf.shape}, first few={vdf[:5]}")
        elif isinstance(vdf, list):
            print(f"  video_decode_frame: len={len(vdf)}, first few={vdf[:5]}")

        for hand in ["left", "right"]:
            text_entries = ep.get("text", {}).get(hand, [])
            rephrase_entries = ep.get("text_rephrase", {}).get(hand, [])
            print(f"  text[{hand}]: {len(text_entries)} entries")
            print(f"  text_rephrase[{hand}]: {len(rephrase_entries)} entries")

            hand_data = ep.get(hand, {})
            for field_name in ["transl_worldspace", "transl_camspace", "kept_frames"]:
                val = hand_data.get(field_name)
                if val is not None and hasattr(val, "shape"):
                    print(f"  {hand}.{field_name}: shape={val.shape}")
                elif val is not None:
                    print(f"  {hand}.{field_name}: type={type(val).__name__}")
                else:
                    print(f"  {hand}.{field_name}: MISSING")


# ------------------------------------------------------------------
# Trajectory extraction
# ------------------------------------------------------------------

def get_trajectory(
    episode_info: Dict[str, Any],
    hand: str,
    start: int,
    end: int,
    traj_space: str,
) -> Tuple[Optional[np.ndarray], str]:
    """Extract trajectory segment in the desired coordinate space.

    Args:
        episode_info: Episode dictionary.
        hand: "left" or "right".
        start: Start frame index (inclusive).
        end: End frame index (exclusive).
        traj_space: "first_frame_camspace" or "camspace_per_frame".

    Returns:
        (trajectory_array [T_seg, 3], traj_space_label)
        trajectory_array is None if extraction fails.
    """
    hand_data = episode_info.get(hand, {})
    T = len(hand_data.get("transl_camspace", []))

    if traj_space == "camspace_per_frame":
        traj = hand_data.get("transl_camspace")
        if traj is None:
            return None, "camspace_per_frame"
        return traj[start:end].astype(np.float32), "camspace_per_frame"

    # Default: first_frame_camspace
    transl_worldspace = hand_data.get("transl_worldspace")
    extrinsics = episode_info.get("extrinsics")

    if transl_worldspace is not None and extrinsics is not None:
        try:
            full_traj = transform_points_world_to_first_cam(
                transl_worldspace.astype(np.float32),
                extrinsics,
            )
            return full_traj[start:end], "first_frame_camspace"
        except Exception as e:
            logger.warning(
                f"first_frame_camspace transform failed: {e}. "
                f"Falling back to camspace_per_frame."
            )

    # Fallback to camspace_per_frame
    traj = hand_data.get("transl_camspace")
    if traj is not None:
        return traj[start:end].astype(np.float32), "camspace_per_frame_fallback"

    return None, "none"


# ------------------------------------------------------------------
# Text description extraction
# ------------------------------------------------------------------

def get_text_segments(
    episode_info: Dict[str, Any],
    hand: str,
    rephrase_mode: str,
    min_traj_len: int,
    allow_anno_type_fallback: bool = False,
    allow_default_instruction_fallback: bool = False,
) -> Tuple[List[Dict[str, Any]], bool]:
    """Extract text segments for a hand, with description and time interval.

    Priority:
      1. text_rephrase[hand]
      2. text[hand]
      3. anno_type (only if allow_anno_type_fallback=True and anno_type is not generic)
      4. default instruction (only if allow_default_instruction_fallback=True)

    Args:
        episode_info: Episode dictionary.
        hand: "left" or "right".
        rephrase_mode: "first", "all", or "random".
        min_traj_len: Minimum trajectory length to accept.
        allow_anno_type_fallback: Allow using anno_type as fallback description.
        allow_default_instruction_fallback: Allow using a default instruction as fallback.

    Returns:
        (segments, no_description_skipped)
        segments: List of dicts with keys: description, start, end, source.
        no_description_skipped: True if this hand was skipped due to no available description.
    """
    # Generic anno_type values that are NOT valid task descriptions
    GENERIC_ANNO_TYPES = {"left", "right", "both", "hand", ""}

    segments: List[Dict[str, Any]] = []
    text_rephrase = episode_info.get("text_rephrase", {}).get(hand, [])
    text = episode_info.get("text", {}).get(hand, [])

    # Try text_rephrase first
    if text_rephrase:
        for entry in text_rephrase:
            if not isinstance(entry, (list, tuple)) or len(entry) < 2:
                continue
            descriptions, interval = entry[0], entry[1]
            if not isinstance(interval, (list, tuple)) or len(interval) < 2:
                continue
            start, end = int(interval[0]), int(interval[1])
            if end <= start:
                continue
            if end - start < min_traj_len:
                continue
            if not descriptions:
                continue

            if rephrase_mode == "first":
                desc = descriptions[0].strip()
                if desc:
                    segments.append({
                        "description": desc, "start": start, "end": end,
                        "source": "text_rephrase",
                    })
            elif rephrase_mode == "all":
                for d in descriptions:
                    d = d.strip()
                    if d:
                        segments.append({
                            "description": d, "start": start, "end": end,
                            "source": "text_rephrase",
                        })
            elif rephrase_mode == "random":
                d = random.choice(descriptions).strip()
                if d:
                    segments.append({
                        "description": d, "start": start, "end": end,
                        "source": "text_rephrase",
                    })
        if segments:
            return segments, False

    # Fallback to text
    if text:
        for entry in text:
            if not isinstance(entry, (list, tuple)) or len(entry) < 2:
                continue
            description, interval = entry[0], entry[1]
            if not isinstance(interval, (list, tuple)) or len(interval) < 2:
                continue
            start, end = int(interval[0]), int(interval[1])
            if end <= start:
                continue
            if end - start < min_traj_len:
                continue
            desc = description.strip()
            if not desc:
                continue
            segments.append({
                "description": desc, "start": start, "end": end,
                "source": "text",
            })
        if segments:
            return segments, False

    # No text_rephrase or text available for this hand
    # Only fallback to anno_type/default if explicitly allowed

    anno_type = episode_info.get("anno_type", "")
    anno_type_stripped = anno_type.strip() if anno_type else ""
    default_instruction = "Predict the 3D wrist motion trajectory for this hand."

    if allow_anno_type_fallback and anno_type_stripped and anno_type_stripped.lower() not in GENERIC_ANNO_TYPES:
        hand_data = episode_info.get(hand, {})
        traj = hand_data.get("transl_camspace")
        if traj is not None and len(traj) >= min_traj_len:
            segments.append({
                "description": anno_type_stripped, "start": 0, "end": len(traj),
                "source": "anno_type",
            })
            return segments, False

    if allow_default_instruction_fallback:
        hand_data = episode_info.get(hand, {})
        traj = hand_data.get("transl_camspace")
        if traj is not None and len(traj) >= min_traj_len:
            segments.append({
                "description": default_instruction, "start": 0, "end": len(traj),
                "source": "default_instruction",
            })
            return segments, False

    return segments, True


# ------------------------------------------------------------------
# Sample generation
# ------------------------------------------------------------------

def generate_samples(
    episode_info: Dict[str, Any],
    npy_path: str,
    motion_tokenizer: WristMotionTokenizer,
    config: Dict[str, Any],
) -> Tuple[List[Dict[str, Any]], Dict[str, int]]:
    """Generate SFT samples from a single episode.

    Args:
        config: Dict with keys: rephrase_mode, min_traj_len, max_traj_len,
            allow_anno_type_fallback, allow_default_instruction_fallback,
            traj_space, min_valid_ratio, invalid_frame_policy,
            downsample_policy, allow_text_only, require_image,
            frame_extractor (FirstFrameExtractor or None).

    Returns:
        (samples_list, per_episode_stats_dict)
    """
    samples: List[Dict[str, Any]] = []
    stats: Dict[str, int] = defaultdict(int)

    # Episode-level info
    video_name = str(episode_info.get("video_name", ""))
    anno_type = str(episode_info.get("anno_type", ""))
    avg_speed = float(episode_info.get("avg_speed", 0.0))
    total_rotvec_degree = float(episode_info.get("total_rotvec_degree", 0.0))
    total_transl_dist = float(episode_info.get("total_transl_dist", 0.0))

    vdf = episode_info.get("video_decode_frame")
    if vdf is not None and len(vdf) > 0:
        first_frame_idx = int(vdf[0])
    else:
        first_frame_idx = 0

    # Extract first-frame image
    frame_extractor = config.get("frame_extractor")
    image_path = None
    if frame_extractor is not None:
        image_path = frame_extractor.extract(npy_path, video_name, first_frame_idx)
    has_image = image_path is not None

    for hand in ["left", "right"]:
        hand_data = episode_info.get(hand, {})
        kept_frames = hand_data.get("kept_frames")

        # Get text segments
        segments, no_desc_skipped = get_text_segments(
            episode_info, hand, config["rephrase_mode"], config["min_traj_len"],
            allow_anno_type_fallback=config["allow_anno_type_fallback"],
            allow_default_instruction_fallback=config["allow_default_instruction_fallback"],
        )

        if no_desc_skipped:
            stats["skip_no_text_description"] += 1
            continue

        for seg in segments:
            start, end = seg["start"], seg["end"]
            description = seg["description"]
            source = seg["source"]

            # Clip start/end to valid range
            hand_traj = hand_data.get("transl_camspace")
            if hand_traj is not None:
                T = len(hand_traj)
            else:
                continue

            if start < 0 or end > T:
                start = max(0, start)
                end = min(T, end)

            if end - start < config["min_traj_len"]:
                stats["skip_too_short"] += 1
                continue

            # Check kept_frames validity
            if kept_frames is not None:
                kept_arr = np.asarray(kept_frames, dtype=np.int8)
                segment_mask = kept_arr[start:end]
                valid_ratio = float(np.mean(segment_mask == 1))
            else:
                valid_ratio = 1.0  # No mask, assume all valid

            if valid_ratio < config["min_valid_ratio"]:
                stats["skip_low_valid_ratio"] += 1
                continue

            # Handle invalid frames
            if config["invalid_frame_policy"] == "filter_invalid" and kept_frames is not None:
                filter_invalid = True
            else:
                filter_invalid = False

            # Extract trajectory
            traj, traj_space_label = get_trajectory(
                episode_info, hand, start, end, config["traj_space"]
            )

            if traj is None:
                stats["skip_no_trajectory"] += 1
                continue

            if traj_space_label == "camspace_per_frame_fallback":
                stats["camspace_per_frame_fallback"] += 1

            # Filter invalid frames if requested
            if filter_invalid and kept_frames is not None:
                valid_mask = np.asarray(kept_frames[start:end], dtype=bool)
                traj = traj[valid_mask]

            # Trajectory length control
            traj_len = len(traj)
            if traj_len < config["min_traj_len"]:
                stats["skip_too_short_after_filter"] += 1
                continue

            if traj_len > config["max_traj_len"]:
                if config["downsample_policy"] == "uniform":
                    indices = np.linspace(0, traj_len - 1, config["max_traj_len"], dtype=int)
                    traj = traj[indices]
                    traj_len = config["max_traj_len"]
                    stats["downsampled"] += 1

            # Check for NaN/Inf
            if not np.isfinite(traj).all():
                stats["skip_non_finite_trajectory"] += 1
                continue

            # Motion tokenization
            motion_tokens_str = motion_tokenizer.encode_token_string(traj)
            motion_token_len = traj_len * 3

            # Clipping stats
            clip_stats = motion_tokenizer.clipping_stats(traj)

            # Build image field
            if has_image:
                images = [image_path]
                user_content = (
                    f"<image>\n"
                    f"Task: {description}\n"
                    f"Hand: {hand}.\n"
                    f"Predict the 3D wrist motion trajectory for this hand in the "
                    f"first-frame camera coordinate system. Return only motion tokens."
                )
                image_missing = False
            elif config["require_image"]:
                stats["skip_require_image"] += 1
                continue
            elif config["allow_text_only"]:
                user_content = (
                    f"Task: {description}\n"
                    f"Hand: {hand}.\n"
                    f"Predict the 3D wrist motion trajectory for this hand in the "
                    f"first-frame camera coordinate system. Return only motion tokens."
                )
                image_missing = True
                images = None
            else:
                stats["skip_no_image"] += 1
                continue

            sample = {
                "messages": [
                    {"role": "user", "content": user_content},
                    {"role": "assistant", "content": motion_tokens_str},
                ],
                "metadata": {
                    "source_npy": npy_path,
                    "video_name": video_name,
                    "first_frame_idx": first_frame_idx,
                    "image_path": image_path,
                    "image_missing": image_missing,
                    "hand": hand,
                    "start_frame": start,
                    "end_frame": end,
                    "description": description,
                    "anno_type": anno_type,
                    "traj_space": traj_space_label,
                    "traj_len": traj_len,
                    "motion_token_len": motion_token_len,
                    "valid_ratio": round(valid_ratio, 4),
                    "avg_speed": round(avg_speed, 6),
                    "total_rotvec_degree": round(total_rotvec_degree, 6),
                    "total_transl_dist": round(total_transl_dist, 6),
                    "text_source": source,
                    "clipping_x_below": round(clip_stats["x"]["below"], 6),
                    "clipping_x_above": round(clip_stats["x"]["above"], 6),
                    "clipping_y_below": round(clip_stats["y"]["below"], 6),
                    "clipping_y_above": round(clip_stats["y"]["above"], 6),
                    "clipping_z_below": round(clip_stats["z"]["below"], 6),
                    "clipping_z_above": round(clip_stats["z"]["above"], 6),
                },
            }
            if images is not None:
                sample["images"] = images

            samples.append(sample)
            stats["total"] += 1

            if source == "text_rephrase":
                stats["text_rephrase"] += 1
            elif source == "text":
                stats["text_source"] += 1
            elif source == "anno_type":
                stats["anno_type_fallback"] += 1
            else:
                stats["default_instruction_fallback"] += 1

            if hand == "left":
                stats["left"] += 1
            else:
                stats["right"] += 1

            if has_image:
                stats["has_image"] += 1
            else:
                stats["no_image"] += 1

            # Accumulate clipping stats
            for axis in ["x", "y", "z"]:
                for direction in ["below", "above"]:
                    key = f"clipping_{axis}_{direction}"
                    stats[key] = stats.get(key, 0.0) + clip_stats[axis][direction]

            if traj_space_label == "first_frame_camspace":
                stats["traj_first_frame_camspace"] += 1
            elif traj_space_label == "camspace_per_frame":
                stats["traj_camspace_per_frame"] += 1
            elif traj_space_label == "camspace_per_frame_fallback":
                stats["traj_camspace_per_frame_fallback"] += 1

    return samples, dict(stats)


# ------------------------------------------------------------------
# Report generation
# ------------------------------------------------------------------

def build_report(
    all_samples: List[Dict[str, Any]],
    total_npy: int,
    parsed_count: int,
    skip_reasons: Dict[str, int],
    per_episode_stats: List[Dict[str, int]],
    val_ratio: float,
    seed: int,
    train_count: int,
    val_count: int,
) -> Dict[str, Any]:
    """Build the preprocess_report.json content."""
    report: Dict[str, Any] = {
        "total_npy_files": total_npy,
        "parsed_episode_count": parsed_count,
        "success_sample_count": len(all_samples),
        "skipped_episode_count": total_npy - parsed_count,
        "skipped_sample_count": int(sum(skip_reasons.values())),
        "skip_reasons": dict(skip_reasons),
    }

    # Text stats
    text_rephrase_count = sum(
        1 for s in all_samples if s["metadata"]["text_source"] == "text_rephrase"
    )
    text_count = sum(
        1 for s in all_samples if s["metadata"]["text_source"] == "text"
    )
    anno_type_count = sum(
        1 for s in all_samples if s["metadata"]["text_source"] == "anno_type"
    )
    default_count = sum(
        1 for s in all_samples if s["metadata"]["text_source"] == "default_instruction"
    )
    left_count = sum(1 for s in all_samples if s["metadata"]["hand"] == "left")
    right_count = sum(1 for s in all_samples if s["metadata"]["hand"] == "right")

    report.update({
        "text_rephrase_sample_count": text_rephrase_count,
        "text_sample_count": text_count,
        "anno_type_fallback_count": anno_type_count,
        "default_instruction_fallback_count": default_count,
        "left_sample_count": left_count,
        "right_sample_count": right_count,
    })

    # Trajectory stats
    traj_lens = [s["metadata"]["traj_len"] for s in all_samples]
    token_lens = [s["metadata"]["motion_token_len"] for s in all_samples]

    report.update({
        "traj_len_min": min(traj_lens) if traj_lens else 0,
        "traj_len_mean": float(np.mean(traj_lens)) if traj_lens else 0,
        "traj_len_max": max(traj_lens) if traj_lens else 0,
        "motion_token_len_min": min(token_lens) if token_lens else 0,
        "motion_token_len_mean": float(np.mean(token_lens)) if token_lens else 0,
        "motion_token_len_max": max(token_lens) if token_lens else 0,
    })

    # Traj space stats
    traj_space_counts = defaultdict(int)
    for s in all_samples:
        traj_space_counts[s["metadata"]["traj_space"]] += 1
    report["traj_space_first_frame_camspace_count"] = traj_space_counts.get(
        "first_frame_camspace", 0
    )
    report["traj_space_camspace_per_frame_count"] = traj_space_counts.get(
        "camspace_per_frame", 0
    )
    report["traj_space_camspace_per_frame_fallback_count"] = traj_space_counts.get(
        "camspace_per_frame_fallback", 0
    )

    # Valid ratio
    valid_ratios = [s["metadata"]["valid_ratio"] for s in all_samples]
    report["valid_ratio_mean"] = float(np.mean(valid_ratios)) if valid_ratios else 0

    # Downsampled
    downsampled = sum(ep_stats.get("downsampled", 0) for ep_stats in per_episode_stats)
    report["downsampled_count"] = downsampled

    # Clipping stats (mean across all samples)
    n_samples = len(all_samples)
    if n_samples > 0:
        for axis in ["x", "y", "z"]:
            for direction in ["below", "above"]:
                key = f"clipping_{axis}_{direction}"
                values = [s["metadata"][key] for s in all_samples]
                report[f"mean_clipping_ratio_{axis}_{direction}"] = round(
                    float(np.mean(values)), 6
                )
    else:
        for axis in ["x", "y", "z"]:
            for direction in ["below", "above"]:
                report[f"mean_clipping_ratio_{axis}_{direction}"] = 0.0

    # Image stats
    image_count = sum(1 for s in all_samples if not s["metadata"]["image_missing"])
    no_image_count = sum(1 for s in all_samples if s["metadata"]["image_missing"])
    report.update({
        "image_count": image_count,
        "no_image_count": no_image_count,
        "require_image_skip_count": skip_reasons.get("skip_require_image", 0),
    })

    # Data split
    report.update({
        "train_count": train_count,
        "val_count": val_count,
        "val_ratio": val_ratio,
        "seed": seed,
    })

    return report


# ------------------------------------------------------------------
# Main
# ------------------------------------------------------------------

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Prepare VITRA-1M npy data into ms-swift SFT format"
    )
    parser.add_argument("--data_root", type=str, default="/cache/wx1469573/data/VITRA-1M")
    parser.add_argument("--output_dir", type=str, default="/cache/wx1469573/data/VITRA-1M-ms-swift-motion-sft")
    parser.add_argument("--video_root", type=str, default=None,
                        help="Root directory of VITRA-1M videos (e.g. .../VITRA-1M/Video). "
                             "If provided, first-frame images are extracted from video clips.")
    parser.add_argument("--val_ratio", type=float, default=0.02)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--inspect_only", action="store_true")
    parser.add_argument("--max_inspect", type=int, default=20)
    parser.add_argument("--max_files", type=int, default=None)
    parser.add_argument("--max_samples", type=int, default=None)
    parser.add_argument("--rephrase_mode", type=str, default="first", choices=["first", "all", "random"])
    parser.add_argument("--traj_space", type=str, default="first_frame_camspace",
                        choices=["first_frame_camspace", "camspace_per_frame"])
    parser.add_argument("--min_valid_ratio", type=float, default=0.8)
    parser.add_argument("--invalid_frame_policy", type=str, default="skip_segment",
                        choices=["skip_segment", "filter_invalid"])
    parser.add_argument("--min_traj_len", type=int, default=4)
    parser.add_argument("--max_traj_len", type=int, default=128)
    parser.add_argument("--downsample_policy", type=str, default="uniform",
                        choices=["uniform", "none"])
    parser.add_argument("--allow_text_only", type=str, default="true",
                        help="true/false string")
    parser.add_argument("--require_image", type=str, default="false",
                        help="true/false string")
    parser.add_argument("--allow_anno_type_fallback", type=str, default="false",
                        help="true/false. Allow using anno_type as fallback description. "
                             "Generic values like 'left'/'right'/'both' are always filtered.")
    parser.add_argument("--allow_default_instruction_fallback", type=str, default="false",
                        help="true/false. Allow using a default instruction when no text description is available.")
    parser.add_argument("--num_bins", type=int, default=1024)
    parser.add_argument("--x_min", type=float, default=-0.5)
    parser.add_argument("--x_max", type=float, default=0.5)
    parser.add_argument("--y_min", type=float, default=-0.5)
    parser.add_argument("--y_max", type=float, default=0.5)
    parser.add_argument("--z_min", type=float, default=0.0)
    parser.add_argument("--z_max", type=float, default=1.0)
    parser.add_argument("--num_workers", type=int, default=1,
                        help="Number of parallel workers for data processing. "
                             "Use >1 for multi-core speedup (e.g. 8 or 16).")
    return parser.parse_args()


def _process_one_npy(
    npy_path: str,
    config: Dict[str, Any],
    motion_tokenizer_config: Dict[str, Any],
) -> Tuple[List[Dict[str, Any]], Dict[str, int]]:
    """Worker function: load one npy, generate samples.

    Args:
        npy_path: Path to .npy file.
        config: Processing config dict (same keys as generate_samples expects).
        motion_tokenizer_config: Dict with keys: num_bins, x_range, y_range, z_range.

    Returns:
        (samples_list, stats_dict). stats_dict includes 'load_failed' if npy
        could not be loaded.
    """
    # Each worker creates its own tokenizer and frame extractor instances
    # to avoid pickling / shared-state issues.
    motion_tokenizer = WristMotionTokenizer(
        k=motion_tokenizer_config["num_bins"],
        x_range=tuple(motion_tokenizer_config["x_range"]),
        y_range=tuple(motion_tokenizer_config["y_range"]),
        z_range=tuple(motion_tokenizer_config["z_range"]),
    )

    video_root = config.get("video_root")
    output_dir = config.get("output_dir")
    if video_root and not config.get("_frame_extractor"):
        config = dict(config)  # copy to avoid mutating shared dict
        config["frame_extractor"] = FirstFrameExtractor(video_root, output_dir)

    episode_info = load_episode(npy_path)
    if episode_info is None:
        return [], {"load_failed": 1}

    samples, ep_stats = generate_samples(episode_info, npy_path, motion_tokenizer, config)
    return samples, ep_stats


def main() -> None:
    args = parse_args()
    args.allow_text_only = args.allow_text_only.lower() == "true"
    args.require_image = args.require_image.lower() == "true"
    args.allow_anno_type_fallback = args.allow_anno_type_fallback.lower() == "true"
    args.allow_default_instruction_fallback = args.allow_default_instruction_fallback.lower() == "true"

    # --- Validate video_root ---
    if args.video_root and not os.path.isdir(args.video_root):
        logger.error(f"--video_root not found: {args.video_root}")
        sys.exit(1)
    if args.video_root:
        logger.info(f"Video root: {args.video_root} (first-frame extraction enabled)")
    elif not args.allow_text_only:
        logger.warning(
            "--video_root not provided and --allow_text_only is false. "
            "All samples without images will be skipped."
        )

    # --- Collect npy files ---
    logger.info(f"Scanning npy files in: {args.data_root}")
    npy_files: List[str] = []
    for root, _dirs, files in os.walk(args.data_root):
        for f in files:
            if f.endswith(".npy"):
                npy_files.append(os.path.join(root, f))
    npy_files.sort()
    logger.info(f"Found {len(npy_files)} npy files")

    if args.max_files is not None:
        npy_files = npy_files[: args.max_files]
        logger.info(f"Limiting to {len(npy_files)} files (--max_files)")

    # --- Inspect mode ---
    if args.inspect_only:
        inspect_episodes(npy_files, args.max_inspect)
        return

    # --- Build config dicts for worker processes ---
    config: Dict[str, Any] = {
        "rephrase_mode": args.rephrase_mode,
        "min_traj_len": args.min_traj_len,
        "max_traj_len": args.max_traj_len,
        "allow_anno_type_fallback": args.allow_anno_type_fallback,
        "allow_default_instruction_fallback": args.allow_default_instruction_fallback,
        "traj_space": args.traj_space,
        "min_valid_ratio": args.min_valid_ratio,
        "invalid_frame_policy": args.invalid_frame_policy,
        "downsample_policy": args.downsample_policy,
        "allow_text_only": args.allow_text_only,
        "require_image": args.require_image,
        "video_root": args.video_root,
        "output_dir": args.output_dir,
        "frame_extractor": None,  # Workers create their own
    }

    motion_tokenizer_config: Dict[str, Any] = {
        "num_bins": args.num_bins,
        "x_range": [args.x_min, args.x_max],
        "y_range": [args.y_min, args.y_max],
        "z_range": [args.z_min, args.z_max],
    }

    # --- Process episodes ---
    random.seed(args.seed)
    all_samples: List[Dict[str, Any]] = []
    skip_reasons: Dict[str, int] = defaultdict(int)
    per_episode_stats: List[Dict[str, int]] = []
    parsed_count = 0
    load_fail_count = 0

    num_workers = max(1, args.num_workers)
    start_time = time.time()

    if num_workers == 1:
        # Single-process mode (no pickle overhead)
        motion_tokenizer = WristMotionTokenizer(
            k=args.num_bins,
            x_range=(args.x_min, args.x_max),
            y_range=(args.y_min, args.y_max),
            z_range=(args.z_min, args.z_max),
        )
        # Create single frame extractor for reuse
        if args.video_root:
            config["frame_extractor"] = FirstFrameExtractor(args.video_root, args.output_dir)

        for i, npy_path in enumerate(npy_files):
            if args.max_samples is not None and len(all_samples) >= args.max_samples:
                logger.info(f"Reached max_samples={args.max_samples}, stopping")
                break

            if (i + 1) % 1000 == 0:
                elapsed = time.time() - start_time
                logger.info(
                    f"Progress: {i + 1}/{len(npy_files)} files, "
                    f"{len(all_samples)} samples, {elapsed:.1f}s elapsed"
                )

            episode_info = load_episode(npy_path)
            if episode_info is None:
                load_fail_count += 1
                continue
            parsed_count += 1

            samples, ep_stats = generate_samples(
                episode_info, npy_path, motion_tokenizer, config
            )
            all_samples.extend(samples)
            per_episode_stats.append(ep_stats)

            for k, v in ep_stats.items():
                if k.startswith("skip_"):
                    skip_reasons[k] = skip_reasons.get(k, 0) + v

        # Collect frame extractor stats from single-process mode
        frame_extractor_stats = None
        if config.get("frame_extractor"):
            frame_extractor_stats = config["frame_extractor"].stats

    else:
        # Multi-process mode
        frame_extractor_stats = None  # Not available in multi-process mode
        logger.info(f"Using {num_workers} workers for parallel processing")
        worker_fn = partial(
            _process_one_npy,
            config=config,
            motion_tokenizer_config=motion_tokenizer_config,
        )

        total_files = len(npy_files)
        done_count = 0
        last_log_time = start_time

        with Pool(processes=num_workers) as pool:
            for samples, ep_stats in pool.imap_unordered(worker_fn, npy_files, chunksize=64):
                done_count += 1

                if "load_failed" in ep_stats:
                    load_fail_count += 1
                else:
                    parsed_count += 1
                    all_samples.extend(samples)
                    per_episode_stats.append(ep_stats)
                    for k, v in ep_stats.items():
                        if k.startswith("skip_"):
                            skip_reasons[k] = skip_reasons.get(k, 0) + v

                now = time.time()
                if now - last_log_time >= 10.0:  # Log every ~10s
                    elapsed = now - start_time
                    speed = done_count / elapsed if elapsed > 0 else 0
                    eta = (total_files - done_count) / speed if speed > 0 else 0
                    logger.info(
                        f"Progress: {done_count}/{total_files} files, "
                        f"{len(all_samples)} samples, "
                        f"{elapsed:.1f}s elapsed, ETA {eta:.0f}s "
                        f"({speed:.0f} files/s)"
                    )
                    last_log_time = now

                if args.max_samples is not None and len(all_samples) >= args.max_samples:
                    logger.info(f"Reached max_samples={args.max_samples}, stopping")
                    pool.terminate()
                    break

    skip_reasons["load_failed"] = load_fail_count

    logger.info(
        f"Processed {len(npy_files)} files -> {len(all_samples)} samples in "
        f"{time.time() - start_time:.1f}s"
    )

    # --- Train/val split ---
    random.shuffle(all_samples)
    val_count = int(len(all_samples) * args.val_ratio)
    train_count = len(all_samples) - val_count
    train_samples = all_samples[:train_count]
    val_samples = all_samples[train_count:]

    logger.info(f"Train: {train_count}, Val: {val_count}")

    # --- Save ---
    os.makedirs(args.output_dir, exist_ok=True)

    train_path = os.path.join(args.output_dir, "train.jsonl")
    val_path = os.path.join(args.output_dir, "val.jsonl")
    report_path = os.path.join(args.output_dir, "preprocess_report.json")

    for path, data in [(train_path, train_samples), (val_path, val_samples)]:
        with open(path, "w", encoding="utf-8") as f:
            for sample in data:
                f.write(json.dumps(sample, ensure_ascii=False) + "\n")
        logger.info(f"Saved {len(data)} samples to {path}")

    # --- Save report ---
    report = build_report(
        all_samples=all_samples,
        total_npy=len(npy_files),
        parsed_count=parsed_count,
        skip_reasons=dict(skip_reasons),
        per_episode_stats=per_episode_stats,
        val_ratio=args.val_ratio,
        seed=args.seed,
        train_count=train_count,
        val_count=val_count,
    )

    with open(report_path, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    logger.info(f"Saved report to {report_path}")

    # Add frame extractor stats to report if available
    if frame_extractor_stats is not None:
        report["frames_extracted"] = frame_extractor_stats["frames_extracted"]
        report["frame_cache_hits"] = frame_extractor_stats["cache_hits"]
        with open(report_path, "w", encoding="utf-8") as f:
            json.dump(report, f, ensure_ascii=False, indent=2)

    # --- Print summary ---
    print("\n" + "=" * 60)
    print("VITRA-1M Motion SFT Data Preparation - Summary")
    print("=" * 60)
    print(f"  NPY files scanned:    {report['total_npy_files']}")
    print(f"  Episodes parsed:      {report['parsed_episode_count']}")
    print(f"  Total samples:        {report['success_sample_count']}")
    print(f"  Skipped episodes:     {report['skipped_episode_count']}")
    print(f"  Skipped samples:      {report['skipped_sample_count']}")
    print(f"  Train samples:        {report['train_count']}")
    print(f"  Val samples:          {report['val_count']}")
    print(f"  With image:           {report['image_count']}")
    print(f"  Without image:        {report['no_image_count']}")
    print(f"  Traj len: [{report['traj_len_min']}, {report['traj_len_mean']:.1f}, {report['traj_len_max']}]")
    print(f"  Token len: [{report['motion_token_len_min']}, {report['motion_token_len_mean']:.1f}, {report['motion_token_len_max']}]")
    print(f"  First-frame cam:      {report['traj_space_first_frame_camspace_count']}")
    print(f"  Camspace fallback:    {report['traj_space_camspace_per_frame_fallback_count']}")
    for axis in ["x", "y", "z"]:
        for d in ["below", "above"]:
            k = f"mean_clipping_ratio_{axis}_{d}"
            print(f"  Clipping {axis} {d}: {report[k]:.4f}")
    if frame_extractor_stats is not None:
        print(f"  Frames extracted:     {frame_extractor_stats['frames_extracted']}")
        print(f"  Frame cache hits:     {frame_extractor_stats['cache_hits']}")
    print("=" * 60)


if __name__ == "__main__":
    main()

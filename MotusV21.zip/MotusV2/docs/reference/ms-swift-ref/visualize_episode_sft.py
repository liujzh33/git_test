#!/usr/bin/env python3
"""Visualize VITRA episode hand mesh + decoded motion token trajectory side-by-side as MP4.

For each SFT sample, generates 3 MP4 videos:
  1. {name}_original.mp4   – VITRA HandVisualizer rendering (cam + first modes)
  2. {name}_tokens.mp4     – Decoded motion token trajectory animation on first frame
  3. {name}_compare.mp4    – Side-by-side concatenation of 1 and 2

Usage:
python scripts/visualize_episode_sft.py \
    --data_dir /cache/wx1469573/data/VITRA-1M-ms-swift-motion-sft \
    --video_root /cache/wx1469573/data/VITRA-1M/Video \
    --output_dir /cache/wx1469573/data/VITRA-1M-ms-swift-motion-sft/episode_visualizations \
    --mano_model_path /home/ma-user/work/wx1469573/VITRA-main/weights/mano \
    --num_samples 10
"""

import argparse
import json
import os
import re
import sys
import tempfile
import random
from typing import Dict, List, Optional, Tuple

import cv2
import numpy as np

# Add VITRA root first (so visualization package is found)
VITRA_ROOT = "/home/ma-user/work/wx1469573/VITRA-main"
if VITRA_ROOT not in sys.path:
    sys.path.insert(0, VITRA_ROOT)

# Add scripts dir for motion_tokenizer
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from motion_tokenizer import WristMotionTokenizer, transform_points_world_to_first_cam

from visualization.visualize_core import HandVisualizer, Config, get_frame_interval, get_camera_info
from visualization.video_utils import read_video_frames, resize_frames_to_long_side, save_to_video


# ---------------------------------------------------------------------------
# Motion token parsing
# ---------------------------------------------------------------------------

_TOKEN_RE = re.compile(r"<\|motion_([xyz])_(\d+)\|>")


def parse_motion_tokens(text: str) -> np.ndarray:
    """Parse motion token string to bin indices array [T, 3]."""
    matches = _TOKEN_RE.findall(text)
    if not matches:
        return np.array([], dtype=np.int64).reshape(0, 3)
    indices = []
    current: Dict[str, int] = {}
    for axis, idx_str in matches:
        current[axis] = int(idx_str)
        if len(current) == 3:
            indices.append([current["x"], current["y"], current["z"]])
            current = {}
    if current:
        print(f"  Warning: incomplete triplet, dropping {len(current)} token(s)")
    return np.array(indices, dtype=np.int64)


# ---------------------------------------------------------------------------
# Video part resolution (same logic as prepare_vitra_motion_sft_data.py)
# ---------------------------------------------------------------------------

_DATASET_TO_VIDEO_SUBDIR = {
    "ego4d": "Ego4D_root",
    "egoexo4d": "Ego4D_root",
    "epic": "Epic-Kitchen_root",
    "somethingsomething": "Somethingsomething-v2_root",
    "ssv2": "Somethingsomething-v2_root",
}


def _resolve_video_subdir(npy_path: str) -> Optional[str]:
    basename = os.path.basename(npy_path)
    dirname = os.path.basename(os.path.dirname(npy_path))
    parentdir = os.path.basename(os.path.dirname(os.path.dirname(npy_path)))
    for candidate in [basename, dirname, parentdir]:
        prefix = candidate.split("_")[0].lower()
        for key, val in _DATASET_TO_VIDEO_SUBDIR.items():
            if prefix == key or key in candidate.lower():
                return val
    return None


def find_video_part_path(
    video_root: str, video_subdir: str, video_name: str,
    first_frame_idx: int, frames_per_part: int = 2000,
) -> Tuple[Optional[str], int]:
    part_index = first_frame_idx // frames_per_part + 1
    frame_in_part = first_frame_idx % frames_per_part
    subdir_path = os.path.join(video_root, video_subdir)

    candidates = [
        os.path.join(subdir_path, f"{video_name}_part{part_index}.mp4"),
        os.path.join(subdir_path, f"{video_name}_part{part_index}.MP4"),
    ]
    # Epic-Kitchen nested structure
    if "Epic" in video_subdir or "epic" in video_subdir:
        person_id = video_name.split("_")[0]
        candidates.insert(0, os.path.join(
            subdir_path, person_id, "videos",
            f"{video_name}_part{part_index}.MP4"
        ))
        candidates.insert(1, os.path.join(
            subdir_path, person_id, "videos",
            f"{video_name}_part{part_index}.mp4"
        ))

    for path in candidates:
        if os.path.exists(path):
            return path, frame_in_part
    return None, frame_in_part


def read_episode_video_frames(
    video_root: str, npy_path: str, video_name: str,
    start_frame: int, end_frame: int, frames_per_part: int = 2000,
) -> List[np.ndarray]:
    """Read video frames spanning possibly multiple parts."""
    video_subdir = _resolve_video_subdir(npy_path)
    if video_subdir is None:
        print(f"  Cannot resolve video subdir for {npy_path}")
        return []

    frames = []
    current_frame = start_frame
    while current_frame < end_frame:
        part_index = current_frame // frames_per_part + 1
        frame_in_part = current_frame % frames_per_part
        part_end = min(part_index * frames_per_part, end_frame)

        part_path, _ = find_video_part_path(
            video_root, video_subdir, video_name, current_frame, frames_per_part
        )
        if part_path is None:
            print(f"  Video part not found: {video_name} frame {current_frame}")
            # Fill with black frames
            frames.extend([np.zeros((480, 640, 3), dtype=np.uint8)] * (part_end - current_frame))
            current_frame = part_end
            continue

        cap = cv2.VideoCapture(part_path)
        cap.set(cv2.CAP_PROP_POS_FRAMES, frame_in_part)
        while current_frame < part_end:
            ret, frame = cap.read()
            if not ret:
                frames.append(np.zeros((480, 640, 3), dtype=np.uint8))
            else:
                frames.append(frame)
            current_frame += 1
        cap.release()

    return frames


# ---------------------------------------------------------------------------
# 1. Original hand visualization (using VITRA HandVisualizer)
# ---------------------------------------------------------------------------


def render_original_episode(
    visualizer: HandVisualizer,
    video_root: str,
    npy_path: str,
    output_path: str,
) -> Optional[str]:
    """Render original hand mesh visualization using VITRA's HandVisualizer.

    Generates an MP4 with cam + first modes side-by-side.
    """
    episode_info = np.load(npy_path, allow_pickle=True).item()
    video_name = episode_info["video_name"]
    start_frame, end_frame = get_frame_interval(episode_info)
    R_w2c, t_w2c, normalized_intrinsics = get_camera_info(episode_info)

    # Read video frames
    video_frames = read_episode_video_frames(
        video_root, npy_path, video_name, start_frame, end_frame
    )
    if not video_frames:
        print(f"  No video frames for {video_name}")
        return None

    resize_video_frames = resize_frames_to_long_side(video_frames, visualizer.config.RENDER_SIZE_LONG_SIDE)
    H, W, _ = resize_video_frames[0].shape

    # Initialize renderer
    intrinsics_denorm = normalized_intrinsics.copy()
    intrinsics_denorm[0] *= W
    intrinsics_denorm[1] *= H
    fx_exo = intrinsics_denorm[0, 0]
    fy_exo = intrinsics_denorm[1, 1]

    from visualization.render_utils import Renderer
    renderer = Renderer(W, H, (fx_exo, fy_exo), 'cuda')

    # Get hand labels
    from visualization.visualize_core import get_hand_labels, get_caption_info, generate_overlay_text, find_caption_index, generate_hand_colors
    from visualization.video_utils import add_overlay_text

    (verts_left_worldspace, left_hand_mask), (verts_right_worldspace, right_hand_mask) = \
        get_hand_labels(episode_info, visualizer.mano)
    caption_left, caption_right, hand_type = get_caption_info(episode_info)

    hand_traj_wordspace = (verts_left_worldspace, verts_right_worldspace)
    hand_mask = (left_hand_mask, right_hand_mask)
    extrinsics = (R_w2c, t_w2c)

    # Render cam + first modes (no full mode for speed)
    all_rendered_frames = []
    for mode in ['cam', 'first']:
        save_frames = visualizer._render_hand_trajectory(
            resize_video_frames, hand_traj_wordspace, hand_mask,
            extrinsics, renderer, mode=mode
        )
        all_rendered_frames.append(save_frames)

    # Concatenate cam + first side-by-side
    num_frames = len(all_rendered_frames[0])
    caption_primary = caption_right if hand_type == 'right' else caption_left
    caption_opposite = caption_left if hand_type == 'right' else caption_right
    opposite_intervals = [interval for _, interval in caption_opposite]

    final_frames = []
    for frame_idx in range(num_frames):
        curr_img = np.concatenate(
            [all_rendered_frames[mode_idx][frame_idx] for mode_idx in range(len(all_rendered_frames))],
            axis=1
        )
        overlay_text_primary = caption_primary[0][0]
        opposite_idx = find_caption_index(frame_idx, opposite_intervals)
        overlay_text_opposite = caption_opposite[opposite_idx][0] if opposite_idx is not None else 'None.'
        overlay_text_full = generate_overlay_text(overlay_text_primary, overlay_text_opposite, hand_type)
        add_overlay_text(curr_img, overlay_text_full)
        final_frames.append(curr_img)

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    save_to_video(final_frames, output_path, fps=visualizer.config.FPS)
    print(f"  Saved original viz: {output_path}")
    return output_path


# ---------------------------------------------------------------------------
# 2. Motion token trajectory visualization
# ---------------------------------------------------------------------------


def project_points_to_image(
    points_cam: np.ndarray, intrinsics: np.ndarray,
) -> np.ndarray:
    """Project camera-space 3D points to 2D pixel coordinates using intrinsics."""
    fx = intrinsics[0, 0]
    fy = intrinsics[1, 1]
    cx = intrinsics[0, 2]
    cy = intrinsics[1, 2]
    z = np.maximum(points_cam[:, 2], 0.01)
    u = fx * points_cam[:, 0] / z + cx
    v = fy * points_cam[:, 1] / z + cy
    return np.stack([u, v], axis=1)


def draw_trajectory_on_frame(
    frame: np.ndarray,
    uv: np.ndarray,
    up_to: int,
    start_color: Tuple[int, int, int] = (0, 255, 255),
    end_color: Tuple[int, int, int] = (255, 0, 255),
    line_width: int = 3,
) -> np.ndarray:
    """Draw trajectory up to frame `up_to` on the image."""
    overlay = frame.copy()
    h, w = frame.shape[:2]
    T = min(up_to + 1, len(uv))

    for i in range(T - 1):
        t = i / max(T - 1, 1)
        color = tuple(int(start_color[c] * (1 - t) + end_color[c] * t) for c in range(3))
        pt1 = (int(round(uv[i, 0])), int(round(uv[i, 1])))
        pt2 = (int(round(uv[i + 1, 0])), int(round(uv[i + 1, 1])))
        if (pt1[0] < -w or pt1[0] > 2 * w or pt1[1] < -h or pt1[1] > 2 * h) and \
           (pt2[0] < -w or pt2[0] > 2 * w or pt2[1] < -h or pt2[1] > 2 * h):
            continue
        cv2.line(overlay, pt1, pt2, color, line_width, cv2.LINE_AA)

    # Current point marker
    if T > 0:
        p = (int(round(uv[T - 1, 0])), int(round(uv[T - 1, 1])))
        if -50 < p[0] < w + 50 and -50 < p[1] < h + 50:
            cv2.circle(overlay, p, 8, end_color, -1)
            cv2.circle(overlay, p, 8, (255, 255, 255), 2)

    # Start marker
    p0 = (int(round(uv[0, 0])), int(round(uv[0, 1])))
    if -50 < p0[0] < w + 50 and -50 < p0[1] < h + 50:
        cv2.circle(overlay, p0, 7, start_color, -1)
        cv2.circle(overlay, p0, 7, (255, 255, 255), 2)

    return overlay


def render_token_trajectory_video(
    video_root: str,
    npy_path: str,
    decoded_xyz: np.ndarray,
    intrinsics: np.ndarray,
    extrinsics: np.ndarray,
    start_frame: int,
    end_frame: int,
    hand: str,
    desc: str,
    output_path: str,
    fps: int = 15,
    render_size: int = 480,
) -> Optional[str]:
    """Render decoded motion token trajectory as animated MP4.

    Each frame shows the first-frame image with the trajectory progressively drawn.
    Layout matches VITRA cam+first: left=progressive frame-by-frame, right=full trajectory on first frame.
    """
    episode_info = np.load(npy_path, allow_pickle=True).item()
    video_name = episode_info["video_name"]
    vf_start, vf_end = get_frame_interval(episode_info)

    # Read video frames
    video_frames = read_episode_video_frames(
        video_root, npy_path, video_name, vf_start, vf_end
    )
    if not video_frames:
        return None

    resize_video_frames = resize_frames_to_long_side(video_frames, render_size)
    H, W, _ = resize_video_frames[0].shape

    # Denormalize intrinsics for the resized frame size (same as VITRA does)
    from visualization.visualize_core import normalize_camera_intrinsics
    normalized_K = normalize_camera_intrinsics(intrinsics)
    K_resized = normalized_K.copy()
    K_resized[0] *= W
    K_resized[1] *= H

    # Project decoded trajectory onto each camera frame
    T_dec = len(decoded_xyz)
    T_episode = len(resize_video_frames)

    # Pre-compute trajectory in each frame's camera space
    traj_per_frame_uv = []  # [T_episode] each [T_dec, 2]
    for f_idx in range(T_episode):
        Ef = extrinsics[min(f_idx, len(extrinsics) - 1)]
        Rf = Ef[:3, :3]
        tf = Ef[:3, 3:]
        # decoded_xyz is in first-frame cam space, transform back to world then to frame-f cam space
        # First: first-cam-space -> world: inv(E0) @ xyz
        E0 = extrinsics[0]
        R0_inv = E0[:3, :3].T
        t0_inv = -R0_inv @ E0[:3, 3:]
        # world coords: R0_inv @ decoded_xyz.T + t0_inv
        world_xyz = (R0_inv @ decoded_xyz.T + t0_inv).T  # [T_dec, 3]
        # world -> frame-f cam: Rf @ world + tf
        cam_f = (Rf @ world_xyz.T + tf).T  # [T_dec, 3]
        uv_f = project_points_to_image(cam_f, K_resized)
        traj_per_frame_uv.append(uv_f)

    # Also compute trajectory on first frame (for the "first" mode panel)
    uv_first = traj_per_frame_uv[0]

    # Frame range for this sample within the episode
    sample_start = start_frame
    sample_end = min(end_frame, T_episode)

    final_frames = []
    for f_idx in range(T_episode):
        # Left panel: current frame with trajectory up to current point
        if f_idx < sample_start or f_idx >= sample_end:
            # Outside sample range: show frame with full trajectory faintly
            left_frame = draw_trajectory_on_frame(
                resize_video_frames[f_idx],
                traj_per_frame_uv[f_idx],
                up_to=T_dec,
                line_width=1,
            )
            # Dim overlay
            left_frame = cv2.addWeighted(left_frame, 0.5, resize_video_frames[f_idx], 0.5, 0)
        else:
            # Within sample range: progressive trajectory
            progress = (f_idx - sample_start) / max(sample_end - sample_start - 1, 1)
            up_to = int(progress * (T_dec - 1)) + 1
            left_frame = draw_trajectory_on_frame(
                resize_video_frames[f_idx],
                traj_per_frame_uv[f_idx],
                up_to=up_to,
            )

        # Right panel: first frame with full trajectory
        right_frame = draw_trajectory_on_frame(
            resize_video_frames[0],
            uv_first,
            up_to=T_dec,
        )

        # Add frame counter
        label = f"Frame {f_idx}/{T_episode-1} | {hand} | {desc[:40]}"
        cv2.putText(left_frame, label, (10, 25),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2, cv2.LINE_AA)
        cv2.putText(right_frame, "First frame + full trajectory (decoded tokens)", (10, 25),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2, cv2.LINE_AA)

        # Concatenate
        combined = np.concatenate([left_frame, right_frame], axis=1)
        # imageio expects RGB, cv2 frames are BGR
        combined = cv2.cvtColor(combined, cv2.COLOR_BGR2RGB)
        final_frames.append(combined)

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    save_to_video(final_frames, output_path, fps=fps)
    print(f"  Saved token viz: {output_path}")
    return output_path


# ---------------------------------------------------------------------------
# 3. Concatenate two videos side-by-side
# ---------------------------------------------------------------------------


def concatenate_videos_side_by_side(
    left_path: str, right_path: str, output_path: str,
) -> Optional[str]:
    """Concatenate two MP4 videos side-by-side using ffmpeg."""
    cmd = (
        f"ffmpeg -y -i {left_path} -i {right_path} "
        f"-filter_complex '[0:v][1:v]hstack=inputs=2[v]' "
        f"-map '[v]' -c:v libx264 -crf 18 -preset fast "
        f"{output_path} 2>/dev/null"
    )
    ret = os.system(cmd)
    if ret == 0:
        print(f"  Saved comparison: {output_path}")
        return output_path
    else:
        print(f"  ffmpeg concatenation failed (ret={ret})")
        return None


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main():
    parser = argparse.ArgumentParser(
        description="Visualize VITRA episode hand mesh + decoded motion token trajectory"
    )
    parser.add_argument("--data_dir", type=str, required=True,
                        help="Directory containing train.jsonl / val.jsonl")
    parser.add_argument("--video_root", type=str, required=True,
                        help="Root directory of video files")
    parser.add_argument("--output_dir", type=str, required=True,
                        help="Output directory for visualization videos")
    parser.add_argument("--mano_model_path", type=str,
                        default=os.path.join(VITRA_ROOT, "weights", "mano"),
                        help="Path to MANO model files")
    parser.add_argument("--num_samples", type=int, default=5,
                        help="Number of samples to visualize (default: 5)")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--split", type=str, default="train", choices=["train", "val"])
    parser.add_argument("--num_bins", type=int, default=1024)
    parser.add_argument("--fps", type=int, default=15)
    parser.add_argument("--render_size", type=int, default=480)
    parser.add_argument("--indices", type=str, default=None,
                        help="Comma-separated sample indices (e.g. '0,5,10')")
    parser.add_argument("--skip_original", action="store_true",
                        help="Skip VITRA original hand visualization (faster, no GPU mesh)")
    parser.add_argument("--skip_compare", action="store_true",
                        help="Skip side-by-side comparison video (saves disk space)")
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)

    tokenizer = WristMotionTokenizer(k=args.num_bins)

    # Initialize VITRA visualizer
    visualizer = None
    if not args.skip_original:
        config = Config()
        config.VIDEO_ROOT = args.video_root
        config.SAVE_PATH = args.output_dir
        config.MANO_MODEL_PATH = args.mano_model_path
        config.FPS = args.fps
        config.RENDER_SIZE_LONG_SIDE = args.render_size
        visualizer = HandVisualizer(config, render_gradual_traj=False)

    # Load data
    jsonl_path = os.path.join(args.data_dir, f"{args.split}.jsonl")
    if not os.path.exists(jsonl_path):
        print(f"Error: {jsonl_path} not found")
        return

    samples = []
    with open(jsonl_path, "r") as f:
        for line in f:
            line = line.strip()
            if line:
                samples.append(json.loads(line))

    print(f"Loaded {len(samples)} samples from {jsonl_path}")

    # Select samples
    if args.indices:
        selected_indices = [int(i) for i in args.indices.split(",")]
        selected = [(i, samples[i]) for i in selected_indices if i < len(samples)]
    else:
        random.seed(args.seed)
        n = min(args.num_samples, len(samples))
        selected_indices = sorted(random.sample(range(len(samples)), n))
        selected = [(i, samples[i]) for i in selected_indices]

    print(f"Visualizing {len(selected)} samples...")

    for idx, sample in selected:
        metadata = sample.get("metadata", {})
        messages = sample["messages"]
        source_npy = metadata.get("source_npy", "")
        video_name = metadata.get("video_name", "")
        first_frame_idx = metadata.get("first_frame_idx", 0)
        hand = metadata.get("hand", "right")
        start_frame = metadata.get("start_frame", 0)
        end_frame = metadata.get("end_frame", 0)
        desc = metadata.get("description", "N/A")
        traj_len = metadata.get("traj_len", 0)
        traj_space = metadata.get("traj_space", "first_frame_camspace")

        # Name for output files
        out_name = f"sample_{idx:06d}_{hand}_{traj_len}f"

        print(f"\n[{idx}] {desc} (hand={hand}, frames={traj_len}, video={video_name})")

        # Parse motion tokens
        assistant_content = ""
        for msg in messages:
            if msg["role"] == "assistant":
                assistant_content = msg["content"]
                break

        token_indices = parse_motion_tokens(assistant_content)
        if token_indices.shape[0] == 0:
            print(f"  No motion tokens, skipping")
            continue

        decoded_xyz = tokenizer.decode_centers(token_indices)

        # Load episode for camera params
        if not os.path.exists(source_npy):
            print(f"  npy not found: {source_npy}")
            continue

        episode_info = np.load(source_npy, allow_pickle=True).item()
        intrinsics = episode_info["intrinsics"]
        extrinsics = episode_info["extrinsics"]

        # ----- 1. Original hand visualization -----
        original_path = os.path.join(args.output_dir, f"{out_name}_original.mp4")
        if not args.skip_original:
            try:
                render_original_episode(
                    visualizer, args.video_root, source_npy, original_path
                )
            except Exception as e:
                import traceback
                print(f"  Original viz error: {e}")
                traceback.print_exc()
                original_path = None
        else:
            original_path = None

        # ----- 2. Motion token trajectory visualization -----
        tokens_path = os.path.join(args.output_dir, f"{out_name}_tokens.mp4")
        try:
            render_token_trajectory_video(
                args.video_root, source_npy, decoded_xyz,
                intrinsics, extrinsics,
                start_frame, end_frame, hand, desc,
                tokens_path,
                fps=args.fps, render_size=args.render_size,
            )
        except Exception as e:
            import traceback
            print(f"  Token viz error: {e}")
            traceback.print_exc()
            tokens_path = None

        # ----- 3. Side-by-side comparison -----
        if not args.skip_compare and original_path and tokens_path:
            compare_path = os.path.join(args.output_dir, f"{out_name}_compare.mp4")
            if os.path.exists(original_path) and os.path.exists(tokens_path):
                concatenate_videos_side_by_side(original_path, tokens_path, compare_path)

    print(f"\nDone! Outputs saved to {args.output_dir}")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
# Copyright (c) VITRA Motion SFT Experiment Contributors. All rights reserved.
"""Training launcher for Qwen3-VL + VITRA-1M Motion Token SFT.

Wraps `swift sft` with structured logging (file + console),
following the logging style from Motus/train/train.py.
"""

import argparse
import logging
import os
import re
import subprocess
import sys
import time
from datetime import datetime

# ---------------------------------------------------------------------------
# Logging setup (mirrors Motus/train/train.py style)
# ---------------------------------------------------------------------------

train_start_timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")


def setup_logging(log_dir: str = None, log_level: str = "INFO") -> logging.Logger:
    """Setup structured logging with console and optional file output."""
    root_logger = logging.getLogger()
    root_logger.setLevel(getattr(logging, log_level.upper()))

    formatter = logging.Formatter(
        "[Rank 0] %(asctime)s - %(name)s - %(levelname)s - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    root_logger.addHandler(console_handler)

    # File handler (always write, this is rank-0 launcher)
    if log_dir is not None:
        os.makedirs(log_dir, exist_ok=True)
        file_handler = logging.FileHandler(
            os.path.join(log_dir, "train.log"), mode="a"
        )
        file_handler.setFormatter(formatter)
        root_logger.addHandler(file_handler)

    return root_logger


# ---------------------------------------------------------------------------
# Swift log parser: intercept swift sft stdout and re-emit with logger
# ---------------------------------------------------------------------------

# Pattern for swift's per-step metric lines, e.g.:
# {'loss': 20.58, 'grad_norm': 799.5, 'learning_rate': 2e-05,
#  'token_acc': 0.01, 'epoch': 0.0, 'global_step/max_steps': '1/10',
#  'elapsed_time': '10s', 'remaining_time': '1m 27s', ...}
_METRIC_LINE_RE = re.compile(r"^\s*\{.*'loss'")

# Pattern for progress bar lines
_PROGRESS_BAR_RE = re.compile(r"^(Train|Eval):\s+\d+%")

# Pattern for [INFO:swift] lines
_SWIFT_INFO_RE = re.compile(r"^\[INFO:swift\]\s*(.*)")

# Pattern for [WARNING:swift] lines
_SWIFT_WARN_RE = re.compile(r"^\[WARNING:swift\]\s*(.*)")

# Patterns to suppress (noisy / irrelevant)
_SUPPRESSED_PATTERNS = [
    re.compile(r"`torch_dtype` is deprecated"),
    re.compile(r"Setting OMP_NUM_THREADS"),
    re.compile(r"INFO:root:Using (MoXing|OBS-Python)"),
    re.compile(r"WARNING:urllib3"),
    re.compile(r"WARNING:accelerate"),
    re.compile(r"The tokenizer has new PAD/BOS/EOS tokens"),
]


def _should_suppress(line: str) -> bool:
    for pat in _SUPPRESSED_PATTERNS:
        if pat.search(line):
            return True
    return False


def _parse_metric_line(line: str) -> str:
    """Reformat a swift metric dict line into a clean, readable string."""
    # Extract key values using regex
    parts = {}

    def _extract(key, pattern, line, cast=float):
        m = pattern.search(line)
        if m:
            parts[key] = cast(m.group(1))
        return m

    _extract("step", re.compile(r"'global_step/max_steps'\s*:\s*'(\d+)/\d+'"), line, int)
    _extract("max_steps", re.compile(r"'global_step/max_steps'\s*:\s*'\d+/(\d+)'"), line, int)
    _extract("loss", re.compile(r"'loss'\s*:\s*([\d.eE+-]+)"), line)
    _extract("grad_norm", re.compile(r"'grad_norm'\s*:\s*([\d.eE+-]+)"), line)
    _extract("lr", re.compile(r"'learning_rate'\s*:\s*([\d.eE+-]+)"), line)
    _extract("token_acc", re.compile(r"'token_acc'\s*:\s*([\d.eE+-]+)"), line)
    _extract("epoch", re.compile(r"'epoch'\s*:\s*([\d.eE+-]+)"), line)
    _extract("elapsed", re.compile(r"'elapsed_time'\s*:\s*'([^']+)'"), line, str)
    _extract("remaining", re.compile(r"'remaining_time'\s*:\s*'([^']+)'"), line, str)
    _extract("memory", re.compile(r"'memory\(GiB\)'\s*:\s*([\d.eE+-]+)"), line)
    _extract("speed", re.compile(r"'train_speed\(s/it\)'\s*:\s*([\d.eE+-]+)"), line)

    if "step" not in parts:
        return line.strip()

    msg = f"Step {parts['step']}/{parts.get('max_steps', '?')}"
    if "loss" in parts:
        msg += f", Loss: {parts['loss']:.4f}"
    if "token_acc" in parts:
        msg += f", TokenAcc: {parts['token_acc']:.4f}"
    if "grad_norm" in parts:
        msg += f", GradNorm: {parts['grad_norm']:.2f}"
    if "lr" in parts:
        msg += f", LR: {parts['lr']:.2e}"
    if "epoch" in parts:
        msg += f", Epoch: {parts['epoch']:.2f}"
    if "elapsed" in parts:
        msg += f", Elapsed: {parts['elapsed']}"
    if "remaining" in parts:
        msg += f", Remaining: {parts['remaining']}"
    if "memory" in parts:
        msg += f", Mem: {parts['memory']:.1f}GiB"
    if "speed" in parts:
        msg += f", Speed: {parts['speed']:.2f}s/it"
    return msg


def _process_line(line: str, logger: logging.Logger) -> None:
    """Process a single stdout/stderr line from swift sft."""
    line = line.rstrip("\n\r")

    if not line.strip():
        return

    if _should_suppress(line):
        return

    # Swift metric dict line -> reformat as INFO
    if _METRIC_LINE_RE.match(line):
        logger.info(_parse_metric_line(line))
        return

    # Progress bar line -> DEBUG
    if _PROGRESS_BAR_RE.match(line):
        logger.debug(line)
        return

    # [INFO:swift] -> INFO
    m = _SWIFT_INFO_RE.match(line)
    if m:
        logger.info(f"[swift] {m.group(1)}")
        return

    # [WARNING:swift] -> WARNING
    m = _SWIFT_WARN_RE.match(line)
    if m:
        logger.warning(f"[swift] {m.group(1)}")
        return

    # Everything else -> INFO (preserve content)
    logger.info(line)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def parse_args():
    parser = argparse.ArgumentParser(
        description="Launch Qwen3-VL Motion Token SFT with structured logging"
    )
    parser.add_argument(
        "--log_dir",
        type=str,
        default=None,
        help="Directory for log files. Defaults to output_dir/logs.",
    )
    parser.add_argument(
        "--log_level",
        type=str,
        default="INFO",
        help="Logging level (default: INFO)",
    )
    # Passthrough: all remaining args go to swift sft
    return parser.parse_known_args()


def main():
    args, swift_argv = parse_args()

    # Determine output_dir from swift args to set default log_dir
    output_dir = None
    for i, a in enumerate(swift_argv):
        if a == "--output_dir" and i + 1 < len(swift_argv):
            output_dir = swift_argv[i + 1]
            break

    log_dir = args.log_dir or (os.path.join(output_dir, "logs") if output_dir else None)
    logger = setup_logging(log_dir=log_dir, log_level=args.log_level)

    logger.info("=" * 60)
    logger.info("Qwen3-VL + VITRA-1M Motion Token SFT")
    logger.info(f"Start time: {train_start_timestamp}")
    logger.info(f"Log dir: {log_dir}")
    logger.info("=" * 60)

    # Build swift sft command
    # Build swift sft command - use the swift CLI entry point which handles
    # torch.distributed.run internally
    cmd = ["swift", "sft"] + swift_argv
    logger.info(f"Command: {' '.join(cmd)}")

    # Launch swift sft as subprocess, capture stdout/stderr
    start_time = time.time()
    try:
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,  # line-buffered
        )

        for line in proc.stdout:
            _process_line(line, logger)

        proc.wait()
        elapsed = time.time() - start_time

        if proc.returncode == 0:
            logger.info("=" * 60)
            logger.info(f"Training completed successfully in {elapsed:.1f}s")
            logger.info("=" * 60)
        else:
            logger.error("=" * 60)
            logger.error(f"Training FAILED with exit code {proc.returncode} after {elapsed:.1f}s")
            logger.error("=" * 60)
            sys.exit(proc.returncode)

    except KeyboardInterrupt:
        logger.warning("Training interrupted by user (Ctrl+C)")
        proc.terminate()
        proc.wait()
        sys.exit(130)
    except Exception as e:
        logger.error(f"Launcher error: {e}")
        import traceback
        logger.error(traceback.format_exc())
        sys.exit(1)


if __name__ == "__main__":
    main()

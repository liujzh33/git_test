#!/usr/bin/env python3
"""Visualize motion token trajectories from SFT data.

For each sample:
  1. Load the first-frame image
  2. Decode motion tokens -> xyz coordinates via WristMotionTokenizer.decode_centers
  3. Overlay trajectory on image (perspective projection) + 3D/2D trajectory plots
  4. Save visualization to output directory

Usage:
  python scripts/visualize_motion_sft.py \
    --data_dir /cache/wx1469573/data/VITRA-1M-ms-swift-motion-sft \
    --output_dir /cache/wx1469573/data/VITRA-1M-ms-swift-motion-sft/visualizations \
    --num_samples 20
"""

import argparse
import json
import os
import re
import sys
import random
from typing import Dict, List, Optional, Tuple

import cv2
import numpy as np

# Add scripts dir to path for motion_tokenizer import
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from motion_tokenizer import WristMotionTokenizer

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401


# ---------------------------------------------------------------------------
# Motion token parsing
# ---------------------------------------------------------------------------

_TOKEN_RE = re.compile(r"<\|motion_([xyz])_(\d+)\|>")


def parse_motion_tokens(text: str) -> np.ndarray:
    """Parse motion token string to bin indices array [T, 3].

    Input format: ``<|motion_x_0151|><|motion_y_0776|><|motion_z_0511|>...``
    Output: int64 array of shape [T, 3] with columns (x_idx, y_idx, z_idx).
    """
    matches = _TOKEN_RE.findall(text)
    if not matches:
        return np.array([], dtype=np.int64).reshape(0, 3)

    indices = []
    current: Dict[str, int] = {}
    for axis, idx_str in matches:
        current[axis] = int(idx_str)
        if len(current) == 3:
            indices.append([current["x"], current["y"], current["z"]])
            current = {}

    if current:
        print(f"  Warning: incomplete triplet at end, dropping {len(current)} token(s)")

    return np.array(indices, dtype=np.int64)


# ---------------------------------------------------------------------------
# Projection helpers
# ---------------------------------------------------------------------------


def project_to_image(
    xyz: np.ndarray,
    image: np.ndarray,
    fov_deg: float = 90.0,
) -> np.ndarray:
    """Project 3D camera-space points to 2D image pixel coordinates.

    Simple pinhole perspective projection with assumed horizontal FOV.

    Camera coordinate convention (first_frame_camspace):
        x: rightward, y: downward (image convention), z: forward

    Args:
        xyz: [T, 3] camera-space coordinates.
        image: HxW image.
        fov_deg: assumed horizontal FOV in degrees.

    Returns:
        [T, 2] array of (u, v) pixel coordinates.
    """
    h, w = image.shape[:2]
    fx = w / (2 * np.tan(np.radians(fov_deg / 2)))
    fy = fx
    cx, cy = w / 2.0, h / 2.0

    z = np.maximum(xyz[:, 2], 0.01)  # avoid div-by-zero
    u = fx * xyz[:, 0] / z + cx
    v = fy * xyz[:, 1] / z + cy  # y already positive-down in our camspace

    return np.stack([u, v], axis=1)


# ---------------------------------------------------------------------------
# Visualization
# ---------------------------------------------------------------------------


def _draw_trajectory_on_image(
    image: np.ndarray,
    xyz: np.ndarray,
    fov_deg: float = 90.0,
    line_width: int = 2,
) -> np.ndarray:
    """Draw color-coded trajectory on a copy of the image."""
    overlay = image.copy()
    uv = project_to_image(xyz, image, fov_deg=fov_deg)

    h, w = image.shape[:2]
    T = len(uv)

    for i in range(T - 1):
        t = i / max(T - 1, 1)
        # Blue -> Red gradient
        color = (int(255 * (1 - t)), 30, int(255 * t))

        pt1 = (int(round(uv[i, 0])), int(round(uv[i, 1])))
        pt2 = (int(round(uv[i + 1, 0])), int(round(uv[i + 1, 1])))

        # Skip segments far outside the image
        if (
            pt1[0] < -w or pt1[0] > 2 * w
            or pt1[1] < -h or pt1[1] > 2 * h
        ):
            continue

        cv2.line(overlay, pt1, pt2, color, line_width, cv2.LINE_AA)

    # Start (green) and end (red) markers
    if 0 <= uv[0, 0] < w and 0 <= uv[0, 1] < h:
        cv2.circle(overlay, (int(round(uv[0, 0])), int(round(uv[0, 1]))),
                    7, (0, 255, 0), -1)
    if 0 <= uv[-1, 0] < w and 0 <= uv[-1, 1] < h:
        cv2.circle(overlay, (int(round(uv[-1, 0])), int(round(uv[-1, 1]))),
                    7, (0, 0, 255), -1)

    return overlay


def visualize_sample(
    sample: Dict,
    tokenizer: WristMotionTokenizer,
    output_path: str,
    fov_deg: float = 90.0,
):
    """Create a 2x2 visualization for a single sample.

    Layout:
      Top-left:     Original first-frame image
      Top-right:    Image with trajectory overlay
      Bottom-left:  3D trajectory (camera perspective)
      Bottom-right: 2D projections (XY top-down, XZ side view)
    """
    messages = sample["messages"]
    metadata = sample.get("metadata", {})
    image_paths = sample.get("images", [])

    # --- Parse motion tokens ---
    assistant_content = ""
    for msg in messages:
        if msg["role"] == "assistant":
            assistant_content = msg["content"]
            break

    indices = parse_motion_tokens(assistant_content)
    if indices.shape[0] == 0:
        print(f"  No motion tokens found, skipping")
        return

    xyz = tokenizer.decode_centers(indices)

    # --- Load image ---
    image = None
    if image_paths and os.path.exists(image_paths[0]):
        image_bgr = cv2.imread(image_paths[0])
        if image_bgr is not None:
            image = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)

    # --- Create figure ---
    fig = plt.figure(figsize=(16, 12))

    # -- Top-left: original image --
    ax1 = fig.add_subplot(2, 2, 1)
    if image is not None:
        ax1.imshow(image)
    else:
        ax1.text(0.5, 0.5, "Image not found", ha="center", va="center", fontsize=14)
        ax1.set_xlim(0, 1)
        ax1.set_ylim(0, 1)
    ax1.set_title("First Frame", fontsize=12, fontweight="bold")
    ax1.axis("off")

    # -- Top-right: image + trajectory overlay --
    ax2 = fig.add_subplot(2, 2, 2)
    if image is not None:
        overlay = _draw_trajectory_on_image(image, xyz, fov_deg=fov_deg)
        ax2.imshow(overlay)
    else:
        ax2.text(0.5, 0.5, "No image for overlay", ha="center", va="center", fontsize=14)
        ax2.set_xlim(0, 1)
        ax2.set_ylim(0, 1)
    ax2.set_title("Trajectory Overlay (perspective projection)", fontsize=12, fontweight="bold")
    ax2.axis("off")

    T = len(xyz)
    desc = metadata.get("description", "N/A")
    hand = metadata.get("hand", "N/A")
    traj_len = metadata.get("traj_len", T)
    traj_space = metadata.get("traj_space", "N/A")
    total_dist = metadata.get("total_transl_dist", "N/A")
    clipping_info = []
    for axis in ["x", "y", "z"]:
        for side in ["below", "above"]:
            v = metadata.get(f"clipping_{axis}_{side}", 0)
            if v > 0:
                clipping_info.append(f"{axis}_{side}={v:.2f}")

    info_text = (
        f"Task: {desc}\n"
        f"Hand: {hand} | Frames: {traj_len} | Space: {traj_space}\n"
        f"Total dist: {total_dist}"
    )
    if clipping_info:
        info_text += f" | Clipping: {', '.join(clipping_info)}"

    # -- Bottom-left: 3D trajectory --
    ax3 = fig.add_subplot(2, 2, 3, projection="3d")

    # Color by time: blue -> red
    t_vals = np.linspace(0, 1, T)
    ax3.scatter(xyz[:, 0], xyz[:, 1], xyz[:, 2], c=t_vals, cmap="coolwarm", s=8, alpha=0.7)
    ax3.plot(xyz[:, 0], xyz[:, 1], xyz[:, 2], "k-", alpha=0.2, linewidth=0.5)
    ax3.scatter(*xyz[0], color="green", s=80, marker="o", label="Start", zorder=5)
    ax3.scatter(*xyz[-1], color="red", s=80, marker="s", label="End", zorder=5)

    ax3.set_xlabel("X (left-right)")
    ax3.set_ylabel("Y (down-up)")
    ax3.set_zlabel("Z (forward)")
    ax3.set_xlim(-0.5, 0.5)
    ax3.set_ylim(-0.5, 0.5)
    ax3.set_zlim(0, 1.0)
    ax3.legend(fontsize=8, loc="upper left")
    ax3.set_title("3D Trajectory (camera space)", fontsize=11, fontweight="bold")
    # Set camera viewing angle (looking from behind/above)
    ax3.view_init(elev=25, azim=-60)

    # -- Bottom-right: 2D projections --
    ax4 = fig.add_subplot(2, 2, 4)

    # XZ (top-down) view
    ax4.scatter(xyz[:, 0], xyz[:, 2], c=t_vals, cmap="coolwarm", s=10, alpha=0.7)
    ax4.plot(xyz[:, 0], xyz[:, 2], "k-", alpha=0.2, linewidth=0.5)
    ax4.scatter(xyz[0, 0], xyz[0, 2], color="green", s=60, marker="o", zorder=5)
    ax4.scatter(xyz[-1, 0], xyz[-1, 2], color="red", s=60, marker="s", zorder=5)

    # Add XY view as inset
    ax_inset = ax4.inset_axes([0.6, 0.6, 0.38, 0.38])
    ax_inset.scatter(xyz[:, 0], xyz[:, 1], c=t_vals, cmap="coolwarm", s=4, alpha=0.7)
    ax_inset.plot(xyz[:, 0], xyz[:, 1], "k-", alpha=0.2, linewidth=0.3)
    ax_inset.scatter(xyz[0, 0], xyz[0, 1], color="green", s=20, marker="o", zorder=5)
    ax_inset.scatter(xyz[-1, 0], xyz[-1, 1], color="red", s=20, marker="s", zorder=5)
    ax_inset.set_xlabel("X", fontsize=7)
    ax_inset.set_ylabel("Y", fontsize=7)
    ax_inset.set_xlim(-0.5, 0.5)
    ax_inset.set_ylim(-0.5, 0.5)
    ax_inset.set_title("XY (front view)", fontsize=7)
    ax_inset.tick_params(labelsize=5)

    ax4.set_xlabel("X (left-right)")
    ax4.set_ylabel("Z (forward)")
    ax4.set_xlim(-0.5, 0.5)
    ax4.set_ylim(0, 1.0)
    ax4.invert_yaxis()  # z increases upward (forward) in the plot
    ax4.set_title("XZ (top-down view)", fontsize=11, fontweight="bold")
    ax4.grid(True, alpha=0.3)

    # Main title with info
    fig.suptitle(info_text, fontsize=10, y=0.98, va="top",
                 bbox=dict(boxstyle="round,pad=0.3", facecolor="lightyellow", alpha=0.8))

    plt.tight_layout(rect=[0, 0, 1, 0.93])
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main():
    parser = argparse.ArgumentParser(
        description="Visualize motion token trajectories from SFT JSONL data"
    )
    parser.add_argument(
        "--data_dir", type=str, required=True,
        help="Directory containing train.jsonl / val.jsonl",
    )
    parser.add_argument(
        "--output_dir", type=str, required=True,
        help="Output directory for visualization images",
    )
    parser.add_argument(
        "--num_samples", type=int, default=20,
        help="Number of samples to visualize (default: 20)",
    )
    parser.add_argument(
        "--seed", type=int, default=42,
        help="Random seed for sampling",
    )
    parser.add_argument(
        "--split", type=str, default="train", choices=["train", "val"],
        help="Which split to sample from (default: train)",
    )
    parser.add_argument("--num_bins", type=int, default=1024)
    parser.add_argument(
        "--fov_deg", type=float, default=90.0,
        help="Assumed horizontal FOV for perspective projection (default: 90)",
    )
    parser.add_argument(
        "--no_projection", action="store_true",
        help="Skip trajectory overlay on image (use when images are missing)",
    )
    parser.add_argument(
        "--start_idx", type=int, default=0,
        help="Start index for sequential sampling (default: 0, random)",
    )
    parser.add_argument(
        "--indices", type=str, default=None,
        help="Comma-separated sample indices to visualize (e.g. '0,5,10')",
    )
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)

    tokenizer = WristMotionTokenizer(k=args.num_bins)

    # Load data
    jsonl_path = os.path.join(args.data_dir, f"{args.split}.jsonl")
    if not os.path.exists(jsonl_path):
        print(f"Error: {jsonl_path} not found")
        return

    samples = []
    with open(jsonl_path, "r") as f:
        for line in f:
            line = line.strip()
            if line:
                samples.append(json.loads(line))

    print(f"Loaded {len(samples)} samples from {jsonl_path}")

    # Select samples
    if args.indices:
        selected_indices = [int(i) for i in args.indices.split(",")]
        selected = [(i, samples[i]) for i in selected_indices if i < len(samples)]
    elif args.start_idx > 0 or args.start_idx == 0 and args.indices is None:
        if args.start_idx >= 0 and args.indices is None:
            # If start_idx is 0, we do random sampling
            if args.start_idx == 0 and args.indices is None:
                random.seed(args.seed)
                n = min(args.num_samples, len(samples))
                selected_indices = sorted(random.sample(range(len(samples)), n))
                selected = [(i, samples[i]) for i in selected_indices]
            else:
                end_idx = min(args.start_idx + args.num_samples, len(samples))
                selected = [(i, samples[i]) for i in range(args.start_idx, end_idx)]
        else:
            random.seed(args.seed)
            n = min(args.num_samples, len(samples))
            selected_indices = sorted(random.sample(range(len(samples)), n))
            selected = [(i, samples[i]) for i in selected_indices]

    print(f"Visualizing {len(selected)} samples...")

    success = 0
    for idx, sample in selected:
        metadata = sample.get("metadata", {})
        desc = metadata.get("description", "unknown")[:40]
        hand = metadata.get("hand", "?")
        traj_len = metadata.get("traj_len", "?")

        output_name = f"sample_{idx:06d}_{hand}_{traj_len}f.png"
        output_path = os.path.join(args.output_dir, output_name)

        print(f"  [{idx}] {desc}... (hand={hand}, frames={traj_len})")
        try:
            visualize_sample(
                sample, tokenizer, output_path,
                fov_deg=args.fov_deg,
            )
            success += 1
        except Exception as e:
            print(f"  ERROR: {e}")

    print(f"\nDone! {success}/{len(selected)} visualizations saved to {args.output_dir}")


if __name__ == "__main__":
    main()

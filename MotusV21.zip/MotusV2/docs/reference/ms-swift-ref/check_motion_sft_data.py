#!/usr/bin/env python3
# Copyright (c) VITRA Motion SFT Experiment Contributors. All rights reserved.
"""Sanity check for VITRA-1M motion SFT data.

Validates:
  1. Sample format and required fields
  2. Motion token legality and ordering (x,y,z,x,y,z,...)
  3. Token index range [0, 1023]
  4. Tokenizer recognition of motion tokens as single tokens
  5. Image path existence
  6. Metadata consistency

Usage:
    python scripts/check_motion_sft_data.py \
        --data_dir /cache/wx1469573/data/VITRA-1M-ms-swift-motion-sft

    python scripts/check_motion_sft_data.py \
        --data_dir /cache/wx1469573/data/VITRA-1M-ms-swift-motion-sft-smoke \
        --max_samples 50 \
        --tokenizer_path /home/ma-user/work/wx1469573/Motus/pretrained_models/Qwen3-VL-2B-Instruct-motion-token
"""

import argparse
import json
import logging
import os
import re
import sys
from collections import defaultdict
from typing import Dict, List, Optional, Set, Tuple

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

# Motion token regex pattern
MOTION_TOKEN_RE = re.compile(r"<\|motion_([xyz])_(\d{4})\|>")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Check VITRA-1M motion SFT data")
    parser.add_argument("--data_dir", type=str, required=True,
                        help="Directory containing train.jsonl and val.jsonl")
    parser.add_argument("--max_samples", type=int, default=None,
                        help="Max samples to check per split")
    parser.add_argument("--tokenizer_path", type=str, default=None,
                        help="Path to extended tokenizer for token-id verification")
    parser.add_argument("--num_bins", type=int, default=1024)
    parser.add_argument("--verbose", action="store_true",
                        help="Print sample details")
    parser.add_argument("--allow_fallback_text", action="store_true",
                        help="Allow anno_type/default_instruction as text_source without error")
    return parser.parse_args()


def load_samples(path: str, max_samples: Optional[int] = None) -> List[Dict]:
    """Load JSONL samples from a file."""
    samples = []
    with open(path, "r", encoding="utf-8") as f:
        for i, line in enumerate(f):
            if max_samples is not None and i >= max_samples:
                break
            samples.append(json.loads(line.strip()))
    return samples


def extract_motion_tokens(content: str) -> List[Tuple[str, int]]:
    """Extract motion tokens from assistant content.

    Returns:
        List of (axis, index) tuples in order of appearance.
    """
    return [(m.group(1), int(m.group(2))) for m in MOTION_TOKEN_RE.finditer(content)]


def check_samples(
    samples: List[Dict],
    split_name: str,
    tokenizer=None,
    num_bins: int = 1024,
    verbose: bool = False,
    allow_fallback_text: bool = False,
) -> Dict[str, int]:
    """Run all checks on a list of samples.

    Returns:
        Dict of error_type -> count.
    """
    errors: Dict[str, int] = defaultdict(int)
    total = len(samples)

    logger.info(f"\n{'=' * 60}")
    logger.info(f"Checking {split_name}: {total} samples")
    logger.info(f"{'=' * 60}")

    for i, sample in enumerate(samples):
        sample_id = f"{split_name}[{i}]"

        # Check required fields
        messages = sample.get("messages")
        if not messages or not isinstance(messages, list):
            errors["missing_messages"] += 1
            logger.error(f"{sample_id}: missing or invalid 'messages'")
            continue

        metadata = sample.get("metadata", {})

        # Find user and assistant messages
        user_msg = None
        assistant_msg = None
        for msg in messages:
            if msg.get("role") == "user":
                user_msg = msg
            elif msg.get("role") == "assistant":
                assistant_msg = msg

        if user_msg is None:
            errors["missing_user_message"] += 1
            logger.error(f"{sample_id}: no user message")
            continue

        if assistant_msg is None:
            errors["missing_assistant_message"] += 1
            logger.error(f"{sample_id}: no assistant message")
            continue

        # Check image field
        images = sample.get("images")
        image_missing = metadata.get("image_missing", False)

        # Forbidden: videos field
        if "videos" in sample:
            errors["videos_field_forbidden"] += 1
            logger.error(f"{sample_id}: 'videos' field is forbidden")

        if images is not None:
            for img_path in images:
                if not os.path.isfile(img_path):
                    errors["image_not_found"] += 1
                    if verbose:
                        logger.warning(f"{sample_id}: image not found: {img_path}")

        if images is None and not image_missing:
            errors["missing_images_field_without_flag"] += 1

        # Check user content has <image> when images present
        if images is not None and "<image>" not in user_msg.get("content", ""):
            errors["user_missing_image_tag"] += 1
            logger.warning(f"{sample_id}: has images but user content missing <image> tag")

        if images is None and "<image>" in user_msg.get("content", ""):
            errors["user_has_image_tag_without_images"] += 1
            logger.warning(f"{sample_id}: <image> tag in content but no images field")

        # Check user content contains "Task:"
        user_content = user_msg.get("content", "")
        if "Task:" not in user_content:
            errors["missing_task_in_user_content"] += 1
            logger.error(f"{sample_id}: user content missing 'Task:'")

        # Check for generic/invalid Task descriptions
        GENERIC_DESCRIPTIONS = {"left", "right", "both", "hand"}
        description = metadata.get("description", "")
        if description.lower() in GENERIC_DESCRIPTIONS:
            errors["invalid_description_too_generic"] += 1
            logger.error(
                f"{sample_id}: description is too generic: '{description}'"
            )

        # Check for "Task: left" / "Task: right" in user content
        import re as _re
        task_match = _re.search(r"Task:\s*(\S+)", user_content)
        if task_match and task_match.group(1).lower() in GENERIC_DESCRIPTIONS:
            errors["invalid_task_description"] += 1
            logger.error(
                f"{sample_id}: Task description is generic: '{task_match.group(0)}'"
            )

        # Check for fallback text sources (warning unless --allow_fallback_text)
        text_source = metadata.get("text_source", "")
        if text_source in {"anno_type", "default_instruction"}:
            if not allow_fallback_text:
                errors["fallback_text_source_without_flag"] += 1
                logger.error(
                    f"{sample_id}: text_source is '{text_source}' but "
                    f"--allow_fallback_text not set"
                )

        # Check required metadata fields
        required_meta = [
            "source_npy", "hand", "start_frame", "end_frame",
            "traj_space", "traj_len", "motion_token_len",
        ]
        for key in required_meta:
            if key not in metadata:
                errors[f"missing_metadata_{key}"] += 1
                logger.error(f"{sample_id}: missing metadata key '{key}'")

        # Check hand value
        if "hand" in metadata and metadata["hand"] not in {"left", "right"}:
            errors["invalid_hand"] += 1
            logger.error(f"{sample_id}: invalid hand '{metadata['hand']}'")

        # Check traj_space value
        valid_traj_spaces = {
            "first_frame_camspace", "camspace_per_frame", "camspace_per_frame_fallback",
        }
        if "traj_space" in metadata and metadata["traj_space"] not in valid_traj_spaces:
            errors["invalid_traj_space"] += 1
            logger.error(f"{sample_id}: invalid traj_space '{metadata['traj_space']}'")

        # Check motion_token_len == 3 * traj_len
        if "motion_token_len" in metadata and "traj_len" in metadata:
            if metadata["motion_token_len"] != 3 * metadata["traj_len"]:
                errors["metadata_motion_len_not_3x_traj_len"] += 1
                logger.error(
                    f"{sample_id}: motion_token_len={metadata['motion_token_len']} "
                    f"!= 3 * traj_len={3 * metadata['traj_len']}"
                )

        # Check motion tokens in assistant content
        content = assistant_msg.get("content", "")
        motion_tokens = extract_motion_tokens(content)

        if not motion_tokens:
            errors["no_motion_tokens"] += 1
            logger.error(f"{sample_id}: no motion tokens found in assistant content")
            continue

        # Check no non-motion-token text (should only be motion tokens)
        # Remove all motion tokens and check remaining
        remaining = MOTION_TOKEN_RE.sub("", content).strip()
        if remaining:
            errors["non_motion_token_text"] += 1
            if verbose:
                logger.warning(
                    f"{sample_id}: non-motion-token text in assistant: "
                    f"'{remaining[:100]}'"
                )

        # Check token index range
        for axis, idx in motion_tokens:
            if idx < 0 or idx >= num_bins:
                errors["token_index_out_of_range"] += 1
                logger.error(
                    f"{sample_id}: token index {idx} out of range [0, {num_bins})"
                )

        # Check x,y,z ordering
        expected_axes = ["x", "y", "z"]
        for j, (axis, idx) in enumerate(motion_tokens):
            expected_axis = expected_axes[j % 3]
            if axis != expected_axis:
                errors["wrong_axis_order"] += 1
                if errors["wrong_axis_order"] <= 5:  # Only log first 5
                    logger.error(
                        f"{sample_id}: at position {j}, expected axis "
                        f"'{expected_axis}' but got '{axis}'"
                    )

        # Check motion_token_len consistency
        expected_token_len = metadata.get("motion_token_len")
        if expected_token_len is not None and len(motion_tokens) != expected_token_len:
            errors["motion_token_len_mismatch"] += 1
            logger.error(
                f"{sample_id}: expected {expected_token_len} tokens, "
                f"got {len(motion_tokens)}"
            )

        # Check traj_len consistency (should be motion_tokens / 3)
        expected_traj_len = metadata.get("traj_len")
        if expected_traj_len is not None and len(motion_tokens) // 3 != expected_traj_len:
            errors["traj_len_mismatch"] += 1
            logger.error(
                f"{sample_id}: expected traj_len={expected_traj_len}, "
                f"got {len(motion_tokens) // 3}"
            )

        # Tokenizer check
        if tokenizer is not None:
            # Check a few tokens are recognized as single tokens
            for axis_str, idx_val in motion_tokens[:3]:
                token_str = f"<|motion_{axis_str}_{idx_val:04d}|>"
                token_ids = tokenizer.encode(token_str, add_special_tokens=False)
                if len(token_ids) != 1:
                    errors["tokenizer_multi_token"] += 1
                    if errors["tokenizer_multi_token"] <= 5:
                        logger.error(
                            f"{sample_id}: token '{token_str}' encodes to "
                            f"{len(token_ids)} tokens: {token_ids}"
                        )
                    break  # Only check first occurrence per sample

        # Verbose output
        if verbose and i < 5:
            preview = "".join(
                f"<|motion_{axis}_{idx:04d}|>" for axis, idx in motion_tokens[:30]
            )
            print(f"\n--- {sample_id} ---")
            print(f"  User prompt: {user_msg['content'][:100]}...")
            print(f"  Image path: {images[0] if images else 'N/A'}")
            print(f"  Motion token count: {len(motion_tokens)}")
            print(f"  First 30 tokens: {preview}")
            print(f"  Hand: {metadata.get('hand')}, Traj len: {metadata.get('traj_len')}")
            print(f"  Traj space: {metadata.get('traj_space')}")

    # Summary
    logger.info(f"\n{split_name} check results:")
    logger.info(f"  Total samples: {total}")
    if errors:
        logger.info(f"  Errors found:")
        for error_type, count in sorted(errors.items()):
            logger.info(f"    {error_type}: {count}")
    else:
        logger.info(f"  All checks PASSED!")

    return dict(errors)


def main() -> None:
    args = parse_args()

    # Load tokenizer if path provided
    tokenizer = None
    if args.tokenizer_path:
        try:
            from transformers import AutoTokenizer
            logger.info(f"Loading tokenizer from: {args.tokenizer_path}")
            tokenizer = AutoTokenizer.from_pretrained(
                args.tokenizer_path, trust_remote_code=True, local_files_only=True
            )
            # Quick test
            test_id = tokenizer.encode("<|motion_x_0000|>", add_special_tokens=False)
            if len(test_id) == 1:
                logger.info("Tokenizer verification: motion tokens recognized as single tokens")
            else:
                logger.warning(
                    f"Tokenizer issue: <|motion_x_0000|> encodes to {len(test_id)} tokens"
                )
        except Exception as e:
            logger.warning(f"Could not load tokenizer: {e}")

    # Check each split
    all_errors: Dict[str, int] = defaultdict(int)
    for split in ["train", "val"]:
        path = os.path.join(args.data_dir, f"{split}.jsonl")
        if not os.path.isfile(path):
            logger.warning(f"File not found: {path}")
            continue

        samples = load_samples(path, args.max_samples)
        errors = check_samples(
            samples, split, tokenizer=tokenizer,
            num_bins=args.num_bins, verbose=args.verbose,
            allow_fallback_text=args.allow_fallback_text,
        )
        for k, v in errors.items():
            all_errors[k] += v

    # Print report path
    report_path = os.path.join(args.data_dir, "preprocess_report.json")
    if os.path.isfile(report_path):
        with open(report_path) as f:
            report = json.load(f)
        logger.info(f"\nPreprocess report ({report_path}):")
        for key in [
            "total_npy_files", "parsed_episode_count", "success_sample_count",
            "train_count", "val_count", "image_count", "no_image_count",
            "traj_space_first_frame_camspace_count",
            "traj_space_camspace_per_frame_fallback_count",
        ]:
            if key in report:
                logger.info(f"  {key}: {report[key]}")

    # Final verdict
    if all_errors:
        total_errors = sum(all_errors.values())
        logger.info(f"\nTOTAL ERRORS: {total_errors}")
        for k, v in sorted(all_errors.items()):
            logger.info(f"  {k}: {v}")
        sys.exit(1)
    else:
        logger.info("\nAll checks PASSED!")
        sys.exit(0)


if __name__ == "__main__":
    main()

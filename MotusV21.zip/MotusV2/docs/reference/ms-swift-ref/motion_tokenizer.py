#!/usr/bin/env python3
# Copyright (c) VITRA Motion SFT Experiment Contributors. All rights reserved.
"""WristMotionTokenizer: Discretize 3D wrist trajectories into motion tokens.

Token space: camera-forward 1m³ volume
  x: [-0.5, 0.5] (left-right)
  y: [-0.5, 0.5] (down-up)
  z: [0.0, 1.0]  (forward)

Each 3D waypoint is converted to 3 motion tokens:
  <|motion_x_0000|> ... <|motion_x_1023|>
  <|motion_y_0000|> ... <|motion_y_1023|>
  <|motion_z_0000|> ... <|motion_z_1023|>

Total: 3 * 1024 = 3072 special tokens.
"""

import json
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np


@dataclass
class AxisRange:
    lo: float
    hi: float

    @property
    def width(self) -> float:
        return self.hi - self.lo


class WristMotionTokenizer:
    """Discretize 3D wrist trajectories into motion token sequences.

    Binning rule (hi boundary must map to k-1):
        normalized = (value - lo) / (hi - lo)
        idx = floor(normalized * k)
        idx = clip(idx, 0, k - 1)
    """

    def __init__(
        self,
        k: int = 1024,
        x_range: Tuple[float, float] = (-0.5, 0.5),
        y_range: Tuple[float, float] = (-0.5, 0.5),
        z_range: Tuple[float, float] = (0.0, 1.0),
        token_format: str = "<|motion_{axis}_{idx:04d}|>",
    ) -> None:
        if k <= 0:
            raise ValueError(f"k must be positive, got {k}")
        self.k = k
        self.ranges: Dict[str, AxisRange] = {
            "x": AxisRange(*x_range),
            "y": AxisRange(*y_range),
            "z": AxisRange(*z_range),
        }
        for axis, ar in self.ranges.items():
            if ar.hi <= ar.lo:
                raise ValueError(f"Invalid range for {axis}: hi={ar.hi} <= lo={ar.lo}")
        self.axes = ["x", "y", "z"]
        self.token_format = token_format

    # ------------------------------------------------------------------
    # Core binning
    # ------------------------------------------------------------------

    def _coord_to_bin(self, value: np.ndarray, axis_range: AxisRange) -> np.ndarray:
        """Map continuous values to bin indices.

        Args:
            value: 1-D float array of coordinate values.
            axis_range: AxisRange with lo/hi bounds.

        Returns:
            int64 array of bin indices in [0, k-1].
        """
        value = np.asarray(value, dtype=np.float32)
        value = np.clip(value, axis_range.lo, axis_range.hi)
        normalized = (value - axis_range.lo) / axis_range.width
        idx = np.floor(normalized * self.k).astype(np.int64)
        idx = np.clip(idx, 0, self.k - 1)
        return idx

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def encode_indices(self, traj: np.ndarray) -> np.ndarray:
        """Encode a trajectory to bin indices.

        Args:
            traj: np.ndarray, shape [T, 3], camera-space wrist positions in meters.

        Returns:
            np.ndarray, shape [T, 3], each value in [0, k-1].
        """
        traj = np.asarray(traj, dtype=np.float32)
        if traj.ndim != 2 or traj.shape[1] != 3:
            raise ValueError(f"Expected shape [T, 3], got {traj.shape}")
        if not np.isfinite(traj).all():
            raise ValueError("Trajectory contains NaN or Inf values")

        out = []
        for dim, axis in enumerate(self.axes):
            out.append(self._coord_to_bin(traj[:, dim], self.ranges[axis]))
        return np.stack(out, axis=1)

    def encode_tokens(self, traj: np.ndarray) -> List[str]:
        """Encode a trajectory to a flattened list of motion tokens.

        Order: [x_t0, y_t0, z_t0, x_t1, y_t1, z_t1, ...]

        Args:
            traj: np.ndarray, shape [T, 3].

        Returns:
            List of motion token strings, length = T * 3.
        """
        indices = self.encode_indices(traj)
        tokens: List[str] = []
        for t in range(indices.shape[0]):
            for dim, axis in enumerate(self.axes):
                tokens.append(self.token_format.format(axis=axis, idx=int(indices[t, dim])))
        return tokens

    def encode_token_string(self, traj: np.ndarray) -> str:
        """Encode a trajectory to a concatenated motion token string.

        No spaces between tokens.
        """
        return "".join(self.encode_tokens(traj))

    def decode_centers(self, indices: np.ndarray) -> np.ndarray:
        """Convert bin indices back to bin-center coordinates.

        Args:
            indices: np.ndarray, shape [T, 3], bin indices in [0, k-1].

        Returns:
            np.ndarray, shape [T, 3], bin-center coordinates in meters.
        """
        indices = np.asarray(indices, dtype=np.int64)
        if indices.ndim != 2 or indices.shape[1] != 3:
            raise ValueError(f"Expected shape [T, 3], got {indices.shape}")

        coords = []
        for dim, axis in enumerate(self.axes):
            ar = self.ranges[axis]
            idx = np.clip(indices[:, dim], 0, self.k - 1)
            bin_width = ar.width / self.k
            coord = ar.lo + (idx + 0.5) * bin_width
            coords.append(coord)
        return np.stack(coords, axis=1).astype(np.float32)

    def clipping_stats(self, traj: np.ndarray) -> Dict[str, Dict[str, float]]:
        """Compute clipping statistics for each axis.

        Args:
            traj: np.ndarray, shape [T, 3].

        Returns:
            Dict mapping axis -> {"below": fraction, "above": fraction}.
            "below" = fraction of values < lo
            "above" = fraction of values > hi
        """
        traj = np.asarray(traj, dtype=np.float32)
        if traj.ndim != 2 or traj.shape[1] != 3:
            raise ValueError(f"Expected shape [T, 3], got {traj.shape}")

        stats: Dict[str, Dict[str, float]] = {}
        n = traj.shape[0]
        for dim, axis in enumerate(self.axes):
            ar = self.ranges[axis]
            below = float(np.sum(traj[:, dim] < ar.lo)) / n
            above = float(np.sum(traj[:, dim] > ar.hi)) / n
            stats[axis] = {"below": below, "above": above}
        return stats

    # ------------------------------------------------------------------
    # Token list generation
    # ------------------------------------------------------------------

    def build_motion_tokens(self, k: Optional[int] = None) -> List[str]:
        """Generate the full list of motion special tokens.

        Args:
            k: Number of bins per axis. Defaults to self.k.

        Returns:
            List of 3 * k token strings in order:
            [x_0, ..., x_{k-1}, y_0, ..., y_{k-1}, z_0, ..., z_{k-1}]
        """
        k = k or self.k
        tokens: List[str] = []
        for axis in self.axes:
            for idx in range(k):
                tokens.append(self.token_format.format(axis=axis, idx=idx))
        return tokens

    def save_motion_tokens_json(self, path: str) -> None:
        """Save motion tokens list to a JSON file.

        Args:
            path: Output file path.
        """
        tokens = self.build_motion_tokens()
        data = {
            "num_tokens": len(tokens),
            "k": self.k,
            "ranges": {axis: {"lo": ar.lo, "hi": ar.hi} for axis, ar in self.ranges.items()},
            "token_format": self.token_format,
            "tokens": tokens,
        }
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    @classmethod
    def from_json(cls, path: str) -> "WristMotionTokenizer":
        """Load a WristMotionTokenizer from a motion_tokens.json file.

        Args:
            path: Path to the JSON file.

        Returns:
            WristMotionTokenizer instance.
        """
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        ranges = data["ranges"]
        return cls(
            k=data["k"],
            x_range=(ranges["x"]["lo"], ranges["x"]["hi"]),
            y_range=(ranges["y"]["lo"], ranges["y"]["hi"]),
            z_range=(ranges["z"]["lo"], ranges["z"]["hi"]),
            token_format=data.get("token_format", "<|motion_{axis}_{idx:04d}|>"),
        )


# ------------------------------------------------------------------
# Convenience: world-to-first-frame-camera transform
# ------------------------------------------------------------------

def transform_points_world_to_first_cam(
    world_xyz: np.ndarray,
    extrinsics: np.ndarray,
) -> np.ndarray:
    """Transform world-space points to the first-frame camera coordinate system.

    Args:
        world_xyz: np.ndarray, shape [T, 3], wrist translations in world space.
        extrinsics: np.ndarray, shape [T, 4, 4] or [4, 4], World2Cam matrices.

    Returns:
        traj_first_cam: np.ndarray, shape [T, 3], points in first-frame camera space.

    Raises:
        ValueError: If extrinsics has unexpected ndim.
    """
    world_xyz = np.asarray(world_xyz, dtype=np.float32)
    if world_xyz.ndim != 2 or world_xyz.shape[1] != 3:
        raise ValueError(f"world_xyz must be [T, 3], got {world_xyz.shape}")

    extrinsics = np.asarray(extrinsics, dtype=np.float64)
    if extrinsics.ndim == 3:
        E0 = extrinsics[0]
    elif extrinsics.ndim == 2:
        E0 = extrinsics
    else:
        raise ValueError(f"extrinsics must be [T, 4, 4] or [4, 4], got ndim={extrinsics.ndim}")

    if E0.shape != (4, 4):
        raise ValueError(f"Extrinsic matrix must be [4, 4], got {E0.shape}")

    # Homogeneous coordinates
    T = world_xyz.shape[0]
    world_h = np.concatenate([world_xyz, np.ones((T, 1), dtype=np.float32)], axis=-1)  # [T, 4]
    traj_first_cam = (E0 @ world_h.T).T[:, :3]  # [T, 3]
    return traj_first_cam.astype(np.float32)

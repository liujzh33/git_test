#!/usr/bin/env python3
# Copyright (c) VITRA Motion SFT Experiment Contributors. All rights reserved.
"""Prepare Qwen3-VL-2B-Instruct model with extended vocabulary for motion tokens.

Adds 3072 special tokens (<|motion_x_0000|> ... <|motion_z_1023|>) to the
tokenizer, resizes model embeddings, and saves the extended model.

Usage:
    python scripts/prepare_qwen3vl_motion_token_model.py
    python scripts/prepare_qwen3vl_motion_token_model.py --overwrite
"""

import argparse
import json
import logging
import os
import sys

import torch
from transformers import AutoProcessor, AutoTokenizer, Qwen3VLForConditionalGeneration

# Add scripts dir to path for motion_tokenizer import
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from motion_tokenizer import WristMotionTokenizer

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Extend Qwen3-VL tokenizer with motion tokens")
    parser.add_argument(
        "--model_path",
        type=str,
        default="/home/ma-user/work/wx1469573/Motus/pretrained_models/Qwen3-VL-2B-Instruct",
        help="Path to the original Qwen3-VL-2B-Instruct model.",
    )
    parser.add_argument(
        "--output_path",
        type=str,
        default="/home/ma-user/work/wx1469573/Motus/pretrained_models/Qwen3-VL-2B-Instruct-motion-token",
        help="Path to save the extended model.",
    )
    parser.add_argument(
        "--num_bins",
        type=int,
        default=1024,
        help="Number of bins per axis for motion tokens.",
    )
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="Overwrite output directory if it exists.",
    )
    parser.add_argument(
        "--cpu",
        action="store_true",
        help="Force CPU loading (slower but safe for limited GPU memory).",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()

    # --- Validate paths ---
    if not os.path.isdir(args.model_path):
        raise FileNotFoundError(f"Model path not found: {args.model_path}")

    if os.path.exists(args.output_path):
        if args.overwrite:
            logger.warning(f"Output path exists, overwriting: {args.output_path}")
        else:
            raise FileExistsError(
                f"Output path already exists: {args.output_path}. "
                "Use --overwrite to replace it."
            )

    # --- Build motion tokens ---
    tokenizer_builder = WristMotionTokenizer(k=args.num_bins)
    motion_tokens = tokenizer_builder.build_motion_tokens()
    logger.info(f"Built {len(motion_tokens)} motion tokens (bins={args.num_bins} x 3 axes)")

    # --- Load original model and tokenizer ---
    logger.info(f"Loading model from: {args.model_path}")
    device_map = "cpu" if args.cpu else "auto"
    torch_dtype = torch.float32 if args.cpu else torch.bfloat16

    processor = AutoProcessor.from_pretrained(
        args.model_path, trust_remote_code=True, local_files_only=True
    )
    tokenizer = AutoTokenizer.from_pretrained(
        args.model_path, trust_remote_code=True, local_files_only=True
    )

    original_vocab_size = len(tokenizer)
    logger.info(f"Original vocab size: {original_vocab_size}")

    model = Qwen3VLForConditionalGeneration.from_pretrained(
        args.model_path,
        trust_remote_code=True,
        torch_dtype=torch_dtype,
        device_map=device_map,
        local_files_only=True,
    )

    # --- Add special tokens ---
    num_added = tokenizer.add_special_tokens(
        {"additional_special_tokens": motion_tokens},
        replace_additional_special_tokens=False,
    )
    logger.info(f"Added {num_added} new special tokens to tokenizer")

    # Also update the processor's tokenizer if it's a separate object
    if hasattr(processor, "tokenizer") and processor.tokenizer is not tokenizer:
        num_added_proc = processor.tokenizer.add_special_tokens(
            {"additional_special_tokens": motion_tokens},
            replace_additional_special_tokens=False,
        )
        logger.info(f"Added {num_added_proc} new special tokens to processor.tokenizer")

    # --- Resize model embeddings ---
    new_vocab_size = len(tokenizer)
    logger.info(f"New vocab size: {new_vocab_size}")
    model.resize_token_embeddings(new_vocab_size)

    # Verify embedding size matches
    embed_dim = model.get_input_embeddings().weight.shape[0]
    assert embed_dim == new_vocab_size, (
        f"Embedding size mismatch: {embed_dim} != {new_vocab_size}"
    )
    logger.info(f"Model embedding resized to: {embed_dim}")

    # --- Save ---
    os.makedirs(args.output_path, exist_ok=True)
    logger.info(f"Saving extended model to: {args.output_path}")

    model.save_pretrained(args.output_path, safe_serialization=True)
    tokenizer.save_pretrained(args.output_path)
    processor.save_pretrained(args.output_path)

    # Save motion tokens metadata
    tokenizer_builder.save_motion_tokens_json(os.path.join(args.output_path, "motion_tokens.json"))

    # --- Summary ---
    print("\n" + "=" * 60)
    print("Qwen3-VL Motion Token Model Preparation - Summary")
    print("=" * 60)
    print(f"  Original model:     {args.model_path}")
    print(f"  Output path:        {args.output_path}")
    print(f"  Original vocab:     {original_vocab_size}")
    print(f"  Added tokens:       {num_added}")
    print(f"  New vocab:          {new_vocab_size}")
    print(f"  Motion tokens:      {len(motion_tokens)}")
    print(f"  Bins per axis:      {args.num_bins}")
    print(f"  Token range:        <|motion_x_0000|> ... <|motion_z_{args.num_bins - 1:04d}|>")
    print("=" * 60)

    # Quick verification: encode a motion token and check it's a single token
    test_token = motion_tokens[0]
    token_ids = tokenizer.encode(test_token, add_special_tokens=False)
    if len(token_ids) == 1:
        logger.info(f"Verification PASSED: '{test_token}' -> single token id {token_ids[0]}")
    else:
        logger.warning(
            f"Verification FAILED: '{test_token}' -> {len(token_ids)} tokens: {token_ids}. "
            "Motion tokens may not be recognized as single tokens!"
        )

    # --- Reload verification ---
    logger.info("Reloading model from output path to verify integrity...")
    try:
        reload_model = Qwen3VLForConditionalGeneration.from_pretrained(
            args.output_path, trust_remote_code=True, torch_dtype=torch.float32,
            device_map="cpu", local_files_only=True,
        )
        reload_tokenizer = AutoTokenizer.from_pretrained(
            args.output_path, trust_remote_code=True, local_files_only=True,
        )
        reload_vocab = len(reload_tokenizer)
        reload_embed = reload_model.get_input_embeddings().weight.shape[0]
        assert reload_vocab == new_vocab_size, f"Reloaded vocab mismatch: {reload_vocab} != {new_vocab_size}"
        assert reload_embed == new_vocab_size, f"Reloaded embed mismatch: {reload_embed} != {new_vocab_size}"
        # Re-verify single token
        reload_ids = reload_tokenizer.encode(test_token, add_special_tokens=False)
        assert len(reload_ids) == 1, f"Reloaded tokenizer: {test_token} -> {len(reload_ids)} tokens"
        logger.info(
            f"Reload verification PASSED: vocab={reload_vocab}, embed={reload_embed}, "
            f"single-token check OK"
        )
        del reload_model  # Free memory
    except Exception as e:
        logger.warning(f"Reload verification failed: {e}")


if __name__ == "__main__":
    main()

#!/bin/bash
# ============================================================
# Qwen3-VL-2B-Instruct + VITRA-1M Motion Token SFT
# ============================================================
# This script trains a Qwen3-VL-2B model to predict 3D wrist
# motion trajectories as motion token sequences.
#
# Prerequisites:
#   1. Run prepare_qwen3vl_motion_token_model.py to create the
#      extended vocabulary model.
#   2. Run prepare_vitra_motion_sft_data.py to generate SFT data.
#   3. Run check_motion_sft_data.py to verify data integrity.
#
# Quick test (dry-run with small data):
#   Add --max_steps 10 --eval_strategy no
#
# Full fine-tuning instead of LoRA:
#   Change --tuner_type to "full" and adjust learning_rate to 2e-5.
#   Remove --lora_rank, --lora_alpha, --target_modules.
#   May need more GPU memory or DeepSpeed ZeRO-3.
# ============================================================

set -e

# ---- Paths ----
MODEL_PATH="/home/ma-user/work/wx1469573/Motus/pretrained_models/Qwen3-VL-2B-Instruct-motion-token"
DATA_DIR="/cache/wx1469573/data/VITRA-1M-ms-swift-motion-sft"
OUTPUT_DIR="/home/ma-user/work/wx1469573/Motus/outputs/qwen3vl_vitra_motion_sft"

# ---- Validate paths ----
if [ ! -d "$MODEL_PATH" ]; then
    echo "ERROR: Extended model not found at $MODEL_PATH"
    echo "Run: python scripts/prepare_qwen3vl_motion_token_model.py"
    exit 1
fi

if [ ! -f "$DATA_DIR/train.jsonl" ]; then
    echo "ERROR: SFT data not found at $DATA_DIR/train.jsonl"
    echo "Run: python scripts/prepare_vitra_motion_sft_data.py"
    exit 1
fi

# ---- Training Configuration ----
# LoRA SFT (recommended for limited GPU memory)
# For full fine-tuning: change tuner_type to "full", lr to 2e-5,
# remove lora_rank/alpha/target_modules, use deepspeed zero3

NPROC_PER_NODE=1
CUDA_VISIBLE_DEVICES=1

# For multi-GPU LoRA (e.g., 4 GPUs):
# NPROC_PER_NODE=4
# CUDA_VISIBLE_DEVICES=0,1,2,3

# max_length needs to accommodate:
#   image tokens (~256 for Qwen3-VL with default resolution) +
#   prompt (~50 tokens) +
#   motion tokens (max_traj_len * 3 = 384 for 128 waypoints)
# 2048 is sufficient for most cases; increase if needed

MAX_LENGTH=2048

# Motion token sequence length: max_traj_len * 3 tokens
# If you used --max_traj_len 256, set MAX_LENGTH=4096 or higher

# CRITICAL: --modules_to_save makes the new motion token embeddings
# and lm_head fully trainable alongside LoRA adapters. Without this,
# the 3072 newly initialized motion token embeddings would stay random
# because LoRA only trains low-rank adapter matrices, not the base
# embedding weights.
#
# PEFT's modules_to_save wraps the specified modules so they are
# trained as full parameters (not via LoRA), while other linear layers
# get LoRA adapters via --target_modules all-linear.
#
# Verified module names for Qwen3-VL-2B:
#   - model.language_model.embed_tokens (Embedding)
#   - lm_head (Linear, tied with embed_tokens)
#
# Note: --trainable_parameters only works with tuner_type=full,
# not with LoRA. For LoRA, use --modules_to_save instead.

# ============================================================
# LoRA SFT (commented out)
# ============================================================
# IMAGE_MAX_TOKEN_NUM=1024 \
# NPROC_PER_NODE=${NPROC_PER_NODE} \
# CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES} \
# python scripts/train_with_logging.py \
#     --model "${MODEL_PATH}" \
#     --model_type qwen3_vl \
#     --dataset "${DATA_DIR}/train.jsonl" \
#     --val_dataset "${DATA_DIR}/val.jsonl" \
#     --tuner_type lora \
#     --torch_dtype bfloat16 \
#     --num_train_epochs 3 \
#     --per_device_train_batch_size 1 \
#     --per_device_eval_batch_size 1 \
#     --learning_rate 1e-4 \
#     --lora_rank 16 \
#     --lora_alpha 32 \
#     --target_modules all-linear \
#     --modules_to_save model.language_model.embed_tokens lm_head \
#     --freeze_vit true \
#     --freeze_aligner true \
#     --gradient_accumulation_steps 8 \
#     --gradient_checkpointing true \
#     --eval_steps 200 \
#     --save_steps 200 \
#     --save_total_limit 5 \
#     --logging_steps 10 \
#     --max_length ${MAX_LENGTH} \
#     --output_dir "${OUTPUT_DIR}" \
#     --warmup_ratio 0.05 \
#     --dataloader_num_workers 4 \
#     --dataset_num_proc 4 \
#     --deepspeed zero2 \
#     --save_only_model true \
#     --load_from_cache_file false \
#     --report_to tensorboard

# ============================================================
# Full fine-tuning (active)
# ============================================================
IMAGE_MAX_TOKEN_NUM=1024 \
NPROC_PER_NODE=4 \
CUDA_VISIBLE_DEVICES=1,2,3,4 \
python scripts/train_with_logging.py \
    --model "${MODEL_PATH}" \
    --model_type qwen3_vl \
    --dataset "${DATA_DIR}/train.jsonl" \
    --val_dataset "${DATA_DIR}/val.jsonl" \
    --tuner_type full \
    --torch_dtype bfloat16 \
    --num_train_epochs 3 \
    --per_device_train_batch_size 16 \
    --per_device_eval_batch_size 16 \
    --learning_rate 8e-5 \
    --freeze_vit true \
    --freeze_aligner true \
    --trainable_parameters model.language_model.embed_tokens \
    --gradient_accumulation_steps 2 \
    --gradient_checkpointing true \
    --eval_steps 5000 \
    --save_steps 5000 \
    --save_total_limit 20 \
    --logging_steps 1 \
    --max_length ${MAX_LENGTH} \
    --output_dir "${OUTPUT_DIR}" \
    --warmup_ratio 0.15 \
    --dataloader_num_workers 4 \
    --dataset_num_proc 4 \
    --deepspeed zero3 \
    --load_from_cache_file false \
    --report_to tensorboard \
    --max_steps 50000

# ============================================================
# Smoke test: add these flags to the swift sft command
# ============================================================
# --max_steps 10 --eval_strategy no
# This runs only 10 steps to verify the pipeline works end-to-end.

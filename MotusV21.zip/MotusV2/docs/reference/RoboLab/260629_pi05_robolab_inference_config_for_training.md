# RoboLab Pi0.5 推理配置对齐文档

本文档用于指导 World-Action-Model 在 DROID 数据集上做后训练时，对齐当前 RoboLab 中 `pi05` / Pi0.5 policy 的推理设定，避免训练与评测时 observation、action、camera、prompt、action chunk 或 gripper 语义不一致。

## 1. 当前评测入口

RoboLab 端使用：

```bash
uv run python policies/pi0_family/run.py --policy pi05 ...
```

OpenPI server 使用：

```bash
XLA_PYTHON_CLIENT_MEM_FRACTION=0.5 uv run scripts/serve_policy.py policy:checkpoint \
  --policy.config=pi05_droid_jointpos \
  --policy.dir=gs://openpi-assets-simeval/pi05_droid_jointpos
```

RoboLab client：

```python
policies.pi0_family.client.Pi0DroidJointposClient
```

重要结论：

- 当前 RoboLab Pi0.5 评测是 DROID joint-position / qpos 动作设定。
- 不是 EEF pose / IK / delta pose 动作设定。
- 训练 WAM 时应优先复用同一 observation/action schema。

## 2. Policy / server / client 对应关系

| 项目 | 当前 RoboLab 设定 |
|---|---|
| RoboLab policy name | `pi05` |
| OpenPI server config | `pi05_droid_jointpos` |
| OpenPI checkpoint | `gs://openpi-assets-simeval/pi05_droid_jointpos` |
| RoboLab client | `Pi0DroidJointposClient` |
| Server protocol | WebSocket client policy |
| 默认 host/port | `localhost:8000` |
| action mode | joint position / qpos |
| open-loop horizon | `15` for `pi05` |

## 3. Observation schema

Pi0.5 client 从 RoboLab raw observation 中读取：

```python
raw_obs["image_obs"]["over_shoulder_left_camera"]
raw_obs["image_obs"]["wrist_cam"]
raw_obs["proprio_obs"]["arm_joint_pos"]
raw_obs["proprio_obs"]["gripper_pos"]
```

然后打包成 OpenPI request：

```python
{
    "observation/exterior_image_1_left": resize_with_pad(over_shoulder_left_camera, 224, 224),
    "observation/wrist_image_left": resize_with_pad(wrist_cam, 224, 224),
    "observation/joint_position": arm_joint_pos,
    "observation/gripper_position": gripper_pos,
    "prompt": instruction,
}
```

训练时建议严格使用相同 key 或在 dataloader 中显式映射到这些语义。

### 3.1 图像输入

| OpenPI request key | RoboLab source | 语义 | 训练要求 |
|---|---|---|---|
| `observation/exterior_image_1_left` | `image_obs.over_shoulder_left_camera` | 左侧 over-shoulder 外部视角 | resize/pad 到 `224 x 224` |
| `observation/wrist_image_left` | `image_obs.wrist_cam` | Robotiq gripper wrist camera | resize/pad 到 `224 x 224` |

注意：

- RoboLab client 代码里局部变量名叫 `right_image`，但实际读取的是 `over_shoulder_left_camera`。训练配置不要被变量名误导。
- 当前 Pi0.5 评测默认不使用 `over_shoulder_right_camera`、`head_camera` 或 viewport camera。
- viewport / egocentric mirrored camera 主要用于视频记录，不进入 Pi0.5 policy request。
- 原始仿真相机分辨率通常是 `720 x 1280 x 3`，送入 policy 前用 `openpi_client.image_tools.resize_with_pad(..., 224, 224)`。

### 3.2 Proprio 输入

| OpenPI request key | RoboLab source | shape | 语义 |
|---|---|---:|---|
| `observation/joint_position` | `proprio_obs.arm_joint_pos` | `(7,)` | Franka 7-dof arm joint positions |
| `observation/gripper_position` | `proprio_obs.gripper_pos` | `(1,)` | normalized gripper position |

`arm_joint_pos` 的 joint 顺序：

```text
panda_joint1
panda_joint2
panda_joint3
panda_joint4
panda_joint5
panda_joint6
panda_joint7
```

`gripper_pos` 的定义：

```python
gripper_pos = finger_joint_position / (pi / 4)
```

即：

- `0.0` 近似 open；
- `1.0` 近似 close；
- RoboLab observation 里会对 gripper position 加 observation noise 配置并 clip 到 `[0, 1]`，但 Pi0.5 client 只接收最终 observation 值。

注意：

- RoboLab proprio group 里还存在 `ee_pos`、`ee_quat`、`eef_pos`、`eef_quat`。
- 当前 Pi0.5 client 没有把这些 EE/EFF pose 字段发给 OpenPI server。
- WAM 如果要和 Pi0.5 公平比较，应避免在默认配置中额外使用 EEF pose，除非明确作为 ablation。

### 3.3 Language 输入

Pi0.5 request key：

```python
"prompt": instruction
```

RoboLab 评测中 instruction 来自任务配置和 `--instruction-type`。如果评估使用：

```bash
--instruction-type specific
```

训练/验证也应明确区分 `specific`、`default`、`vague` 等 instruction 类型，不要混用不同 instruction source 的结果。

## 4. Action schema

当前 RoboLab 评测注册的是：

```python
auto_register_droid_envs(...)
actions_cfg = DroidJointPositionActionCfg()
```

动作空间由两部分组成：

| action slice | RoboLab action term | dim | 语义 |
|---|---|---:|---|
| `action[0:7]` | `body` / `panda_joint.*` | 7 | absolute joint position command |
| `action[7]` | `finger_joint` | 1 | binary gripper command |

因此单步 action 维度通常是：

```text
8 = 7 arm joints + 1 gripper
```

训练 target action 应与此保持一致：

```text
[panda_joint1, panda_joint2, panda_joint3, panda_joint4, panda_joint5, panda_joint6, panda_joint7, gripper]
```

不要把 action target 设成：

- EEF position；
- EEF quaternion；
- delta EEF pose；
- IK command；
- velocity action；
- normalized delta joint action。

除非你明确要做另一个 policy/backend，并且 RoboLab 评测端也同步改成对应 action cfg。

## 5. Gripper 语义与后处理

Pi0.5 client 对 server 返回的 action chunk 做后处理：

```python
chunk[..., -1] = (chunk[..., -1] > 0.5).astype(chunk.dtype)
```

RoboLab action term `BinaryJointPositionZeroToOneAction` 中也使用：

```python
binary_mask = actions > 0.5
processed = close_command if binary_mask else open_command
```

其中：

```python
open_command  = 0.0
close_command = pi / 4
```

训练建议：

- gripper target 使用 `0/1` 或能被 `>0.5` 正确解释的连续值。
- `0` 表示 open。
- `1` 表示 close。
- 推理时最后一维会被阈值化，不应依赖 gripper action 的连续幅值。

## 6. Action chunk 与 open-loop horizon

OpenPI server 返回：

```python
response["actions"]
```

RoboLab client 将其转为：

```python
np.asarray(response["actions"])
```

期望 shape：

```text
(chunk_length, action_dim)
```

对 `pi05`，RoboLab client 默认：

```python
open_loop_horizon = 15
```

推理控制逻辑：

1. 当前 env 没有 cached action chunk，或已执行满 `open_loop_horizon` 步时，请求 server。
2. server 返回一个 action chunk。
3. client 对整个 chunk 的最后一维 gripper 做二值化。
4. 每个仿真 step 取 chunk 中下一条 action 执行。
5. 执行 15 步后重新 query server。

训练建议：

- action chunk 长度应与 Pi0.5 训练/推理设定保持一致，默认使用 `15`。
- 如果 WAM 输出 chunk，建议输出 shape 为 `(15, 8)`。
- 如果 WAM 内部预测更长 horizon，评测端仍需明确只以相同 open-loop horizon 执行，或在报告中说明差异。

## 7. Camera 与 robot 配置

当前默认 camera preset：

```python
WRIST_LEFT = [
    OverShoulderLeftCameraCfg,
    WristCameraCfg,
]
```

其中：

- `OverShoulderLeftCameraCfg.over_shoulder_left_camera`
  - 分辨率：`720 x 1280`
  - policy 前处理：`resize_with_pad(..., 224, 224)`
- `DroidCfg.wrist_cam`
  - mounted at Robotiq gripper base link
  - 分辨率：`720 x 1280`
  - policy 前处理：`resize_with_pad(..., 224, 224)`

Robot：

- Franka arm + Robotiq 2F-85 gripper；
- joint action 使用 `panda_joint.*`；
- gripper action 使用 `finger_joint`；
- wrist camera 位于 `/robot/Gripper/Robotiq_2F_85/base_link/wrist_cam`。

## 8. 训练配置 checklist

Claude Code 组织训练配置和代码时，应逐项检查：

- [ ] policy / dataset schema 使用 `jointpos`，不是 EEF / IK。
- [ ] image inputs 只有：
  - [ ] `exterior_image_1_left` ← over-shoulder-left；
  - [ ] `wrist_image_left` ← wrist camera。
- [ ] 两路图像都使用 resize-with-pad 到 `224 x 224`，不要直接 crop 导致视角分布变化。
- [ ] proprio inputs 只有：
  - [ ] 7-dof arm joint position；
  - [ ] 1-dim gripper position。
- [ ] language input 使用 task instruction / prompt。
- [ ] action target 是 `(15, 8)` chunk，或等价的 15-step chunk format。
- [ ] 单步 action 顺序是 7 个 Panda joints + 1 个 gripper。
- [ ] gripper target / output 最后一维使用 open=0、close=1 语义。
- [ ] 推理后处理会对 gripper 做 `>0.5` threshold。
- [ ] 不额外使用 EEF pose、right camera、head camera、viewport camera，除非作为明确 ablation。
- [ ] 评测时 RoboLab runner 使用 `policies/pi0_family/run.py --policy pi05` 或 WAM 对应 runner 但保持同一 env registration/action cfg。

## 9. 最小伪代码

训练样本建议整理成如下语义：

```python
sample = {
    "observation/exterior_image_1_left": resize_with_pad(over_shoulder_left_camera, 224, 224),
    "observation/wrist_image_left": resize_with_pad(wrist_cam, 224, 224),
    "observation/joint_position": np.array([q1, q2, q3, q4, q5, q6, q7], dtype=np.float32),
    "observation/gripper_position": np.array([gripper_open_close], dtype=np.float32),
    "prompt": instruction,
    "actions": np.array([
        [q1_t1, q2_t1, q3_t1, q4_t1, q5_t1, q6_t1, q7_t1, grip_t1],
        ...
        [q1_t15, q2_t15, q3_t15, q4_t15, q5_t15, q6_t15, q7_t15, grip_t15],
    ], dtype=np.float32),
}
```

其中：

```python
sample["actions"].shape == (15, 8)
```

## 10. 代码依据

当前文档基于以下 RoboLab 文件核对：

- `policies/pi0_family/run.py`
- `policies/pi0_family/client.py`
- `policies/pi0_family/README.md`
- `robolab/registrations/droid/auto_env_registrations_jointpos.py`
- `robolab/registrations/droid/camera_presets.py`
- `robolab/robots/droid.py`

# train_log_extra.md — CKPT_WamVlmMask_droid_v4_2cams_9w_steps 补充信息

日志：`docs/ddp-680c9fb3-91f-master-0.log`（20.2 MB，104368 行，rank 0）
配置名（日志 `Config File` 行）：`droid_wan_vlm_mask_2cam.yaml`
摘要脚本产出：`/tmp/train_log_summary.md`

> ⚠️ 命名与实际步数的出入：权重名为 `..._9w_steps`（9 万步），但日志显示训练实际跑到 **max_steps=100000**（10 万步）正常结束（见第 7 条）。`best_action_l2` 权重对应 **step 70000**（见第 5 条），另有周期性 `checkpoint_step_100000`。9w 这个名字与日志对不上，需确认交付的到底是 step_90000 周期 ckpt、best_action_l2(step 70000)、还是 step_100000。

---

## 1. 实际生效的配置

训练时写入 checkpoint 目录的契约文件 `config.json` 和启动拷贝的 yaml 都在集群本地路径，本机不可访问：

- `config.json`：`/cache/wx1469573/ckpts/checkpoints_wan_vlm_mask_droid_2cam/droid_wan_vlm_mask_2cam/droid_wan_vlm_mask_2cam/best_action_l2/config.json` → 本机 `ls` 报 No such file or directory（`/cache/` 是集群路径）
- 启动 yaml：`/cache/wx1469573/ckpts/tensorboard_wan_vlm_mask_droid_2cam/2026-08-12_23-40-28/droid_wan_vlm_mask_2cam.yaml` → 同样不可访问

但日志里 `Config File` 指向的文件名与仓库源文件 `configs/droid_wan_vlm_mask_2cam.yaml` 同名，内容应一致。仓库源文件关键项（`configs/droid_wan_vlm_mask_2cam.yaml`）：

- `common.action_dim: 8`（7 panda joints + 1 gripper，qpos），`state_dim: 8`
- `num_video_frames: 8`，`video_action_freq_ratio: 2` → action chunk = 16
- `video 384x320`，`camera_layout: v_stack`（exterior 上 / wrist 下，各占一半），`random_exterior: true`
- `dataset.require_success: true`，`filter_idle: true`（idle_min_len=7 等）
- `action_normalization: true`，`norm_stats_path: null`（→ `data/droid/droid_norm_stats.json`），arm 维 delta w.r.t. 条件帧、gripper 绝对、q01/q99 缩放到 [-1,1]
- `model.training_mode: finetune`（state+action + 4 register tokens），`finetune.checkpoint_path: /cache/.../pretrained_models/ckpt`
- `video_flow_shift: 5.0`，`action_flow_shift: 1.0`（uniform sigma；日志 `P(sigma<0.1)=0.099 P(sigma<0.5)=0.499` 证实）
- `inference.num_inference_timesteps: 10`（注释里说 20 比 10 好，但实际配的是 10）
- `loss_weights`：只有 `video_loss_weight: 1.0` 和 `action_loss_weight: 1.0`，**没有 token 项** → 这解释了第 4 条 token loss 恒为 0
- `ema.enabled: false`
- `training.batch_size: 12`，`gradient_accumulation_steps: 1`，`max_steps: 100000`
- `learning_rate / wan_learning_rate / vlm_learning_rate` 均为 `5.0e-5`
- `scheduler_type: linear`，`warmup_steps: 200`，`cycle_length: 5000000`，`f_max: 0.99`，`f_min: 0.4`
- `system.save_interval: 10000`，`val_interval: 500`，`num_workers: 16`
- `resume.checkpoint_path: null`（从 finetune ckpt 新启动，非断点续训）

checkpoint 目录（集群路径）下的产物（从日志可见）：`best_action_l2/`、`checkpoint_step_100000/`，以及周期性 `checkpoint_step_10000` … `checkpoint_step_90000`、`checkpoint_step_80000` 等（在末尾 OBS 上传列表里出现）。

## 2. 并行规模与真实 batch

```
WORLD_SIZE=4                                  # 每节点 4 卡（环境变量）
MotusWanVlmDirect Trainer initialized on rank 0/32   # 总 32 进程 = 8 节点 × 4 卡
Gradient accumulation steps: 1
batch_size: 12  (per GPU, 来自 yaml)
```

- **总卡数 world_size = 32**，每卡 `batch_size=12`，`grad_accum=1` → **全局 batch = 384**
- rank-0 采样计数佐证：step 500 时 rank-0 累计 6012 个样本 ≈ 500×12，与每卡 12 一致
- 每 epoch ≈ 63 步（见摘要 `Steps per epoch: 63.0`）→ 一个 epoch 全局只过 63×384 ≈ 24192 个样本

## 3. 数据集规模

```
DROID: skipped 1360 episodes with corrupt/truncated video files (4 unique bad mp4s)
DROID: skipped 16794 episodes with is_episode_successful=False
DroidLeRobotDataset: 77504 episodes indexed (fps=15.0, chunk=16, ds=1)
resolving instructions for 77504 indexed episodes
Dataloader creation took 42.0s (storage_mode=local)
```

- **过滤后实际索引 77504 个 episode**（成功 + 非损坏），不是请求文档里假设的 7566/6205。7566 那个数字应来自更早一次仅用于算归一化统计的子集，本次训练用的是完整 DROID 子集（77504）。
- 77504 episode、全局 batch 384、63 步/epoch → 一个 epoch 只采样 ~24192 个样本，**远小于 episode 数**，意味着每个 epoch 只触及数据集的一小部分。
- 100000 步 / 63 ≈ **1587 个 epoch**。即使数据集有 77504 个 episode，重复 1587 轮仍属大量重复曝光（见下一条关于 sampler 的说明）。
- 任务采样分布在训练全程几乎不变（step 500 / 50000 / 99500 的 top 任务占比一致，`manipulate the object` 始终 ~5.3%），说明采样顺序稳定（与未调 `set_epoch` 一致）。

## 4. 是否发生过断点续训

```
grep -nE "Loading checkpoint from|Resetting scheduler|Checkpoint loaded successfully|Resumed|resumed" → 无任何匹配
```

- **没有断点续训**。从 step 1 单调递增到 step 100000，摘要里 `Step-number regressions (resume markers): 0`。
- 启动方式：`resume.checkpoint_path: null` + `finetune.checkpoint_path` 加载预训练 backbone，属于冷启动 finetune，不是 resume。
- 中途有两次大的时间跳变（step ~22000→~62000 之间日志时间从 08-13 22:03 跳到 08-16 04:41，约 2.5 天），但 step 编号连续、无 `Loading checkpoint` / `Resetting scheduler`，说明是训练在跑（可能含停机占位或评估间隔），不是 resume。best_action_l2 的保存时间也连续递增。

## 5. 最优 action L2 出现在哪一步

`New best action L2 loss (action_l2_error)` 全部记录（共 8 次刷新）：

| step | best action_l2_error | 时间 |
|---:|---:|---|
| 500 | 0.238396 | 08-13 00:21 |
| 2000 | 0.226296 | 08-13 02:11 |
| 2500 | 0.181385 | 08-13 02:49 |
| 11500 | 0.174637 | 08-13 13:56 |
| 14500 | 0.162289 | 08-13 17:41 |
| 18000 | 0.136365 | 08-13 22:02 |
| 62000 | 0.129734 | 08-16 04:41 |
| **70000** | **0.107000** | 08-16 14:38 |

- **最优 `best_action_l2` = 0.107000，出现在 step 70000**；之后 step 70000→100000（共 30000 步）**再未刷新** best。
- 即 `best_action_l2` 这个权重对应 step 70000 的状态，不是最终步。最终步 step 100000 的验证 `action_l2_error=0.1511`、`action_mse_loss=0.0738`（见第 6 条），比 best 差。
- 注意：验证集 = 训练集（见请求文档第 4 条第 2 点），且每次只评 2 个 batch（`Running UniDiffuser evaluation for 2 batches...`），所以这个 best 反映的是在固定 2 个训练 batch 上的拟合，不是泛化。

## 6. 最后一次验证的原始输出

日志最末尾的完整验证块（step 100000，行 104298–104309）：

```
[Rank 0] 2026-08-18 03:50:24 - __main__ - INFO - Validation - Step 100000
[Rank 0] 2026-08-18 03:50:26 - sample - INFO - === UniDiffuser Evaluation Results ===
[Rank 0] 2026-08-18 03:50:26 - sample - INFO -   video_mse: 0.0152
[Rank 0] 2026-08-18 03:50:26 - sample - INFO -   video_mse_std: 0.0018
[Rank 0] 2026-08-18 03:50:26 - sample - INFO -   action_mse_loss: 0.0738
[Rank 0] 2026-08-18 03:50:26 - sample - INFO -   action_mse_loss_std: 0.0088
[Rank 0] 2026-08-18 03:50:26 - sample - INFO -   action_l2_error: 0.1511
[Rank 0] 2026-08-18 03:50:26 - sample - INFO -   action_l2_error_std: 0.0089
[Rank 0] 2026-18 03:50:26 - sample - INFO -   action_mse_std: 0.0967
[Rank 0] 2026-08-18 03:50:26 - sample - INFO -   action_mse_std_std: 0.0242
[Rank 0] 2026-08-18 03:50:26 - sample - INFO -   action_l2_std: 0.0970
[Rank 0] 2026-08-18 03:50:26 - sample - INFO -   action_l2_std_std: 0.0060
```

对照请求文档第一节：step 1000 时 `action_mse_loss=0.186`（≈ 均值基线 0.195，R²≈0.046）。到 step 100000 该值降到 **0.0738**，`action_l2_error=0.1511`。即在训练集的固定 2 个 batch 上，采样输出已显著优于均值基线 —— 但这是训练集拟合，不是 OOD 泛化（RoboLab 6.88% 是分布外）。

验证曲线全程（200 个 block）`action_mse_loss` 在 0.04–0.23 间剧烈抖动（受 2-batch 评估的高方差驱动，`action_mse_loss_std` 常达 0.03–0.09），整体趋势从早期 ~0.13–0.19 缓慢下降到末期 ~0.05–0.10，但**并非单调**，且与训练 action loss（0.27→0.044）的下降幅度相比，验证下降温和得多 —— 这与“训练损失低、采样依赖条件弱”的判断一致：模型在训练分布上拟合良好，但验证指标本身就测在训练数据上，无法反映泛化。

## 7. 训练是否正常结束

日志最后 50 行（行 104310–104368）核心内容：

```
[Rank 0] 2026-08-18 03:50:26 - __main__ - INFO - Reached max_steps 100000, training complete!
... Saving current state to .../checkpoint_step_100000
... DeepSpeed Model and Optimizer saved ...
... Model 0 saved to .../checkpoint_step_100000/pytorch_model_0.bin
... Wrote config.json to .../checkpoint_step_100000
... Uploading checkpoint to OBS (node 4): checkpoint_step_100000 -> ...
------------------ Train End ------------------
------- Upload weights and logs to OBS -------
------- Final Upload: weights and logs to OBS -------
... (OBS 上传，含若干 Retry=9 警告)
multiprocessing.pool.RemoteTraceback:
  ...
  FileNotFoundError: No such file or directory: .../checkpoint_step_100000/pytorch_model/mp_rank_00_model_states.pt.upload_record
...
Upload checkpoints done: obs://yw-2030-gy/external/wx1469573/cache-DI/20260812_234011/checkpoints
Upload tensorboard logs done: obs://yw-2030-gy/external/wx1469573/cache-DI/20260812_234011/tensorboard_logs
==============training job finish!=================
training job result code: 0
```

- **训练正常结束**：`Reached max_steps 100000, training complete!` + `training job result code: 0`。
- 末尾的 `Traceback` / `FileNotFoundError` 来自 OBS 上传 moxing 框架对一个临时 `.upload_record` 文件的清理报错，发生在 **`Train End` 之后**的产物上传阶段，**不影响训练结果**：step 100000 的 checkpoint 和 best_action_l2 均已成功保存并上传（`Upload checkpoints done`、`Upload tensorboard logs done`）。摘要脚本把它归入 `Anomalies/error` 仅因匹配到 `Traceback` 关键字。
- 训练时间：08-12 23:45 起步 → 08-18 03:50 结束，约 5 天 4 小时（32 卡）。

---

## 附：对请求文档第四节各点的对照（基于完整日志）

1. **过拟合**：数据集规模修正为 **77504 episode**（非假设的 7566/6205）。但 100000 步仍 ≈ 1587 epoch，且 `DistributedSampler` 未调 `set_epoch`（任务分布全程不变即证据），每 epoch 仅 ~24192 样本 << 77504 episode，实际曝光重复度仍很高。过拟合风险仍在，只是不是“6000 场景重复 1350 遍”那种量级。

2. **验证测不出过拟合**：日志证实每次验证 `Running UniDiffuser evaluation for 2 batches...`（`num_eval_batches=2`，配置未显式设，走代码默认）。验证集 = 训练集（`val` 仅控增强开关，未划分 episode），且 sampler 未 set_epoch → 验证曲线是训练集固定 2 batch 上的拟合度，非泛化。**确认成立**。

3. **采样-训练不一致 / 条件通路弱**：训练 action loss 从 0.27（step 0–999）降到 0.044（step 99000–99999），去噪器拟合极强；验证 `action_mse_loss` 从 ~0.19 降到 ~0.07（best 单点 0.0393@step 92000）。step 1000 的矛盾（训练 0.11 vs 验证 0.186）在后续训练中**部分收敛**（验证也降了），但因为验证=训练集，这只能说明模型记住了训练分布的采样，不能否定“条件通路弱”的判断 —— RoboLab OOD 6.88% 仍是直接证据。第 5 节的离线 σ-分层实验仍值得做。

4. **token loss 恒为 0**：配置 `loss_weights` 只有 `video_loss_weight` 和 `action_loss_weight`，**无 token 项**。日志全程 `Token: 0.0000`（所有 100 个 bucket 精确为 0）。这是**配置上有意未启用 VLM token 预测头**（VLM 仅作特征提取参与 MoT），非接线错误。

5. **学习率与训练时长**：step 1 LR=2.48e-7（warmup 中），~step 800–1000 升至峰值 4.95e-5（≈ 5e-5，warmup 200 已结束），之后线性/余弦极缓衰减至 step 100000 的 4.89e-5 —— `cycle_length=5000000` 使衰减在 10 万步内几乎不可见（峰值 4.95e-5 → 末期 4.89e-5，仅降 1.2%）。三组 LR（main/wan/vlm）全程相等且同步。warmup 与衰减均符合配置。
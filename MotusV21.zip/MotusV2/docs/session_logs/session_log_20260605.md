# MotusV2 Motion Token Prediction — 实施记录

生成时间: 2026-06-05

## 修改文件清单

| # | 文件路径 | 修改类型 | 说明 |
|---|---------|---------|------|
| 1 | `utils/motion_tokenizer.py` | 新增 | WristMotionTokenizer: 3D 腕部轨迹 → 离散 motion token（从 ms-swift 复制） |
| 2 | `utils/vlm_utils.py` | 功能新增 | 新增 `preprocess_vlm_messages_with_motion_tokens()` 构建含 assistant 响应的 VLM 输入 + labels |
| 3 | `data/robotwin2/robotwin_agilex_dataset.py` | 功能新增 | 新增 `motion_token_prediction` 参数，__getitem__ 中构造 motion token labels |
| 4 | `data/dataset.py` | 功能新增 | `_robotwin()` 传递 motion_token_prediction 配置；`collate_fn()` 处理 motion_token_labels |
| 5 | `models/motus_wan_vlm_direct_mask.py` | 功能新增 | Config 新增 `token_loss_weight`；training_step 新增 token loss 计算（lm_head + cross_entropy） |
| 6 | `train/train_wan_vlm_mask.py` | 功能新增 | load_config 默认值；train_step 传参；log_metrics 显示 token_loss |
| 7 | `configs/robotwin_eepos_WanVlmMask_motion_token.yaml` | 新增 | Motion token prediction 训练配置（扩展词表 VLM + token_loss_weight=1.0） |
| 8 | `scripts/train_ADS_MotusV2_robotwin_eepos_motion_token.sh` | 新增 | 训练启动脚本（4 GPU） |

## 1. 项目目标

在 MotusV2 的训练框架中引入 VLM 的第三类监督信号：**token-loss**（next-token prediction on motion tokens），实现同时监督 video、action、token sequence 三类信号。

参考项目：ms-swift 中的 VITRA Motion SFT，采用 VIPA-VLA 方法论的 Route A: VLM SFT with next-token prediction on motion tokens。

## 2. 关键决策

### [决策-1] Motion Token 来源：从 action_sequence 推导
- RobotWin eepos 16-dim 布局: `[left_xyz(3), left_quat(4), left_grip(1), right_xyz(3), right_quat(4), right_grip(1)]`
- 提取 `left_xyz = action_sequence[:, 0:3]`，`right_xyz = action_sequence[:, 8:11]`
- 使用 WristMotionTokenizer 离散化为 1024 bins × 3 轴 = 3072 special tokens
- 不从外部数据源加载预计算的 motion tokens
- 归一化的 action 需要先 denormalize 再 tokenize（因为 bin 范围定义在原始坐标空间）

### [决策-2] 双手 Motion Token 序列
- 每个样本同时构造左右手的 motion token 序列
- 格式: `Left:<|motion_x_...|><|motion_y_...|><|motion_z_...|>...Right:<|motion_x_...|>...`
- 每个 waypoint 3 个 token，16 个 waypoints × 3 × 2 手 = 96 个 motion tokens

### [决策-3] VLM 模型：使用扩展词表模型
- 使用已准备好的 motion-token 扩展模型: `/cache/wx1469573/pretrained_models/Qwen3-VL-2B-Instruct-motion-token`
- 原始词表: 151669，扩展后: 154741 (新增 3072 motion tokens)
- Motion token ID 范围: 151669 ~ 154740
- 每个运动 token 是 vocab 中的单 token（验证通过）

### [决策-4] 全序列 MoT 方案
- 当 motion token prediction 启用时，VLM 输入序列包含完整的 user prompt + assistant response
- MoT 处理完整序列，VLM 特征被视频/动作信息增强
- Token loss 仅在 assistant 位置计算（user 位置 label = -100）
- **不再需要** 单独的第二遍 VLM forward pass

### [决策-5] Label 构造：Pre-shifted 方案
- 在 dataset 中预构造 labels: `labels[t] = input_ids[t+1]`
- User token 位置 label = -100
- Last position label = -100（无下一个 token）
- 模型中直接用 `cross_entropy(logits, labels)` 无需额外 shift

### [决策-6] 坐标范围
- Motion tokenizer 范围: x: [-0.5, 0.5], y: [-0.5, 0.5], z: [0.0, 1.2]
- z 范围从 VITRA 的 [0, 1.0] 扩展到 [0, 1.2] 以适应 RobotWin 数据
- 超出范围的值会被 clip 到 bin 边界

### [决策-7] 配置驱动：Token Loss 可开关
- `model.loss_weights.token_loss_weight: 0.0` = 关闭（默认），>0 = 开启
- `model.motion_token_prediction.enabled: true/false` 控制数据集是否构造 motion tokens
- 完全向后兼容：原始配置不受影响

## 3. 代码修改记录

### 3.1 新增文件

#### `utils/motion_tokenizer.py`
- 来源: 从 `/home/ma-user/work/wx1469573/ms-swift/scripts/motion_tokenizer.py` 复制
- 内容: `AxisRange` 数据类 + `WristMotionTokenizer` 类
- 核心方法:
  - `encode_indices(traj)`: [T,3] → [T,3] int bin indices
  - `encode_token_string(traj)`: → `"<|motion_x_0614|><|motion_y_0307|>..."`
  - `encode_tokens(traj)`: → List[str]
  - `build_motion_tokens()`: 生成 3072 个特殊 token 字符串
  - `decode_centers(indices)`: 反向解码
  - `clipping_stats(traj)`: 计算 clip 比率
  - `from_json()`: 从 JSON 加载
- 同时包含 `transform_points_world_to_first_cam()` 用于未来 VITRA 数据

#### `configs/robotwin_eepos_WanVlmMask_motion_token.yaml`
- 基于 `robotwin_eepos_WanVlmMask.yaml` 扩展
- 关键差异:
  - `model.vlm.checkpoint_path`: 指向扩展词表模型
  - `model.loss_weights.token_loss_weight: 1.0`
  - `model.motion_token_prediction.enabled: true`
  - `model.motion_token_prediction.num_bins: 1024`
  - `model.motion_token_prediction.z_range: [0.0, 1.2]`
  - checkpoint/tensorboard 目录名含 `_motion_token` 后缀

#### `scripts/train_ADS_MotusV2_robotwin_eepos_motion_token.sh`
- 训练启动脚本，指向新 YAML 配置
- 用户已修改为使用 4 GPU (CUDA_VISIBLE_DEVICES=4,5,6,7)

### 3.2 修改文件

#### `utils/vlm_utils.py`
- 新增函数 `preprocess_vlm_messages_with_motion_tokens()`
- 参数: text_instruction, image_pil, processor, left_motion_token_str, right_motion_token_str
- 逻辑:
  1. 构建 messages: user (image + instruction) + assistant (Left:token_str Right:token_str)
  2. `apply_chat_template(messages, add_generation_prompt=False)` — 包含完整响应
  3. 处理 vision info → processor → inputs
  4. 构造 labels: `labels[t] = input_ids[t+1]`，初始化为 -100
  5. 查找 `<|im_start|>assistant\n` 位置，`assistant_pos` 之前的 labels 设为 -100
  6. 返回 inputs dict + `labels` key
- 原有 `preprocess_vlm_messages()` 不变

#### `data/robotwin2/robotwin_agilex_dataset.py`
- `__init__` 新增参数 `motion_token_prediction: Optional[Dict[str, Any]] = None`
- `__init__` 新增初始化逻辑:
  - 解析 motion_token_prediction config
  - 实例化 WristMotionTokenizer (k=1024, 扩展 z 范围)
  - 加载扩展词表 AutoProcessor 作为 motion_token_processor
  - 设置 `self.motion_token_enabled` 标志
- `__getitem__` 修改:
  - 当 `motion_token_enabled` 时，不再走标准 VLM 处理分支
  - 提取 left_xyz (dims 0:3) 和 right_xyz (dims 8:11)
  - 如果有 normalization，先 denormalize 再 tokenize
  - 调用 `preprocess_vlm_messages_with_motion_tokens()` 构建完整 prompt+response
  - 从 mt_inputs 中 pop labels → `motion_token_labels`
  - 返回 dict 新增 `motion_token_labels` 字段

#### `data/dataset.py`
- `_robotwin()` 修改:
  - 检查 `config.model.motion_token_prediction.enabled`
  - 如果启用，构建 mt_config dict 并设置 `vlm_checkpoint_path`
  - 传入 `motion_token_prediction` 参数给 RobotWinTaskDataset
- `collate_fn()` 修改:
  - 新增 motion_token_labels 的 padding 逻辑
  - padding 值使用 -100（与 label mask 一致）
  - 不同长度的 labels 对齐到 max_label_len
  - 结果: `motion_token_labels: [B, max_seq_len]` int64

#### `models/motus_wan_vlm_direct_mask.py`
- `MotusWanVlmDirectMaskConfig` 新增:
  - `token_loss_weight: float = 0.0`
- `training_step()` 修改:
  - 新增参数 `motion_token_labels: Optional[torch.Tensor] = None`
  - 在 video_loss + action_loss 之后，如果 `token_loss_weight > 0`:
    - `token_logits = self.vlm_model.lm_head(vlm_tokens)` — 使用 MoT 更新后的 VLM 特征
    - `cross_entropy(token_logits, motion_token_labels, ignore_index=-100)`
    - 累加到 total_loss
  - 返回 dict 新增 `token_loss` 字段

#### `train/train_wan_vlm_mask.py`
- `load_config()` 新增默认值:
  - `config.model.motion_token_prediction = {'enabled': False, 'num_bins': 1024}`
  - `config.model.loss_weights.token_loss_weight = 0.0`
- `train_step()` 修改:
  - 从 batch 取 `motion_token_labels`
  - 传入 `model.training_step(motion_token_labels=...)`
- `log_metrics()` 修改:
  - 日志中新增 Token loss 显示
- `create_model_and_optimizer()` 修改:
  - 传入 `token_loss_weight=config.model.loss_weights.get('token_loss_weight', 0.0)`

## 4. 数据流总结

```
Dataset.__getitem__():
  1. 加载 action_sequence [16, 16] (eepos)
  2. 提取 left_xyz [16, 3], right_xyz [16, 3]
  3. WristMotionTokenizer.encode_token_string() → token 字符串
  4. preprocess_vlm_messages_with_motion_tokens():
     - 构建 messages (user+assistant)
     - apply_chat_template → text
     - processor → input_ids, attention_mask, pixel_values, image_grid_thw
     - 构造 labels (pre-shifted: labels[t]=input_ids[t+1], user位置=-100)
  5. 返回: {first_frame, video_frames, initial_state, action_sequence,
            language_embedding, vlm_inputs(完整序列), motion_token_labels}

collate_fn():
  - vlm_inputs 正常 batch padding
  - motion_token_labels 独立 padding (pad_value=-100)

Model.training_step():
  1. VAE encode → video latent
  2. Flow-matching noise → noisy_video, noisy_actions
  3. extract_per_layer_features(vlm_inputs) → 30 层 VLM 特征
  4. 30 层 MoT 循环 (WAN + Action + VLM joint attention)
  5. Video/Action heads → video_loss, action_loss
  6. lm_head(vlm_tokens) → token_logits
  7. cross_entropy(token_logits, motion_token_labels) → token_loss
  8. total_loss = w_v * video + w_a * action + w_t * token
```

## 5. 验证结果

### 数据管道测试 (通过)
- Dataset 初始化: 27244 episodes, motion_token_enabled=True
- Sample 返回: motion_token_labels shape [1, 317], 102 non-masked (32.2%)
- Motion token 数量: 96 = 16 waypoints × 3 axes × 2 hands ✓
- Collate: batch [2, 328] motion_token_labels, int64 ✓

### Label 正确性测试 (通过)
- labels[t] == input_ids[t+1] 对所有非 -100 位置 ✓
- User tokens 正确 mask 为 -100 ✓
- Last position label = -100 ✓

### 向后兼容性 (通过)
- 原始 robotwin_eepos_WanVlmMask.yaml 不含 motion_token_prediction
- load_config 默认 token_loss_weight=0.0, enabled=False
- token_loss_weight=0 时不计算 token loss

### 配置加载测试 (通过)
- 新 YAML 正确加载所有字段
- OmegaConf 解析正常

### 语法检查 (通过)
- 所有 6 个修改文件 ast.parse 无错误

## 6. 待办事项

- [ ] 完整训练 Smoke test: `torchrun --nproc_per_node=4 train/train_wan_vlm_mask.py --config configs/robotwin_eepos_WanVlmMask_motion_token.yaml --max_steps 5`
- [ ] 验证 token_loss 非零且下降
- [ ] 验证 video_loss 和 action_loss 不受 token_loss 影响（权重可调）
- [ ] 检查 VLM 序列长度增长对显存的影响（prompt+response 比 prompt-only 长约 100 tokens）
- [ ] 考虑 token_loss_weight 的调参（初始建议 1.0，可能需要调整）
- [ ] 扩展到其他数据集类型（vitra_human, cross_dataset_mixed 等）时的 motion token 构造
- [ ] Inference 阶段: 当前 inference_step 未修改，需要考虑是否要添加 motion token 生成

## 7. 文件路径速查

| 文件 | 路径 |
|------|------|
| Motion Tokenizer | `utils/motion_tokenizer.py` |
| VLM Utils | `utils/vlm_utils.py` |
| RobotWin Dataset | `data/robotwin2/robotwin_agilex_dataset.py` |
| Dataset Registry | `data/dataset.py` |
| Model | `models/motus_wan_vlm_direct_mask.py` |
| Training Script | `train/train_wan_vlm_mask.py` |
| 新 YAML Config | `configs/robotwin_eepos_WanVlmMask_motion_token.yaml` |
| 新 Shell Script | `scripts/train_ADS_MotusV2_robotwin_eepos_motion_token.sh` |
| 扩展词表 VLM 模型 | `/cache/wx1469573/pretrained_models/Qwen3-VL-2B-Instruct-motion-token` |
| 原始 VLM 模型 | `/cache/wx1469573/pretrained_models/Qwen3-VL-2B-Instruct` |
| WAN 5B 模型 | `/cache/wx1469573/pretrained_models/Wan2.2-TI2V-5B` |
| RobotWin eepos 数据 | `/cache/wx1469573/data/RoboTwin_emb_ee` |

# MotusV2 Motion Token 训推一致性分析

> 日期：2026-06-12 ~ 2026-06-15
> 分析范围：训练代码（MotusV2）+ 推理代码（RoboTwin_EE/policy/MotusWanVlmDirectMaskMotion）
> 涉及配置：`robotwin_eepos_WanVlmMask_motion_token_on.yaml` / `motion_token_off.yaml`

---

## 1. 问题背景

MotusV2 在 RoboTwin 基准上开启了 motion token 训练目标后，评测结果反而出现掉点。为定位根因，对三个初始怀疑（T5 条件偏移、checkpoint 加载、图像构造不一致）以及最终发现的关键问题（VLM 输入分布偏移）进行了系统性分析。同时梳理了 motion token ON/OFF 配置下的 VLM 路径选择逻辑。

---

## 2. 评测结果概览

### 2.1 重要说明

两次评测均为 **motion token ON** 模式（同一训练配置 `robotwin_eepos_WanVlmMask_motion_token_on.yaml`），差异仅在于训练步数不同：

| 日期 | 训练步数 | Checkpoint 路径 | 平均成功率 |
|------|---------|----------------|-----------|
| 6/9 | 34,000 steps | `/cache/wx1469573/ckpts/motion_best_action_l2_34000` | 71.6% |
| 6/11 | 40,000 steps | `/cache/wx1469573/pretrained_models/ckpt` | 68.3% |

**这不是 motion token on/off 的对比实验，而是同一配置下不同训练步数的对比。** 40k 步的 checkpoint 反而比 34k 步低了 3.3%，说明模型在训练后期出现了性能退化。

### 2.2 任务级波动

50 个任务中有 12 个任务波动超过 ±30%：

| 任务 | 34k | 40k | 差异 | 方向 |
|------|-----|------|------|------|
| handover_block | 95% | 8% | -87% | 严重退步 |
| hanging_mug | 61% | 12% | -49% | 严重退步 |
| pick_diverse_bottles | 82% | 18% | -64% | 严重退步 |
| pick_dual_bottles | 80% | 19% | -61% | 严重退步 |
| move_pillbottle_pad | 51% | 30% | -68% | 严重退步 |
| place_cans_plasticbox | 96% | 40% | -56% | 严重退步 |
| stack_blocks_three | 70% | 24% | -46% | 严重退步 |
| shake_bottle_horizontally | 29% | 99% | +70% | 大幅进步 |
| grab_roller | 9% | 99% | +90% | 大幅进步 |
| lift_pot | 30% | 81% | +51% | 大幅进步 |
| open_laptop | 44% | 92% | +48% | 大幅进步 |
| place_burger_fries | 46% | 94% | +48% | 大幅进步 |

极端方差的模式（部分任务骤降，部分任务暴涨）是 VLM 特征分布偏移的典型表现——随着训练继续，模型越来越依赖 VLM 中的 GT 运动令牌信息，导致对"VLM 运动信息敏感"的任务在训练集上表现更好，但在推理时因信息缺失而退步；同时一些不敏感的任务反而因更长训练而获益。

### 2.3 Oracle Best 分析

取两个 checkpoint 中每个任务的最高分，Oracle best 平均成功率可达 **83.9%**，比单独 34k (71.6%) 高 12.3%，比 40k (68.3%) 高 15.6%。

| 任务 | 34k | 40k | Best | 来源 |
|------|-----|------|------|------|
| adjust_bottle | 100% | 99% | 100% | 34k |
| beat_block_hammer | 87% | 86% | 87% | 34k |
| blocks_ranking_rgb | 79% | 87% | 87% | 40k |
| blocks_ranking_size | 48% | 50% | 50% | 40k |
| click_alarmclock | 100% | 99% | 100% | 34k |
| click_bell | 100% | 100% | 100% | - |
| grab_roller | 98% | 74% | 98% | 34k |
| handover_block | 9% | 99% | 99% | 40k |
| handover_mic | 95% | 8% | 95% | 34k |
| hanging_mug | 17% | 82% | 82% | 40k |
| lift_pot | 61% | 12% | 61% | 34k |
| move_can_pot | 30% | 81% | 81% | 40k |
| move_pillbottle_pad | 51% | 34% | 51% | 34k |
| move_playingcard_away | 98% | 30% | 98% | 34k |
| move_stapler_pad | 62% | 98% | 98% | 40k |
| open_laptop | 99% | 57% | 99% | 34k |
| open_microwave | 44% | 92% | 92% | 40k |
| pick_diverse_bottles | 68% | 50% | 68% | 34k |
| pick_dual_bottles | 82% | 18% | 82% | 34k |
| place_a2b_left | 80% | 19% | 80% | 34k |
| place_a2b_right | 82% | 78% | 82% | 34k |
| place_bread_basket | 81% | 74% | 81% | 34k |
| place_bread_skillet | 62% | 75% | 75% | 40k |
| place_burger_fries | 86% | 68% | 86% | 34k |
| place_can_basket | 46% | 94% | 94% | 40k |
| place_cans_plasticbox | 34% | 38% | 38% | 40k |
| place_container_plate | 96% | 40% | 96% | 34k |
| place_dual_shoes | 73% | 92% | 92% | 40k |
| place_empty_cup | 97% | 73% | 97% | 34k |
| place_fan | 46% | 85% | 85% | 40k |
| place_mouse_pad | 60% | 50% | 60% | 34k |
| place_object_basket | 68% | 59% | 68% | 34k |
| place_object_scale | 81% | 82% | 82% | 40k |
| place_object_stand | 86% | 79% | 86% | 34k |
| place_phone_stand | 70% | 86% | 86% | 40k |
| place_shoe | 96% | 73% | 96% | 34k |
| press_stapler | 99% | 89% | 99% | 34k |
| put_bottles_dustbin | 59% | 98% | 98% | 40k |
| put_object_cabinet | 56% | 33% | 56% | 34k |
| rotate_qrcode | 77% | 46% | 77% | 34k |
| scan_object | 53% | 77% | 77% | 40k |
| shake_bottle | 100% | 61% | 100% | 34k |
| shake_bottle_horizontally | 100% | 98% | 100% | 34k |
| stack_blocks_three | 29% | 99% | 99% | 40k |
| stack_blocks_two | 70% | 24% | 70% | 34k |
| stack_bowls_three | 66% | 74% | 74% | 40k |
| stack_bowls_two | 94% | 60% | 94% | 34k |
| stamp_seal | 69% | 80% | 80% | 40k |
| turn_switch | 64% | 75% | 75% | 40k |
| **平均** | **71.6%** | **68.3%** | **83.9%** | - |

50 个任务中 34k 赢了 31 个，40k 赢了 19 个。两者呈现明显的**互补性**——如果能解决 VLM 偏移问题，一个充分训练的 checkpoint 有望在大多数任务上同时达到 Oracle best 的水平。

---

## 3. 三项初始怀疑的分析结论

### 3.1 T5 文本条件一致性

**结论：一致，无问题。**

| 对比项 | 训练 | 推理 |
|--------|------|------|
| T5 编码方式 | 预编码 `.pt` 文件 | `T5EncoderModel` 实时编码 |
| 文本前缀 | 包含 scene prefix | 包含 scene prefix |
| 原始指令来源 | `metas/*.txt` 中某一行 | `TASK_ENV.get_instruction()` |

**训练侧**：T5 embedding 从 `.pt` 文件直接加载（`robotwin_agilex_dataset.py:680-697`），这些 embedding 是用完整文本预编码的。每条指令均包含完整 prefix：

```
The whole scene is in a realistic, industrial art style with three views:
a fixed rear camera, a movable left arm camera, and a movable right arm camera.
The aloha robot is currently performing the following task: <raw instruction>
```

**推理侧**：`deploy_policy.py:238-242` 构造的 T5 输入使用完全相同的 prefix。

**排除风险**：此前担心的"评测侧给 T5 额外拼了三视角 scene prefix 造成 WAN cross-attention 条件偏移"问题**不存在**，因为训练数据的 T5 预编码本身已包含相同的 prefix。

### 3.2 Checkpoint 加载校验

**结论：完全正常，missing=0, unexpected=0。**

日志证据（`adjust_bottle.log:143`）：

```
models.motus_wan_vlm_direct_mask - INFO - Checkpoint loaded from
/cache/wx1469573/pretrained_models/ckpt/mp_rank_00_model_states.pt:
missing=0, unexpected=0
```

模型参数校验：WAN 5B (4,999,787,712) + Action Expert (641,533,968) + VLM + Qwen3 Module = 8.53B total，全部 trainable。

**代码风险提示**：`deploy_policy.py:110` 使用 `strict=False`，底层只打印 missing/unexpected 数量，不打印具体 key 名称。建议改为 `strict=True`，或至少将 missing/unexpected key 全量写日志并 assert 不包含关键前缀。

### 3.3 图像构造一致性

**结论：协议层面一致，不构成 Major 级风险。**

| 步骤 | 训练 | 推理 |
|------|------|------|
| 图像来源 | mp4 视频帧（decord 读取） | 仿真环境实时捕获（3 个摄像头拼接） |
| 拼接布局 | head 在上 + left/right 在下并排 | head 在上 + left/right 在下并排 |
| 原始拼接尺寸 | 360x320 | 240x320 + (120x160)x2 = 360x320 |
| resize 方式 | `resize_with_padding(384, 320)` | `resize_with_padding(384, 320)` |
| 最终尺寸 | 384x320 (12px 上下黑边) | 384x320 (12px 上下黑边) |
| 像素归一化 | `uint8 / 255.0` → [0,1] | `uint8 / 255.0` → [0,1] |
| VAE 归一化 | `x 2.0 - 1.0` → [-1,1] | `x 2.0 - 1.0` → [-1,1] |
| VLM 输入 | `tensor_to_pil` → Qwen3 processor | `_tensor_to_pil_image` → Qwen3 processor |

微小差异：推理侧 `cv2.resize(left_img, (160, 120))` 默认使用双线性插值，训练视频录制时的 resize 方式未知，但差异极小。仿真环境重启后的随机化（光照、物体位置）属正常变异，非 bug。

---

## 4. [关键发现] VLM 输入分布偏移

### 4.1 问题描述

以上三个初始怀疑均非根因，但在追踪代码时发现一个更严重的 consistency issue：

**训练时 VLM 看到了 GT 运动令牌回复，推理时没有。**

### 4.2 训练流程

`robotwin_agilex_dataset.py:898-912`：

```python
# motion_token 开启时，构造完整 user+assistant 序列
mt_inputs = preprocess_vlm_messages_with_motion_tokens(
    text_instruction=text_instruction,
    image_pil=first_frame_pil,
    processor=self.motion_token_processor,
    left_motion_token_str=left_token_str,
    right_motion_token_str=right_token_str,
)
vlm_user_inputs = preprocess_vlm_messages_motion_prompt_only(
    text_instruction=text_instruction,
    image_pil=first_frame_pil,
    processor=self.motion_token_processor,
)
vlm_inputs = mt_inputs  # ← 传给模型做 VLM 前向传播
motion_token_labels = mt_inputs.pop('labels')  # [1, seq_len]
```

`vlm_inputs` 包含完整序列：

```
<|im_start|>user
<image>Task: <instruction>
Predict the 3D wrist motion trajectories...<|im_end|>
<|im_start|>assistant
Left:<|motion_x_0000|><|motion_y_0512|>...Right:<|motion_x_0234|>...<|im_end|>
```

VLM 的 28 层前向传播**处理了 GT 运动令牌**，产生的 `vlm_per_layer` 特征编码了正确的运动轨迹信息。

### 4.3 推理流程

`deploy_policy.py:252-253`：

```python
vlm_inputs = self._preprocess_vlm_messages_motion_prompt_only(
    self.current_instruction, first_frame_pil
)
```

VLM 输入仅包含 user prompt：

```
<|im_start|>user
<image>Task: <instruction>
Predict the 3D wrist motion trajectories...<|im_end|>
<|im_start|>assistant  ← 截止，无 GT 内容
```

### 4.4 影响链路

模型 forward（`motus_wan_vlm_direct_mask.py:750`）：

```python
vlm_per_layer = self.qken3_module.extract_per_layer_features(vlm_inputs)
```

30 层 MoT 循环中，VLM 特征通过 QKV projection 注入 Video/Action 的 attention：

```python
# 每一层：VLM 特征参与 Action 的 cross-attention
vlm_base = vlm_per_layer[layer_idx]
```

- **训练时**：`vlm_per_layer` 编码了 GT 运动令牌 → Action 模块可以通过 attention "看到"正确轨迹 → action prediction 被隐式辅助
- **推理时**：`vlm_per_layer` 只编码了 prompt → Action 模块无法从 VLM 获取运动信息 → action prediction 失去了一个强条件信号

### 4.5 对比：无运动令牌基线

无运动令牌版本训练和推理都使用 `preprocess_vlm_messages`（仅 prompt），VLM 特征分布完全一致，**不存在此偏移**。

### 4.6 为什么导致极端任务级方差

- 某些任务的 VLM 特征对 GT 运动令牌更敏感（如 `handover_block` 需要精确的双臂协调，VLM 特征中的 GT 轨迹提供了关键的时序约束），去掉后性能骤降
- 另一些任务对 VLM 运动信息不敏感（如 `shake_bottle` 只需简单重复动作），反而因 motion token CE loss 的正则化效果而改善
- 随训练步数增加，模型对 VLM 中 GT 运动令牌的依赖加深，解释了 40k 步比 34k 步整体退步但部分任务进步的现象

### 4.7 修复方案

#### 方案 A：训练侧对齐推理（推荐）

训练时使用 `vlm_user_inputs`（仅 prompt 版）提取 VLM 特征，`mt_inputs` 仅用于计算 token CE loss：

```python
# 当前（有问题）
vlm_inputs = mt_inputs  # 完整序列用于 VLM 前向

# 修改后
vlm_inputs = vlm_user_inputs  # 仅 prompt 用于 VLM 前向（与推理一致）
# mt_inputs 仅用于计算 token prediction loss
motion_token_labels = mt_inputs.pop('labels')
```

需要确保 `extract_per_layer_features(vlm_user_inputs)` 和推理时的 `vlm_inputs` 分布对齐。

#### 方案 B：推理侧对齐训练

推理时给 VLM 喂空/placeholder 的 assistant 回复，使序列结构与训练一致。但这种方式有悖于推理流程的设计初衷，且 placeholder 内容无法匹配训练时的 GT token。

#### 方案 C：A/B 实验验证

在做上述修改前，先做对照实验：
1. 用当前 checkpoint + `vlm_user_inputs`（仅 prompt）做一次评测
2. 对比当前 `mt_inputs`（含 GT）评测结果

如果方案 A 有效，应该能看到退步任务（如 `handover_block`, `pick_dual_bottles`）的显著恢复。

---

## 5. VLM 路径选择：Motion Token ON vs OFF

### 5.1 问题的提出

当前 `robotwin_eepos_WanVlmMask_motion_token_off.yaml` 中 VLM 路径配置为：

```yaml
vlm:
  checkpoint_path: "/cache/wx1469573/pretrained_models/Qwen3-VL-2B-Instruct-motion-token"
```

如果用此配置训练，评估时 `paths_config.yml` 的 `vlm_path` 应选哪个版本？

### 5.2 VLM 初始化链路分析

#### 训练侧

1. 模型初始化时（`motus_wan_vlm_direct_mask.py:414-428`）：
   - `load_backbones=True` → 从 `vlm_checkpoint_path` 加载完整预训练权重
   - `load_backbones=False` → 用 `AutoConfig.from_pretrained(vlm_checkpoint_path)` 获取架构配置，再 `_from_config()` 初始化随机权重

2. 无论是哪种方式，**VLM 的架构维度（embed_tokens、lm_head 的 vocab_size）由 `vlm_checkpoint_path` 决定**

3. 训练完成后，checkpoint 中保存的 VLM 权重维度与初始化时一致

#### 推理侧

1. `deploy_policy.py:119-169`：`_create_model_config()` 中将 `vlm_path` 传入 `MotusWanVlmDirectMaskConfig.vlm_checkpoint_path`
2. `load_pretrained_backbones=False` → 用 `AutoConfig.from_pretrained(vlm_path)` 确定架构维度
3. 然后从 checkpoint 文件加载权重到该架构中

**关键点**：如果训练时 VLM 用 motion-token 版本（扩展词表 151936+3072），但推理时 `vlm_path` 指向原始版本（词表 151936），那么 `embed_tokens` 和 `lm_head` 的维度将不匹配，权重加载会静默失败（`strict=False` 不报错）。

### 5.3 当前配置的问题

| 配置 | vlm.checkpoint_path | 实际 motion_token 状态 | 扩展词表是否需要 |
|------|---------------------|----------------------|---------------|
| motion_token_on.yaml | `Qwen3-VL-2B-Instruct-motion-token` | enabled: true | 需要 (3072 tokens) |
| motion_token_off.yaml | `Qwen3-VL-2B-Instruct-motion-token` | enabled: false | **不需要** |

motion_token_off.yaml 虽然关闭了 motion token 功能，但 VLM 路径仍指向扩展词表版本，这导致：
- 训练出的 checkpoint VLM 部分带有 3072 个无用 token 的 embed/lm_head 权重
- 推理时必须匹配此维度，否则加载失败

### 5.4 推荐方案

| 方案 | 训练 vlm.checkpoint_path | 评估 vlm_path | 说明 |
|------|-------------------------|--------------|------|
| A（当前 off 配置） | `Qwen3-VL-2B-Instruct-motion-token` | `Qwen3-VL-2B-Instruct-motion-token` | 可行但不必要，多了 3072 个无用 token |
| **B（推荐）** | **`Qwen3-VL-2B-Instruct`** | **`Qwen3-VL-2B-Instruct`** | **更干净，训推完全一致，无冗余词表** |

**建议选方案 B**：把 `robotwin_eepos_WanVlmMask_motion_token_off.yaml` 的 `vlm.checkpoint_path` 改为原始 `Qwen3-VL-2B-Instruct`，评估时 `paths_config.yml` 的 `vlm_path` 也对应改为原始版本。

### 5.5 需要同步修改的位置

1. **训练配置**：`configs/robotwin_eepos_WanVlmMask_motion_token_off.yaml` 第 47 行
   ```yaml
   # 修改前
   checkpoint_path: "/cache/wx1469573/pretrained_models/Qwen3-VL-2B-Instruct-motion-token"
   # 修改后
   checkpoint_path: "/cache/wx1469573/pretrained_models/Qwen3-VL-2B-Instruct"
   ```

2. **评估配置**：`RoboTwin_EE/policy/MotusWanVlmDirectMaskMotion/paths_config.yml` 第 13 行
   ```yaml
   # 当前（已改为原始版本）
   vlm_path: "/cache/wx1469573/pretrained_models/Qwen3-VL-2B-Instruct"
   ```
   注意：当前 `paths_config.yml` 中 vlm_path 已经是原始版本。如果用方案 A 训练（motion-token VLM），则评估时需改回 `Qwen3-VL-2B-Instruct-motion-token`，否则维度不匹配。

3. **VLM processor**：`deploy_policy.py:70` 也从 `vlm_path` 加载 processor
   ```python
   self.vlm_processor = AutoProcessor.from_pretrained(self.vlm_path, trust_remote_code=True)
   ```
   - motion token ON 评估 → processor 需要识别 `<|motion_x_*|>` token → 必须用 motion-token 版本
   - motion token OFF 评估 → processor 只需标准 chat template → 原始版本即可

### 5.6 完整配置对照表

| 场景 | 训练 yaml vlm.checkpoint_path | 评估 paths_config.yml vlm_path | Dataset VLM processor |
|------|------|------|------|
| Motion Token ON | `Qwen3-VL-2B-Instruct-motion-token` | `Qwen3-VL-2B-Instruct-motion-token` | motion_token_processor (扩展词表) |
| Motion Token OFF (方案 A) | `Qwen3-VL-2B-Instruct-motion-token` | `Qwen3-VL-2B-Instruct-motion-token` | vlm_processor (扩展词表，但不用 motion tokens) |
| **Motion Token OFF (方案 B，推荐)** | **`Qwen3-VL-2B-Instruct`** | **`Qwen3-VL-2B-Instruct`** | **vlm_processor (标准词表)** |

---

## 6. 其他次要发现

### 6.1 Action chunk 执行协议

推理时每步预测整个 action chunk（16 步），但在 `eval()` 函数中逐 action 执行并实时重新预测。这意味着每步的 action chunk 只有第一个 action 被执行，然后重新观测再预测。这是常见的 open-loop execution 策略，与训练时的 chunk-level 预测目标一致。

### 6.2 VLM prompt 格式差异

motion token ON 时训练和推理的 VLM prompt 内容一致（都是 `"Task: {instruction}\nPredict the 3D wrist motion trajectories..."`），差异在于序列是否包含 GT assistant 回复。motion token OFF 时使用标准 `preprocess_vlm_messages`，prompt 内容为简单的 instruction + image。

---

## 7. 结论与建议

### 结论

1. **T5 文本条件**：训练和推理一致，scene prefix 完全匹配
2. **Checkpoint 加载**：完全正常，无遗漏权重
3. **图像构造**：协议层面一致，尺寸/归一化/布局均对齐
4. **VLM 输入分布偏移**：**这是最可能导致掉点的根因**。训练时 VLM 处理了含 GT 运动令牌的完整序列，推理时只有 prompt，导致 MoT 循环中 VLM→Action 的条件信号分布偏移
5. **实验对照说明**：当前两次评测均为 motion token ON 模式，差异来自训练步数（34k vs 40k），并非 motion token on/off 对比。尚缺 motion token OFF 的基线评测数据
6. **VLM 路径选择**：motion token OFF 训练应使用原始 `Qwen3-VL-2B-Instruct`（非扩展词表版本），推理时也对应使用原始版本，保持训推维度一致

### 优先级行动建议

| 优先级 | 行动 | 预期效果 |
|--------|------|---------|
| P0 | 训练时改用 `vlm_user_inputs` 提取 VLM 特征，`mt_inputs` 仅用于 CE loss | 消除 VLM 特征分布偏移 |
| P1 | 修改 motion_token_off.yaml 的 VLM 路径为 `Qwen3-VL-2B-Instruct`，然后运行 motion token OFF 基线评测 | 建立 motion token 效果的公平比较基准 |
| P2 | 将 `strict=False` 改为 `strict=True` 或添加 key 白名单检查 | 防止未来 checkpoint 加载静默失败 |
| P3 | 保存 eval 输入帧与训练视频首帧做像素级对比 | 彻底排除图像差异 |

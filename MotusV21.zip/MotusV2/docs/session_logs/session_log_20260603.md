# MotusV2 会话记录 - 2026-06-03/05

## 一、关键决策

### 06-03 决策
1. **加载 EgoDex 全部分片**：将 `splits: ["part1", "part2"]` 删除，回退到代码默认值加载全部 7 个分片（part1-part5, extra, test）
2. **auto_weight 按数据集 episode 数量自动计算权重**：不再手动指定 `weight: 1.0`，改为 `auto_weight: true`，每个 episode 被采到的概率相等
3. **T5 路径修正**：将 `wan_path`、`t5_cache_dir` 等相对路径改为绝对路径，与 WAN/VLM checkpoint 路径保持一致
4. **环境修复**：NCCL 和 cuDNN 的 pip 包内部 `.so` 文件版本错误，需 `--force-reinstall` 才能下载到正确版本

### 06-04 决策
5. **OBS 直读模式**：RoboTwin 训练不再预下载整个数据集到本地，改为通过 moxing API 直接从 OBS 读取数据。视频文件因 decord 不支持内存读取，采用本地磁盘缓存策略（首次下载，后续读缓存）。`.pt`/`.txt`/`.json` 通过 `mox.file.read()` + `BytesIO` 在内存中解析。
6. **OBS 实现方式**：在现有 `RobotWinTaskDataset` 中加条件分支（而非抽象接口），通过 `storage_mode` 参数切换 local/obs 模式。
7. **VLM frozen 状态**：cross_mixed_wrist16 配置的 VLM 应为 `frozen: true`。VLM 可训练（2.13B 参数）会导致 DeepSpeed ZeRO-1 额外占用 ~16 GiB/卡显存，4 卡 140GiB 配置下 OOM。
8. **训练日志保存**：加 `tee` 重定向终端输出到文件，解决 FileHandler 被 DeepSpeed 覆盖导致 train.log 断写的问题。
9. **Dataloader 创建计时**：在 `create_dataloaders()` 调用前后加计时，便于对比 OBS 和 local 模式的加载耗时。

## 二、修改文件清单

| # | 文件路径 | 修改类型 | 日期 |
|---|---------|---------|------|
| 1 | `models/wan_model_mask.py` | Bug 修复 | 06-03 |
| 2 | `data/human/vitra_core.py` | Bug 修复 | 06-03 |
| 3 | `data/dataset.py` | 功能新增 + Bug 修复 | 06-03/04 |
| 4 | `configs/motusv1_adapted/cross_dataset_mixed_wrist16.yaml` | 配置修改 | 06-03/04 |
| 5 | `configs/motusv1_adapted/cross_dataset_mixed_relative_wrist16.yaml` | 配置修改 | 06-03 |
| 6 | `scripts/train_ADS_MotusV2_cross_wrist16.sh` | Bug 修复 | 06-03 |
| 7 | `CLAUDE.md` | 新增文件 | 06-03 |
| 8 | `data/robotwin2/robotwin_agilex_dataset.py` | OBS 直读功能 | 06-04 |
| 9 | `configs/robotwin_wan_vlm_mask_stage2_15w.yaml` | 配置修复 + OBS | 06-04 |
| 10 | `scripts/train_ADS_MotusV2_robotwin.sh` | GPU 配置修复 + tee 日志 | 06-04 |
| 11 | `train/train_wan_vlm_mask.py` | 日志修复 + 计时 | 06-04 |

## 三、代码修改详情

### 1. `models/wan_model_mask.py` (06-03)
- **问题**：直接 `from wan.modules.model_mask import ...` 但未将 `bak/` 加入 `sys.path`，导致 `ModuleNotFoundError: No module named 'wan'`
- **修改**：在 import 前添加 `BAK_ROOT` 路径设置
```python
BAK_ROOT = str((Path(__file__).parent.parent / "bak").resolve())
if BAK_ROOT not in sys.path:
    sys.path.insert(0, BAK_ROOT)
```

### 2. `data/human/vitra_core.py` (06-03)
- **问题**：`from skimage.color import gray2rgb` 导致 `numpy.dtype size changed` ABI 不兼容错误
- **修改**：
  - 删除 `from skimage.color import gray2rgb`
  - 替换 `np.array([gray2rgb(frame) for frame in video])` 为 `np.stack([np.broadcast_to(frame[..., None], (*frame.shape, 3)) for frame in video])`

### 3. `data/dataset.py` (06-03/04)
- **问题**：新增的 `auto_weight` 日志使用了 `logger` 但文件未导入 logging
- **修改**：
  - 添加 `import logging` 和 `logger = logging.getLogger(__name__)`
- **新增 auto_weight 功能**：在 `_cross_dataset_mixed()` 中，当 `config.dataset.auto_weight` 为 `True` 时，用各子数据集的 episode 数量自动设置权重
- **06-04 新增**：`_robotwin()` 的 `_copy_dataset_keys` 增加 `"storage_mode"` 和 `"obs_base_path"`，传递 OBS 配置到 `RobotWinTaskDataset`

### 4. `configs/motusv1_adapted/cross_dataset_mixed_wrist16.yaml` (06-03/04)
- 06-03 修改：删除 EgoDex splits、删除 weight、新增 auto_weight、路径改为绝对路径
- 06-04 修改：用户取消注释 EgoDex 条目、新增 `confidence_threshold: 0.3`、`vlm.frozen` 改为 `false`（后发现 OOM，应改回 `true`）、`batch_size` 改为 `10`

### 5. `configs/motusv1_adapted/cross_dataset_mixed_relative_wrist16.yaml` (06-03)
- 删除 `splits: ["part1", "part2"]`、删除 weight、新增 auto_weight、`vlm.checkpoint_path` 改为绝对路径

### 6. `scripts/train_ADS_MotusV2_cross_wrist16.sh` (06-03)
- **问题**：第 18 行设 `NPROC_PER_NODE=4`，但第 25 行 `NPROC_PER_NODE=${NPROC_PER_NODE:-8}` 被环境变量覆盖回 8
- **修改**：去掉冗余赋值，默认值从 `8` 改为 `4`

### 7. `CLAUDE.md` (06-03)
- 新建项目文档，包含项目概述、训练命令、架构说明、关键约定

### 8. `data/robotwin2/robotwin_agilex_dataset.py` (06-04) — **OBS 直读功能**
- **新增 import**：`import io`
- **新增构造参数**：`storage_mode: str = "local"`, `obs_base_path: Optional[str] = None`
- **新增 OBS 初始化**：当 `storage_mode="obs"` 时导入 moxing，创建视频缓存目录 `/tmp/obs_video_cache_*`
- **新增 7 个存储辅助方法**：
  - `_local_to_obs(local_path)` — 本地路径转 OBS URL
  - `_obs_to_local_cache(obs_path)` — OBS URL 转本地缓存路径
  - `_path_exists(path)` — `mox.file.exists()` 或 `Path.exists()`
  - `_path_is_dir(path)` — `mox.file.is_directory()` 或 `Path.is_dir()`
  - `_list_dir(path)` — `mox.file.list_directory(return_abs_path=True)` 或 `Path.iterdir()`
  - `_read_bytes(path)` — `mox.file.read(binary=True)` 或 `open('rb')`
  - `_read_text(path)` — `mox.file.read(binary=False)` 或 `open('r')`
  - `_get_video_local_path(video_path)` — 视频文件从 OBS 下载到本地缓存后返回本地路径
- **修改 `_scan_task_folder`**：OBS 模式用 `mox.file.list_directory` + `mox.file.exists` 替代 `Path.glob` + `Path.exists`
- **修改 `_load_episodes`**：OBS 模式用 `mox.file` API 替代 `Path` API
- **修改 `_load_robot_data`**：OBS 模式用 `mox.file.read(binary=True)` + `BytesIO` + `torch.load`
- **修改 `_load_language_embedding`**：同上
- **修改 `_load_text_instruction`**：OBS 模式用 `mox.file.read(binary=False)` 替代 `open()`
- **修改 `__getitem__`**：视频路径通过 `_get_video_local_path()` 获取本地缓存路径
- **修改 split 推断**：用 `'/clean/' in path_str` 替代 `Path.parts` 检查，兼容 OBS URL
- **修改 `MinMaxNormalizer.from_stats_file`**：支持从 OBS URL 读取 JSON（`mox.file.read` + `json.loads`）

### 9. `configs/robotwin_wan_vlm_mask_stage2_15w.yaml` (06-04)
- **修复 YAML 嵌套错误**：原文件有 `model.model.wan` 双层嵌套，改为 `model.wan`（`wan` 和 `vlm` 与 `qwen3_expert` 同级）
- **新增 OBS 配置**：
```yaml
storage_mode: "obs"
obs_base_path: "obs://yw-2030-gy/data/opensource/RoboTwin2_0/RoboTwin_emb"
```

### 10. `scripts/train_ADS_MotusV2_robotwin.sh` (06-04)
- **修复 NPROC_PER_NODE**：去掉 `CUDA_VISIBLE_DEVICES=4,5,6,7` 和冗余的 `NPROC_PER_NODE` 赋值（原来 8 进程 4 卡导致 `invalid device ordinal`）
- **新增 tee 日志**：`torchrun ... 2>&1 | tee "$LOG_FILE"`，保存完整终端输出到 `outputs/motus-*/console_*.log`

### 11. `train/train_wan_vlm_mask.py` (06-04)
- **新增 Dataloader 创建计时**：
```python
_dl_start = _time.time()
train_dataloader, val_dataloader = create_dataloaders(config, rank, world_size)
_dl_elapsed = _time.time() - _dl_start
logger.info(f"Dataloader creation took {_dl_elapsed:.1f}s (storage_mode=...)")
```
- **修复 FileHandler 断写**：在 `accelerator.prepare()` 之后检查 FileHandler 是否被 DeepSpeed 清除，如果清除则重新添加
```python
if rank == 0:
    root_logger = logging.getLogger()
    has_file_handler = any(isinstance(h, logging.FileHandler) for h in root_logger.handlers)
    if not has_file_handler and os.path.isdir(train_logs_dir):
        # 重新添加 _FlushFileHandler
```

## 四、环境修复记录

### NCCL 版本问题 (06-03)
- **现象**：`NCCL version 2.29.7` + `CUDA driver version is insufficient for CUDA runtime version`
- **根因**：pip 包 `nvidia-nccl-cu12==2.21.5` 内部 `.so` 文件实际是 NCCL 2.29.7+cuda13.2，与 CUDA 12.8 驱动不兼容
- **修复**：`pip install nvidia-nccl-cu12==2.21.5 --force-reinstall --no-deps`，重装后下载到正确的 NCCL 2.21.5+cuda12.4

### cuDNN 版本问题 (06-03)
- **现象**：`cuDNN error: CUDNN_STATUS_NOT_INITIALIZED`
- **根因**：与 NCCL 同类问题，pip 包 `nvidia-cudnn-cu12==9.1.0.70` 内部 `.so` 文件版本错误
- **修复**：`pip install nvidia-cudnn-cu12==9.1.0.70 --force-reinstall --no-deps`，重装后下载到正确版本

### skimage/numpy ABI 问题 (06-03)
- **现象**：`numpy.dtype size changed, may indicate binary incompatibility`
- **根因**：skimage 编译时的 numpy 版本与当前 numpy 2.2.6 不兼容
- **修复**：代码中去掉 skimage 依赖，用 numpy 等价实现替代 `gray2rgb`

## 五、问题排查记录 (06-04)

### YAML 嵌套错误 → `Missing key vlm`
- **现象**：`omegaconf.errors.ConfigAttributeError: Missing key vlm, full_key: model.vlm`
- **根因**：`robotwin_wan_vlm_mask_stage2_15w.yaml` 中 `wan` 和 `vlm` 被错误放在 `model.model` 下（多余嵌套）
- **修复**：将 `wan`/`vlm` 提升到 `model` 顶层，与 `qwen3_expert` 同级

### NPROC_PER_NODE 与 CUDA_VISIBLE_DEVICES 不匹配 → `invalid device ordinal`
- **现象**：`CUDA error: invalid device ordinal`，rank 4-7 崩溃
- **根因**：`CUDA_VISIBLE_DEVICES=4,5,6,7` 只暴露 4 张 GPU，但 `NPROC_PER_NODE=8` 启动了 8 个进程
- **根因细节**：`${NPROC_PER_NODE:-4}` 不会覆盖已有值 8（bash `:-` 只在变量未设置时生效）
- **修复**：去掉 `CUDA_VISIBLE_DEVICES` 限制

### VLM frozen=false 导致 OOM
- **现象**：Step 1 之后 OOM，`Tried to allocate 158.00 MiB. GPU 0 ... 124.44 MiB is free`
- **根因**：`vlm.frozen: false`（VLM 可训练）vs 昨晚成功的 `frozen: true`（VLM 冻结）。2.13B 参数的梯度+Adam 优化器状态额外占 ~16 GiB/卡
- **修复**：改回 `frozen: true`

### train.log 只记录到 `Creating dataloaders...` 就断了
- **现象**：train.log 只有 35 行，后续训练日志只出现在终端
- **根因**：`accelerator.prepare()` / DeepSpeed 初始化会清除 Python root logger 的 FileHandler
- **修复**：在 `accelerator.prepare()` 之后检查并重新添加 FileHandler；同时在启动脚本加 `tee` 保存终端输出

## 六、训练运行记录

### RoboTwin 训练 (06-04)
- **配置**：`robotwin_wan_vlm_mask_stage2_15w.yaml`，OBS 直读模式
- **OBS 扫描结果**：成功扫描 clean+randomized 共 35 个 task，约 27244 episodes
- **Dataloader 创建耗时**：未完整记录（FileHandler 断写）
- **TensorBoard 数据**：6000 步训练完整保存，total_loss 从 2.7790 降到 0.1133
- **状态**：训练正常运行中

### Cross-mixed-wrist16 训练 (06-04)
- **昨晚成功**：4 卡，VLM frozen=true，batch_size=16
- **今天 OOM**：4 卡，VLM frozen=false，batch_size=10，Step 1 后 OOM
- **配置差异**：用户手动将 `vlm.frozen` 从 `true` 改为 `false`，并取消注释 EgoDex

## 七、待办事项

- [ ] VITRA 数据集反复出现 `Wrist mode enabled but statistics not found at None. Normalization disabled for wrist.` 警告，如需 wrist normalization 需提供 `wrist_statistics_path`
- [ ] `cross_dataset_mixed_relative_wrist16.yaml` 的 `wan_path` 仍为相对路径 `"./pretrained_models"`，可能需要同步更新为绝对路径
- [ ] OBS 直读模式的视频缓存没有清理机制，长时间训练可能占用大量 `/tmp` 空间
- [ ] RoboTwin OBS 模式的 Dataloader 创建耗时需关注（目录扫描走网络）
- [ ] RunDi 脚本（集群启动脚本）中仍有 `conda activate qwen3` 和错误的 warning 消息待修复
- [ ] `train_wan_vlm_mask.py` 第 410 行 `qwen3_python = "/root/miniconda3/envs/qwen3/bin/python"` 硬编码路径，OBS 上传子进程可能找不到该 python
- [ ] `cross_dataset_mixed_wrist16.yaml` 的 `vlm.frozen` 当前为 `false`，需要确认是否要改回 `true` 以避免 OOM

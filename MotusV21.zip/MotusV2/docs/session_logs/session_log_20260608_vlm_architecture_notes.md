# MotusV2 VLM 模块架构理解笔记

> 基于对代码的深入阅读和讨论，整理于 2026-06-08

---

## 1. 核心问题：`extract_per_layer_features(vlm_inputs)` 在计算什么？

### 一句话概括

对 Qwen3-VL-2B 做一次完整前向传播，提取全部 28 层隐藏状态，映射到 30 层（WAN 层数），返回长度为 30 的 tensor 列表，每个形状 `[B, seq_len, 2048]`。

### 三步计算流程

**Step 1: `_process_vlm_inputs_to_tokens`** — 将 processor 输出转为模型可用嵌入

```
input_ids    → 查表得 text embedding         → inputs_embeds [B, seq_len, 2048]
pixel_values → vision encoder (no_grad)       → image_embeds + deepstack_image_embeds
inputs_embeds → masked_scatter 替换图像占位符  → 最终 inputs_embeds
                                                + visual_pos_masks [B, seq_len]
                                                + position_ids [B, seq_len]
```

- Vision encoder 在 `torch.no_grad()` 下运行，只训练 language model 部分

**Step 2: VLM language model 前向** — 关键参数 `output_hidden_states=True`

```python
vlm_output = self.vlm_model.model.language_model(
    inputs_embeds, attention_mask, position_ids,
    visual_pos_masks, deepstack_visual_embeds,
    output_hidden_states=True,   # 核心：输出所有层隐藏状态
)
```

- `hidden_states` 元组长度 29 = 28 层 + 1 个 embedding 层
- `hidden_states[0]` = embedding 层（跳过）
- `hidden_states[1]` ~ `hidden_states[28]` = VLM Layer 0 ~ 27 输出

**Step 3: 层映射 28 → 30**

```python
result = list(hidden_states[1:])     # 28 个 tensor: Layer 0..27
result.append(result[-2].clone())    # VLM Layer 26 → WAN Layer 28
result.append(result[-1].clone())    # VLM Layer 27 → WAN Layer 29
```

- WAN 30 层，VLM 28 层，最后两层复用 VLM 第 26、27 层

### 返回值

`vlm_per_layer`：长度 30 的 `List[Tensor]`，每个 `[B, seq_len, 2048]`

作用：作为每层 MoT 联合注意力中 VLM 分支的初始 token（锚点），经 `Qwen3VLWanBlock` 的 QKV 投影映射到 WAN 统一 head space（3072D = 24 heads × 128 dim），参与三模态联合注意力。

---

## 2. `vlm_inputs` 的完整结构

### 基础字段（两种模式共有）

| Key | 形状 | 说明 |
|-----|------|------|
| `input_ids` | `[B, seq_len]` | 文本 token id（含图像占位符 `<|image_pad|>`、special tokens） |
| `pixel_values` | `[B, num_patches, C, H, W]` | 图像像素值（processor 从第一帧 PIL 图像生成） |
| `image_grid_thw` | `[B, 3]` | 每张图的 temporal/height/width grid 信息，Qwen3-VL 用来算 RoPE |
| `attention_mask` | `[B, seq_len]` | 1=有效 token，0=padding |

### Motion Token 模式额外字段

| Key | 形状 | 说明 |
|-----|------|------|
| `assistant_token_mask` | `[B, seq_len]` | True=GT assistant 回复位置，用于 MoT 阻止 Action 看到 GT |
| `assistant_loss_mask` | `[B, seq_len]` | True=参与 token CE loss 的位置 |

注意：`labels` 不在 `vlm_inputs` 中，在 dataset 层被 `pop` 出来，单独作为 `motion_token_labels` 传递。

### 两种模式的差异

| | 标准模式 | Motion Token 模式 |
|---|---|---|
| 构建函数 | `preprocess_vlm_messages()` | `preprocess_vlm_messages_with_motion_tokens()` |
| VLM 序列内容 | user prompt + 图像 | user prompt + 图像 + GT assistant motion token 回复 |
| assistant 相关 mask | 无 | `assistant_token_mask` + `assistant_loss_mask` |
| chat template | `add_generation_prompt=True` | `add_generation_prompt=False`（回复已包含） |

---

## 3. GT 信息泄漏问题：三层防护

### 核心矛盾

Motion token 模式下，GT assistant 回复在 `vlm_inputs` 中，Qwen3-VL 前向确实看到了完整序列。会不会通过 MoT 泄漏给 Video/Action 分支？

### 防线 A：Action 被 blocked 看 assistant GT tokens

```python
# motus_wan_vlm_direct_mask.py L266-269
action_to_vlm_allowed = (vlm_valid & ~vlm_assistant).unsqueeze(1)
attn_mask[:, L_v:L_v + L_a, L_v + L_a:] &= action_to_vlm_allowed
```

- `vlm_assistant` 来自 `vlm_inputs["assistant_token_mask"]`
- Action 只能看到 VLM 中的 **user/image prompt 部分**，看不到 GT motion token

### 防线 B：VLM 分支使用 causal mask

```python
# motus_wan_vlm_direct_mask.py L271-274
vlm_causal = torch.tril(torch.ones((L_vlm, L_vlm), ...))
attn_mask[:, L_v + L_a:, L_v + L_a:] &= vlm_causal.unsqueeze(0)
```

- VLM 在 MoT 中做下三角因果注意力
- 保证 token CE loss 的 autoregressive 性质不被破坏

### 防线 C：Video 完全隔离

```python
attn_mask[:, :L_v, L_v:] = False   # Video 不看 Action 和 VLM
```

### 完整 Attention Mask 矩阵（Motion Token 模式）

```
Query \ Key          Video   Action   VLM(prompt)   VLM(assistant)
Video                 ✅      ❌        ❌              ❌
Action                ✅      ✅        ✅              ❌  ← 防线A
VLM(prompt)           ❌      ❌        因果✅          因果✅
VLM(assistant)        ❌      ❌        因果✅          因果✅  ← 防线B
```

---

## 4. `attention_mask` 与 `assistant_token_mask` 的构造与含义

### `attention_mask` — Qwen3-VL processor 自动生成

标准 HuggingFace 行为，1 表示有效 token，0 表示 padding。

### `assistant_token_mask` — 手动构建（`vlm_utils.py:149-176`）

构造逻辑：
1. 初始化全零 bool tensor
2. 在 `input_ids` 中搜索 `<|im_start|>assistant\n` 的 token 子序列，找到 `assistant_pos`
3. 从 `assistant_pos` 到 `valid_len`（padding 之前）之间标记为 True

### 具体示例

```
VLM positions:       [system] [user+image] [asst_marker] [GT_motion_tokens] [pad]
attention_mask:        1         1            1               1               0
assistant_mask:        0         0            0               1               0

vlm_valid:            ✅        ✅           ✅              ✅               ❌
vlm_valid & ~asst:    ✅        ✅           ✅              ❌               ❌  ← Action可看
vlm_valid &  asst:    ❌        ❌           ❌              ✅               ❌  ← Action禁止看
```

### 在 MoT 中的使用（`process_joint_attention`）

| 组合表达式 | 选出区域 | 用途 |
|-----------|---------|------|
| `vlm_valid` | prompt + 图像 + assistant（所有有效 token） | 任何模态都不看 padding key |
| `vlm_valid & ~vlm_assistant` | prompt + 图像（仅 user 部分） | Action 可以看的 VLM key 范围 |
| `vlm_valid & vlm_assistant` | 仅 GT assistant motion token | Action 被禁止看的 VLM key |

### 推理时的 fallback

推理时用 `vlm_user_inputs`（无 assistant 回复），字典中无 `assistant_token_mask`：

```python
if vlm_assistant_mask is not None:
    vlm_assistant = vlm_assistant_mask[:, :L_vlm]
else:
    vlm_assistant = torch.zeros(...)  # 全 False → 全部 VLM token 对 Action 可见
```

---

## 5. Train-Test 不一致性分析

### 不一致点

| | 训练 | 推理 |
|---|---|---|
| vlm_inputs 来源 | `preprocess_vlm_messages_with_motion_tokens()` | `preprocess_vlm_messages_motion_prompt_only()` |
| VLM 输入序列 | user prompt + 图像 + GT assistant motion tokens | user prompt + 图像（只有 prompt） |
| `vlm_per_layer` 语义 | 包含对 GT 回复的理解 | 只包含对 prompt 的理解 |
| `assistant_token_mask` | 有 | 无 |

### 为什么不构成严重问题

1. `vlm_per_layer` 在 MoT 中只是**锚点**，不是直接喂给 Action/Video 的信息
2. Action/Video 从未通过 MoT 看到过 GT assistant token 的 key/value（mask 阻止了）
3. VLM 的 assistant 部分主要通过 **token CE loss** 训练，而非通过 MoT 为 Action/Video 提供信息
4. VLM 为 MoT 提供的锚点中，user/image prompt 部分在训练和推理中是一致的

### 当前推理代码的行为

`inference_step` 中：
- 只跑一次 `extract_per_layer_features`（L932/L955）
- 没有 autoregressive 生成 motion token 的逻辑
- token prediction head 在推理时实际未使用

### 设计意图

Motion token prediction 目前主要是**训练时的辅助信号**，增强 VLM 对动作语义的理解，而非推理时的生成目标。如果要完全消除 train-test 不一致，需要推理时做 autoregressive 生成，但计算成本不可接受（每步去噪 × 30 层 × 多个 token）。

---

## 6. 关键代码位置索引

| 内容 | 文件 | 行号 |
|------|------|------|
| `extract_per_layer_features` | `models/qwen3_module_wan.py` | 106-185 |
| `_process_vlm_inputs_to_tokens` | `models/qwen3_module_wan.py` | 187-288 |
| `process_joint_attention` (MoT mask) | `models/motus_wan_vlm_direct_mask.py` | 182-301 |
| `training_step` (VLM 提取 + MoT 循环) | `models/motus_wan_vlm_direct_mask.py` | 662-860 |
| `inference_step` | `models/motus_wan_vlm_direct_mask.py` | 891-1023 |
| `preprocess_vlm_messages_with_motion_tokens` | `utils/vlm_utils.py` | 55-182 |
| `preprocess_vlm_messages_motion_prompt_only` | `utils/vlm_utils.py` | 185-226 |
| RoboTwin dataset vlm_inputs 构建 | `data/robotwin2/robotwin_agilex_dataset.py` | 870-932 |
| `_process_vlm_inputs_batch` (collate) | `data/dataset.py` | 354-417 |
| 验证时 vlm_inputs 选择 | `train/sample.py` | 114 |

---

## 7. 待深入的问题

- [ ] VLM tokens 在 MoT 逐层更新时的 `(vlm_base + vlm_tokens) / 2` 混合策略是否最优？有无实验对比？
- [ ] 推理时如果要做 autoregressive motion token 生成，需要怎样的工程改造？性能瓶颈在哪？
- [ ] `vlm_per_layer` 的 28→30 层映射（复用 Layer 26/27）对性能的影响？
- [ ] token CE loss weight 0.2 的选择依据？是否做过消融？

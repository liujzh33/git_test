# Stage2 FTRTqpos 训练步数分析报告

> 日期：2026-06-15
> 训练配置：`configs/robotwin_wan_vlm_mask_stage2_15w.yaml`
> 评测数据目录：`/home/ma-user/work/wx1469573/AnalyseTrainSteps/WanVlmMask_RobotAndHuman_FTRTqpos`
> 模型策略目录：`RoboTwin_EE/policy/MotusWanVlmDirectMask`（注意：非 Motion 版本）

---

## 1. 训练配置摘要

| 项目 | 值 |
|------|-----|
| 配置文件 | `robotwin_wan_vlm_mask_stage2_15w.yaml` |
| action_dim | 14（qpos 关节角度模式） |
| training_mode | finetune（state+action + register tokens） |
| Motion Token | **未启用**（无 motion_token_prediction 配置） |
| VLM | `Qwen3-VL-2B-Instruct`（原始版本，非 motion-token 扩展版） |
| 数据集 | RoboTwin（type: robotwin, data_mode: both） |
| max_steps | 120,000 |
| save_interval | 20,000 |
| learning_rate | 5e-5（WAN/VLM/其他统一） |
| batch_size | 8 × 8 GPU = 64 |

---

## 2. 评测结果概览

5个训练步数的评测结果（每个任务 100 episodes）：

| 训练步数 | 平均成功率 | 距Oracle |
|---------|-----------|---------|
| 20,000 (2W) | 83.6% | -7.4% |
| **37,000 (3.7W)** | **87.8%** | **-3.2%** |
| 40,000 (4W) | 87.0% | -4.0% |
| 60,000 (6W) | 78.6% | -12.4% |
| 92,000 (9.2W) | 79.0% | -12.0% |

**趋势**：3.7W 达峰后持续下降，4W→6W 是最大退化窗口（-8.4%）。

---

## 3. Q1: Oracle Best 分析

每个任务取5次评估中的最高值：

**Oracle Best 平均成功率 = 91.0%**

比最优单点 3.7W (87.8%) 高 3.2%，说明不同任务的最佳 checkpoint 时间点差异显著。

各步数赢得任务数（取最高值时）：

| 步数 | 赢得任务数 |
|------|-----------|
| 2W | 8 |
| **3.7W** | **27** |
| 4W | 9 |
| 6W | 4 |
| 9.2W | 2 |

逐任务 Oracle Best 详情：

| 任务 | 2W | 3.7W | 4W | 6W | 9.2W | Best | 来源 |
|------|-----|------|-----|-----|------|------|------|
| adjust_bottle | 98% | 100% | 99% | 100% | 100% | 100% | 3.7W |
| beat_block_hammer | 85% | 93% | 77% | 94% | 84% | 94% | 6W |
| blocks_ranking_rgb | 92% | 95% | 94% | 93% | 94% | 95% | 3.7W |
| blocks_ranking_size | 62% | 73% | 67% | 60% | 67% | 73% | 3.7W |
| click_alarmclock | 98% | 100% | 99% | 99% | 99% | 100% | 3.7W |
| click_bell | 100% | 100% | 100% | 100% | 100% | 100% | 2W |
| dump_bin_bigbin | 88% | 91% | 93% | 91% | 86% | 93% | 4W |
| grab_roller | 100% | 100% | 100% | 100% | 100% | 100% | 2W |
| handover_block | 65% | 75% | 75% | 1% | 16% | 75% | 3.7W |
| handover_mic | 99% | 100% | 97% | 96% | 95% | 100% | 3.7W |
| hanging_mug | 37% | 48% | 11% | 32% | 16% | 48% | 3.7W |
| lift_pot | 82% | 100% | 99% | 70% | 61% | 100% | 3.7W |
| move_can_pot | 66% | 78% | 79% | 50% | 64% | 79% | 4W |
| move_pillbottle_pad | 95% | 98% | 91% | 79% | 74% | 98% | 3.7W |
| move_playingcard_away | 94% | 96% | 97% | 86% | 96% | 97% | 4W |
| move_stapler_pad | 44% | 61% | 39% | 40% | 51% | 61% | 3.7W |
| open_laptop | 96% | 98% | 92% | 98% | 99% | 99% | 9.2W |
| open_microwave | 100% | 37% | 100% | 100% | 98% | 100% | 2W |
| pick_diverse_bottles | 69% | 86% | 84% | 38% | 30% | 86% | 3.7W |
| pick_dual_bottles | 71% | 100% | 84% | 35% | 33% | 100% | 3.7W |
| place_a2b_left | 91% | 93% | 91% | 77% | 89% | 93% | 3.7W |
| place_a2b_right | 93% | 93% | 84% | 83% | 88% | 93% | 2W |
| place_bread_basket | 94% | 87% | 93% | 91% | 83% | 94% | 2W |
| place_bread_skillet | 89% | 91% | 95% | 88% | 94% | 95% | 4W |
| place_burger_fries | 99% | 99% | 100% | 99% | 95% | 100% | 4W |
| place_can_basket | 71% | 74% | 70% | 52% | 61% | 74% | 3.7W |
| place_cans_plasticbox | 99% | 93% | 99% | 97% | 76% | 99% | 2W |
| place_container_plate | 97% | 100% | 98% | 97% | 99% | 100% | 3.7W |
| place_dual_shoes | 77% | 85% | 88% | 94% | 86% | 94% | 6W |
| place_empty_cup | 100% | 100% | 99% | 96% | 97% | 100% | 2W |
| place_fan | 87% | 93% | 91% | 82% | 82% | 93% | 3.7W |
| place_mouse_pad | 64% | 75% | 64% | 63% | 65% | 75% | 3.7W |
| place_object_basket | 85% | 87% | 92% | 80% | 76% | 92% | 4W |
| place_object_scale | 88% | 96% | 95% | 82% | 91% | 96% | 3.7W |
| place_object_stand | 94% | 96% | 96% | 94% | 94% | 96% | 3.7W |
| place_phone_stand | 85% | 82% | 84% | 65% | 70% | 85% | 2W |
| place_shoe | 98% | 98% | 100% | 95% | 96% | 100% | 4W |
| press_stapler | 96% | 100% | 96% | 97% | 97% | 100% | 3.7W |
| put_bottles_dustbin | 28% | 75% | 75% | 34% | 19% | 75% | 3.7W |
| put_object_cabinet | 65% | 57% | 75% | 69% | 64% | 75% | 4W |
| rotate_qrcode | 71% | 73% | 76% | 83% | 85% | 85% | 9.2W |
| scan_object | 75% | 73% | 86% | 84% | 75% | 86% | 4W |
| shake_bottle | 98% | 100% | 98% | 100% | 99% | 100% | 3.7W |
| shake_bottle_horizontally | 99% | 100% | 99% | 100% | 99% | 100% | 3.7W |
| stack_blocks_three | 82% | 96% | 91% | 72% | 88% | 96% | 3.7W |
| stack_blocks_two | 96% | 100% | 100% | 84% | 98% | 100% | 3.7W |
| stack_bowls_three | 73% | 81% | 77% | 85% | 85% | 85% | 6W |
| stack_bowls_two | 92% | 93% | 97% | 98% | 96% | 98% | 6W |
| stamp_seal | 83% | 97% | 86% | 65% | 78% | 97% | 3.7W |
| turn_switch | 69% | 76% | 76% | 61% | 60% | 76% | 3.7W |

---

## 4. Q2: 可视化图表

4 张图已保存至 `WanVlmMask_RobotAndHuman_FTRTqpos/`：

| 文件名 | 内容 |
|--------|------|
| `50tasks_success_rate_vs_steps.png` | 10×5 网格，50个任务各一条曲线，按趋势类别着色（红=严重过拟合，橙=早峰缓降，蓝=中峰，绿=晚峰，灰=稳定） |
| `overview_avg_and_categories.png` | 左：平均趋势线+Oracle基线；右：趋势类别分布柱状图 |
| `severe_overfit_tasks.png` | 8个严重过拟合任务的放大曲线 |
| `heatmap_success_rate.png` | 50×5 热力图，按平均成功率排序，标注数值 |

---

## 5. Q3: 任务过拟合趋势分类

### 5.1 严重过拟合型（8个）— 峰值≤3.7W，后续下降≥20%

| 任务 | 峰值 | 峰值步数 | 最终(9.2W) | 跌幅 |
|------|------|---------|-----------|------|
| pick_dual_bottles | 100% | 3.7W | 33% | **-67%** |
| handover_block | 75% | 3.7W | 16% | **-59%** |
| pick_diverse_bottles | 86% | 3.7W | 30% | **-56%** |
| put_bottles_dustbin | 75% | 3.7W | 19% | **-56%** |
| lift_pot | 100% | 3.7W | 61% | -39% |
| hanging_mug | 48% | 3.7W | 16% | -32% |
| move_pillbottle_pad | 98% | 3.7W | 74% | -24% |
| place_cans_plasticbox | 99% | 2W | 76% | -23% |

**动作语义共性**：双物体抓取（pick_dual/diverse）、交接/转移（handover、put_bottles、move_pillbottle）、悬挂/精确放置（hanging_mug、place_cans、lift_pot）。末端执行器轨迹微小偏差即导致失败，过拟合训练集特定配置后泛化能力下降。

### 5.2 早峰缓降型（14个）— 峰值≤3.7W，跌幅<20%

stamp_seal(-19%)、turn_switch(-16%)、place_phone_stand(-15%)、place_can_basket(-13%)、place_bread_basket(-11%)、place_fan(-11%)、move_stapler_pad(-10%)、place_mouse_pad(-10%)、stack_blocks_three(-8%)、blocks_ranking_size(-6%)、place_a2b_right(-5%)、place_object_scale(-5%)、place_a2b_left(-4%)、open_microwave(-2%)、stack_blocks_two(-2%)

### 5.3 中峰型（5个）— 峰值在4W

place_object_basket(92%→76%, -16%)、move_can_pot(79%→64%, -15%)、put_object_cabinet(75%→64%, -11%)、scan_object(86%→75%, -11%)、move_playingcard_away(97%→96%, -1%)

### 5.4 晚峰/持续上升型（4个）— 峰值≥6W

| 任务 | 趋势 |
|------|------|
| rotate_qrcode | 71%→85%，持续上升 |
| place_dual_shoes | 77%→94%→86%，6W达峰 |
| stack_bowls_three | 73%→85%，缓慢上升 |
| beat_block_hammer | 非单调（85→93→77→94→84），6W达峰 |

### 5.5 稳定型（19个）— 波动<10%

click_bell、grab_roller（始终100%），以及大部分简单 place 类任务和 shake 类任务。

---

## 6. Q4: 其他关键发现

### 6.1 3.7W 是"黄金步数"

3.7W 在 50 个任务中赢了 27 个（54%），远超其他步数。该配置无 motion token、qpos 模式、RoboTwin 单数据集，模型在 3.7W 步时恰好处在"充分学习但尚未过拟合"的甜蜜点。

### 6.2 后期训练对精细操作任务有害，对简单任务有益

9.2W vs 3.7W：**37个任务退步，仅9个改善**。退步TOP5全部是精细操作类，改善的主要是 open_microwave(+61%) 和 rotate_qrcode(+12%)。这表明后期训练中模型逐渐丧失精细操作泛化能力，但简单/重复动作的鲁棒性反而增强。

### 6.3 open_microwave 异常波动

open_microwave 在5次评估中为 [100%, 37%, 100%, 100%, 98%]，3.7W 时骤降至37%后又恢复。这不是典型的过拟合模式，更像是3.7W checkpoint 恰好学到了一个错误的策略。类似的非单调波动也出现在 beat_block_hammer 上。

### 6.4 困难任务本身也最不稳定

4个平均成功率<60%的困难任务：

| 任务 | 5次平均 | 波动范围 |
|------|---------|---------|
| hanging_mug | 28.8% | 11%-48% |
| put_bottles_dustbin | 46.2% | 19%-75% |
| handover_block | 46.4% | 1%-75% |
| move_stapler_pad | 47.0% | 39%-61% |

这些任务的学习是脆弱的——可能训练数据中 episode 质量或多样性不足。

### 6.5 过拟合任务的动作语义共性分析

8个严重过拟合任务可按动作语义分组：

- **双物体抓取类**（pick_dual_bottles、pick_diverse_bottles）：需要同时或依次抓取两个相似物体
- **交接/转移类**（handover_block、put_bottles_dustbin、move_pillbottle_pad）：物体从一个位置到另一个位置的精确转移
- **悬挂/放置类**（hanging_mug、place_cans_plasticbox、lift_pot）：需要精确的空间对齐

共同特征：末端执行器轨迹的微小偏差就会导致失败，模型在训练集上过拟合了特定的轨迹模式，推理时遇到初始状态差异就无法泛化。

### 6.6 4W→6W 是最关键的退化窗口

平均成功率从 4W 的 87.0% 骤降到 6W 的 78.6%（-8.4%），是所有相邻步数间最大的降幅。3.7W→4W 基本持平（-0.8%），说明**退化主要发生在 40k~60k 步之间**。

---

## 7. 与 Motion Token 配置的对比

本分析基于 **无 motion token 的 qpos 配置**（`MotusWanVlmDirectMask`），与之前分析的 motion token 配置（`MotusWanVlmDirectMaskMotion`）的关键差异：

| 对比项 | 本配置 (FTRTqpos) | Motion Token 配置 |
|--------|-------------------|------------------|
| action_dim | 14 (qpos) | 16 (eepos) |
| Motion Token | 未启用 | 启用 |
| VLM | Qwen3-VL-2B-Instruct | Qwen3-VL-2B-Instruct-motion-token |
| 3.7W 平均 | **87.8%** | 71.6% (34k) / 68.3% (40k) |
| Oracle Best | **91.0%** | 83.9% |
| 策略目录 | MotusWanVlmDirectMask | MotusWanVlmDirectMaskMotion |

无 motion token 配置的评测结果显著优于 motion token 配置，后者受 VLM 输入分布偏移影响（详见 `motion_token_train_eval_consistency_analysis.md`）。

---

## 8. 关键决策与待办事项

### 关键决策

1. **Early stopping 应设在 3.7W~4W 步之间**：3.7W 是最优单点，4W→6W 出现最大退化
2. **当前 qpos 配置 (87.8%) 优于 motion token eepos 配置 (71.6%)**：但需要排除 VLM 偏移的干扰后才能公平对比 motion token 的贡献
3. **过拟合主要影响精细操作任务**：简单 place/click/shake 类任务基本不受影响

### 待办事项

| 优先级 | 行动 | 说明 |
|--------|------|------|
| P0 | 修复 motion token VLM 输入分布偏移 | 训练时改用 `vlm_user_inputs` 提取 VLM 特征，详见 `motion_token_train_eval_consistency_analysis.md` 第4节 |
| P1 | 修改 motion_token_off.yaml VLM 路径 | 改为 `Qwen3-VL-2B-Instruct`（原始版本），消除冗余词表 |
| P2 | 运行 motion token OFF 基线评测 | 建立 motion token 效果的公平比较基准（eepos 模式，无 motion token） |
| P3 | 调查困难任务数据质量 | hanging_mug、put_bottles_dustbin、handover_block 的训练 episode 多样性是否不足 |
| P4 | 考虑在 4W~6W 区间加密评测 | 在 4.5W、5W、5.5W 步保存 checkpoint 并评测，精确定位退化拐点 |
| P5 | 探索 EMA / LR schedule 调整 | 当前 `ema.enabled: false`，启用 EMA 可能缓解后期退化；LR 从 5e-5 可能在 4W 后偏大 |

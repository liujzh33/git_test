# Unified EEF Camera-Delta Wrist16 Code Review Findings

> Date: 2026-06-24  
> Purpose: hand this document to Claude Code as an actionable bug-fix brief.  
> Scope: review of the current `unified_eef_camera_delta_wrist16` implementation in MotusV2.

## Overall Verdict

- Review result: **not ready for formal training**.
- Main reason: the core action delta helper mostly matches the requested formula, but the implementation still has experiment-semantics bugs in state coordinates, VITRA temporal/text alignment, and mask compatibility.
- Recommended action: fix the Critical Issues below first, then rerun helper tests plus dataloader smoke tests on the real `/cache/wx1469573/...` data paths.

## Critical Issues

### 1. Unified EEF `initial_state` is not actually camera-frame position

- File: `data/human/unified_eef_action.py`
- Location: around `compute_unified_eef_state_16d`, lines 279-333
- Current code:

```python
R_c_w = R_w_c.T
t_cam_left = R_c_w @ t_w_e_left
```

- Problem: this omits the reference camera translation. If `R_w_c` maps camera-frame vectors to world-frame vectors, then a world point should be expressed in camera coordinates as:

```text
t_c_e = R_w_c^T @ (t_w_e - t_w_c)
```

The current implementation computes only `R_w_c^T @ t_w_e`, which leaks the world origin into the conditioning state.

- Why this matters: action deltas are translation-origin invariant, but the model also receives `initial_state`. With the current code, `initial_state` is not a unified camera-frame EEF pose across datasets.
- Possible consequence: the model may learn dataset/world-coordinate biases, and cross-dataset training semantics become inconsistent.
- Minimal fix:

1. Add `t_w_c` to `compute_unified_eef_state_16d()` and `compute_unified_eef_state_from_poses()`.
2. Compute position as:

```python
t_cam_left = R_c_w @ (t_w_e_left - t_w_c)
R_cam_left = R_c_w @ R_w_e_left
```

3. Pass camera world position from each dataset adapter:

- VITRA: `t_w_c = -R_w2c[frame_id].T @ t_w2c[frame_id]`, because VITRA extrinsics are used as `p_cam = R_w2c @ p_world + t_w2c`.
- EgoDex: `t_w_c = cam_tfs[frame_idx, :3, 3]`, assuming `/transforms/camera` is camera-to-world.
- Xperience: `build_camera_world_pose_from_slam()` already returns `(R_w_c, t_w_c)`, so pass the returned `t_w_c`.

### 2. VITRA unified path discards hand-specific temporal windows from `_build_instruction()`

- File: `data/human/vitra_dataset.py`
- Location: `_get_unified_eef_sample()`, around lines 501-567
- Current behavior:
  - Calls `_build_instruction()` and obtains `idx_win_left`, `oob_left`, `idx_win_right`, `oob_right`.
  - Calls `_prepare_side_window()` with those hand-specific windows.
  - Then ignores those windows for action computation and indexes both hands with the shared `idx_win`.

Current problematic area:

```python
left_R_win = left_R_w[idx_win]
right_R_win = right_R_w[idx_win]
left_valid_win = left_kept[idx_win]
right_valid_win = right_kept[idx_win]
```

- Problem: old VITRA logic allows the main hand and secondary hand to have different text-aligned windows and OOB masks. The unified path silently collapses both hands back to the shared window, which can mismatch the instruction and hand validity.
- Why this matters: action labels can correspond to a different temporal/text segment than the sample instruction, especially for secondary-hand clips.
- Possible consequence: noisy or wrong supervision for VITRA samples in the unified dataset.
- Minimal fix:

Use hand-specific windows:

```python
left_R_win = left_R_w[idx_win_left]
left_t_win = left_t_w[idx_win_left]
right_R_win = right_R_w[idx_win_right]
right_t_win = right_t_w[idx_win_right]

left_valid_win = left_kept[idx_win_left] & ~oob_left
right_valid_win = right_kept[idx_win_right] & ~oob_right
```

Then slice with `ap = self.action_past` as before.

Also replace `oob=_` with an explicit variable from `_window_indices()`:

```python
idx_win, oob = self.core._window_indices(...)
...
oob=oob
```

### 3. New masked loss path breaks or changes old training semantics

- Files:
  - `models/motus_wan_vlm_direct_mask.py`
  - `train/train_wan_vlm_mask.py`
  - `data/dataset.py`
  - `data/egodex/egodex_dataset.py`
  - `data/wiyh/wiyh_dataset.py`
  - `data/human/vitra_robot_dataset.py`
- Location: model masked loss around `models/motus_wan_vlm_direct_mask.py:972`
- Current issue:
  - Unified mode returns a correct per-dim mask with shape `[F, 16]`.
  - Some legacy datasets return a per-hand mask with shape `[F, 2]`.
  - The model assumes `action_valid_mask` can multiply `[B, F, action_dim]`.

- Why this matters:
  - A full EgoDex legacy batch with mask `[B, F, 2]` and action `[B, F, 16]` will shape-error.
  - In mixed legacy batches where not every sample returns `action_valid_mask`, `collate_fn` drops the mask entirely, changing old invalid-hand behavior silently.

- Minimal fix options:

Option A, safest for preserving old behavior:

1. Only return `action_valid_mask` from datasets when it is per-dim and same shape as `action_sequence`.
2. For legacy per-hand masks, either rename to `hand_valid_mask` or expand it inside dataset before returning.
3. In model loss, require exact mask shape:

```python
if action_valid_mask is not None and action_valid_mask.shape != action_pred.shape:
    raise ValueError(
        f"action_valid_mask shape {action_valid_mask.shape} must match action_pred {action_pred.shape}"
    )
```

Option B, centralized expansion:

Add a helper in `data/dataset.py` or `train/train_wan_vlm_mask.py` that expands known legacy layouts:

- 14D wrist: `[left 7, right 7]`
- 16D padded wrist: `[left 0:7, pad 7, right 8:15, pad 15]`
- unified EEF: already `[0:6, 8:14]`

Do not rely on implicit broadcasting.

### 4. Masked-out/reserved action dims are still noised and encoded

- File: `models/motus_wan_vlm_direct_mask.py`
- Location: action noising around lines 849-856
- Current code:

```python
action_noise = torch.randn_like(actions, dtype=self.dtype)
noisy_actions = actions * (1 - sigma_action) + action_noise * sigma_action
```

- Problem: invalid hands and reserved dims are masked only in the loss. They still enter the action encoder as random noisy dimensions.
- Why this matters: reserved dims are intended to be interface padding only. Feeding random noise through them lets the model attend to meaningless channels.
- Minimal fix:

After creating `noisy_actions` and `action_target`, zero masked dims:

```python
if action_valid_mask is not None:
    mask = action_valid_mask.to(actions.device).to(actions.dtype)
    if mask.shape != actions.shape:
        raise ValueError(...)
    noisy_actions = noisy_actions * mask
    action_target = action_target * mask
```

This should be done before `input_encoder()`.

## Major Issues

### 5. Temporal horizon semantics changed from old relative wrist mode

- File: `data/human/unified_eef_action.py`
- Location: `compute_unified_eef_action_sequence()`, around lines 514-571
- Current unified behavior:

```text
action[i] = pose[t+i] -> pose[t+i+1]
```

- Old `relative_wrist_padded16` behavior:

```text
action[i] = pose[t] -> pose[t+i+1]
```

because old code first extracts absolute future wrist poses and then calls `relative_wrist_14_to_initial(action, state)`.

- Assessment: step-wise deltas can be a valid design, but it is not the same action-horizon semantics as old relative wrist training. Make sure inference/evaluation integrates actions step by step. Do not interpret the unified sequence as all deltas from the anchor pose.

### 6. `log_SO3()` is numerically weak near pi

- File: `data/human/unified_eef_action.py`
- Location: `log_SO3()`, around lines 77-136
- Observation: for a rotation of `pi - 1e-7`, a local check produced a reconstruction error of about `0.033` in the rotation matrix.
- Minimal fix:
  - Prefer `scipy.spatial.transform.Rotation.from_matrix(...).as_rotvec()` unless there is a strong reason to keep custom math.
  - Or use a wider near-pi threshold and a more robust branch.
  - Add a near-pi test with `pi - 1e-7`, `pi - 1e-6`, and `pi - 1e-5`.

### 7. `reference_camera_key` is exposed but not fully implemented for Xperience

- File: `data/xperience/xperience_dataset.py`
- Locations:
  - MP4 is hardcoded to `stereo_left.mp4`, around line 186
  - Calibration is hardcoded to `calibration/cam0/T_c_b`, around line 231
- Assessment: current config uses `cam0`, so the current run is internally consistent. But the parameter is misleading and unsafe if changed.
- Minimal fix:
  - Either assert `reference_camera_key == "cam0"` for now, or map `cam0 -> stereo_left.mp4` and future camera keys explicitly.

### 8. Xperience fallback flag is exposed but not implemented

- File: `data/xperience/xperience_dataset.py`
- Location: around lines 267-273
- Current behavior: `allow_base_relative_fallback=True` does not actually implement a fallback.
- Minimal fix:
  - For now, raise `NotImplementedError` when fallback is requested.
  - Do not silently continue.

## Minor Issues

### 9. New train script hardcodes GPUs

- File: `scripts/train_ADS_MotusV2_cross_unified_eef_wrist16_xperience10m.sh`
- Location: around lines 31-34
- Current code hardcodes:

```bash
export CUDA_VISIBLE_DEVICES=6,7
NPROC_PER_NODE=${NPROC_PER_NODE:-2}
```

- Suggestion: let the user set `CUDA_VISIBLE_DEVICES` externally and default only `NPROC_PER_NODE`.

### 10. Debug statistics ignore action masks

- File: `train/train_wan_vlm_mask.py`
- Location: first-batch debug around lines 1152-1199
- Problem: mean/std/min/max include invalid and reserved dims.
- Suggestion: for unified mode, compute stats only over masked effective dims.

## Formula Audit

The core action delta function currently matches the requested formula:

```text
R_e_e* = R_w_e^T @ R_w_e*
t_e_e* = R_w_e^T @ (t_w_e* - t_w_e)
R_c_e = R_w_c^T @ R_w_e
R_delta_c = R_c_e @ R_e_e* @ R_e_c
t_delta_c = R_c_e @ t_e_e*
```

Implementation location: `data/human/unified_eef_action.py`, around lines 186-198.

Important caveat: the state helper does not have the same coordinate rigor because it lacks `t_w_c`.

## Dataset-Specific Audit

### VITRA

- Action formula path uses world wrist pose and anchor camera rotation, which is conceptually correct.
- Critical problem: uses shared `idx_win` for both hands instead of `idx_win_left/right`.
- State problem: camera translation omitted.

### EgoDex

- If `/transforms/camera` is truly camera-to-world, then `R_w_c = cam_tfs[frame_idx, :3, :3]` is correct.
- State problem: camera translation omitted.
- Remaining verification needed: confirm EgoDex camera transform convention with real data or documentation.

### Xperience

- Current `cam0` path is consistent with `stereo_left.mp4` and `calibration/cam0/T_c_b`.
- Action formula can be correct if:
  - `hand_mocap/*_translation` is world-frame meters.
  - `*_global_orient` is wrist-to-world rotation matrix.
  - `slam/quat_wxyz` is body-to-world rotation.
  - `T_c_b` maps body-frame points to camera-frame points.
- State problem: camera translation omitted.
- Remaining verification needed: video-frame and mocap-frame timestamp alignment.

## Normalization / Stats Audit

- No evidence that unified action reuses old `[xyzquat, 0]` wrist statistics.
- However, unified action/state statistics are not implemented.
- If stats are added later, they must:
  - use only dims `0:6` and `8:14`;
  - exclude reserved dims `6:8` and `14:16`;
  - exclude invalid hands using `action_valid_mask`;
  - keep new stats separate from old `relative_wrist_padded16` stats.

## Tests To Add Or Update

1. State camera translation test  
   Construct `R_w_c = I`, `t_w_c = [10, 0, 0]`, `t_w_e = [11, 2, 3]`. Expected state xyz is `[1, 2, 3]`, not `[11, 2, 3]`.

2. VITRA hand-specific window test  
   Mock `_build_instruction()` so left and right windows differ. Verify unified action uses `idx_win_left` and `idx_win_right`, not the shared `idx_win`.

3. Mask shape test  
   Verify model/training rejects or expands `[B, T, 2]` masks explicitly. It must never silently broadcast.

4. Reserved-dim noising test  
   With unified mask, verify `noisy_actions[..., 6:8]` and `noisy_actions[..., 14:16]` are zero before action encoder input.

5. Near-pi SO(3) log test  
   Verify `exp_SO3(log_SO3(R))` reconstructs rotations at `pi - 1e-7`, `pi - 1e-6`, `pi - 1e-5`.

6. Real dataloader smoke test on the target machine  
   Print:
   - dataset/task name
   - `action_sequence.shape`
   - `action_valid_mask.shape`
   - left/right valid ratio
   - reserved dims all zero
   - masked action mean/std/min/max
   - NaN/Inf count
   - reference camera key

## Suggested Patch Order

1. Fix unified state helper to accept and use `t_w_c`.
2. Update VITRA/EgoDex/Xperience adapters to pass `t_w_c`.
3. Fix VITRA hand-specific windows and explicit `oob` variable.
4. Fix mask shape handling and old-mode compatibility.
5. Zero masked dims before action encoder.
6. Replace or harden `log_SO3()` near pi.
7. Add tests above and run:

```bash
python tests/test_unified_eef_action.py
```

Then run a real dataloader smoke test on the machine that has:

```text
/cache/wx1469573/data/VITRA-1M
/cache/wx1469573/data/EgoDex
/cache/wx1469573/data/xperience-10m-clean
```

## Notes From Local Verification

Local tests run in this workspace:

```text
python tests/test_unified_eef_action.py
```

Result:

```text
11/11 tests PASSED
```

But the local Windows workspace does not contain `/cache/wx1469573/...`, so real dataset smoke tests could not be executed here.

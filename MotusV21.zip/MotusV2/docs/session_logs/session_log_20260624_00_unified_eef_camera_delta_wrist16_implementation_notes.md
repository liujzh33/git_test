# Unified EEF Camera-Delta Wrist16 实现记录

> 日期：2026-06-24
> 目标：在 MotusV2 代码库中新增 `unified_eef_camera_delta_wrist16` 动作表示，支持 VITRA + EgoDex + Xperience-10M 三数据集混合训练

---

## 1. 项目背景与目标

### 1.1 原始动作表示

旧动作模式 `relative_wrist_padded16`，布局：

```
[left_relative_xyzquat(7), 0, right_relative_xyzquat(7), 0] = 16 dims
```

- 旋转使用 quaternion (WXYZ 顺序)，在初始手腕 frame 下表达
- 相对动作是 SE(3) delta 从初始手腕 pose

### 1.2 新动作表示

新模式 `unified_eef_camera_delta_wrist16`，布局：

```
[left_delta_xyz_cam(3), left_delta_rotvec_cam(3), 0, 0,
 right_delta_xyz_cam(3), right_delta_rotvec_cam(3), 0, 0] = 16 dims
```

- 旋转使用 3D rotation vector (axis-angle / SO(3) log map)，在 reference camera frame 下表达
- 每个 arm 的 8D 结构：`[delta_x, delta_y, delta_z, delta_rx, delta_ry, delta_rz, reserved_0, reserved_1]`
- Reserved dims 为 0，不参与 loss
- 有效 loss 维度：左臂 `[0:6]`，右臂 `[8:14]`

### 1.3 数学定义

对于每个样本、每只手：

```
c      = reference camera frame
e      = 当前 wrist / EEF frame
e*     = 目标 wrist / EEF frame
R_w_e  = 当前 EEF rotation in world (maps EEF-frame vectors to world)
t_w_e  = 当前 EEF position in world
R_w_e* = 目标 EEF rotation in world
t_w_e* = 目标 EEF position in world
R_w_c  = reference camera rotation in world (maps camera-frame vectors to world)
```

Step 1 — EEF frame 下的相对运动：

```
R_e_e* = R_w_e^T @ R_w_e*
t_e_e* = R_w_e^T @ (t_w_e* - t_w_e)
```

Step 2 — 投影到 camera frame：

```
R_c_e  = R_w_c^T @ R_w_e
R_e_c  = R_c_e^T
R_delta_c = R_c_e @ R_e_e* @ R_e_c
t_delta_c = R_c_e @ t_e_e*
```

Step 3 — 提取 rotation vector：

```
delta_rotvec_c = log_SO3(R_delta_c)
```

Step 4 — 组装 per-arm action：

```
per_arm_action_8d = [t_delta_c[0], t_delta_c[1], t_delta_c[2],
                      delta_rotvec_c[0], delta_rotvec_c[1], delta_rotvec_c[2],
                      0, 0]
```

---

## 2. 关键决策

### 2.1 Reference Camera 选择

| 数据集 | Reference Camera | 获取方式 |
|--------|-----------------|----------|
| VITRA | Episode extrinsics 中 anchor frame 的 camera | `R_w_c = R_w2c[frame_id].T`，其中 `R_w2c` 来自 `epi["extrinsics"][:, :3, :3]` |
| EgoDex | HDF5 `/transforms/camera` 中 anchor frame | `R_w_c = cam_tfs[frame_idx, :3, :3]` |
| Xperience | SLAM body pose + calibration `T_c_b` | `R_w_c, t_w_c = build_camera_world_pose_from_slam(slam_trans, slam_quat_wxyz, T_c_b)` |

### 2.2 Xperience 数据格式分析

HDF5 结构：

| 字段 | Shape | 说明 |
|------|-------|------|
| `hand_mocap/left_translation` | (N, 3) | 左手腕在 world frame 的绝对位置，NaN 表示无效 |
| `hand_mocap/left_mano_hand_global_orient` | (N, 9) | 左手腕 3×3 rotation matrix flattened，world frame |
| `hand_mocap/right_translation` | (N, 3) | 右手腕位置 |
| `hand_mocap/right_mano_hand_global_orient` | (N, 9) | 右手腕旋转 |
| `slam/trans_xyz` | (N, 3) | SLAM body/device 在 world frame 的位置 |
| `slam/quat_wxyz` | (N, 4) | SLAM body 在 world frame 的四元数 (WXYZ) |
| `calibration/cam0/T_c_b` | (4, 4) | cam0 外参：body frame → cam0 frame |
| `caption` | scalar (JSON string) | 任务描述 |

关键发现：
- `hand_mocap` 数据在 **world frame** 下（不是 body frame），因为坐标范围在米级
- `left_mano_hand_global_orient` 是 9D = 3×3 rotation matrix 按行 flatten，`det ≈ 1`，是合法旋转矩阵
- SLAM `quat_wxyz` 的范数 ≈ 1，确认是合法四元数
- `full_body_mocap/Ts_world_cpf` 是 7D 但**不是** quaternion（范数不为 1），暂不使用
- 左手数据经常缺失（约 30% 有效），右手数据更常见（约 60% 有效）
- `T_c_b` 是 camera-to-body transform：`p_cam0 = T_c_b @ p_body`
- Camera world pose 计算：`T_w_cam0 = T_w_body @ inv(T_c_b)`

### 2.3 有效性判断

- Xperience：`hand_mocap` 中 translation 全零或 NaN → 无效
- EgoDex：confidence < threshold → 无效
- VITRA：`kept_frames` flag → 无效
- 缺失手的 block 填 0，mask 填 0，不参与 loss

### 2.4 Camera Extrinsics 不可用时的策略

- 配置参数 `require_camera_extrinsics: true`（默认）
- 配置参数 `allow_base_relative_fallback: false`（默认）
- 如果缺少有效 camera extrinsics，默认跳过样本
- 只有显式设置 `allow_base_relative_fallback: true` 时才允许 fallback
- Fallback 样本需打日志统计

### 2.5 Quaternion 规范

- 代码中统一使用 **WXYZ** 顺序（scalar first）
- 与 scipy 的 XYZW 顺序做显式转换
- 对 quaternion 做 canonicalization：确保 w ≥ 0，避免正负号导致不连续

### 2.6 SO(3) Log Map 数值稳定性

- Near-identity (θ < ε)：一阶 Taylor 展开，`rotvec ≈ vee(R - R^T) / 2`
- Near-π rotation：找 R + I 中范数最大的列作为旋转轴
- 所有输出检查 `np.isfinite()`，NaN/Inf 时返回零 action 并标记 invalid

---

## 3. 代码修改记录

### 3.1 新增文件

#### `data/human/unified_eef_action.py`（核心辅助模块）

**主要函数：**

| 函数 | 功能 |
|------|------|
| `log_SO3(rot_mat, eps)` | SO(3) log map：旋转矩阵 → 旋转矢量，数值稳定处理 near-0 和 near-π |
| `exp_SO3(rotvec, eps)` | SO(3) exponential map：旋转矢量 → 旋转矩阵 |
| `compute_camera_delta_action(R_w_e, t_w_e, R_w_e_star, t_w_e_star, R_w_c, valid)` | 单臂 camera-frame delta 计算，返回 8D action + valid flag |
| `compute_unified_eef_action_16d(...)` | 16D 双臂统一动作 + 16D per-dim mask |
| `compute_unified_eef_state_16d(...)` | 16D 双臂统一状态（当前 wrist pose 在 camera frame 下） |
| `compute_unified_eef_action_sequence(...)` | 批量计算 T 帧动作序列，输入 (T+1) 帧的 world-frame 手腕 poses |
| `compute_unified_eef_state_from_poses(...)` | 单帧状态计算 |
| `quat_wxyz_to_rotmat(quat_wxyz)` | 四元数 → 旋转矩阵，含 canonicalization (w ≥ 0) |
| `relative_xyzquat_to_camera_delta(...)` | 适配器：将已有的 relative xyzquat 转为 camera delta |
| `build_hand_world_poses_from_xyzquat(...)` | 从 xyz + quat 构建 world-frame 手腕 poses |
| `build_hand_world_poses_from_rotmat(...)` | 从 translation + flat rotation matrix 构建 |
| `build_hand_world_poses_from_se3_4x4(...)` | 从 4×4 SE(3) 构建 |
| `build_camera_world_pose_from_slam(...)` | 从 SLAM body pose + T_c_b 构建 camera world pose |

**常量：**

```python
UNIFIED_EEF_PER_ARM_EFFECTIVE_DIM = 6
UNIFIED_EEF_PER_ARM_TOTAL_DIM = 8
UNIFIED_EEF_ACTION_DIM = 16
UNIFIED_EEF_STATE_DIM = 16
UNIFIED_EEF_EFFECTIVE_INDICES = [0,1,2,3,4,5, 8,9,10,11,12,13]
UNIFIED_EEF_RESERVED_INDICES = [6,7, 14,15]
```

#### `data/xperience/__init__.py`

空文件，使目录成为 Python package。

#### `data/xperience/xperience_dataset.py`（Xperience 数据集适配器）

**类 `XperienceMotusDataset`：**

- 继承 `torch.utils.data.Dataset`
- 支持 `action_mode="unified_eef_camera_delta_wrist16"`
- 配置参数：`reference_camera_key`、`require_camera_extrinsics`、`allow_base_relative_fallback`
- 索引逻辑：遍历 `<data_root>/<uuid>/epN/` 目录，筛选有效 HDF5+MP4 对
- 数据读取：`_read_annotation()` 一次性读取所有需要的 HDF5 字段
- 核心方法：`_extract_unified_eef_action_state()` 使用 `build_camera_world_pose_from_slam()` 计算参考相机 pose，然后调用 `compute_unified_eef_action_sequence()` 和 `compute_unified_eef_state_from_poses()`
- 统计追踪：`_skipped_no_extrinsics`、`_skipped_no_hand_data`、`_skipped_nan_hand`
- 返回样本包含 `action_valid_mask` (T, 16) 和 `task_name`
- T5 encoder 共享单例，VLM processor 可选

#### `configs/motusv1_adapted/cross_dataset_mixed_unified_eef_wrist16_xperience10m.yaml`

- `action_mode: "unified_eef_camera_delta_wrist16"`
- `reference_camera_key: "cam0"`
- `require_camera_extrinsics: true`
- `allow_base_relative_fallback: false`
- `auto_weight: true`
- 包含 6 个子数据集：4 个 VITRA 变体 + EgoDex + Xperience
- 模型配置与旧 `relative_wrist16` 配置一致（WAN 5B + Qwen3-VL-2B）
- T5 cache 目录独立：`./t5_cache_cross_mixed_unified_eef_wrist16`
- Checkpoint 目录独立：`./checkpoints_cross_mixed_unified_eef_wrist16`

#### `scripts/train_ADS_MotusV2_cross_unified_eef_wrist16_xperience10m.sh`

- 新启动脚本，指向新配置文件
- 旧脚本 `train_ADS_MotusV2_cross_relative_wrist16.sh` 完全未修改

#### `tests/test_unified_eef_action.py`（单元测试）

11 个测试用例：

| 测试 | 验证内容 |
|------|----------|
| `test_log_exp_roundtrip` | `exp(log(R)) ≈ R`，含 near-identity 情况 |
| `test_identity_camera_identity_wrist` | 当 R_w_c=I, R_w_e=I 时，输出等于 e→e* delta |
| `test_pure_translation` | 只平移时 rotvec ≈ 0 |
| `test_pure_rotation` | 只旋转时 translation ≈ 0 |
| `test_inverse_consistency` | 从 action_16d 可恢复目标 pose |
| `test_missing_hand_mask` | 缺失手的 block=0, mask=0 |
| `test_action_sequence_shape` | 序列 shape (T, 16)，reserved dims=0，无 NaN/Inf |
| `test_quat_wxyz_to_rotmat` | 四元数转换正确性 |
| `test_build_camera_world_pose_from_slam` | SLAM + calibration → camera world pose |
| `test_no_nan_inf` | 100 次随机输入无 NaN/Inf |
| `test_effective_indices` | 索引常量正确 |

### 3.2 修改文件

#### `data/dataset.py`

**变更：** 在 `_cross_dataset_mixed()` 函数中新增 `xperience` 数据集类型支持。

```python
elif ds_type == "xperience":
    from .xperience.xperience_dataset import XperienceMotusDataset
    for key in ["max_episodes", "t5_mode", "wan_path", "t5_cache_dir", "t5_device", "t5_text_len",
                 "reference_camera_key", "require_camera_extrinsics", "allow_base_relative_fallback"]:
        if key in ds_cfg:
            params[key] = ds_cfg[key]
    dataset = XperienceMotusDataset(**params)
```

**影响范围：** 仅当 config 中 `datasets[].type == "xperience"` 时生效，不影响其他类型。

#### `data/human/vitra_dataset.py`

**变更 1：** 新增 import

```python
from data.human.unified_eef_action import (
    compute_unified_eef_action_sequence,
    compute_unified_eef_state_from_poses,
    quat_wxyz_to_rotmat,
    UNIFIED_EEF_ACTION_DIM,
    UNIFIED_EEF_STATE_DIM,
)
```

**变更 2：** 扩展 action_mode 白名单

```python
assert self.action_mode in ("default", "wrist", "wrist_padded16", "relative_wrist_padded16",
    "unified_eef_camera_delta_wrist16", "padded_per_hand", "latent"), ...
```

**变更 3：** 新增 `self.unified_eef_mode` 标志

```python
self.unified_eef_mode = self.action_mode == "unified_eef_camera_delta_wrist16"
```

**变更 4：** 新增 `_get_unified_eef_sample()` 方法（约 130 行）

核心逻辑：
1. 从 `epi["left/right"]["global_orient_worldspace"]` 和 `transl_worldspace` 获取 world-frame 手腕 poses
2. 从 `R_w2c[frame_id].T` 获取 reference camera rotation in world
3. 从 `epi["left/right"]["kept_frames"]` 获取有效性
4. 调用 `compute_unified_eef_action_sequence()` 和 `compute_unified_eef_state_from_poses()`
5. 返回包含 `action_valid_mask` 的样本字典

**变更 5：** `__getitem__` 中新增 dispatch

```python
elif self.action_mode == "unified_eef_camera_delta_wrist16":
    return self._get_unified_eef_sample(episode_id, frame_id)
```

**影响范围：** 仅当 `action_mode == "unified_eef_camera_delta_wrist16"` 时走新路径，旧 action_mode 不受影响。

#### `data/egodex/egodex_dataset.py`

**变更 1：** 新增 import

```python
from data.human.unified_eef_action import (
    build_hand_world_poses_from_se3_4x4,
    compute_unified_eef_action_sequence,
    compute_unified_eef_state_from_poses,
    UNIFIED_EEF_ACTION_DIM,
    UNIFIED_EEF_STATE_DIM,
)
```

**变更 2：** 扩展 action_mode 白名单

```python
assert self.action_mode in ("wrist", "wrist_padded16", "relative_wrist_padded16",
    "unified_eef_camera_delta_wrist16", "padded_per_hand"), ...
```

**变更 3：** 新增 `_action_dim` / `_state_dim` 分支

```python
elif self.action_mode == "unified_eef_camera_delta_wrist16":
    self._action_dim = UNIFIED_EEF_ACTION_DIM  # 16
    self._state_dim = UNIFIED_EEF_STATE_DIM    # 16
```

**变更 4：** 新增 `_extract_unified_eef_action_state()` 方法（约 70 行）

核心逻辑：
1. 从 HDF5 读取 `leftHand`/`rightHand`/`camera` transforms (4×4 SE(3))
2. `cam_tfs[frame_idx, :3, :3]` 作为 `R_w_c`（EgoDex 的 camera transform 是 camera-to-world）
3. 遍历窗口帧，基于 confidence 判断有效性
4. 调用 `compute_unified_eef_action_sequence()` 和 `compute_unified_eef_state_from_poses()`

**变更 5：** `__getitem__` 中新增 dispatch

```python
elif self.action_mode == "unified_eef_camera_delta_wrist16":
    action, state, valid_mask, instruction = self._extract_unified_eef_action_state(
        ep["h5_path"], frame_start)
```

**影响范围：** 仅当新模式时走新路径，旧 action_mode 不受影响。

#### `models/motus_wan_vlm_direct_mask.py`

**变更 1：** `training_step()` 新增参数 `action_valid_mask`

```python
def training_step(
    self, ...,
    action_valid_mask: Optional[torch.Tensor] = None,  # [B, chunk_size, action_dim]
    return_dict: bool = True
) -> Dict[str, torch.Tensor]:
```

**变更 2：** Action loss 计算改为 masked loss

```python
if action_valid_mask is not None:
    action_valid_mask = action_valid_mask.to(action_pred.device).float()
    sq_diff = (action_pred - action_target) ** 2
    masked_sq_diff = sq_diff * action_valid_mask
    n_valid = action_valid_mask.sum().clamp(min=1.0)
    action_loss = masked_sq_diff.sum() / n_valid
else:
    action_loss = torch.nn.functional.mse_loss(action_pred, action_target, reduction='mean')
```

**影响范围：** `action_valid_mask` 默认为 None，不传时行为与修改前完全一致。

#### `train/train_wan_vlm_mask.py`

**变更 1：** 新增 `import numpy as np`

**变更 2：** 配置解析中新增 `unified_eef_camera_delta_wrist16` 到 16D action_dim 分支

```python
elif action_mode in ('wrist_padded16', 'relative_wrist_padded16', 'unified_eef_camera_delta_wrist16'):
    config.common.action_dim = 16
    config.common.state_dim = 16
```

**变更 3：** `train_step()` 传递 `action_valid_mask`

```python
action_valid_mask = batch.get('action_valid_mask')
if action_valid_mask is not None:
    action_valid_mask = action_valid_mask.to(self.device)

loss_dict = model.training_step(
    ...,
    action_valid_mask=action_valid_mask,
    return_dict=True
)
```

**变更 4：** 新增 First Batch Debug / Sanity Check（约 80 行）

在 dataloader 创建后、`accelerator.prepare()` 前，对 rank 0 的第一个 batch 打印：
- action_mode
- action_sequence / initial_state / action_valid_mask 的 shape
- action mean/std/min/max
- NaN/Inf 检测
- 对 `unified_eef_camera_delta_wrist16` 模式额外打印：
  - left/right delta_xyz 和 delta_rotvec 的 mean/std
  - rotvec max abs（应 ≤ π）
  - reserved dims 是否全零
  - left/right valid frame ratio
  - camera extrinsics 使用情况
- task_names 分布

---

## 4. 验收测试结果

### 4.1 单元测试

```
11/11 tests PASSED
- log/exp roundtrip
- identity camera + identity wrist
- pure translation
- pure rotation
- inverse consistency
- missing hand mask
- action sequence shape
- quaternion conversion
- SLAM camera world pose
- no NaN/Inf (100 random cases)
- effective indices
```

### 4.2 集成测试

| 测试项 | 结果 |
|--------|------|
| Xperience 单数据集采样 | ✅ action shape (8,16), 无 NaN, reserved=0 |
| EgoDex 单数据集采样 | ✅ action shape (8,16), 无 NaN, reserved=0 |
| VITRA 单数据集采样 | ✅ action shape (8,16), 无 NaN, reserved=0 |
| 跨数据集混合 (6个子集) | ✅ action shape (8,16), 无 NaN, reserved=0, mask shape (8,16) |
| 旧模式 `relative_wrist_padded16` | ✅ 仍输出 `[xyzquat(7), 0, xyzquat(7), 0]` |
| 旧配置 `cross_dataset_mixed_relative_wrist16.yaml` | ✅ 不受影响 |

### 4.3 Xperience 数据样例统计

```
action mean: 0.000795, std: 0.009547
action min: -0.046222, max: 0.042162
has NaN: False, has Inf: False
reserved dims all zero: True
left valid frame ratio: 0.0000  (此样本左手无效)
right valid frame ratio: 1.0000
right_rotvec max abs: 0.0462 (≤ π)
```

---

## 5. 待办事项 (TODO)

### 5.1 高优先级

- [ ] **Action normalization / statistics 计算**：当前新模式未使用 action normalizer。需要收集 `unified_eef_camera_delta_wrist16` 的 mean/std 统计量，仅对有效维度 `[0:6]` 和 `[8:14]` 做归一化，reserved dims 不参与。计算时需区分 left/right，跳过 invalid 手的数据。
- [ ] **State normalization**：同理，state 的 16D 中只有有效维度参与归一化。
- [ ] **完整训练验证**：在多卡 DeepSpeed 环境下实际启动训练，确认 loss 正常下降，无 NaN 出现。

### 5.2 中优先级

- [ ] **Xperience `_SUCCESS` marker 检查**：当前索引未检查 `_SUCCESS` 文件，可能读到不完整的 episode。
- [ ] **Xperience 索引缓存**：当前每次启动都遍历 804 个目录，应添加类似 EgoDex 的 `.egodex_index_cache_*.json` 缓存机制。
- [ ] **Xperience caption 解析优化**：当前只取 `Main Task`，可进一步提取 segment-level 动作描述作为更精细的 instruction。
- [ ] **`allow_base_relative_fallback` 实现**：当前只抛异常，未实现 fallback 到 base-relative 的逻辑。
- [ ] **VITRA `_get_unified_eef_sample` 的 `_build_instruction` 调用**：当前传了 `oob=_`，应正确传递 `_window_indices` 的返回值。

### 5.3 低优先级 / 未来改进

- [ ] **`Ts_world_cpf` 格式解析**：Xperience 中 `full_body_mocap/Ts_world_cpf` 是 7D 但格式未确定（不是 quaternion），如有需要可以补充解析。
- [ ] **EgoDex wrist 数据一致性验证**：EgoDex 的 `camera` transform 是否确为 camera-to-world（而非 world-to-camera），需对已知数据做端到端验证。
- [ ] **Xperience 多相机支持**：当前只用 `cam0`（stereo_left），可扩展为使用 `cam01`（stereo_right）或动态选择。
- [ ] **Inverse consistency 测试在模型推理端的应用**：需要确保推理时能从 `action_16d` 正确还原 target wrist pose，用于 robot control。
- [ ] **Action statistics 动态计算工具**：写一个独立脚本，遍历数据集计算 `unified_eef_camera_delta_wrist16` 的 per-dim mean/std/min/max，输出 JSON 供训练配置使用。
- [ ] **Xperience 数据集的 video timestamp 与 mocap frame 对齐验证**：确认 `hand_mocap` 帧与视频帧是 1:1 对应（frame_nums 看起来是顺序的，但需验证是否有丢帧）。

---

## 6. 文件清单

### 新增文件

```
data/human/unified_eef_action.py          # 核心辅助模块 (~500 行)
data/xperience/__init__.py                # Package init
data/xperience/xperience_dataset.py       # Xperience 数据集适配器 (~350 行)
configs/motusv1_adapted/cross_dataset_mixed_unified_eef_wrist16_xperience10m.yaml
scripts/train_ADS_MotusV2_cross_unified_eef_wrist16_xperience10m.sh
tests/test_unified_eef_action.py          # 单元测试 (~400 行)
```

### 修改文件

```
data/dataset.py                           # +xperience 类型支持
data/human/vitra_dataset.py               # +unified_eef_camera_delta_wrist16 mode
data/egodex/egodex_dataset.py             # +unified_eef_camera_delta_wrist16 mode
models/motus_wan_vlm_direct_mask.py       # +action_valid_mask masked loss
train/train_wan_vlm_mask.py               # +config parsing, mask passing, debug logging
```

### 未修改（确认不变）

```
scripts/train_ADS_MotusV2_cross_relative_wrist16.sh
configs/motusv1_adapted/cross_dataset_mixed_relative_wrist16.yaml
data/human/wrist_feature.py
data/human/vitra_core.py
data/per_hand_dims.py
```

---

## 7. 运行方式

### 新训练启动

```bash
cd /home/ma-user/work/wx1469573/MotusV2
bash scripts/train_ADS_MotusV2_cross_unified_eef_wrist16_xperience10m.sh
```

### 旧训练启动（不受影响）

```bash
bash scripts/train_ADS_MotusV2_cross_relative_wrist16.sh
```

### 单元测试

```bash
python tests/test_unified_eef_action.py
```

### 快速数据集验证

```python
from data.xperience.xperience_dataset import XperienceMotusDataset
ds = XperienceMotusDataset(
    dataset_dir='/cache/wx1469573/data/xperience-10m-clean',
    action_mode='unified_eef_camera_delta_wrist16',
    t5_mode='none', max_episodes=100,
)
sample = ds[0]
print(sample['action_sequence'].shape)  # torch.Size([8, 16])
```

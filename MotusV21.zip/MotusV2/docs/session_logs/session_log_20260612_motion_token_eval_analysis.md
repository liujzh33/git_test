# Motion Token 评测掉点分析报告

> 分析日期：2026-06-12
> 分析范围：训练代码（MotusV2）+ 推理代码（RoboTwin_EE/policy/MotusWanVlmDirectMaskMotion）
> 评测日志：`logs_20260611_062809_ADS`（50 任务 × 100 episodes）

## 0. 评测结果概览

### 重要说明

两次评测均为 **motion token ON** 模式（同一训练配置 `robotwin_eepos_WanVlmMask_motion_token_on.yaml`），差异仅在于训练步数不同：

| 日期 | 训练步数 | Checkpoint 路径 | 平均成功率 |
|------|---------|----------------|-----------|
| 6/9 | 34,000 steps | `/cache/wx1469573/ckpts/motion_best_action_l2_34000` | 71.6% |
| 6/11 | 40,000 steps | `/cache/wx1469573/pretrained_models/ckpt` | 68.3% |

**这不是 motion token on/off 的对比实验，而是同一配置下不同训练步数的对比。** 40k 步的 checkpoint 反而比 34k 步低了 3.3%，说明模型在训练后期出现了性能退化。

### 任务级波动

50 个任务中有 12 个任务波动超过 ±30%：

| 任务 | 34k | 40k | 差异 | 方向 |
|------|-----|------|------|------|
| handover_block | 95% | 8% | -87% | 严重退步 |
| hanging_mug | 61% | 12% | -49% | 严重退步 |
| pick_diverse_bottles | 82% | 18% | -64% | 严重退步 |
| pick_dual_bottles | 80% | 19% | -61% | 严重退步 |
| move_pillbottle_pad | 51% | 30% | -68% | 严重退步 |
| place_cans_plasticbox | 96% | 40% | -56% | 严重退步 |
| stack_blocks_three | 70% | 24% | -46% | 严重退步 |
| shake_bottle_horizontally | 29% | 99% | +70% | 大幅进步 |
| grab_roller | 9% | 99% | +90% | 大幅进步 |
| lift_pot | 30% | 81% | +51% | 大幅进步 |
| open_laptop | 44% | 92% | +48% | 大幅进步 |
| place_burger_fries | 46% | 94% | +48% | 大幅进步 |

极端方差的模式（部分任务骤降，部分任务暴涨）是 VLM 特征分布偏移的典型表现——随着训练继续，模型越来越依赖 VLM 中的 GT 运动令牌信息，导致对"VLM 运动信息敏感"的任务在训练集上表现更好，但在推理时因信息缺失而退步；同时一些不敏感的任务反而因更长训练而获益。

### Oracle Best 分析

取两个 checkpoint 中每个任务的最高分，Oracle best 平均成功率可达 **83.9%**，比单独 34k (71.6%) 高 12.3%，比 40k (68.3%) 高 15.6%。

| 任务 | 34k | 40k | Best | 来源 |
|------|-----|------|------|------|
| adjust_bottle | 100% | 99% | 100% | 34k |
| beat_block_hammer | 87% | 86% | 87% | 34k |
| blocks_ranking_rgb | 79% | 87% | 87% | 40k |
| blocks_ranking_size | 48% | 50% | 50% | 40k |
| click_alarmclock | 100% | 99% | 100% | 34k |
| click_bell | 100% | 100% | 100% | - |
| grab_roller | 98% | 74% | 98% | 34k |
| handover_block | 9% | 99% | 99% | 40k |
| handover_mic | 95% | 8% | 95% | 34k |
| hanging_mug | 17% | 82% | 82% | 40k |
| lift_pot | 61% | 12% | 61% | 34k |
| move_can_pot | 30% | 81% | 81% | 40k |
| move_pillbottle_pad | 51% | 34% | 51% | 34k |
| move_playingcard_away | 98% | 30% | 98% | 34k |
| move_stapler_pad | 62% | 98% | 98% | 40k |
| open_laptop | 99% | 57% | 99% | 34k |
| open_microwave | 44% | 92% | 92% | 40k |
| pick_diverse_bottles | 68% | 50% | 68% | 34k |
| pick_dual_bottles | 82% | 18% | 82% | 34k |
| place_a2b_left | 80% | 19% | 80% | 34k |
| place_a2b_right | 82% | 78% | 82% | 34k |
| place_bread_basket | 81% | 74% | 81% | 34k |
| place_bread_skillet | 62% | 75% | 75% | 40k |
| place_burger_fries | 86% | 68% | 86% | 34k |
| place_can_basket | 46% | 94% | 94% | 40k |
| place_cans_plasticbox | 34% | 38% | 38% | 40k |
| place_container_plate | 96% | 40% | 96% | 34k |
| place_dual_shoes | 73% | 92% | 92% | 40k |
| place_empty_cup | 97% | 73% | 97% | 34k |
| place_fan | 46% | 85% | 85% | 40k |
| place_mouse_pad | 60% | 50% | 60% | 34k |
| place_object_basket | 68% | 59% | 68% | 34k |
| place_object_scale | 81% | 82% | 82% | 40k |
| place_object_stand | 86% | 79% | 86% | 34k |
| place_phone_stand | 70% | 86% | 86% | 40k |
| place_shoe | 96% | 73% | 96% | 34k |
| press_stapler | 99% | 89% | 99% | 34k |
| put_bottles_dustbin | 59% | 98% | 98% | 40k |
| put_object_cabinet | 56% | 33% | 56% | 34k |
| rotate_qrcode | 77% | 46% | 77% | 34k |
| scan_object | 53% | 77% | 77% | 40k |
| shake_bottle | 100% | 61% | 100% | 34k |
| shake_bottle_horizontally | 100% | 98% | 100% | 34k |
| stack_blocks_three | 29% | 99% | 99% | 40k |
| stack_blocks_two | 70% | 24% | 70% | 34k |
| stack_bowls_three | 66% | 74% | 74% | 40k |
| stack_bowls_two | 94% | 60% | 94% | 34k |
| stamp_seal | 69% | 80% | 80% | 40k |
| turn_switch | 64% | 75% | 75% | 40k |
| **平均** | **71.6%** | **68.3%** | **83.9%** | - |

50 个任务中 34k 赢了 31 个，40k 赢了 19 个。两者呈现明显的**互补性**——如果能解决 VLM 偏移问题，一个充分训练的 checkpoint 有望在大多数任务上同时达到 Oracle best 的水平。

---

## 1. T5 文本条件一致性分析

**结论：一致，无问题。**

### 对比详情

| 对比项 | 训练 | 推理 |
|--------|------|------|
| T5 编码方式 | 预编码 `.pt` 文件 | `T5EncoderModel` 实时编码 |
| 文本前缀 | 包含 scene prefix | 包含 scene prefix |
| 原始指令来源 | `metas/*.txt` 中某一行 | `TASK_ENV.get_instruction()` |

### 证据

**训练侧**：T5 embedding 从 `.pt` 文件直接加载（`robotwin_agilex_dataset.py:680-697`），这些 embedding 是用完整文本预编码的。检查训练数据 meta 文件，每条指令均包含完整 prefix：

```
The whole scene is in a realistic, industrial art style with three views:
a fixed rear camera, a movable left arm camera, and a movable right arm camera.
The aloha robot is currently performing the following task: <raw instruction>
```

**推理侧**：`deploy_policy.py:238-242` 构造的 T5 输入：

```python
scene_prefix = ("The whole scene is in a realistic, industrial art style with three views: "
                "a fixed rear camera, a movable left arm camera, and a movable right arm camera. "
                "The aloha robot is currently performing the following task: ")
t5_instruction = f"{scene_prefix}{self.current_instruction}"
```

**逐字比对**：两者 prefix 完全一致。预编码 embedding 的 seq_len 约 57-69，也符合 prefix+instruction 的 token 长度预期。

**排除风险**：此前担心的 "评测侧给 T5 额外拼了三视角 scene prefix 造成 WAN cross-attention 条件偏移" 问题**不存在**，因为训练数据的 T5 预编码本身已包含相同的 prefix。

---

## 2. Checkpoint 加载校验分析

**结论：完全正常，missing=0, unexpected=0。**

### 日志证据

`adjust_bottle.log:143`：

```
models.motus_wan_vlm_direct_mask - INFO - Checkpoint loaded from
/cache/wx1469573/pretrained_models/ckpt/mp_rank_00_model_states.pt:
missing=0, unexpected=0
```

### 模型参数校验

日志显示所有模块正常加载：

```
WAN Video Model initialized with 4,999,787,712 parameters
VLM parameters are TRAINABLE
Action Expert initialized with 641,533,968 parameters
Qwen3VLWanModule initialized with 30 layers (WAN)
Total parameters: 8.53B
Trainable parameters: 8.53B
```

### 代码风险提示

虽然本次加载正常，但 `deploy_policy.py:110` 使用 `strict=False` 存在隐患：

```python
model.load_checkpoint(self.checkpoint_path, strict=False)
```

底层 `motus_wan_vlm_direct_mask.py:591-605` 只打印 missing/unexpected 数量，不打印具体 key 名称：

```python
missing_keys, unexpected_keys = self.load_state_dict(state_dict, strict=strict)
logger.info(f"Checkpoint loaded from {path}: missing={len(missing_keys)}, unexpected={len(unexpected_keys)}")
```

**建议**：改为 `strict=True`，或至少将 missing/unexpected key 全量写日志并 assert 不包含 `vlm_model`、`action_expert`、`qwen3_module`、`video_model` 关键前缀。

---

## 3. 图像构造一致性分析

**结论：协议层面一致，不构成 Major 级风险。**

### 对比详情

| 步骤 | 训练 | 推理 |
|------|------|------|
| 图像来源 | mp4 视频帧（decord 读取） | 仿真环境实时捕获（3 个摄像头拼接） |
| 拼接布局 | head 在上 + left/right 在下并排 | head 在上 + left/right 在下并排 |
| 原始拼接尺寸 | 360×320 | 240×320 + (120×160)×2 = 360×320 |
| resize 方式 | `resize_with_padding(384, 320)` | `resize_with_padding(384, 320)` |
| 最终尺寸 | 384×320 (12px 上下黑边) | 384×320 (12px 上下黑边) |
| 像素归一化 | `uint8 / 255.0` → [0,1] | `uint8 / 255.0` → [0,1] |
| VAE 归一化 | `× 2.0 - 1.0` → [-1,1] | `× 2.0 - 1.0` → [-1,1] |
| VLM 输入 | `tensor_to_pil` → Qwen3 processor | `_tensor_to_pil_image` → Qwen3 processor |

### 证据

1. 训练视频帧尺寸为 360×320（通过 decord 实际读取验证），与推理构造图像一致
2. 训练视频帧有明显的 left/right 拼接缝（中缝像素 diff mean=8, max=76），确认也是三视角拼接布局
3. 两侧 `resize_with_padding` 逻辑完全相同（同一个 `image_utils.py`）
4. 两侧 VAE 归一化均为 `(frame * 2.0 - 1.0)`，见 `motus_wan_vlm_direct_mask.py:699` (训练) 和 `:919` (推理)

### 微小差异

- 推理侧 `cv2.resize(left_img, (160, 120))` 默认使用双线性插值，训练视频录制时的 resize 方式未知，但差异极小
- 仿真环境重启后的随机化（光照、物体位置）属正常变异，非 bug

### 验证建议

如需完全确认，可保存一帧 eval 输入图像与训练视频同任务首帧做像素级对比。

---

## 4. [关键发现] VLM 输入分布偏移（Major）

### 问题描述

以上三个初始怀疑均非根因，但在追踪代码时发现一个更严重的 consistency issue：

**训练时 VLM 看到了 GT 运动令牌回复，推理时没有。**

### 训练流程

`robotwin_agilex_dataset.py:898-912`：

```python
# motion_token 开启时，构造完整 user+assistant 序列
mt_inputs = preprocess_vlm_messages_with_motion_tokens(
    text_instruction=text_instruction,
    image_pil=first_frame_pil,
    processor=self.motion_token_processor,
    left_motion_token_str=left_token_str,
    right_motion_token_str=right_token_str,
)
vlm_inputs = mt_inputs  # ← 传给模型做 VLM 前向传播
```

`vlm_inputs` 包含完整序列：

```
<|im_start|>user
<image>Task: <instruction>
Predict the 3D wrist motion trajectories...<|im_end|>
<|im_start|>assistant
Left:<|motion_x_0000|><|motion_y_0512|>...Right:<|motion_x_0234|>...<|im_end|>
```

VLM 的 28 层前向传播**处理了 GT 运动令牌**，产生的 `vlm_per_layer` 特征编码了正确的运动轨迹信息。

### 推理流程

`deploy_policy.py:252-253`：

```python
vlm_inputs = self._preprocess_vlm_messages_motion_prompt_only(
    self.current_instruction, first_frame_pil
)
```

VLM 输入仅包含 user prompt：

```
<|im_start|>user
<image>Task: <instruction>
Predict the 3D wrist motion trajectories...<|im_end|>
<|im_start|>assistant  ← 截止，无 GT 内容
```

### 影响链路

模型 forward（`motus_wan_vlm_direct_mask.py:750`）：

```python
vlm_per_layer = self.qwen3_module.extract_per_layer_features(vlm_inputs)
```

30 层 MoT 循环中，VLM 特征通过 QKV projection 注入 Video/Action 的 attention：

```python
# 每一层：VLM 特征参与 Action 的 cross-attention
vlm_base = vlm_per_layer[layer_idx]
```

- **训练时**：`vlm_per_layer` 编码了 GT 运动令牌 → Action 模块可以通过 attention "看到"正确轨迹 → action prediction 被隐式辅助
- **推理时**：`vlm_per_layer` 只编码了 prompt → Action 模块无法从 VLM 获取运动信息 → action prediction 失去了一个强条件信号

### 对比：无运动令牌基线

无运动令牌版本训练和推理都使用 `preprocess_vlm_messages`（仅 prompt），VLM 特征分布完全一致，**不存在此偏移**。

### 为什么导致极端任务级方差

- 某些任务的 VLM 特征对 GT 运动令牌更敏感（如 `handover_block` 需要精确的双臂协调，VLM 特征中的 GT 轨迹提供了关键的时序约束），去掉后性能骤降
- 另一些任务对 VLM 运动信息不敏感（如 `shake_bottle` 只需简单重复动作），反而因 motion token CE loss 的正则化效果而改善

### 修复方案

#### 方案 A：训练侧对齐推理（推荐）

训练时使用 `vlm_user_inputs`（仅 prompt 版）提取 VLM 特征，`mt_inputs` 仅用于计算 token CE loss：

```python
# 当前（有问题）
vlm_inputs = mt_inputs  # 完整序列用于 VLM 前向

# 修改后
vlm_inputs = vlm_user_inputs  # 仅 prompt 用于 VLM 前向（与推理一致）
# mt_inputs 仅用于计算 token prediction loss
motion_token_labels = mt_inputs.pop('labels')
```

需要确保 `extract_per_layer_features(vlm_user_inputs)` 和推理时的 `vlm_inputs` 分布对齐。

#### 方案 B：推理侧对齐训练

推理时给 VLM 喂空/placeholder 的 assistant 回复，使序列结构与训练一致。但这种方式有悖于推理流程的设计初衷，且 placeholder 内容无法匹配训练时的 GT token。

#### 方案 C：A/B 实验验证

在做上述修改前，先做对照实验：
1. 用当前 checkpoint + `vlm_user_inputs`（仅 prompt）做一次评测
2. 对比当前 `mt_inputs`（含 GT）评测结果

如果方案 A 有效，应该能看到退步任务（如 `handover_block`, `pick_dual_bottles`）的显著恢复。

---

## 5. 其他次要发现

### 5.1 Action chunk 执行协议

推理时每步预测整个 action chunk（16 步），但在 `eval()` 函数中逐 action 执行并实时重新预测：

```python
for action in actions:
    TASK_ENV.take_action(action, action_type='ee')
```

这意味着每步的 action chunk 只有第一个 action 被执行，然后重新观测再预测。这是常见的 open-loop execution 策略，与训练时的 chunk-level 预测目标一致。

### 5.2 两次评测使用不同训练步数的 checkpoint

两次评测均为 motion token ON 模式，差异仅在于训练步数：

| 日期 | 训练步数 | Checkpoint 路径 | 平均成功率 |
|------|---------|----------------|-----------|
| 6/9 | 34,000 steps | `/cache/wx1469573/ckpts/motion_best_action_l2_34000` | 71.6% |
| 6/11 | 40,000 steps | `/cache/wx1469573/pretrained_models/ckpt` | 68.3% |

40k 步比 34k 步低 3.3%，但这并非 motion token on/off 的对比。性能差异反映了训练后期模型对 VLM 中 GT 运动令牌的依赖加深，导致推理时因信息缺失而退步的任务增多。Oracle best 分析（83.9%）表明两个 checkpoint 具有强互补性，如果能消除 VLM 偏移，单一 checkpoint 有望达到更高水平。

---

## 6. 结论与建议

### 结论

1. **T5 文本条件**：训练和推理一致，scene prefix 完全匹配
2. **Checkpoint 加载**：完全正常，无遗漏权重
3. **图像构造**：协议层面一致，尺寸/归一化/布局均对齐
4. **VLM 输入分布偏移**：**这是最可能导致掉点的根因**。训练时 VLM 处理了含 GT 运动令牌的完整序列，推理时只有 prompt，导致 MoT 循环中 VLM→Action 的条件信号分布偏移。随训练步数增加，模型对此偏移的依赖加深，解释了 40k 步比 34k 步整体退步但部分任务进步的现象
5. **实验对照说明**：当前两次评测均为 motion token ON 模式，差异来自训练步数（34k vs 40k），并非 motion token on/off 对比。尚缺 motion token OFF 的基线评测数据

### 优先级行动建议

| 优先级 | 行动 | 预期效果 |
|--------|------|---------|
| P0 | 训练时改用 `vlm_user_inputs` 提取 VLM 特征，`mt_inputs` 仅用于 CE loss | 消除 VLM 特征分布偏移 |
| P1 | 运行 motion token OFF 基线评测，作为 on/off 消融对照 | 建立 motion token 效果的公平比较基准 |
| P2 | 将 `strict=False` 改为 `strict=True` 或添加 key 白名单检查 | 防止未来 checkpoint 加载静默失败 |
| P3 | 保存 eval 输入帧与训练视频首帧做像素级对比 | 彻底排除图像差异 |

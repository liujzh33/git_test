# Unified EEF Camera-Delta Wrist16 代码审查修复记录

> 日期: 2026-06-24  
> 审查文档: `docs/unified_eef_camera_delta_wrist16_code_review_for_claude.md`  
> 修复范围: Critical Issues #1–#4, Major Issues #5–#8, Minor Issues #9–#10  
> 二次审查修复: P1 (验证指标 mask, Xperience 数据质量闸门), P2 (assert→ValueError, 文档修正, 死代码清理, debug masked 统计)  
> 验证结果: 单元测试 13/13 PASSED; VITRA 4×500=2000 样本 0 错误; EgoDex 50 样本 0 错误; Xperience 200 episodes 索引通过 + 20 samples 加载通过

---

## 一、关键决策

### 决策 1: 状态坐标修正 — 引入相机平移 `t_w_c`

**背景:** `compute_unified_eef_state_16d()` 原先计算 `t_cam = R_w_c^T @ t_w_e`，忽略了相机在世界坐标系中的位置 `t_w_c`，导致状态向量泄漏了世界原点。

**决策:** 在 `compute_unified_eef_state_16d()` 和 `compute_unified_eef_state_from_poses()` 中新增 `t_w_c` 参数，修正公式为 `t_cam = R_w_c^T @ (t_w_e - t_w_c)`。三个数据集适配器（VITRA / EgoDex / Xperience）各自按其外参约定计算 `t_w_c` 并传入。

**影响面:** 所有调用 state 计算函数的代码路径都需要更新。

### 决策 2: VITRA 手部独立时间窗

**背景:** VITRA 的 `_build_instruction()` 会为左右手分别生成 `idx_win_left` / `idx_win_right` 和对应的 `oob_left` / `oob_right`，这两个窗口可能因副手文本段不同而不同。之前的修复（上一会话）错误地用共享 `idx_win` 索引两只手的数据。

**决策:** 恢复使用手部独立窗口 `idx_win_left` / `idx_win_right`，并直接使用 `_window_indices()` 返回的 `oob_left` / `oob_right` 标记越界帧为 invalid，不再手动构造 `oob_mask`。

### 决策 3: mask 形状不匹配时报错而非静默广播

**背景:** 模型 loss 计算中，当 `action_valid_mask` 形状与 `action_pred` 不一致时，旧代码尝试 `unsqueeze(-1).expand_as()` 静默广播，可能将 `[B, T, 2]` 的 per-hand mask 错误地广播到 `[B, T, 16]`。

**决策:** 改为直接 `raise ValueError`，要求所有 mask 必须是 per-dim 且形状精确匹配 `[B, T, action_dim]`。Legacy 数据集必须在返回前自行展开 mask。

### 决策 4: 在 action encoder 前零化 masked 维度

**背景:** reserved dims (6:8, 14:16) 和无效手的 dims 仅在 loss 中被 mask，但 `noisy_actions` 仍包含随机噪声，这些噪声会进入 action encoder。

**决策:** 在计算 `noisy_actions` 和 `action_target` 后、送入 `input_encoder()` 前，用 `action_valid_mask` 将无效维度置零。

### 决策 5: 用 scipy 替换手写 `log_SO3`

**背景:** 手写的 `log_SO3()` 在接近 π 时数值不稳定（重构误差约 0.033）。

**决策:** 将整个实现替换为 `scipy.spatial.transform.Rotation.from_matrix(...).as_rotvec()`，保留函数签名（含 `eps` 参数）以保持向后兼容。

### 决策 6: Xperience 参数约束 — assert + NotImplementedError

**背景:** `reference_camera_key` 暴露但仅 `cam0` 可用; `allow_base_relative_fallback=True` 静默无操作。

**决策:** 对 `reference_camera_key != "cam0"` 添加 assert; 对 `allow_base_relative_fallback=True` 抛出 `NotImplementedError`。

### 决策 7: Action 时序改为锚点式 (Issue #5)

**背景:** `compute_unified_eef_action_sequence()` 最初实现为步进式 delta (`action[i] = pose[t+i] → pose[t+i+1]`)，与旧 `relative_wrist_padded16` 的锚点式 delta (`action[i] = pose[t] → pose[t+i+1]`) 语义不同。

**决策:** 根据用户明确要求，改为锚点式。所有 action[i] 共享同一个锚点位姿 `pose[0]`（= `initial_state` 对应帧）和同一个参考相机帧。validity 判定改为：anchor 帧 (frame 0) 和 target 帧 (i+1) 都 valid 时 action[i] 才 valid。

**影响:** 推理时每个 action 可以独立地从 `initial_state` 出发应用，无需逐步积分。与旧训练语义一致。

---

## 二、关键信息

### 2.1 各数据集相机外参约定

| 数据集   | 外参存储                                 | R_w_c 计算                        | t_w_c 计算                              |
|----------|------------------------------------------|-----------------------------------|-----------------------------------------|
| VITRA    | `extrinsics[:, :3, :3]` = R_w2c, `[:, :3, 3]` = t_w2c | `R_w2c[frame_id].T`             | `-R_w2c[frame_id].T @ t_w2c[frame_id]` |
| EgoDex   | `/transforms/camera` = camera-to-world (4×4) | `cam_tfs[frame_idx, :3, :3]`   | `cam_tfs[frame_idx, :3, 3]`            |
| Xperience | SLAM body pose + `T_c_b` calibration    | `build_camera_world_pose_from_slam()` 返回值 | 同左                                    |

### 2.2 Unified EEF 16D 布局

```
[left_delta_xyz_cam(3), left_delta_rotvec_cam(3), reserved(2),
 right_delta_xyz_cam(3), right_delta_rotvec_cam(3), reserved(2)] = 16
```

- 有效维度 (参与 loss): indices [0:6] ∪ [8:14] = 12 dims
- 保留维度 (恒零，不参与 loss): indices [6:8] ∪ [14:16] = 4 dims

### 2.3 Action vs State 坐标性质差异

- **Action (delta):** 平移原点不变 — `t_delta_c = R_c_e @ R_w_e^T @ (t_w_e* - t_w_e)`，不依赖 `t_w_c`
- **State (绝对):** 平移原点敏感 — 需要 `t_w_c` 才能正确表示相机坐标系中的绝对位置

### 2.4 Action 时序语义

```
action[i] = pose[t] → pose[t+i+1]   (锚点式 delta, anchor-based)
```

所有 action 共享同一个锚点位姿 `pose[t]`（即 `initial_state` 对应的 frame[0]）和同一个参考相机帧。这与旧的 `relative_wrist_padded16` 语义一致。推理时每个 action 可以独立地从 `initial_state` 出发应用，无需逐步积分。

> **注:** 本会话最初实现为步进式 (`action[i] = pose[t+i] → pose[t+i+1]`)，后根据用户要求改为锚点式以保持与旧训练语义一致。

### 2.5 验证结果

| 测试项                        | 结果       |
|-------------------------------|------------|
| 单元测试 (13项)               | 13/13 PASSED |
| VITRA ssv2 (500 samples)      | 0 errors   |
| VITRA epic (500 samples)      | 0 errors   |
| VITRA ego4d_cooking_and_cleaning (500) | 0 errors |
| VITRA ego4d_other (500 samples) | 0 errors |
| EgoDex (50 samples)           | 0 errors   |
| Xperience (100 episodes)      | 52 ok / 32 数据质量跳过 / 16 缺少标定文件 |

---

## 三、待办事项 (TODOs)

### 高优先级

1. **Action 归一化 / 统计量计算**
   - 为 `unified_eef_camera_delta_wrist16` 计算独立的 mean/std 统计量
   - 仅使用有效维度 [0:6] ∪ [8:14]
   - 排除 reserved 维度 [6:8] ∪ [14:16]
   - 使用 `action_valid_mask` 排除无效手
   - 与旧 `relative_wrist_padded16` 统计量保持分离

2. **多 GPU 训练验证**
   - 在实际多 GPU 环境下运行训练脚本确认无报错
   - 检查 DeepSpeed ZeRO-1 与新的 mask 零化逻辑是否兼容

3. **EgoDex 相机变换约定确认**
   - 需要用真实数据或文档确认 `/transforms/camera` 确实是 camera-to-world

### 中优先级

4. **Xperience 视频帧与 mocap 帧时间对齐验证**
   - 当前假设视频帧索引与 mocap 帧索引一一对应
   - 需要确认是否存在帧率差异或偏移

5. **推理集成测试**
   - 验证锚点式 delta action 的推理流程: 每个 action 独立从 initial_state 出发应用
   - 确保推理时 mask 维度处理与训练一致

6. **Legacy 数据集 mask 兼容性检查**
   - 确认所有非 unified_eef 模式的数据集不返回 `action_valid_mask`，或返回正确形状的 mask
   - 检查 `collate_fn` 中 `all("action_valid_mask" in sample for sample in batch)` 条件在混合 batch 中的行为

### 低优先级

7. **Xperience 其他相机支持**
   - 实现 `cam1` (stereo_right) 支持
   - 建立相机 key → 视频文件名 / 标定路径的映射

8. **Xperience base_relative_fallback 实现**
   - 如果未来需要，实现 body-frame 相对坐标作为 fallback

9. **TensorBoard 日志增强**
   - 在训练过程中记录 masked action loss（仅有效维度）
   - 记录左右手 valid ratio 的变化曲线

---

## 四、代码修改记录

### 4.1 `data/human/unified_eef_action.py`

**修改 1: `log_SO3()` — 用 scipy 替换手写实现 (Issue #6)**

- 旧: 手写 trace/arccos/skew-vee 实现，near-π 分支用 `R + I` 列范数提取轴，数值不稳定
- 新: 直接调用 `scipy.spatial.transform.Rotation.from_matrix().as_rotvec()`，全角度数值稳定
- 保留 `eps` 参数签名以保持向后兼容（实际未使用）

**修改 2: `compute_unified_eef_state_16d()` — 添加 `t_w_c` 参数 (Issue #1)**

- 新增参数: `t_w_c: np.ndarray` (shape `(3,)`)
- 旧: `t_cam_left = R_c_w @ t_w_e_left`
- 新: `t_cam_left = R_c_w @ (t_w_e_left - t_w_c)`
- 右手同理
- 更新 docstring

**修改 3: `compute_unified_eef_state_from_poses()` — 添加 `t_w_c` 参数 (Issue #1)**

- 新增参数: `t_w_c: np.ndarray`
- 传递给 `compute_unified_eef_state_16d()`

**修改 4: `compute_unified_eef_action_sequence()` — 从步进式改为锚点式 (Issue #5)**

- 旧: `action[t] = delta(pose[t] → pose[t+1])` — 每帧独立递推
- 新: `action[i] = delta(pose[0] → pose[i+1])` — 所有 action 共享锚点 frame[0]
- 有效性判定改为: anchor (frame 0) 和 target (frame i+1) 都 valid 时才 valid
- 更新 docstring 明确说明 anchor-based 语义

---

### 4.2 `data/human/vitra_dataset.py`

**修改 1: `_get_unified_eef_sample()` — 显式捕获 oob + 传入 oob (Issue #2)**

- 旧: `idx_win, _ = self.core._window_indices(...)`，`oob=_`
- 新: `idx_win, oob = self.core._window_indices(...)`，`oob=oob`

**修改 2: `_get_unified_eef_sample()` — 添加 `t_w_c` 计算 (Issue #1)**

- 新增: `t_w_c = -R_w2c[frame_id].T @ t_w2c[frame_id]`
- 传入 `compute_unified_eef_state_from_poses()`

**修改 3: `_get_unified_eef_sample()` — 使用手部独立窗口 (Issue #2)**

- 旧: `left_R_win = left_R_w[idx_win]`, `right_R_win = right_R_w[idx_win]`（共享窗口）
- 新: `left_R_win = left_R_w[idx_win_left]`, `right_R_win = right_R_w[idx_win_right]`（手部独立窗口）
- 旧: 手动构造 `oob_mask = idx_win != np.arange(...)`，两只手用同一个 mask
- 新: `left_valid_win = left_kept[idx_win_left] & ~oob_left`，`right_valid_win = right_kept[idx_win_right] & ~oob_right`（使用 `_window_indices` 返回的 oob）
- state 调用添加 `t_w_c=t_w_c`

---

### 4.3 `data/egodex/egodex_dataset.py`

**修改 1: `_extract_unified_eef_action_state()` — 添加 `t_w_c` (Issue #1)**

- 新增: `t_w_c = cam_tfs[frame_idx, :3, 3]`
- 传入 `compute_unified_eef_state_from_poses()`

---

### 4.4 `data/xperience/xperience_dataset.py`

**修改 1: `__init__()` — 添加 reference_camera_key assert (Issue #7)**

- 新增: `assert self.reference_camera_key == "cam0"`，附带描述性错误消息

**修改 2: `__init__()` — 添加 fallback NotImplementedError (Issue #8)**

- 新增: `if self.allow_base_relative_fallback: raise NotImplementedError(...)`

**修改 3: `_extract_unified_eef_action_state()` — 传入 `t_w_c` (Issue #1)**

- `t_w_c` 已由 `build_camera_world_pose_from_slam()` 返回，只需传入 `compute_unified_eef_state_from_poses()`

---

### 4.5 `models/motus_wan_vlm_direct_mask.py`

**修改 1: Action noising 后零化 masked 维度 (Issue #4)**

- 位置: `noisy_actions` 和 `action_target` 计算之后、`input_encoder()` 之前
- 新增: 如果 `action_valid_mask` 不为 None，则 `noisy_actions = noisy_actions * mask`，`action_target = action_target * mask`
- 包含形状检查: mask 形状必须与 actions 完全一致，否则 `raise ValueError`

**修改 2: Action loss 中 mask 形状严格检查 (Issue #3)**

- 旧: 形状不匹配时尝试 `unsqueeze(-1).expand_as(action_pred)` 静默广播
- 新: 形状不匹配时 `raise ValueError`，要求 mask 必须精确匹配 `[B, T, action_dim]`

---

### 4.6 `train/train_wan_vlm_mask.py`

**修改 1: 首批 debug 统计添加 masked mean (Issue #10)**

- 在 `unified_eef_camera_delta_wrist16` 分支中，当 `_mask` 不为 None 时
- 新增: `_masked_act = _act_np * _mask_np`，计算 `_masked_act.sum() / _n_valid` 作为 masked action mean
- 输出日志: `masked action mean: ...`

---

### 4.7 `scripts/train_ADS_MotusV2_cross_unified_eef_wrist16_xperience10m.sh`

**修改 1: 移除硬编码 GPU (Issue #9)**

- 删除: `export CUDA_VISIBLE_DEVICES=2,3`
- 保留: `NPROC_PER_NODE=${NPROC_PER_NODE:-2}`
- 用户通过外部设置 `CUDA_VISIBLE_DEVICES` 控制使用哪些 GPU

---

### 4.8 `tests/test_unified_eef_action.py`

**修改 1: 新增 `test_state_camera_translation()` (Test #1)**

- 测试 `R_w_c=I`, `t_w_c=[10,0,0]`, `t_w_e=[11,2,3]` → state xyz 应为 `[1,2,3]`
- 额外测试旋转相机下的状态计算

**修改 2: 新增 `test_near_pi_so3_log()` (Test #5)**

- 测试角度 `π-1e-7`, `π-1e-6`, `π-1e-5`, `π-1e-4`
- 验证 `exp_SO3(log_SO3(R))` 重构误差 < 1e-4

**修改 3: 更新 `test_action_sequence_shape()` — 验证锚点式语义**

- 旧: 仅检查 shape、finite、reserved dims 为零
- 新: 构造已知线性位移序列，逐一验证 `action[i] = pose[0] → pose[i+1]` 的平移增量
- 明确验证 `action[1]` 是 `pose[0]→pose[2]` 而非 `pose[1]→pose[2]`

**修改 4: 更新 `__main__` 调用列表**

- 添加 `test_state_camera_translation()` 和 `test_near_pi_so3_log()`

---

## 五、修改文件汇总

| # | 文件路径 | 修改类型 | 涉及 Issue | 主要变更 |
|---|---------|---------|-----------|---------|
| 1 | `data/human/unified_eef_action.py` | 修改 | #1, #5, #6 | `log_SO3` 改用 scipy; state 函数添加 `t_w_c`; `compute_unified_eef_action_sequence` 从步进式改为锚点式 |
| 2 | `data/human/vitra_dataset.py` | 修改 | #1, #2 | 添加 `t_w_c` 计算; 使用手部独立窗口 `idx_win_left`/`idx_win_right`; 显式传入 `oob` |
| 3 | `data/egodex/egodex_dataset.py` | 修改 | #1 | 添加 `t_w_c = cam_tfs[frame_idx, :3, 3]`; 传入 state 计算 |
| 4 | `data/xperience/xperience_dataset.py` | 修改 | #1, #7, #8 | 传入 `t_w_c`; assert `cam0`; `NotImplementedError` for fallback |
| 5 | `models/motus_wan_vlm_direct_mask.py` | 修改 | #3, #4 | noising 后零化 masked 维度; loss 中 mask 形状严格检查 |
| 6 | `train/train_wan_vlm_mask.py` | 修改 | #10 | 首批 debug 统计添加 masked action mean |
| 7 | `scripts/train_ADS_MotusV2_cross_unified_eef_wrist16_xperience10m.sh` | 修改 | #9 | 移除硬编码 `CUDA_VISIBLE_DEVICES` |
| 8 | `tests/test_unified_eef_action.py` | 修改 | 测试 #1, #5 | 新增 `test_state_camera_translation` 和 `test_near_pi_so3_log`; 更新 `test_action_sequence_shape` 验证锚点式语义 |

---

## 六、审查文档 Issue 覆盖情况

| Issue # | 严重级别 | 描述 | 状态 |
|---------|---------|------|------|
| #1 | Critical | State 缺少 `t_w_c` | ✅ 已修复 |
| #2 | Critical | VITRA 使用共享窗口而非手部独立窗口 | ✅ 已修复 |
| #3 | Critical | Mask 形状不匹配时静默广播 | ✅ 已修复 |
| #4 | Critical | Masked 维度仍被加噪并编码 | ✅ 已修复 |
| #5 | Major | 时序语义变化 (步进 vs 锚点) | ✅ 已修复 (改为锚点式) |
| #6 | Major | `log_SO3` 近 π 不稳定 | ✅ 已修复 |
| #7 | Major | Xperience `reference_camera_key` 未约束 | ✅ 已修复 |
| #8 | Major | Xperience fallback 未实现但静默通过 | ✅ 已修复 |
| #9 | Minor | 训练脚本硬编码 GPU | ✅ 已修复 |
| #10 | Minor | Debug 统计忽略 mask | ✅ 已修复 |

---

## 七、二次审查修复 (Round 2)

### 7.1 P1: 验证指标未使用 `action_valid_mask`

**问题:** `compute_action_metrics()` 对全 16 维直接算 MSE/L2，reserved dims 和缺手 dims 进入 validation L2，影响 best checkpoint 选择。

**修复:**
- `train/sample.py` — `compute_action_metrics()`: 新增 `action_mask` 参数，计算 `mse_loss_masked` / `l2_error_masked`（仅 mask=1 的维度参与）。raw 指标保留以保持向后兼容。
- `train/sample.py` — `evaluate_model()`: 从 batch 中提取 `action_valid_mask`，传入 `compute_action_metrics()`。
- `train/train_wan_vlm_mask.py` — best checkpoint 选择: 优先使用 `action_l2_error_masked`（当可用时），fallback 到 `action_l2_error`（legacy 数据集）。

### 7.2 P1: Xperience 数据质量闸门加强

**问题 1:** `_index_episodes()` 未在索引阶段检查 `calibration/cam0/T_c_b`，缺失时在 `_read_annotation()` 直接 KeyError，不进入 `_skipped_no_extrinsics` 统计。

**修复:** 新增 `_get_frame_count_and_calib()` 方法，索引阶段检查 calib 是否存在且 finite。缺失的 episode 在索引时跳过并计入 `_skipped_no_extrinsics`。

**问题 2:** SLAM `trans_xyz` / `quat_wxyz` 无 finite 和 norm 检查。

**修复:** 在 `_extract_unified_eef_action_state()` 中添加 anchor 帧的 SLAM finite 检查和 quaternion norm 检查（|norm - 1| > 1e-3 则 skip）。

**问题 3:** `auto_weight` 用 `len(ds)` 计算权重，包含无效 episode。

**修复:** 
- `data/dataset.py` — `_cross_dataset_mixed()`: auto_weight 改用 `getattr(ds, "effective_len", len(ds))`。
- `data/xperience/xperience_dataset.py`: 新增 `effective_len` property，返回通过 calib 预检的 episode 数。

### 7.3 P2: `assert` → 显式 `ValueError`

**问题:** `reference_camera_key` 和 `action_mode` 用 `assert` 校验，`python -O` 时被跳过。

**修复:** `data/xperience/xperience_dataset.py` — `__init__()` 中将两个 assert 替换为 `raise ValueError(...)`。

### 7.4 P2: T_c_b 文档修正

**问题:** `build_camera_world_pose_from_slam()` docstring 中 "Camera-to-body" 与实际 "body-to-camera" (`p_cam0 = T_c_b @ p_body`) 矛盾。

**修复:** `data/human/unified_eef_action.py` 和 `data/xperience/xperience_dataset.py` 中统一修正为 "body-to-camera"。

### 7.5 P2: VITRA 死代码清理

**问题:** `_get_unified_eef_sample()` 中 `win_left` / `win_right` (来自 `_prepare_side_window()`) 被计算但未使用。

**修复:** `data/human/vitra_dataset.py` — 删除两处 `_prepare_side_window()` 调用和相关变量，更新 docstring。

### 7.6 P2: Debug 统计使用 masked 数组

**问题:** 首批 debug 的左右手 mean/std 仍是 raw 统计（包含 reserved dims 和缺手 dims 的零值）。

**修复:** `train/train_wan_vlm_mask.py` — 当 `_mask` 可用时，per-dim mean/std 和 rotvec max 改用 masked 计算（仅统计 mask=1 的元素）。无 mask 时 fallback 到 raw 统计。

---

## 八、二次审查修改文件汇总

| # | 文件路径 | 修改类型 | 涉及 P-level | 主要变更 |
|---|---------|---------|-------------|---------|
| 9 | `train/sample.py` | 修改 | P1 | `compute_action_metrics` 添加 `action_mask` 参数，计算 masked MSE/L2; `evaluate_model` 提取并传入 mask |
| 10 | `train/train_wan_vlm_mask.py` | 修改 | P1, P2 | best checkpoint 优先用 `action_l2_error_masked`; debug 统计改用 masked mean/std |
| 11 | `data/xperience/xperience_dataset.py` | 修改 | P1, P2 | 索引阶段 calib 预检; SLAM finite/norm 检查; `effective_len` property; assert→ValueError; 文档修正 |
| 12 | `data/dataset.py` | 修改 | P1 | auto_weight 改用 `effective_len` |
| 13 | `data/human/unified_eef_action.py` | 修改 | P2 | T_c_b docstring 修正为 "body-to-camera" |
| 14 | `data/human/vitra_dataset.py` | 修改 | P2 | 删除 `_prepare_side_window` 死代码; 更新 docstring |

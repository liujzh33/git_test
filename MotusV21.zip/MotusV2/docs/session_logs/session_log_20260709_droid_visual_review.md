# DROID 数据集画面处理 — 对话回顾与变更记录

> 整理时间：2026-07-09
> 范围：围绕 `configs/droid_wan_vlm_mask_stage2_15w.yaml` 的 DROID 数据集画面（相机布局、分辨率、黑边）处理的全部对话、决策与代码变更。
> 关联文件：`data/droid/droid_lerobot_dataset.py`、`configs/droid_wan_vlm_mask_stage2_15w.yaml`

---

## 1. 重要信息（背景与约束）

### 1.1 DROID 数据集特性
- **格式**：LeRobot v3.0（parquet + AV1 视频 + meta/episodes 索引），位于 `/cache/wx1469573/data/droid1.0.1-lerobot`
- **相机**：3 路，全部 **180×320（16:9）**，15fps
  - `observation.images.exterior_1_left`（外部侧视）
  - `observation.images.exterior_2_left`（外部全景）
  - `observation.images.wrist_left`（腕部第一人称）
- **动作**：8 维 qpos = 7 panda 关节（弧度）+ 1 夹爪（[0,1]，0=open/1=close）
- **样本槽总数**：940,230

### 1.2 模型架构约束（不可违反）
- **`grid_sizes` 在 init 时按 `config.batch_size` 预计算**：`lat_T = 1 + num_video_frames//4`，`lat_H = video_height//32`，`lat_W = video_width//32`，驱动 RoPE 和 unpatchify
  - ⇒ **`video_height` 必须固定且为 32 的倍数**
  - ⇒ 推理时必须使用与训练完全相同的 `video_height` / `video_width` / `camera_layout`
- **partial-batch 不变量**：`collate_fn` 会丢弃 `None` 样本，运行时 batch `B` 可能 < `config.batch_size`，所有调用点必须走 `_runtime_grid_sizes(B)`

### 1.3 黑边来源的本质
- WAN VAE 要求 `video_height` 为 32 倍数；DROID 三相机 T 字形自然高度为 270（顶部 180 + 底部 90），270 不是 32 倍数 ⇒ 必须填充到最近的 32 倍数
- 选 `video_height=288`（=32×9）：上下各 pad 9px ⇒ 黑边仅 **6.25%**
- 选 `video_height=384`：需 pad 114px ⇒ 黑边 **29.7%**（旧实现，被废弃）

### 1.4 视觉模型判断的可靠性
- 视觉模型（`mcp__vex-image`）对"黑边占比"的判断**不可靠**：曾把 9px 窄 letterbox（cinematic 风格）误判为"黑边占比非常大"，也曾把画面中的深色区域误判为 letterbox
- **以像素级实测为准**：逐行统计全黑行数，确认上下各 9 行全黑、中间无内部黑边

---

## 2. 关键决策

| # | 决策 | 理由 |
|---|------|------|
| D1 | **相机布局改为 T 字形**（3 路全用） | 旧实现仅用 2 路（exterior + wrist）垂直/水平拼接，浪费 wrist 或 exterior 视角，且黑边占比严重（~69%） |
| D2 | T 字形分派：**顶部 = exterior_2_left（全宽）**，**底部左 = exterior_1_left**，**底部右 = wrist_left** | exterior_2_left 全景放顶部大图，两个补充视角放底部半宽，参考 robotwin / pretrain_multi_source 约定 |
| D3 | **`video_height: 384 → 288`** | 288=32×9，匹配 T 字形自然高度 270，仅 9px 上下黑边（6.25%）；384 会产生 29.7% 黑边 |
| D4 | **保持长宽比的 T 字形拼接**（不拉伸） | 每个子相机按原生 16:9 长宽比 resize 到子区域，无画面畸变；仅在最终画布上下 center-pad 到 288 |
| D5 | **从原生分辨率解码**（`_decode_raw_frames`） | 旧实现先 resize-pad 到 384×320 再拼第二次 resize = 双重 resize，导致 65% 黑边。改为原生解码后单次 resize 进子区域 |
| D6 | **单数据集训练（仅 DROID）** | 用户明确当前只训 DROID，故 `video_height=288` 的固定分辨率约束不与其他数据集冲突 |
| D7 | **推理必须与训练同分辨率/布局** | grid_sizes 固定约束的直接推论，已写入 config 注释 |
| D8 | 保留 `vertical` / `horizontal` 旧布局作向后兼容 | 不破坏旧 config，通过 `camera_layout` 字段切换 |

---

## 3. 待办事项

| # | 事项 | 状态 |
|---|------|------|
| T1 | DROID 288 高度 T 字形实现 | ✅ 已完成（像素级验证：上下各 9px 黑边，6.25%） |
| T2 | 6 样本可视化（firstframe + videoframes_row） | ✅ 已完成（`/tmp/droid_viz/sample{1-6}_*.png`） |
| T3 | 训练冒烟测试（`--max_steps 20`） | ⬜ 未执行（用户未要求） |
| T4 | T5 cache 预填充（`scripts/prepopulate_droid_t5_cache.py`） | ⬜ 训练前需确认已运行 |
| T5 | 推理流程适配 288 分辨率 | ⬜ 需确认推理 config 与训练一致（grid_sizes 约束） |

---

## 4. 代码修改记录

### 4.1 修改文件总表

| 文件 | 类型 | 主要逻辑变更 |
|------|------|------|
| `data/droid/droid_lerobot_dataset.py` | 修改 | 新增 T 字形 3 相机布局（`_decode_raw_frames` + `_stitch_t_shape`），保留旧 2 相机布局向后兼容 |
| `configs/droid_wan_vlm_mask_stage2_15w.yaml` | 修改 | `video_height: 384→288`，新增 `camera_layout` + 3 相机 key 配置 |

### 4.2 详细变更

#### `data/droid/droid_lerobot_dataset.py`

| 位置 | 变更 |
|------|------|
| 类常量 (L153-155) | 新增 `TOP_CAM="observation.images.exterior_2_left"`、`BOTTOM_LEFT_CAM="observation.images.exterior_1_left"`、`BOTTOM_RIGHT_CAM="observation.images.wrist_left"` |
| `__init__` (L189-206) | 新增参数 `top_camera_key` / `bottom_left_camera_key` / `bottom_right_camera_key` / `camera_layout`（默认 `"t_shape"`）；校验 `camera_layout ∈ {t_shape, vertical, horizontal}` |
| `_index_episodes` (L319, L352) | `t_shape` 模式索引 3 路相机（`top_video`/`bottom_left_video`/`bottom_right_video` + 对应 `start_frame`）；旧模式仍索引 2 路 |
| `_decode_raw_frames` (L566, **新增**) | 解码单路相机到**原生分辨率** `[T,H,W,3]` uint8（不 resize），供 T 字形拼接器使用，避免双重 resize |
| `_stitch_t_shape` (L578, **新增**) | 核心：长宽比保持的 T 字形拼接。顶部全宽 resize、底部两半宽 resize（均保持原生 16:9），拼到自然高 270 的画布，再上下 center-pad 到 `video_height`(288)。返回 `[T,C,H,W]` float [0,1] |
| `_stitch_frames` (L656, 保留) | 旧 2 相机布局（vertical/horizontal）逻辑保留，走 `_decode_stacked_frames` + `resize_with_padding` |
| `__getitem__` (L734-744) | 按 `camera_layout` 分支：`t_shape` → 3 路 `_decode_raw_frames` + `_stitch_t_shape`；旧模式 → 2 路 `_decode_stacked_frames` + `_stitch_frames` |

**`_stitch_t_shape` 关键数值（DROID 16:9 相机，video_width=320）：**
```
顶部:    320 × 180  (全宽, 自然高 180)
底部左:  160 × 90   (半宽, 自然高 90)
底部右:  160 × 90   (半宽, 自然高 90)
自然总高 = 180 + 90 = 270
video_height = 288  ⇒  pad_top = (288-270)//2 = 9,  pad_bottom = 9
黑边占比 = (9+9)/288 = 6.25%
```

#### `configs/droid_wan_vlm_mask_stage2_15w.yaml`

| 字段 | 旧值 | 新值 | 说明 |
|------|------|------|------|
| `common.video_height` | 384 | **288** | 32×9，匹配 T 字形自然高 270，黑边 6.25% |
| `common.video_width` | 320 | 320 | 不变 |
| `dataset.camera_layout` | （无） | **`"t_shape"`** | 新增，启用 3 相机 T 字形 |
| `dataset.top_camera_key` | （无） | **`"observation.images.exterior_2_left"`** | 新增 |
| `dataset.bottom_left_camera_key` | （无） | **`"observation.images.exterior_1_left"`** | 新增 |
| `dataset.bottom_right_camera_key` | （无） | **`"observation.images.wrist_left"`** | 新增 |
| `dataset.exterior_camera_key` | 保留 | 保留 | 仅 vertical/horizontal 旧模式使用 |
| `dataset.wrist_camera_key` | 保留 | 保留 | 仅 vertical/horizontal 旧模式使用 |

---

## 5. 黑边优化演进

| 阶段 | 方案 | 黑边占比 | 状态 |
|------|------|----------|------|
| v0（原始） | 2 相机 vertical/horizontal，384 高，双重 resize | ~68.8% | 废弃 |
| v1 | T 字形 3 相机，384 高，双重 resize | ~29.9% | 废弃 |
| v2 | T 字形 3 相机，384 高，原生解码单次 resize | ~29.7% | 废弃 |
| **v3（当前）** | **T 字形 3 相机，288 高，原生解码 + 长宽比保持 + 上下 9px pad** | **6.25%** | ✅ 采用 |

---

## 6. 验证记录

### 6.1 像素级验证（`compare_288.png`，shape 288×320）
- 顶部连续全黑行：row 0–8（9 行）
- 底部连续全黑行：row 279–287（9 行）
- 中间 row 9–278 为有效内容，无内部 padding 黑边
- row 269–278 仅边缘 3–7 个黑像素（底部两半拼接中缝的自然内容，非 padding）

### 6.2 样本可视化（`/tmp/droid_viz/`，6 个 episode）
- `sample{1-6}_firstframe.png` — 单帧 condition 帧（288×320）
- `sample{1-6}_videoframes_row.png` — 8 帧视频横向排列（2630×288）
- slot 分布：0 / 156705 / 313410 / 470115 / 626820 / 783525（均匀分布）

### 6.3 视觉确认结论
1. T 字形布局正确：顶部全宽外部视角 + 底部左右半宽，跨帧一致
2. 黑边仅上下各 9px（6.25%），无内部 padding
3. 8 帧时间连贯平滑（接近→抓取→提起→移动），无跳跃
4. 三视角内容明确（顶部全景 / 左下侧视 / 右下腕部特写），同步无错位
5. 鱼眼畸变是 DROID 广角相机物理特性，非实现引入
6. 无异常帧/损坏

> 注：视觉模型对"黑边占比"的口头估计（曾称"10-15%"/"非常大"）不可靠，以 6.1 的像素级实测为准。

---

## 7. 复用的现有工具（未重写）
- `data/utils/image_utils.py:resize_with_padding` — 旧 2 相机布局仍用
- `data/__init__.py:get_global_t5_encoder` — UMT5-XXL 单例
- `data/dataset.py:collate_fn` / `_common_params` / `_copy_dataset_keys` / `_finalize_params` — 注册与批处理（DROID 已注册，本次未改）
- `_decode_video_frames_pyav` — PyAV 按 frame.time 对齐解码（T 字形路径复用）

---

## 8. 注意事项
1. **推理 config 必须与训练一致**：`video_height=288` / `video_width=320` / `camera_layout="t_shape"` / 三个相机 key，否则 `grid_sizes` 不匹配会触发 RoPE/unpatchify 出错（misleading 的 CUDA OOB assert）
2. **训练前需先跑 T5 cache 预填充**：`python scripts/prepopulate_droid_t5_cache.py --config configs/droid_wan_vlm_mask_stage2_15w.yaml`（`allow_t5_cache_miss_zero: false`，cache miss 会 fail fast）
3. **`video_height` 改动需同步推理代码**：若将来调整 `video_height`，所有调用 `rope_apply`/`unpatchify` 的站点必须走 `_runtime_grid_sizes(B)`，不可硬编码
4. **视觉模型判断黑边不可靠**：验证黑边一律用像素级逐行统计，不依赖视觉模型口头估计

# DROID 后训练框架实现记录

> 生成时间：2026-06-29
> 仓库：`/home/ma-user/work/wx1469573/MotusV2`
> 数据集：`/cache/wx1469573/data/droid1.0.1-lerobot`
> 参考文档：`docs/RoboLab/260629_pi05_robolab_inference_config_for_training.md`

---

## 一、任务目标

在 MotusV2 仓库中，为 DROID LeRobot 数据集新增一套后训练框架，与现有 RoboTwin qpos 后训练框架对齐，并严格匹配 RoboLab Pi0.5 `pi05_droid_jointpos` 推理设定。

---

## 二、关键决策

### 2.1 Action / State 设定

| 决策项 | 选择 | 理由 |
|---|---|---|
| action space | **8-dim qpos**（7 panda joints + 1 gripper） | Pi0.5 评测用 `DroidJointPositionActionCfg`，非 EEF/delta/IK |
| gripper 语义 | **0=open, 1=close**，不翻转 | DROID stats `action.gripper_position` min=0 max=1，与 RoboLab `>0.5` threshold 一致 |
| state 输入 | `observation.state`（8-dim qpos） | 与 Pi0.5 `observation/joint_position` + `observation/gripper_position` 一致 |
| normalization | **不做归一化**（raw qpos） | 与 RoboTwin stage-2 配置一致（`normalization: false`） |
| action chunk | **16**（`num_video_frames=8 × video_action_freq_ratio=2`） | Pi0.5 `open_loop_horizon=15`，推理取前 15 步；保持 16 以兼容预训练 checkpoint |

### 2.2 相机设定

| 决策项 | 选择 | 理由 |
|---|---|---|
| 相机选择 | `observation.images.exterior_1_left` + `observation.images.wrist_left` | Pi0.5 client 用的就是这两路 |
| 拼接方式 | 可配置 `vertical`（默认）/ `horizontal` | WAM 是视频模型，需拼成单路；WAN VAE 对布局无先验 |
| 不使用的相机 | exterior_2_left / head / viewport | Pi0.5 评测不用 |
| 分辨率 | resize-pad 到 (384, 320) | 与 RoboTwin stage-2 一致 |

### 2.3 语言指令

| 决策项 | 选择 | 理由 |
|---|---|---|
| instruction 来源 | parquet `language_instruction` 字段 | DROID 原生标注 |
| WAN T5 嵌入 | UMT5-XXL on-the-fly 编码 + disk cache | 与 EgoDex 模式一致 |
| VLM 输入 | Qwen3-VL processor（text + first_frame） | 与 RoboTwin 一致 |

### 2.4 视频解码

| 决策项 | 选择 | 理由 |
|---|---|---|
| 解码器 | **PyAV**（`av` 库） | DROID 视频是 AV1 编码，decord 无法解码 |
| 帧定位 | timestamp → frame index（`round(from_timestamp * fps)`） | DROID 视频按 parquet file 拼接，episode 间共享 mp4 |

### 2.5 数据读取

| 决策项 | 选择 | 理由 |
|---|---|---|
| parquet 读取 | pandas + pyarrow | 无需 lerobot 运行时依赖 |
| episode 索引 | meta/episodes parquet → (data_file, video_file, from_timestamp) | LeRobot v3.0 结构 |
| 不依赖 lerobot 库 | 自包含实现 | lerobot 库重且未必可用 |

---

## 三、新增/修改文件一览

### 3.1 新增文件

| 文件路径 | 作用 |
|---|---|
| `data/droid/__init__.py` | 包导出 `DroidLeRobotDataset` |
| `data/droid/droid_lerobot_dataset.py` | DROID LeRobot 数据集主实现（读取、视频解码、T5/VLM 处理、采样） |
| `configs/droid_wan_vlm_mask_stage2_15w.yaml` | DROID 后训练配置文件 |
| `scripts/train_ADS_MotusV2_droid.sh` | DROID 训练启动脚本（torchrun + deepspeed） |
| `scripts/prepopulate_droid_t5_cache.py` | T5 语言嵌入缓存预生成脚本（多 worker 训练前运行） |

### 3.2 修改文件

| 文件路径 | 修改内容 |
|---|---|
| `data/dataset.py` | 新增 `_droid()` builder 函数；在 `DATASET_REGISTRY` 注册 `"droid"` 类型；`_copy_dataset_keys` 传入 DROID 专用参数 |
| `train/train_wan_vlm_mask.py` | `load_config()` 中新增 `elif dataset_type == 'droid'` 分支，派生 `action_dim=8, state_dim=8` |

---

## 四、代码修改详细记录

### 4.1 `data/droid/droid_lerobot_dataset.py`（新增，主文件）

**核心类**：`DroidLeRobotDataset(torch.utils.data.Dataset)`

**主要逻辑**：

1. **`__init__`**
   - 读取 `meta/info.json` 获取 fps（15Hz）
   - 调用 `_index_episodes()` 构建 episode 索引
   - 加载 Qwen3-VL processor（可选）
   - 配置 T5 encoder（disk_cache 模式，共享 singleton）

2. **`_index_episodes()`**
   - 遍历 `meta/episodes/chunk-XXX/*.parquet`
   - 每个 episode 记录：episode_index, length, data_chunk, data_file, ext_video, wrist_video, ext_start_frame, wrist_start_frame
   - **损坏文件过滤**：文件大小 < 1MB 的 mp4 标记为 corrupt，跳过对应 episode（DROID 有 4 个 ~3.5KB 占位符文件，影响 1635 个 episode）

3. **`_calculate_sampling_indices(total_frames)`**
   - 与 RoboTwin / LeRobotMotusDataset 完全一致的采样逻辑
   - `action_chunk_size = num_video_frames * video_action_freq_ratio = 16`
   - condition frame 随机采样，action/video indices 按步长推导

4. **`_decode_video_frames_pyav(video_path, frame_indices, fps)`**
   - PyAV 解码 AV1 视频
   - timestamp-based seek 到关键帧，前向解码收集目标帧
   - 返回 `[T, H, W, 3]` uint8 RGB

5. **`_decode_stacked_frames(video_path, start_frame, frame_offsets)`**
   - 解码单路相机的指定帧，resize-pad 到 video_size
   - 返回 `[T, C, H, W]` float32 [0,1]

6. **`_stitch_ext_wrist(ext_frames, wrist_frames)`**
   - 支持两种布局（`camera_layout` 参数）：
     - `vertical`：exterior 上 + wrist 下 → `[C, 2H, W]` → resize-pad
     - `horizontal`：exterior 左 + wrist 右 → `[C, H, 2W]` → resize-pad
   - 修复了 float32 输入被重复除以 255 的 bug

7. **`_get_t5_embedding(instruction)`**
   - disk_cache 模式：SHA1(instruction) 作为缓存 key
   - DataLoader worker 进程中不初始化 T5 encoder（CUDA fork 限制），cache miss 返回零向量
   - 主进程编码并写盘

8. **`__getitem__`**
   - 随机选 episode → 采样 indices → 读 parquet（state/action/instruction）→ 解码视频 → 拼接 → T5/VLM 处理
   - 返回样本契约：`first_frame`, `video_frames`, `initial_state`, `action_sequence`, `language_embedding`, `vlm_inputs`, `task_name`
   - 8 次 retry 机制（与 RoboTwin 一致）

9. **`_load_parquet_rows(data_chunk, data_file, episode_index)`**
   - LRU 缓存最近 8 个 parquet 文件
   - 按 episode_index 过滤行

**关键常量**：
```python
_CORRUPT_VIDEO_MIN_BYTES = 1 * 1024 * 1024  # 1 MB，过滤损坏 mp4
DROID_FPS = 15
ACTION_DIM = 8   # 7 joints + 1 gripper
STATE_DIM = 8
```

### 4.2 `data/dataset.py`（修改）

新增 `_droid` builder：
```python
def _droid(config: OmegaConf, val: bool):
    from .droid.droid_lerobot_dataset import DroidLeRobotDataset
    params = _common_params(config)
    _copy_dataset_keys(config, params, [
        "dataset_dir", "max_episodes", "instruction_field",
        "exterior_camera_key", "wrist_camera_key", "camera_layout",
        "t5_mode", "t5_cache_dir", "t5_text_len", "t5_device",
    ])
    params["image_aug"] = bool(config.dataset.get("image_aug", False)) and not val
    return DroidLeRobotDataset(**_finalize_params(config, params, val))
```

注册：
```python
DATASET_REGISTRY = {
    ...
    "lerobot": _lerobot,
    "droid": _droid,   # ← 新增
    ...
}
```

### 4.3 `train/train_wan_vlm_mask.py`（修改）

`load_config()` 新增 DROID action_dim 派生：
```python
elif dataset_type == 'droid':
    # DROID qpos action: 7 panda joints + 1 gripper (aligned with RoboLab Pi0.5)
    config.common.action_dim = 8
    config.common.state_dim = 8
```

### 4.4 `configs/droid_wan_vlm_mask_stage2_15w.yaml`（新增）

关键配置：
```yaml
common:
  action_dim: 8
  state_dim: 8
  num_video_frames: 8
  video_height: 384
  video_width: 320
  global_downsample_rate: 1    # DROID 15Hz
  video_action_freq_ratio: 2   # action_chunk_size = 16

dataset:
  type: "droid"
  dataset_dir: "/cache/wx1469573/data/droid1.0.1-lerobot"
  t5_mode: "disk_cache"
  t5_cache_dir: "/cache/wx1469573/data/droid1.0.1-lerobot/t5_cache"
  instruction_field: "language_instruction"
  exterior_camera_key: "observation.images.exterior_1_left"
  wrist_camera_key: "observation.images.wrist_left"
  camera_layout: "vertical"
  params:
    wan_path: "/cache/wx1469573/pretrained_models"
```

### 4.5 `scripts/train_ADS_MotusV2_droid.sh`（新增）

与 RoboTwin 脚本结构一致，指向 `configs/droid_wan_vlm_mask_stage2_15w.yaml`。

### 4.6 `scripts/prepopulate_droid_t5_cache.py`（新增）

遍历所有 parquet 中的 unique `language_instruction`，单进程编码 T5 嵌入并写盘。多 worker 训练前必须运行一次。

---

## 五、开发过程中的 Bug 修复

| Bug | 现象 | 修复 |
|---|---|---|
| `__getitem__` state 读取行有笔误 | `rows[self.instruction_field and True or "observation.state"]` 逻辑错误 | 改为 `cond_row = rows.iloc[cond_idx]; state = np.array(cond_row["observation.state"])` |
| `_stitch_ext_wrist` 像素值塌缩 | float32 [0,1] 输入被重复除以 255，输出范围 [0, 0.004] | 改为先 `clip(0,255).astype(uint8)` 再 resize_with_padding 再 `/255` |
| T5 encoder 在 worker 中初始化失败 | `Cannot re-initialize CUDA in forked subprocess` | worker 进程 cache miss 时返回零向量，主进程预生成缓存 |
| 损坏 mp4 文件导致 warning | 4 个 ~3.5KB 占位符 mp4（moov atom not found），影响 1635 episode | `_index_episodes` 中按文件大小 < 1MB 过滤 |
| PyAV 解码函数初始版本逻辑混乱 | `_decode_video_window_pyav` 帧索引映射错误 | 重写为 `_decode_video_frames_pyav`，按 pts→frame index 精确映射 |

---

## 六、环境依赖

### 6.1 原 motus 环境已有包（无需安装）

| 包 | 原环境版本 | 说明 |
|---|---|---|
| transformers | 5.0.0rc0 | Qwen3-VL processor |
| huggingface-hub | **1.4.1** | 已满足 `>=1.0.0` 要求，**无需升级** |
| av (PyAV) | 16.1.0 | AV1 视频解码 |
| decord | 0.6.0 | 其他数据集视频解码（DROID 不用） |
| pandas | 2.3.3 | parquet 读取（需配合 pyarrow） |
| torch / torchvision | 2.7.1 / 0.22.1 | 训练框架 |

### 6.2 集群恢复原环境后必须安装的包

**只需安装一个包**：

```bash
pip install "pyarrow==24.0.0"
```

| 包 | 必要性 | 原因 |
|---|---|---|
| **pyarrow** | **必须** | DROID 读 parquet 文件（pandas 引擎），原环境没有 |

### 6.3 不需要安装的包（开发时装了但 DROID 代码不依赖）

| 包 | 原因 |
|---|---|
| lerobot | DROID 代码自包含（用 pandas + PyAV 直读），未 import lerobot 库 |
| draccus | lerobot 的依赖，不需要 lerobot 就不需要 |
| datasets | lerobot 的依赖，同上 |
| huggingface-hub 升级 | 原环境 1.4.1 已满足 transformers 5.0.0rc0 的 `>=1.0.0` 要求 |

### 6.4 集群启动命令参考

```bash
echo "------------------- set envs -------------------"
envs_name=motus
python -c "import moxing as mox; mox.file.copy_parallel('obs://yw-2030-gy/external/wwx1484778/envs/motus.tar.gz','/cache/envs/$envs_name.tar.gz')"
mkdir -p /root/miniconda3/envs/$envs_name
tar -xf /cache/envs/$envs_name.tar.gz -C /root/miniconda3/envs
conda activate $envs_name

pip install "omegaconf==2.3.0"
pip install "pyarrow==24.0.0"   # ← DROID 训练唯一额外依赖
echo "---------------- set envs done ----------------"
```

---

## 七、已完成的自检

| 检查项 | 结果 |
|---|---|
| 数据集初始化（全量） | ✅ 95658 → 94023 episodes（过滤 1635 损坏） |
| `__getitem__` 单样本 shape | ✅ first_frame [3,384,320], video_frames [8,3,384,320], initial_state [8], action_sequence [16,8] |
| gripper 范围 | ✅ [0, 1]（0=open, 1=close） |
| joint 范围 | ✅ ~[-3, 4] rad |
| `collate_fn` batch | ✅ [B,16,8] action / [B,8] state / [B,512,4096] lang |
| Qwen3-VL processor | ✅ input_ids / pixel_values / image_grid_thw 正常 |
| UMT5-XXL T5 编码 | ✅ disk_cache 正常，非零嵌入 |
| `create_dataset(config)` | ✅ 配置驱动构建正常 |
| `load_config` action_dim | ✅ droid → action_dim=8, state_dim=8, chunk=16 |
| DataLoader num_workers=0 | ✅ T5 嵌入非零 |
| DataLoader num_workers=2 | ✅ 正常 collate（依赖 T5 预缓存） |
| camera_layout vertical | ✅ [3,384,320] range [0,1] |
| camera_layout horizontal | ✅ [3,384,320] range [0,1] |
| 损坏文件过滤 | ✅ 0 条 warning，50 次采样全部成功 |
| RoboTwin 配置向后兼容 | ✅ 仍为 action_dim=14 |
| 语法/导入检查 | ✅ 所有文件 ast.parse + import 通过 |

---

## 八、DROID 数据字段 → 模型输入映射

| 模型输入 | 数据来源 | shape | 语义 |
|---|---|---|---|
| `action_sequence` | parquet `action` | [16, 8] | 7 joints (rad) + 1 gripper [0,1]，absolute qpos |
| `initial_state` | parquet `observation.state` (cond frame) | [8] | 7 joints + 1 gripper (qpos) |
| `first_frame` | `exterior_1_left` + `wrist_left` 拼接 | [3, 384, 320] | condition frame |
| `video_frames` | 同上 | [8, 3, 384, 320] | target video frames |
| `language_embedding` | `language_instruction` → UMT5-XXL | [512, 4096] | WAN cross-attn |
| `vlm_inputs` | `language_instruction` + first_frame → Qwen3-VL | dict | MoT |
| `task_name` | `language_instruction` | str | 采样统计 |

---

## 九、训练-推理一致性核对

对照 `docs/RoboLab/260629_pi05_robolab_inference_config_for_training.md`：

| 检查项 | 状态 | 说明 |
|---|---|---|
| action = joint position / qpos | ✅ | 8-dim = 7 joints + 1 gripper |
| gripper 语义 0=open 1=close | ✅ | DROID 原生即此语义，无需翻转 |
| proprio = 7 joint + 1 gripper | ✅ | `observation.state` |
| camera = exterior_1_left + wrist_left | ✅ | 不使用 exterior_2 / head / viewport |
| language = task instruction | ✅ | `language_instruction` 字段 |
| 不使用 EEF pose | ✅ | 未使用 cartesian_position |
| action chunk horizon | ⚠️ | WAM 输出 16 步，Pi0.5 用 15 步（推理取前 15） |
| 训练无推理时不可见信息 | ✅ | condition frame 的 state/action 均来自当前及未来帧 |
| resize-with-pad 到目标分辨率 | ✅ | `resize_with_padding` 保持宽高比 |

---

## 十、运行方式

### 10.1 预生成 T5 缓存（多 worker 训练前必须运行一次）

```bash
python scripts/prepopulate_droid_t5_cache.py \
    --config configs/droid_wan_vlm_mask_stage2_15w.yaml \
    --max-episodes 0   # 0 = all episodes
```

### 10.2 启动训练

```bash
bash scripts/train_ADS_MotusV2_droid.sh
```

多节点：
```bash
WORLD_SIZE=<nodes> VC_WORKER_NUM=<nodes> VC_TASK_INDEX=<rank> \
    MASTER_ADDR=<addr> MASTER_PORT=<port> NPROC_PER_NODE=<gpus> \
    bash scripts/train_ADS_MotusV2_droid.sh
```

### 10.3 切换相机拼接布局

在 `configs/droid_wan_vlm_mask_stage2_15w.yaml` 中：
```yaml
dataset:
  camera_layout: "horizontal"   # 或 "vertical"（默认）
```

---

## 十一、待办 / 需人工确认事项

| 事项 | 说明 |
|---|---|
| T5 缓存预生成 | 多 worker 训练前必须运行 `prepopulate_droid_t5_cache.py`，否则 worker 进程 cache miss 返回零向量 |
| action chunk horizon | WAM 输出 16 步，Pi0.5 推理 `open_loop_horizon=15`，推理端需取前 15 步 |
| 相机拼接布局差异 | WAM 是单路拼接视频（exterior+wrist），Pi0.5 推理是两路独立 224×224 图像；这是 WAM 框架设定，非数据侧问题 |
| gripper 连续值 vs 二值化 | 训练用连续 [0,1]，推理时 RoboLab 对最后一维 `>0.5` 二值化，二者兼容 |
| 完整训练 dry-run | 未完成（需 GPU + deepspeed 环境），但 dataset/dataloader/config 层面 smoke test 全部通过 |
| `lerobot` 库依赖 | 已安装但 DROID dataset 实现未直接依赖（自包含 parquet+PyAV 读取）；若其他数据集需要则保留 |

---

## 十二、数据集统计

| 统计项 | 值 |
|---|---|
| 总 episode 数 | 95658（原始）→ 94023（过滤损坏后） |
| 过滤的损坏 episode | 1635（对应 4 个损坏 mp4） |
| 总帧数 | 27,630,375 |
| fps | 15 |
| action_dim | 8 (7 joints + 1 gripper) |
| gripper 范围 | [0.0, 1.0] (0=open, 1=close) |
| joint 范围 | ~[-3.0, 4.4] rad |
| 相机分辨率 | 180 × 320 (原始) → 384 × 320 (resize-pad) |
| 视频编码 | AV1 (yuv420p) |
| action chunk size | 16 (8 video frames × 2 freq ratio) |

# Session Log: OOM 修复与 Gradient Checkpointing

> 日期: 2025-06-25  
> 关联任务: 新训练配置 `cross_dataset_mixed_unified_eef_wrist16_xperience10m.yaml` 的 OOM 与 NaN 问题排查修复

---

## 一、问题背景

### 1.1 现象

- **旧配置** `pretrain_human_robot_mixed.yaml` 可在 4×140GB GPU 上以 `batch_size=16` 正常训练
- **新配置** `cross_dataset_mixed_unified_eef_wrist16_xperience10m.yaml` 在同样 4×140GB GPU 上，`batch_size=16` 时 OOM
- 降至 `batch_size=4` 可运行，但 Step 2 起出现 NaN loss（用户确认 NaN 是 total batch 太小导致，不需要修复）
- Step 1 可正常完成，Step 2 的 forward/backward 阶段 OOM（PyTorch 分配 ~136-138 GB，接近 140 GB 上限）

### 1.2 根因分析

| 原因 | 显存影响 | 说明 |
|------|---------|------|
| 3× T5-XXL 编码器实例 | ~18.7 GB 浪费 | VITRA、EgoDex、Xperience 各加载一份 UMT5-XXL (~9.4 GB/份)，实际完全相同 |
| 训练期间 T5 未释放 | ~9.4 GB | disk_cache 模式下 T5 只在初始化时用，训练时仍占显存 |
| 30 层 MoT 无 Gradient Checkpointing | ~28 GB | 30 层 transformer 中间激活值全部保留在显存中 |
| DeepSpeed ZeRO-1 bucket buffer | ~1 GB | backward 时 setup_buckets 分配额外的 reduce buffer |

**总计可节省: ~56 GB**，足以让 batch_size=16 在 4×140GB GPU 上运行。

---

## 二、关键决策

### 决策 1: T5 编码器全局单例

**方案**: 在 `data/__init__.py` 中创建全局 T5 单例，三个数据集共享同一实例。训练开始前释放。

**理由**: 
- 三个数据集加载的是同一个 checkpoint (`models_t5_umt5-xxl-enc-bf16.pth`)
- `t5_text_len=512`, `t5_device="cuda"` 在三个数据集中完全相同
- 单例模式保证只加载一份，节省 ~18.7 GB
- 训练前释放再省 ~9.4 GB

**不影响训练效果的原因**: T5 只在 `disk_cache` 模式的 dataset 初始化阶段使用（将文本 embedding 写入磁盘缓存），训练时直接读缓存文件，不需要 T5 模型。

### 决策 2: Gradient Checkpointing

**方案**: 在 MoT 30 层循环中使用 `torch.utils.checkpoint.checkpoint` 包裹每层计算，丢弃中间激活值，backward 时重算。

**理由**:
- 30 层 MoT 的中间激活值约 30 GB（QKV + attention weights + FFN intermediate per layer × 30）
- Gradient checkpointing 将激活值显存从 ~30 GB 降至 ~1.5 GB
- 省出 ~28 GB 显存

**代价**: 训练速度慢约 25-30%（每层 forward 需要计算两次）

**不影响训练效果的原因**: 
- Forward 计算完全相同 → 输出相同 → loss 相同
- Backward 从相同输入重算 → 梯度数学上完全等价
- 仅存在浮点非结合性带来的 ~1e-7 级别差异，可忽略

### 决策 3: NaN 不单独修复

**理由**: 用户确认 NaN 是 total batch size 太小导致的，增大 batch size 后自然解决，不需要额外代码修复。

---

## 三、待办事项

### 已完成 ✅

- [x] T5 全局单例实现 (`data/__init__.py`)
- [x] 三个数据集委托到全局单例
- [x] 训练代码中释放 T5 编码器
- [x] Gradient checkpointing 实现
- [x] 配置文件添加 `gradient_checkpointing: true`
- [x] NaN 检测代码（已添加但 NaN 问题确认不需要修复）

### 待验证 🔲

- [ ] 运行新脚本验证 batch_size=16 是否能正常训练
- [ ] 监控训练速度，评估 gradient checkpointing 的实际开销
- [ ] 多 GPU 训练验证（确认无 NCCL 问题）

### 后续优化（可选）💡

- [ ] 如有更大显存 GPU，可设 `gradient_checkpointing: false` 恢复全速
- [ ] 考虑将 `gradient_checkpointing` 设为默认 `True`（当前已如此）
- [ ] Action normalization / statistics 计算（unified_eef_camera_delta_wrist16 的 mean/std）
- [ ] EgoDex camera transform convention 确认
- [ ] Xperience video/mocap frame alignment 验证
- [ ] Inference integration test (anchor-based)
- [ ] Legacy dataset mask compatibility check

---

## 四、代码修改记录

### 4.1 `data/__init__.py` — 新建全局 T5 单例

**主要逻辑变更**:
- 新增 `get_global_t5_encoder(wan_path, t5_text_len, t5_device)` 函数：创建或复用 T5EncoderModel 单例
- 新增 `release_global_t5_encoder()` 函数：释放 T5 单例并清空 GPU 显存
- 使用 `(wan_path, t5_text_len, t5_device)` 三元组作为配置 key，配置变化时自动释放旧实例

### 4.2 `data/human/vitra_dataset.py` — T5 委托到全局单例

**主要逻辑变更**:
- 删除模块级 `_GLOBAL_T5_ENCODER` / `_GLOBAL_T5_CONFIG` 变量
- `_get_shared_t5_encoder()` 简化为直接调用 `get_global_t5_encoder()`
- 添加 `from data import get_global_t5_encoder` 导入

### 4.3 `data/egodex/egodex_dataset.py` — T5 委托到全局单例

**主要逻辑变更**:
- 删除模块级 `_SHARED_T5_ENCODER` / `_SHARED_T5_CONFIG` 变量
- `_get_shared_t5_encoder()` 简化为直接调用 `get_global_t5_encoder()`
- 添加 `from data import get_global_t5_encoder` 导入

### 4.4 `data/xperience/xperience_dataset.py` — T5 委托到全局单例

**主要逻辑变更**:
- 删除模块级 `_SHARED_T5_ENCODER` / `_SHARED_T5_CONFIG` 变量
- `_get_shared_t5_encoder()` 简化为直接调用 `get_global_t5_encoder()`
- 添加 `from data import get_global_t5_encoder` 导入

### 4.5 `models/motus_wan_vlm_direct_mask.py` — Gradient Checkpointing + NaN 检测

**主要逻辑变更**:

1. **`MotusWanVlmDirectMaskConfig`** 新增字段:
   - `gradient_checkpointing: bool = True` — 控制 MoT 层是否使用 gradient checkpointing

2. **新增 `_run_mot_layer()` 方法**:
   - 封装单层 MoT 计算：joint_attention → cross_attention → FFN (video + action + VLM)
   - 接收所有必要参数（tokens, adaln_params, t5_context, layer_idx, masks）
   - 设计为可被 `torch.utils.checkpoint.checkpoint` 包裹

3. **修改 `training_step()` 中的 MoT 循环**:
   - 新增 `use_grad_ckpt = self.config.gradient_checkpointing and self.training` 开关
   - 预提取 VLM masks（`_vlm_attn_mask`, `_vlm_asst_mask`），避免每层重复从 dict 取值
   - `use_grad_ckpt=True` 时，用 `torch.utils.checkpoint.checkpoint` 包裹 `_run_mot_layer`
   - `use_grad_ckpt=False` 时，保留原有内联计算逻辑
   - 简化 timing 统计（不再拆分为 wan/action/vlm 子项）

4. **NaN 检测代码**（已添加，NaN 问题确认不需要修复，但代码保留）:
   - VLM hidden states / video_tokens / action_tokens 的 NaN 检查
   - MoT 每层 before/after NaN 检查
   - Output head NaN 检查
   - 使用 `_nan_check_done` flag 确保只运行一次

### 4.6 `train/train_wan_vlm_mask.py` — 释放 T5 + 传递配置

**主要逻辑变更**:

1. **`accelerator.prepare()` 前释放 T5 编码器**:
   - 在 `accelerator.wait_for_everyone()` 之后、`accelerator.prepare()` 之前
   - 调用 `release_global_t5_encoder()` 释放 ~9.4 GB 显存
   - 用 try/except 包裹，释放失败不影响训练启动

2. **模型创建时传递 `gradient_checkpointing` 参数**:
   - `MotusWanVlmDirectMaskConfig` 构造时新增 `gradient_checkpointing=getattr(config.model, 'gradient_checkpointing', True)`
   - 默认值为 `True`（向后兼容旧配置文件）

3. **日志输出 gradient checkpointing 状态**:
   - 模型创建后立即 log `Gradient checkpointing: True/False`

### 4.7 `configs/motusv1_adapted/cross_dataset_mixed_unified_eef_wrist16_xperience10m.yaml` — 配置更新

**主要逻辑变更**:
- 新增 `model.gradient_checkpointing: true`

---

## 五、文件修改清单

| # | 文件路径 | 操作 | 主要变更 |
|---|---------|------|---------|
| 1 | `data/__init__.py` | 新建 | 全局 T5 单例 `get_global_t5_encoder()` + `release_global_t5_encoder()` |
| 2 | `data/human/vitra_dataset.py` | 修改 | 删除旧 `_GLOBAL_T5_*` 变量，`_get_shared_t5_encoder()` 委托到全局单例 |
| 3 | `data/egodex/egodex_dataset.py` | 修改 | 删除旧 `_SHARED_T5_*` 变量，`_get_shared_t5_encoder()` 委托到全局单例 |
| 4 | `data/xperience/xperience_dataset.py` | 修改 | 删除旧 `_SHARED_T5_*` 变量，`_get_shared_t5_encoder()` 委托到全局单例 |
| 5 | `models/motus_wan_vlm_direct_mask.py` | 修改 | 新增 `_run_mot_layer()` 方法；MoT 循环支持 gradient checkpointing；新增 `gradient_checkpointing` 配置字段；新增 NaN 检测代码 |
| 6 | `train/train_wan_vlm_mask.py` | 修改 | `accelerator.prepare()` 前释放 T5；传递 `gradient_checkpointing` 配置参数；log gradient checkpointing 状态 |
| 7 | `configs/motusv1_adapted/cross_dataset_mixed_unified_eef_wrist16_xperience10m.yaml` | 修改 | 新增 `gradient_checkpointing: true` |

---

## 六、显存节省估算

| 优化项 | 节省显存 | 原理 |
|--------|---------|------|
| T5 全局单例 | ~18.7 GB | 3 份 → 1 份（每份 ~9.4 GB） |
| 训练前释放 T5 | ~9.4 GB | disk_cache 模式下训练时不需要 T5 |
| Gradient Checkpointing | ~28 GB | 30 层激活值从 ~30 GB 降至 ~1.5 GB |
| **总计** | **~56 GB** | 140 GB - 56 GB = ~84 GB 可用 |

---

## 七、训练效果影响评估

| 改动 | 训练效果 | 训练速度 | 说明 |
|------|---------|---------|------|
| T5 全局单例 | ✅ 无影响 | ✅ 无影响 | 同一 checkpoint 加载，输出完全一致 |
| 释放 T5 | ✅ 无影响 | ✅ 无影响 | disk_cache 模式训练时不使用 T5 |
| Gradient Checkpointing | ✅ 无影响 | ⚠️ 慢 ~25-30% | 梯度数学等价，但每层 forward 需计算两次 |
| NaN 检测代码 | ✅ 无影响 | ✅ 无影响 | 只读检查，且只运行一次后关闭 |

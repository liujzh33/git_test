# Session Log: VLM Prompt Mode Fix for Inference-Training Distribution Shift

**Date:** 2026-06-22  
**Scope:** MotusV2 / RoboTwin_EE evaluation pipeline  
**Status:** ✅ Fix implemented, syntax verified, runtime Unicode error fixed

---

## 1. Problem Statement

Two RoboTwin training configurations with nearly identical training objectives produced a **34.3% gap** in evaluation success rate:

| Config | VLM Checkpoint | Motion Token Loss | Success Rate |
|--------|---------------|-------------------|-------------|
| `robotwin_eepos_WanVlmMask.yaml` (normal eepos) | Qwen3-VL-2B-Instruct (vocab 151936) | N/A | **76.6%** |
| `robotwin_eepos_WanVlmMask_motion_token_off.yaml` | Qwen3-VL-2B-Instruct-motion-token (vocab 154741) | disabled | **42.3%** |

Both configs train the same action prediction objective (16-dim eepos diffusion) without motion token loss. The motion_token_off config merely adds `motion_token_prediction.enabled=false` and uses an extended-vocab VLM. Yet performance drops drastically.

---

## 2. Root Cause Analysis

### 2.1 VLM Feature Distribution Shift

**The root cause is a training-inference prompt mismatch in the VLM branch.**

- **Training time:** When `motion_token_prediction.enabled=false`, training calls `preprocess_vlm_messages()` which builds a **simple prompt**:
  ```
  User: [image] {instruction}
  Assistant:   ← add_generation_prompt=True, no motion-token framing
  ```

- **Inference time:** `deploy_policy.py` **hardcoded** the motion-token prompt format for ALL evaluations via `_preprocess_vlm_messages_motion_prompt_only()`:
  ```
  User: [image] Task: {instruction}\nPredict the 3D wrist motion trajectories for both
        hands in the robot base coordinate system. Return only motion tokens.
  Assistant:   ← add_generation_prompt=True
  ```

This means models trained without motion tokens (both normal eepos and motion_token_off) receive a **completely different VLM prompt at inference** than what they saw during training.

### 2.2 Why This Matters — MoT Architecture

MotusV2 uses Mixture-of-Transformers (MoT) with asymmetric joint attention:
- **Video** self-attends only
- **Action** attends to Video + Action + VLM(prompt tokens)
- **VLM** uses causal self-attention

VLM features flow to the Action module via cross-attention. The VLM's `vlm_per_layer` features are blended with base features each layer via `(vlm_base + vlm_tokens) / 2`.

When the VLM sees the motion-token prompt at inference but was trained with simple prompts, its internal feature representations shift dramatically — the VLM forms "prepare to generate motion tokens" activation patterns that the Action module never encountered during training, degrading action prediction.

### 2.3 Extended Vocab VLM Amplifies the Problem

The `Qwen3-VL-2B-Instruct-motion-token` model (vocab 154741) has 2805 additional embedding rows (indices 151936–154740) for motion tokens. These are verified identical in shared weights to `Qwen3-VL-2B-Instruct` (max diff = 0.0), and tokenization produces identical token IDs for shared-vocab text.

However, the extended-vocab model's `embed_tokens` contains motion token rows that cause it to form "motion token preparation" feature patterns when seeing the motion-token prompt — patterns that are more pronounced than in the base model and that the Action module was never trained to handle.

### 2.4 Two Training Config Differences (Non-Root-Cause)

| Difference | normal eepos | motion_token_off |
|-----------|-------------|-----------------|
| VLM checkpoint | Qwen3-VL-2B-Instruct | Qwen3-VL-2B-Instruct-motion-token |
| warmup_steps | 200 | 1000 |
| validation_split | (none) | 0.02 |
| motion_token_prediction section | (none) | enabled=false, token_loss_weight=0.0 |

The warmup and validation_split differences are minor. The VLM checkpoint difference (shared weights identical) only matters insofar as it amplifies the motion-token prompt distribution shift.

---

## 3. Key Technical Details

### 3.1 MotusV2 Architecture (Trimodal UniDiffuser)
- **WAN 5B**: Video generation backbone
- **Qwen3-VL 2B**: VLM branch providing visual-language understanding features
- **Action Expert (DiT)**: Diffusion-based action prediction module
- Connected via asymmetric joint attention (Mixture-of-Transformers)

### 3.2 VLM Prompt Functions in `utils/vlm_utils.py`

| Function | Purpose | Prompt Format |
|----------|---------|--------------|
| `preprocess_vlm_messages()` | Training without motion tokens | `[image] {instruction}` + generation prompt |
| `preprocess_vlm_messages_with_motion_tokens()` | Training with motion tokens | `[image] Task: {instruction}\nPredict...` + assistant GT response |
| `preprocess_vlm_messages_motion_prompt_only()` | Inference with motion tokens | `[image] Task: {instruction}\nPredict...` + generation prompt |

### 3.3 Inference Data Flow

```
auto_eval_new.sh
  → script/eval_policy.py --vlm_path ...
    → deploy_policy.py get_model()
      → reads vlm_prompt_mode from paths_config.yml  ← NEW
      → MotusWanVlmDirectMaskPolicy(vlm_prompt_mode=...)
        → get_action()
          → dispatches to _preprocess_vlm_messages_motion_prompt_only()  [mode="motion_token"]
            or _preprocess_vlm_messages_simple()                         [mode="simple"]
```

---

## 4. Code Modification Records

### 4.1 `deploy_policy.py`

**File:** `/home/ma-user/work/wx1469573/RoboTwin_EE/policy/MotusWanVlmDirectMaskMotion/deploy_policy.py`

#### Change 1: `__init__` — Add `vlm_prompt_mode` parameter

```python
def __init__(self, checkpoint_path: str, config_path: str, wan_path: str, vlm_path: str,
             device: str = "cuda", log_dir: Optional[str] = None, task_name: Optional[str] = None,
             vlm_prompt_mode: str = "motion_token"):  # ← NEW parameter
```

- Default `"motion_token"` preserves backward compatibility
- Stored as `self.vlm_prompt_mode`
- Logged at init: `logger.info(f"VLM prompt mode: {self.vlm_prompt_mode}")`

#### Change 2: `get_action()` — Dispatch logic for prompt modes

```python
if self.vlm_prompt_mode == "motion_token":
    vlm_inputs = self._preprocess_vlm_messages_motion_prompt_only(
        self.current_instruction, first_frame_pil
    )
elif self.vlm_prompt_mode == "simple":
    vlm_inputs = self._preprocess_vlm_messages_simple(
        self.current_instruction, first_frame_pil
    )
else:
    raise ValueError(
        f"Unknown vlm_prompt_mode: {self.vlm_prompt_mode!r}. "
        f"Expected 'motion_token' or 'simple'."
    )
```

#### Change 3: New method `_preprocess_vlm_messages_simple()`

```python
def _preprocess_vlm_messages_simple(
    self, text_instruction: str, image_pil: Image.Image
) -> Dict[str, torch.Tensor]:
    messages = [
        {
            "role": "user",
            "content": [
                {"type": "image", "image": image_pil},
                {"type": "text", "text": text_instruction},
            ],
        }
    ]
    text = self.vlm_processor.apply_chat_template(
        messages, add_generation_prompt=True, tokenize=False
    )
    image_inputs, video_inputs = process_vision_info(messages)
    encoded = self.vlm_processor(
        text=[text], images=image_inputs, videos=video_inputs,
        padding=True, return_tensors="pt",
    )
    vlm_inputs = {
        'input_ids': encoded['input_ids'].to(self.device),
        'attention_mask': encoded['attention_mask'].to(self.device),
        'pixel_values': encoded['pixel_values'].to(self.device),
    }
    if 'image_grid_thw' in encoded and encoded['image_grid_thw'] is not None:
        vlm_inputs['image_grid_thw'] = encoded['image_grid_thw'].to(self.device)
    return vlm_inputs
```

**Key**: Matches training-time `preprocess_vlm_messages()` exactly — same content order (image → text), same `add_generation_prompt=True`, same encoding flow.

#### Change 4: `get_model()` — Read `vlm_prompt_mode` from config

```python
# Load vlm_prompt_mode from paths_config.yml
paths_config_path = policy_dir / "paths_config.yml"
vlm_prompt_mode = "motion_token"  # default: backward-compatible
if paths_config_path.exists():
    with open(paths_config_path, 'r', encoding='utf-8') as f:  # ← encoding='utf-8' added
        paths_config = yaml.safe_load(f)
    vlm_prompt_mode = paths_config.get('vlm_prompt_mode', 'motion_token')
    logger.info(f"Loaded vlm_prompt_mode from config: {vlm_prompt_mode}")

# ... passed to constructor:
policy = MotusWanVlmDirectMaskPolicy(
    ...
    vlm_prompt_mode=vlm_prompt_mode,
)
```

#### Change 5: Bug fix — `encoding='utf-8'` in file open

Originally `open(paths_config_path, 'r')` used system default encoding (ASCII on the eval server), causing `UnicodeDecodeError` when the YAML contained em-dash characters. Fixed by adding `encoding='utf-8'`.

---

### 4.2 `paths_config.yml`

**File:** `/home/ma-user/work/wx1469573/RoboTwin_EE/policy/MotusWanVlmDirectMaskMotion/paths_config.yml`

#### Change 1: Add `vlm_prompt_mode` field with documentation

```yaml
# ============================================================================
# VLM Prompt Mode
# ============================================================================
# Controls the prompt format used for VLM inference. Must match the training
# configuration to avoid VLM feature distribution shift.
#
# "motion_token" - Motion-token prompt format (default, backward-compatible):
#     "Task: {instruction}\nPredict the 3D wrist motion trajectories for both
#      hands in the robot base coordinate system. Return only motion tokens."
#     Use when the model was trained with motion-token VLM inputs
#     (motion_token_prediction.enabled=True, e.g. motion_token_on.yaml).
#
# "simple" - Simple instruction prompt (matches normal eepos training):
#     "{instruction}"
#     Use when the model was trained WITHOUT motion tokens
#     (e.g. robotwin_eepos_WanVlmMask.yaml or motion_token_off.yaml).
#     This avoids the VLM feature distribution shift caused by presenting
#     a motion-token prompt to a model that was never trained with one.
vlm_prompt_mode: "motion_token"
```

#### Change 2: Bug fix — Replace em-dash `—` with hyphen `-`

Two em-dash characters in comments caused `UnicodeDecodeError` when `yaml.safe_load()` read the file with ASCII default encoding. Replaced with plain ASCII hyphen `-`.

---

### 4.3 `auto_eval_new.sh`

**File:** `/home/ma-user/work/wx1469573/RoboTwin_EE/policy/MotusWanVlmDirectMaskMotion/auto_eval_new.sh`

#### Change 1: Parse `VLM_PROMPT_MODE` from config

```bash
VLM_PROMPT_MODE=$(parse_yaml_value "vlm_prompt_mode" "$CONFIG_FILE")
```

#### Change 2: Echo VLM Prompt Mode in evaluation configuration

```bash
echo "VLM Prompt Mode: ${VLM_PROMPT_MODE:-motion_token}"
```

#### Change 3: Include VLM Prompt Mode in evaluation summary

```bash
VLM Prompt Mode: ${VLM_PROMPT_MODE:-motion_token}
```

**Note:** `VLM_PROMPT_MODE` is parsed and displayed but NOT passed as a CLI arg to `eval_policy.py`. This is intentional — `deploy_policy.py` reads it directly from `paths_config.yml` in `get_model()`, making `paths_config.yml` the single source of truth.

---

## 5. Bugs Encountered and Fixed

### 5.1 Syntax Error After Method Insertion

After inserting `_preprocess_vlm_messages_simple()`, the `return vlm_inputs` of the new method got merged with the `_create_frame_grid()` definition, producing:

```python
return vlm_inputs(self, condition_frame:  # ← malformed
```

**Fix:** Properly separated the two methods with correct indentation and blank line.

**Verification:** `python3 -c "import ast; ast.parse(open('deploy_policy.py').read())"` — passed.

### 5.2 UnicodeDecodeError at Runtime

```
UnicodeDecodeError: 'ascii' codec can't decode byte 0xe2 in position 1189: ordinal not in range(128)
```

**Cause:** `paths_config.yml` contained em-dash `—` characters in comments. `yaml.safe_load()` used default ASCII encoding.

**Fix (two-pronged):**
1. Replace `—` with `-` in `paths_config.yml` (eliminates non-ASCII source)
2. Add `encoding='utf-8'` to `open()` in `deploy_policy.py` (prevents future recurrence)

---

## 6. Important Conclusions

1. **VLM prompt format must match between training and inference.** The MoT architecture makes the Action module highly sensitive to VLM feature distributions. Even small prompt changes can cause large performance drops (34% in this case).

2. **Extended-vocab VLM is not inherently harmful.** The `Qwen3-VL-2B-Instruct-motion-token` model has identical shared weights with `Qwen3-VL-2B-Instruct`. The extra embedding rows are never accessed when motion tokens are not in the input text. The performance drop was caused by the prompt mismatch, not the extended vocab.

3. **The motion_token_off config should use `Qwen3-VL-2B-Instruct`** instead of `Qwen3-VL-2B-Instruct-motion-token`. While the extended vocab itself doesn't hurt (shared weights identical), using the base model eliminates any subtle interaction with the motion-token prompt format and is the cleaner choice when motion token prediction is disabled.

4. **`vlm_prompt_mode: "simple"` is the correct setting** for models trained with `robotwin_eepos_WanVlmMask.yaml` or `robotwin_eepos_WanVlmMask_motion_token_off.yaml`.

---

## 7. Todo / Next Steps

- [ ] **Re-evaluate the motion_token_off checkpoint** with `vlm_prompt_mode: "simple"` in `paths_config.yml` to verify the fix closes the 34% gap
- [ ] **Re-evaluate the normal eepos checkpoint** with `vlm_prompt_mode: "simple"` to confirm it still achieves ~76.6%
- [ ] **Update `robotwin_eepos_WanVlmMask_motion_token_off.yaml`** to use `vlm_checkpoint_path: Qwen3-VL-2B-Instruct` instead of `Qwen3-VL-2B-Instruct-motion-token` (recommended but not strictly necessary)
- [ ] **Create documentation** for future training configs: always match the VLM prompt format between training and inference
- [ ] **Consider adding a runtime assertion** in `deploy_policy.py` that logs a warning if `vlm_prompt_mode="motion_token"` is used with a VLM path that doesn't contain "motion-token" in its name (or vice versa), as a sanity check

---

## 8. Reference: Evaluation Results

### Normal eepos (76.6% average, 50 tasks)
- Top performers: adjust_bottle, grab_roller, press_stapler, shake_bottle, shake_bottle_horizontally (100%)
- Weakest: hanging_mug (25%), handover_block (43%), put_object_cabinet (40%), put_bottles_dustbin (49%)

### Motion token off (42.3% average, same 50 tasks)
- Evaluated with the incorrect motion-token prompt format (the bug that this fix addresses)
- Re-evaluation with `vlm_prompt_mode: "simple"` expected to recover performance closer to 76.6%

---

## 9. Related Prior Session Logs

- `docs/session_log_20260612_motion_token_eval_analysis.md` — Initial analysis of motion token evaluation
- `docs/session_log_20260615_motion_token_train_eval_consistency_analysis.md` — Detailed train-eval consistency analysis identifying VLM distribution shift

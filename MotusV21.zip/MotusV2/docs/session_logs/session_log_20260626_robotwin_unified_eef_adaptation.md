# RoboTwin Unified EEF Camera-Delta Wrist16 适配记录

> 日期：2026-06-26
> 目标：将 RoboTwin 数据集从 eepos 模式适配到 `unified_eef_camera_delta_wrist16` 统一动作表示，同时包含夹爪开合信息

---

## 1. 背景与动机

### 1.1 旧 eepos 模式

RoboTwin 旧配置使用 `action_mode: "eepos"`，布局为：

```
[left_xyz(3), left_quat_wxyz(4), left_gripper(1), right_xyz(3), right_quat_wxyz(4), right_gripper(1)] = 16D
```

- 绝对 EEF 位姿（xyz + quaternion）在世界坐标系下
- 夹爪状态在 dim 7 和 dim 15
- 无 `action_valid_mask`（所有维度均参与 loss）

### 1.2 新统一模式

适配后的 `unified_eef_camera_delta_wrist16` 布局为：

```
[left_delta_xyz_cam(3), left_delta_rotvec_cam(3), left_gripper(1), 0,
 right_delta_xyz_cam(3), right_delta_rotvec_cam(3), right_gripper(1), 0] = 16D
```

与人类数据的关键区别：
- **旋转表示**：rotation vector (axis-angle) 代替 quaternion
- **坐标系**：camera-frame delta 代替 world-frame 绝对坐标
- **夹爪位置**：dim 6 和 dim 14（人类数据中这些是 reserved=0）
- **保留维度**：dim 7 和 dim 15（人类数据中是 dim 6:8 和 dim 14:16）

### 1.3 适配意义

- **跨域统一**：RoboTwin、VITRA、EgoDex、Xperience 共享相同的动作表示语义
- **夹爪信息保留**：机器人夹爪开合是有意义的动作信号，不应丢弃
- **锚点式 delta**：推理时每个 action 可独立从 `initial_state` 出发应用

### 1.4 RoboTwin eepos 数据格式

原始 eepos `.pt` 文件每帧 16D：

```
[left_xyz(3), left_quat_wxyz(4), left_gripper(1), right_xyz(3), right_quat_wxyz(4), right_gripper(1)]
```

- xyz：世界坐标系（机器人基座坐标系）下的绝对位置，单位米
- quat_wxyz：世界坐标系下的绝对旋转（WXYZ 顺序，scalar first）
- gripper：归一化到 [0, 1]（0=闭合，1=张开），连续值
- 数据来源：SAPIEN 仿真器中 `robot.get_left_ee_pose()` / `get_right_ee_pose()`

---

## 2. RoboTwin 相机外参

### 2.1 相机配置来源

RoboTwin 使用固定头部相机（head_camera），配置在 `/cache/wx1469573/RoboTwin/assets/embodiments/aloha-agilex/config.yml`：

```yaml
static_camera_list:
- name: head_camera
  type: D435
  position: [-0.032, -0.45, 1.35]
  forward: [0, 0.6, -0.8]
  left: [-1, 0, 0]
```

### 2.2 相机外参验证（从原始 HDF5 数据）

检查 `/cache/wx1469573/data/aloha-agilex_clean_50/data/episode*.hdf5` 中的 `observation/head_camera/extrinsic_cv`：

| 检查项 | 结果 |
|--------|------|
| 单 episode 内帧间差异（475 帧） | **0.0**（完全不变） |
| 50 个 episode 间差异 | **0.0**（完全不变） |

原因：`random_head_camera_dis=0`（clean 和 randomized 数据均如此），头部相机在所有 episode 的所有帧中位置和朝向完全固定。

### 2.3 相机坐标系约定与 Bug 修复

**⚠️ 重要 Bug 修复**：初始实现中从 `config.yml` 的 `forward/left/up` 直接列堆叠构建 `R_w_c`，结果**错误**。

**错误原因**：`config.yml` 中的 `forward/left/up` 是语义方向。SAPIEN 的 `camera.entity.set_pose()` 用 `[forward, left, up]` 作为 entity pose 的列向量，但 `get_extrinsic_matrix()` 返回的是 **OpenCV convention**（x=right, y=down, z=forward）。正确的转换：

```
R_w_c (OpenCV) = [right, down, forward] = [-left, -up, forward]
```

而不是直接用 `[forward, left, up]`。

**正确值**（从 HDF5 `extrinsic_cv` 验证）：

```
HDF5 extrinsic_cv (world-to-camera, OpenCV):
  R_w2c = [[1,  0,    0  ],
           [0, -0.8, -0.6],
           [0,  0.6, -0.8]]
  t_w2c = [0.032, 0.45, 1.35]

正确的 R_w_c = R_w2c^T:
  R_w_c = [[1,  0,    0  ],
           [0, -0.8,  0.6],
           [0, -0.6, -0.8]]
  t_w_c = [-0.032, -0.45, 1.35]

错误的 R_w_c (已修复):
  R_w_c = [[0,  -1,   0  ],
           [0.6, 0,   0.8],
           [-0.8, 0,   0.6]]
```

**影响**：
- `t_w_c` 相同（位置正确）
- `R_w_c` 错误 → camera-frame 下的 xyz 和 rotvec 方向全部错误
- state 绝对位置错误（三分量被重新排列+符号翻转）
- delta action 旋转分量错误

**验证**：修复后的 `R_w_c` 与 HDF5 `extrinsic_cv` 直接转换结果一致（差异 0.0）。

### 2.4 预处理数据中不含相机外参

`/cache/wx1469573/data/RoboTwin_emb_ee/` 预处理数据只有 `eepos/`、`qpos/`、`videos/`、`umt5_wan/`、`metas/` 五个目录，**没有相机外参文件**。原始 pkl/hdf5 中的逐帧 `extrinsic_cv` 在预处理时被丢弃。但由于相机外参固定不变，硬编码是合理的。

---

## 3. 关键设计决策

### 决策 1：夹爪放置在 dim 6 和 dim 14

人类数据中 dim 6:8 和 dim 14:16 是 reserved（恒零，不参与 loss）。机器人数据有有意义的夹爪值（0=闭合，1=张开），放在 dim 6 和 dim 14。

**Mask 对比：**

| 数据集 | 有效维度 | 保留维度 |
|--------|---------|---------|
| 人类 (VITRA/EgoDex/Xperience) | [0:6] ∪ [8:14] (12D) | [6:8] ∪ [14:16] (4D) |
| 机器人 (RoboTwin) | [0:7] ∪ [8:15] (14D) | [7] ∪ [15] (2D) |

### 决策 2：夹爪值为 target 帧的绝对值

与 pose delta（锚点式）不同，夹爪值直接存储目标帧的绝对值（0 或 1 或中间值），而非 delta。原因：
- 夹爪值已归一化到 [0, 1]，直接存储更有意义
- 推理时直接输出目标夹爪状态，无需从初始状态做增量

### 决策 3：读取 eepos 数据转换为 unified delta

`action_mode="unified_eef_camera_delta_wrist16"` 仍然从 `eepos/` 目录读取原始绝对位姿数据，然后在 `_extract_unified_eef_action_state()` 中在线转换为 camera-frame delta。原始 eepos 数据不被修改。

### 决策 4：episode_data key 使用 'eepos_path'

由于原始数据来自 eepos 目录，`_scan_task_folder` 中的 `episode_data` 键名统一为 `eepos_path`（而非 `unified_eef_camera_delta_wrist16_path`）。

### 决策 5：相机外参硬编码

由于 `random_head_camera_dis=0`，相机外参在所有 episode 中完全固定，因此硬编码为类常量。正确值从 HDF5 `extrinsic_cv` 验证获得。

### 决策 6：锚点式 delta 语义

action[i] = delta(pose[0] → pose[i+1])，所有 action 共享同一个 anchor 帧（frame 0，即 `initial_state` 对应的帧）。推理时每个 action 可独立从 `initial_state` 出发应用，无需逐步积分。这与人类数据（VITRA/EgoDex/Xperience）的 unified EEF 语义一致。

---

## 4. 代码修改记录

### 4.1 `data/human/unified_eef_action.py`

**新增常量：**

```python
UNIFIED_EEF_ROBOT_EFFECTIVE_INDICES = list(range(7)) + list(range(8, 15))
UNIFIED_EEF_ROBOT_RESERVED_INDICES = [7, 15]
```

**新增函数（6个，均在文件末尾）：**

| 函数 | 功能 |
|------|------|
| `compute_camera_delta_action_with_gripper()` | 单臂 camera-frame delta + gripper，dim 6=gripper, dim 7=0 |
| `compute_unified_eef_action_16d_with_gripper()` | 16D 双臂动作 + gripper，mask 覆盖 [0:7]∪[8:15] |
| `compute_unified_eef_state_16d_with_gripper()` | 16D 双臂状态 + gripper |
| `compute_unified_eef_action_sequence_with_gripper()` | 批量锚点式动作序列 + gripper |
| `compute_unified_eef_state_from_poses_with_gripper()` | 单帧状态 + gripper |

**关键差异**（与人类数据版本的对比）：

| 函数 | 人类版本 | 机器人版本 |
|------|---------|-----------|
| per-arm dim 6 | 0 (reserved) | gripper 值 |
| per-arm dim 7 | 0 (reserved) | 0 (reserved) |
| mask [0:6] | 1 (有效) | 1 (有效) |
| mask [6] | 0 (reserved) | 1 (gripper 有效) |
| mask [7] | 0 (reserved) | 0 (reserved) |

### 4.2 `data/robotwin2/robotwin_agilex_dataset.py`

**变更 1：新增 unified_eef_action 导入**

```python
from data.human.unified_eef_action import (
    build_hand_world_poses_from_xyzquat,
    compute_unified_eef_action_sequence_with_gripper,
    compute_unified_eef_state_from_poses_with_gripper,
    UNIFIED_EEF_ACTION_DIM, UNIFIED_EEF_STATE_DIM,
)
```

**变更 2：扩展 action_mode 白名单**

```python
# 旧
assert action_mode in ["qpos", "eepos"], ...
# 新
valid_modes = ["qpos", "eepos", "unified_eef_camera_delta_wrist16"]
if action_mode not in valid_modes:
    raise ValueError(...)
```

**变更 3：`_scan_task_folder()` — 统一 action_path_key**

```python
# 新增逻辑：unified_eef 模式下，原始数据来自 eepos 目录
if self.action_mode in ("qpos", "eepos"):
    action_path_key = f'{self.action_mode}_path'
else:
    action_path_key = f'{action_dir_name}_path'  # 'eepos_path'
```

episode_data 字典中的键从 `f'{self.action_mode}_path'` 改为 `action_path_key`（两处：OBS 模式和本地模式）。

**变更 4：`_apply_train_val_split()` — 修复 key 查找**

```python
# 旧
ep.get(f"{self.action_mode}_path", "")
# 新
ep.get("eepos_path", ep.get("qpos_path", ""))
```

三处排序/去重 key 查找全部修复。

**变更 5：新增 `_load_raw_eepos()` 方法**

加载原始 eepos `.pt` 文件（支持 OBS 模式），返回 float32 tensor。

**变更 6：新增 `_get_head_camera_extrinsics()` 方法 + 类常量**

```python
_HEAD_CAMERA_R_W_C = np.array([
    [ 1.0,  0.0,  0.0],
    [ 0.0, -0.8,  0.6],
    [ 0.0, -0.6, -0.8],
], dtype=np.float64)
_HEAD_CAMERA_T_W_C = np.array([-0.032, -0.45, 1.35], dtype=np.float64)
```

**⚠️ Bug 修复**：初始版本使用错误的 `R_w_c`（从 config.yml forward/left/up 直接列堆叠），已修正为从 HDF5 `extrinsic_cv` 验证的正确值（OpenCV convention）。

**变更 7：新增 `_extract_unified_eef_action_state()` 方法（~60 行）**

核心转换逻辑：
1. 从 eepos 数据提取 `left_xyz`, `left_quat`, `left_grip`, `right_xyz`, `right_quat`, `right_grip`
2. 通过 `build_hand_world_poses_from_xyzquat()` 构建 world-frame 旋转矩阵
3. 构建 `[anchor] + action_indices` 的帧序列
4. 调用 `compute_unified_eef_action_sequence_with_gripper()` 计算锚点式动作序列
5. 调用 `compute_unified_eef_state_from_poses_with_gripper()` 计算锚点帧状态
6. 返回 `(initial_state, action_sequence, action_valid_mask, None)`

**变更 8：`__getitem__()` — 新增 unified_eef 分支**

```python
if self.action_mode == "unified_eef_camera_delta_wrist16":
    eepos_data = self._load_raw_eepos(episode_data['eepos_path'])
    initial_state, action_sequence, action_valid_mask, _ = \
        self._extract_unified_eef_action_state(eepos_data, condition_frame_idx, action_indices)
else:
    # 原始 qpos/eepos 路径不变
```

返回字典新增 `action_valid_mask`（仅 unified_eef 模式）。

**变更 9：`MinMaxNormalizer.from_stats_file()` — 新增 unified_eef 分支**

支持 `unified_eef_min` / `unified_eef_max` 统计量键名。

**变更 10：inferred_split 路径查找修复**

```python
# 旧
for key in (action_path_key, 'video_path', 'lang_path'):
# 新
for key in ('eepos_path', 'qpos_path', 'video_path', 'lang_path'):
```

### 4.3 `train/train_wan_vlm_mask.py`

**变更 1：robotwin 分支新增 unified_eef action_dim 处理**

```python
if dataset_type == 'robotwin':
    robot_action_mode = config.dataset.get('action_mode', 'qpos')
    if robot_action_mode == 'unified_eef_camera_delta_wrist16':
        dim = 16
    elif robot_action_mode == 'eepos':
        dim = 16
    else:
        dim = config.common.get('action_dim', 14)
```

**变更 2：首批 debug 统计增强**

- 机器人数据 reserved dims 为 [7] 和 [15]（非人类数据的 [6:8] 和 [14:16]）
- 新增 left/right gripper range/mean 统计日志

```python
if dataset_type == 'robotwin':
    reserved = np.concatenate([_act_np[:, :, 7:8], _act_np[:, :, 15:16]], axis=-1)
    # + gripper 统计日志
else:
    reserved = np.concatenate([_act_np[:, :, 6:8], _act_np[:, :, 14:16]], axis=-1)
```

### 4.4 新增文件

| 文件 | 作用 |
|------|------|
| `configs/robotwin_unified_eef_WanVlmMask.yaml` | RoboTwin unified EEF 训练配置，`action_mode: "unified_eef_camera_delta_wrist16"`，`gradient_checkpointing: true` |
| `scripts/train_ADS_MotusV2_robotwin_unified_eef.sh` | 训练启动脚本，默认 4 GPU |

---

## 5. 验证结果

### 5.1 单元测试

| 测试 | 结果 |
|------|------|
| gripper placement in 8D action | ✅ dim 6=gripper, dim 7=0 |
| 16D action with gripper mask | ✅ mask[0:7]=1, mask[7]=0, mask[8:15]=1, mask[15]=0 |
| state with gripper | ✅ dim 6/14 存储 gripper 绝对值 |
| invalid hand with gripper mask | ✅ 无效手的 mask 全 0 |
| robot effective indices | ✅ [0:7]∪[8:15], reserved=[7,15] |
| sequence with gripper | ✅ 锚点式，gripper 为 target 帧值 |
| 原有 13 项 unified EEF 测试 | ✅ 全部通过（无回归） |

### 5.2 集成测试

| 测试 | 结果 |
|------|------|
| RoboTwin 单集采样 (unified_eef) | ✅ 10/10 samples, 无 NaN/Inf |
| reserved dims [7,15] = 0 | ✅ |
| mask dim 6/14 = 1 (gripper) | ✅ |
| mask dim 7/15 = 0 (reserved) | ✅ |
| gripper value range [0, 1] | ✅ |
| collate_fn batch 处理 | ✅ mask shape (B, T, 16) |
| eepos 模式向后兼容 | ✅ 无 action_valid_mask, action shape (T, 16) |
| qpos 模式向后兼容 | ✅ action shape (T, 14) |

### 5.3 数据质量检查（修复相机外参后）

```
Left EEF world:  [-0.298, -0.314, 0.942]
Left EEF camera: [-0.266, 0.136, 0.408]   ← 与 HDF5 extrinsic_cv 直接验证一致
Right EEF world: [0.306, -0.313, 0.941]
Right EEF camera: [0.338, 0.136, 0.410]

Delta xyz norm range: [0.054, 0.319]
Delta rotvec norm range: [0.381, 1.225]  (≤ π ✓)
Left gripper: [0.0, 1.0] (闭合→张开)
Right gripper: [0.0, 1.0]
```

### 5.4 相机外参验证

| 验证项 | 结果 |
|--------|------|
| HDF5 extrinsic_cv 帧间差异 | 0.0（475 帧完全不变） |
| HDF5 extrinsic_cv episode 间差异 | 0.0（50 episode 完全不变） |
| 硬编码 R_w_c 与 HDF5 一致性 | ✅ 差异 0.0（修复后） |
| EEF camera coords 与 extrinsic_cv 直接验证 | ✅ 一致 |

---

## 6. 运行方式

### 新训练启动

```bash
cd /home/ma-user/work/wx1469573/MotusV2
bash scripts/train_ADS_MotusV2_robotwin_unified_eef.sh
```

### 旧训练启动（不受影响）

```bash
bash scripts/train_ADS_MotusV2_robotwin_eepos.sh
```

### 配置文件

```yaml
# configs/robotwin_unified_eef_WanVlmMask.yaml
dataset:
  type: "robotwin"
  action_mode: "unified_eef_camera_delta_wrist16"
  # ... 其他参数与 eepos 配置一致
model:
  gradient_checkpointing: true  # 节省显存
```

---

## 7. 修改文件汇总

| # | 文件路径 | 修改类型 | 主要变更 |
|---|---------|---------|---------|
| 1 | `data/human/unified_eef_action.py` | 修改 | 新增 robot 常量（`UNIFIED_EEF_ROBOT_EFFECTIVE_INDICES` 等）和 6 个 gripper 变体函数 |
| 2 | `data/robotwin2/robotwin_agilex_dataset.py` | 修改 | 支持 `unified_eef_camera_delta_wrist16` action_mode；新增 `_extract_unified_eef_action_state()`、`_load_raw_eepos()`、`_get_head_camera_extrinsics()` 等方法；修复 `_scan_task_folder` key 名；**修复相机外参 R_w_c（Bug fix）** |
| 3 | `train/train_wan_vlm_mask.py` | 修改 | robotwin 分支支持 unified_eef action_dim；首批 debug 统计适配机器人 gripper 维度 |
| 4 | `configs/robotwin_unified_eef_WanVlmMask.yaml` | 新增 | RoboTwin unified EEF 训练配置 |
| 5 | `scripts/train_ADS_MotusV2_robotwin_unified_eef.sh` | 新增 | 训练启动脚本 |

---

## 8. 待办事项

### 高优先级

- [x] **推理集成测试**：验证从 unified delta action 还原 EEF 位姿用于机器人控制 ✅（见第 10 节）
  - 在 `RoboTwin_EE/policy/MotusWanVlmDirectMaskUnifiedEE/deploy_policy.py` 中新增 unified delta → 绝对位姿的逆变换
  - 逆变换公式：`R_e_e_star = R_c_e^T @ R_delta_c @ R_c_e`，`t_e_e_star = R_c_e^T @ t_delta_c`，`R_w_e_star = R_w_e @ R_e_e_star`，`t_w_e_star = t_w_e + R_w_e @ t_e_e_star`
  - 夹爪直接使用预测值
  - Round-trip 测试通过（pos err ~6e-8, rot err ~1e-7）
- [ ] **Action normalization 统计量**：为 `unified_eef_camera_delta_wrist16` 在 RoboTwin 上计算 mean/std/min/max，仅覆盖有效维度 [0:7]∪[8:15]，排除 reserved [7,15]
- [ ] **多 GPU 训练验证**：实际启动训练确认无报错，loss 正常下降

### 中优先级

- [ ] **Random camera displacement 处理**：当 `random_head_camera_dis > 0` 时，相机位置随机偏移，需要从原始 HDF5 数据中读取实际相机外参（预处理数据中已丢弃）
- [ ] **混合数据集训练**：验证 RoboTwin + 人类数据（VITRA/EgoDex/Xperience）混合训练的 collate 兼容性
  - 人类数据 mask 有效维度 [0:6]∪[8:14]，机器人数据 [0:7]∪[8:15]
  - 模型 loss 计算已支持 per-dim mask，理论上兼容
- [ ] **Wrist camera 支持**：当前仅使用 head_camera，未来可支持 wrist camera 视角（需从 wrist_camera extrinsic 读取外参）

### 低优先级

- [ ] **生成 unified_eef stats 脚本**：类似 `scripts/generate_eepos_stats.py`，计算 RoboTwin unified EEF 的归一化统计量
- [ ] **其他 embodiment 支持**：当前硬编码 aloha-agilex 的 head camera 外参，如需支持 piper/franka-panda 等其他机器人，需从对应 config.yml 或 HDF5 读取外参

---

## 9. 关键技术细节

### 9.1 相机外参推导链

```
config.yml (forward/left/up)
  → SAPIEN camera.entity.set_pose([forward, left, up] as columns)
    → get_extrinsic_matrix() returns OpenCV convention
      → HDF5 observation/head_camera/extrinsic_cv
        → R_w2c = extrinsic_cv[:3, :3]
        → t_w2c = extrinsic_cv[:3, 3]
          → R_w_c = R_w2c^T
          → t_w_c = -R_w_c @ t_w2c
```

### 9.2 动作语义

```
state (initial_state) = anchor 帧 (frame 0) 的 EEF 位姿在 camera frame 下的表示
  - xyz_cam = R_w_c^T @ (t_w_e - t_w_c)
  - rotvec_cam = log(R_w_c^T @ R_w_e)
  - gripper = anchor 帧的绝对值

action[i] = delta(pose[0] → pose[i+1])  (锚点式)
  - delta_xyz_cam = R_c_e @ R_w_e[0]^T @ (t_w_e[i+1] - t_w_e[0])
  - delta_rotvec_cam = log(R_delta_c)  where R_delta_c = R_c_e @ R_w_e[0]^T @ R_w_e[i+1] @ R_w_e[0] @ R_c_e^T
  - gripper = target 帧 (i+1) 的绝对值
```

### 9.3 RoboTwin eepos 坐标系

- eepos 中的 xyz 和 quat 在**世界坐标系（机器人基座坐标系）**下
- 来源：`robot.get_left_ee_pose()` → `_trans_endpose()` → SAPIEN `ee_pose.global_pose`
- `global_trans_matrix = [[1,0,0],[0,-1,0],[0,0,-1]]` 对旋转做了 y/z 翻转
- eepos quaternion 是 WXYZ 顺序（scalar first），已验证 norm ≈ 1

### 9.4 与人类数据的兼容性

| 特性 | 人类数据 (VITRA/EgoDex/Xperience) | 机器人数据 (RoboTwin) |
|------|----------------------------------|----------------------|
| 有效维度 | [0:6]∪[8:14] (12D) | [0:7]∪[8:15] (14D) |
| 保留维度 | [6:8]∪[14:16] (4D) | [7]∪[15] (2D) |
| dim 6/14 含义 | reserved (0) | gripper (0-1) |
| dim 7/15 含义 | reserved (0) | reserved (0) |
| 相机外参来源 | 每帧/每 episode 不同 | 固定（硬编码） |
| 双手有效性 | 可能缺手 | 始终有效 |
| action_valid_mask | per-dim, 可能有 0 | per-dim, [0:7]∪[8:15]=1 |

---

## 10. 推理适配（训推一致）

> 日期：2026-06-26（续）
> 目标：将推理 policy 适配到 `unified_eef_camera_delta_wrist16` 统一设定，实现训推一致

### 10.1 推理代码位置

```
/home/ma-user/work/wx1469573/RoboTwin_EE/policy/MotusWanVlmDirectMaskUnifiedEE/
├── deploy_policy.py          # 修改：新增 unified EEF 转换逻辑
└── paths_config.yml          # 修改：action_mode 配置项文档化
```

### 10.2 设计原则：最小侵入

- **不修改模型代码**：模型输入/输出格式不变（state 16D, action 16D）
- **不修改环境接口**：`take_action(action_type='ee')` 仍接收 16D 绝对 eepos
- **边界转换**：在 `update_obs` 和 `get_action` 边界做 absolute eepos ↔ unified delta 的转换
- **向后兼容**：`action_mode: "eepos"` 时行为与原版完全一致

### 10.3 数据流

```
                    ┌─────────────────────────────────────────┐
                    │           update_obs(obs)               │
                    │                                         │
环境绝对 eepos ────► │  robot.get_left_ee_pose()  (xyz,quat)   │
[xyz, quat, grip]   │  robot.get_right_ee_pose() (xyz,quat)   │
                    │         │                               │
                    │         ▼                               │
                    │  current_eepos_state (16D, float64)     │
                    │         │                               │
                    │  ┌──────┴──────┐                        │
                    │  │ eepos mode  │ unified_eef mode       │
                    │  │ state=eepos │ state=_build_unified_  │
                    │  │             │   eef_state(eepos)     │
                    │  └─────────────┘                        │
                    └─────────────────────────────────────────┘
                                │
                                ▼
                    ┌─────────────────────────────────────────┐
                    │         model.inference_step()           │
                    │   state(16D) → predicted_actions(T,16D)  │
                    └─────────────────────────────────────────┘
                                │
                                ▼
                    ┌─────────────────────────────────────────┐
                    │           get_action()                  │
                    │         │                               │
                    │  ┌──────┴──────┐                        │
                    │  │ eepos mode  │ unified_eef mode       │
                    │  │ 直接返回    │ _unified_delta_to_     │
                    │  │             │   eepos_actions(       │
                    │  │             │     delta, anchor)     │
                    │  └─────────────┘                        │
                    └─────────────────────────────────────────┘
                                │
                                ▼
                    take_action(action, action_type='ee')
```

### 10.4 逆变换数学推导

**正向（训练）** — `compute_camera_delta_action_with_gripper`：

```
R_e_e_star = R_w_e^T @ R_w_e_star          # EEF-frame relative rotation
t_e_e_star = R_w_e^T @ (t_w_e_star - t_w_e)  # EEF-frame relative translation
R_c_e = R_w_c^T @ R_w_e                      # EEF in camera frame
R_delta_c = R_c_e @ R_e_e_star @ R_c_e^T    # camera-frame delta rotation
t_delta_c = R_c_e @ t_e_e_star               # camera-frame delta translation
```

**逆向（推理）** — `_unified_delta_to_eepos_actions`：

```
# 已知：anchor pose (R_w_e, t_w_e)、predicted delta (t_delta_c, R_delta_c)
R_c_e = R_w_c^T @ R_w_e                      # EEF in camera frame
R_e_e_star = R_c_e^T @ R_delta_c @ R_c_e    # ← 逆：R_delta_c = R_c_e @ R_e_e_star @ R_c_e^T
t_e_e_star = R_c_e^T @ t_delta_c             # ← 逆：t_delta_c = R_c_e @ t_e_e_star
R_w_e_star = R_w_e @ R_e_e_star              # 目标世界旋转
t_w_e_star = t_w_e + R_w_e @ t_e_e_star      # 目标世界位置
gripper_star = action[6] / action[14]         # 夹爪直接使用预测值
```

### 10.5 修改文件清单

#### `deploy_policy.py`（修改）

| 变更 | 说明 |
|------|------|
| 新增 `scipy.spatial.transform.Rotation` 导入 | 用于 SO(3) 运算 |
| 新增类常量 `_HEAD_CAMERA_R_W_C`, `_HEAD_CAMERA_T_W_C` | 与训练侧一致的固定相机外参 |
| `__init__` 新增 `action_mode` 参数 | 支持 `"eepos"` 和 `"unified_eef_camera_delta_wrist16"` |
| 新增 `current_eepos_state` 缓存 | 存储当前帧绝对 eepos 作为逆变换 anchor |
| 新增 `_quat_wxyz_to_rotmat()` | WXYZ 四元数 → 旋转矩阵，保持 batch shape |
| 新增 `_rotmat_to_quat_wxyz()` | 旋转矩阵 → WXYZ 四元数，canonicalize w≥0 |
| 新增 `_log_so3()` / `_exp_so3()` | SO(3) 对数/指数映射 |
| 新增 `_build_unified_eef_state()` | 绝对 eepos → unified state（镜像训练侧 `compute_unified_eef_state_16d_with_gripper`） |
| 新增 `_unified_delta_to_eepos_actions()` | unified delta → 绝对 eepos（逆变换） |
| 修改 `update_obs()` | 按 `action_mode` 分流构建 state；始终缓存 `current_eepos_state` |
| 修改 `get_action()` | unified_eef 模式下将预测 delta 转回绝对 eepos |
| 修改 `get_model()` | 从 `paths_config.yml` 读取 `action_mode` 并传入 policy |
| 修改 `reset_model()` | 清理 `current_eepos_state` 缓存 |
| 修改 `eval()` 文档字符串 | 说明 unified_eef 模式下内部转换 |

#### `paths_config.yml`（修改）

`action_mode` 配置项文档化，支持两个值：
- `"eepos"`（默认，向后兼容）
- `"unified_eef_camera_delta_wrist16"`（新增）

### 10.6 验证结果

#### Round-trip 一致性测试

| 测试 | 结果 |
|------|------|
| state 构建：推理 `_build_unified_eef_state` vs 训练 `compute_unified_eef_state_16d_with_gripper` | ✅ max diff 9.5e-8（float32 精度） |
| 单帧 action round-trip：训练正向 delta → 推理逆向 → 恢复目标 pose | ✅ pos 3.5e-8, rot 7.4e-8, grip 2.8e-8 |
| 批量 action round-trip（5 帧） | ✅ pos 3.1e-8, rot 8.4e-8, grip 1.9e-8 |
| Policy 类方法集成测试（20 随机目标） | ✅ pos 5.9e-8, rot 1.0e-7, grip 0.0 |
| 零 delta → 恢复 anchor | ✅ pos 1.2e-8 |

#### 静态方法 shape 测试

| 测试 | 结果 |
|------|------|
| `_quat_wxyz_to_rotmat((4,))` → `(3,3)` | ✅ |
| `_rotmat_to_quat_wxyz((3,3))` → `(4,)` | ✅ |
| `_log_so3` / `_exp_so3` roundtrip | ✅ |

### 10.7 如何使用

1. **训练 unified EEF 模型**（使用 `configs/robotwin_unified_eef_WanVlmMask.yaml`）
2. **修改 `paths_config.yml`**：
   ```yaml
   action_mode: "unified_eef_camera_delta_wrist16"
   ```
3. **运行评估**：
   ```bash
   cd /home/ma-user/work/wx1469573/RoboTwin_EE/policy/MotusWanVlmDirectMaskUnifiedEE
   bash auto_eval_new.sh
   ```
4. 旧的 eepos 模型不受影响：将 `action_mode` 设为 `"eepos"` 即可

# MotusV2 Motion Token Training Review and Fix Log

Date: 2026-06-06

## 1. Conversation Summary

The user asked for a senior ML/training-system review of the MotusV2 VLM training pipeline, with special focus on:

- `docs/session_log_20260605.md`
- `scripts/train_ADS_MotusV2_robotwin_eepos_motion_token.sh`
- the implemented motion-token training path for RobotWin eepos data

The initial review concluded that the implementation mechanically covered most of the requested motion-token loss integration, but had high-risk training correctness issues:

- Ground-truth assistant motion tokens were visible to the action/video pathway.
- The VLM branch in MoT used non-causal self-attention while training next-token prediction.
- Validation/inference could consume target-derived assistant responses.
- Gradient accumulation was configured but not actually respected by the training loop.
- Train and validation datasets sampled from the same episode pool.
- Motion-token training hyperparameters were too aggressive for a joint VLM/WAN/action finetune.

The user then requested code changes for only Blocker and Major issues from the review report.

## 2. Key Decisions

1. Do not rewrite the whole training system.

   The fix keeps the existing MotusV2 structure and adds masks/metadata where needed.

2. Keep full prompt+assistant VLM inputs for token loss, but prevent leakage.

   The dataset still builds the complete sequence needed for token CE. The model receives assistant masks and blocks Action from attending to ground-truth assistant tokens.

3. Use prompt-only VLM inputs for validation/inference.

   Motion-token samples now return both:

   - `vlm_inputs`: full prompt + assistant response, used for training token loss.
   - `vlm_user_inputs`: prompt-only VLM input, used by validation/inference.

4. Make MoT VLM attention causal.

   The VLM slice of the MoT attention mask now uses a lower-triangular causal mask and respects padding.

5. Keep parameter changes conservative.

   The motion-token config lowers per-GPU batch size, uses gradient accumulation, reduces LR, reduces token loss weight, and increases warmup.

## 3. Issues From Review

### Blocker-1: Target Motion Token Leakage

Problem:

Training VLM input contained assistant motion tokens derived from `action_sequence`, while Action attention could see the full VLM sequence. This made action/video training and validation potentially use the answer.

Resolution:

- Add `assistant_token_mask`.
- Block Action attention to assistant response tokens.
- Use prompt-only VLM input during validation/inference.

### Blocker-2: Non-Causal VLM Attention For Next-Token Loss

Problem:

MoT VLM self-attention allowed each VLM token to attend to future tokens, invalidating strict next-token prediction.

Resolution:

- Add causal lower-triangular VLM self-attention mask inside MoT.
- Preserve padding masking for VLM keys.

### Blocker-3: Motion-Token Inference/Validation Path Missing

Problem:

Validation used `batch["vlm_inputs"]`, which in motion-token mode contained ground-truth assistant tokens.

Resolution:

- Dataset returns `vlm_user_inputs`.
- Validation/inference prefers `vlm_user_inputs` if present.

### Major-1: Gradient Accumulation Not Applied Correctly

Problem:

`gradient_accumulation_steps` was passed to Accelerate, but `train_step()` still ran optimizer and scheduler every micro-batch.

Resolution:

- Wrap forward/backward in `accelerator.accumulate()`.
- Clip gradients only when gradients are synchronized.
- Increment `global_step` only after a real optimizer step.

### Major-2: Validation Was Not A Held-Out Split

Problem:

Train and validation dataloaders were built from the same RobotWin episode pool.

Resolution:

- Add deterministic `validation_split` / `validation_seed`.
- Split episodes per task for multi-task RobotWin training.

### Major-3: Motion-Token Training Hyperparameters Too Aggressive

Problem:

Full joint finetuning with WAN/VLM LR `5e-5`, batch size 8, short warmup, and token loss weight 1.0 was likely unstable or token-loss dominated.

Resolution:

- Reduce batch size and use accumulation.
- Lower WAN/VLM learning rates.
- Reduce token loss weight.
- Increase warmup.

### Major-4: Processor Failure Was Silent

Problem:

If the extended-vocab processor failed to load, motion-token training could continue without valid token labels.

Resolution:

- Fail fast when motion-token prediction is enabled but the processor is invalid.
- Verify `<|motion_x_0000|>` encodes as a single token.

## 4. Code Modification Record

### `utils/vlm_utils.py`

Main changes:

- Updated `preprocess_vlm_messages_with_motion_tokens()`.
- Added `assistant_token_mask` and `assistant_loss_mask`.
- Added `preprocess_vlm_messages_motion_prompt_only()`.

Reason:

- Supports leakage-free MoT masking and prompt-only validation/inference.

Corresponding review issues:

- Blocker-1
- Blocker-2
- Blocker-3

### `data/robotwin2/robotwin_agilex_dataset.py`

Main changes:

- Added `validation_split` and `validation_seed` constructor parameters.
- Added deterministic train/validation episode splitting.
- Added fail-fast validation for motion-token processor loading.
- Added single-token tokenizer check for `<|motion_x_0000|>`.
- Added prompt-only `vlm_user_inputs` for motion-token samples.

Reason:

- Prevent validation leakage.
- Ensure motion-token training cannot silently run with an invalid tokenizer.
- Provide safe inference/validation VLM inputs.

Corresponding review issues:

- Blocker-3
- Major-2
- Major-4

### `data/dataset.py`

Main changes:

- Passed RobotWin `validation_split` and `validation_seed` from config.
- Extended `_process_vlm_inputs_batch()` to pad optional sequence masks:
  - `assistant_token_mask`
  - `assistant_loss_mask`
- Added collate handling for `vlm_user_inputs`.

Reason:

- Keeps assistant masks aligned after padding.
- Allows validation/inference to use prompt-only VLM inputs.

Corresponding review issues:

- Blocker-1
- Blocker-2
- Blocker-3
- Major-2

### `models/motus_wan_vlm_direct_mask.py`

Main changes:

- Extended `VideoModule.process_joint_attention()` with:
  - `vlm_attention_mask`
  - `vlm_assistant_mask`
- Updated MoT attention mask:
  - Video attends only to Video.
  - Action attends to Video, Action, and prompt/image VLM tokens.
  - Action is blocked from assistant ground-truth motion tokens.
  - VLM attends only to causal VLM tokens.
  - VLM padding keys are masked.
- Passed VLM masks in both training and inference MoT loops.
- Token loss now handles all-ignored labels safely.
- Replaced `.view()` with `.reshape()` in token CE flattening.

Reason:

- Removes answer leakage and makes next-token loss autoregressive.

Corresponding review issues:

- Blocker-1
- Blocker-2
- Major-4

### `train/sample.py`

Main changes:

- Validation/inference now prefers `batch["vlm_user_inputs"]` when present.

Reason:

- Prevents validation/inference from consuming ground-truth assistant motion tokens.

Corresponding review issues:

- Blocker-3

### `train/train_wan_vlm_mask.py`

Main changes:

- Wrapped training step in `accelerator.accumulate(self.model)`.
- Gradient clipping now happens only when `accelerator.sync_gradients` is true.
- Optimizer/scheduler stepping is accumulation-aware.
- `global_step` increments only after a real optimizer step.

Reason:

- Makes `gradient_accumulation_steps` behave as intended.

Corresponding review issues:

- Major-1

### `configs/robotwin_eepos_WanVlmMask_motion_token.yaml`

Main changes:

- Added:
  - `dataset.validation_split: 0.02`
  - `dataset.validation_seed: 42`
- Changed:
  - `training.batch_size: 8 -> 2`
  - `training.gradient_accumulation_steps: 1 -> 4`
  - `training.learning_rate: 5.0e-5 -> 2.0e-5`
  - `training.wan_learning_rate: 5.0e-5 -> 1.0e-5`
  - `training.vlm_learning_rate: 5.0e-5 -> 2.0e-5`
  - `model.loss_weights.token_loss_weight: 1.0 -> 0.2`
  - `training.warmup_steps: 200 -> 1000`

Reason:

- More conservative and stable starting point for joint WAN/VLM/action finetuning.

Corresponding review issues:

- Major-2
- Major-3

## 5. Validation Performed

Completed:

```bash
python -m py_compile utils\vlm_utils.py data\dataset.py data\robotwin2\robotwin_agilex_dataset.py models\motus_wan_vlm_direct_mask.py train\train_wan_vlm_mask.py train\sample.py
```

Result:

- Python syntax compilation passed.

Not completed:

- Runtime collate smoke test, because the local Python environment did not have `torch`.
- Real training smoke test, because local model/data dependencies were unavailable.

## 6. Remaining To-Do Items

1. Run a real 4-GPU smoke test in the training environment:

   ```bash
   torchrun --nproc_per_node=4 train/train_wan_vlm_mask.py \
     --deepspeed configs/zero1.json \
     --config configs/robotwin_eepos_WanVlmMask_motion_token.yaml \
     --run_name robotwin_eepos_motion_token_smoke \
     --report_to tensorboard \
     --max_steps 20
   ```

2. Verify that:

   - `token_loss` is non-zero.
   - `token_loss` decreases over early steps.
   - action/video losses do not collapse due to target leakage.
   - validation uses `vlm_user_inputs`, not full assistant responses.

3. Run a leakage sanity test:

   - Compare action/video validation metrics with and without assistant response tokens.
   - Metrics should not depend on target-derived assistant content.

4. Run a causal mask sanity test:

   - Perturb future assistant tokens.
   - Earlier token logits should not change through the MoT VLM branch.

5. Tune:

   - `token_loss_weight` in `{0.05, 0.1, 0.2, 0.5}`
   - `wan_learning_rate` in `{5e-6, 1e-5}`
   - `vlm_learning_rate` in `{1e-5, 2e-5}`

## 7. Notes

- The implementation intentionally does not address Minor review items.
- `Left:` and `Right:` text remains in the assistant response, because that was marked Minor in the review.
- `py_compile` created local `__pycache__` directories during validation. They should not be committed.

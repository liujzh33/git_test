# MotusV2 新变更总结

> 对比基准：`/home/ma-user/work/wx1469573/MotusV2-main`（原仓库）
> 当前仓库：`/home/ma-user/work/wx1469573/MotusV2`
> 生成日期：2026-06-10

## 修改文件清单

| # | 文件路径 | 修改类型 | 说明 |
|---|---------|---------|------|
| 1 | `models/motus_wan_vlm_direct_mask.py` | 修改 | `inference_step` 类型注解 `List→Any`；移除 denoising loop 内冗余 VLM 特征提取 |
| 2 | `configs/robotwin_eepos_WanVlmMask_motion_token_on.yaml` | 新增（替代原 `motion_token.yaml`） | Motion Token 开启模式训练配置，学习率调大至 5e-5，batch_size=8/grad_accum=1 |
| 3 | `configs/robotwin_eepos_WanVlmMask_motion_token_off.yaml` | 新增 | Motion Token 关闭模式训练配置（消融对照），`enabled: false`，`token_loss_weight: 0.0` |
| 4 | `scripts/train_ADS_MotusV2_robotwin_eepos_motion_token_on.sh` | 新增（替代原 `motion_token.sh`） | Motion Token ON 训练启动脚本，默认 8 GPU |
| 5 | `scripts/train_ADS_MotusV2_robotwin_eepos_motion_token_off.sh` | 新增 | Motion Token OFF 训练启动脚本（消融对照） |
| 6 | `docs/session_log_20260608_vlm_architecture_notes.md` | 新增 | VLM 模块架构理解笔记（MoT 注意力 mask、train-test 差异等） |
| 7 | `FastWAM-main/` | 新增目录 | 独立的 FastWAM 训练/评估框架（Hydra+Accelerate），支持 Libero 和 RoboTwin |
| 8 | `configs/robotwin_eepos_WanVlmMask_motion_token.yaml`（原仓库） | 删除（被 #2 替代） | 已拆分为 on/off 两个版本 |
| 9 | `scripts/train_ADS_MotusV2_robotwin_eepos_motion_token.sh`（原仓库） | 删除（被 #4 替代） | 已拆分为 on/off 两个版本 |

---

## 变更概览

相较于原仓库 MotusV2-main，当前 MotusV2 仓库共有以下新增/修改：

| 类型 | 数量 |
|------|------|
| 修改的文件 | 1 |
| 新增的文件 | 5（含 1 个文档） |
| 删除的文件（被替代） | 2 |
| 新增的目录 | 2（`FastWAM-main/`、`.claude/`） |

---

## 一、修改的文件

### 1. `models/motus_wan_vlm_direct_mask.py`

**2 处修改，均为非功能性改动：**

**(a)** `inference_step` 函数参数类型注解变更（L897）：
```diff
- vlm_inputs: Optional[List] = None
+ vlm_inputs: Optional[Any] = None
```
- **原因**：推理时 `vlm_inputs` 传入的是 dict（包含 `input_ids`, `attention_mask`, `pixel_values` 等），而非 list。原类型注解 `List` 不准确，改为 `Any` 以兼容 dict 输入。
- **影响**：纯类型注解，不影响运行逻辑。

**(b)** 移除 denoising loop 内冗余的 VLM 特征提取（L953-955）：
```diff
- # Extract VLM per-layer features for this step (VLM is updated each step)
- vlm_per_layer = self.qwen3_module.extract_per_layer_features(vlm_inputs)
```
- **原因**：VLM 特征在 denoising loop 之前已提取一次（L932），`vlm_inputs` 在推理时不会变化，无需每个 denoising step 重复计算。
- **影响**：推理性能优化，消除无意义的重复前向传播，结果完全一致。

---

## 二、新增的文件

### 2. `configs/robotwin_eepos_WanVlmMask_motion_token_on.yaml`

**Motion Token 开启模式的训练配置。**

替代原仓库的单个 `robotwin_eepos_WanVlmMask_motion_token.yaml`，明确标注为"开启"模式。

与原仓库配置的关键差异：

| 配置项 | 原仓库（motion_token.yaml） | 当前仓库（motion_token_on.yaml） |
|--------|---------------------------|-------------------------------|
| `batch_size` | 2 | 8 |
| `learning_rate` | 2.0e-5 | 5.0e-5 |
| `wan_learning_rate` | 1.0e-5 | 5.0e-5 |
| `vlm_learning_rate` | 2.0e-5 | 5.0e-5 |
| `gradient_accumulation_steps` | 4 | 1 |
| `system.checkpoint_dir` | `...motion_token` | `...motion_token_on` |
| `logging.tensorboard_log_dir` | `...motion_token_on` | `...motion_token_on` |

其余配置（模型结构、loss weights、motion token 参数等）与原仓库完全一致。

**注**：有效 batch size 保持相同 = `batch_size × grad_accum × num_gpus` = 2×4×8 = 8×1×8 = 64。主要差异是学习率调大 2.5~5 倍。

### 3. `configs/robotwin_eepos_WanVlmMask_motion_token_off.yaml`

**Motion Token 关闭模式的训练配置（新增）。**

用于对比实验，与 `motion_token_on.yaml` 的关键差异：

| 配置项 | motion_token_on | motion_token_off |
|--------|----------------|-----------------|
| `motion_token_prediction.enabled` | `true` | `false` |
| `loss_weights.token_loss_weight` | `0.2` | `0.0` |
| `system.checkpoint_dir` | `...motion_token_on` | `...motion_token_off` |
| `logging.tensorboard_log_dir` | `...motion_token_on` | `...motion_token_off` |

模型结构、数据路径、学习率等其他配置完全相同。此配置便于进行 motion token 预测的消融实验。

### 4. `scripts/train_ADS_MotusV2_robotwin_eepos_motion_token_on.sh`

**Motion Token 开启模式的训练启动脚本。**

替代原仓库的 `train_ADS_MotusV2_robotwin_eepos_motion_token.sh`。

差异：
- `TASK` 名称：`robotwin_eepos_WanVlmMask_motion_token` → `robotwin_eepos_WanVlmMask_motion_token_on`
- `CONFIG_FILE`：指向新配置 `configs/robotwin_eepos_WanVlmMask_motion_token_on.yaml`
- GPU 设置：原仓库硬编码 `CUDA_VISIBLE_DEVICES=4,5,6,7` + `NPROC_PER_NODE=4`；当前版本默认 `NPROC_PER_NODE=8`，不限制 GPU

### 5. `scripts/train_ADS_MotusV2_robotwin_eepos_motion_token_off.sh`

**Motion Token 关闭模式的训练启动脚本（新增）。**

与 `_on.sh` 完全对称，仅 `TASK` 和 `CONFIG_FILE` 指向 `_off` 版本。用于消融实验对照。

### 6. `docs/session_log_20260608_vlm_architecture_notes.md`

**VLM 模块架构理解笔记（新增文档）。**

记录了对 MotusV2 三模态 MoT 架构的深入理解，包含以下章节：

1. **`extract_per_layer_features` 计算流程**：VLM 输入处理 → 28 层前向 → 层映射 28→30
2. **`vlm_inputs` 完整结构**：基础字段（input_ids, pixel_values, image_grid_thw, attention_mask）与 motion token 额外字段（assistant_token_mask, assistant_loss_mask）
3. **GT 信息泄漏防护**：三层防线（Action blocked 看 assistant、VLM causal mask、Video 完全隔离）
4. **attention_mask 与 assistant_token_mask 的构造**：构造逻辑、示例、在 MoT 中的使用
5. **Train-Test 不一致性分析**：VLM 输入序列差异、为何不构成严重问题
6. **关键代码位置索引**：函数名、文件、行号对照表
7. **待深入问题**：层映射策略、autoregressive 生成可行性、CE loss weight 消融等

---

## 三、被替代的文件（原仓库有，当前仓库无）

### 7. `configs/robotwin_eepos_WanVlmMask_motion_token.yaml`（原仓库）

已被拆分为 `motion_token_on.yaml` + `motion_token_off.yaml`，支持消融实验。

### 8. `scripts/train_ADS_MotusV2_robotwin_eepos_motion_token.sh`（原仓库）

已被拆分为 `_on.sh` + `_off.sh`，对应两种配置。

---

## 四、新增目录

### `FastWAM-main/`（原仓库中不存在）

**整个目录为新增**，是一个独立的项目，包含 FastWAM 框架下 MotusV2 的训练和评估代码。与 MotusV2 主仓库是**两套独立的训练框架**（不同的模型实现、数据流、训练逻辑），详见下方第五节分析。

### `.claude/`

Claude Code 工具的工作目录，包含项目记忆和配置，不属于项目代码变更。

---

## 五、FastWAM-main 详细分析

### 5.1 项目结构概览

```
FastWAM-main/
├── configs/           # Hydra 配置（train.yaml, task/, model/, data/）
├── experiments/       # 实验入口（libero/, robotwin/）
│   ├── libero/        #   train_motus_v2.py, eval_motus_v2_libero.py, run_libero_manager.py
│   └── robotwin/      #   eval_robotwin_single.py, run_robotwin_manager.py
├── scripts/           # 启动脚本
│   ├── train_zero1_motus_v2.sh          # 通用 launch 脚本（accelerate launch）
│   ├── train_motus_v2_libero_all.sh     # Libero 训练入口
│   └── train_robotwin_motus_v2.sh       # RoboTwin 训练入口
├── src/fastwam/       # 核心框架代码
│   ├── models/wan22/motus_v2.py         # FastWAM 版 MotusV2 模型
│   ├── datasets/lerobot/                # 数据集（RobotVideoDataset, FastWAMProcessor）
│   └── trainer.py                       # Wan22Trainer
├── third_party/
│   └── RoboTwin/      # RoboTwin 评估环境（envs/, description/, code_gen/）
├── checkpoints/       # 权重存放目录
└── pyproject.toml     # 项目依赖定义
```

### 5.2 两个训练脚本的依赖分析

#### `train_motus_v2_libero_all.sh`

**调用链**：
```
train_motus_v2_libero_all.sh
  → train_zero1_motus_v2.sh
    → accelerate launch scripts/train_motus_v2.py
      → experiments/libero/train_motus_v2.py:run_training()
        → create_motus_v2_model() → fastwam.models.wan22.motus_v2.MotusV2
        → build_datasets() → fastwam.datasets.lerobot.robot_video_dataset.RobotVideoDataset
        → Wan22Trainer.train()
```

**PYTHONPATH 依赖**：
```bash
export PYTHONPATH="/home/ma-user/work/wx1469672/motus/LIBERO-master:\
/home/ma-user/work/wx1469672/motus/ref_eval_code/FastWAM-main/src:\
/home/ma-user/work/wx1469672/motus/ref_eval_code/FastWAM-main/experiments:${PYTHONPATH:-}"
```

- **LIBERO-master**：仅在 **评估阶段** 被 `eval_motus_v2_libero.py` 和 `run_libero_manager.py` 通过 `from libero.libero import benchmark` 导入。**训练阶段不需要**。
- **FastWAM-main/src** 和 **FastWAM-main/experiments**：训练必需，提供 `fastwam.*` 和 `experiments.*` 模块。

**是否依赖 `third_party/`**：**否**。训练阶段完全不涉及 `third_party/RoboTwin`。

#### `train_robotwin_motus_v2.sh`

**调用链**：
```
train_robotwin_motus_v2.sh
  → cd /home/ma-user/work/wx1469672/motus/ref_eval_code/FastWAM-main
  → train_zero1_motus_v2.sh
    → accelerate launch scripts/train_motus_v2.py
      → experiments/libero/train_motus_v2.py:run_training()  (通用入口)
        → create_motus_v2_model() → fastwam.models.wan22.motus_v2.MotusV2
        → build_datasets() → fastwam.datasets.lerobot.robot_video_dataset.RobotVideoDataset
        → Wan22Trainer.train()
```

**PYTHONPATH 依赖**：该脚本中 LIBERO-master 行被**注释掉**了，仅保留：
```bash
export PYTHONWARNINGS="ignore"
export DIFFSYNTH_MODEL_BASE_PATH="/cache/wwx1484778/motus_weights"
```

数据读取从 `/cache/wwx1484778/robotwin2.0-fastwam/robotwin2.0` 直接加载 LeRobot 格式数据，不经过 RoboTwin 仿真环境。

**是否依赖 `third_party/RoboTwin`**：**否**。训练阶段完全不涉及。

### 5.3 `third_party/RoboTwin` 的实际用途

`third_party/RoboTwin/` **仅在评估阶段被使用**，具体位置：

| 文件 | 用途 |
|------|------|
| `experiments/robotwin/eval_robotwin_single.py` | 评估时调用 RoboTwin 环境运行策略 |
| `experiments/robotwin/run_robotwin_manager.py` L20 | 读取 `third_party/RoboTwin/task_config/_eval_step_limit.yml` 获取每个 task 的步数限制 |
| `configs/sim_robotwin.yaml` L17 | `robotwin_root: third_party/RoboTwin` 配置评估环境的根路径 |

**注意**：当前 `third_party/RoboTwin/task_config/` 目录为空（`_eval_step_limit.yml` 不存在），评估时可能会报错。该文件需从 RoboTwin 原始仓库补充。

### 5.4 训练 vs 评估依赖总结

| 阶段 | 需要 LIBERO-master | 需要 third_party/RoboTwin |
|------|-------------------|-------------------------|
| Libero 训练 | 否 | 否 |
| Libero 评估 | 是 | 否 |
| RoboTwin 训练 | 否 | 否 |
| RoboTwin 评估 | 否 | 是（且缺 `_eval_step_limit.yml`） |

### 5.5 硬编码路径问题

两个训练脚本中存在多处硬编码的绝对路径，指向**另一台机器**的用户目录：

| 脚本 | 硬编码路径 | 用途 |
|------|-----------|------|
| `train_motus_v2_libero_all.sh` | `/home/ma-user/work/wx1469672/motus/LIBERO-master` | PYTHONPATH（评估用） |
| `train_motus_v2_libero_all.sh` | `/home/ma-user/work/wx1469672/motus/ref_eval_code/FastWAM-main/...` | PYTHONPATH |
| `train_robotwin_motus_v2.sh` | `/home/ma-user/work/wx1469672/motus/ref_eval_code/FastWAM-main` | cd 目标目录 |
| 数据配置 (robotwin.yaml) | `/cache/wwx1484778/robotwin2.0-fastwam/...` | 数据集路径 |
| 数据配置 (libero_2cam.yaml) | `/cache/wwx1484778/libero_lerobot_hf/...` | 数据集路径 |
| 模型配置 (motus_v2.yaml) | `/cache/wwx1484778/motus_weights/...` | 预训练权重路径 |
| 训练输出 | `/cache/wwx1484778/Fastwam/runs/...` | checkpoint 保存路径 |

若要在当前机器运行，需要将这些路径替换为本机对应路径。

---

## 六、完全相同的文件

除上述变更外，以下目录中的所有文件与原仓库完全一致：

- `bak/` — WAN 原始代码
- `data/` — 数据集定义
- `models/` — 除 `motus_wan_vlm_direct_mask.py` 外的模型代码
- `scripts/` — 除新增/替代脚本外的训练脚本
- `train/` — 训练逻辑
- `utils/` — 工具函数
- `README.md` — 项目说明

---

## 七、变更意图总结

本次变更包含两方面的内容：

**A. MotusV2 主仓库变更**（配置拆分 + 推理优化）：

1. **配置拆分**：原单个 `motion_token.yaml` → `motion_token_on.yaml` + `motion_token_off.yaml`，通过 `enabled: true/false` 和 `token_loss_weight: 0.2/0.0` 控制是否启用 motion token 预测辅助 loss
2. **脚本拆分**：训练启动脚本同步拆分，确保一键运行
3. **超参调整**：`_on` 版本调大了学习率（2e-5 → 5e-5），去掉了 GPU 限制，使用更大的 per-GPU batch size + 更少的 gradient accumulation
4. **推理优化**：移除 denoising loop 中冗余的 VLM 特征提取，修复类型注解
5. **文档补充**：新增 VLM 架构理解笔记，记录三模态 MoT 的设计细节和 train-test 差异分析

**B. FastWAM-main 新增**（独立的训练/评估框架）：

FastWAM-main 是一套基于 Hydra + Accelerate + DeepSpeed 的独立框架，与 MotusV2 主仓库的 torchrun + HF Accelerate 框架完全独立。它实现了同一模型（MotusV2）的另一套训练管线，支持 Libero 和 RoboTwin 两个 benchmark。`third_party/RoboTwin` 仅在评估阶段使用，训练不依赖。

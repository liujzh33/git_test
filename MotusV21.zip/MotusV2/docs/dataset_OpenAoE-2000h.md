# inclusionAI / OpenAoE-2000h 数据集说明文档

> 本文档用于梳理 `obs://yw-2030-gy/data/opensource/inclusionAI-OpenAoE-2000h/` 数据集的目录结构、数据内容与文件格式，供编写 dataset 加载脚本参考。
> 数据集对应 ModelScope 仓库：`inclusionAI/OpenAoE-2000h`（由样本目录中的 `.ms_upload_cache` 内 `repo_id` 字段确认）。

---

## 1. 数据集概览

| 项目 | 内容 |
|------|------|
| 数据集名称 | inclusionAI / OpenAoE-2000h |
| OBS 路径 | `obs://yw-2030-gy/data/opensource/inclusionAI-OpenAoE-2000h/` |
| 顶层条目数 | **13,332** 个目录（无散落文件） |
| 命名前缀 | `aoe_`（59 个）与 `raw_`（13,273 个）两类 |
| 单样本目录内文件数 | 标准 **9 个**文件（部分上传未完成的尾部目录少于 9 个） |
| 估算总规模 | 约 **4.7 TB**（按 30 个目录采样，平均 0.36 GB/目录 × 13,332） |
| 数据模态 | 第一人称（ego）/ 操作视角（manipulation）视频 + 手部 3D 重建（MANO）+ 相机轨迹 + 动作标注 |
| 采集设备 | 多品牌安卓手机（samsung / HUAWEI / OPPO / Xiaomi / Apple iPhone 等） |
| 视频分辨率 | 1920×1080 或 1280×720 |
| 视频帧率 | 多为 29~30 fps，部分 60 fps |

### 1.1 两种顶层目录命名规则

| 前缀 | 数量 | 命名格式 | 说明 |
|------|------|----------|------|
| `aoe_` | 59 | `aoe_<YYYYMMDD>_<HHMMSS>_p<编号>` <br>例：`aoe_20260131_193028_p000` | 时间戳 + 参与者编号。时间跨度 2026-01-31 ~ 2026-05-25。`p000`/`p001`… 为同一次录制中的不同参与者/段落编号。 |
| `raw_` | 13,273 | `raw_<原始ID>_seg_<片段序号>` <br>例：`raw_304396_seg_304529`、`raw_305142_seg_12` | `<原始ID>` 为原始录制任务 ID；`seg_` 后为切片序号，可能是较大数值（如 `304529`，疑似全局帧/段编号）或小整数（如 `1, 2, 3, 5, 7, 9, 11, 13 …`，为同一原始视频的切片序号）。 |

> 两类目录**内部文件结构完全一致**，区别仅在于：`raw_` 目录多一个 `.ms_upload_cache` 缓存文件；`video_info.json` 的字段详略程度因采集 App 版本/设备而异（见 §4.2）。

---

## 2. OBS 数据读取方法

使用华为云 `moxing`（`mox.file`）API 访问，需先设置环境变量：

```python
import os
os.environ['S3_ENDPOINT'] = '10.170.30.79:80'
os.environ['S3_USE_HTTPS'] = '0'
os.environ['ACCESS_KEY_ID'] = 'l00609438'
os.environ['SECRET_ACCESS_KEY'] = '9c24d3232bb14e188ca6e1757f7af470'

import moxing as mox
```

常用操作：

| 操作 | 代码 | 说明 |
|------|------|------|
| 列顶层（不递归） | `mox.file.list_directory('obs://yw-2030-gy/data/opensource/inclusionAI-OpenAoE-2000h/')` | 返回 `list[str]`，13,332 个目录名 |
| 递归列举 | `mox.file.list_directory(path, recursive=True)` | 返回相对路径列表（含子目录与文件） |
| 判断是否目录 | `mox.file.is_directory(path)` | 返回 `bool` |
| 判断存在 | `mox.file.exists(path)` | 返回 `bool` |
| 获取文件大小 | `mox.file.get_size(path)` | 单位 bytes |
| 递归目录总大小 | `mox.file.get_size(path, recursive=True)` | 单位 bytes |
| 获取 stat | `mox.file.stat(path)` | 含 `length` / `mtime_nsec` / `is_directory` |
| 下载文件到本地 | `mox.file.copy(obs_path, local_path)` | 单文件复制（下载） |
| 下载整个目录 | `mox.file.copy_parallel(obs_dir, local_dir)` | 递归复制目录 |

> **注意**：`list_directory` 对大目录会分页拉取（日志可见 `Listing OBS: 1000 / 2000 …`），13,332 条会触发多次请求，注意耗时与超时。
> **建议**：写 dataset 脚本时先用 `list_directory` 获取全部样本目录名并缓存到本地索引文件，再按需下载/读取单个文件，避免每次启动都全量列举。

---

## 3. 单样本目录结构

每个样本目录（`aoe_*` 或 `raw_*`）的标准结构如下，共 **9 个文件**：

```
<sample_dir>/
├── raw_video.mp4                                    # 原始第一人称视频（带镜头畸变）
├── video_info.json                                  # 设备/相机内参/IMU/定位等元信息
├── ego_annotation/
│   └── ego_action_annotation.json                   # 逐段动作标注（动词+对象+手+描述+bbox）
├── ego_process/
│   ├── ego_undistorted_video/
│   │   ├── raw_video_undistorted.mp4                # 去畸变后的视频
│   │   └── undistorted_video_info.json              # 去畸变后相机内参/FOV/fps 等信息
│   └── ego_hands_reconstruction/
│       ├── camera_traj.npz                          # 逐帧相机轨迹（c2w 4×4）+ 内参矩阵
│       ├── hands.npz                                # 逐帧双手 MANO 重建参数 + 世界/相机坐标变换
│       └── visualization/
│           ├── hands_combined.mp4                   # 手部重建可视化视频（叠加渲染，帧数为原始的约 1/2）
│           └── overview.png                         # 重建结果总览图（静态拼图）
└── .ms_upload_cache                                 # [仅 raw_* 目录] ModelScope 上传缓存（可忽略）
```

### 文件清单与典型大小（以 `aoe_20260131_193028_p000` 为例）

| 文件 | 典型大小 | 说明 |
|------|----------|------|
| `raw_video.mp4` | ~86 MB | 1920×1080, ~30fps, ~166s, H.264, 含音频流 |
| `video_info.json` | < 2 KB | 元信息 |
| `ego_annotation/ego_action_annotation.json` | 数 KB ~ 数十 KB | 动作标注 |
| `ego_process/ego_undistorted_video/raw_video_undistorted.mp4` | ~318 MB | 去畸变视频（文件较大，无压缩增益） |
| `ego_process/ego_undistorted_video/undistorted_video_info.json` | < 2 KB | 去畸变后内参 |
| `ego_process/ego_hands_reconstruction/camera_traj.npz` | ~0.6 ~ 1 MB | 相机轨迹 |
| `ego_process/ego_hands_reconstruction/hands.npz` | ~3 ~ 5 MB | 手部重建参数 |
| `ego_process/ego_hands_reconstruction/visualization/hands_combined.mp4` | ~48 MB | 可视化视频 |
| `ego_process/ego_hands_reconstruction/visualization/overview.png` | ~0.35 MB | 总览图 |
| `.ms_upload_cache` | ~2 KB | 上传缓存（仅 `raw_*`） |

> **下载成本提示**：单目录完整下载约 0.36 GB，其中 `raw_video_undistorted.mp4` 占大头。若只需标注+原始视频+重建参数，可跳过 `visualization/` 与 `raw_video_undistorted.mp4`，体积可降至约 90 MB/目录。

---

## 4. 文件格式详解

### 4.1 `raw_video.mp4` — 原始视频

- **容器**：MP4（QuickTime/MOV），通常含 2 个流（视频 + 音频）。
- **视频编码**：H.264 (AVC)，`yuvj420p`，`pc` color range。
- **分辨率**：1920×1080 或 1280×720（取决于设备）。
- **帧率**：实际平均约 29~30 fps（`avg_frame_rate`），元数据 `r_frame_rate` 个别为 120（捕获基准率），但 `nb_frames / duration` ≈ 30。部分目录为 60 fps。
- **坐标系约定**：OpenCV 约定（x-right, y-down, z-forward），见 `video_info.json` 的 `camera_coord_frame` 字段。
- **是否带畸变**：是（原始未校正），畸变系数见 `video_info.json` 的 `lensDistortion`。
- **帧数与重建对齐**：视频帧数 = `camera_traj.npz` / `hands.npz` 第一维大小（逐帧对齐，见 §5）。

示例（`aoe_20260131_193028_p000`）：1920×1080, nb_frames=4997, duration=166.56s, bitrate≈4.2 Mbps。
示例（`raw_304396_seg_304529`）：1280×720, nb_frames=7303, duration=251.83s, 29fps。

### 4.2 `video_info.json` — 视频元信息

**该文件 schema 不统一**，字段随采集 App 版本与设备变化。编写脚本时**务必对缺失字段做容错**（`dict.get`）。

存在两种主要 schema 变体：

#### 变体 A（简版，多见于部分 `aoe_*`）
```json
{
  "deviceInfo": { "brand": "samsung", "model": "SM-S9080", "androidVersion": "13" },
  "cameraParams": {
    "usedCameraId": "2",
    "resolution": "1920x1080",
    "fx_pixels": 787.91, "fy_pixels": 591.31,
    "cx_pixels": 961.26, "cy_pixels": 539.47,
    "max_fx_pixels": 787.91, "max_fy_pixels": 787.91,
    "minFocusDistance_meters": 10,
    "lensDistortion": "[-0.0019, 0.0146, -0.0092, 0.0, 0.0]"
  }
}
```

#### 变体 B（详细版，多见于 `raw_*` 及较新 `aoe_*`）
```json
{
  "deviceInfo": {
    "brand": "Xiaomi", "model": "M2011K2C", "androidVersion": "14",
    "appVersion": "3.2.54", "reportTime": "2026-07-17 16:57:03"
  },
  "cameraParams": {
    "usedPhysicalCameraId": "0", "openedLogicalCameraId": "0",
    "isOpenedAsLogicalCamera": false, "isWideAngle": false, "isZoomWideAngle": false,
    "zoomRatio": 1, "fps": 30, "resolution": "1280x720",
    "fovHorizontal_degrees": 70.34, "fovVertical_degrees": 55.71,
    "fx_pixels": 908.24, "fy_pixels": 681.18, "cx_pixels": 640, "cy_pixels": 360,
    "max_fx_pixels": 908.24, "max_fy_pixels": 681.18,
    "minFocusDistance_diopters": 10,
    "lensDistortion": "[0.0, 0.0, 0.0, 0.0, 0.0]",
    "lensDistortionOrder": "k1,k2,k3,p1,p2",
    "lockedFocusDistance": 0, "lockedIso": 0, "lockedExposureTimeNs": 0,
    "latitude": 0, "longitude": 0, "location_region": "0",
    "imu_to_camera_rotation_row_major": "[1,0,0, 0,-1,0, 0,0,-1]",
    "imu_reference_frame": "android_sensor: x-right, y-up, z-out_of_screen",
    "camera_coord_frame": "opencv: x-right, y-down, z-forward"
  },
  "localization": { "latitude": 30.594079, "longitude": 114.178905, "region": "湖北省武汉市硚口区" },
  "imu": {
    "reference_frame": "android_sensor: x-right, y-up, z-out_of_screen",
    "to_camera_rotation_row_major": "1,0,0, 0,-1,0, 0,0,-1",
    "camera_coord_frame": "opencv: x-right, y-down, z-forward",
    "frequency_hz": 50
  },
  "perspective": "manipulation"
}
```

#### 变体 C（含录制任务信息，见于部分 `raw_*`）
额外包含顶层字段：`version`(`"2.0"`)、`createTime`(毫秒时间戳)、`taskId`、`recording`(`{fileName, durationSeconds, fileSizeKB}`)，以及更详细的 `imu`（含 `localMcapPath`/`remoteMcapPath`/`accelerometerSamples`/`gyroscopeSamples`/`sampleRateHz`/`durationMs`，IMU 原始数据存于 `.mcap`，**不在本数据集中**）。

#### 字段参考表

| 字段路径 | 类型 | 是否必有 | 说明 |
|----------|------|----------|------|
| `deviceInfo.brand` | str | 是 | 手机品牌（samsung/HUAWEI/OPPO/Xiaomi/Apple…） |
| `deviceInfo.model` | str | 是 | 机型（如 `SM-S9080`、`iPhone`） |
| `deviceInfo.androidVersion` | str | 是 | 安卓版本 |
| `deviceInfo.appVersion` | str | 否 | 采集 App 版本（如 `3.2.54`） |
| `deviceInfo.reportTime` | str | 否 | 上报时间 |
| `cameraParams.resolution` | str | 是 | `"WxH"`，如 `"1920x1080"` |
| `cameraParams.fps` | int | 否 | 目标帧率（30/60）；**可能缺失**，需用 ffprobe 兜底 |
| `cameraParams.fx_pixels` / `fy_pixels` | float | 是 | 焦距（像素） |
| `cameraParams.cx_pixels` / `cy_pixels` | float | 是 | 主点（像素） |
| `cameraParams.max_fx_pixels` / `max_fy_pixels` | float | 是 | 最大焦距 |
| `cameraParams.fovHorizontal_degrees` / `fovVertical_degrees` | float | 否 | 视场角（度） |
| `cameraParams.lensDistortion` | str(JSON array) | 是 | OpenCV 畸变系数 `[k1,k2,k3,p1,p2]`（字符串形式） |
| `cameraParams.lensDistortionOrder` | str | 否 | 畸变系数顺序说明，固定 `"k1,k2,k3,p1,p2"` |
| `cameraParams.isWideAngle` / `isZoomWideAngle` / `zoomRatio` | bool/float | 否 | 广角/变焦信息 |
| `cameraParams.minFocusDistance_*` | float | 否 | 最近对焦距离（单位字段名有 `_meters` 与 `_diopters` 两种，**注意单位差异**） |
| `cameraParams.imu_to_camera_rotation_row_major` | str | 否 | IMU→相机旋转矩阵（行优先，字符串） |
| `cameraParams.camera_coord_frame` | str | 否 | 相机坐标系约定，通常 OpenCV |
| `cameraParams.imu_reference_frame` | str | 否 | IMU 坐标系约定 |
| `localization` | object | 否 | GPS 定位（`latitude`/`longitude`/`region`），多数为 0 或缺失 |
| `imu` | object | 否 | IMU 元信息；`frequency_hz` 多为 50。**IMU 原始流不在本数据集** |
| `perspective` | str | 否 | 视角类型：`"manipulation"`（多数，操作/手部视角）或 `"ego"`（第一人称） |
| `version` / `createTime` / `taskId` / `recording` | - | 否 | 录制任务元信息（仅变体 C） |

> **关键注意**：
> - `lensDistortion` 是**字符串**形式的 JSON 数组，需 `json.loads()` 解析。
> - `fps` 可能缺失，且 `video_info.json` 中的 `fps` 与视频实际帧率（ffprobe）可能不完全一致（如标注 30 实际 29）。以 ffprobe `avg_frame_rate` 为准。
> - `minFocusDistance` 单位字段名不统一（`_meters` vs `_diopters`），勿假定。

### 4.3 `ego_annotation/ego_action_annotation.json` — 动作标注

顶层为 **JSON 数组**，每个元素为一段时间内的动作片段（segment）。字段固定、schema 统一。

#### Segment 字段

| 字段 | 类型 | 说明 |
|------|------|------|
| `id` | int | 片段序号（从 1 开始，按时间顺序） |
| `start_ts` | str | 起始时间戳（秒，字符串形式，如 `"0.00"`） |
| `end_ts` | str | 结束时间戳（秒，字符串） |
| `start_frame` | str | 起始帧号（字符串，如 `"0"`），**与视频帧对齐** |
| `end_frame` | str | 结束帧号（字符串） |
| `scene` | str | 场景类别（见下方枚举） |
| `atomic_action` | array | 原子动作列表（一个 segment 可含多个原子动作） |

#### atomic_action 元素字段

| 字段 | 类型 | 说明 |
|------|------|------|
| `verb` | str | 动作动词（见下方枚举，80+ 种） |
| `object` | str | 操作对象（自由文本，如 `"pot"`、`"sponge"`、`"clear palette"`） |
| `hand` | str | 使用的手：`"left"` / `"right"` / `"both"` |
| `description` | str | 自然语言动作描述（英文） |
| `bbox` | array[int] | 像素坐标包围盒 `[x1, y1, x2, y2]`，基于**原始视频分辨率** |
| `confidence` | float | 标注置信度（0~1，多为 0.9/0.95） |

#### 示例
```json
[
  {
    "id": 1,
    "start_ts": "0.0", "end_ts": "2.0",
    "start_frame": "0", "end_frame": "60",
    "scene": "kitchen",
    "atomic_action": [
      {
        "verb": "gesture", "object": "hands", "hand": "both",
        "description": "The person shows their hands and nails to the camera.",
        "bbox": [300, 100, 700, 600], "confidence": 0.95
      }
    ]
  }
]
```

#### 统计（40 个目录采样）
- 平均每个目录约 **22.5** 个动作 segment。
- `scene` 枚举（18 种）：`bathroom`, `bedroom`, `bus interior`, `car_interior`, `desk`, `dining room`, `hallway`, `hardware store`, `indoor`, `kitchen`, `laundry area`, `living room`, `office`, `outdoor`, `store`, `store counter`, `table`, `workshop`。
- `verb` 枚举（80+ 种），示例：`grasp, hold, reach, place, insert, pick_up, put_down, open, close, turn, press, pull, push, pour, scrub, wipe, wash, fold, cut, slice, chop, peel, screw, unscrew, tie, sew, stack, sort, spread, sprinkle, squeeze, sweep, swipe, tear, throw, transfer, trim, twist, uncap, unfold, unplug, walk, wrap, gesture, …`。
- `hand` 取值：`left` / `right` / `both`。
- 帧号范围：0 ~ 14427（对应最长视频约 480s @30fps）。

> **脚本注意**：`start_ts/end_ts/start_frame/end_frame` 均为**字符串**，使用前需 `int()`/`float()` 转换。`bbox` 为像素坐标 `[x1,y1,x2,y2]`，坐标系为原始视频分辨率，若用在去畸变视频上需做相应变换。

### 4.4 `ego_process/ego_undistorted_video/raw_video_undistorted.mp4` — 去畸变视频

- 对 `raw_video.mp4` 应用 `lensDistortion` 校正后的视频。
- **帧数与 `raw_video.mp4` 相同**，分辨率相同，畸变被去除（内参对应 `undistorted_video_info.json`）。
- 文件较大（约为原始视频的 3~4 倍，因重编码），**非必需时可跳过下载**。

### 4.5 `ego_process/ego_undistorted_video/undistorted_video_info.json` — 去畸变后内参

结构与 `video_info.json`（变体 B）一致，但：
- `cameraParams.lensDistortion` 为 `"[0.0, 0.0, 0.0, 0.0, 0.0]"`（已校正）。
- 额外字段：`video_filename`（去畸变视频文件名，可能为 `raw_video_undistorted.mp4` 或原始任务名如 `rp_dl_zktlbvrn_undistorted.mp4`）、`fps`（去畸变后实际帧率，如 29/30）。
- `cameraParams` 含 `fov_x_degrees/fov_y_degrees/fov_x_radians/fov_y_radians`（去畸变后视场角）。
- 内参 `fx/fy/cx/cy` 为去畸变后等效内参（与 `camera_traj.npz` 的 `intrinsic` 一致）。

### 4.6 `ego_process/ego_hands_reconstruction/camera_traj.npz` — 相机轨迹

NumPy `.npz`，包含 2 个数组：

| 键 | shape | dtype | 说明 |
|----|-------|-------|------|
| `cam_c2w` | `(N, 4, 4)` | float64 | 逐帧相机到世界变换矩阵（camera-to-world，齐次 4×4）。`N` = 视频帧数。 |
| `intrinsic` | `(3, 3)` | float64 | 去畸变后相机内参矩阵（与 `undistorted_video_info.json` 的 fx/fy/cx/cy 一致） |

示例：`aoe_20260131_193028_p000` → `cam_c2w` shape `(4997, 4, 4)`，`intrinsic` =
```
[[787.828,   0.   , 961.866],
 [  0.   , 791.208, 539.973],
 [  0.   ,   0.   ,   1.   ]]
```

> `cam_c2w` 旋转部分采用 OpenCV 相机坐标系（z-forward）。第 0 帧的 `cam_c2w` 不一定是单位阵（已含世界系初始位姿）。

### 4.7 `ego_process/ego_hands_reconstruction/hands.npz` — 手部 3D 重建（MANO）

NumPy `.npz`，包含 12 个数组。**双手**维度（第一维大小为 2，索引 `[0]`/`[1]` 对应两只手，顺序需按 `pred_valid` 判断，通常为 left/right）。`N` = 视频帧数。

| 键 | shape | dtype | 说明 |
|----|-------|-------|------|
| `R_w2c` | `(N, 3, 3)` | float32 | 逐帧世界→相机旋转矩阵 |
| `t_w2c` | `(N, 3)` | float32 | 逐帧世界→相机平移 |
| `R_c2w` | `(N, 3, 3)` | float32 | 逐帧相机→世界旋转矩阵 |
| `t_c2w` | `(N, 3)` | float32 | 逐帧相机→世界平移 |
| `pred_trans` | `(2, N, 3)` | float32 | 双手世界坐标系下的平移（MANO global translation） |
| `pred_rot` | `(2, N, 3)` | float32 | 双手世界坐标系下的全局旋转（轴角 axis-angle 表示） |
| `pred_trans_cam` | `(2, N, 3)` | float32 | 双手相机坐标系下的平移 |
| `pred_rot_cam` | `(2, N, 3)` | float32 | 双手相机坐标系下的全局旋转（轴角） |
| `pred_hand_pose` | `(2, N, 45)` | float32 | MANO 手部姿态参数（45 = 15 个关节 × 3 轴角） |
| `pred_betas` | `(2, N, 10)` | float32 | MANO 形状参数（10 维 PCA 系数） |
| `pred_valid` | `(2, N)` | float32 | 每只手每帧的有效性掩码（1.0=有效，0.0=无效/不可见） |
| `focal` | `()` | float64 | 焦距标量（与 `intrinsic[0,0]` 一致） |

> **使用要点**：
> - 结合 `pred_hand_pose`(45) + `pred_betas`(10) + `pred_trans`(3) + `pred_rot`(3) 可通过 MANO 模型重建完整手部 mesh 与 3D 关节。
> - `pred_rot` 为轴角表示，转旋转矩阵需用 `scipy.spatial.transform.Rotation` 或等价实现。
> - 重建结果是**预测（pred_）**，非真值；用 `pred_valid` 过滤无效帧。
> - 世界系位姿需配合 `camera_traj.npz` 的 `cam_c2w` / `hands.npz` 的 `R_c2w,t_c2w` 理解。
> - 示例：`aoe_20260131_193028_p000` → 所有 `N=4997`；`raw_304396_seg_304529` → `N=7303`。

### 4.8 `ego_process/ego_hands_reconstruction/visualization/hands_combined.mp4` — 可视化视频

- 手部重建结果叠加渲染到视频上的可视化（供人工质检，**训练时一般不读取**）。
- 分辨率较小（如 960×1080），30fps。
- **帧数约为原始视频的一半**（如原始 4997 帧 → 可视化 2499 帧，duration 约为原始的 1/2），疑似每隔一帧渲染或 2× 速。**不要用它做帧对齐**。

### 4.9 `ego_process/ego_hands_reconstruction/visualization/overview.png` — 总览图

- 静态 PNG，将若干关键帧的手部 3D 重建结果（mesh + 相机轨迹）拼接成一张总览图，用于快速浏览重建质量。
- 训练时一般不读取。

### 4.10 `.ms_upload_cache` — 上传缓存（仅 `raw_*`）

- ModelScope 上传工具生成的缓存文件，JSON 格式。
- 内容：`{"version":3, "repo_id":"inclusionAI/OpenAoE-2000h", "files": { "<相对路径>|<时间戳>|<大小>": {"hash":..., "size":..., "status":"c"}, ... }}`。
- **数据加载脚本应忽略此文件**（递归列举时用 `if name == '.ms_upload_cache': continue` 过滤）。

---

## 5. 帧对齐关系（重要）

| 数据 | 帧维度 `N` | 对齐对象 |
|------|-----------|----------|
| `raw_video.mp4` | `nb_frames` | 基准 |
| `raw_video_undistorted.mp4` | = `raw_video` 帧数 | 逐帧对应（仅去畸变） |
| `camera_traj.npz` `cam_c2w` | 第 0 维 = 视频帧数 | 逐帧对齐视频 |
| `hands.npz` 各逐帧数组 | 第 1 维 = 视频帧数 | 逐帧对齐视频 |
| `ego_action_annotation.json` `start_frame/end_frame` | 帧号 | 对齐视频帧号 |
| `hands_combined.mp4` | ≈ 视频帧数 / 2 | **不对齐**，仅可视化 |

> **结论**：标注的 `start_frame`/`end_frame`、所有 `.npz` 逐帧数组均与 `raw_video.mp4`（及去畸变视频，帧数相同）**逐帧对齐**，可直接按帧索引。可视化视频 `hands_combined.mp4` 帧数减半，不可用于对齐。

---

## 6. 数据完整性与规模统计

| 统计项 | 数值 |
|--------|------|
| 顶层目录总数 | 13,332 |
| `aoe_*` 目录数 | 59 |
| `raw_*` 目录数 | 13,273 |
| 随机抽样 300 个目录完整率（含 9 文件） | **100%** |
| 尾部上传中目录（<9 文件） | 列表末尾少数目录（如 `raw_320170_seg_1/2/3`、`raw_320171_seg_1` 仅 4~8 个文件），属上传未完成，**使用时按文件存在性过滤** |
| 单目录平均大小 | ~0.36 GB |
| 估算总规模 | ~4.7 TB |
| `perspective` 分布（30 采样） | `manipulation` 25 / `ego` 5 |
| 采集设备品牌 | samsung, HUAWEI, OPPO, Xiaomi, Apple 等 |
| 视频分辨率 | 1920×1080、1280×720 |
| 视频帧率 | 29/30 fps（个别 60 fps） |

### 完整性处理建议
- 部分目录缺失 `raw_video.mp4` 或 `raw_video_undistorted.mp4`（如 `raw_320170_seg_1` 缺两个 mp4，`raw_320171_seg_1` 仅含 4 个文件）。
- **加载脚本务必对每个需要的文件用 `mox.file.exists()` 校验后再下载/读取**，缺失则跳过该样本或降级处理。
- 递归列举后过滤 `.ms_upload_cache`。

---

## 7. 编写 Dataset 脚本的建议

1. **建立本地索引**：一次性 `list_directory` 获取 13,332 个样本名，缓存为本地 `jsonl`/`txt`，避免重复全量列举（耗时且产生大量 OBS 请求）。
2. **按需下载**：单文件用 `mox.file.copy`；切勿 `copy_parallel` 整个目录（含 ~318MB 的去畸变视频）。建议只下载 `raw_video.mp4` + `video_info.json` + `ego_action_annotation.json` + `hands.npz` + `camera_traj.npz`，按需再下 `raw_video_undistorted.mp4`。
3. **字段容错**：`video_info.json` schema 多变，所有字段用 `.get()`，`fps` 缺失时用 ffprobe 或默认 30；`lensDistortion` 需 `json.loads`；`minFocusDistance` 注意单位字段名差异。
4. **字符串数值转换**：标注中 `start_frame/end_frame/start_ts/end_ts` 均为字符串。
5. **帧对齐**：按 `raw_video.mp4` 帧号索引 npz（`array[frame_idx]`）与标注（`start_frame <= frame < end_frame`）。
6. **有效性过滤**：用 `hands.npz` 的 `pred_valid` 过滤不可见手/帧。
7. **坐标系**：统一 OpenCV 相机系（x-right, y-down, z-forward）；世界系位姿用 `cam_c2w` / `R_c2w,t_c2w`。
8. **MANO 重建**：`pred_rot` 为轴角，需转旋转矩阵；`pred_hand_pose`(45=15×3) + `pred_betas`(10) 喂入 MANO。
9. **忽略文件**：递归列举时跳过 `.ms_upload_cache`；`visualization/` 与 `hands_combined.mp4`、`overview.png` 一般不入训练数据。
10. **异步/缓存**：OBS 读取有网络延迟，建议本地缓存已下载文件，并用 `mox.file.stat` 获取 `mtime_nsec` 做增量校验。

---

## 8. 快速验证代码片段

```python
import os, json
os.environ['S3_ENDPOINT'] = '10.170.30.79:80'
os.environ['S3_USE_HTTPS'] = '0'
os.environ['ACCESS_KEY_ID'] = 'l00609438'
os.environ['SECRET_ACCESS_KEY'] = '9c24d3232bb14e188ca6e1757f7af470'
import moxing as mox
import numpy as np

BASE = 'obs://yw-2030-gy/data/opensource/inclusionAI-OpenAoE-2000h/'
sample = 'aoe_20260131_193028_p000'

# 1) 列出样本内所有文件
files = mox.file.list_directory(BASE + sample, recursive=True)
files = [f for f in files if f != '.ms_upload_cache']
print(files)

# 2) 读取 video_info（容错）
mox.file.copy(BASE + sample + '/video_info.json', '/tmp/vi.json')
vi = json.load(open('/tmp/vi.json'))
brand = vi.get('deviceInfo', {}).get('brand')
fx = vi.get('cameraParams', {}).get('fx_pixels')
dist = json.loads(vi.get('cameraParams', {}).get('lensDistortion', '[]'))

# 3) 读取动作标注
mox.file.copy(BASE + sample + '/ego_annotation/ego_action_annotation.json', '/tmp/ann.json')
ann = json.load(open('/tmp/ann.json'))
for seg in ann:
    sf, ef = int(seg['start_frame']), int(seg['end_frame'])
    for aa in seg['atomic_action']:
        verb, hand, bbox = aa['verb'], aa['hand'], aa['bbox']  # bbox=[x1,y1,x2,y2]

# 4) 读取相机轨迹与手部重建
mox.file.copy(BASE + sample + '/ego_process/ego_hands_reconstruction/camera_traj.npz', '/tmp/ct.npz')
mox.file.copy(BASE + sample + '/ego_process/ego_hands_reconstruction/hands.npz', '/tmp/hd.npz')
ct = np.load('/tmp/ct.npz')
hd = np.load('/tmp/hd.npz')
N = ct['cam_c2w'].shape[0]            # 视频帧数
intrinsic = ct['intrinsic']           # (3,3)
hand_trans = hd['pred_trans']         # (2, N, 3) 世界系双手平移
hand_valid = hd['pred_valid']         # (2, N) 有效性
```

---

## 9. 备注 / 待确认

- `aoe_*` 与 `raw_*` 在数据内容上等价，`aoe_*` 数量少（59），疑为精选/早期批次；`raw_*` 为主体。两者可统一处理。
- IMU 原始数据（`.mcap`）**不在本数据集中**（`video_info.json` 仅含 IMU 元信息与远端路径引用）。
- `raw_*` 命名中 `seg_` 后的大整数（如 `304529`）含义未完全确认，疑似全局段编号；小整数（1,2,3…）为同源切片序号。不影响按目录加载。
- `hands_combined.mp4` 帧数减半原因未官方说明，按可视化处理即可。
- 部分目录 `video_info.json` 中 `fps` 字段缺失或与实际不符，**以 ffprobe `avg_frame_rate` 为准**。

# MotusV2

Trimodal UniDiffuser for robot manipulation: jointly generates video and action
predictions conditioned on a first frame, language instructions, and VLM features
(WAN 5B video + Qwen3-VL 2B + DiT action expert). See [CLAUDE.md](CLAUDE.md) for
the full architecture, training commands, and conventions.

## Repository layout

| Path | Contents |
|------|----------|
| `models/` | Model modules (`motus_wan_vlm_direct_mask`, `wan_model_mask`, `action_expert`, `qwen3_module_wan`) |
| `data/` | Dataset adapters + registry (`dataset.py`) and per-dataset modules (`droid/`, `g1d/`, `egodex/`, `xperience/`, `human/`, `robotwin2/`, `lerobot/`, ...) |
| `train/` | Training entry point (`train_wan_vlm_mask.py`) and validation (`sample.py`) |
| `configs/` | OmegaConf training configs (see `configs/README.md`); `configs/motusv1_adapted/` holds MotusV1-derived configs |
| `scripts/` | Training launchers (`train_ADS_MotusV2_*.sh`), T5 cache prepopulation, diagnostics, visualization |
| `utils/` | Shared utilities (VLM, scheduler, motion tokenizer, common) |
| `bak/wan/` | Vendored original WAN 2.2 backbone (imported by model code; do not modify) |
| `FastWAM-main/` | Vendored FastWAM eval/deploy harness (LIBERO / RoboTwin) |
| `docs/` | Documentation (see below) |

## Documentation (`docs/`)

| Path | Contents |
|------|----------|
| `docs/changelog_vs_main/` | Dated change logs vs upstream `MotusV2-main`, plus review reports |
| `docs/session_logs/` | Dated working-session logs (`session_log_YYYYMMDD_*.md`) |
| `docs/notes/` | Design / analysis notes (VLM architecture, unified-EEF goals, task reweight) |
| `docs/eval_results/` | Task success-rate CSVs/summaries (WanVlmMask robot+human FTRT qpos) |
| `docs/reference/` | Reference material (`ms-swift-ref/`, `RoboLab/`) |

## Quick start

```bash
# Fine-tune on RoboTwin
bash scripts/train_ADS_MotusV2_robotwin.sh

# Fine-tune on DROID (T-shape 3-camera stitch)
bash scripts/train_ADS_MotusV2_droid.sh

# Fine-tune on G1-D (Unitree G1 Dex1). Prepopulate the T5 cache first:
python scripts/prepopulate_g1d_t5_cache.py --config configs/g1d_pick_kettle_wan_vlm_mask.yaml
bash scripts/train_ADS_MotusV2_g1d.sh
```

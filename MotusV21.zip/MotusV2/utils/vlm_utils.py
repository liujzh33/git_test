# VLM Utilities
# Simple functions for VLM data preprocessing

import torch
from qwen_vl_utils import process_vision_info
from typing import List, Dict, Any, Tuple, Optional
import logging

logger = logging.getLogger(__name__)


def preprocess_vlm_messages(text_instruction: str, image_pil, processor):
    """
    Complete VLM preprocessing - create messages, process vision, and get final inputs.

    Args:
        text_instruction: Robot task instruction
        image_pil: PIL Image object
        processor: VLM processor (AutoProcessor)

    Returns:
        VLM inputs ready for model forward
    """
    # Create VLM messages format
    messages = [
        {
            "role": "user",
            "content": [
                {"type": "image", "image": image_pil},
                {"type": "text", "text": text_instruction}
            ]
        }
    ]

    # Apply chat template
    text = processor.apply_chat_template(
        messages, tokenize=False, add_generation_prompt=True
    )

    # Process vision info
    image_inputs, video_inputs = process_vision_info(messages)

    # Get final processor inputs
    inputs = processor(
        text=[text],
        images=image_inputs,
        videos=video_inputs,
        padding=True,
        return_tensors="pt",
    )

    return inputs


def preprocess_vlm_messages_with_motion_tokens(
    text_instruction: str,
    image_pil,
    processor,
    left_motion_token_str: str,
    right_motion_token_str: str,
):
    """
    VLM preprocessing with motion token assistant response for next-token prediction.

    Builds a full prompt+response sequence where the assistant response contains
    discretized 3D wrist motion trajectories as special motion tokens. Constructs
    labels with -100 masking for user tokens so only assistant tokens contribute
    to the cross-entropy loss.

    Args:
        text_instruction: Robot task instruction
        image_pil: PIL Image object
        processor: VLM processor (extended-vocab AutoProcessor with motion tokens)
        left_motion_token_str: Concatenated motion tokens for left hand
            (e.g. "<|motion_x_0000|><|motion_y_0512|>...")
        right_motion_token_str: Concatenated motion tokens for right hand

    Returns:
        Dict with VLM inputs plus 'labels' tensor [1, seq_len]
    """
    # Build messages with assistant response containing motion tokens.
    # Review Blocker-1/2: downstream MoT needs to know which tokens are the
    # ground-truth assistant response so action attention can be blocked from
    # seeing them and VLM MoT attention can stay causal.
    messages = [
        {
            "role": "user",
            "content": [
                {"type": "image", "image": image_pil},
                {
                    "type": "text",
                    "text": (
                        f"Task: {text_instruction}\n"
                        "Predict the 3D wrist motion trajectories for both hands "
                        "in the robot base coordinate system. Return only motion tokens."
                    ),
                },
            ],
        },
        {
            "role": "assistant",
            "content": (
                f"Left:{left_motion_token_str}Right:{right_motion_token_str}"
            ),
        },
    ]

    # Apply chat template WITHOUT generation prompt (response included)
    text = processor.apply_chat_template(
        messages, tokenize=False, add_generation_prompt=False
    )

    # Process vision info
    image_inputs, video_inputs = process_vision_info(messages)

    # Get final processor inputs
    inputs = processor(
        text=[text],
        images=image_inputs,
        videos=video_inputs,
        padding=True,
        return_tensors="pt",
    )

    # Construct labels for next-token prediction: labels[t] = input_ids[t+1]
    # Mask user tokens with -100, only assistant response tokens have real labels.
    input_ids = inputs["input_ids"]  # [1, seq_len]
    # Shift: label at position t is the token at position t+1
    labels = torch.full_like(input_ids, -100)
    labels[0, :-1] = input_ids[0, 1:]  # labels[t] = input_ids[t+1]

    # Find the assistant response start position
    # Qwen3 chat template: ...<|im_start|>assistant\n{response}<|im_end|>\n
    # We need to find where "<|im_start|>assistant\n" ends
    tokenizer = processor.tokenizer if hasattr(processor, "tokenizer") else processor
    assistant_start_ids = tokenizer.encode(
        "<|im_start|>assistant\n", add_special_tokens=False
    )

    # Search for the assistant marker in input_ids
    ids_list = input_ids[0].tolist()
    assistant_start_len = len(assistant_start_ids)
    assistant_pos = None
    for i in range(len(ids_list) - assistant_start_len + 1):
        if ids_list[i : i + assistant_start_len] == assistant_start_ids:
            assistant_pos = i + assistant_start_len  # First token of response
            break

    assistant_token_mask = torch.zeros_like(input_ids, dtype=torch.bool)
    assistant_loss_mask = torch.zeros_like(input_ids, dtype=torch.bool)

    if assistant_pos is None:
        logger.warning("Could not find assistant response marker, masking all labels")
        labels.fill_(-100)
    else:
        # Mask everything before assistant response with -100
        # The label at position t predicts token t+1, so the first
        # assistant token label is at position assistant_pos-1 (predicting the
        # first response token). But we want to start from the first response
        # token being predicted, which means label at assistant_pos predicts
        # token at assistant_pos+1.
        # Actually: we want labels[t] to be the target for hidden state at t.
        # The first meaningful target is the first response token, which is at
        # assistant_pos. The hidden state that predicts it is at assistant_pos-1.
        # So we keep labels starting from assistant_pos-1.
        labels[0, :assistant_pos - 1] = -100

        # Mark response tokens, excluding right padding if any. The mask is used
        # by MoT to prevent Action from attending to ground-truth assistant
        # tokens (review Blocker-1), while still allowing user/image tokens.
        attention_mask = inputs.get("attention_mask")
        if attention_mask is not None:
            valid_len = int(attention_mask[0].sum().item())
        else:
            valid_len = input_ids.shape[1]
        assistant_token_mask[0, assistant_pos:valid_len] = True
        assistant_loss_mask[0] = labels[0] != -100

    inputs["labels"] = labels
    inputs["assistant_token_mask"] = assistant_token_mask
    inputs["assistant_loss_mask"] = assistant_loss_mask
    return inputs


def preprocess_vlm_messages_motion_prompt_only(
    text_instruction: str,
    image_pil,
    processor,
):
    """
    VLM preprocessing for motion-token runs without the ground-truth assistant
    response.

    Review Blocker-1/3: validation and inference must not receive assistant
    motion tokens derived from the target action sequence. This keeps the same
    user prompt as preprocess_vlm_messages_with_motion_tokens() but uses a
    generation prompt only.
    """
    messages = [
        {
            "role": "user",
            "content": [
                {"type": "image", "image": image_pil},
                {
                    "type": "text",
                    "text": (
                        f"Task: {text_instruction}\n"
                        "Predict the 3D wrist motion trajectories for both hands "
                        "in the robot base coordinate system. Return only motion tokens."
                    ),
                },
            ],
        }
    ]

    text = processor.apply_chat_template(
        messages, tokenize=False, add_generation_prompt=True
    )
    image_inputs, video_inputs = process_vision_info(messages)
    return processor(
        text=[text],
        images=image_inputs,
        videos=video_inputs,
        padding=True,
        return_tensors="pt",
    )

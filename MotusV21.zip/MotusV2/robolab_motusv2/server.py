"""Small pickle-over-HTTP MotusV2 policy server for RoboLab.

``POST /infer`` with a pickled request dict returns a pickled
``{"actions": np.ndarray}`` response.  ``GET /health`` reports whether the
model is loaded.  ``POST /sanity`` returns preprocessing summary without
running the model.  This keeps Isaac/RoboLab and the heavy MotusV2 model
runtime in separate processes.
"""

from __future__ import annotations

import argparse
import logging
import pickle
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

from .adapter import (
    DroidInferenceContract,
    MotusV2DroidJointposPolicy,
    find_missing_runtime_assets,
    resolve_runtime_assets,
    summarize_request,
)

logger = logging.getLogger(__name__)


class _State:
    policy: MotusV2DroidJointposPolicy | None = None
    contract: DroidInferenceContract | None = None
    assets: dict[str, str] = {}
    missing_assets: dict[str, str] = {}
    mode: str = "unloaded"


def _write_pickle(handler: BaseHTTPRequestHandler, status: int, payload: dict[str, Any]) -> None:
    body = pickle.dumps(payload, protocol=pickle.HIGHEST_PROTOCOL)
    handler.send_response(status)
    handler.send_header("Content-Type", "application/octet-stream")
    handler.send_header("Content-Length", str(len(body)))
    handler.end_headers()
    handler.wfile.write(body)


class MotusV2Handler(BaseHTTPRequestHandler):
    server_version = "MotusV2RoboLab/0.2"

    def do_GET(self) -> None:  # noqa: N802
        if self.path != "/health":
            _write_pickle(self, 404, {"ok": False, "error": "not found"})
            return
        _write_pickle(
            self,
            200,
            {
                "ok": _State.policy is not None,
                "contract": _State.contract.__dict__ if _State.contract is not None else None,
                "assets": _State.assets,
                "missing_assets": _State.missing_assets,
                "mode": _State.mode,
            },
        )

    def do_POST(self) -> None:  # noqa: N802
        if self.path not in ("/infer", "/sanity"):
            _write_pickle(self, 404, {"ok": False, "error": "not found"})
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            request = pickle.loads(self.rfile.read(length))
            if self.path == "/sanity":
                if _State.contract is None:
                    raise RuntimeError("server contract is not initialized")
                _write_pickle(self, 200, {"ok": True, "summary": summarize_request(request, _State.contract)})
                return
            if _State.policy is None:
                raise RuntimeError("policy is not loaded")
            actions = _State.policy.infer_chunk(request)
            _write_pickle(self, 200, {"ok": True, "actions": actions})
        except Exception as exc:
            logger.exception("Request failed")
            _write_pickle(self, 500, {"ok": False, "error": str(exc), "traceback": traceback.format_exc()})

    def log_message(self, fmt: str, *args: Any) -> None:
        logger.info("%s - %s", self.address_string(), fmt % args)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Serve MotusV2 DROID qpos policy for RoboLab.")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8020)
    parser.add_argument("--checkpoint-path", default="/home/work/wenjj/ckpt/MotusV2Droid_v2_3W")
    parser.add_argument("--config-path", default=str(Path(__file__).resolve().parents[1] / "configs/droid_wan_vlm_mask_stage2_15w.yaml"))
    parser.add_argument("--wan-path", default=None)
    parser.add_argument("--vlm-path", default=None)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--dtype", default="bfloat16")
    parser.add_argument("--t5-device", default=None, help="Optional separate device for the UMT5 text encoder.")
    parser.add_argument("--check-assets", action="store_true", help="Validate required assets and exit without serving.")
    return parser


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    args = build_parser().parse_args()
    _State.contract = DroidInferenceContract.from_config(args.config_path)
    _State.assets = {
        name: str(path)
        for name, path in resolve_runtime_assets(
            checkpoint_path=args.checkpoint_path,
            config_path=args.config_path,
            wan_path=args.wan_path,
            vlm_path=args.vlm_path,
        ).items()
    }
    _State.missing_assets = find_missing_runtime_assets(
        checkpoint_path=args.checkpoint_path,
        config_path=args.config_path,
        wan_path=args.wan_path,
        vlm_path=args.vlm_path,
    )
    if args.check_assets:
        if _State.missing_assets:
            for name, path in _State.missing_assets.items():
                logger.error("missing %s: %s", name, path)
            raise SystemExit(1)
        logger.info("All MotusV2 runtime assets exist. Contract: %s", _State.contract)
        return
    _State.policy = MotusV2DroidJointposPolicy(
        checkpoint_path=args.checkpoint_path,
        config_path=args.config_path,
        wan_path=args.wan_path,
        vlm_path=args.vlm_path,
        device=args.device,
        dtype=args.dtype,
        t5_device=args.t5_device,
    )
    _State.mode = "motusv2"
    httpd = ThreadingHTTPServer((args.host, args.port), MotusV2Handler)
    logger.info("MotusV2 policy server listening on http://%s:%d", args.host, args.port)
    httpd.serve_forever()


if __name__ == "__main__":
    main()

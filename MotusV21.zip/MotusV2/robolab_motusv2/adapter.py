"""MotusV2 DROID qpos inference adapter for RoboLab observations.

This module keeps RoboLab/Isaac out of the MotusV2 process.  The public policy
class accepts plain numpy arrays and returns a denoised MotusV2 action chunk in
the same 8D joint-position action space used by RoboLab's
``DroidJointPositionActionCfg``:

    [panda_joint1..7, gripper], gripper 0=open and 1=close.

Visual contract (MUST match training ``data/droid/droid_lerobot_dataset.py``):
  camera_layout == "t_shape" (current DROID config):
      top          : exterior_2_left  (full width)
      bottom-left  : exterior_1_left  (half width)
      bottom-right : wrist_left        (half width)
    Each camera is resized ONCE (aspect-ratio-preserving, cv2 INTER_LINEAR) into
    its sub-region; the T canvas (natural height) is vertically center-padded to
    ``video_height`` (288).  This mirrors ``_stitch_t_shape`` exactly.
  Legacy "horizontal"/"vertical" 2-camera layouts are also supported for the
  older checkpoints.
"""

from __future__ import annotations

import logging
import os
import sys
from collections import OrderedDict
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

logger = logging.getLogger(__name__)


def _np():
    import numpy as np

    return np


@dataclass(frozen=True)
class DroidInferenceContract:
    action_dim: int
    state_dim: int
    num_video_frames: int
    video_height: int
    video_width: int
    video_action_freq_ratio: int
    global_downsample_rate: int
    action_chunk_size: int
    camera_layout: str
    # Legacy 2-camera keys.
    exterior_camera_key: str
    wrist_camera_key: str
    # 3-camera T-shape keys.
    top_camera_key: str
    bottom_left_camera_key: str
    bottom_right_camera_key: str
    instruction_field: str
    num_inference_timesteps: int
    t5_text_len: int
    # Action/state normalization contract — must match the training dataset.
    # See data/droid/droid_norm.py.
    action_normalization: bool
    norm_stats_path: str
    # T5 precision must match the one the language cache was built with; see
    # data/__init__.py::get_global_t5_encoder.
    t5_precision: str

    @classmethod
    def from_config(cls, config_path: str | os.PathLike[str]) -> "DroidInferenceContract":
        with open(config_path, "r", encoding="utf-8") as f:
            cfg = yaml.safe_load(f)
        common = cfg["common"]
        dataset = cfg["dataset"]
        model = cfg["model"]
        action_chunk_size = int(common["num_video_frames"]) * int(common["video_action_freq_ratio"])
        default_stats = str(_repo_root() / "data" / "droid" / "droid_norm_stats.json")
        return cls(
            action_dim=int(common["action_dim"]),
            state_dim=int(common["state_dim"]),
            num_video_frames=int(common["num_video_frames"]),
            video_height=int(common["video_height"]),
            video_width=int(common["video_width"]),
            video_action_freq_ratio=int(common["video_action_freq_ratio"]),
            global_downsample_rate=int(common["global_downsample_rate"]),
            action_chunk_size=action_chunk_size,
            camera_layout=str(dataset.get("camera_layout", "t_shape")),
            exterior_camera_key=str(dataset.get("exterior_camera_key", "observation.images.exterior_1_left")),
            wrist_camera_key=str(dataset.get("wrist_camera_key", "observation.images.wrist_left")),
            top_camera_key=str(dataset.get("top_camera_key", "observation.images.exterior_2_left")),
            bottom_left_camera_key=str(dataset.get("bottom_left_camera_key", "observation.images.exterior_1_left")),
            bottom_right_camera_key=str(dataset.get("bottom_right_camera_key", "observation.images.wrist_left")),
            instruction_field=str(dataset.get("instruction_field", "language_instruction")),
            num_inference_timesteps=int(model.get("inference", {}).get("num_inference_timesteps", 10)),
            t5_text_len=int(dataset.get("t5_text_len", 512)),
            action_normalization=bool(dataset.get("action_normalization", True)),
            norm_stats_path=str(dataset.get("norm_stats_path") or default_stats),
            t5_precision=str(dataset.get("t5_precision", "float32")),
        )


def resolve_runtime_assets(
    *,
    checkpoint_path: str,
    config_path: str,
    wan_path: str | None = None,
    vlm_path: str | None = None,
) -> dict[str, Path]:
    """Resolve the files/directories required before constructing the model."""
    with open(config_path, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    model_cfg = cfg["model"]
    resolved_checkpoint = Path(checkpoint_path)
    checkpoint_file = (
        resolved_checkpoint / "mp_rank_00_model_states.pt"
        if resolved_checkpoint.is_dir() or not resolved_checkpoint.suffix
        else resolved_checkpoint
    )
    resolved_wan = Path(wan_path or model_cfg["wan"]["checkpoint_path"])
    resolved_vlm = Path(vlm_path or model_cfg["vlm"]["checkpoint_path"])
    assets = {
        "checkpoint_path": resolved_checkpoint,
        "checkpoint_file": checkpoint_file,
        "wan_path": resolved_wan,
        "wan_vae": resolved_wan / "Wan2.2_VAE.pth",
        "wan_t5": resolved_wan / "models_t5_umt5-xxl-enc-bf16.pth",
        "wan_t5_tokenizer": resolved_wan / "google" / "umt5-xxl",
        "vlm_path": resolved_vlm,
    }
    # Serving a normalized checkpoint without its stats file would silently
    # produce garbage actions, so make it a /health-visible required asset.
    contract = DroidInferenceContract.from_config(config_path)
    if contract.action_normalization:
        assets["norm_stats"] = Path(contract.norm_stats_path)
    return assets


def find_missing_runtime_assets(
    *,
    checkpoint_path: str,
    config_path: str,
    wan_path: str | None = None,
    vlm_path: str | None = None,
) -> dict[str, str]:
    """Return missing runtime assets keyed by logical name."""
    assets = resolve_runtime_assets(
        checkpoint_path=checkpoint_path,
        config_path=config_path,
        wan_path=wan_path,
        vlm_path=vlm_path,
    )
    return {name: str(path) for name, path in assets.items() if not path.exists()}


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def _ensure_repo_imports() -> None:
    root = str(_repo_root())
    bak = str((_repo_root() / "bak").resolve())
    for path in (root, bak):
        if path not in sys.path:
            sys.path.insert(0, path)
    for path in os.environ.get("MOTUS_EXTRA_SITE_PACKAGES", "").split(os.pathsep):
        if path and path not in sys.path:
            sys.path.append(path)


def _as_rgb_uint8(image: Any, *, name: str) -> "np.ndarray":
    np = _np()
    arr = np.asarray(image)
    if arr.ndim != 3 or arr.shape[-1] < 3:
        raise ValueError(f"{name} must be HWC RGB-like, got shape={arr.shape}")
    arr = arr[..., :3]
    if arr.dtype != np.uint8:
        if arr.max(initial=0) <= 1.0:
            arr = arr * 255.0
        arr = np.clip(arr, 0, 255).astype(np.uint8)
    return np.ascontiguousarray(arr)


def build_stitched_first_frame(
    images: list,
    contract: DroidInferenceContract,
) -> "np.ndarray":
    """Lay the cameras out exactly as the training dataset does.

    ``images`` are raw HWC RGB frames in slot order.  Returns HWC float32 in
    [0,1] at (video_height, video_width).  The geometry itself lives in
    ``data/droid/droid_stitch.py``, shared with the dataset.
    """
    np = _np()
    from data.droid.droid_stitch import stitch_frame

    canvas = stitch_frame(
        contract.camera_layout, images, contract.video_height, contract.video_width
    )
    return canvas.astype(np.float32) / 255.0


def _resize_with_padding(frame: "np.ndarray", target_size: tuple[int, int]) -> "np.ndarray":
    """Legacy aspect-ratio-preserving resize + black padding (2-camera layouts)."""
    np = _np()
    import cv2

    target_h, target_w = target_size
    h, w = frame.shape[:2]
    scale = min(target_h / h, target_w / w)
    new_h = max(1, int(h * scale))
    new_w = max(1, int(w * scale))
    resized = cv2.resize(frame, (new_w, new_h))
    out = np.zeros((target_h, target_w, frame.shape[2]), dtype=frame.dtype)
    y = (target_h - new_h) // 2
    x = (target_w - new_w) // 2
    out[y:y + new_h, x:x + new_w] = resized
    return out


def build_droid_horizontal_first_frame(
    exterior_image: Any,
    wrist_image: Any,
    contract: DroidInferenceContract,
) -> "np.ndarray":
    """Legacy 2-camera vertical/horizontal stitch (older checkpoints)."""
    np = _np()
    size = (contract.video_height, contract.video_width)
    ext = _resize_with_padding(_as_rgb_uint8(exterior_image, name="exterior_image"), size)
    wrist = _resize_with_padding(_as_rgb_uint8(wrist_image, name="wrist_image"), size)
    if contract.camera_layout == "vertical":
        stitched = np.concatenate([ext, wrist], axis=0)
    else:
        stitched = np.concatenate([ext, wrist], axis=1)
    return _resize_with_padding(stitched, size).astype(np.float32) / 255.0


# RoboLab request keys feeding each layout slot, in slot order.
LAYOUT_REQUEST_KEYS = {
    "v_stack": ("exterior_image", "wrist_image"),
    "t_shape": ("top_image", "bottom_left_image", "bottom_right_image"),
}


def build_first_frame(request: dict[str, Any], contract: DroidInferenceContract) -> "np.ndarray":
    """Build the single MotusV2 condition frame HWC float32 in [0,1] per layout."""
    keys = LAYOUT_REQUEST_KEYS.get(contract.camera_layout)
    if keys is not None:
        missing = [k for k in keys if request.get(k) is None]
        if missing:
            raise ValueError(
                f"camera_layout={contract.camera_layout!r} needs {list(keys)}; "
                f"missing {missing} in the request"
            )
        return build_stitched_first_frame(
            [_as_rgb_uint8(request[k], name=k) for k in keys], contract
        )
    return build_droid_horizontal_first_frame(
        request["exterior_image"],
        request["wrist_image"],
        contract,
    )


def build_droid_state(joint_position: Any, gripper_position: Any) -> "np.ndarray":
    np = _np()
    joints = np.asarray(joint_position, dtype=np.float32).reshape(-1)
    gripper = np.asarray(gripper_position, dtype=np.float32).reshape(-1)
    if joints.shape[0] != 7:
        raise ValueError(f"joint_position must have 7 values, got shape={joints.shape}")
    if gripper.shape[0] < 1:
        raise ValueError("gripper_position must contain at least one value")
    return np.concatenate([joints, gripper[:1]], axis=0).astype(np.float32)


class MotusV2DroidJointposPolicy:
    """Loads a MotusV2 DROID checkpoint and returns 8D qpos action chunks."""

    def __init__(
        self,
        *,
        checkpoint_path: str,
        config_path: str,
        wan_path: str | None = None,
        vlm_path: str | None = None,
        device: str = "cuda",
        dtype: str = "bfloat16",
        t5_device: str | None = None,
        t5_cache_size: int = 256,
    ) -> None:
        _ensure_repo_imports()
        self.checkpoint_path = str(checkpoint_path)
        self.config_path = str(config_path)
        self.contract = DroidInferenceContract.from_config(config_path)
        if self.contract.action_dim != 8 or self.contract.state_dim != 8:
            raise ValueError(f"DROID adapter requires 8D action/state, got {self.contract}")
        self.device = device
        self.t5_device = t5_device or device
        self.dtype_name = dtype

        with open(config_path, "r", encoding="utf-8") as f:
            self.config_dict = yaml.safe_load(f)
        model_cfg = self.config_dict["model"]
        self.wan_path = str(wan_path or model_cfg["wan"]["checkpoint_path"])
        self.vlm_path = str(vlm_path or model_cfg["vlm"]["checkpoint_path"])
        self._validate_runtime_paths()

        import torch
        from models.motus_wan_vlm_direct_mask import MotusWanVlmDirectMask, MotusWanVlmDirectMaskConfig
        from transformers import AutoProcessor
        from wan.modules.t5 import T5EncoderModel

        self.torch = torch
        self.dtype = getattr(torch, dtype)
        common = self.config_dict["common"]
        action_expert = model_cfg["action_expert"]
        qwen3_expert = model_cfg["qwen3_expert"]
        model_config = MotusWanVlmDirectMaskConfig(
            wan_checkpoint_path=self.wan_path,
            vae_path=str(Path(self.wan_path) / "Wan2.2_VAE.pth"),
            wan_config_path=self.wan_path,
            video_precision=dtype,
            vlm_checkpoint_path=self.vlm_path,
            vlm_dim=int(qwen3_expert["vlm_dim"]),
            qwen3_expert_head_dim=int(qwen3_expert["head_dim"]),
            qwen3_expert_num_heads=int(qwen3_expert["num_heads"]),
            qwen3_expert_num_layers=int(qwen3_expert["num_layers"]),
            qwen3_expert_norm_eps=float(qwen3_expert["norm_eps"]),
            num_layers=int(model_cfg.get("num_layers", 30)),
            action_state_dim=int(common["state_dim"]),
            action_dim=int(common["action_dim"]),
            action_expert_dim=int(action_expert["hidden_size"]),
            action_expert_ffn_dim_multiplier=int(action_expert["ffn_dim_multiplier"]),
            action_expert_norm_eps=float(action_expert["norm_eps"]),
            global_downsample_rate=int(common["global_downsample_rate"]),
            video_action_freq_ratio=int(common["video_action_freq_ratio"]),
            num_video_frames=int(common["num_video_frames"]),
            video_loss_weight=1.0,
            action_loss_weight=1.0,
            batch_size=1,
            video_height=int(common["video_height"]),
            video_width=int(common["video_width"]),
            training_mode=str(model_cfg.get("training_mode", "finetune")),
            load_pretrained_backbones=False,
            vlm_frozen=False,
        )
        self._verify_checkpoint_contract()

        self.model = MotusWanVlmDirectMask(model_config).to(device)
        self.model.load_checkpoint(self.checkpoint_path, strict=False)
        self.model.eval()

        # Inverse of the training-time state/action transform.  Loaded from the
        # same stats file and the same code path the dataset uses.
        self.normalizer = None
        if self.contract.action_normalization:
            from data.droid.droid_norm import DroidNormalizer

            self.normalizer = DroidNormalizer.from_stats_file(self.contract.norm_stats_path)
            logger.info("Action normalization ON (stats: %s)", self.contract.norm_stats_path)
        else:
            logger.warning(
                "Action normalization OFF: serving a raw-absolute-qpos checkpoint. "
                "This matches the legacy training setting only."
            )

        # T5 runs at the precision the training cache was built with, which is
        # independent of the policy dtype: fp32 costs ~21 GB instead of ~11 GB
        # but is the only way the batched cache and this one-at-a-time call
        # produce the same embedding.
        self.t5_dtype = getattr(torch, self.contract.t5_precision)
        logger.info("T5 encoder precision: %s", self.contract.t5_precision)
        self.t5_encoder = T5EncoderModel(
            text_len=self.contract.t5_text_len,
            dtype=self.t5_dtype,
            device=self.t5_device,
            checkpoint_path=str(Path(self.wan_path) / "models_t5_umt5-xxl-enc-bf16.pth"),
            tokenizer_path=str(Path(self.wan_path) / "google" / "umt5-xxl"),
        )
        self.vlm_processor = AutoProcessor.from_pretrained(self.vlm_path, trust_remote_code=True)
        # A RoboLab run touches at most a few dozen distinct instructions and each
        # entry is only a few hundred KB, so this never grows meaningfully.
        self._t5_cache: "OrderedDict[str, Any]" = OrderedDict()
        self._t5_cache_max = int(t5_cache_size)
        logger.info("Loaded MotusV2 DROID policy: %s", self.contract)

    def _verify_checkpoint_contract(self) -> None:
        """Refuse to serve a checkpoint whose action space differs from the config.

        A raw-absolute-qpos checkpoint served under a normalized config (or vice
        versa) still returns numerically plausible joint angles, so the mistake
        only shows up as a mysteriously low success rate.  Training writes
        ``config.json`` next to the weights; cross-check it when present.
        """
        import json

        ckpt_dir = Path(self.checkpoint_path)
        if not ckpt_dir.is_dir():
            ckpt_dir = ckpt_dir.parent
        cfg_file = ckpt_dir / "config.json"
        if not cfg_file.exists():
            logger.warning(
                "No config.json next to %s; cannot verify the checkpoint's action "
                "space. Ensure it was trained with dataset.action_normalization=%s.",
                self.checkpoint_path,
                self.contract.action_normalization,
            )
            return
        try:
            with open(cfg_file, "r", encoding="utf-8") as f:
                trained = json.load(f)
        except Exception as exc:  # noqa: BLE001
            logger.warning("Could not read %s: %s", cfg_file, exc)
            return
        trained_ds = trained.get("dataset", {})
        trained_norm = trained_ds.get("action_normalization")
        if trained_norm is None:
            logger.warning(
                "%s predates the action-space contract; assuming it matches "
                "dataset.action_normalization=%s.",
                cfg_file, self.contract.action_normalization,
            )
            return
        if bool(trained_norm) != bool(self.contract.action_normalization):
            raise ValueError(
                f"Action-space mismatch: checkpoint {self.checkpoint_path} was trained "
                f"with action_normalization={trained_norm}, but it is being served with "
                f"action_normalization={self.contract.action_normalization} "
                f"(config: {self.config_path}). Serving this combination silently "
                f"produces wrong joint targets."
            )
        # The language cache the model was trained against was built at a
        # specific T5 precision; encoding at a different one here shifts every
        # instruction embedding by ~20% relative without any visible error.
        trained_t5 = trained_ds.get("t5_precision")
        if trained_t5 is not None and str(trained_t5) != self.contract.t5_precision:
            raise ValueError(
                f"T5 precision mismatch: checkpoint {self.checkpoint_path} was trained "
                f"against a t5_precision={trained_t5} language cache, but it is being "
                f"served with t5_precision={self.contract.t5_precision} "
                f"(config: {self.config_path})."
            )
        logger.info(
            "Checkpoint contract verified (action_normalization=%s, t5_precision=%s)",
            trained_norm, trained_t5 or "<unrecorded>",
        )

    def _validate_runtime_paths(self) -> None:
        missing_by_name = find_missing_runtime_assets(
            checkpoint_path=self.checkpoint_path,
            config_path=self.config_path,
            wan_path=self.wan_path,
            vlm_path=self.vlm_path,
        )
        missing = list(missing_by_name.values())
        if missing:
            raise FileNotFoundError("Missing MotusV2 runtime assets:\n  " + "\n  ".join(missing))

    def _encode_t5(self, instruction: str):
        """Encode one instruction, memoised across calls.

        An episode re-sends the same instruction with every action chunk -- ~450
        times per 90 s episode -- and UMT5-XXL costs ~100 ms per call on GPU
        (~9 s on CPU), about 20% of a chunk's inference time. The result depends
        only on the text, so caching it is exact, and it is what makes serving
        T5 from CPU practical: the encoder then runs once per distinct
        instruction instead of once per chunk.
        """
        torch = self.torch
        cached = self._t5_cache.get(instruction)
        if cached is not None:
            self._t5_cache.move_to_end(instruction)
            # Fresh list per call so a caller cannot mutate the cached entry.
            return [cached]

        with torch.no_grad():
            out = self.t5_encoder([instruction], self.t5_device)
        if isinstance(out, torch.Tensor):
            emb = out.squeeze(0) if out.ndim == 3 else out
        elif isinstance(out, list):
            emb = out[0]
        else:
            raise TypeError(f"Unexpected T5 encoder output: {type(out)}")
        emb = emb.to(self.device).to(self.dtype)

        self._t5_cache[instruction] = emb
        if len(self._t5_cache) > self._t5_cache_max:
            self._t5_cache.popitem(last=False)
        logger.info("T5 encoded %r (cache: %d/%d)",
                    instruction[:48], len(self._t5_cache), self._t5_cache_max)
        return [emb]

    def _build_vlm_inputs(self, instruction: str, first_frame_chw):
        from PIL import Image
        from utils.vlm_utils import preprocess_vlm_messages

        arr = (
            first_frame_chw.detach()
            .cpu()
            .float()
            .clamp(0, 1)
            .permute(1, 2, 0)
            .numpy()
        )
        first_pil = Image.fromarray((arr * 255.0).astype("uint8"), mode="RGB")
        inputs = preprocess_vlm_messages(instruction, first_pil, self.vlm_processor)
        return {
            key: value.to(self.device) if hasattr(value, "to") else value
            for key, value in inputs.items()
        }

    def _maybe_dump_first_frame(self, request: dict[str, Any], frame_hwc) -> None:
        """One-shot debug dump of the stitched model input + raw cameras.

        Enabled by setting MOTUS_DUMP_DIR. Purely diagnostic; no effect on
        inference. Lets a reviewer confirm the live T-shape camera mapping.
        """
        dump_dir = os.environ.get("MOTUS_DUMP_DIR")
        if not dump_dir or getattr(self, "_dumped", False):
            return
        try:
            np = _np()
            from PIL import Image

            os.makedirs(dump_dir, exist_ok=True)
            Image.fromarray((np.clip(frame_hwc, 0, 1) * 255).astype("uint8"), "RGB").save(
                os.path.join(dump_dir, "stitched_first_frame.png")
            )
            for key in ("top_image", "bottom_left_image", "bottom_right_image",
                        "exterior_image", "wrist_image"):
                if key in request and request[key] is not None:
                    Image.fromarray(_as_rgb_uint8(request[key], name=key)).save(
                        os.path.join(dump_dir, f"raw_{key}.png")
                    )
            logger.info("Dumped first-frame debug images to %s", dump_dir)
        except Exception as exc:
            logger.warning("First-frame dump failed: %s", exc)
        finally:
            self._dumped = True

    def infer_chunk(self, request: dict[str, Any]) -> "np.ndarray":
        np = _np()
        instruction = str(request.get("instruction", "")).strip()
        if not instruction:
            raise ValueError("instruction must be a non-empty string")
        frame_hwc = build_first_frame(request, self.contract)
        self._maybe_dump_first_frame(request, frame_hwc)
        raw_state = build_droid_state(request["joint_position"], request["gripper_position"])
        state_np = (
            self.normalizer.normalize_state(raw_state)
            if self.normalizer is not None
            else raw_state
        )

        torch = self.torch
        first_frame = (
            torch.from_numpy(frame_hwc)
            .permute(2, 0, 1)
            .unsqueeze(0)
            .to(self.device, dtype=self.dtype)
        )
        state = torch.from_numpy(state_np).unsqueeze(0).to(self.device, dtype=self.dtype)
        language_embeddings = self._encode_t5(instruction)
        vlm_inputs = self._build_vlm_inputs(instruction, first_frame[0])

        with torch.no_grad():
            _, predicted_actions = self.model.inference_step(
                first_frame=first_frame,
                state=state,
                num_inference_steps=self.contract.num_inference_timesteps,
                language_embeddings=language_embeddings,
                vlm_inputs=vlm_inputs,
            )
        actions = predicted_actions.squeeze(0).detach().float().cpu().numpy().astype(np.float32)
        if actions.shape != (self.contract.action_chunk_size, self.contract.action_dim):
            raise ValueError(
                f"Model returned action chunk shape {actions.shape}, "
                f"expected {(self.contract.action_chunk_size, self.contract.action_dim)}"
            )
        if self.normalizer is not None:
            # Undo q01/q99 scaling and add the raw state back on the delta dims,
            # yielding absolute joint targets in radians for RoboLab.
            actions = self.normalizer.from_model_actions(actions, raw_state)
        actions[:, -1] = (actions[:, -1] > 0.5).astype(np.float32)
        logger.info(
            "MotusV2 chunk: shape=%s joints=[%.3f, %.3f] max|Δq| vs state=%.3f grip_unique=%s",
            actions.shape,
            float(actions[:, :7].min()),
            float(actions[:, :7].max()),
            float(np.abs(actions[:, :7] - raw_state[None, :7]).max()),
            np.unique(actions[:, -1]).tolist(),
        )
        return actions


def summarize_request(request: dict[str, Any], contract: DroidInferenceContract) -> dict[str, Any]:
    frame = build_first_frame(request, contract)
    state = build_droid_state(request["joint_position"], request["gripper_position"])
    instruction = str(request.get("instruction", ""))
    return {
        "instruction_nonempty": bool(instruction.strip()),
        "camera_layout": contract.camera_layout,
        "first_frame_shape": tuple(frame.shape),
        "first_frame_dtype": str(frame.dtype),
        "first_frame_min": float(frame.min(initial=0)),
        "first_frame_max": float(frame.max(initial=0)),
        "state_shape": tuple(state.shape),
        "state_min": float(state.min(initial=0)),
        "state_max": float(state.max(initial=0)),
        "action_chunk_shape": (contract.action_chunk_size, contract.action_dim),
        "action_normalization": contract.action_normalization,
        "norm_stats_path": contract.norm_stats_path,
    }

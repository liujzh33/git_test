#!/usr/bin/env python3
"""Analyze recorded qpos-only / eef-only evaluation runs.

Answers the two questions the dual-head setup was built for:

1. Which control channel is better?  ->  per-task and overall success rates
2. Does head disagreement predict failure?  ->  point-biserial correlation
   between per-episode disagreement statistics and the success flag.

Usage::

    # single run
    python analyze_records.py --run <log_dir>/trajectories

    # head-to-head, qpos vs eef
    python analyze_records.py \
        --run <qpos_log_dir>/trajectories \
        --run <eef_log_dir>/trajectories

    # also dump a per-step CSV for finer analysis
    python analyze_records.py --run <log_dir>/trajectories --per-step-csv steps.csv

Only numpy and the standard library are required.
"""

import argparse
import csv
import json
import math
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np

# Disagreement / tracking metrics reported per episode by the recorder.
METRIC_KEYS = [
    "grip_gap_l_mean",
    "grip_gap_r_mean",
    "grip_gap_max",
    "track_err_qpos_mean",
    "track_err_qpos_max",
    "track_err_eef_pos_l_mean",
    "track_err_eef_pos_l_max",
    "track_err_eef_pos_r_mean",
    "track_err_eef_pos_r_max",
    "track_err_eef_rot_l_mean",
    "track_err_eef_rot_r_mean",
]


def load_run(run_dir: Path) -> List[Dict[str, Any]]:
    """Load every episodes.jsonl under a trajectories directory."""
    episodes: List[Dict[str, Any]] = []
    for jsonl_path in sorted(run_dir.glob("*/episodes.jsonl")):
        with open(jsonl_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    record = json.loads(line)
                except json.JSONDecodeError:
                    continue
                record.setdefault("task_name", jsonl_path.parent.name)
                record["_run_dir"] = str(run_dir)
                episodes.append(record)
    return episodes


def point_biserial(values: np.ndarray, labels: np.ndarray) -> Optional[float]:
    """Correlation between a continuous metric and a binary outcome.

    Equivalent to Pearson r with the binary variable coded 0/1.
    """
    mask = np.isfinite(values)
    values, labels = values[mask], labels[mask]
    if values.size < 3:
        return None
    if values.std() < 1e-12 or labels.std() < 1e-12:
        return None
    return float(np.corrcoef(values, labels)[0, 1])


def summarize_run(episodes: List[Dict[str, Any]], label: str) -> Dict[str, Any]:
    if not episodes:
        print(f"\n[{label}] no episodes found")
        return {}

    control_modes = sorted({e.get("control_mode", "?") for e in episodes})
    success = np.array([bool(e.get("success", False)) for e in episodes], dtype=np.float64)

    print(f"\n{'=' * 72}")
    print(f"RUN: {label}")
    print(f"{'=' * 72}")
    print(f"control_mode : {', '.join(control_modes)}")
    print(f"episodes     : {len(episodes)}")
    print(f"success rate : {success.mean() * 100:.1f}%  ({int(success.sum())}/{len(episodes)})")

    per_task: Dict[str, List[bool]] = defaultdict(list)
    for e in episodes:
        per_task[e.get("task_name", "?")].append(bool(e.get("success", False)))

    print(f"\n{'task':<40} {'n':>4} {'success':>9}")
    print("-" * 56)
    for task in sorted(per_task):
        flags = per_task[task]
        rate = 100.0 * sum(flags) / len(flags)
        print(f"{task:<40} {len(flags):>4} {rate:>8.1f}%")

    print(f"\ndisagreement vs success (point-biserial r; negative = "
          f"more disagreement, more failure)")
    print(f"{'metric':<32} {'n':>5} {'mean':>12} {'r':>8}")
    print("-" * 60)
    correlations: Dict[str, Optional[float]] = {}
    for key in METRIC_KEYS:
        raw = [e.get(key) for e in episodes]
        values = np.array(
            [np.nan if v is None else float(v) for v in raw], dtype=np.float64
        )
        finite = values[np.isfinite(values)]
        if finite.size == 0:
            continue
        r = point_biserial(values, success)
        correlations[key] = r
        r_text = "  n/a" if r is None else f"{r:+.3f}"
        print(f"{key:<32} {finite.size:>5} {finite.mean():>12.5f} {r_text:>8}")

    # Split the strongest metric by outcome, which is usually more readable
    # than the correlation alone.
    ranked = [(k, v) for k, v in correlations.items() if v is not None]
    if ranked:
        best_key = max(ranked, key=lambda kv: abs(kv[1]))[0]
        values = np.array(
            [np.nan if e.get(best_key) is None else float(e[best_key]) for e in episodes],
            dtype=np.float64,
        )
        mask = np.isfinite(values)
        succ_vals = values[mask & (success > 0.5)]
        fail_vals = values[mask & (success <= 0.5)]
        if succ_vals.size and fail_vals.size:
            print(f"\nstrongest signal: {best_key}")
            print(f"  success episodes: mean={succ_vals.mean():.5f}  n={succ_vals.size}")
            print(f"  failed  episodes: mean={fail_vals.mean():.5f}  n={fail_vals.size}")
            ratio = fail_vals.mean() / succ_vals.mean() if abs(succ_vals.mean()) > 1e-12 else float("inf")
            print(f"  fail/success ratio: {ratio:.2f}x")

    return {
        "label": label,
        "control_modes": control_modes,
        "n_episodes": len(episodes),
        "success_rate": float(success.mean()),
        "per_task": {t: (sum(v) / len(v)) for t, v in per_task.items()},
        "correlations": correlations,
    }


def compare_runs(summaries: List[Dict[str, Any]]):
    """Per-task head-to-head between two runs (typically qpos vs eef)."""
    usable = [s for s in summaries if s]
    if len(usable) < 2:
        return

    print(f"\n{'=' * 72}")
    print("HEAD-TO-HEAD")
    print(f"{'=' * 72}")

    labels = [s["label"] for s in usable]
    tasks = sorted(set().union(*[set(s["per_task"]) for s in usable]))

    header = f"{'task':<40}" + "".join(f"{lbl[:14]:>16}" for lbl in labels)
    print(header)
    print("-" * len(header))
    for task in tasks:
        row = f"{task:<40}"
        for s in usable:
            rate = s["per_task"].get(task)
            row += f"{'--':>16}" if rate is None else f"{rate * 100:>15.1f}%"
        print(row)

    print("-" * len(header))
    row = f"{'OVERALL':<40}"
    for s in usable:
        row += f"{s['success_rate'] * 100:>15.1f}%"
    print(row)


def paired_comparison(run_a: Path, run_b: Path):
    """Match episodes across two runs by (task, episode index).

    Both runs walk the same seed sequence, and the accepted-seed filtering is
    policy-independent, so episode ``i`` of a task is the same scene in both.
    That makes the per-episode union ("either channel succeeds") computable,
    which is the number that decides whether fusion has anything to exploit:
    if it barely exceeds the better single channel, the two channels fail on
    the same episodes and there is nothing to gain.
    """
    def index(run_dir: Path) -> Dict[Any, bool]:
        return {
            (e.get("task_name"), e.get("episode")): bool(e.get("success"))
            for e in load_run(run_dir)
        }

    a, b = index(run_a), index(run_b)
    keys = sorted(set(a) & set(b), key=lambda k: (str(k[0]), k[1]))
    if not keys:
        print("\nNo overlapping (task, episode) pairs; skipping paired comparison.")
        return

    both = only_a = only_b = neither = 0
    for key in keys:
        if a[key] and b[key]:
            both += 1
        elif a[key]:
            only_a += 1
        elif b[key]:
            only_b += 1
        else:
            neither += 1

    n = len(keys)
    rate_a = (both + only_a) / n
    rate_b = (both + only_b) / n
    union = (both + only_a + only_b) / n
    best_single = max(rate_a, rate_b)

    print(f"\n{'=' * 72}")
    print("PAIRED PER-EPISODE COMPARISON")
    print(f"{'=' * 72}")
    print(f"A = {run_a.parent.name}")
    print(f"B = {run_b.parent.name}")
    print(f"matched episodes : {n}")
    print(f"  both succeed   : {both:>6}  ({both / n * 100:.1f}%)")
    print(f"  only A         : {only_a:>6}  ({only_a / n * 100:.1f}%)")
    print(f"  only B         : {only_b:>6}  ({only_b / n * 100:.1f}%)")
    print(f"  both fail      : {neither:>6}  ({neither / n * 100:.1f}%)")
    print(f"\nA success        : {rate_a * 100:.1f}%")
    print(f"B success        : {rate_b * 100:.1f}%")
    print(f"per-episode oracle (either succeeds): {union * 100:.1f}%")
    print(f"headroom over the better channel   : {(union - best_single) * 100:+.1f} pp")

    # McNemar on the discordant pairs, normal approximation (no scipy needed).
    disc = only_a + only_b
    if disc > 0:
        z = (abs(only_a - only_b) - 1) / math.sqrt(disc)
        print(f"\nMcNemar z = {z:.2f} on {disc} discordant pairs "
              f"({'significant' if z > 1.96 else 'not significant'} at 0.05)")

    if union - best_single < 0.02:
        print("\n-> The channels fail on the SAME episodes. Fusion has little to exploit;")
        print("   ship the better single channel.")
    else:
        print("\n-> The channels fail on DIFFERENT episodes. There is real complementarity")
        print("   for a verifier or fusion scheme to recover.")


def early_window_predictiveness(run_dirs: List[Path], k: int):
    """Does disagreement in the FIRST k replans predict eventual failure?

    Episode-level disagreement is confounded: a rollout that is already failing
    wanders out of distribution, where both heads degrade and naturally
    disagree. That makes the correlation a symptom rather than a forecast. This
    restricts the window to the opening of each episode, before any failure has
    had time to develop, and re-runs the same correlation.

    Uses the gripper gap, which is pure head disagreement (qpos dims 6/14 vs
    EEF dims 22/30) with no kinematics or execution error mixed in.
    """
    early_max, early_mean, full_max, labels = [], [], [], []

    for run_dir in run_dirs:
        for jsonl_path in sorted(run_dir.glob("*/episodes.jsonl")):
            task_dir = jsonl_path.parent
            with open(jsonl_path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    meta = json.loads(line)
                    npz_path = task_dir / meta.get("npz", "")
                    if not npz_path.exists():
                        continue
                    with np.load(npz_path) as data:
                        pred32 = data["pred32"]
                    if pred32.shape[0] < k:
                        continue
                    gap = np.maximum(
                        np.abs(pred32[:, :, 6] - pred32[:, :, 22]),
                        np.abs(pred32[:, :, 14] - pred32[:, :, 30]),
                    )  # (N, T)
                    early_max.append(float(gap[:k].max()))
                    early_mean.append(float(gap[:k].mean()))
                    full_max.append(float(gap.max()))
                    labels.append(1.0 if meta.get("success") else 0.0)

    if len(labels) < 3:
        print("\nNot enough episodes for the early-window test.")
        return

    labels_arr = np.asarray(labels)
    print(f"\n{'=' * 72}")
    print(f"EARLY-WINDOW PREDICTIVENESS (first {k} replans)")
    print(f"{'=' * 72}")
    print(f"episodes: {len(labels)}   success rate: {labels_arr.mean() * 100:.1f}%")
    print(f"\n{'window':<28} {'metric':<14} {'r':>8}")
    print("-" * 52)

    r_full = point_biserial(np.asarray(full_max), labels_arr)
    r_early_max = point_biserial(np.asarray(early_max), labels_arr)
    r_early_mean = point_biserial(np.asarray(early_mean), labels_arr)
    for name, metric, r in (
        ("whole episode", "grip_gap max", r_full),
        (f"first {k} replans", "grip_gap max", r_early_max),
        (f"first {k} replans", "grip_gap mean", r_early_mean),
    ):
        print(f"{name:<28} {metric:<14} {'  n/a' if r is None else f'{r:+.3f}':>8}")

    if r_full is None or r_early_max is None:
        return
    retained = abs(r_early_max) / max(abs(r_full), 1e-9)
    print(f"\nearly window retains {retained * 100:.0f}% of the whole-episode correlation")
    if abs(r_early_max) > 0.15 and retained > 0.4:
        print("-> Disagreement is genuinely PREDICTIVE. A verifier / gate can act on it.")
    else:
        print("-> Disagreement mostly REACTS to failure rather than forecasting it.")
        print("   Still usable for online abort/retry, but not for choosing actions upfront.")


def dump_per_step_csv(run_dirs: List[Path], out_path: Path):
    """Flatten per-step arrays from the npz files into one CSV.

    Emits the FK-free disagreement signals (gripper gap, predicted delta
    magnitude) alongside the episode outcome, so each step can be attributed to
    a successful or failed rollout.
    """
    rows = []
    for run_dir in run_dirs:
        for jsonl_path in sorted(run_dir.glob("*/episodes.jsonl")):
            task_dir = jsonl_path.parent
            with open(jsonl_path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    meta = json.loads(line)
                    npz_path = task_dir / meta.get("npz", "")
                    if not npz_path.exists():
                        continue
                    with np.load(npz_path) as data:
                        pred32 = data["pred32"]
                        n_exec = data["n_executed"]
                        cnt = data["take_action_cnt"]

                    for n in range(pred32.shape[0]):
                        chunk = pred32[n]
                        rows.append(
                            {
                                "run_dir": str(run_dir),
                                "task_name": meta.get("task_name"),
                                "control_mode": meta.get("control_mode"),
                                "episode": meta.get("episode"),
                                "success": int(bool(meta.get("success"))),
                                "step": n,
                                "take_action_cnt": int(cnt[n]),
                                "n_executed": int(n_exec[n]),
                                "grip_gap_l": float(np.abs(chunk[:, 6] - chunk[:, 22]).mean()),
                                "grip_gap_r": float(np.abs(chunk[:, 14] - chunk[:, 30]).mean()),
                                "eef_dxyz_l": float(np.linalg.norm(chunk[:, 16:19], axis=-1).mean()),
                                "eef_dxyz_r": float(np.linalg.norm(chunk[:, 24:27], axis=-1).mean()),
                                "eef_drot_l": float(np.linalg.norm(chunk[:, 19:22], axis=-1).mean()),
                                "eef_drot_r": float(np.linalg.norm(chunk[:, 27:30], axis=-1).mean()),
                            }
                        )

    if not rows:
        print("\nNo per-step data found, CSV not written.")
        return

    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    print(f"\nWrote {len(rows)} per-step rows to {out_path}")


def main():
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--run", action="append", required=True, type=Path,
                        help="Trajectories directory of a run (repeatable).")
    parser.add_argument("--per-step-csv", type=Path, default=None,
                        help="Also flatten every step into this CSV.")
    parser.add_argument("--paired", action="store_true",
                        help="Match episodes across the first two runs and report "
                             "the per-episode oracle (either channel succeeds).")
    parser.add_argument("--early-window", type=int, default=None, metavar="K",
                        help="Re-run the disagreement correlation using only the "
                             "first K replans, to separate prediction from symptom.")
    args = parser.parse_args()

    runs = [d for d in args.run if d.exists()]
    for run_dir in args.run:
        if not run_dir.exists():
            print(f"Warning: {run_dir} does not exist, skipping")

    summaries = []
    for run_dir in runs:
        episodes = load_run(run_dir)
        label = f"{run_dir.parent.name}/{run_dir.name}"
        summaries.append(summarize_run(episodes, label))

    compare_runs(summaries)

    if args.paired:
        if len(runs) >= 2:
            paired_comparison(runs[0], runs[1])
        else:
            print("\n--paired needs two existing --run directories.")

    if args.early_window is not None:
        for run_dir in runs:
            print(f"\n### {run_dir.parent.name}/{run_dir.name}")
            early_window_predictiveness([run_dir], args.early_window)

    if args.per_step_csv is not None:
        dump_per_step_csv(runs, args.per_step_csv)


if __name__ == "__main__":
    main()

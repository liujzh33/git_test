#!/bin/bash
# Script to extract task success rates from evaluation logs
# Usage: ./extract_success_rates.sh <log_directory>

set -e

# Default to the most recent logs directory if not specified
if [ -z "$1" ]; then
    LOG_DIR=$(ls -dt /home/ma-user/work/wx1469573/RoboTwin_ADS/policy/MotusWanVlmDirectMask/logs_* 2>/dev/null | head -1)
    if [ -z "$LOG_DIR" ]; then
        echo "Error: No log directory found. Please specify a log directory."
        echo "Usage: $0 <log_directory>"
        exit 1
    fi
    echo "Using most recent log directory: $LOG_DIR"
else
    LOG_DIR="$1"
fi

if [ ! -d "$LOG_DIR" ]; then
    echo "Error: Directory not found: $LOG_DIR"
    exit 1
fi

CSV_FILE="${LOG_DIR}/task_success_rates.csv"
TXT_FILE="${LOG_DIR}/task_success_rates_summary.txt"

# Extract success rates and write to CSV
echo "Extracting success rates from: $LOG_DIR"

echo "task_name,success_count,total_count,success_rate" > "$CSV_FILE"

for log_file in "$LOG_DIR"/*.log; do
    # Skip gpu.log files
    if [[ "$log_file" == *".gpu.log" ]]; then
        continue
    fi

    if [ ! -f "$log_file" ]; then
        continue
    fi

    task_name=$(basename "$log_file" .log)

    # Get the last "Success rate:" line
    last_rate=$(grep "Success rate:" "$log_file" | tail -1)

    if [ -n "$last_rate" ]; then
        # Extract success/total and percentage
        success_total=$(echo "$last_rate" | grep -oP '\d+/\d+')
        success=$(echo "$success_total" | cut -d'/' -f1)
        total=$(echo "$success_total" | cut -d'/' -f2)
        rate=$(echo "$last_rate" | grep -oP '\d+\.\d+(?=%)' || echo "$last_rate" | grep -oP '\d+(?=%)')
        echo "$task_name,$success,$total,$rate%" >> "$CSV_FILE"
    fi
done

echo "CSV file saved to: $CSV_FILE"

# Generate summary TXT file with categorized results
echo "Generating summary..."

# Read all tasks and categorize
declare -a excellent_tasks  # >90%
declare -a good_tasks       # 50-90%
declare -a poor_tasks       # <50%

total_success=0
total_count=0

while IFS=, read -r task_name success total rate; do
    # Skip header
    [ "$task_name" = "task_name" ] && continue

    # Remove % sign and convert to number
    rate_num=${rate%\%}

    # Accumulate totals
    total_success=$((total_success + success))
    total_count=$((total_count + total))

    # Categorize
    if awk "BEGIN {exit !($rate_num > 90)}"; then
        excellent_tasks+=("$task_name: $rate")
    elif awk "BEGIN {exit !($rate_num >= 50)}"; then
        good_tasks+=("$task_name: $rate")
    else
        poor_tasks+=("$task_name: $rate")
    fi
done < "$CSV_FILE"

# Calculate average success rate
if [ $total_count -gt 0 ]; then
    avg_rate=$(awk "BEGIN {printf \"%.1f\", $total_success * 100.0 / $total_count}")
else
    avg_rate="0.0"
fi

# Write summary to TXT file
{
    echo "========================================"
    echo "    Task Success Rates Summary"
    echo "========================================"
    echo ""
    echo "Log Directory: $LOG_DIR"
    echo "Generated at: $(date)"
    echo ""

    # Find max lengths for each column
    max_excellent=0
    max_good=0
    max_poor=0

    for task in "${excellent_tasks[@]}"; do
        len=${#task}
        [ $len -gt $max_excellent ] && max_excellent=$len
    done
    for task in "${good_tasks[@]}"; do
        len=${#task}
        [ $len -gt $max_good ] && max_good=$len
    done
    for task in "${poor_tasks[@]}"; do
        len=${#task}
        [ $len -gt $max_poor ] && max_poor=$len
    done

    # Ensure minimum width
    [ $max_excellent -lt 25 ] && max_excellent=25
    [ $max_good -lt 22 ] && max_good=22
    [ $max_poor -lt 23 ] && max_poor=23

    # Print header
    printf "+-%-${max_excellent}s-+-%-${max_good}s-+-%-${max_poor}s-+\n" | tr ' ' '-'
    printf "| %-${max_excellent}s | %-${max_good}s | %-${max_poor}s |\n" "Best (>90%)" "Medium (50-90%)" "Poor (<50%)"
    printf "+-%-${max_excellent}s-+-%-${max_good}s-+-%-${max_poor}s-+\n" | tr ' ' '-'

    # Find max rows
    max_rows=${#excellent_tasks[@]}
    [ ${#good_tasks[@]} -gt $max_rows ] && max_rows=${#good_tasks[@]}
    [ ${#poor_tasks[@]} -gt $max_rows ] && max_rows=${#poor_tasks[@]}

    # Print rows
    for ((i=0; i<max_rows; i++)); do
        excellent="${excellent_tasks[$i]:-}"
        good="${good_tasks[$i]:-}"
        poor="${poor_tasks[$i]:-}"

        printf "| %-${max_excellent}s | %-${max_good}s | %-${max_poor}s |\n" "$excellent" "$good" "$poor"
    done

    printf "+-%-${max_excellent}s-+-%-${max_good}s-+-%-${max_poor}s-+\n" | tr ' ' '-'

    echo ""
    echo "----------------------------------------"
    echo "Average Success Rate: ${avg_rate}%"
    echo "Total Tasks: $((${#excellent_tasks[@]} + ${#good_tasks[@]} + ${#poor_tasks[@]}))"
    echo "  - Best (>90%):  ${#excellent_tasks[@]}"
    echo "  - Medium (50-90%): ${#good_tasks[@]}"
    echo "  - Poor (<50%):  ${#poor_tasks[@]}"
    echo "----------------------------------------"

} > "$TXT_FILE"

echo "Summary saved to: $TXT_FILE"
echo ""
cat "$TXT_FILE"
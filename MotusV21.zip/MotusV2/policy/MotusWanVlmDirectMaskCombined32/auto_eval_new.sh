#!/bin/bash
# Optimized auto evaluation script for Motus policy on RoboTwin platform
# Designed for large-memory GPUs (default tuned for 140GB VRAM per GPU)

set -uo pipefail

echo "Starting Motus evaluation on RoboTwin at $(date)"

# Record start time
START_TIME=$(date +%s)

# Get script directory (policy/Motus/)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
POLICY_DIR="$SCRIPT_DIR"

# ============================================================================
# Helpers
# ============================================================================

parse_yaml_value() {
    # Usage: parse_yaml_value "key" "file"
    local key="$1"
    local file="$2"
    grep "^${key}:" "$file" 2>/dev/null | \
        sed 's/#.*//' | \
        sed 's/.*: *"\?\([^"]*\)"\?.*/\1/' | \
        tr -d '"' | \
        xargs
}

timestamp() {
    date "+%Y-%m-%d %H:%M:%S"
}

is_running() {
    [ -n "${1:-}" ] && kill -0 "$1" 2>/dev/null
}

# Get GPU total/used/free memory in MiB
# Output format: total,used,free
get_gpu_mem_info() {
    local gpu_id="$1"
    local info total used free
    info=$(nvidia-smi --id="$gpu_id" --query-gpu=memory.total,memory.used --format=csv,noheader,nounits 2>/dev/null)
    [ -z "$info" ] && return 1

    total=$(echo "$info" | cut -d',' -f1 | xargs)
    used=$(echo "$info"  | cut -d',' -f2 | xargs)

    if [[ ! "$total" =~ ^[0-9]+$ ]] || [[ ! "$used" =~ ^[0-9]+$ ]]; then
        return 1
    fi

    free=$((total - used))
    echo "${total},${used},${free}"
    return 0
}

get_gpu_memory_used() {
    local gpu_id="$1"
    local info
    info=$(get_gpu_mem_info "$gpu_id") || return 1
    echo "$info" | cut -d',' -f2
}

get_gpu_memory_free() {
    local gpu_id="$1"
    local info
    info=$(get_gpu_mem_info "$gpu_id") || return 1
    echo "$info" | cut -d',' -f3
}

# Clean dead PIDs from gpu_pids map
cleanup_gpu_pids() {
    local gpu_id pid new_pids
    for gpu_id in "${GPU_IDS[@]}"; do
        new_pids=""
        for pid in ${gpu_pids[$gpu_id]:-}; do
            if is_running "$pid"; then
                new_pids="${new_pids} ${pid}"
            fi
        done
        gpu_pids[$gpu_id]="$(echo "$new_pids" | xargs)"
    done
}

count_gpu_tasks() {
    local gpu_id="$1"
    local pid count=0
    for pid in ${gpu_pids[$gpu_id]:-}; do
        if is_running "$pid"; then
            ((count++))
        fi
    done
    echo "$count"
}

show_progress() {
    local current="$1"
    local total="$2"
    local percent=$((current * 100 / total))
    local bar_length=50
    local filled=$((percent * bar_length / 100))

    printf "\r["
    printf "%${filled}s" | tr ' ' '='
    printf "%$((bar_length - filled))s" | tr ' ' ' '
    printf "] %d%% (%d/%d)" "$percent" "$current" "$total"
}

# Decide whether this GPU can accept another task based on:
# 1) max concurrent tasks per GPU
# 2) minimum required free memory before launch
# 3) cooldown after last launch on the same GPU
#
# Output: gpu_id:slot:free_mem
get_best_gpu() {
    while true; do
        cleanup_gpu_pids

        local best_gpu=""
        local best_slot=""
        local best_free_mem=-1
        local now
        now=$(date +%s)

        local gpu_id free_mem task_count last_launch elapsed required_mem
        for gpu_id in "${GPU_IDS[@]}"; do
            free_mem=$(get_gpu_memory_free "$gpu_id" 2>/dev/null || true)
            [ -z "${free_mem:-}" ] && continue

            task_count=$(count_gpu_tasks "$gpu_id")

            # Hard cap
            if [ "$task_count" -ge "$MAX_TASKS_PER_GPU" ]; then
                continue
            fi

            # Cooldown for 2nd/3rd task launch on same GPU
            last_launch=${gpu_last_launch_time[$gpu_id]:-0}
            elapsed=$((now - last_launch))

            if [ "$task_count" -ge 1 ] && [ "$elapsed" -lt "$GPU_LAUNCH_COOLDOWN" ]; then
                continue
            fi

            # Required free memory depends on current running task count
            # task_count=0 -> launching slot 1
            # task_count=1 -> launching slot 2
            # task_count=2 -> launching slot 3
            case "$task_count" in
                0)
                    required_mem="$FREE_MEM_FOR_SLOT1"
                    ;;
                1)
                    required_mem="$FREE_MEM_FOR_SLOT2"
                    ;;
                2)
                    required_mem="$FREE_MEM_FOR_SLOT3"
                    ;;
                *)
                    continue
                    ;;
            esac

            if [ "$free_mem" -lt "$required_mem" ]; then
                continue
            fi

            # Choose GPU with the most free memory
            if [ "$free_mem" -gt "$best_free_mem" ]; then
                best_gpu="$gpu_id"
                best_slot=$((task_count + 1))
                best_free_mem="$free_mem"
            fi
        done

        if [ -n "$best_gpu" ]; then
            echo "${best_gpu}:${best_slot}:${best_free_mem}"
            return 0
        fi

        sleep "$SCHEDULER_POLL_SECONDS"
    done
}

# ============================================================================
# Load Configuration from paths_config.yml
# ============================================================================

CONFIG_FILE="${POLICY_DIR}/paths_config.yml"

if [ ! -f "$CONFIG_FILE" ]; then
    echo "Error: Configuration file not found: $CONFIG_FILE"
    echo "Please create paths_config.yml with required paths."
    exit 1
fi

echo "Loading configuration from: $CONFIG_FILE"

ROBOTWIN_ROOT=$(parse_yaml_value "robotwin_root" "$CONFIG_FILE")
CONDA_ENV=$(parse_yaml_value "conda_env" "$CONFIG_FILE")
CHECKPOINT_PATH=$(parse_yaml_value "checkpoint_path" "$CONFIG_FILE")
WAN_PATH=$(parse_yaml_value "wan_path" "$CONFIG_FILE")
VLM_PATH=$(parse_yaml_value "vlm_path" "$CONFIG_FILE")
VLM_TYPE=$(parse_yaml_value "vlm_type" "$CONFIG_FILE")
VLM_PROMPT_MODE=$(parse_yaml_value "vlm_prompt_mode" "$CONFIG_FILE")

# Optional configurations
TASK_CONFIG=$(parse_yaml_value "task_config" "$CONFIG_FILE")
SEED=$(parse_yaml_value "seed" "$CONFIG_FILE")
TASKS_FILE=$(parse_yaml_value "tasks_file" "$CONFIG_FILE")

TASK_CONFIG=${TASK_CONFIG:-"demo_randomized"}
SEED=${SEED:-"42"}
TASKS_FILE=${TASKS_FILE:-"tasks_all.txt"}
POLICY_NAME="MotusWanVlmDirectMaskCombined32"

# Control channel: "qpos" or "eef". The CONTROL_MODE env var wins over the
# yaml so the two runs can share one config file:
#   CONTROL_MODE=qpos bash auto_eval_new.sh
#   CONTROL_MODE=eef  bash auto_eval_new.sh
CONTROL_MODE_CFG=$(parse_yaml_value "control_mode" "$CONFIG_FILE")
CONTROL_MODE="${CONTROL_MODE:-${CONTROL_MODE_CFG:-qpos}}"

if [ "$CONTROL_MODE" != "qpos" ] && [ "$CONTROL_MODE" != "eef" ]; then
    echo "Error: control_mode must be 'qpos' or 'eef', got '$CONTROL_MODE'"
    exit 1
fi
export MOTUS_CONTROL_MODE="$CONTROL_MODE"

# Optional tuning knobs from config if you want to override defaults
MAX_TASKS_PER_GPU_CFG=$(parse_yaml_value "max_tasks_per_gpu" "$CONFIG_FILE")
FREE_MEM_FOR_SLOT1_CFG=$(parse_yaml_value "free_mem_for_slot1" "$CONFIG_FILE")
FREE_MEM_FOR_SLOT2_CFG=$(parse_yaml_value "free_mem_for_slot2" "$CONFIG_FILE")
FREE_MEM_FOR_SLOT3_CFG=$(parse_yaml_value "free_mem_for_slot3" "$CONFIG_FILE")
GPU_LAUNCH_COOLDOWN_CFG=$(parse_yaml_value "gpu_launch_cooldown" "$CONFIG_FILE")
LAUNCH_STAGGER_SECONDS_CFG=$(parse_yaml_value "launch_stagger_seconds" "$CONFIG_FILE")
SCHEDULER_POLL_SECONDS_CFG=$(parse_yaml_value "scheduler_poll_seconds" "$CONFIG_FILE")
GPU_MONITOR_INTERVAL_CFG=$(parse_yaml_value "gpu_monitor_interval" "$CONFIG_FILE")
OMP_NUM_THREADS_CFG=$(parse_yaml_value "omp_num_threads" "$CONFIG_FILE")
LOG_BASE_DIR_CFG=$(parse_yaml_value "log_base_dir" "$CONFIG_FILE")

# Parse GPU IDs from config (if specified)
GPU_IDS_STR=$(grep "^gpu_ids:" "$CONFIG_FILE" | sed 's/#.*//' | sed 's/.*: *\[\(.*\)\]/\1/' | tr -d ' ')
if [ -n "${GPU_IDS_STR:-}" ] && [ "$GPU_IDS_STR" != "[]" ]; then
    IFS=',' read -ra GPU_IDS <<< "$GPU_IDS_STR"
else
    GPU_IDS=()  # auto-detect
fi

# ============================================================================
# Validation
# ============================================================================

if [ -z "$ROBOTWIN_ROOT" ]; then
    echo "Error: robotwin_root is not set in $CONFIG_FILE"
    exit 1
fi

if [ -z "$CONDA_ENV" ]; then
    echo "Error: conda_env is not set in $CONFIG_FILE"
    exit 1
fi

if [ -z "$CHECKPOINT_PATH" ]; then
    echo "Error: checkpoint_path is not set in $CONFIG_FILE"
    exit 1
fi

if [ -z "$WAN_PATH" ]; then
    echo "Error: wan_path is not set in $CONFIG_FILE"
    exit 1
fi

if [ -z "$VLM_PATH" ]; then
    echo "Error: vlm_path is not set in $CONFIG_FILE"
    exit 1
fi

VLM_TYPE=${VLM_TYPE:-"qwen3_vl"}

if [ ! -d "$ROBOTWIN_ROOT" ]; then
    echo "Error: RoboTwin root not found: $ROBOTWIN_ROOT"
    exit 1
fi

if [ ! -d "$CHECKPOINT_PATH" ]; then
    echo "Error: Checkpoint not found: $CHECKPOINT_PATH"
    exit 1
fi

if [ ! -d "$WAN_PATH" ]; then
    echo "Error: WAN path not found: $WAN_PATH"
    exit 1
fi

if [ ! -d "$VLM_PATH" ]; then
    echo "Error: VLM path not found: $VLM_PATH"
    exit 1
fi

cd "$ROBOTWIN_ROOT" || exit 1

# Activate conda
if ! command -v conda >/dev/null 2>&1; then
    echo "Error: conda not found."
    exit 1
fi

eval "$(conda shell.bash hook)"
conda activate "$CONDA_ENV"

if [ $? -ne 0 ]; then
    echo "Error: Failed to activate conda environment: $CONDA_ENV"
    exit 1
fi

# Set environment
export PYTHONPATH="${ROBOTWIN_ROOT}:${PYTHONPATH:-}"
export OMP_NUM_THREADS="${OMP_NUM_THREADS_CFG:-8}"

# Create logs directory
LOG_BASE_DIR="${LOG_BASE_DIR_CFG:-${POLICY_DIR}}"
LOG_DIR="${LOG_BASE_DIR}/logs_${CONTROL_MODE}_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$LOG_DIR"
echo "Log directory: $LOG_DIR"
cp "$CONFIG_FILE" "$LOG_DIR/config_backup.yml"
echo "control_mode (effective): $CONTROL_MODE" >> "$LOG_DIR/config_backup.yml"

# Load tasks (filter comments and empty lines)
TASKS_PATH="${POLICY_DIR}/${TASKS_FILE}"
if [ ! -f "$TASKS_PATH" ]; then
    echo "Error: Tasks file not found: $TASKS_PATH"
    exit 1
fi

mapfile -t tasks < <(grep -v '^[[:space:]]*#' "$TASKS_PATH" | grep -v '^[[:space:]]*$')

if [ ${#tasks[@]} -eq 0 ]; then
    echo "Error: No tasks found."
    exit 1
fi

# Auto-detect GPUs if not specified
if [ ${#GPU_IDS[@]} -eq 0 ]; then
    if command -v nvidia-smi >/dev/null 2>&1; then
        mapfile -t GPU_IDS < <(nvidia-smi --query-gpu=index --format=csv,noheader)
        echo "Auto-detected ${#GPU_IDS[@]} GPUs: ${GPU_IDS[*]}"
    else
        echo "Warning: nvidia-smi not found, using GPU 0"
        GPU_IDS=(0)
    fi
fi

# ============================================================================
# Scheduler Parameters (defaults tuned for 140GB VRAM GPUs)
# ============================================================================
#
# Meaning:
# - slot1 threshold: launching the first task on a GPU requires at least this much free memory
# - slot2 threshold: launching the second concurrent task requires at least this much free memory
# - slot3 threshold: launching the third concurrent task requires at least this much free memory
#
# For 140GB cards, these defaults are intentionally conservative:
#   slot1: >= 45GB free
#   slot2: >= 85GB free
#   slot3: >= 50GB free
#
# Typical behavior:
# - empty 140GB GPU -> slot1 allowed
# - after one task settles, if still >= 85GB free -> slot2 allowed
# - after two tasks settle, if still >= 50GB free -> slot3 allowed
#
# If you still see OOM, raise slot2/slot3 thresholds or reduce MAX_TASKS_PER_GPU to 2.

MAX_TASKS_PER_GPU="${MAX_TASKS_PER_GPU_CFG:-3}"

FREE_MEM_FOR_SLOT1="${FREE_MEM_FOR_SLOT1_CFG:-45000}"
FREE_MEM_FOR_SLOT2="${FREE_MEM_FOR_SLOT2_CFG:-85000}"
FREE_MEM_FOR_SLOT3="${FREE_MEM_FOR_SLOT3_CFG:-50000}"

GPU_LAUNCH_COOLDOWN="${GPU_LAUNCH_COOLDOWN_CFG:-45}"
LAUNCH_STAGGER_SECONDS="${LAUNCH_STAGGER_SECONDS_CFG:-3}"
SCHEDULER_POLL_SECONDS="${SCHEDULER_POLL_SECONDS_CFG:-5}"
GPU_MONITOR_INTERVAL="${GPU_MONITOR_INTERVAL_CFG:-10}"

# GPU management
declare -A gpu_pids
declare -A gpu_last_launch_time

for gpu_id in "${GPU_IDS[@]}"; do
    gpu_pids[$gpu_id]=""
    gpu_last_launch_time[$gpu_id]=0
done

echo -e "\n\033[33m=== Evaluation Configuration ===\033[0m"
echo "RoboTwin Root: $ROBOTWIN_ROOT"
echo "Policy Dir: $POLICY_DIR"
echo "Checkpoint: $CHECKPOINT_PATH"
echo "WAN Path: $WAN_PATH"
echo "VLM Path: $VLM_PATH"
echo "VLM Type: $VLM_TYPE"
echo "VLM Prompt Mode: ${VLM_PROMPT_MODE:-simple}"
echo "Policy: $POLICY_NAME"
echo "Control Mode: $CONTROL_MODE"
echo "Task Config: $TASK_CONFIG"
echo "Tasks: ${#tasks[@]}"
echo "GPUs: ${GPU_IDS[*]}"
echo "Max Tasks / GPU: $MAX_TASKS_PER_GPU"
echo "Free Mem Thresholds (MiB): slot1=$FREE_MEM_FOR_SLOT1, slot2=$FREE_MEM_FOR_SLOT2, slot3=$FREE_MEM_FOR_SLOT3"
echo "GPU Launch Cooldown: ${GPU_LAUNCH_COOLDOWN}s"
echo "Launch Stagger: ${LAUNCH_STAGGER_SECONDS}s"
echo "Scheduler Poll: ${SCHEDULER_POLL_SECONDS}s"
echo "GPU Monitor Interval: ${GPU_MONITOR_INTERVAL}s"
echo "Seed: $SEED"
echo "OMP_NUM_THREADS: $OMP_NUM_THREADS"
echo "Log Dir: $LOG_DIR"
echo "================================"

# ============================================================================
# Launch tasks
# ============================================================================

pids=()
completed=0
total=${#tasks[@]}

declare -A pid_to_task
declare -A pid_to_gpu
declare -A task_to_log

echo -e "\n\033[32mLaunching evaluation tasks...\033[0m"

for task in "${tasks[@]}"; do
    selection=$(get_best_gpu)
    gpu_id=$(echo "$selection" | cut -d: -f1)
    slot=$(echo "$selection" | cut -d: -f2)
    free_mem=$(echo "$selection" | cut -d: -f3)
    used_mem=$(get_gpu_memory_used "$gpu_id" 2>/dev/null || echo "NA")
    ckpt_setting="${CHECKPOINT_PATH}"

    # Safe filename
    safe_task_name=$(echo "$task" | sed 's#[/ ]#_#g')
    log_file="${LOG_DIR}/${safe_task_name}.log"
    gpu_log_file="${LOG_DIR}/${safe_task_name}.gpu.log"

    echo -e "\033[36m-> Task: $task | GPU: $gpu_id | Slot: $slot | Free: ${free_mem}MiB | Used: ${used_mem}MiB\033[0m"

    (
        export CUDA_VISIBLE_DEVICES="$gpu_id"

        echo "[$(timestamp)] Task started: $task" >> "$log_file"
        echo "[$(timestamp)] Assigned GPU: $gpu_id, slot: $slot" >> "$log_file"
        echo "[$(timestamp)] Initial GPU mem info:" >> "$log_file"
        nvidia-smi --id="$gpu_id" --query-gpu=index,name,memory.total,memory.used,utilization.gpu --format=csv >> "$log_file" 2>&1 || true
        echo >> "$log_file"

        # Background GPU monitor for this task
        (
            while true; do
                echo "[$(timestamp)]" >> "$gpu_log_file"
                nvidia-smi --id="$gpu_id" --query-gpu=index,name,memory.total,memory.used,utilization.gpu --format=csv >> "$gpu_log_file" 2>&1 || true
                echo >> "$gpu_log_file"
                sleep "$GPU_MONITOR_INTERVAL"
            done
        ) &
        monitor_pid=$!

        PYTHONWARNINGS=ignore::UserWarning \
        PYTHONUNBUFFERED=1 \
        python -u script/eval_policy.py \
            --config "policy/${POLICY_NAME}/deploy_policy.yml" \
            --overrides \
            --task_name "${task}" \
            --task_config "${TASK_CONFIG}" \
            --ckpt_setting "${ckpt_setting}" \
            --seed "${SEED}" \
            --policy_name "${POLICY_NAME}" \
            --log_dir "${LOG_DIR}" \
            --wan_path "${WAN_PATH}" \
            --vlm_path "${VLM_PATH}" \
            --vlm_type "${VLM_TYPE}" \
            2>&1 | sed -u 's/\x1b\[[0-9;]*m//g' >> "$log_file"

        exit_code=$?

        kill "$monitor_pid" >/dev/null 2>&1 || true
        wait "$monitor_pid" 2>/dev/null || true

        echo >> "$log_file"
        echo "[$(timestamp)] Final GPU mem info:" >> "$log_file"
        nvidia-smi --id="$gpu_id" --query-gpu=index,name,memory.total,memory.used,utilization.gpu --format=csv >> "$log_file" 2>&1 || true

        if [ $exit_code -eq 0 ]; then
            echo "[$(timestamp)] Task $task completed successfully" >> "$log_file"
        else
            echo "[$(timestamp)] Task $task failed with exit code $exit_code" >> "$log_file"
        fi

        exit $exit_code
    ) &

    pid=$!
    gpu_last_launch_time[$gpu_id]=$(date +%s)

    if [ -z "${gpu_pids[$gpu_id]}" ]; then
        gpu_pids[$gpu_id]="$pid"
    else
        gpu_pids[$gpu_id]="${gpu_pids[$gpu_id]} $pid"
    fi

    pids+=("$pid")
    pid_to_task[$pid]="$task"
    pid_to_gpu[$pid]="$gpu_id"
    task_to_log[$task]="$log_file"

    sleep "$LAUNCH_STAGGER_SECONDS"
done

echo -e "\n\033[33mWaiting for completion...\033[0m"

# Track exit codes
declare -A pid_exit_code

for pid in "${pids[@]}"; do
    if wait "$pid"; then
        pid_exit_code[$pid]=0
    else
        pid_exit_code[$pid]=$?
    fi
    ((completed++))
    show_progress "$completed" "$total"
done

echo -e "\n\033[32mAll tasks completed!\033[0m"

# ============================================================================
# Generate summary
# ============================================================================

summary="${LOG_DIR}/evaluation_summary.txt"

cat > "$summary" << EOF
Motus Evaluation Summary
========================
Date: $(date)
Host: $(hostname)
RoboTwin: $ROBOTWIN_ROOT
Checkpoint: $CHECKPOINT_PATH
WAN Path: $WAN_PATH
VLM Path: $VLM_PATH
VLM Prompt Mode: ${VLM_PROMPT_MODE:-simple}
Policy: $POLICY_NAME
Control Mode: $CONTROL_MODE
Task Config: $TASK_CONFIG
Seed: $SEED
Total Tasks: $total
GPUs: ${GPU_IDS[*]}

Scheduler Parameters:
---------------------
Max Tasks / GPU: $MAX_TASKS_PER_GPU
Free Mem Slot1: $FREE_MEM_FOR_SLOT1 MiB
Free Mem Slot2: $FREE_MEM_FOR_SLOT2 MiB
Free Mem Slot3: $FREE_MEM_FOR_SLOT3 MiB
GPU Launch Cooldown: $GPU_LAUNCH_COOLDOWN s
Launch Stagger: $LAUNCH_STAGGER_SECONDS s
Scheduler Poll: $SCHEDULER_POLL_SECONDS s
GPU Monitor Interval: $GPU_MONITOR_INTERVAL s

Task Results:
-------------
EOF

success=0
failed=0
oom_failed=0

for task in "${tasks[@]}"; do
    log_file="${task_to_log[$task]:-${LOG_DIR}/$(echo "$task" | sed 's#[/ ]#_#g').log}"

    if [ ! -f "$log_file" ]; then
        echo "  ? $task: LOG NOT FOUND" >> "$summary"
        ((failed++))
        continue
    fi

    if grep -qiE "out of memory|cuda oom|CUDA out of memory|CUBLAS_STATUS_ALLOC_FAILED|std::bad_alloc" "$log_file"; then
        echo "  OOM $task: FAILED (OOM)" >> "$summary"
        ((failed++))
        ((oom_failed++))
    elif grep -q "completed successfully\|Episode.*completed" "$log_file" 2>/dev/null; then
        echo "  OK  $task: SUCCESS" >> "$summary"
        ((success++))
    else
        echo "  XX  $task: FAILED" >> "$summary"
        ((failed++))
    fi
done

success_rate=$(awk "BEGIN { if ($total == 0) print \"0.0\"; else printf \"%.1f\", $success * 100.0 / $total }")

cat >> "$summary" << EOF

Summary Statistics:
-------------------
OK  (Success): $success
XX  (Failed): $failed
OOM (Failed): $oom_failed
Total: $total
Success Rate: ${success_rate}%

Logs: $LOG_DIR
EOF

echo -e "\n=== Summary ==="

# Calculate elapsed time
END_TIME=$(date +%s)
ELAPSED_SECONDS=$((END_TIME - START_TIME))
HOURS=$((ELAPSED_SECONDS / 3600))
MINUTES=$(((ELAPSED_SECONDS % 3600) / 60))
SECONDS=$((ELAPSED_SECONDS % 60))

echo "Total Time: ${HOURS}h ${MINUTES}m ${SECONDS}s"
echo "OK  (Success): $success"
echo "XX  (Failed): $failed"
echo "OOM (Failed): $oom_failed"
echo "Success Rate: ${success_rate}%"
echo "Summary: $summary"

bash "${POLICY_DIR}/extract_success_rates.sh" "$LOG_DIR"

echo "------- Upload weights and logs to OBS -------"
if [ "${VC_TASK_INDEX:-0}" = "0" ]; then
    echo "------- Upload weights and logs to OBS -------"
    time=$(date "+%Y%m%d_%H%M%S")
    target_obs="obs://yw-2030-gy/external/wx1469573/cache-DI/EvalRoboTwin/$time"

    conda activate qwen3

    if [ -d "$LOG_DIR" ]; then
        python -c "import moxing as mox; mox.file.copy_parallel('$LOG_DIR', '$target_obs')"
        echo "Upload done: $target_obs"
    else
        echo "WARNING: $LOG_DIR not found, skip upload"
    fi
fi

if [ $failed -eq 0 ]; then
    echo "All tasks passed!"
    exit 0
else
    echo "Check logs for failures."
    exit 1
fi

# MotusWanVlmDirectMaskCombined32 — qpos-only vs eef-only evaluation

Evaluation policy for the **combined 32-dim** checkpoint trained with
`configs/robotwin_qpos_unified_eef_combined32_wan_vlm_mask.yaml`.

The model predicts both action spaces in one vector:

```
[0:16]  abs qpos padded : [L_qpos7, 0, R_qpos7, 0]      qpos7 = [j0..j5, gripper]
[16:32] unified EEF     : [L_eef7,  0, R_eef7,  0]      eef7  = [dxyz_cam(3), drotvec_cam(3), gripper]
```

Reserved pads sit at dims `[7, 15, 23, 31]` and are held at zero throughout
denoising, matching training.

## Picking the control channel

Both heads are decoded on every replan; `control_mode` decides which one drives
the robot.

| `control_mode` | sent to simulator | executed by |
|---|---|---|
| `qpos` | 14-dim joints → `take_action(action_type='qpos')` | TOPP on the joint path; cannot fail |
| `eef` | 16-dim absolute eepos → `take_action(action_type='ee')` | IK + mplib planning; can fail and can override the intended path |

Set it in `paths_config.yml`, or override per run without editing the file:

```bash
CONTROL_MODE=qpos bash auto_eval_new.sh
CONTROL_MODE=eef  bash auto_eval_new.sh
```

Each run writes to its own `logs_{control_mode}_{timestamp}/`.

## Recording and analysis

`record_trajectory: true` dumps, per task and episode:

```
{log_dir}/trajectories/{task}/episode_XXXX.npz   per-step arrays (compressed)
{log_dir}/trajectories/{task}/episodes.jsonl     one line of scalars per episode
```

The npz keeps the raw 32-dim predictions plus the observed state, so any
derived quantity (including a forward-kinematics head-disagreement) can be
recomputed offline. The jsonl carries the per-episode success flag next to the
disagreement statistics, which is what the correlation analysis consumes:

```bash
python analyze_records.py \
    --run <qpos_log_dir>/trajectories \
    --run <eef_log_dir>/trajectories \
    --per-step-csv steps.csv
```

That prints per-task and overall success rates for each channel, a head-to-head
table, and the point-biserial correlation between each disagreement metric and
success.

Two disagreement families are reported. `grip_gap_*` is the direct gap between
the duplicated gripper predictions (qpos dims 6/14 vs EEF dims 22/30) and needs
no kinematics. `track_err_*` compares what a head predicted for the last
executed action against what was actually observed next; for the head that is
**not** driving, this is the cross-head disagreement realized through the robot.

`save_images: false` disables the predicted-frame grid PNGs. RoboTwin's own eval
video is separate and controlled by its task config.

## Offline sanity check

`test_combined32_policy.py` runs without a GPU, checkpoint, or RoboTwin install.
It cross-checks the policy's state construction and delta inversion against the
training-side implementation in `data/human/unified_eef_action.py`:

```bash
python test_combined32_policy.py
```

---

## RoboTwin platform setup

**Important Note:** RoboTwin evaluation uses a **separate conda environment** from Motus training. You will need two environments:
- **`motus`**: For Motus training (see main README)
- **`RoboTwin`**: For RoboTwin simulation and evaluation (this guide)

## Table of Contents
- [Environment Setup](#environment-setup)
- [Installation](#installation)
- [Configuration](#configuration)
- [Running Evaluation](#running-evaluation)
- [Viewing Results](#viewing-results)

---

## Environment Setup

### 1. Install RoboTwin Platform

Follow the official RoboTwin installation guide to create the `RoboTwin` conda environment:
```
https://robotwin-platform.github.io/doc/usage/robotwin-install.html
```

This will create a conda environment named `RoboTwin` (or your custom name) with all necessary RoboTwin dependencies.

### 2. System Requirements

- **CUDA >= 12.6**
- **PyTorch >= 2.4.0**
- **torchvision >= 0.19.0**

Install PyTorch with CUDA 12.6:
```bash
pip install torch>=2.4.0 torchvision>=0.19.0 --index-url https://download.pytorch.org/whl/cu126
```

### 3. Install Additional Dependencies

After installing RoboTwin, **activate the RoboTwin environment** and install Motus-specific requirements:

```bash
conda activate RoboTwin  # Or your RoboTwin environment name
cd /path/to/RoboTwin/policy/Motus
pip install -r requirements.txt
```

**Note:** Make sure you're in the `RoboTwin` environment, not the `motus` training environment.

---

## Installation

### Deploy Motus Policy to RoboTwin

1. **Copy the Motus inference folder** to RoboTwin policy directory:

```bash
# From Motus repository root
cp -r inference/robotwin/Motus /path/to/RoboTwin/policy/
```

2. **Verify directory structure:**

```
RoboTwin/
├── policy/
│   ├── Motus/
│   │   ├── auto_eval.sh
│   │   ├── eval.sh
│   │   ├── per_eval_logs.sh
│   │   ├── paths_config.yml
│   │   ├── deploy_policy.py
│   │   ├── deploy_policy.yml
│   │   ├── requirements.txt
│   │   ├── tasks_all.txt
│   │   ├── models/
│   │   └── README.md (this file)
│   └── ... (other policies)
├── script/
│   └── eval_policy.py
└── ... (other RoboTwin files)
```

---

## Configuration

### Edit `paths_config.yml`

Open `paths_config.yml` and configure all required paths:

```yaml
# ============================================================================
# Core Paths - MUST MODIFY THESE
# ============================================================================
robotwin_root: "/path/to/RoboTwin"
conda_env: "/path/to/conda/envs/RoboTwin-env"
checkpoint_path: 

# Pretrained model paths (for loading configs/tokenizer, not weights)
wan_path: "/path/to/pretrained_models/Wan2.2-TI2V-5B"
vlm_path: "/path/to/pretrained_models/Qwen3-VL-2B-Instruct"

# ============================================================================
# Optional Configuration
# ============================================================================
# GPU IDs (empty means auto-detect)
gpu_ids: []

# Task configuration
task_config: "demo_randomized"
seed: 42
tasks_file: "tasks_all.txt"
```

**Important Notes:**
- `checkpoint_path`: Must be the **directory** containing `mp_rank_00_model_states.pt`
  - Example structure: `checkpoint_path/mp_rank_00_model_states.pt`
- `wan_path` and `vlm_path`: Only config/tokenizer files are required, not full pretrained weights
- `gpu_ids`: Leave empty `[]` for auto-detection, or specify GPU IDs like `[0, 1, 2, 3]`

### Configure Task List

Edit `tasks_all.txt` to specify which tasks to evaluate:

```bash
# One task name per line
PickCube
StackCube
PutSpoon
# ... add more tasks
```

---

## Running Evaluation

### Batch Evaluation (Multiple Tasks)

Evaluate all tasks listed in `tasks_all.txt`:

```bash
cd /path/to/RoboTwin/policy/Motus
bash auto_eval.sh
```

This will:
1. Load configuration from `paths_config.yml`
2. Activate the conda environment
3. Run evaluation for each task in parallel across available GPUs
4. Save logs to `logs_YYYYMMDD_HHMMSS/` directory


### Single Task Evaluation

Evaluate a specific task:

```bash
cd /path/to/RoboTwin/policy/Motus
bash eval.sh <task_name>

# Example:
bash eval.sh PickCube
```

---

## Viewing Results

### Detailed Task Scores

To view detailed per-task success rates, use the `per_eval_logs.sh` script:

1. **Edit `per_eval_logs.sh`** and set the `LOG_DIR` variable to your logs directory:

```bash
# Open per_eval_logs.sh and modify:
LOG_DIR="/path/to/RoboTwin/policy/Motus/logs_YYYYMMDD_HHMMSS"
```

2. **Run the script:**

```bash
cd /path/to/RoboTwin/policy/Motus
bash per_eval_logs.sh
```
"""Per-episode trajectory recorder for the combined qpos + unified-EEF policy.

Storage layout::

    {record_dir}/{task_name}/episode_{idx:04d}.npz   compressed per-step arrays
    {record_dir}/{task_name}/episodes.jsonl          one line of scalars per episode

The npz holds everything needed to recompute any derived quantity offline
(including a forward-kinematics based head-disagreement), while the jsonl is
small enough to load in bulk for success-correlation analysis.
"""

import json
import logging
import numpy as np
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


def quat_wxyz_angle(q_a: np.ndarray, q_b: np.ndarray) -> float:
    """Geodesic angle in radians between two WXYZ quaternions."""
    q_a = np.asarray(q_a, dtype=np.float64)
    q_b = np.asarray(q_b, dtype=np.float64)
    na = np.linalg.norm(q_a)
    nb = np.linalg.norm(q_b)
    if na < 1e-9 or nb < 1e-9:
        return float("nan")
    dot = abs(float(np.dot(q_a / na, q_b / nb)))
    return float(2.0 * np.arccos(min(1.0, max(0.0, dot))))


class TrajectoryRecorder:
    """Buffers one episode at a time and flushes it to disk on ``end_episode``.

    Per-step arrays in the npz (``N`` replans, chunk length ``T``):

    ``state32``       (N, 32)     policy input state
    ``pred32``        (N, T, 32)  raw model output, both heads
    ``anchor_eepos``  (N, 16)     observed absolute eepos; also the delta anchor
    ``obs_qpos14``    (N, 14)     observed absolute joints
    ``n_executed``    (N,)        actions of the chunk actually run
    ``take_action_cnt`` (N,)      simulator step counter at replan time

    ``anchor_eepos[n + 1]`` and ``obs_qpos14[n + 1]`` are the observations that
    follow chunk ``n``, which is what makes the tracking errors below possible.
    """

    def __init__(
        self,
        record_dir: str,
        task_name: str,
        control_mode: str,
        enabled: bool = True,
        extra_meta: Optional[Dict[str, Any]] = None,
        unified_delta_to_eepos=None,
    ):
        self.enabled = bool(enabled)
        self.task_name = task_name
        self.control_mode = control_mode
        self.extra_meta = dict(extra_meta or {})
        self.unified_delta_to_eepos = unified_delta_to_eepos

        self.out_dir = Path(record_dir) / task_name
        self.jsonl_path = self.out_dir / "episodes.jsonl"
        if self.enabled:
            self.out_dir.mkdir(parents=True, exist_ok=True)
            logger.info(f"Trajectory recording enabled -> {self.out_dir}")

        self.episode_idx = -1
        self._buffer: List[Dict[str, Any]] = []
        self._episode_open = False
        self._success = False

    # ------------------------------------------------------------------
    # Episode lifecycle
    # ------------------------------------------------------------------
    def start_episode(self, episode_idx: int):
        self.episode_idx = episode_idx
        self._buffer = []
        self._episode_open = True
        self._success = False

    def log_step(
        self,
        state32: np.ndarray,
        pred32: np.ndarray,
        anchor_eepos: np.ndarray,
        obs_qpos14: np.ndarray,
        take_action_cnt: int,
    ):
        """Record one replan. ``n_executed`` is filled in by ``log_execution``."""
        if not (self.enabled and self._episode_open):
            return
        self._buffer.append(
            {
                "state32": np.asarray(state32, dtype=np.float32).reshape(-1),
                "pred32": np.asarray(pred32, dtype=np.float32),
                "anchor_eepos": np.asarray(anchor_eepos, dtype=np.float32).reshape(-1),
                "obs_qpos14": np.asarray(obs_qpos14, dtype=np.float32).reshape(-1),
                "take_action_cnt": int(take_action_cnt),
                "n_executed": 0,
            }
        )

    def log_execution(self, n_executed: int, success: bool):
        """Attach execution outcome to the most recent step."""
        if not (self.enabled and self._episode_open) or not self._buffer:
            return
        self._buffer[-1]["n_executed"] = int(n_executed)
        if success:
            self._success = True

    def end_episode(self, success: Optional[bool] = None):
        if not (self.enabled and self._episode_open):
            self._episode_open = False
            return
        self._episode_open = False

        if success is not None:
            self._success = bool(success)

        if not self._buffer:
            return

        arrays = {
            "state32": np.stack([s["state32"] for s in self._buffer]),
            "pred32": np.stack([s["pred32"] for s in self._buffer]),
            "anchor_eepos": np.stack([s["anchor_eepos"] for s in self._buffer]),
            "obs_qpos14": np.stack([s["obs_qpos14"] for s in self._buffer]),
            "n_executed": np.array([s["n_executed"] for s in self._buffer], dtype=np.int16),
            "take_action_cnt": np.array([s["take_action_cnt"] for s in self._buffer], dtype=np.int32),
        }

        npz_name = f"episode_{self.episode_idx:04d}.npz"
        try:
            np.savez_compressed(self.out_dir / npz_name, **arrays)
        except Exception as e:
            logger.warning(f"Failed to save trajectory npz {npz_name}: {e}")
            self._buffer = []
            return

        summary = self._summarize(arrays)
        summary.update(
            {
                "episode": int(self.episode_idx),
                "task_name": self.task_name,
                "control_mode": self.control_mode,
                "success": bool(self._success),
                "n_steps": int(len(self._buffer)),
                "n_take_actions": int(arrays["n_executed"].sum()),
                "npz": npz_name,
            }
        )
        summary.update(self.extra_meta)

        try:
            with open(self.jsonl_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(summary) + "\n")
        except Exception as e:
            logger.warning(f"Failed to append episode summary: {e}")

        logger.info(
            f"Recorded episode {self.episode_idx} "
            f"(success={self._success}, steps={len(self._buffer)}) -> {npz_name}"
        )
        self._buffer = []

    # ------------------------------------------------------------------
    # Derived statistics
    # ------------------------------------------------------------------
    def _summarize(self, arrays: Dict[str, np.ndarray]) -> Dict[str, Any]:
        """Compute the scalars used for the disagreement/success correlation.

        Two families of numbers are produced per step ``n``:

        ``grip_gap``
            Direct disagreement between the two heads on the duplicated gripper
            dims (qpos dim 6/14 vs EEF dim 22/30). Needs no kinematics.

        ``track_err_*``
            Error between what a head predicted for the last executed action of
            chunk ``n`` and what was actually observed at step ``n + 1``.
            Whichever head is NOT driving control, this is the cross-head
            disagreement realized through the robot; for the driving head it is
            plain controller tracking error.
        """
        stats = summarize_predictions(
            pred32=arrays["pred32"],
            anchor_eepos=arrays["anchor_eepos"],
            obs_qpos14=arrays["obs_qpos14"],
            n_executed=arrays["n_executed"],
            unified_delta_to_eepos=self.unified_delta_to_eepos,
        )
        return {k: (None if v is None or not np.isfinite(v) else float(v)) for k, v in stats.items()}


def summarize_predictions(
    pred32: np.ndarray,
    anchor_eepos: np.ndarray,
    obs_qpos14: np.ndarray,
    n_executed: np.ndarray,
    unified_delta_to_eepos=None,
) -> Dict[str, float]:
    """Episode-level scalars derived from the raw per-step arrays.

    ``unified_delta_to_eepos`` converts a (T, 16) unified delta chunk plus a
    (16,) anchor into (T, 16) absolute eepos. When omitted the EEF tracking
    error is skipped (the gripper gap and qpos tracking error are still
    reported), which keeps this helper usable without the policy class.
    """
    n_steps = pred32.shape[0]

    # Gripper double-prediction gap: qpos dims 6/14 vs EEF dims 22/30.
    grip_gap_l = np.abs(pred32[:, :, 6] - pred32[:, :, 22]).mean(axis=1)
    grip_gap_r = np.abs(pred32[:, :, 14] - pred32[:, :, 30]).mean(axis=1)

    qpos_pred = np.concatenate([pred32[:, :, 0:7], pred32[:, :, 8:15]], axis=-1)  # (N, T, 14)

    track_qpos = []
    track_eef_pos_l, track_eef_pos_r = [], []
    track_eef_rot_l, track_eef_rot_r = [], []

    for n in range(n_steps - 1):
        k = int(n_executed[n]) - 1
        if k < 0 or k >= qpos_pred.shape[1]:
            continue

        track_qpos.append(float(np.linalg.norm(qpos_pred[n, k] - obs_qpos14[n + 1])))

        if unified_delta_to_eepos is None:
            continue
        eepos_chunk = unified_delta_to_eepos(pred32[n, :, 16:32], anchor_eepos[n])
        target = eepos_chunk[k]
        nxt = anchor_eepos[n + 1]
        track_eef_pos_l.append(float(np.linalg.norm(target[0:3] - nxt[0:3])))
        track_eef_pos_r.append(float(np.linalg.norm(target[8:11] - nxt[8:11])))
        track_eef_rot_l.append(quat_wxyz_angle(target[3:7], nxt[3:7]))
        track_eef_rot_r.append(quat_wxyz_angle(target[11:15], nxt[11:15]))

    def _agg(values, name):
        if not values:
            return {f"{name}_mean": None, f"{name}_max": None}
        arr = np.asarray(values, dtype=np.float64)
        arr = arr[np.isfinite(arr)]
        if arr.size == 0:
            return {f"{name}_mean": None, f"{name}_max": None}
        return {f"{name}_mean": float(arr.mean()), f"{name}_max": float(arr.max())}

    out: Dict[str, Any] = {
        "grip_gap_l_mean": float(grip_gap_l.mean()),
        "grip_gap_r_mean": float(grip_gap_r.mean()),
        "grip_gap_max": float(max(grip_gap_l.max(), grip_gap_r.max())),
    }
    out.update(_agg(track_qpos, "track_err_qpos"))
    out.update(_agg(track_eef_pos_l, "track_err_eef_pos_l"))
    out.update(_agg(track_eef_pos_r, "track_err_eef_pos_r"))
    out.update(_agg(track_eef_rot_l, "track_err_eef_rot_l"))
    out.update(_agg(track_eef_rot_r, "track_err_eef_rot_r"))
    return out

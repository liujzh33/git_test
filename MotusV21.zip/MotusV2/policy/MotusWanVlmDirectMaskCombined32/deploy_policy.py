# MotusWanVlmDirectMask policy for the combined qpos + unified-EEF (32D) checkpoint.
#
# The model predicts BOTH action spaces in a single 32-dim vector:
#
#     [0:16]  abs qpos padded : [L_qpos7, 0, R_qpos7, 0]
#     [16:32] unified EEF     : [L_eef7,  0, R_eef7,  0]
#
# where qpos7 = [j0..j5, gripper] and eef7 = [dxyz_cam(3), drotvec_cam(3), gripper].
# Reserved pads live at dims [7, 15, 23, 31].
#
# Only ONE of the two heads drives the robot, selected by `control_mode` in
# paths_config.yml:
#
#     control_mode: "qpos" -> take_action(qpos14,  action_type='qpos')
#     control_mode: "eef"  -> take_action(eepos16, action_type='ee')
#
# Both heads are decoded and logged on every replan regardless of which one is
# driving, so a single pair of runs yields the qpos-only vs eef-only ceiling
# plus the data needed to correlate head disagreement with task success.

import torch
import numpy as np
import cv2
from pathlib import Path
import sys
import os
import atexit
import logging
logging.basicConfig(level=logging.INFO, format='%(name)s - %(levelname)s - %(message)s')
from typing import Dict, Any, Optional
from collections import deque
import yaml
from PIL import Image
from transformers import AutoProcessor
from scipy.spatial.transform import Rotation as _Rotation
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend

# Add model paths
sys.path.append(str(Path(__file__).parent))
sys.path.append(str(Path(__file__).parent / "models"))

from models.motus_wan_vlm_direct_mask import MotusWanVlmDirectMask, MotusWanVlmDirectMaskConfig

# Add bak path for T5EncoderModel
BAK_ROOT = str((Path(__file__).parent / "bak").resolve())
if BAK_ROOT not in sys.path:
    sys.path.insert(0, BAK_ROOT)

from wan.modules.t5 import T5EncoderModel
from utils.image_utils import resize_with_padding
from utils.trajectory_recorder import TrajectoryRecorder
from qwen_vl_utils import process_vision_info

logger = logging.getLogger(__name__)


class MotusWanVlmDirectMaskCombined32Policy:
    """Policy wrapper for the 32-dim combined qpos + unified-EEF checkpoint."""

    ACTION_DIM = 32
    RESERVED_INDICES = [7, 15, 23, 31]

    # Fixed head camera extrinsics (OpenCV convention: x=right, y=down, z=forward).
    # R_w_c maps camera-frame vectors to world frame.
    _HEAD_CAMERA_R_W_C = np.array([
        [ 1.0,  0.0,  0.0],
        [ 0.0, -0.8,  0.6],
        [ 0.0, -0.6, -0.8],
    ], dtype=np.float64)
    _HEAD_CAMERA_T_W_C = np.array([-0.032, -0.45, 1.35], dtype=np.float64)

    # RobotWin metas/*.txt lines embed this prefix verbatim, and both the T5
    # embeddings and the VLM inputs were built from the full prefixed text during
    # training. The raw instruction at inference is the bare task, so the prefix
    # has to be re-added here to keep the text distribution consistent.
    _SCENE_PREFIX = (
        "The whole scene is in a realistic, industrial art style with three views: "
        "a fixed rear camera, a movable left arm camera, and a movable right arm camera. "
        "The aloha robot is currently performing the following task: "
    )

    def __init__(self, checkpoint_path: str, config_path: str, wan_path: str, vlm_path: str,
                 device: str = "cuda", log_dir: Optional[str] = None, task_name: Optional[str] = None,
                 vlm_prompt_mode: str = "simple",
                 control_mode: str = "qpos",
                 save_images: bool = False,
                 record_trajectory: bool = True,
                 record_dir: Optional[str] = None):
        """
        Args:
            vlm_prompt_mode: "simple" or "motion_token", must match training.
            control_mode: which head drives the robot, "qpos" or "eef".
            save_images: write the predicted-frame grid to disk (off by default;
                the grid is pure diagnostics and costs time on every replan).
            record_trajectory: dump per-episode action/state arrays for analysis.
            record_dir: where to write records; defaults to {log_dir}/trajectories.
        """
        self.device = device
        self.checkpoint_path = checkpoint_path
        self.wan_path = wan_path
        self.vlm_path = vlm_path
        self.vlm_prompt_mode = vlm_prompt_mode

        control_mode = str(control_mode).lower()
        if control_mode in ("eef", "unified_eef", "ee"):
            control_mode = "eef"
        if control_mode not in ("qpos", "eef"):
            raise ValueError(
                f"Unknown control_mode: {control_mode!r}. Expected 'qpos' or 'eef'."
            )
        self.control_mode = control_mode
        self.control_action_type = "qpos" if control_mode == "qpos" else "ee"

        logger.info(f"Control mode: {self.control_mode} (take_action type='{self.control_action_type}')")
        logger.info(f"VLM prompt mode: {self.vlm_prompt_mode}")

        # Load configuration
        with open(config_path, 'r') as f:
            self.config_dict = yaml.safe_load(f)

        cfg_action_dim = self.config_dict['common']['action_dim']
        if cfg_action_dim != self.ACTION_DIM:
            raise ValueError(
                f"This policy expects the combined 32-dim checkpoint, but "
                f"{config_path} declares action_dim={cfg_action_dim}."
            )

        self.chunk_size = (self.config_dict['common']['num_video_frames'] *
                           self.config_dict['common']['video_action_freq_ratio'])

        # Initialize model WITHOUT loading pretrained backbones
        self.model = self._load_model()

        # Initialize T5 encoder for language embeddings (WAN text encoder)
        self.t5_encoder = T5EncoderModel(
            text_len=512,
            dtype=torch.bfloat16,
            device=device,
            checkpoint_path=os.path.join(self.wan_path, 'models_t5_umt5-xxl-enc-bf16.pth'),
            tokenizer_path=os.path.join(self.wan_path, 'google', 'umt5-xxl'),
        )

        self.vlm_processor = AutoProcessor.from_pretrained(self.vlm_path, trust_remote_code=True)

        # Caches
        self._task_env = None                # set by eval() each step
        self.obs_cache = deque(maxlen=1)
        self.action_cache = deque()

        # Per-step observation state
        self.current_state = None            # torch [1, 32]
        self.current_state_np = None         # np (32,)
        self.current_eepos_state = None      # np (16,) absolute eepos anchor
        self.current_qpos_state = None       # np (14,) absolute joints
        self.is_first_step = True
        self.prev_action = None

        # Most recent decoded prediction (both heads), kept for recording
        self.last_pred32 = None              # np (T, 32)
        self.last_qpos_actions = None        # np (T, 14)
        self.last_eepos_actions = None       # np (T, 16)
        self.control_actions = None          # np (T, 14) or (T, 16)

        # Frame-grid rendering (diagnostics only, disabled by default)
        self.save_images = bool(save_images)
        base_log_dir = log_dir or os.environ.get('LOG_DIR') or str(Path(__file__).resolve().parent.parent / "logs")
        self.task_name = task_name or os.environ.get('TASK_NAME') or "default_task"
        self.save_dir = Path(base_log_dir) / "images" / self.task_name
        if self.save_images:
            self.save_dir.mkdir(parents=True, exist_ok=True)
        self.episode_count = -1
        self.step_count = 0

        # Trajectory recording
        record_root = record_dir or os.path.join(base_log_dir, "trajectories")
        self.recorder = TrajectoryRecorder(
            record_dir=record_root,
            task_name=self.task_name,
            control_mode=self.control_mode,
            enabled=bool(record_trajectory),
            extra_meta={"checkpoint_path": str(checkpoint_path)},
            unified_delta_to_eepos=self._unified_delta_to_eepos_actions,
        )

        logger.info("MotusWanVlmDirectMaskCombined32 Policy initialized successfully")

    def set_instruction(self, instruction: str):
        """Set the current instruction for the policy."""
        self.current_instruction = instruction
        logger.info(f"Instruction set: {instruction}")

    def _load_model(self) -> MotusWanVlmDirectMask:
        """Load the MotusWanVlmDirectMask model from checkpoint."""
        logger.info("Initializing MotusWanVlmDirectMask model from config")

        config = self._create_model_config()

        model = MotusWanVlmDirectMask(config)
        model = model.to(self.device)

        try:
            logger.info(f"Loading checkpoint from {self.checkpoint_path}")
            model.load_checkpoint(self.checkpoint_path, strict=False)
            logger.info("Model checkpoint loaded successfully")
        except Exception as e:
            logger.error(f"Failed to load checkpoint: {e}")
            raise

        model.eval()
        return model

    def _create_model_config(self) -> MotusWanVlmDirectMaskConfig:
        """Create model configuration from yaml config - inference mode."""
        common = self.config_dict['common']
        model_cfg = self.config_dict['model']

        vae_path = os.path.join(self.wan_path, "Wan2.2_VAE.pth")

        hidden_size = model_cfg['action_expert']['hidden_size']
        ffn_multiplier = model_cfg['action_expert']['ffn_dim_multiplier']

        config = MotusWanVlmDirectMaskConfig(
            wan_checkpoint_path=self.wan_path,
            vae_path=vae_path,
            wan_config_path=self.wan_path,
            video_precision='bfloat16',
            vlm_checkpoint_path=self.vlm_path,

            vlm_dim=model_cfg['qwen3_expert']['vlm_dim'],
            qwen3_expert_head_dim=model_cfg['qwen3_expert']['head_dim'],
            qwen3_expert_num_heads=model_cfg['qwen3_expert']['num_heads'],
            qwen3_expert_num_layers=model_cfg['qwen3_expert']['num_layers'],
            qwen3_expert_norm_eps=model_cfg['qwen3_expert']['norm_eps'],

            num_layers=model_cfg.get('num_layers', 30),
            action_state_dim=common['state_dim'],
            action_dim=common['action_dim'],
            action_expert_dim=hidden_size,
            action_expert_ffn_dim_multiplier=ffn_multiplier,
            action_expert_norm_eps=model_cfg['action_expert']['norm_eps'],

            global_downsample_rate=common['global_downsample_rate'],
            video_action_freq_ratio=common['video_action_freq_ratio'],
            num_video_frames=common['num_video_frames'],
            video_loss_weight=1.0,
            action_loss_weight=1.0,

            batch_size=1,
            video_height=common['video_height'],
            video_width=common['video_width'],
            training_mode='finetune',

            load_pretrained_backbones=False,
            vlm_frozen=False,
        )

        return config

    # ------------------------------------------------------------------
    # Combined 32-dim packing / unpacking
    # ------------------------------------------------------------------
    # These mirror the training-side transforms in
    # MotusV2/data/human/unified_eef_action.py and
    # MotusV2/data/robotwin2/robotwin_agilex_dataset.py.

    @staticmethod
    def _pad_qpos_14_to_16(qpos_14: np.ndarray) -> np.ndarray:
        """[L7, R7] -> [L7, 0, R7, 0], for a vector or a (T, 14) sequence."""
        qpos_14 = np.asarray(qpos_14, dtype=np.float32)
        out = np.zeros(qpos_14.shape[:-1] + (16,), dtype=np.float32)
        out[..., :7] = qpos_14[..., :7]
        out[..., 8:15] = qpos_14[..., 7:14]
        return out

    @staticmethod
    def _unpad_qpos_16_to_14(qpos_16: np.ndarray) -> np.ndarray:
        """[L7, 0, R7, 0] -> [L7, R7], dropping the reserved pads."""
        qpos_16 = np.asarray(qpos_16, dtype=np.float32)
        return np.concatenate([qpos_16[..., 0:7], qpos_16[..., 8:15]], axis=-1)

    @staticmethod
    def _quat_wxyz_to_rotmat(quat_wxyz: np.ndarray) -> np.ndarray:
        """Convert WXYZ quaternion (scalar first) to 3x3 rotation matrix."""
        quat_wxyz = np.asarray(quat_wxyz, dtype=np.float64)
        w = quat_wxyz[..., 0:1]
        quat_wxyz = np.where(w < 0, -quat_wxyz, quat_wxyz)
        quat_xyzw = np.roll(quat_wxyz, -1, axis=-1)
        return _Rotation.from_quat(quat_xyzw.reshape(-1, 4)).as_matrix().reshape(
            quat_wxyz.shape[:-1] + (3, 3)
        )

    @staticmethod
    def _rotmat_to_quat_wxyz(rotmat: np.ndarray) -> np.ndarray:
        """Convert 3x3 rotation matrix to WXYZ quaternion (scalar first)."""
        rotmat = np.asarray(rotmat, dtype=np.float64)
        q_xyzw = _Rotation.from_matrix(rotmat.reshape(-1, 3, 3)).as_quat().reshape(
            rotmat.shape[:-2] + (4,)
        )
        q_wxyz = np.roll(q_xyzw, 1, axis=-1)
        q_wxyz = np.where(q_wxyz[..., 0:1] < 0, -q_wxyz, q_wxyz)
        return q_wxyz

    @staticmethod
    def _log_so3(rotmat: np.ndarray) -> np.ndarray:
        """SO(3) log map: rotation matrix -> rotation vector."""
        r = np.asarray(rotmat, dtype=np.float64).reshape(-1, 3, 3)
        return _Rotation.from_matrix(r).as_rotvec().reshape(rotmat.shape[:-2] + (3,))

    @staticmethod
    def _exp_so3(rotvec: np.ndarray) -> np.ndarray:
        """SO(3) exp map: rotation vector -> rotation matrix."""
        v = np.asarray(rotvec, dtype=np.float64).reshape(-1, 3)
        return _Rotation.from_rotvec(v).as_matrix().reshape(rotvec.shape[:-1] + (3, 3))

    def _build_unified_eef_state(self, eepos_state: np.ndarray) -> np.ndarray:
        """Absolute eepos -> unified EEF camera-frame state (16D).

        Mirrors compute_unified_eef_state_16d_with_gripper() in training.

        eepos_state: [left_xyz(3), left_quat_wxyz(4), left_grip(1),
                      right_xyz(3), right_quat_wxyz(4), right_grip(1)]
        Returns:     [left_xyz_cam(3), left_rotvec_cam(3), left_grip(1), 0,
                      right_xyz_cam(3), right_rotvec_cam(3), right_grip(1), 0]
        """
        R_w_c = self._HEAD_CAMERA_R_W_C
        t_w_c = self._HEAD_CAMERA_T_W_C
        R_c_w = R_w_c.T  # world -> camera

        state_16d = np.zeros(16, dtype=np.float64)

        # Left arm
        R_w_e_left = self._quat_wxyz_to_rotmat(eepos_state[3:7])
        state_16d[0:3] = R_c_w @ (eepos_state[0:3] - t_w_c)
        state_16d[3:6] = self._log_so3(R_c_w @ R_w_e_left)
        state_16d[6] = float(eepos_state[7])
        # dim 7 reserved = 0

        # Right arm
        R_w_e_right = self._quat_wxyz_to_rotmat(eepos_state[11:15])
        state_16d[8:11] = R_c_w @ (eepos_state[8:11] - t_w_c)
        state_16d[11:14] = self._log_so3(R_c_w @ R_w_e_right)
        state_16d[14] = float(eepos_state[15])
        # dim 15 reserved = 0

        return state_16d

    def _unified_delta_to_eepos_actions(
        self, unified_actions: np.ndarray, eepos_anchor: np.ndarray
    ) -> np.ndarray:
        """Predicted unified camera-frame deltas -> absolute eepos actions.

        Inverse of compute_unified_eef_action_16d_with_gripper(). Every action
        is an anchor-based delta from the EEF pose captured in update_obs.

        Args:
            unified_actions: (T, 16), per arm [dxyz_cam(3), drotvec_cam(3), grip(1), 0]
            eepos_anchor: (16,) current absolute eepos

        Returns:
            (T, 16) absolute eepos for take_action(action_type='ee').
        """
        unified_actions = np.asarray(unified_actions, dtype=np.float64)
        eepos_anchor = np.asarray(eepos_anchor, dtype=np.float64)
        R_w_c = self._HEAD_CAMERA_R_W_C

        left_xyz_0 = eepos_anchor[0:3]
        right_xyz_0 = eepos_anchor[8:11]
        R_w_e_left = self._quat_wxyz_to_rotmat(eepos_anchor[3:7])
        R_w_e_right = self._quat_wxyz_to_rotmat(eepos_anchor[11:15])

        # R_c_e = R_w_c^T @ R_w_e
        R_c_e_left = R_w_c.T @ R_w_e_left
        R_c_e_right = R_w_c.T @ R_w_e_right

        T = unified_actions.shape[0]
        eepos_actions = np.zeros((T, 16), dtype=np.float64)

        for i in range(T):
            a = unified_actions[i]

            # --- Left arm ---
            R_delta_c_l = self._exp_so3(a[3:6])
            # R_delta_c = R_c_e @ R_e_e_star @ R_c_e^T  =>  R_e_e_star = R_c_e^T @ R_delta_c @ R_c_e
            R_e_e_star_l = R_c_e_left.T @ R_delta_c_l @ R_c_e_left
            # t_delta_c = R_c_e @ t_e_e_star           =>  t_e_e_star = R_c_e^T @ t_delta_c
            t_e_e_star_l = R_c_e_left.T @ a[0:3]

            eepos_actions[i, 0:3] = left_xyz_0 + R_w_e_left @ t_e_e_star_l
            eepos_actions[i, 3:7] = self._rotmat_to_quat_wxyz(R_w_e_left @ R_e_e_star_l)
            eepos_actions[i, 7] = float(a[6])

            # --- Right arm ---
            R_delta_c_r = self._exp_so3(a[11:14])
            R_e_e_star_r = R_c_e_right.T @ R_delta_c_r @ R_c_e_right
            t_e_e_star_r = R_c_e_right.T @ a[8:11]

            eepos_actions[i, 8:11] = right_xyz_0 + R_w_e_right @ t_e_e_star_r
            eepos_actions[i, 11:15] = self._rotmat_to_quat_wxyz(R_w_e_right @ R_e_e_star_r)
            eepos_actions[i, 15] = float(a[14])

        return eepos_actions.astype(np.float32)

    # ------------------------------------------------------------------
    # Observation / inference
    # ------------------------------------------------------------------
    def update_obs(self, observation: Dict[str, Any]):
        """Build the 32-dim state from the environment.

            [0:16]  padded absolute joint positions
            [16:32] unified EEF camera-frame pose + gripper

        The absolute eepos anchor is cached so predicted camera-frame deltas can
        be converted back to absolute poses for the simulator.
        """
        # Extract visual observations
        if 'observation' in observation:
            obs_data = observation['observation']
            if 'head_camera' in obs_data and 'left_camera' in obs_data and 'right_camera' in obs_data:
                head_img = obs_data['head_camera']['rgb']
                left_img = obs_data['left_camera']['rgb']
                right_img = obs_data['right_camera']['rgb']

                left_img_resized = cv2.resize(left_img, (160, 120))
                right_img_resized = cv2.resize(right_img, (160, 120))
                bottom_row = np.concatenate([left_img_resized, right_img_resized], axis=1)
                image = np.concatenate([head_img, bottom_row], axis=0)
            else:
                raise ValueError("Missing camera data")
        elif 'head_camera' in observation:
            image = observation['head_camera']
        elif 'image' in observation:
            image = observation['image']
        else:
            raise ValueError("No visual observation found")

        target_size = (self.config_dict['common']['video_height'],
                       self.config_dict['common']['video_width'])

        if isinstance(image, np.ndarray):
            image_tensor = torch.from_numpy(image).permute(2, 0, 1).unsqueeze(0)
        else:
            image_tensor = image

        if image_tensor.shape[-2:] != target_size:
            image_np = image_tensor.squeeze(0).permute(1, 2, 0).cpu().numpy()
            resized_np = resize_with_padding(image_np, target_size)
            if resized_np.dtype == np.uint8:
                resized_np = resized_np.astype(np.float32) / 255.0
            image_tensor = torch.from_numpy(resized_np).permute(2, 0, 1).unsqueeze(0)

        self.obs_cache.append(image_tensor.to(self.device))

        # --- qpos block: absolute joint positions, same source as qpos training ---
        qpos_14 = np.asarray(observation['joint_action']['vector'], dtype=np.float32).reshape(-1)
        if qpos_14.shape[0] != 14:
            raise ValueError(f"Expected 14-dim joint_action vector, got {qpos_14.shape}")
        self.current_qpos_state = qpos_14

        # --- EEF block: absolute EEF pose from the robot, then camera-frame ---
        left_ee = np.array(self._task_env.robot.get_left_ee_pose(), dtype=np.float32)    # [7]
        right_ee = np.array(self._task_env.robot.get_right_ee_pose(), dtype=np.float32)  # [7]
        left_grip = np.array([observation['joint_action']['left_gripper']], dtype=np.float32)
        right_grip = np.array([observation['joint_action']['right_gripper']], dtype=np.float32)

        eepos_state = np.concatenate([left_ee, left_grip, right_ee, right_grip])  # [16]
        self.current_eepos_state = eepos_state.astype(np.float64)

        state_32 = np.zeros(self.ACTION_DIM, dtype=np.float32)
        state_32[0:16] = self._pad_qpos_14_to_16(qpos_14)
        state_32[16:32] = self._build_unified_eef_state(self.current_eepos_state).astype(np.float32)
        state_32[self.RESERVED_INDICES] = 0.0

        self.current_state_np = state_32
        self.current_state = torch.from_numpy(state_32).unsqueeze(0).to(self.device)

    def _build_action_valid_mask(self) -> torch.Tensor:
        """Zero the reserved pads so the action encoder never sees noise there.

        Training zeroes dims [7, 15, 23, 31] on both the noisy actions and the
        target, so at inference they must be held at zero at init and after each
        Euler step to keep the input distribution identical.
        """
        mask_1d = torch.ones(self.ACTION_DIM, dtype=torch.float32)
        mask_1d[self.RESERVED_INDICES] = 0.0
        return mask_1d.view(1, 1, self.ACTION_DIM).expand(
            1, self.chunk_size, self.ACTION_DIM
        ).to(self.device)

    def get_action(self, instruction: str = None) -> np.ndarray:
        """Run the model and return the control actions for the active channel.

        Both heads are always decoded: ``self.last_qpos_actions`` (T, 14) and
        ``self.last_eepos_actions`` (T, 16) are populated on every call.
        """
        if len(self.obs_cache) == 0:
            raise ValueError("No observations in cache. Call update_obs first.")

        if self.current_state is None:
            raise ValueError("No robot state available. Call update_obs first.")

        current_frame = self.obs_cache[-1]

        # Encode instruction with T5 using the training-time prefixed text.
        prefixed_instruction = f"{self._SCENE_PREFIX}{self.current_instruction}"
        t5_out = self.t5_encoder([prefixed_instruction], self.device)
        if isinstance(t5_out, torch.Tensor):
            t5_list = [t5_out.squeeze(0)] if t5_out.dim() == 3 else [t5_out]
        elif isinstance(t5_out, list):
            t5_list = t5_out
        else:
            raise ValueError("Unexpected T5 encoder output format")

        first_frame_pil = self._tensor_to_pil_image(current_frame.squeeze(0).cpu())
        if self.vlm_prompt_mode == "motion_token":
            vlm_inputs = self._preprocess_vlm_messages_motion_prompt_only(
                prefixed_instruction, first_frame_pil
            )
        elif self.vlm_prompt_mode == "simple":
            vlm_inputs = self._preprocess_vlm_messages_simple(
                prefixed_instruction, first_frame_pil
            )
        else:
            raise ValueError(
                f"Unknown vlm_prompt_mode: {self.vlm_prompt_mode!r}. "
                f"Expected 'motion_token' or 'simple'."
            )

        action_valid_mask = self._build_action_valid_mask()

        num_inference_steps = self.config_dict['model']['inference']['num_inference_timesteps']
        with torch.no_grad():
            predicted_frames, predicted_actions = self.model.inference_step(
                first_frame=current_frame,
                state=self.current_state,
                num_inference_steps=num_inference_steps,
                language_embeddings=t5_list,
                vlm_inputs=vlm_inputs,
                action_valid_mask=action_valid_mask,
            )

        if self.save_images and predicted_frames is not None and predicted_frames.dim() == 5:
            if predicted_frames.shape[1] == 3:
                predicted_frames_viz = predicted_frames.permute(0, 2, 1, 3, 4)
            else:
                predicted_frames_viz = predicted_frames
            self._save_frame_grid(current_frame.squeeze(0), predicted_frames_viz.squeeze(0))
        self.step_count += 1

        pred32 = predicted_actions.squeeze(0).float().cpu().numpy()  # (T, 32)
        if pred32.ndim != 2 or pred32.shape[-1] != self.ACTION_DIM:
            raise ValueError(f"Expected (T, 32) prediction, got {pred32.shape}")

        # Decode both heads. Qpos is absolute joints; EEF is an anchor-based
        # camera-frame delta that has to be lifted back to absolute world poses.
        self.last_pred32 = pred32
        self.last_qpos_actions = self._unpad_qpos_16_to_14(pred32[:, 0:16])
        self.last_eepos_actions = self._unified_delta_to_eepos_actions(
            pred32[:, 16:32], self.current_eepos_state
        )

        if self.control_mode == "qpos":
            self.control_actions = self.last_qpos_actions.astype(np.float32)
        else:
            self.control_actions = self.last_eepos_actions.astype(np.float32)

        self.recorder.log_step(
            state32=self.current_state_np,
            pred32=pred32,
            anchor_eepos=self.current_eepos_state,
            obs_qpos14=self.current_qpos_state,
            take_action_cnt=int(getattr(self._task_env, "take_action_cnt", -1)),
        )

        self.prev_action = self.control_actions[-1].copy()
        self.action_cache.extend(self.control_actions)

        return self.control_actions

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _tensor_to_pil_image(self, tensor_chw: torch.Tensor) -> Image.Image:
        """Convert [C, H, W] tensor to PIL Image."""
        if tensor_chw.dtype != torch.float32:
            tensor_chw = tensor_chw.float()
        tensor_chw = tensor_chw.clamp(0, 1)
        np_img = (tensor_chw.permute(1, 2, 0).numpy() * 255.0).astype(np.uint8)
        return Image.fromarray(np_img, mode='RGB')

    def _preprocess_vlm_messages_motion_prompt_only(
        self, text_instruction: str, image_pil: Image.Image
    ) -> Dict[str, torch.Tensor]:
        """Motion-token prompt format (prompt only, no GT response)."""
        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "image", "image": image_pil},
                    {
                        "type": "text",
                        "text": (
                            f"Task: {text_instruction}\n"
                            "Predict the 3D wrist motion trajectories for both hands "
                            "in the robot base coordinate system. Return only motion tokens."
                        ),
                    },
                ],
            }
        ]
        return self._encode_vlm_messages(messages, image_pil)

    def _preprocess_vlm_messages_simple(
        self, text_instruction: str, image_pil: Image.Image
    ) -> Dict[str, torch.Tensor]:
        """Simple instruction prompt, matching preprocess_vlm_messages() in training."""
        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "image", "image": image_pil},
                    {"type": "text", "text": text_instruction},
                ],
            }
        ]
        return self._encode_vlm_messages(messages, image_pil)

    def _encode_vlm_messages(self, messages, image_pil: Image.Image) -> Dict[str, torch.Tensor]:
        text = self.vlm_processor.apply_chat_template(
            messages, add_generation_prompt=True, tokenize=False
        )

        image_inputs, video_inputs = process_vision_info(messages)
        encoded = self.vlm_processor(
            text=[text],
            images=image_inputs,
            videos=video_inputs,
            padding=True,
            return_tensors="pt",
        )

        vlm_inputs = {
            'input_ids': encoded['input_ids'].to(self.device),
            'attention_mask': encoded['attention_mask'].to(self.device),
            'pixel_values': encoded['pixel_values'].to(self.device),
        }
        if 'image_grid_thw' in encoded and encoded['image_grid_thw'] is not None:
            vlm_inputs['image_grid_thw'] = encoded['image_grid_thw'].to(self.device)

        return vlm_inputs

    def _create_frame_grid(self, condition_frame: torch.Tensor, predicted_frames: torch.Tensor) -> Image.Image:
        """Create horizontal grid."""
        def tensor_to_numpy(tensor):
            if tensor.dim() == 3:
                tensor = tensor.permute(1, 2, 0)
            tensor = tensor.detach().cpu().float()
            tensor = torch.clamp(tensor, 0, 1)
            return (tensor.numpy() * 255).astype(np.uint8)

        condition_np = tensor_to_numpy(condition_frame)
        predicted_np = [tensor_to_numpy(predicted_frames[i]) for i in range(predicted_frames.shape[0])]

        while len(predicted_np) < 4:
            predicted_np.append(predicted_np[-1] if predicted_np else condition_np)

        all_frames = [condition_np] + predicted_np[:4]
        return Image.fromarray(np.concatenate(all_frames, axis=1))

    def _save_frame_grid(self, condition_frame: torch.Tensor, predicted_frames: torch.Tensor):
        """Save frame grid to disk."""
        if not self.save_images:
            return

        try:
            grid_image = self._create_frame_grid(condition_frame, predicted_frames)
            filename = f"episode_{max(self.episode_count, 0):04d}_step_{self.step_count:04d}.png"
            grid_image.save(self.save_dir / filename)
        except Exception as e:
            logger.warning(f"Failed to save frame grid: {e}")


def encode_obs(observation):
    """Post-Process Observation"""
    return observation


def _load_policy_options(policy_dir: Path) -> Dict[str, Any]:
    """Read the inference knobs from paths_config.yml, with env overrides.

    The env overrides let the qpos-only and eef-only runs share one config file
    (and run concurrently) instead of editing the yaml between launches.
    """
    options = {
        "vlm_prompt_mode": "simple",
        "control_mode": "qpos",
        "save_images": False,
        "record_trajectory": True,
        "record_dir": None,
    }

    paths_config_path = policy_dir / "paths_config.yml"
    if paths_config_path.exists():
        with open(paths_config_path, 'r', encoding='utf-8') as f:
            paths_config = yaml.safe_load(f) or {}
        for key in options:
            if key in paths_config and paths_config[key] is not None:
                options[key] = paths_config[key]
    else:
        logger.warning(f"paths_config.yml not found at {paths_config_path}, using defaults")

    env_overrides = {
        "control_mode": "MOTUS_CONTROL_MODE",
        "vlm_prompt_mode": "MOTUS_VLM_PROMPT_MODE",
        "record_dir": "MOTUS_RECORD_DIR",
    }
    for key, env_name in env_overrides.items():
        value = os.environ.get(env_name)
        if value:
            options[key] = value
            logger.info(f"Override {key} from {env_name}: {value}")

    for key, env_name in (("save_images", "MOTUS_SAVE_IMAGES"),
                          ("record_trajectory", "MOTUS_RECORD_TRAJECTORY")):
        value = os.environ.get(env_name)
        if value is not None and value != "":
            options[key] = value.strip().lower() in ("1", "true", "yes", "on")
            logger.info(f"Override {key} from {env_name}: {options[key]}")

    logger.info(f"Policy options: {options}")
    return options


def get_model(usr_args):
    """Initialize the combined 32-dim policy."""
    checkpoint_path = usr_args.get('ckpt_setting')
    wan_path = usr_args.get('wan_path')
    vlm_path = usr_args.get('vlm_path')

    if not wan_path:
        raise ValueError("wan_path not provided in usr_args")

    if not vlm_path:
        raise ValueError("vlm_path not provided in usr_args")

    policy_dir = Path(__file__).parent
    config_path = policy_dir / "utils" / "robotwin_wan_vlm.yml"
    options = _load_policy_options(policy_dir)

    device = "cuda" if torch.cuda.is_available() else "cpu"

    policy = MotusWanVlmDirectMaskCombined32Policy(
        checkpoint_path=checkpoint_path,
        wan_path=wan_path,
        vlm_path=vlm_path,
        config_path=str(config_path),
        device=device,
        log_dir=usr_args.get('log_dir'),
        task_name=usr_args.get('task_name'),
        vlm_prompt_mode=options["vlm_prompt_mode"],
        control_mode=options["control_mode"],
        save_images=bool(options["save_images"]),
        record_trajectory=bool(options["record_trajectory"]),
        record_dir=options["record_dir"],
    )

    # The eval loop never signals "last episode finished", so flush on exit to
    # avoid dropping the final episode's record.
    atexit.register(lambda: policy.recorder.end_episode())

    return policy


def eval(TASK_ENV, model, observation):
    """Evaluation step.

    The control channel is chosen by ``control_mode``: qpos actions go to
    take_action(action_type='qpos'), EEF actions to action_type='ee'. The
    non-driving head is still decoded and recorded.
    """
    # update_obs needs the robot handle to read the current EE pose
    model._task_env = TASK_ENV

    obs = encode_obs(observation)

    instruction = TASK_ENV.get_instruction()
    model.set_instruction(instruction)
    model.update_obs(obs)

    actions = model.get_action()

    cnt_before = TASK_ENV.take_action_cnt
    for action in actions:
        TASK_ENV.take_action(action, action_type=model.control_action_type)
    n_executed = TASK_ENV.take_action_cnt - cnt_before

    model.recorder.log_execution(
        n_executed=n_executed,
        success=bool(getattr(TASK_ENV, "eval_success", False)),
    )


def reset_model(model):
    """Flush the finished episode and reset caches for the next one."""
    model.recorder.end_episode()

    model.obs_cache.clear()
    model.action_cache.clear()
    model.current_state = None
    model.current_state_np = None
    model.current_eepos_state = None
    model.current_qpos_state = None
    model.is_first_step = True
    model.prev_action = None
    model.last_pred32 = None
    model.last_qpos_actions = None
    model.last_eepos_actions = None
    model.control_actions = None
    model.episode_count += 1
    model.step_count = 0

    model.recorder.start_episode(model.episode_count)
    logger.info(f"Model reset completed for episode {model.episode_count}")

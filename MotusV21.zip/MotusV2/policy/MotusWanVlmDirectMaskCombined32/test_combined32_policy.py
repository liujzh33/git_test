"""Offline checks for the combined 32-dim policy.

Runs without a GPU, a checkpoint, or RoboTwin: the heavy imports of
``deploy_policy`` are stubbed so the pure numpy transforms can be cross-checked
against the training-side implementation in ``MotusV2/data/human/unified_eef_action.py``.

    python test_combined32_policy.py
"""

import json
import sys
import tempfile
import types
from pathlib import Path

import numpy as np

POLICY_DIR = Path(__file__).resolve().parent
MOTUS_ROOT = POLICY_DIR.parent.parent


def _stub_heavy_imports():
    """Install placeholders for modules that need a GPU / RoboTwin install."""

    def _module(name, **attrs):
        mod = types.ModuleType(name)
        for key, value in attrs.items():
            setattr(mod, key, value)
        sys.modules[name] = mod
        return mod

    class _Dummy:
        def __init__(self, *args, **kwargs):
            raise RuntimeError("stub: not usable in offline tests")

        @classmethod
        def from_pretrained(cls, *args, **kwargs):
            raise RuntimeError("stub: not usable in offline tests")

    _module("models", __path__=[])
    _module(
        "models.motus_wan_vlm_direct_mask",
        MotusWanVlmDirectMask=_Dummy,
        MotusWanVlmDirectMaskConfig=_Dummy,
    )
    _module("wan", __path__=[])
    _module("wan.modules", __path__=[])
    _module("wan.modules.t5", T5EncoderModel=_Dummy)
    _module("qwen_vl_utils", process_vision_info=lambda *a, **k: (None, None))

    for name in ("cv2", "transformers", "matplotlib", "PIL", "PIL.Image"):
        if name in sys.modules:
            continue
        try:
            __import__(name)
        except ImportError:
            if name == "transformers":
                _module(name, AutoProcessor=_Dummy)
            elif name == "matplotlib":
                _module(name, use=lambda *a, **k: None)
            elif name == "PIL":
                _module(name, __path__=[])
            elif name == "PIL.Image":
                _module(name, Image=object, fromarray=lambda *a, **k: None)
            else:
                _module(name)


_stub_heavy_imports()
# POLICY_DIR must precede MOTUS_ROOT: both ship a top-level ``utils`` package
# and the policy's own copy is the one under test.
sys.path.insert(0, str(MOTUS_ROOT))
sys.path.insert(0, str(POLICY_DIR))

from deploy_policy import MotusWanVlmDirectMaskCombined32Policy as Policy  # noqa: E402
from utils.trajectory_recorder import TrajectoryRecorder, quat_wxyz_angle  # noqa: E402

# Training-side reference implementation
from data.human.unified_eef_action import (  # noqa: E402
    build_hand_world_poses_from_xyzquat,
    compute_unified_eef_action_sequence_with_gripper,
    compute_unified_eef_state_from_poses_with_gripper,
    pack_combined_qpos_eef_32,
    build_combined_qpos_eef_valid_mask,
    UNIFIED_EEF_ROBOT_EFFECTIVE_INDICES,
)

RNG = np.random.default_rng(0)


def _random_eepos(n_frames: int) -> np.ndarray:
    """Random but valid absolute eepos sequence (xyz + unit quat + gripper) x2."""
    out = np.zeros((n_frames, 16), dtype=np.float64)
    for i in range(n_frames):
        for base, off in ((0, 0), (8, 1)):
            out[i, base:base + 3] = RNG.normal(scale=0.3, size=3) + np.array([0.2 * off, 0.1, 0.9])
            q = RNG.normal(size=4)
            q /= np.linalg.norm(q)
            if q[0] < 0:
                q = -q
            out[i, base + 3:base + 7] = q
        out[i, 7] = RNG.uniform(0, 1)
        out[i, 15] = RNG.uniform(0, 1)
    return out


def test_qpos_padding_roundtrip():
    qpos = RNG.normal(size=(5, 14)).astype(np.float32)
    padded = Policy._pad_qpos_14_to_16(qpos)
    assert padded.shape == (5, 16)
    assert np.allclose(padded[:, [7, 15]], 0.0)
    np.testing.assert_allclose(Policy._unpad_qpos_16_to_14(padded), qpos)

    # Must agree with the training-side packing helper.
    eef = RNG.normal(size=(5, 16)).astype(np.float32)
    eef[:, [7, 15]] = 0.0
    combined = pack_combined_qpos_eef_32(qpos, eef)
    np.testing.assert_allclose(combined[:, 0:16], padded)
    np.testing.assert_allclose(combined[:, 16:32], eef)
    print("ok  qpos padding round-trip matches training packing")


def test_state_matches_training():
    """Policy state construction must equal the dataset's state construction."""
    eepos = _random_eepos(1)[0]

    policy_state = Policy._build_unified_eef_state(Policy, eepos)

    left_R, left_t = build_hand_world_poses_from_xyzquat(eepos[None, 0:3], eepos[None, 3:7])
    right_R, right_t = build_hand_world_poses_from_xyzquat(eepos[None, 8:11], eepos[None, 11:15])
    ref_state, _ = compute_unified_eef_state_from_poses_with_gripper(
        R_w_e_left=left_R[0], t_w_e_left=left_t[0],
        R_w_e_right=right_R[0], t_w_e_right=right_t[0],
        R_w_c=Policy._HEAD_CAMERA_R_W_C.astype(np.float32),
        t_w_c=Policy._HEAD_CAMERA_T_W_C.astype(np.float32),
        left_gripper=float(eepos[7]), right_gripper=float(eepos[15]),
        left_valid=True, right_valid=True,
    )

    np.testing.assert_allclose(policy_state, ref_state, atol=1e-5)
    assert policy_state[7] == 0.0 and policy_state[15] == 0.0
    print("ok  EEF state block matches training compute_unified_eef_state_*")


def test_delta_inverse_recovers_absolute_poses():
    """delta -> eepos must invert the training forward transform exactly."""
    n_targets = 6
    eepos = _random_eepos(n_targets + 1)

    left_R, left_t = build_hand_world_poses_from_xyzquat(eepos[:, 0:3], eepos[:, 3:7])
    right_R, right_t = build_hand_world_poses_from_xyzquat(eepos[:, 8:11], eepos[:, 11:15])

    actions, masks = compute_unified_eef_action_sequence_with_gripper(
        R_w_e_left=left_R, t_w_e_left=left_t,
        R_w_e_right=right_R, t_w_e_right=right_t,
        R_w_c=Policy._HEAD_CAMERA_R_W_C.astype(np.float32),
        left_gripper=eepos[:, 7], right_gripper=eepos[:, 15],
        left_valid=np.ones(n_targets + 1, dtype=bool),
        right_valid=np.ones(n_targets + 1, dtype=bool),
        num_action_frames=n_targets,
    )

    recovered = Policy._unified_delta_to_eepos_actions(Policy, actions, eepos[0])

    for i in range(n_targets):
        np.testing.assert_allclose(recovered[i, 0:3], eepos[i + 1, 0:3], atol=1e-4)
        np.testing.assert_allclose(recovered[i, 8:11], eepos[i + 1, 8:11], atol=1e-4)
        assert quat_wxyz_angle(recovered[i, 3:7], eepos[i + 1, 3:7]) < 1e-3
        assert quat_wxyz_angle(recovered[i, 11:15], eepos[i + 1, 11:15]) < 1e-3
        assert abs(recovered[i, 7] - eepos[i + 1, 7]) < 1e-5
        assert abs(recovered[i, 15] - eepos[i + 1, 15]) < 1e-5

    mask32 = build_combined_qpos_eef_valid_mask(masks)
    assert mask32.shape == (n_targets, 32)
    assert np.allclose(mask32[:, [7, 15, 23, 31]], 0.0)
    for idx in UNIFIED_EEF_ROBOT_EFFECTIVE_INDICES:
        assert np.all(mask32[:, idx + 16] == 1.0)
    print("ok  unified delta -> absolute eepos inverts the training transform")


def test_control_channel_slicing():
    """The 32-dim prediction must split into the exact simulator layouts."""
    chunk = 4
    pred32 = RNG.normal(size=(chunk, 32)).astype(np.float32)
    pred32[:, [7, 15, 23, 31]] = 0.0

    qpos14 = Policy._unpad_qpos_16_to_14(pred32[:, 0:16])
    assert qpos14.shape == (chunk, 14)
    # take_action('qpos') reads [left_j6, left_grip, right_j6, right_grip]
    np.testing.assert_allclose(qpos14[:, 0:6], pred32[:, 0:6])
    np.testing.assert_allclose(qpos14[:, 6], pred32[:, 6])
    np.testing.assert_allclose(qpos14[:, 7:13], pred32[:, 8:14])
    np.testing.assert_allclose(qpos14[:, 13], pred32[:, 14])

    anchor = _random_eepos(1)[0]
    eepos16 = Policy._unified_delta_to_eepos_actions(Policy, pred32[:, 16:32], anchor)
    assert eepos16.shape == (chunk, 16)
    # take_action('ee') reads [left_xyzquat(7), left_grip, right_xyzquat(7), right_grip]
    np.testing.assert_allclose(eepos16[:, 7], pred32[:, 22], atol=1e-6)
    np.testing.assert_allclose(eepos16[:, 15], pred32[:, 30], atol=1e-6)
    for i in range(chunk):
        assert abs(np.linalg.norm(eepos16[i, 3:7]) - 1.0) < 1e-5
        assert abs(np.linalg.norm(eepos16[i, 11:15]) - 1.0) < 1e-5
    print("ok  control-channel slicing matches take_action layouts")


def test_recorder_and_analysis_roundtrip():
    n_steps, chunk = 5, 4
    with tempfile.TemporaryDirectory() as tmp:
        recorder = TrajectoryRecorder(
            record_dir=tmp,
            task_name="fake_task",
            control_mode="qpos",
            enabled=True,
            unified_delta_to_eepos=lambda d, a: Policy._unified_delta_to_eepos_actions(Policy, d, a),
        )

        for episode in range(2):
            recorder.start_episode(episode)
            for step in range(n_steps):
                pred32 = RNG.normal(scale=0.05, size=(chunk, 32)).astype(np.float32)
                pred32[:, [7, 15, 23, 31]] = 0.0
                recorder.log_step(
                    state32=RNG.normal(size=32).astype(np.float32),
                    pred32=pred32,
                    anchor_eepos=_random_eepos(1)[0].astype(np.float32),
                    obs_qpos14=RNG.normal(size=14).astype(np.float32),
                    take_action_cnt=step * chunk,
                )
                recorder.log_execution(n_executed=chunk, success=(episode == 1 and step == n_steps - 1))
            recorder.end_episode()

        task_dir = Path(tmp) / "fake_task"
        assert (task_dir / "episode_0000.npz").exists()
        assert (task_dir / "episode_0001.npz").exists()

        with np.load(task_dir / "episode_0000.npz") as data:
            assert data["pred32"].shape == (n_steps, chunk, 32)
            assert data["state32"].shape == (n_steps, 32)
            assert data["anchor_eepos"].shape == (n_steps, 16)
            assert data["obs_qpos14"].shape == (n_steps, 14)
            assert data["n_executed"].shape == (n_steps,)

        lines = (task_dir / "episodes.jsonl").read_text().strip().split("\n")
        assert len(lines) == 2
        summaries = [json.loads(line) for line in lines]
        assert summaries[0]["success"] is False
        assert summaries[1]["success"] is True
        for s in summaries:
            assert s["n_steps"] == n_steps
            assert s["control_mode"] == "qpos"
            # EEF tracking error requires the converter, which was supplied.
            assert s["track_err_eef_pos_l_mean"] is not None
            assert s["track_err_qpos_mean"] is not None
            assert s["grip_gap_l_mean"] is not None

        # The analysis CLI must consume the very files just written.
        import subprocess

        result = subprocess.run(
            [sys.executable, str(POLICY_DIR / "analyze_records.py"), "--run", tmp,
             "--per-step-csv", str(Path(tmp) / "steps.csv")],
            capture_output=True, text=True,
        )
        assert result.returncode == 0, result.stderr
        assert "success rate" in result.stdout
        assert (Path(tmp) / "steps.csv").exists()

    print("ok  recorder round-trip + analyze_records.py")


if __name__ == "__main__":
    test_qpos_padding_roundtrip()
    test_state_matches_training()
    test_delta_inverse_recovers_absolute_poses()
    test_control_channel_slicing()
    test_recorder_and_analysis_roundtrip()
    print("\nALL CHECKS PASSED")

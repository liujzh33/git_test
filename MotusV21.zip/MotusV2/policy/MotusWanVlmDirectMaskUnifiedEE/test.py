import yaml, re
cfg_path="/cache/motus_codes/RoboTwin/policy/MotusWanVlmDirectMask/paths_config.yml"
cfg=yaml.safe_load(open(cfg_path,'r',encoding='utf-8'))
def walk(d, prefix=""):
    if isinstance(d, dict):
        for k,v in d.items():
            walk(v, prefix + str(k) + ".")
    elif isinstance(d, list):
        for i,v in enumerate(d):
            walk(v, prefix + f"[{i}].")
    else:
        s=str(d)
        if any(x in prefix.lower() for x in ["ckpt","checkpoint","weight","model"]):
            print(prefix[:-1], "=>", repr(s))
walk(cfg)
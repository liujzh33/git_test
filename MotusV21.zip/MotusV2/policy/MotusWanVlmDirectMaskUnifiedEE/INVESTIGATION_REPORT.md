# UnifiedEEF 训推一致性排查报告

**日期**: 2026-06-29  
**排查范围**: MotusWanVlmDirectMaskUnifiedEE 设定在 RoboTwin 上的训推一致性

---

## 1. 检查过的关键文件列表

### 训练侧 (MotusV2)
| 文件 | 用途 |
|------|------|
| `scripts/train_ADS_MotusV2_robotwin_unified_eef.sh` | 训练启动脚本 |
| `configs/robotwin_unified_eef_WanVlmMask.yaml` | 训练配置 |
| `data/robotwin2/robotwin_agilex_dataset.py` | 数据加载、action 转换、VLM prompt |
| `data/human/unified_eef_action.py` | UnifiedEEF action 生成函数 |
| `models/motus_wan_vlm_direct_mask.py` | 模型定义 (inference_step, loss) |
| `utils/vlm_utils.py` | VLM prompt 构造函数 |

### 推理侧 (RoboTwin_EE / cache)
| 文件 | 用途 |
|------|------|
| `policy/MotusWanVlmDirectMaskUnifiedEE/deploy_policy.py` | 推理 policy (已修改) |
| `policy/MotusWanVlmDirectMaskUnifiedEE/auto_eval_new.sh` | 评测脚本 (已修改) |
| `policy/MotusWanVlmDirectMaskUnifiedEE/paths_config.yml` | 路径和模式配置 |
| `policy/MotusWanVlmDirectMaskUnifiedEE/utils/robotwin_wan_vlm.yml` | 模型配置 |
| `policy/MotusWanVlmDirectMaskMotion/deploy_policy.py` | 旧 eepos policy (对比参考) |
| `script/eval_policy.py` | 评测入口脚本 |

### Checkpoint / 日志
| 文件 | 用途 |
|------|------|
| `/cache/wx1469573/pretrained_models/ckpt/` | 推理用的 checkpoint |
| `logs_20260629_092924/` | 失败评测日志 |
| `tensorboard_WanVlmMask_ft_Robotwin_unified_eef/` | 训练日志 |

---

## 2. 训练侧 vs 推理侧一致性对齐表

| 检查项 | 训练侧实现 | 推理侧实现 (修复前) | 推理侧实现 (修复后) | 是否一致 | 风险等级 | 证据 |
|--------|-----------|---------------------|---------------------|---------|---------|------|
| **policy 代码** | N/A | 加载 `MotusWanVlmDirectMaskMotion` (旧 eepos) | 加载 `MotusWanVlmDirectMaskUnifiedEE` | ✅ 修复 | **致命** | eval log: `MotusWanVlmDirectMaskMotion.deploy_policy` |
| **action_dim** | 16 | 16 | 16 | ✅ | - | config.json |
| **action_order** | `[dxyz_cam(3), drotvec_cam(3), grip(1), 0] x2` | `[xyz(3), quat(4), grip(1)] x2` (eepos) | `[dxyz_cam(3), drotvec_cam(3), grip(1), 0] x2` | ✅ 修复 | **致命** | deploy_policy.py |
| **rotation 表示** | rotvec (axis-angle, 3D) | quaternion (4D) | rotvec (3D) | ✅ 修复 | **致命** | unified_eef_action.py L668 |
| **reserved dims** | dims 7,15 = 0, mask=0 | 无 reserved | dims 7,15 = 0 | ✅ 修复 | 高 | unified_eef_action.py L694-708 |
| **gripper dims** | dims 6,14 (target gripper) | dims 7,15 | dims 6,14 | ✅ 修复 | **致命** | unified_eef_action.py L694 |
| **horizon/chunk 语义** | anchor-based: `action[i] = delta(pose[0] -> pose[i+1])` | 无 delta 转换 | anchor-based, `_unified_delta_to_eepos_actions` | ✅ 修复 | **致命** | dataset L786, deploy_policy L334 |
| **normalization** | false (无归一化) | 无归一化 | 无归一化 | ✅ | - | yaml L38 |
| **camera extrinsics** | `R_w_c=[[1,0,0],[0,-0.8,0.6],[0,-0.6,-0.8]], t_w_c=[-0.032,-0.45,1.35]` | 无 camera 转换 | 硬编码相同值 | ✅ 修复 | 高 | dataset L908-914, deploy_policy L63-68 |
| **VLM prompt** | simple (`text_instruction` only) | motion_token (`"Task: ... Predict the 3D wrist..."`) | simple (`text_instruction` only) | ✅ 修复 | **致命** | vlm_utils L12-30, deploy_policy L624-667 |
| **T5 prompt** | scene_prefix + instruction | scene_prefix + instruction | scene_prefix + instruction | ✅ | - | deploy_policy L500-503 |
| **image 预处理** | head(384x320) + left(160x120) + right(160x120) 拼接 | 相同 | 相同 | ✅ | - | deploy_policy L434-441 |
| **image resize** | resize_with_padding to (384,320) | 相同 | 相同 | ✅ | - | deploy_policy L459-464 |
| **state 输入** | unified 16D camera-frame state | absolute eepos 16D | unified 16D camera-frame state | ✅ 修复 | **致命** | deploy_policy L491-493 |
| **action 输出 decode** | N/A (训练时不 decode) | 直接作为 absolute eepos | `_unified_delta_to_eepos_actions` 转换 | ✅ 修复 | **致命** | deploy_policy L595-598 |
| **checkpoint loading** | N/A | `strict=False`, missing=0, unexpected=0 | 相同 | ✅ | - | model load_checkpoint |
| **model eval mode** | N/A | `model.eval()` | `model.eval()` | ✅ | - | deploy_policy L183 |
| **RoboTwin controller** | N/A | `take_action(action_type='ee')` | `take_action(action_type='ee')` | ✅ | - | deploy_policy L781 |
| **action_chunk 执行** | 16 actions per chunk, anchor-based | 16 actions 全部执行 | 16 actions 全部执行 (转换后 absolute eepos) | ✅ | - | eval_policy L296-298 |
| **训练步数** | 50000 steps | - | - | ⚠️ 仅训练到 2783 步 | 高 | train.log |

---

## 3. 发现的问题列表 (按严重程度排序)

### 问题 #1 (致命): 评测脚本加载了错误的 policy 代码

**现象**: 评测日志显示 `MotusWanVlmDirectMaskMotion.deploy_policy - INFO`，即加载了旧的 eepos policy，而非 UnifiedEEF policy。

**根因**: `auto_eval_new.sh` 中硬编码了 `POLICY_NAME="MotusWanVlmDirectMaskMotion"`，且 `ROBOTWIN_ROOT="/cache/wx1469573/RoboTwin"`。`eval_policy.py` 通过 `importlib.import_module(policy_name)` 从 `/cache/wx1469573/RoboTwin/policy/MotusWanVlmDirectMaskMotion/` 加载了旧 eepos policy。

而 UnifiedEEF 修改只在 `/home/ma-user/work/wx1469573/RoboTwin_EE/policy/MotusWanVlmDirectMaskUnifiedEE/` 中，从未被评测脚本加载。

**后果**:
- state 以 absolute eepos 构建（而非 camera-frame unified state）
- 模型输出被直接当作 absolute eepos 传给模拟器（而非从 camera-frame delta 转换）
- VLM prompt 使用 motion_token 格式（而非训练时的 simple 格式）

**修复**:
1. 将 `MotusWanVlmDirectMaskUnifiedEE/` 目录复制到 `/cache/wx1469573/RoboTwin/policy/`
2. 将 `auto_eval_new.sh` 中 `POLICY_NAME` 改为 `"MotusWanVlmDirectMaskUnifiedEE"`

### 问题 #2 (致命): VLM prompt 格式不一致

**现象**: 训练配置 `robotwin_unified_eef_WanVlmMask.yaml` 中无 `motion_token_prediction` 配置，训练使用 `preprocess_vlm_messages()` (simple 格式: 仅 `text_instruction`)。但旧 eepos policy 硬编码使用 motion_token 格式 (`"Task: {instruction}\nPredict the 3D wrist motion trajectories..."`)。

**根因**: 旧 `MotusWanVlmDirectMaskMotion/deploy_policy.py` 的 `_preprocess_vlm_messages_motion_prompt_only()` 硬编码了 motion_token prompt，与训练时的 simple prompt 不一致。

**后果**: VLM 接收到训练时从未见过的 prompt 格式，导致 VLM 特征分布偏移，模型输出质量严重下降。

**修复**: UnifiedEEF policy 已支持 `vlm_prompt_mode: "simple"`，`paths_config.yml` 已设置为 `"simple"`。只需使用 UnifiedEEF policy 即可自动修复。

### 问题 #3 (高): 训练严重不足

**现象**: 训练日志显示仅训练到 step 2783/50000 (约 5.6%)，action loss 仍在 0.01-0.07 波动。

**根因**: 训练可能在 step 2783 后中断（日志截止于 Jun 26 16:55）。

**后果**: 即使修复训推一致性问题，模型性能也会因训练不足而较差。

**建议**: 继续训练至至少 50000 步，或直到 action loss 收敛。

### 问题 #4 (需验证): Checkpoint 来源不确定

**现象**: `/cache/wx1469573/pretrained_models/ckpt/mp_rank_00_model_states.pt` 修改时间为 Jun 29 09:24 (评测前 5 分钟)。训练输出在 `/cache/wx1469573/ckpts/checkpoints_WanVlmMask_ft_Robotwin_unified_eef/.../best_action_l2/`。

**风险**: 如果 `pretrained_models/ckpt` 仍是原始 eepos 预训练权重（而非 unified_eef 训练后的权重），则即使使用 UnifiedEEF policy，模型输出的也是 eepos 格式的动作，被错误地当作 camera-frame delta 解析。

**验证方法**: 运行 `MOTUS_UNIFIED_EEF_DEBUG=1` 评测，检查 raw action output 的数值范围。unified_eef delta 的数值应该较小（dxyz ~0.01-0.1, drotvec ~0.01-0.3），而 eepos absolute pose 的数值较大（xyz ~0.3-0.9, quat ~-1 to 1）。

---

## 4. 代码修复说明

### 修复 1: 复制 UnifiedEEF policy 到 cache checkout

```bash
cp -r /home/ma-user/work/wx1469573/RoboTwin_EE/policy/MotusWanVlmDirectMaskUnifiedEE \
      /cache/wx1469573/RoboTwin/policy/
```

**原因**: 评测脚本从 `/cache/wx1469573/RoboTwin/` 运行，需要 UnifiedEEF policy 目录存在于该路径。

### 修复 2: 修改 POLICY_NAME

**文件**: `auto_eval_new.sh` (两个位置都已修改)

```diff
- POLICY_NAME="MotusWanVlmDirectMaskMotion"
+ POLICY_NAME="MotusWanVlmDirectMaskUnifiedEE"
```

**原因**: 让评测脚本加载正确的 UnifiedEEF policy。

### 修复 3: 添加 debug instrumentation

**文件**: `deploy_policy.py`

添加了 `MOTUS_UNIFIED_EEF_DEBUG=1` 环境变量开关，开启后在前 10 个 step 打印:
- `update_obs`: eepos_state, unified_state, left/right xyz_cam, rotvec_cam
- `get_action`: raw model output (shape, min/max/mean/std, NaN/Inf 检查, delta norm, reserved dims)
- `converted_action`: 转换后的 absolute eepos actions
- `checkpoint_load`: action_expert decoder 参数统计 (mean, std, NaN, all_zero)

保存到 `debug_unified_eef_trace.jsonl`。

### 修复 4: 添加 sanity check 测试脚本

**文件**: `test_unified_eef_consistency.py`

测试内容:
1. Action layout 正确性 (reserved dims=0, gripper at 6/14, rotvec 3D not quat 4D)
2. Action round-trip (训练 forward → 推理 inverse，误差 < 1e-6)
3. Zero delta → recovers anchor
4. Checkpoint loading (参数非 NaN, 非全零)

---

## 5. 修改过的文件列表

| 文件 | 修改内容 |
|------|---------|
| `RoboTwin_EE/policy/MotusWanVlmDirectMaskUnifiedEE/auto_eval_new.sh` | `POLICY_NAME` 改为 `MotusWanVlmDirectMaskUnifiedEE` |
| `RoboTwin_EE/policy/MotusWanVlmDirectMaskUnifiedEE/deploy_policy.py` | 添加 debug instrumentation |
| `RoboTwin_EE/policy/MotusWanVlmDirectMaskUnifiedEE/test_unified_eef_consistency.py` | 新增测试脚本 |
| `cache/RoboTwin/policy/MotusWanVlmDirectMaskUnifiedEE/` | 新增 (从 RoboTwin_EE 同步) |

**未修改的文件** (保持旧设定不变):
- `MotusWanVlmDirectMotion/` (旧 eepos policy)
- 训练侧代码 (`MotusV2/`)
- checkpoint / 数据集 / 日志

---

## 6. Debug / Test 使用方法

### 运行 sanity check 测试

```bash
cd /cache/wx1469573/RoboTwin
python policy/MotusWanVlmDirectMaskUnifiedEE/test_unified_eef_consistency.py --full
```

### 运行带 debug 的评测

```bash
cd /cache/wx1469573/RoboTwin
MOTUS_UNIFIED_EEF_DEBUG=1 bash policy/MotusWanVlmDirectMaskUnifiedEE/auto_eval_new.sh
```

debug 日志保存到 `logs_*/debug_unified_eef_trace.jsonl`，包含:
- 每个 step 的 eepos_state 和 unified_state
- 模型 raw output 的统计信息 (min/max/mean/std, NaN/Inf 检查)
- 转换后的 absolute eepos actions
- checkpoint 参数统计

---

## 7. 建议的下一步评测步骤

### Step 1: 单任务快速验证

先跑一个任务验证 policy 正确加载和 action 输出合理:

```bash
cd /cache/wx1469573/RoboTwin
MOTUS_UNIFIED_EEF_DEBUG=1 \
CUDA_VISIBLE_DEVICES=0 \
python -u script/eval_policy.py \
    --config policy/MotusWanVlmDirectMaskUnifiedEE/deploy_policy.yml \
    --overrides \
    --task_name beat_block_hammer \
    --task_config demo_randomized \
    --ckpt_setting /cache/wx1469573/pretrained_models/ckpt \
    --seed 42 \
    --policy_name MotusWanVlmDirectMaskUnifiedEE \
    --log_dir /tmp/debug_eval \
    --wan_path /cache/wx1469573/pretrained_models/Wan2.2-TI2V-5B \
    --vlm_path /cache/wx1469573/pretrained_models/Qwen3-VL-2B-Instruct \
    --vlm_type qwen3_vl
```

### Step 2: 检查 debug 日志

```bash
cat /tmp/debug_eval/debug_unified_eef_trace.jsonl | python3 -m json.tool
```

**关键检查项**:
- `checkpoint_load`: action_expert decoder 参数 std > 0 (非全零)
- `get_action`: `raw_has_nan=false`, `raw_has_inf=false`
- `get_action`: `raw_action_min` 和 `raw_action_max` 在合理范围 (delta 值应较小: -0.5 ~ 0.5)
- `get_action`: `raw_reserved_dims` 接近 0
- `converted_action`: `converted_left_xyz` 和 `converted_right_xyz` 在合理的工作空间范围内

### Step 3: 全量评测

确认单任务正常后，运行完整评测:

```bash
bash policy/MotusWanVlmDirectMaskUnifiedEE/auto_eval_new.sh
```

### Step 4: 如果成功率仍低

如果 action 输出合理但成功率仍低，最可能的原因是**训练不足** (仅 2783/50000 步)。建议:
1. 继续训练 unified_eef 模型至 50000 步
2. 将训练后的 best checkpoint 合并为 `mp_rank_00_model_states.pt` 格式
3. 复制到 `/cache/wx1469573/pretrained_models/ckpt/`
4. 重新评测

---

## 8. 仍需确认的事项

1. **Checkpoint 是否为 unified_eef 训练权重**: 需通过 debug 日志中 raw action 的数值范围确认。如果 raw action 值较大 (xyz ~0.3-0.9)，说明 checkpoint 仍是 eepos 权重，需要替换为 unified_eef 训练后的权重。

2. **训练是否需要继续**: 当前仅训练到 step 2783/50000，建议继续训练。

3. **best_action_l2 checkpoint 合并**: 训练输出是 DeepSpeed ZeRO 分片格式 (`pytorch_model_0.bin` + `bf16_zero_pp_rank_*_optim_states.pt`)，需要用 `zero_to_fp32.py` 合并为 `mp_rank_00_model_states.pt` 格式才能被推理加载。需确认此合并步骤是否已正确执行。

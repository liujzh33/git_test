# MotusWanVlmDirect Policy for RoboTwin Evaluation
# Supports two action representations:
#   - eepos: 16-dim absolute end-effector poses [xyz(3), quat_wxyz(4), gripper(1)] x2
#   - unified_eef_camera_delta_wrist16: 16-dim camera-frame delta EEF + gripper
#     [delta_xyz_cam(3), delta_rotvec_cam(3), gripper(1), 0] x2
# The unified EEF mode converts between absolute eepos (used by the simulator)
# and camera-frame delta (used by the model) at inference time, ensuring
# train/inference consistency.

import torch
import torch.nn as nn
import numpy as np
import cv2
from pathlib import Path
import sys
import os
import logging
logging.basicConfig(level=logging.INFO, format='%(name)s - %(levelname)s - %(message)s')
from typing import List, Dict, Any, Optional, Tuple
from collections import deque
import yaml
from PIL import Image
from transformers import AutoProcessor
from scipy.spatial.transform import Rotation as _Rotation
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend

# Add model paths
sys.path.append(str(Path(__file__).parent))
sys.path.append(str(Path(__file__).parent / "models"))

from models.motus_wan_vlm_direct_mask import MotusWanVlmDirectMask, MotusWanVlmDirectMaskConfig

# Add bak path for T5EncoderModel
BAK_ROOT = str((Path(__file__).parent / "bak").resolve())
if BAK_ROOT not in sys.path:
    sys.path.insert(0, BAK_ROOT)

from wan.modules.t5 import T5EncoderModel
from utils.image_utils import resize_with_padding
from qwen_vl_utils import process_vision_info

logger = logging.getLogger(__name__)


class MotusWanVlmDirectMaskPolicy:
    """
    MotusWanVlmDirectMask Policy wrapper for RoboTwin evaluation.
    Uses WAN 5B + Action Expert + VLM Direct MoT architecture with asymmetric attention mask.

    Action modes:
        - "eepos": 16-dim absolute EEF poses, action_type='ee'.
        - "unified_eef_camera_delta_wrist16": 16-dim camera-frame delta EEF + gripper.
          Converts between absolute eepos (simulator) and camera-frame delta (model)
          so that train/inference action representations match exactly.
    """

    # Fixed head camera extrinsics (OpenCV convention: x=right, y=down, z=forward).
    # Verified against HDF5 observation/head_camera/extrinsic_cv (diff=0.0 across
    # all episodes and frames, since random_head_camera_dis=0).
    # R_w_c maps camera-frame vectors to world frame.
    _HEAD_CAMERA_R_W_C = np.array([
        [ 1.0,  0.0,  0.0],
        [ 0.0, -0.8,  0.6],
        [ 0.0, -0.6, -0.8],
    ], dtype=np.float64)
    _HEAD_CAMERA_T_W_C = np.array([-0.032, -0.45, 1.35], dtype=np.float64)

    # Scene prefix prepended to every instruction. This MUST match the training
    # data: RobotWin metas/*.txt lines already embed this prefix verbatim
    # ("The whole scene is in a realistic, industrial art style ... The aloha
    # robot is currently performing the following task: {task}"), and the VLM
    # (preprocess_vlm_messages) + T5 (umt5 pre-encoded embeddings) both consume
    # the full prefixed text during training. At inference the raw instruction
    # from generate_episode_instructions is the bare task only, so the prefix
    # must be re-added here for BOTH the T5 and VLM inputs to stay consistent.
    _SCENE_PREFIX = (
        "The whole scene is in a realistic, industrial art style with three views: "
        "a fixed rear camera, a movable left arm camera, and a movable right arm camera. "
        "The aloha robot is currently performing the following task: "
    )

    def __init__(self, checkpoint_path: str, config_path: str, wan_path: str, vlm_path: str,
                 device: str = "cuda", log_dir: Optional[str] = None, task_name: Optional[str] = None,
                 vlm_prompt_mode: str = "motion_token",
                 action_mode: str = "eepos"):
        """
        Args:
            vlm_prompt_mode: VLM prompt format for inference.
                "motion_token" — motion-token prompt format (default, backward-compatible):
                    "Task: {instruction}\nPredict the 3D wrist motion trajectories..."
                    Use this when the model was trained with motion-token VLM inputs
                    (e.g. motion_token_prediction.enabled=True in training config).
                "simple" — simple instruction prompt (matches normal eepos training):
                    "{instruction}"
                    Use this when the model was trained without motion tokens
                    (e.g. robotwin_eepos_WanVlmMask.yaml or motion_token_off.yaml).
            action_mode: Action representation used by the model.
                "eepos" — 16-dim absolute EEF poses (backward-compatible default).
                "unified_eef_camera_delta_wrist16" — 16-dim camera-frame delta EEF
                + gripper.  State and action are converted to/from absolute eepos
                at the boundary so the simulator's take_action(action_type='ee')
                still receives absolute poses.
        """
        self.device = device
        self.checkpoint_path = checkpoint_path
        self.wan_path = wan_path
        self.vlm_path = vlm_path
        self.vlm_prompt_mode = vlm_prompt_mode
        self.action_mode = action_mode

        # Debug instrumentation (env var MOTUS_UNIFIED_EEF_DEBUG=1)
        self.debug = os.environ.get("MOTUS_UNIFIED_EEF_DEBUG", "0") == "1"
        self.debug_step = 0
        self.debug_log_path = None
        if self.debug:
            base = log_dir or os.environ.get('LOG_DIR') or str(Path(__file__).resolve().parent)
            self.debug_log_path = Path(base) / "debug_unified_eef_trace.jsonl"
            self.debug_log_path.parent.mkdir(parents=True, exist_ok=True)
            logger.info(f"DEBUG: debug trace will be saved to {self.debug_log_path}")

        # Validate action_mode
        if self.action_mode not in ("eepos", "unified_eef_camera_delta_wrist16"):
            raise ValueError(
                f"Unknown action_mode: {self.action_mode!r}. "
                f"Expected 'eepos' or 'unified_eef_camera_delta_wrist16'."
            )
        logger.info(f"Action mode: {self.action_mode}")
        logger.info(f"VLM prompt mode: {self.vlm_prompt_mode}")

        # Load configuration
        with open(config_path, 'r') as f:
            self.config_dict = yaml.safe_load(f)

        # Initialize model WITHOUT loading pretrained backbones
        self.model = self._load_model()

        # Initialize T5 encoder for language embeddings (WAN text encoder)
        self.t5_encoder = T5EncoderModel(
            text_len=512,
            dtype=torch.bfloat16,
            device=device,
            checkpoint_path=os.path.join(self.wan_path, 'models_t5_umt5-xxl-enc-bf16.pth'),
            tokenizer_path=os.path.join(self.wan_path, 'google', 'umt5-xxl'),
        )

        # Initialize VLM processor from vlm_path (extended vocab for motion tokens)
        self.vlm_processor = AutoProcessor.from_pretrained(self.vlm_path, trust_remote_code=True)

        # Initialize observation cache
        self.obs_cache = deque(maxlen=1)
        self.action_cache = deque()

        # Model state
        self.current_state = None
        self.current_eepos_state = None  # cached absolute eepos anchor (16,)
        self.is_first_step = True
        self.prev_action = None

        # Initialize image saving
        self.save_images = True
        base_log_dir = log_dir or os.environ.get('LOG_DIR') or str(Path(__file__).resolve().parent.parent / "logs")
        task_dir_name = task_name or os.environ.get('TASK_NAME') or "default_task"
        self.save_dir = Path(base_log_dir) / "images" / task_dir_name
        self.save_dir.mkdir(parents=True, exist_ok=True)
        self.episode_count = 0
        self.step_count = 0

        logger.info(f"VLM prompt mode: {self.vlm_prompt_mode}")
        logger.info("MotusWanVlmDirectMaskMotion Policy initialized successfully")

    def set_instruction(self, instruction: str):
        """Set the current instruction for the policy."""
        self.current_instruction = instruction
        logger.info(f"Instruction set: {instruction}")

    def _load_model(self) -> MotusWanVlmDirectMask:
        """Load the MotusWanVlmDirectMask model from checkpoint."""
        logger.info(f"Initializing MotusWanVlmDirectMask model from config")

        config = self._create_model_config()

        # Initialize model from config without pretrained weights
        model = MotusWanVlmDirectMask(config)
        model = model.to(self.device)

        # Load checkpoint weights via model's load_checkpoint method
        try:
            logger.info(f"Loading checkpoint from {self.checkpoint_path}")
            model.load_checkpoint(self.checkpoint_path, strict=False)
            logger.info("Model checkpoint loaded successfully")
        except Exception as e:
            logger.error(f"Failed to load checkpoint: {e}")
            raise

        # Debug: verify checkpoint loaded correctly by checking a few key parameter stats
        if self.debug:
            import json
            dbg_ckpt = {"event": "checkpoint_load", "checkpoint_path": self.checkpoint_path}
            # Check a few action expert parameters to verify weights are loaded
            for name, param in model.named_parameters():
                if "action_expert" in name and "decoder" in name:
                    dbg_ckpt["action_expert_decoder_param"] = {
                        "name": name,
                        "shape": list(param.shape),
                        "mean": float(param.data.float().mean()),
                        "std": float(param.data.float().std()),
                        "has_nan": bool(torch.isnan(param.data).any()),
                        "all_zero": bool((param.data.abs() < 1e-10).all()),
                    }
                    break
            with open(self.debug_log_path, "a") as f:
                f.write(json.dumps(dbg_ckpt) + "\n")
            logger.info(f"DEBUG checkpoint: {dbg_ckpt}")

        model.eval()
        return model

    def _create_model_config(self) -> MotusWanVlmDirectMaskConfig:
        """Create model configuration from yaml config - inference mode."""
        common = self.config_dict['common']
        model_cfg = self.config_dict['model']

        # Use paths passed to constructor
        vae_path = os.path.join(self.wan_path, "Wan2.2_VAE.pth")

        hidden_size = model_cfg['action_expert']['hidden_size']
        ffn_multiplier = model_cfg['action_expert']['ffn_dim_multiplier']

        config = MotusWanVlmDirectMaskConfig(
            # Paths for config loading only (no weights loaded)
            wan_checkpoint_path=self.wan_path,
            vae_path=vae_path,
            wan_config_path=self.wan_path,
            video_precision='bfloat16',
            vlm_checkpoint_path=self.vlm_path,

            # Qwen3-VL Expert settings (per-layer QKV projections)
            vlm_dim=model_cfg['qwen3_expert']['vlm_dim'],
            qwen3_expert_head_dim=model_cfg['qwen3_expert']['head_dim'],
            qwen3_expert_num_heads=model_cfg['qwen3_expert']['num_heads'],
            qwen3_expert_num_layers=model_cfg['qwen3_expert']['num_layers'],
            qwen3_expert_norm_eps=model_cfg['qwen3_expert']['norm_eps'],

            # Model architecture
            num_layers=model_cfg.get('num_layers', 30),  # WAN has 30 layers
            action_state_dim=common['state_dim'],
            action_dim=common['action_dim'],
            action_expert_dim=hidden_size,
            action_expert_ffn_dim_multiplier=ffn_multiplier,
            action_expert_norm_eps=model_cfg['action_expert']['norm_eps'],

            # Training config
            global_downsample_rate=common['global_downsample_rate'],
            video_action_freq_ratio=common['video_action_freq_ratio'],
            num_video_frames=common['num_video_frames'],
            video_loss_weight=1.0,
            action_loss_weight=1.0,

            # Inference config
            batch_size=1,
            video_height=common['video_height'],
            video_width=common['video_width'],
            training_mode='finetune',

            # Don't load pretrained backbones - will load full model from checkpoint
            load_pretrained_backbones=False,
            vlm_frozen=False,
        )

        return config

    # ------------------------------------------------------------------
    # Unified EEF camera-delta conversion helpers
    # ------------------------------------------------------------------
    # These mirror the training-side transforms in
    # MotusV2/data/human/unified_eef_action.py and
    # MotusV2/data/robotwin2/robotwin_agilex_dataset.py, ensuring the
    # inference policy consumes/produces the exact same representation.
    #
    # Forward (state):  absolute eepos  -> camera-frame EEF state (16D)
    # Inverse (action): camera-frame delta action (16D) -> absolute eepos (16D)
    #
    # Camera extrinsics are hardcoded (fixed head camera, verified identical
    # across all episodes/frames in HDF5 extrinsic_cv).

    @staticmethod
    def _quat_wxyz_to_rotmat(quat_wxyz: np.ndarray) -> np.ndarray:
        """Convert WXYZ quaternion (scalar first) to 3x3 rotation matrix.

        Preserves the input's leading batch shape: a (4,) input returns (3, 3).
        """
        quat_wxyz = np.asarray(quat_wxyz, dtype=np.float64)
        # Canonicalize w >= 0
        w = quat_wxyz[..., 0:1]
        quat_wxyz = np.where(w < 0, -quat_wxyz, quat_wxyz)
        # WXYZ -> XYZW for scipy
        quat_xyzw = np.roll(quat_wxyz, -1, axis=-1)
        return _Rotation.from_quat(quat_xyzw.reshape(-1, 4)).as_matrix().reshape(
            quat_wxyz.shape[:-1] + (3, 3)
        )

    @staticmethod
    def _rotmat_to_quat_wxyz(rotmat: np.ndarray) -> np.ndarray:
        """Convert 3x3 rotation matrix to WXYZ quaternion (scalar first).

        Preserves the input's leading batch shape: a (3, 3) input returns (4,).
        """
        rotmat = np.asarray(rotmat, dtype=np.float64)
        q_xyzw = _Rotation.from_matrix(rotmat.reshape(-1, 3, 3)).as_quat().reshape(
            rotmat.shape[:-2] + (4,)
        )
        # XYZW -> WXYZ
        q_wxyz = np.roll(q_xyzw, 1, axis=-1)
        # Canonicalize w >= 0
        q_wxyz = np.where(q_wxyz[..., 0:1] < 0, -q_wxyz, q_wxyz)
        return q_wxyz

    @staticmethod
    def _log_so3(rotmat: np.ndarray) -> np.ndarray:
        """SO(3) log map: rotation matrix -> rotation vector."""
        r = np.asarray(rotmat, dtype=np.float64).reshape(-1, 3, 3)
        return _Rotation.from_matrix(r).as_rotvec().reshape(rotmat.shape[:-2] + (3,))

    @staticmethod
    def _exp_so3(rotvec: np.ndarray) -> np.ndarray:
        """SO(3) exp map: rotation vector -> rotation matrix."""
        v = np.asarray(rotvec, dtype=np.float64).reshape(-1, 3)
        return _Rotation.from_rotvec(v).as_matrix().reshape(rotvec.shape[:-1] + (3, 3))

    def _build_unified_eef_state(self, eepos_state: np.ndarray) -> np.ndarray:
        """Convert absolute eepos state to unified EEF camera-frame state (16D).

        Mirrors compute_unified_eef_state_16d_with_gripper() in training.

        eepos_state: [left_xyz(3), left_quat_wxyz(4), left_grip(1),
                      right_xyz(3), right_quat_wxyz(4), right_grip(1)]

        Returns:
            state_16d: [left_xyz_cam(3), left_rotvec_cam(3), left_grip(1), 0,
                        right_xyz_cam(3), right_rotvec_cam(3), right_grip(1), 0]
        """
        R_w_c = self._HEAD_CAMERA_R_W_C
        t_w_c = self._HEAD_CAMERA_T_W_C
        R_c_w = R_w_c.T  # world -> camera

        left_xyz = eepos_state[0:3]
        left_quat = eepos_state[3:7]
        left_grip = float(eepos_state[7])
        right_xyz = eepos_state[8:11]
        right_quat = eepos_state[11:15]
        right_grip = float(eepos_state[15])

        state_16d = np.zeros(16, dtype=np.float64)

        # Left arm
        R_w_e_left = self._quat_wxyz_to_rotmat(left_quat)  # (3, 3)
        t_cam_left = R_c_w @ (left_xyz - t_w_c)
        R_cam_left = R_c_w @ R_w_e_left
        rotvec_cam_left = self._log_so3(R_cam_left)
        state_16d[0:3] = t_cam_left
        state_16d[3:6] = rotvec_cam_left
        state_16d[6] = left_grip
        # dim 7 reserved = 0

        # Right arm
        R_w_e_right = self._quat_wxyz_to_rotmat(right_quat)
        t_cam_right = R_c_w @ (right_xyz - t_w_c)
        R_cam_right = R_c_w @ R_w_e_right
        rotvec_cam_right = self._log_so3(R_cam_right)
        state_16d[8:11] = t_cam_right
        state_16d[11:14] = rotvec_cam_right
        state_16d[14] = right_grip
        # dim 15 reserved = 0

        return state_16d

    def _unified_delta_to_eepos_actions(
        self, unified_actions: np.ndarray, eepos_anchor: np.ndarray
    ) -> np.ndarray:
        """Convert predicted unified delta actions back to absolute eepos actions.

        Mirrors the inverse of compute_unified_eef_action_16d_with_gripper()
        in training.  Each action is an anchor-based delta from the current
        EEF pose (captured in update_obs) to the target pose.

        Args:
            unified_actions: (T, 16) predicted unified delta actions.
                Layout per arm: [delta_xyz_cam(3), delta_rotvec_cam(3), gripper(1), 0]
            eepos_anchor: (16,) current absolute eepos pose
                [left_xyz(3), left_quat(4), left_grip(1),
                 right_xyz(3), right_quat(4), right_grip(1)]

        Returns:
            eepos_actions: (T, 16) absolute eepos actions for take_action(action_type='ee').
                Layout: [left_xyz(3), left_quat_wxyz(4), left_grip(1),
                         right_xyz(3), right_quat_wxyz(4), right_grip(1)]
        """
        R_w_c = self._HEAD_CAMERA_R_W_C

        # Parse anchor pose
        left_xyz_0 = eepos_anchor[0:3]
        left_quat_0 = eepos_anchor[3:7]
        right_xyz_0 = eepos_anchor[8:11]
        right_quat_0 = eepos_anchor[11:15]

        R_w_e_left = self._quat_wxyz_to_rotmat(left_quat_0)   # (3, 3)
        R_w_e_right = self._quat_wxyz_to_rotmat(right_quat_0)

        # Camera-to-EEF rotation for anchor: R_c_e = R_w_c^T @ R_w_e
        R_c_e_left = R_w_c.T @ R_w_e_left
        R_c_e_right = R_w_c.T @ R_w_e_right

        T = unified_actions.shape[0]
        eepos_actions = np.zeros((T, 16), dtype=np.float64)

        for i in range(T):
            a = unified_actions[i]

            # --- Left arm ---
            t_delta_c_l = a[0:3]
            rotvec_delta_c_l = a[3:6]
            grip_l = float(a[6])
            R_delta_c_l = self._exp_so3(rotvec_delta_c_l)

            # Inverse of: R_delta_c = R_c_e @ R_e_e_star @ R_c_e^T
            #          => R_e_e_star = R_c_e^T @ R_delta_c @ R_c_e
            R_e_e_star_l = R_c_e_left.T @ R_delta_c_l @ R_c_e_left
            # Inverse of: t_delta_c = R_c_e @ t_e_e_star
            #          => t_e_e_star = R_c_e^T @ t_delta_c
            t_e_e_star_l = R_c_e_left.T @ t_delta_c_l

            R_w_e_star_l = R_w_e_left @ R_e_e_star_l
            t_w_e_star_l = left_xyz_0 + R_w_e_left @ t_e_e_star_l
            quat_l = self._rotmat_to_quat_wxyz(R_w_e_star_l)

            eepos_actions[i, 0:3] = t_w_e_star_l
            eepos_actions[i, 3:7] = quat_l
            eepos_actions[i, 7] = grip_l

            # --- Right arm ---
            t_delta_c_r = a[8:11]
            rotvec_delta_c_r = a[11:14]
            grip_r = float(a[14])
            R_delta_c_r = self._exp_so3(rotvec_delta_c_r)

            R_e_e_star_r = R_c_e_right.T @ R_delta_c_r @ R_c_e_right
            t_e_e_star_r = R_c_e_right.T @ t_delta_c_r

            R_w_e_star_r = R_w_e_right @ R_e_e_star_r
            t_w_e_star_r = right_xyz_0 + R_w_e_right @ t_e_e_star_r
            quat_r = self._rotmat_to_quat_wxyz(R_w_e_star_r)

            eepos_actions[i, 8:11] = t_w_e_star_r
            eepos_actions[i, 11:15] = quat_r
            eepos_actions[i, 15] = grip_r

        return eepos_actions.astype(np.float32)

    def update_obs(self, observation: Dict[str, Any]):
        """Update observation cache with new observation.

        Builds the policy state from environment:
            - eepos mode: 16-dim absolute EEF state
              [left_ee(7), left_grip(1), right_ee(7), right_grip(1)]
            - unified_eef_camera_delta_wrist16 mode: 16-dim camera-frame EEF state
              [left_xyz_cam(3), left_rotvec_cam(3), left_grip(1), 0,
               right_xyz_cam(3), right_rotvec_cam(3), right_grip(1), 0]

        In both modes the current absolute EEF pose (xyz + quat_wxyz + gripper)
        is cached as ``self.current_eepos_state`` so that predicted unified delta
        actions can be converted back to absolute eepos for the simulator.
        """
        # Extract visual observations
        if 'observation' in observation:
            obs_data = observation['observation']
            if 'head_camera' in obs_data and 'left_camera' in obs_data and 'right_camera' in obs_data:
                head_img = obs_data['head_camera']['rgb']
                left_img = obs_data['left_camera']['rgb']
                right_img = obs_data['right_camera']['rgb']

                left_img_resized = cv2.resize(left_img, (160, 120))
                right_img_resized = cv2.resize(right_img, (160, 120))
                bottom_row = np.concatenate([left_img_resized, right_img_resized], axis=1)
                image = np.concatenate([head_img, bottom_row], axis=0)
            else:
                raise ValueError("Missing camera data")
        elif 'head_camera' in observation:
            image = observation['head_camera']
        elif 'image' in observation:
            image = observation['image']
        else:
            raise ValueError("No visual observation found")

        target_size = (self.config_dict['common']['video_height'],
                      self.config_dict['common']['video_width'])

        if isinstance(image, np.ndarray):
            image_tensor = torch.from_numpy(image).permute(2, 0, 1).unsqueeze(0)
        else:
            image_tensor = image

        if image_tensor.shape[-2:] != target_size:
            image_np = image_tensor.squeeze(0).permute(1, 2, 0).cpu().numpy()
            resized_np = resize_with_padding(image_np, target_size)
            if resized_np.dtype == np.uint8:
                resized_np = resized_np.astype(np.float32) / 255.0
            image_tensor = torch.from_numpy(resized_np).permute(2, 0, 1).unsqueeze(0)

        self.obs_cache.append(image_tensor.to(self.device))

        # Read current absolute EEF pose from the robot (xyz + quat_wxyz, 7-dim each)
        left_ee = np.array(self._task_env.robot.get_left_ee_pose(), dtype=np.float32)   # [7]
        right_ee = np.array(self._task_env.robot.get_right_ee_pose(), dtype=np.float32)  # [7]
        left_grip = np.array([observation['joint_action']['left_gripper']], dtype=np.float32)
        right_grip = np.array([observation['joint_action']['right_gripper']], dtype=np.float32)

        # Cache 16-dim absolute eepos: [left_xyz(3), left_quat(4), left_grip(1),
        #                               right_xyz(3), right_quat(4), right_grip(1)]
        eepos_state = np.concatenate([left_ee, left_grip, right_ee, right_grip])  # [16]
        # Store as float64 for accurate rotation math in unified_eef mode
        self.current_eepos_state = eepos_state.astype(np.float64)

        if self.action_mode == "unified_eef_camera_delta_wrist16":
            state_16d = self._build_unified_eef_state(self.current_eepos_state)
            state_tensor = torch.from_numpy(state_16d.astype(np.float32)).unsqueeze(0)  # [1, 16]
        else:
            # eepos mode: state is the absolute eepos directly
            state_tensor = torch.from_numpy(eepos_state).float().unsqueeze(0)  # [1, 16]

        self.current_state = state_tensor.to(self.device)

        # Debug: log state info
        if self.debug and self.debug_step < 10:
            import json
            dbg = {
                "step": self.debug_step,
                "event": "update_obs",
                "action_mode": self.action_mode,
                "eepos_state": self.current_eepos_state.tolist(),
                "left_xyz": self.current_eepos_state[0:3].tolist(),
                "left_quat_wxyz": self.current_eepos_state[3:7].tolist(),
                "left_grip": float(self.current_eepos_state[7]),
                "right_xyz": self.current_eepos_state[8:11].tolist(),
                "right_quat_wxyz": self.current_eepos_state[11:15].tolist(),
                "right_grip": float(self.current_eepos_state[15]),
            }
            if self.action_mode == "unified_eef_camera_delta_wrist16":
                dbg["unified_state_16d"] = state_16d.tolist()
                dbg["left_xyz_cam"] = state_16d[0:3].tolist()
                dbg["left_rotvec_cam"] = state_16d[3:6].tolist()
                dbg["right_xyz_cam"] = state_16d[8:11].tolist()
                dbg["right_rotvec_cam"] = state_16d[11:14].tolist()
            with open(self.debug_log_path, "a") as f:
                f.write(json.dumps(dbg) + "\n")
            logger.info(f"DEBUG step={self.debug_step} update_obs: eepos_left_xyz={dbg['left_xyz']}, "
                        f"unified_left_xyz_cam={dbg.get('left_xyz_cam', 'N/A')}")

    def get_action(self, instruction: str = None) -> List[np.ndarray]:
        """Get action predictions from the model."""
        if len(self.obs_cache) == 0:
            raise ValueError("No observations in cache. Call update_obs first.")

        if self.current_state is None:
            raise ValueError("No robot state available. Call update_obs first.")

        current_frame = self.obs_cache[-1]

        # Encode instruction with T5. The scene prefix is prepended to match
        # the training-time text: RobotWin metas/*.txt lines already embed this
        # prefix, and the umt5_wan/*.pt embeddings were encoded from that full
        # prefixed text. The raw instruction at inference is the bare task only.
        t5_instruction = f"{self._SCENE_PREFIX}{self.current_instruction}"
        t5_out = self.t5_encoder([t5_instruction], self.device)
        if isinstance(t5_out, torch.Tensor):
            t5_list = [t5_out.squeeze(0)] if t5_out.dim() == 3 else [t5_out]
        elif isinstance(t5_out, list):
            t5_list = t5_out
        else:
            raise ValueError("Unexpected T5 encoder output format")

        # Build VLM inputs — dispatch by prompt mode.
        # NOTE: the prefixed instruction is passed so the VLM receives the SAME
        # text it saw during training (RobotWin metas lines embed the scene
        # prefix). See _SCENE_PREFIX docstring.
        prefixed_instruction = f"{self._SCENE_PREFIX}{self.current_instruction}"
        first_frame_pil = self._tensor_to_pil_image(current_frame.squeeze(0).cpu())
        if self.vlm_prompt_mode == "motion_token":
            vlm_inputs = self._preprocess_vlm_messages_motion_prompt_only(
                prefixed_instruction, first_frame_pil
            )
        elif self.vlm_prompt_mode == "simple":
            vlm_inputs = self._preprocess_vlm_messages_simple(
                prefixed_instruction, first_frame_pil
            )
        else:
            raise ValueError(
                f"Unknown vlm_prompt_mode: {self.vlm_prompt_mode!r}. "
                f"Expected 'motion_token' or 'simple'."
            )

        # Build per-dim action validity mask for unified_eef mode.
        # Layout: [dxyz(3), drotvec(3), grip(1), 0, dxyz(3), drotvec(3), grip(1), 0]
        # Dims 7 and 15 are reserved padding (always zero in training, masked out
        # of the loss). Training zeroes these dims on both noisy_actions and
        # action_target, so the action_expert.input_encoder never sees signal on
        # them. Mirror that at inference: zero them on action_latent at init and
        # after each Euler step, otherwise they carry randn noise that perturbs
        # the shared encoder. The downstream _unified_delta_to_eepos_actions
        # ignores dims 7/15, but feeding them as zero keeps the input
        # distribution consistent with training.
        action_valid_mask = None
        if self.action_mode == "unified_eef_camera_delta_wrist16":
            action_dim = self.config_dict['common']['action_dim']  # 16
            chunk_size = self.config_dict['common']['num_video_frames'] * \
                self.config_dict['common']['video_action_freq_ratio']  # 8 * 2 = 16
            mask_1d = torch.ones(action_dim, dtype=torch.float32)
            mask_1d[7] = 0.0
            mask_1d[15] = 0.0
            action_valid_mask = mask_1d.view(1, 1, action_dim).expand(
                1, chunk_size, action_dim
            ).to(self.device)

        # Run inference
        num_inference_steps = self.config_dict['model']['inference']['num_inference_timesteps']
        with torch.no_grad():
            predicted_frames, predicted_actions = self.model.inference_step(
                first_frame=current_frame,
                state=self.current_state,
                num_inference_steps=num_inference_steps,
                language_embeddings=t5_list,
                vlm_inputs=vlm_inputs,
                action_valid_mask=action_valid_mask,
            )

        # Save frame grid
        if predicted_frames is not None:
            if predicted_frames.dim() == 5:
                if predicted_frames.shape[1] == 3:
                    predicted_frames_viz = predicted_frames.permute(0, 2, 1, 3, 4)
                else:
                    predicted_frames_viz = predicted_frames

                condition_frame_viz = current_frame.squeeze(0)
                predicted_frames_viz = predicted_frames_viz.squeeze(0)

                self._save_frame_grid(condition_frame_viz, predicted_frames_viz)
                self.step_count += 1

        actions_real = predicted_actions.squeeze(0).cpu().numpy()  # (T, 16)

        # Debug: log raw model output and converted actions
        if self.debug and self.debug_step < 10:
            import json
            raw = predicted_actions.squeeze(0).cpu().numpy()
            dbg = {
                "step": self.debug_step,
                "event": "get_action",
                "raw_action_shape": list(raw.shape),
                "raw_action_first": raw[0].tolist() if raw.ndim == 2 else raw.tolist(),
                "raw_action_min": raw.min(axis=0).tolist() if raw.ndim == 2 else [],
                "raw_action_max": raw.max(axis=0).tolist() if raw.ndim == 2 else [],
                "raw_action_mean": raw.mean(axis=0).tolist() if raw.ndim == 2 else [],
                "raw_action_std": raw.std(axis=0).tolist() if raw.ndim == 2 else [],
                "raw_has_nan": bool(np.any(np.isnan(raw))),
                "raw_has_inf": bool(np.any(np.isinf(raw))),
                "raw_left_delta_xyz_norm": float(np.linalg.norm(raw[0, 0:3])) if raw.ndim == 2 else 0,
                "raw_left_delta_rotvec_norm": float(np.linalg.norm(raw[0, 3:6])) if raw.ndim == 2 else 0,
                "raw_right_delta_xyz_norm": float(np.linalg.norm(raw[0, 8:11])) if raw.ndim == 2 else 0,
                "raw_right_delta_rotvec_norm": float(np.linalg.norm(raw[0, 11:14])) if raw.ndim == 2 else 0,
                "raw_reserved_dims": raw[0, [7, 15]].tolist() if raw.ndim == 2 else [],
                "vlm_prompt_mode": self.vlm_prompt_mode,
                "action_mode": self.action_mode,
            }
            with open(self.debug_log_path, "a") as f:
                f.write(json.dumps(dbg) + "\n")
            logger.info(f"DEBUG step={self.debug_step} get_action: raw_shape={dbg['raw_action_shape']}, "
                        f"raw_min={raw.min():.4f}, raw_max={raw.max():.4f}, "
                        f"left_dxyz_norm={dbg['raw_left_delta_xyz_norm']:.4f}, "
                        f"reserved={dbg['raw_reserved_dims']}")

        # In unified_eef mode, the model predicts camera-frame delta actions.
        # Convert each predicted delta back to absolute eepos so the simulator's
        # take_action(action_type='ee') receives absolute poses.
        if self.action_mode == "unified_eef_camera_delta_wrist16":
            actions_real = self._unified_delta_to_eepos_actions(
                actions_real, self.current_eepos_state
            )

        # Debug: log converted eepos actions
        if self.debug and self.debug_step < 10:
            import json
            dbg2 = {
                "step": self.debug_step,
                "event": "converted_action",
                "converted_action_shape": list(actions_real.shape),
                "converted_first": actions_real[0].tolist() if actions_real.ndim == 2 else actions_real.tolist(),
                "converted_left_xyz": actions_real[0, 0:3].tolist() if actions_real.ndim == 2 else [],
                "converted_right_xyz": actions_real[0, 8:11].tolist() if actions_real.ndim == 2 else [],
                "converted_left_grip": float(actions_real[0, 7]) if actions_real.ndim == 2 else 0,
                "converted_right_grip": float(actions_real[0, 15]) if actions_real.ndim == 2 else 0,
                "anchor_eepos_left_xyz": self.current_eepos_state[0:3].tolist(),
                "anchor_eepos_right_xyz": self.current_eepos_state[8:11].tolist(),
            }
            with open(self.debug_log_path, "a") as f:
                f.write(json.dumps(dbg2) + "\n")
            logger.info(f"DEBUG step={self.debug_step} converted: "
                        f"left_xyz={dbg2['converted_left_xyz']}, "
                        f"right_xyz={dbg2['converted_right_xyz']}")

        self.debug_step += 1

        self.prev_action = actions_real[-1].copy()
        self.action_cache.extend(actions_real)

        return actions_real

    def _tensor_to_pil_image(self, tensor_chw: torch.Tensor) -> Image.Image:
        """Convert [C, H, W] tensor to PIL Image."""
        if tensor_chw.dtype != torch.float32:
            tensor_chw = tensor_chw.float()
        tensor_chw = tensor_chw.clamp(0, 1)
        np_img = (tensor_chw.permute(1, 2, 0).numpy() * 255.0).astype(np.uint8)
        return Image.fromarray(np_img, mode='RGB')

    def _preprocess_vlm_messages_motion_prompt_only(
        self, text_instruction: str, image_pil: Image.Image
    ) -> Dict[str, torch.Tensor]:
        """Build VLM inputs using motion-token prompt format (prompt-only, no GT response).

        Matches training-time preprocess_vlm_messages_motion_prompt_only():
        same user prompt content, add_generation_prompt=True, no assistant tokens.
        """
        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "image", "image": image_pil},
                    {
                        "type": "text",
                        "text": (
                            f"Task: {text_instruction}\n"
                            "Predict the 3D wrist motion trajectories for both hands "
                            "in the robot base coordinate system. Return only motion tokens."
                        ),
                    },
                ],
            }
        ]

        text = self.vlm_processor.apply_chat_template(
            messages, add_generation_prompt=True, tokenize=False
        )

        image_inputs, video_inputs = process_vision_info(messages)
        encoded = self.vlm_processor(
            text=[text],
            images=image_inputs,
            videos=video_inputs,
            padding=True,
            return_tensors="pt",
        )

        vlm_inputs = {
            'input_ids': encoded['input_ids'].to(self.device),
            'attention_mask': encoded['attention_mask'].to(self.device),
            'pixel_values': encoded['pixel_values'].to(self.device),
        }
        if 'image_grid_thw' in encoded and encoded['image_grid_thw'] is not None:
            vlm_inputs['image_grid_thw'] = encoded['image_grid_thw'].to(self.device)

        return vlm_inputs

    def _preprocess_vlm_messages_simple(
        self, text_instruction: str, image_pil: Image.Image
    ) -> Dict[str, torch.Tensor]:
        """Build VLM inputs using simple instruction prompt (matches normal eepos training).

        This is the prompt format used by preprocess_vlm_messages() during training
        when motion_token_prediction is disabled. The VLM receives only the raw
        instruction text with the image — no motion-token-specific framing.

        Matches training-time:
            utils/vlm_utils.preprocess_vlm_messages(instruction, image, processor)
        """
        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "image", "image": image_pil},
                    {"type": "text", "text": text_instruction},
                ],
            }
        ]

        text = self.vlm_processor.apply_chat_template(
            messages, add_generation_prompt=True, tokenize=False
        )

        image_inputs, video_inputs = process_vision_info(messages)
        encoded = self.vlm_processor(
            text=[text],
            images=image_inputs,
            videos=video_inputs,
            padding=True,
            return_tensors="pt",
        )

        vlm_inputs = {
            'input_ids': encoded['input_ids'].to(self.device),
            'attention_mask': encoded['attention_mask'].to(self.device),
            'pixel_values': encoded['pixel_values'].to(self.device),
        }
        if 'image_grid_thw' in encoded and encoded['image_grid_thw'] is not None:
            vlm_inputs['image_grid_thw'] = encoded['image_grid_thw'].to(self.device)

        return vlm_inputs

    def _create_frame_grid(self, condition_frame: torch.Tensor, predicted_frames: torch.Tensor) -> Image.Image:
        """Create horizontal grid."""
        def tensor_to_numpy(tensor):
            if tensor.dim() == 3:
                tensor = tensor.permute(1, 2, 0)
            tensor = tensor.detach().cpu().float()
            tensor = torch.clamp(tensor, 0, 1)
            return (tensor.numpy() * 255).astype(np.uint8)

        condition_np = tensor_to_numpy(condition_frame)
        predicted_np = []
        num_pred_frames = predicted_frames.shape[0]
        for i in range(num_pred_frames):
            frame_np = tensor_to_numpy(predicted_frames[i])
            predicted_np.append(frame_np)

        while len(predicted_np) < 4:
            predicted_np.append(predicted_np[-1] if predicted_np else condition_np)

        all_frames = [condition_np] + predicted_np[:4]
        grid_image = np.concatenate(all_frames, axis=1)

        return Image.fromarray(grid_image)

    def _save_frame_grid(self, condition_frame: torch.Tensor, predicted_frames: torch.Tensor):
        """Save frame grid to disk."""
        if not self.save_images:
            return

        try:
            grid_image = self._create_frame_grid(condition_frame, predicted_frames)
            filename = f"episode_{self.episode_count:04d}_step_{self.step_count:04d}.png"
            save_path = self.save_dir / filename
            grid_image.save(save_path)
            logger.info(f"Saved frame grid to {save_path}")
        except Exception as e:
            logger.warning(f"Failed to save frame grid: {e}")


def encode_obs(observation):
    """Post-Process Observation"""
    return observation


def get_model(usr_args):
    """
    Initialize MotusWanVlmDirectMask model.

    Args:
        usr_args: Arguments from eval script (must include wan_path and vlm_path)
    """
    checkpoint_path = usr_args.get('ckpt_setting')
    wan_path = usr_args.get('wan_path')
    vlm_path = usr_args.get('vlm_path')

    if not wan_path:
        raise ValueError("wan_path not provided in usr_args")

    if not vlm_path:
        raise ValueError("vlm_path not provided in usr_args")

    policy_dir = Path(__file__).parent
    config_path = policy_dir / "utils" / "robotwin_wan_vlm.yml"

    # Load vlm_prompt_mode and action_mode from paths_config.yml
    paths_config_path = policy_dir / "paths_config.yml"
    vlm_prompt_mode = "motion_token"  # default: backward-compatible
    action_mode = "eepos"             # default: backward-compatible
    if paths_config_path.exists():
        with open(paths_config_path, 'r', encoding='utf-8') as f:
            paths_config = yaml.safe_load(f)
        vlm_prompt_mode = paths_config.get('vlm_prompt_mode', 'motion_token')
        action_mode = paths_config.get('action_mode', 'eepos')
        logger.info(f"Loaded vlm_prompt_mode from config: {vlm_prompt_mode}")
        logger.info(f"Loaded action_mode from config: {action_mode}")

    device = "cuda" if torch.cuda.is_available() else "cpu"

    policy = MotusWanVlmDirectMaskPolicy(
        checkpoint_path=checkpoint_path,
        wan_path=wan_path,
        vlm_path=vlm_path,
        config_path=str(config_path),
        device=device,
        log_dir=usr_args.get('log_dir'),
        task_name=usr_args.get('task_name'),
        vlm_prompt_mode=vlm_prompt_mode,
        action_mode=action_mode,
    )

    return policy


def eval(TASK_ENV, model, observation):
    """Evaluation function.

    Uses action_type='ee' for 16-dim eepos actions.  In unified_eef mode the
    policy internally converts predicted camera-frame delta actions to absolute
    eepos poses before returning them, so the simulator interface is unchanged.
    """
    # Store TASK_ENV reference so update_obs can access robot for ee pose
    model._task_env = TASK_ENV

    obs = encode_obs(observation)

    instruction = TASK_ENV.get_instruction()
    model.set_instruction(instruction)
    model.update_obs(obs)

    actions = model.get_action()

    for action in actions:
        TASK_ENV.take_action(action, action_type='ee')


def reset_model(model):
    """Reset model cache at episode start."""
    model.obs_cache.clear()
    model.action_cache.clear()
    model.current_state = None
    model.is_first_step = True
    model.prev_action = None
    # Clear cached absolute eepos anchor (used by unified_eef inverse transform)
    if hasattr(model, 'current_eepos_state'):
        model.current_eepos_state = None
    model.episode_count += 1
    model.step_count = 0
    logger.info(f"Model reset completed for episode {model.episode_count}")

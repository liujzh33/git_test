"""Local torchaudio stub for the MotusV2 vision-only inference path.

The RoboLab inference venv ships a torchaudio built against CUDA 12.6 while
torch is CUDA 12.8; importing the real torchaudio raises a CUDA-version
RuntimeError, which in turn breaks ``import transformers`` (its lazy
``loss_rnnt`` module does ``import torchaudio``). MotusV2 DROID inference never
uses any torchaudio op, so this no-op stub lets the import chain succeed. If a
torchaudio op is ever actually called, attribute access returns a dummy module
whose call raises loudly.
"""

from __future__ import annotations

import types

__version__ = "0.0.0+motus-stub"


class _Unavailable(types.ModuleType):
    def __getattr__(self, name):  # noqa: D401
        def _raise(*args, **kwargs):
            raise RuntimeError(
                "torchaudio is stubbed for MotusV2 inference; "
                f"real op '{self.__name__}.{name}' is unavailable."
            )

        return _raise


def __getattr__(name):
    # Return a dummy submodule for any attribute (e.g. torchaudio.functional),
    # so import-time attribute access succeeds; calling an op raises clearly.
    return _Unavailable(f"torchaudio.{name}")

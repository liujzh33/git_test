"""Compare inference latency WITH flash-attn vs forced-SDPA (== no flash_attn pkg).

Reuses the model builder from bench_inference_latency. The MoT joint self-attention
already runs through SDPA (it always passes a custom attn_mask); the only place that
actually dispatches to the flash_attn package at inference is the WAN T5 cross-attention
(no mask). This script quantifies the difference by monkeypatching flash_attention to a
pure-SDPA implementation.
"""
import os
import sys
import time

os.environ.setdefault("CUDA_VISIBLE_DEVICES", "1")
ROOT = "/home/work/wenjj/MotusV2"
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "bak"))

import torch
import torch.nn.functional as F

from bench_inference_latency import build_model, build_vlm_inputs, DEVICE


def sdpa_flash_attention(q, k, v, q_lens=None, k_lens=None, attn_mask=None,
                         dropout_p=0.0, softmax_scale=None, q_scale=None,
                         causal=False, window_size=(-1, -1), deterministic=False,
                         dtype=torch.bfloat16, version=None):
    """Drop-in replacement for wan flash_attention using only torch SDPA.

    q/k/v: [B, L, N, C]. attn_mask: [B, Lq, Lk] bool (True=allow) or None.
    Note: k_lens padding is ignored (inference uses full-length / no padding here).
    """
    out_dtype = q.dtype
    q = q.to(dtype)
    k = k.to(dtype)
    v = v.to(dtype)
    if q_scale is not None:
        q = q * q_scale
    qs = q.transpose(1, 2)  # [B, N, L, C]
    ks = k.transpose(1, 2)
    vs = v.transpose(1, 2)
    mask = None
    if attn_mask is not None:
        Lq, Lk = qs.size(2), ks.size(2)
        mask = attn_mask[:, :Lq, :Lk].unsqueeze(1)  # [B,1,Lq,Lk]
    out = F.scaled_dot_product_attention(
        qs, ks, vs, attn_mask=mask, is_causal=causal,
        dropout_p=dropout_p, scale=softmax_scale,
    )
    return out.transpose(1, 2).contiguous().to(out_dtype)


def main():
    torch.backends.cuda.matmul.allow_tf32 = True
    torch.backends.cudnn.allow_tf32 = True

    print(f"[bench] GPU: {torch.cuda.get_device_name(0)}")
    model = build_model()
    vlm_inputs = build_vlm_inputs()
    in_feat = model.video_model.wan_model.text_embedding[0].in_features
    t5 = [torch.randn(512, in_feat, dtype=torch.bfloat16, device=DEVICE)]
    ff = torch.rand(1, 3, 384, 320, device=DEVICE)
    st = torch.randn(1, 16, device=DEVICE)

    def run(n):
        with torch.no_grad():
            return model.inference_step(
                first_frame=ff, state=st, num_inference_steps=n,
                language_embeddings=t5, vlm_inputs=vlm_inputs,
            )

    def timeit(n, iters=10):
        torch.cuda.synchronize()
        t0 = time.perf_counter()
        for _ in range(iters):
            run(n)
        torch.cuda.synchronize()
        return (time.perf_counter() - t0) / iters * 1000.0

    import wan.modules.attention_mask as am
    import wan.modules.model_mask as mm
    print(f"[bench] flash_attn pkg: FA2={am.FLASH_ATTN_2_AVAILABLE} FA3={am.FLASH_ATTN_3_AVAILABLE}")

    # Count how many attention calls actually dispatch to flash_attn (no-mask path)
    orig_fa = mm.flash_attention
    counter = {"flash": 0, "masked": 0}

    def counting(*a, **kw):
        if kw.get("attn_mask", None) is None:
            counter["flash"] += 1
        else:
            counter["masked"] += 1
        return orig_fa(*a, **kw)

    mm.flash_attention = counting
    run(1)
    torch.cuda.synchronize()
    mm.flash_attention = orig_fa
    print(f"[bench] per 1-step inference: flash_attn(no-mask) calls={counter['flash']}, "
          f"SDPA-masked calls={counter['masked']}")

    # ---- WITH flash-attn (default) ----
    for _ in range(3):
        run(10)
    d10 = timeit(10)
    d5 = timeit(5)
    print(f"\n[WITH flash-attn]  5-step: {d5:8.2f} ms | 10-step: {d10:8.2f} ms")

    # ---- forced SDPA everywhere (== no flash_attn package) ----
    mm.flash_attention = sdpa_flash_attention
    try:
        import models.action_expert as ae
        ae.flash_attention = sdpa_flash_attention
    except Exception:
        pass
    for _ in range(3):
        run(10)
    s10 = timeit(10)
    s5 = timeit(5)
    print(f"[SDPA only     ]  5-step: {s5:8.2f} ms | 10-step: {s10:8.2f} ms")

    print("\n===== flash-attn vs SDPA (single RTX 5090, bf16, batch=1) =====")
    print(f"10-step: flash={d10:.1f} ms  sdpa={s10:.1f} ms  "
          f"delta={s10 - d10:+.1f} ms ({(s10/d10 - 1)*100:+.1f}%)")
    print(f" 5-step: flash={d5:.1f} ms  sdpa={s5:.1f} ms  "
          f"delta={s5 - d5:+.1f} ms ({(s5/d5 - 1)*100:+.1f}%)")

    mm.flash_attention = orig_fa


if __name__ == "__main__":
    main()

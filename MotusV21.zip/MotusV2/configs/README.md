# MotusV2 Config Layout

- Top-level YAML files are current MotusV2 experiment configs.
- `motusv1_adapted/` contains MotusV1 dataset/run configs migrated for the MotusV2 model.
- MotusV2 uses `MotusWanVlmDirectMask` with Qwen3-VL direct MoT. Legacy MotusV1 `und_expert` fields are ignored by `train/train_wan_vlm_mask.py`.
- The training loader auto-fills missing MotusV2 fields such as `model.qwen3_expert`, `model.training_mode`, `vlm_learning_rate`, and dataset-specific `common.action_dim/state_dim`.
- Molmo2 MotusV1 configs were converted to `vlm_type: qwen3_vl` because MotusV2 no longer has the Molmo understanding-expert path.

Typical usage:

```bash
accelerate launch train/train_wan_vlm_mask.py --config configs/motusv1_adapted/vitra_human_mixed.yaml --deepspeed configs/zero1.json
```

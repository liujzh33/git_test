"""Standalone single-GPU inference latency benchmark for MotusWanVlmDirectMask
under configs/g1d_pick_kettle_wan_vlm_mask.yaml.

Weights are randomly initialised (load_pretrained_backbones=False): latency depends
only on tensor shapes / architecture, not weight values, so this gives a faithful
timing of the real inference_step() path used by deploy_policy.get_action().
"""
import os
import sys
import time
import argparse

import numpy as np

os.environ.setdefault("CUDA_VISIBLE_DEVICES", "1")

ROOT = "/home/work/wenjj/MotusV2"
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "bak"))

import torch
from PIL import Image
from transformers import AutoProcessor

from models.motus_wan_vlm_direct_mask import (
    MotusWanVlmDirectMask,
    MotusWanVlmDirectMaskConfig,
)

WAN = "/cache/wx1469573/pretrained_models/Wan2.2-TI2V-5B"
VLM = "/cache/wx1469573/pretrained_models/Qwen3-VL-2B-Instruct"
DEVICE = "cuda"


def build_model():
    cfg = MotusWanVlmDirectMaskConfig(
        wan_checkpoint_path=WAN,
        vae_path=os.path.join(WAN, "Wan2.2_VAE.pth"),
        wan_config_path=WAN,
        video_precision="bfloat16",
        vlm_checkpoint_path=VLM,
        vlm_dim=2048,
        qwen3_expert_head_dim=128,
        qwen3_expert_num_heads=24,
        qwen3_expert_num_layers=30,
        qwen3_expert_norm_eps=1e-5,
        num_layers=30,
        action_state_dim=16,
        action_dim=16,
        action_expert_dim=1024,
        action_expert_ffn_dim_multiplier=4,
        action_expert_norm_eps=1e-5,
        global_downsample_rate=1,
        video_action_freq_ratio=2,
        num_video_frames=8,
        batch_size=1,
        video_height=384,
        video_width=320,
        training_mode="finetune",
        load_pretrained_backbones=False,
        vlm_frozen=False,
    )
    model = MotusWanVlmDirectMask(cfg)
    model.eval()
    _patch_vlm_image_features(model)
    return model


def _patch_vlm_image_features(model):
    """transformers>=5 returns a BaseModelOutputWithDeepstackFeatures object from
    get_image_features instead of the (image_embeds, deepstack) tuple the MotusV2
    code was written against. Adapt at the instance level. This only touches the
    return-value plumbing; the underlying vision-encoder compute is unchanged, so
    latency stays faithful.
    """
    orig = model.vlm_model.get_image_features

    def patched(pixel_values, image_grid_thw=None, **kw):
        out = orig(pixel_values, image_grid_thw, **kw)
        if hasattr(out, "pooler_output"):
            return out.pooler_output, out.deepstack_features
        return out

    model.vlm_model.get_image_features = patched


def build_vlm_inputs():
    proc = AutoProcessor.from_pretrained(VLM, trust_remote_code=True)
    img = Image.fromarray(np.random.randint(0, 255, (384, 320, 3), dtype=np.uint8))
    messages = [
        {
            "role": "user",
            "content": [
                {"type": "image", "image": img},
                {
                    "type": "text",
                    "text": (
                        "Task: pick up the kettle and pour water into the cup.\n"
                        "Predict the 3D wrist motion trajectories for both hands "
                        "in the robot base coordinate system. Return only motion tokens."
                    ),
                },
            ],
        }
    ]
    text = proc.apply_chat_template(messages, add_generation_prompt=True, tokenize=False)
    enc = proc(text=[text], images=[img], return_tensors="pt")
    vlm_inputs = {k: (v.to(DEVICE) if hasattr(v, "to") else v) for k, v in enc.items()}
    return vlm_inputs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--warmup", type=int, default=3)
    ap.add_argument("--iters", type=int, default=10)
    args = ap.parse_args()

    torch.backends.cuda.matmul.allow_tf32 = True
    torch.backends.cudnn.allow_tf32 = True

    print(f"[bench] GPU: {torch.cuda.get_device_name(0)}")
    print("[bench] building model (random weights, correct architecture)...")
    model = build_model()

    vlm_inputs = build_vlm_inputs()
    n_vlm_tokens = vlm_inputs["input_ids"].shape[1]
    print(f"[bench] VLM prompt tokens: {n_vlm_tokens}")

    in_feat = model.video_model.wan_model.text_embedding[0].in_features
    t5 = [torch.randn(512, in_feat, dtype=torch.bfloat16, device=DEVICE)]

    first_frame = torch.rand(1, 3, 384, 320, device=DEVICE)
    state = torch.randn(1, 16, device=DEVICE)

    def run(n_steps):
        with torch.no_grad():
            return model.inference_step(
                first_frame=first_frame,
                state=state,
                num_inference_steps=n_steps,
                language_embeddings=t5,
                vlm_inputs=vlm_inputs,
            )

    # warmup
    print(f"[bench] warmup x{args.warmup} @ 10 steps ...")
    for _ in range(args.warmup):
        run(10)
    torch.cuda.synchronize()

    def timeit(n_steps, iters):
        torch.cuda.synchronize()
        t0 = time.perf_counter()
        for _ in range(iters):
            run(n_steps)
        torch.cuda.synchronize()
        return (time.perf_counter() - t0) / iters * 1000.0  # ms

    # ---- component-level breakdown of the fixed (per-chunk) overhead ----
    def cuda_time(fn, iters=10):
        torch.cuda.synchronize()
        t0 = time.perf_counter()
        for _ in range(iters):
            fn()
        torch.cuda.synchronize()
        return (time.perf_counter() - t0) / iters * 1000.0

    first_frame_norm = (first_frame * 2.0 - 1.0).unsqueeze(2).to(model.dtype)

    @torch.no_grad()
    def vlm_only():
        model.qwen3_module.extract_per_layer_features(vlm_inputs)

    @torch.no_grad()
    def vae_encode_only():
        model.video_model.encode_video(first_frame_norm)

    cond_latent = model.video_model.encode_video(first_frame_norm)
    n_lat = 1 + model.config.num_video_frames // 4
    vid_latent = torch.randn(
        (1, cond_latent.shape[1], n_lat, cond_latent.shape[3], cond_latent.shape[4]),
        device=DEVICE, dtype=model.dtype,
    )

    @torch.no_grad()
    def vae_decode_only():
        model.video_model.decode_video(vid_latent)

    print("\n===== COMPONENT BREAKDOWN (one-time per chunk) =====")
    print(f"VLM extract_per_layer_features (Qwen3-VL-2B fwd): {cuda_time(vlm_only):8.2f} ms")
    print(f"VAE encode (1 condition frame):                  {cuda_time(vae_encode_only):8.2f} ms")
    print(f"VAE decode (predicted video, unused for control):{cuda_time(vae_decode_only):8.2f} ms")

    step_grid = [1, 2, 5, 10, 20]
    results = {}
    for n in step_grid:
        ms = timeit(n, args.iters)
        results[n] = ms
        print(f"[bench] num_inference_steps={n:>2d} -> {ms:8.2f} ms/chunk")

    # Linear fit: latency = fixed_overhead + per_step * n
    ns = np.array(step_grid, dtype=np.float64)
    ys = np.array([results[n] for n in step_grid], dtype=np.float64)
    A = np.vstack([ns, np.ones_like(ns)]).T
    per_step, fixed = np.linalg.lstsq(A, ys, rcond=None)[0]

    print("\n===== DECOMPOSITION (linear fit) =====")
    print(f"per denoising step (30 MoT layers): {per_step:8.2f} ms")
    print(f"fixed overhead (VLM extract + VAE encode/decode + T5 proj): {fixed:8.2f} ms")
    print(f"=> config default num_inference_timesteps=10 latency: "
          f"{fixed + per_step*10:8.2f} ms  (~{(fixed + per_step*10)/1000:.2f} s)")

    mem = torch.cuda.max_memory_allocated() / 1024**3
    print(f"\n[bench] peak CUDA memory allocated: {mem:.2f} GB")

    # ---- variant: SKIP VAE video decode (deployment only needs actions) ----
    # Replace decode_video with a cheap stub returning a correctly-shaped tensor,
    # so inference_step still returns (frames, actions) but pays ~0 for decode.
    orig_decode = model.video_model.decode_video

    def _stub_decode(video_latents):
        B = video_latents.shape[0]
        T = model.config.num_video_frames + 1
        return torch.zeros(
            (B, 3, T, model.config.video_height, model.config.video_width),
            device=video_latents.device, dtype=torch.float32,
        )

    model.video_model.decode_video = _stub_decode

    for _ in range(args.warmup):
        run(10)
    torch.cuda.synchronize()

    results_nodec = {}
    print("\n===== VARIANT: SKIP VAE VIDEO DECODE (actions only) =====")
    for n in step_grid:
        ms = timeit(n, args.iters)
        results_nodec[n] = ms
        print(f"[bench] (no-decode) num_inference_steps={n:>2d} -> {ms:8.2f} ms/chunk")

    ys2 = np.array([results_nodec[n] for n in step_grid], dtype=np.float64)
    per_step2, fixed2 = np.linalg.lstsq(A, ys2, rcond=None)[0]
    print("\n===== DECOMPOSITION (no-decode, linear fit) =====")
    print(f"per denoising step: {per_step2:8.2f} ms")
    print(f"fixed overhead (VLM extract + VAE encode + T5 proj, NO decode): {fixed2:8.2f} ms")
    print(f"=> num_inference_timesteps=10, no video decode: "
          f"{fixed2 + per_step2*10:8.2f} ms  (~{(fixed2 + per_step2*10)/1000:.2f} s)")
    print(f"=> savings vs full pipeline @10 steps: "
          f"{(fixed + per_step*10) - (fixed2 + per_step2*10):8.2f} ms")

    model.video_model.decode_video = orig_decode


if __name__ == "__main__":
    main()

# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

MotusV2 is a **trimodal UniDiffuser** for robot manipulation — it jointly generates video and action predictions conditioned on a first frame, language instructions, and VLM features. The architecture combines three modules: **WAN 5B** (video generation), **Qwen3-VL 2B** (visual-language understanding via direct Mixture-of-Transformers), and an **Action Expert** (DiT-style action prediction). All three interact through asymmetric joint attention (Action sees all; Video and VLM only self-attend).

## Training Commands

All training uses distributed `torchrun` with DeepSpeed ZeRO-1:

```bash
# Pre-train on multi-source robot data (8 datasets)
bash scripts/train_ADS_MotusV2_pretrain.sh

# Fine-tune on RoboTwin
bash scripts/train_ADS_MotusV2_robotwin.sh

# Fine-tune on cross-dataset mixed (human + robot, wrist16)
bash scripts/train_ADS_MotusV2_cross_wrist16.sh

# Fine-tune on cross-dataset mixed (relative wrist16)
bash scripts/train_ADS_MotusV2_cross_relative_wrist16.sh
```

Single-node manual launch:
```bash
torchrun --nproc_per_node=8 train/train_wan_vlm_mask.py \
    --deepspeed configs/zero1.json \
    --config configs/robotwin_wan_vlm_mask_stage2_15w.yaml \
    --run_name <name> \
    --report_to tensorboard
```

Key CLI overrides: `--resume <path>`, `--reset_scheduler`, `--max_steps N`, `--report_to {wandb,tensorboard,all,none}`, `--checkpoint_dir <path>`.

## Architecture

### Model (`models/`)

- **`motus_wan_vlm_direct_mask.py`** — `MotusWanVlmDirectMask`: the main model class. Contains `VideoModule`, `ActionModule`, and the core 30-layer trimodal MoT loop. Training uses flow-matching (not DDPM); inference uses Euler integration with teacher-forcing on the first video frame.
- **`wan_model_mask.py`** — `WanVideoModel`: wraps WAN 2.2-TI2V-5B for encoding/decoding video latents via VAE.
- **`action_expert.py`** — `ActionExpert`: DiT-style transformer with AdaLN, per-layer QKV projections into WAN head space, optional register tokens. Two modes: `pretrain` (action-only, no state token, no registers) and `finetune` (state+action, 4 register tokens).
- **`qwen3_module_wan.py`** — `Qwen3VLWanModule`: extracts per-layer hidden states from Qwen3-VL (28 layers) and maps them to 30 WAN layers (VLM layers 26,27 reused for WAN layers 28,29). Each layer has its own QKV projection to WAN head space.

### Asymmetric Attention Mask

The joint attention uses a fixed mask pattern:
```
Query\Key  Video  Action  VLM
Video       ✅      ❌     ❌
Action      ✅      ✅     ✅
VLM         ❌      ❌     ✅
```

### Data (`data/`)

- **`dataset.py`** — Registry pattern: `DATASET_REGISTRY` maps dataset type strings to builder functions. `create_dataset()` and `collate_fn()` are the entry points. `MultipleWeightedDataset` combines datasets with per-sample weighted sampling.
- **`multi_source_pretrain_dataset.py`** — Unified pre-training across 8 robot datasets + 3 human datasets. Robot actions are unified to 16-dim via `unify_action_to_16()`. Human actions (450-dim) are compressed to 16-dim latent via a pre-trained VAE.
- Dataset types: `robotwin`, `multi_source_pretrain`, `latent_action`, `lerobot`, `droid`, `g1d`, `vitra_human`, `vitra_human_mixed`, `vitra_robot_mixed`, `wiyh`, `egodex`, `cross_dataset_mixed`

### Training (`train/`)

- **`train_wan_vlm_mask.py`** — Main training script. Uses HuggingFace Accelerate with DeepSpeed. `MotusWanVlmTrainer` handles the step-based training loop, checkpoint save/load (with OBS upload support), and logging (TensorBoard + optional WandB).
- **`sample.py`** — Validation: `evaluate_model()` and `log_evaluation_metrics()`.

### Config (`configs/`)

YAML configs loaded via OmegaConf. Key sections: `common` (dimensions, video settings), `dataset` (type, sources, weights), `model` (WAN, VLM, qwen3_expert, action_expert, time_distribution, loss_weights), `training` (LR, scheduler, gradient settings), `system` (paths, intervals, workers), `logging`, `resume`, `finetune`.

The `load_config()` function in the training script auto-fills missing MotusV2 fields and adapts MotusV1 configs (e.g., ignores `und_expert`, maps `vlm_type` to `qwen3_vl`).

### Legacy (`bak/wan/`)

Contains the original WAN 2.2 codebase (attention, VAE, T5, model modules). Imported by the current model code — do not modify unless changing the WAN backbone itself.

## Key Conventions

- Precision: `bfloat16` for model weights; `float32` for time embeddings and AdaLN computations (numerical stability).
- Action dimensions: 16-dim unified format `[left_joints(6), pad(1), left_grip(1), right_joints(6), pad(1), right_grip(1)]`.
- Video: 384x320, 8 frames predicted, VAE latent space with 4x temporal + 32x spatial compression.
- Learning rates: separate param groups for WAN backbone (`wan_learning_rate`), VLM (`vlm_learning_rate`), and other params (`learning_rate`). All default to 5e-5.
- Checkpoint format: DeepSpeed saves per-rank optimizer shards; model weights in `mp_rank_00_model_states.pt`.
- `training_mode: pretrain` vs `finetune`: pretrain = action-only (no state token, no registers), finetune = state+action with register tokens.
- Distributed env vars: `NNODES`, `NODE_RANK`, `MASTER_ADDR`, `MASTER_PORT`, `NPROC_PER_NODE` (set by shell scripts or cluster scheduler).

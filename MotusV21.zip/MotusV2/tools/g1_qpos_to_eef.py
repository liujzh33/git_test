"""Forward-kinematics conversion of the G1-D LeRobot dataset from joint space to EEF space.

Reads the 16-dim joint-space state/action columns and emits per-arm Cartesian
poses in the same EEF convention the G1-D controller itself reports, reproduced
to the float32 output floor against Unitree's own logs (see g1_validate_fk.py).

Layout of the produced 16-dim vector, two symmetric 8-dim per-arm blocks of
[xyz(3), rotvec(3), reserved(1), gripper(1)]:

    0:3   left  TCP xyz               (m)
    3:6   left  TCP rotation vector   (rad, SO(3) log)
    6     reserved, always 0
    7     left  gripper               (passthrough of raw dim 14)
    8:11  right TCP xyz
    11:14 right TCP rotation vector
    14    reserved, always 0
    15    right gripper               (passthrough of raw dim 15)

The gripper sits at 7/15 to line up with the qpos layout the pretrained
checkpoint uses (``unify_action_to_16`` in multi_source_pretrain_dataset, and
``G1DLeRobotDataset._REORDER_FROM_RAW``), so that dim keeps its meaning across
the two action modes. Note this differs from
``compute_unified_eef_action_16d_with_gripper`` in data/human/unified_eef_action.py,
which puts the gripper at 6/14 and reserves 7/15.

Rotation is a rotation vector rather than Euler angles: it is what the rest of
the repo's EEF code uses, and it has no gimbal lock (the Euler pitch on this
dataset peaks at 1.49 rad against a singularity at 1.571).
"""

import argparse
import importlib.util
import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
import pinocchio as pin

def _load_eef_actions():
    """Load data/g1d/eef_actions.py without importing the data.g1d package.

    That package's __init__ pulls in the dataset and with it the VLM stack, which
    is absent from the pinocchio environment this tool runs in. Sharing the module
    is what keeps the delta convention here identical to the one training uses.
    """
    path = Path(__file__).resolve().parents[1] / "data" / "g1d" / "eef_actions.py"
    spec = importlib.util.spec_from_file_location("g1d_eef_actions", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


_eef = _load_eef_actions()
GRIPPER_DIMS, RESERVED_DIMS = _eef.GRIPPER_DIMS, _eef.RESERVED_DIMS
delta_stats, delta_moments = _eef.delta_stats, _eef.delta_moments

G1_DIR = Path("/home/work/wenjj/unitree_ros/robots/g1_d_description")
G1_URDF = G1_DIR / "g1_d.urdf"

# The dataset's first 14 dims, in order, named as in meta/info.json.
ARM_JOINTS = [
    "left_shoulder_pitch_joint",
    "left_shoulder_roll_joint",
    "left_shoulder_yaw_joint",
    "left_elbow_joint",
    "left_wrist_roll_joint",
    "left_wrist_pitch_joint",
    "left_wrist_yaw_joint",
    "right_shoulder_pitch_joint",
    "right_shoulder_roll_joint",
    "right_shoulder_yaw_joint",
    "right_elbow_joint",
    "right_wrist_roll_joint",
    "right_wrist_pitch_joint",
    "right_wrist_yaw_joint",
]

# Unitree's own EEF convention, recovered exactly from the raw pour-beans dumps
# (which record both joint angles and Cartesian pose) and matching the L_ee/R_ee
# frames in eval_robot/robot_control/robot_arm_ik.py. See g1_validate_fk.py.
TCP_OFFSET = np.array([0.05, 0.0, 0.0])

# Translation from the frame the G1-D controller reports in to torso_link. That
# frame is where a bipedal G1's pelvis sits with the waist zeroed; G1-D has no
# pelvis (wheeled base plus a lift column), so it is virtual. The practical
# consequence is that the pose is torso-relative, hence blind to lift height and
# chassis motion.
REPORT_FRAME_TO_TORSO = np.array([-0.0039635, 0.0, 0.044])




class G1ArmFK:
    def __init__(self):
        rob = pin.RobotWrapper.BuildFromURDF(str(G1_URDF), str(G1_DIR))
        self.model, self.data = rob.model, rob.model.createData()
        self.qadr = [self.model.joints[self.model.getJointId(n)].idx_q for n in ARM_JOINTS]
        self.wrists = [self.model.getFrameId(f"{s}_wrist_yaw_link") for s in ("left", "right")]
        torso = self.model.getFrameId("torso_link")
        pin.framesForwardKinematics(self.model, self.data, pin.neutral(self.model))
        self.report_frame = self.data.oMf[torso] * pin.SE3(np.eye(3), -REPORT_FRAME_TO_TORSO)
        self.tcp = pin.SE3(np.eye(3), TCP_OFFSET)

    def __call__(self, q16):
        """q16: (N, 16) joint-space frames -> (N, 16) EEF-space frames."""
        out = np.zeros((len(q16), 16), dtype=np.float32)
        q = pin.neutral(self.model)
        for i, q16i in enumerate(q16):
            # Every non-arm joint stays at zero: the reported pose is defined
            # relative to the torso, so lift and chassis state must not enter.
            q[self.qadr] = q16i[:14]
            pin.framesForwardKinematics(self.model, self.data, q)
            for arm, wrist in enumerate(self.wrists):
                rel = self.report_frame.actInv(self.data.oMf[wrist] * self.tcp)
                base = arm * 8
                out[i, base : base + 3] = rel.translation
                out[i, base + 3 : base + 6] = pin.log3(rel.rotation)
                out[i, base + 7] = q16i[14 + arm]
        return out


STATE_COL, ACTION_COL = "observation.state", "action"
EEF_STATE_COL, EEF_ACTION_COL = "observation.state.eef", "action.eef"
STATS_NAME = "eef_stats.json"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default="/home/work/wenjj/data/G1-D/pick-kettle-and-cup")
    ap.add_argument("--write", action="store_true",
                    help="add the EEF columns to the parquet files in place")
    ap.add_argument("--backup", action="store_true", help="keep a .qpos-only backup alongside")
    ap.add_argument("--horizon", type=int, default=64,
                    help="action chunk length the delta stats must cover")
    args = ap.parse_args()

    root = Path(args.root)
    files = sorted(root.glob("data/chunk-*/file-*.parquet"))
    if not files:
        raise SystemExit(f"no parquet under {root}/data/chunk-*/")
    fk = G1ArmFK()

    total, t0 = 0, time.time()
    action_eef, episode_ids = [], []
    for f in files:
        df = pd.read_parquet(f)
        for src, dst in ((STATE_COL, EEF_STATE_COL), (ACTION_COL, EEF_ACTION_COL)):
            eef = fk(np.stack(df[src].to_numpy()).astype(np.float64))
            df[dst] = list(eef)
            if src == ACTION_COL:
                action_eef.append(eef)
                episode_ids.append(df["episode_index"].to_numpy())
                report(eef)
        total += len(df)
        if args.write:
            if args.backup:
                bak = f.with_suffix(".parquet.qpos_backup")
                if not bak.exists():
                    pd.read_parquet(f).to_parquet(bak)
            # Same-directory temp keeps the swap atomic; a stray second parquet
            # in data/chunk-*/ would otherwise be picked up as another chunk.
            tmp = f.with_suffix(".parquet.tmp")
            df.to_parquet(tmp)
            tmp.replace(f)
    dt = time.time() - t0
    print(f"\n{total} frames in {dt:.1f}s ({total / dt:.0f} frames/s, state + action)")

    stats = write_stats(
        np.concatenate(action_eef), np.concatenate(episode_ids),
        args.horizon, root / "meta" / STATS_NAME, args.write,
    )
    print(f"\n{'written to' if args.write else 'would write to'} meta/{STATS_NAME}"
          f"   (delta stats over horizons 1..{args.horizon})")
    print(f"  {'dim':>4}  {'absolute [min, max]':>26}  {'delta [min, max]':>26}")
    for i in range(16):
        tag = "reserved" if i in RESERVED_DIMS else ("gripper" if i in GRIPPER_DIMS else "")
        print(f"  {i:4d}  [{stats['min'][i]:+10.4f}, {stats['max'][i]:+10.4f}]  "
              f"[{stats['delta_min'][i]:+10.4f}, {stats['delta_max'][i]:+10.4f}]  {tag}")
    if not args.write:
        print("\nnothing written; re-run with --write to apply")


def write_stats(eef, episode_ids, horizon, path, do_write):
    lo, hi = eef.min(0), eef.max(0)
    # Reserved dims are constant zero, which would give the min-max normalizer a
    # zero span. A [0, 1] span keeps them at 0 after normalisation.
    for d in RESERVED_DIMS:
        lo[d], hi[d] = 0.0, 1.0
    dlo, dhi = delta_stats(eef, episode_ids, horizon)
    dmu, dsd = delta_moments(eef, episode_ids, horizon)
    stats = {
        "min": lo.tolist(),
        "max": hi.tolist(),
        "mean": eef.mean(0).tolist(),
        "std": eef.std(0).tolist(),
        "delta_min": dlo.tolist(),
        "delta_max": dhi.tolist(),
        "delta_mean": dmu.tolist(),
        "delta_std": dsd.tolist(),
        "delta_horizon": int(horizon),
        "reserved_dims": list(RESERVED_DIMS),
        "gripper_dims": list(GRIPPER_DIMS),
        "layout": "[xyz(3), rotvec(3), reserved, gripper] x 2 arms",
    }
    if do_write:
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w") as fh:
            json.dump(stats, fh, indent=2)
    return stats


def report(eef):
    for arm, name in enumerate(("left ", "right")):
        b = arm * 8
        p, r = eef[:, b : b + 3], eef[:, b + 3 : b + 6]
        print(
            f"{name} TCP xyz x[{p[:, 0].min():+.3f},{p[:, 0].max():+.3f}] "
            f"y[{p[:, 1].min():+.3f},{p[:, 1].max():+.3f}] "
            f"z[{p[:, 2].min():+.3f},{p[:, 2].max():+.3f}]  "
            f"|rotvec| max {np.linalg.norm(r, axis=1).max():.3f} rad  "
            f"grip [{eef[:, b + 7].min():.3f},{eef[:, b + 7].max():.3f}]  "
            f"path {np.linalg.norm(np.diff(p, axis=0), axis=1).sum():.1f} m"
        )


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""
visualize_xperience_unified_eef.py
==================================

Standalone debugging / correctness-audit tool for the Xperience-10M
``unified_eef_camera_delta_wrist16`` action pipeline used by
``scripts/train_ADS_MotusV2_cross_unified_eef_wrist16_xperience10m.sh``.

It re-uses the *exact* training extraction (``XperienceMotusDataset`` +
``data/human/unified_eef_action.py``) via the non-invasive
``XperienceMotusDataset.get_debug_sample`` method, then re-projects the wrist
trajectory back onto the egocentric ``stereo_left.mp4`` frames so the
trajectory / hand correspondence can be checked visually and numerically.

Three trajectories are projected onto every frame:

  GT_DIRECT  (green)  : raw ``hand_mocap/*_translation`` projected *directly*
                        with the rectified cam01 intrinsics, i.e. under the
                        empirically-verified assumption that the mocap data is
                        already expressed in the per-frame camera frame.
  DATASET    (red)    : the trajectory reconstructed from the dataset's own
                        ``state`` + ``action`` tensors, re-projected under the
                        dataset's own semantics (mocap == SLAM-world frame).
  CORRECTED  (green,   : the wrist expressed in the frame-0 camera using the
              dashed)   correct camera-frame->camera-frame composition. Its
                        reprojection coincides with GT_DIRECT by construction.

If the dataset implementation were correct, DATASET (red) would sit on the
hands. It does not -- see the accompanying analysis.

Coordinate-frame naming convention used throughout:
    T_w_c   : maps camera-frame points to world   (camera pose in world)
    T_c_w   : maps world points to camera-frame    (== inv(T_w_c))
    T_c_b   : maps body-frame points to camera      (calibration, body->cam)
    R_w_c   : rotation part of T_w_c
    cam0    : fisheye camera (1088x1280), used by the *training* code
    cam01   : rectified stereo-left virtual pinhole (512x512) == stereo_left.mp4

Run:
    python tools/visualize_xperience_unified_eef.py \
        --data-root /home/work/wenjj/data/xperience-10m-clean \
        --output-dir /home/work/wenjj/MotusV2/outputs/xperience_unified_eef_vis \
        --num-samples 20 --seed 0
"""

import argparse
import json
import logging
import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import cv2
import h5py
import numpy as np

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from data.xperience.xperience_dataset import XperienceMotusDataset  # noqa: E402
from data.human.unified_eef_action import build_camera_world_pose_from_slam  # noqa: E402
from data.utils.image_utils import resize_with_padding  # noqa: E402

logging.basicConfig(level=logging.INFO, format="[%(levelname)s] %(message)s")
logger = logging.getLogger("viz_xp_eef")

# 16-D unified-eef layout (see data/human/unified_eef_action.py)
LEFT_T = slice(0, 3)
RIGHT_T = slice(8, 11)
LEFT_MASK = slice(0, 6)
RIGHT_MASK = slice(8, 14)

# BGR colors
C_GT = (0, 220, 0)        # green  : GT_DIRECT / corrected reprojection
C_DATASET = (0, 0, 255)   # red    : dataset target reprojection
C_HIST = (0, 200, 200)    # yellow : history
C_FUT = (255, 180, 0)     # cyan-ish : future
C_TXT = (255, 255, 255)


# --------------------------------------------------------------------------- #
# Geometry helpers
# --------------------------------------------------------------------------- #
def project_pinhole(p_cam: np.ndarray, K4: np.ndarray) -> Tuple[Optional[np.ndarray], float]:
    """Standard OpenCV pinhole projection (camera looks along +Z).

    Args:
        p_cam: (3,) point in camera frame.
        K4:    (4,) [fx, fy, cx, cy].
    Returns:
        (pixel_xy (2,) or None if behind, depth Z).
    """
    z = float(p_cam[2])
    if z <= 1e-6:
        return None, z
    fx, fy, cx, cy = K4
    u = fx * p_cam[0] / z + cx
    v = fy * p_cam[1] / z + cy
    return np.array([u, v], dtype=np.float64), z


def resize_with_padding_transform(orig_hw: Tuple[int, int], target_hw: Tuple[int, int]
                                  ) -> Tuple[float, float, float]:
    """Return (scale, x_offset, y_offset) matching data.utils.image_utils.resize_with_padding.

    Pixel mapping: (u', v') = (u * scale + x_offset, v * scale + y_offset).
    """
    oh, ow = orig_hw
    th, tw = target_hw
    scale = min(th / oh, tw / ow)
    new_h = int(oh * scale)
    new_w = int(ow * scale)
    y_off = (th - new_h) // 2
    x_off = (tw - new_w) // 2
    return scale, float(x_off), float(y_off)


def cam_pose_series(slam_trans_win: np.ndarray, slam_quat_win: np.ndarray, T_c_b: np.ndarray
                    ) -> Tuple[np.ndarray, np.ndarray]:
    """Per-frame camera pose in world for the whole window.

    Returns (R_w_c (W,3,3), t_w_c (W,3)).  Frames with non-finite / non-unit
    SLAM data are left as NaN so the caller can flag them.
    """
    W = slam_trans_win.shape[0]
    R = np.full((W, 3, 3), np.nan)
    t = np.full((W, 3), np.nan)
    for i in range(W):
        q = slam_quat_win[i]
        if not np.all(np.isfinite(slam_trans_win[i])) or not np.all(np.isfinite(q)):
            continue
        if abs(np.linalg.norm(q) - 1.0) > 1e-2:
            continue
        Ri, ti = build_camera_world_pose_from_slam(slam_trans_win[i], q, T_c_b)
        R[i] = Ri
        t[i] = ti
    return R, t


# --------------------------------------------------------------------------- #
# Trajectory reconstruction (three interpretations)
# --------------------------------------------------------------------------- #
def reconstruct_dataset_anchor(state: np.ndarray, action: np.ndarray) -> Dict[str, np.ndarray]:
    """Absolute wrist positions in the *anchor* (frame-0) camera frame, as the
    dataset represents them: p(0)=state, p(i+1)=state + action[i].

    Returns {'left': (W,3), 'right': (W,3)} where W = F+1.
    """
    F = action.shape[0]
    left = np.zeros((F + 1, 3))
    right = np.zeros((F + 1, 3))
    left[0] = state[LEFT_T]
    right[0] = state[RIGHT_T]
    for i in range(F):
        left[i + 1] = state[LEFT_T] + action[i][LEFT_T]
        right[i + 1] = state[RIGHT_T] + action[i][RIGHT_T]
    return {"left": left, "right": right}


def correct_first_frame_cam(hand_win: np.ndarray, R_w_c01: np.ndarray, t_w_c01: np.ndarray
                            ) -> np.ndarray:
    """CORRECT unified-EEF: express per-frame-camera hand points in the frame-0 camera.

    p_cam0(t) = R_w_c01[0]^T @ ( R_w_c01[t] @ hand_win[t] + t_w_c01[t] - t_w_c01[0] )

    Args:
        hand_win: (W, 3) hand translation in the *per-frame* camera frame.
        R_w_c01, t_w_c01: (W,3,3)/(W,3) per-frame cam01 pose in world.
    Returns:
        (W, 3) hand positions in the frame-0 camera frame.
    """
    W = hand_win.shape[0]
    out = np.full((W, 3), np.nan)
    R0, t0 = R_w_c01[0], t_w_c01[0]
    if not np.all(np.isfinite(R0)):
        return out
    for t in range(W):
        if not np.all(np.isfinite(R_w_c01[t])):
            continue
        p_world = R_w_c01[t] @ hand_win[t] + t_w_c01[t]
        out[t] = R0.T @ (p_world - t0)
    return out


# --------------------------------------------------------------------------- #
# Per-sample processing
# --------------------------------------------------------------------------- #
def native_frames(mp4_path: str, indices: List[int]) -> np.ndarray:
    import decord
    vr = decord.VideoReader(str(mp4_path), num_threads=2)
    n = len(vr)
    safe = [min(max(int(i), 0), n - 1) for i in indices]
    batch = vr.get_batch(safe).asnumpy()
    if batch.shape[-1] == 4:
        batch = batch[..., :3]
    return batch.astype(np.uint8)


def _finite(x) -> bool:
    return x is not None and np.all(np.isfinite(np.asarray(x, dtype=np.float64)))


def compute_projections(sample: Dict[str, Any]) -> Dict[str, Any]:
    """Compute all three trajectories + per-frame camera poses for a debug sample.

    Everything is projected with the cam01 (stereo-left) intrinsics.
    Returns a dict with per-hand, per-frame pixel/depth/status arrays.
    """
    W = sample["num_video_frames"] + 1
    K01 = sample["K_cam01"]
    T_c_b_cam0 = sample["T_c_b_cam0"]
    T_c_b_cam01 = sample["T_c_b_cam01"]

    # Per-frame camera poses (cam01 for projection + correct math; cam0 for dataset math)
    R_w_c01, t_w_c01 = cam_pose_series(sample["slam_trans_win"], sample["slam_quat_win"], T_c_b_cam01)
    R_w_c0, t_w_c0 = cam_pose_series(sample["slam_trans_win"], sample["slam_quat_win"], T_c_b_cam0)

    # Reference (anchor) cam0 pose, exactly as training built it.
    R_ref, t_ref = sample["R_w_c_ref"], sample["t_w_c_ref"]

    out: Dict[str, Any] = {
        "R_w_c01": R_w_c01, "t_w_c01": t_w_c01,
        "R_w_c0": R_w_c0, "t_w_c0": t_w_c0,
        "hands": {},
    }

    has_dataset = sample["action"] is not None and sample["state"] is not None
    ds_anchor = reconstruct_dataset_anchor(sample["state"], sample["action"]) if has_dataset else None

    for hand in ("left", "right"):
        raw = sample[f"{hand}_trans_win"]            # (W,3) per-frame cam frame (empirical)
        valid = sample[f"{hand}_valid_win"]          # (W,) bool
        t_slice = LEFT_T if hand == "left" else RIGHT_T
        mask_slice = LEFT_MASK if hand == "left" else RIGHT_MASK

        # ---- CORRECT first-frame-camera trajectory ----
        corr_cam0 = correct_first_frame_cam(raw, R_w_c01, t_w_c01)  # (W,3)

        gt_px = np.full((W, 2), np.nan)
        gt_z = np.full((W,), np.nan)
        gt_status = ["missing"] * W
        ds_px = np.full((W, 2), np.nan)
        ds_z = np.full((W,), np.nan)
        ds_status = ["missing"] * W

        for j in range(W):
            # GT_DIRECT: raw hand is already in per-frame cam01 frame -> project directly.
            if bool(valid[j]) and _finite(raw[j]):
                px, z = project_pinhole(raw[j], K01)
                gt_z[j] = z
                if px is None:
                    gt_status[j] = "behind(z<=0)"
                else:
                    gt_px[j] = px
                    inb = (0 <= px[0] < 512) and (0 <= px[1] < 512)
                    gt_status[j] = "ok" if inb else "out_of_frame"

            # DATASET: reconstruct anchor(cam0) trajectory from state+action, lift to world
            # via the reference cam0 pose, re-project via per-frame cam01 pose (overlay on
            # stereo_left).  This is the dataset's own semantics (mocap == world).
            if has_dataset and _finite(R_w_c01[j]):
                p_anchor = ds_anchor[hand][j]
                p_world = R_ref @ p_anchor + t_ref       # dataset lifts anchor-cam -> world
                p_cam_j = R_w_c01[j].T @ (p_world - t_w_c01[j])
                px, z = project_pinhole(p_cam_j, K01)
                ds_z[j] = z
                # only meaningful where the dataset's mask marks the hand valid
                dim_valid = has_dataset and (
                    (j == 0 and bool(sample["action_valid_mask"] is not None))
                    or True
                )
                if px is None:
                    ds_status[j] = "behind(z<=0)"
                else:
                    ds_px[j] = px
                    inb = (0 <= px[0] < 512) and (0 <= px[1] < 512)
                    ds_status[j] = "ok" if inb else "out_of_frame"

        out["hands"][hand] = {
            "raw_cam": raw,                 # (W,3) per-frame camera frame
            "valid": valid.astype(bool),
            "correct_cam0": corr_cam0,      # (W,3) frame-0 camera (correct unified eef)
            "dataset_anchor": None if ds_anchor is None else ds_anchor[hand],  # (W,3)
            "gt_px": gt_px, "gt_z": gt_z, "gt_status": gt_status,
            "ds_px": ds_px, "ds_z": ds_z, "ds_status": ds_status,
        }
    return out


# --------------------------------------------------------------------------- #
# Rendering
# --------------------------------------------------------------------------- #
def _map_px(px: np.ndarray, view: str, orig_hw, target_hw, tf) -> Optional[Tuple[int, int]]:
    if px is None or not np.all(np.isfinite(px)):
        return None
    if view == "processed":
        scale, xo, yo = tf
        u = px[0] * scale + xo
        v = px[1] * scale + yo
    else:
        u, v = px[0], px[1]
    return int(round(u)), int(round(v))


def render_overlay(sample: Dict[str, Any], proj: Dict[str, Any], view: str,
                   draw_history: bool, draw_future: bool, future_horizon: int
                   ) -> List[np.ndarray]:
    """Render the window frames with overlays. Returns list of BGR frames."""
    W = sample["num_video_frames"] + 1
    idxs = sample["window_indices"].tolist()
    native = native_frames(sample["mp4_path"], idxs)  # (W,512,512,3) RGB
    orig_hw = (native.shape[1], native.shape[2])
    target_hw = (384, 320)
    tf = resize_with_padding_transform(orig_hw, target_hw)

    def frame_img(j):
        rgb = native[j]
        if view == "processed":
            rgb = resize_with_padding(rgb, target_hw)
        return cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR).copy()

    H = target_hw[0] if view == "processed" else orig_hw[0]
    Wpx = target_hw[1] if view == "processed" else orig_hw[1]

    frames_out = []
    hand_colors = {"left": (255, 128, 0), "right": (0, 128, 255)}
    for j in range(W):
        img = frame_img(j)
        # side panel
        panel = np.zeros((img.shape[0], 360, 3), dtype=np.uint8)
        y = 18

        def put(txt, col=C_TXT, dy=16):
            nonlocal y
            cv2.putText(panel, txt, (6, y), cv2.FONT_HERSHEY_SIMPLEX, 0.42, col, 1, cv2.LINE_AA)
            y += dy

        put(f"{sample['seq_name']}/{sample['ep_name']}", (200, 255, 200))
        put(f"view={view}  clip_start(f0)={idxs[0]}")
        put(f"win_idx(j)={j}  orig_frame={idxs[j]}", (180, 220, 255))
        put(f"K_cam01={np.round(sample['K_cam01'],1).tolist()}", (150, 200, 150), 14)
        put("GREEN=GT/correct  RED=dataset", (0, 255, 255), 18)

        for hand in ("left", "right"):
            hd = proj["hands"][hand]
            col = hand_colors[hand]
            valid = bool(hd["valid"][j])
            put(f"[{hand}] valid={valid}", col, 14)
            raw = hd["raw_cam"][j]
            put(f"  cam_xyz={np.round(raw,3).tolist()}", col, 14)
            gz = hd["gt_z"][j]
            put(f"  GT z={gz:.3f} px={_fmt_px(hd['gt_px'][j])} {hd['gt_status'][j]}", C_GT, 14)
            dz = hd["ds_z"][j]
            put(f"  DS z={dz:.3f} px={_fmt_px(hd['ds_px'][j])} {hd['ds_status'][j]}", C_DATASET, 16)

            # history / future poly-lines (GT_DIRECT) + dataset current point
            if draw_history and j > 0:
                pts = [_map_px(hd["gt_px"][k], view, orig_hw, target_hw, tf) for k in range(0, j + 1)]
                _polyline(img, pts, C_HIST, 1)
            if draw_future:
                hi = min(W, j + 1 + future_horizon)
                pts = [_map_px(hd["gt_px"][k], view, orig_hw, target_hw, tf) for k in range(j, hi)]
                _polyline(img, pts, C_FUT, 1, dashed=True)

            # current points
            if valid:
                p_gt = _map_px(hd["gt_px"][j], view, orig_hw, target_hw, tf)
                if p_gt is not None:
                    _safe_circle(img, p_gt, 7, C_GT, filled=True, label=hand[0].upper())
                p_ds = _map_px(hd["ds_px"][j], view, orig_hw, target_hw, tf)
                if p_ds is not None:
                    _safe_circle(img, p_ds, 6, C_DATASET, filled=False)

        out = np.hstack([img, panel])
        frames_out.append(out)
    return frames_out


def _fmt_px(px):
    if px is None or not np.all(np.isfinite(px)):
        return "--"
    return f"({px[0]:.0f},{px[1]:.0f})"


def _polyline(img, pts, color, thickness, dashed=False):
    pts = [p for p in pts if p is not None]
    for a, b in zip(pts[:-1], pts[1:]):
        if dashed:
            mid = ((a[0] + b[0]) // 2, (a[1] + b[1]) // 2)
            cv2.line(img, a, mid, color, thickness, cv2.LINE_AA)
        else:
            cv2.line(img, a, b, color, thickness, cv2.LINE_AA)


def _safe_circle(img, p, r, color, filled=True, label=None):
    H, Wpx = img.shape[:2]
    x, y = p
    inb = 0 <= x < Wpx and 0 <= y < H
    if inb:
        cv2.circle(img, (x, y), r, color, -1 if filled else 2, cv2.LINE_AA)
        if label:
            cv2.putText(img, label, (x + 6, y - 6), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1, cv2.LINE_AA)
    else:
        # clamp to edge with an arrow indicating out-of-frame
        cx, cy = max(6, min(Wpx - 7, x)), max(6, min(H - 7, y))
        cv2.circle(img, (cx, cy), 5, color, 2, cv2.LINE_AA)
        cv2.putText(img, "OOF", (cx + 6, cy), cv2.FONT_HERSHEY_SIMPLEX, 0.4, color, 1, cv2.LINE_AA)


def write_video(frames: List[np.ndarray], path: str, fps: int):
    if not frames:
        return
    h, w = frames[0].shape[:2]
    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    vw = cv2.VideoWriter(path, fourcc, fps, (w, h))
    for f in frames:
        vw.write(f)
    vw.release()


# --------------------------------------------------------------------------- #
# Numerical consistency checks
# --------------------------------------------------------------------------- #
def numerical_checks(sample: Dict[str, Any], proj: Dict[str, Any]) -> Dict[str, Any]:
    W = sample["num_video_frames"] + 1
    R01, t01 = proj["R_w_c01"], proj["t_w_c01"]
    checks: Dict[str, Any] = {}

    # (4) time alignment: video / hand / slam share the same window indices by construction
    checks["time_alignment_ok"] = True
    checks["window_indices"] = sample["window_indices"].tolist()

    # (2) rigid roundtrip: cam(t) -> world -> frame0-cam -> world -> cam(t)
    rt_err = []
    for hand in ("left", "right"):
        raw = proj["hands"][hand]["raw_cam"]
        corr = proj["hands"][hand]["correct_cam0"]
        for t in range(W):
            if not (_finite(R01[t]) and _finite(R01[0]) and _finite(corr[t]) and _finite(raw[t])):
                continue
            # frame0-cam -> world -> cam(t)
            p_world = R01[0] @ corr[t] + t01[0]
            p_back = R01[t].T @ (p_world - t01[t])
            rt_err.append(float(np.linalg.norm(p_back - raw[t])))
    checks["roundtrip_cam_max_err"] = float(np.max(rt_err)) if rt_err else None
    checks["roundtrip_cam_mean_err"] = float(np.mean(rt_err)) if rt_err else None

    # (1) first-frame reference consistency (GT_DIRECT at j=0)
    ff = {}
    for hand in ("left", "right"):
        hd = proj["hands"][hand]
        ff[hand] = {"valid": bool(hd["valid"][0]), "z": _num(hd["gt_z"][0]),
                    "px": _px_list(hd["gt_px"][0]), "status": hd["gt_status"][0]}
    checks["first_frame_gt"] = ff

    # (5) units / ranges
    stats = {}
    for hand in ("left", "right"):
        raw = proj["hands"][hand]["raw_cam"]
        valid = proj["hands"][hand]["valid"]
        rv = raw[valid]
        if len(rv):
            disp = np.linalg.norm(np.diff(rv, axis=0), axis=1) if len(rv) > 1 else np.array([0.0])
            stats[hand] = {
                "min": rv.min(0).tolist(), "max": rv.max(0).tolist(),
                "mean": rv.mean(0).tolist(), "std": rv.std(0).tolist(),
                "step_disp_mean": float(disp.mean()), "step_disp_max": float(disp.max()),
                "depth_min": float(rv[:, 2].min()), "depth_max": float(rv[:, 2].max()),
            }
    checks["hand_cam_stats"] = stats
    # camera translation over window
    ct = t01[np.all(np.isfinite(t01), axis=1)]
    if len(ct) > 1:
        cam_disp = np.linalg.norm(np.diff(ct, axis=0), axis=1)
        checks["camera_translation"] = {
            "range": (ct.max(0) - ct.min(0)).tolist(),
            "step_mean": float(cam_disp.mean()), "step_max": float(cam_disp.max()),
        }

    # (6) reprojection vs 2D annotation
    checks["reprojection_2d_annotation"] = (
        "NOT AVAILABLE: the Xperience HDF5 exposes only 3D fields "
        "(hand_mocap/*_joints_3d, full_body_mocap/keypoints); there is no 2D "
        "wrist keypoint annotation. GT_DIRECT projection is used as the visual "
        "reference instead."
    )

    # bug quantification: GT_DIRECT vs DATASET projection quality
    quant = {}
    for hand in ("left", "right"):
        hd = proj["hands"][hand]
        valid = hd["valid"]
        n = int(valid.sum())
        if n == 0:
            continue
        gt_ok = sum(1 for j in range(W) if valid[j] and hd["gt_status"][j] == "ok")
        ds_behind = sum(1 for j in range(W) if valid[j] and hd["ds_status"][j] == "behind(z<=0)")
        ds_ok = sum(1 for j in range(W) if valid[j] and hd["ds_status"][j] == "ok")
        quant[hand] = {
            "n_valid": n,
            "gt_direct_inframe_frac": gt_ok / n,
            "dataset_inframe_frac": ds_ok / n,
            "dataset_behind_frac": ds_behind / n,
        }
    checks["projection_quality"] = quant
    return checks


def _num(x):
    return None if x is None or not np.isfinite(x) else float(x)


def _px_list(px):
    if px is None or not np.all(np.isfinite(px)):
        return None
    return [float(px[0]), float(px[1])]


# --------------------------------------------------------------------------- #
# Sample selection
# --------------------------------------------------------------------------- #
def enumerate_candidates(ds: XperienceMotusDataset, rng: np.random.Generator,
                         per_episode: int = 6) -> List[Tuple[int, int]]:
    """Deterministic list of (episode_index, frame_start) candidate windows."""
    F = ds.num_video_frames
    cands = []
    for ei, ep in enumerate(ds.episodes):
        n = ep["n_frames"]
        hi = n - F - 1
        if hi <= 0:
            continue
        starts = np.linspace(0, hi, per_episode).astype(int)
        for s in starts:
            cands.append((ei, int(s)))
    return cands


def classify_sample(sample: Dict[str, Any], proj: Dict[str, Any]) -> List[str]:
    tags = []
    lv = sample["left_valid_win"]
    rv = sample["right_valid_win"]
    if lv.any() and not rv.any():
        tags.append("left_only")
    if rv.any() and not lv.any():
        tags.append("right_only")
    if lv.any() and rv.any():
        tags.append("both_hands")
    if not lv.all() or not rv.all():
        tags.append("has_padding_or_invalid")
    # camera motion
    t01 = proj["t_w_c01"]
    ct = t01[np.all(np.isfinite(t01), axis=1)]
    if len(ct) > 1 and np.linalg.norm(ct[-1] - ct[0]) > 0.15:
        tags.append("large_camera_motion")
    # hand motion
    for hand in ("left", "right"):
        raw = proj["hands"][hand]["raw_cam"]
        vmask = proj["hands"][hand]["valid"]
        rvv = raw[vmask]
        if len(rvv) > 1 and np.linalg.norm(rvv[-1] - rvv[0]) > 0.10:
            tags.append("large_hand_motion")
            break
    # projection anomalies
    for hand in ("left", "right"):
        hd = proj["hands"][hand]
        n = int(hd["valid"].sum())
        if n == 0:
            continue
        oob = sum(1 for j in range(len(hd["gt_status"])) if hd["valid"][j] and hd["gt_status"][j] == "out_of_frame")
        behind = sum(1 for j in range(len(hd["gt_status"])) if hd["valid"][j] and hd["gt_status"][j] == "behind(z<=0)")
        if oob / n > 0.3:
            tags.append("high_oob")
        if behind / n > 0.1:
            tags.append("neg_depth")
    return sorted(set(tags))


# --------------------------------------------------------------------------- #
# Serialization
# --------------------------------------------------------------------------- #
def build_debug_json(sample: Dict[str, Any], proj: Dict[str, Any], checks: Dict[str, Any]) -> Dict[str, Any]:
    def arr(x):
        return None if x is None else np.asarray(x).tolist()
    d = {
        "sample_index": {"episode_index": sample["episode_index"], "frame_start": sample["frame_start"]},
        "video_path": sample["mp4_path"],
        "h5_path": sample["h5_path"],
        "clip_start": int(sample["window_indices"][0]),
        "clip_end": int(sample["window_indices"][-1]),
        "selected_frame_indices": sample["window_indices"].tolist(),
        "instruction": sample["instruction"],
        "extraction_error": sample["error"],
        "camera_intrinsics": {"cam0_K": arr(sample["K_cam0"]), "cam01_K": arr(sample["K_cam01"])},
        "camera_extrinsics": {"cam0_T_c_b": arr(sample["T_c_b_cam0"]), "cam01_T_c_b": arr(sample["T_c_b_cam01"])},
        "reference_camera_pose": {"R_w_c_ref(cam0)": arr(sample["R_w_c_ref"]), "t_w_c_ref(cam0)": arr(sample["t_w_c_ref"])},
        "per_frame_cam01_R_w_c": arr(proj["R_w_c01"]),
        "per_frame_cam01_t_w_c": arr(proj["t_w_c01"]),
        "state": arr(sample["state"]),
        "action": arr(sample["action"]),
        "action_valid_mask": arr(sample["action_valid_mask"]),
        "hands": {},
        "checks": checks,
    }
    for hand in ("left", "right"):
        hd = proj["hands"][hand]
        d["hands"][hand] = {
            "raw_wrist_trajectory_cam_frame": arr(hd["raw_cam"]),
            "unified_eef_trajectory_frame0_cam_CORRECT": arr(hd["correct_cam0"]),
            "dataset_anchor_trajectory": arr(hd["dataset_anchor"]),
            "valid_mask": arr(hd["valid"]),
            "gt_direct_pixels": arr(hd["gt_px"]),
            "gt_direct_depth": arr(hd["gt_z"]),
            "gt_direct_status": hd["gt_status"],
            "dataset_pixels": arr(hd["ds_px"]),
            "dataset_depth": arr(hd["ds_z"]),
            "dataset_status": hd["ds_status"],
        }
    return d


# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #
def build_dataset(data_root: str, num_video_frames: int) -> XperienceMotusDataset:
    return XperienceMotusDataset(
        dataset_dir=data_root,
        num_video_frames=num_video_frames,
        video_size=(384, 320),
        action_mode="unified_eef_camera_delta_wrist16",
        reference_camera_key="cam0",
        require_camera_extrinsics=True,
        allow_base_relative_fallback=False,
        vlm_checkpoint_path=None,
        t5_mode="none",  # skip T5 entirely (no GPU / model weights needed)
    )


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--data-root", default="/home/work/wenjj/data/xperience-10m-clean")
    ap.add_argument("--output-dir", default="/home/work/wenjj/MotusV2/outputs/xperience_unified_eef_vis")
    ap.add_argument("--num-samples", type=int, default=20)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--sample-index", type=int, default=None,
                    help="Explicit candidate index (overrides random selection).")
    ap.add_argument("--episode-index", type=int, default=None)
    ap.add_argument("--frame-start", type=int, default=None)
    ap.add_argument("--num-video-frames", type=int, default=8)
    ap.add_argument("--fps", type=int, default=4)
    ap.add_argument("--future-horizon", type=int, default=4)
    ap.add_argument("--no-history", action="store_true")
    ap.add_argument("--no-future", action="store_true")
    ap.add_argument("--view", choices=["original", "processed", "both"], default="both")
    ap.add_argument("--no-video", action="store_true", help="Skip mp4, only debug json + preview.")
    ap.add_argument("--stratified", action="store_true",
                    help="Try to cover diverse sample categories instead of pure random.")
    args = ap.parse_args()

    out_root = Path(args.output_dir)
    out_root.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(args.seed)

    logger.info(f"Building Xperience dataset from {args.data_root} ...")
    ds = build_dataset(args.data_root, args.num_video_frames)

    # ---- choose (episode_index, frame_start) list ----
    if args.episode_index is not None and args.frame_start is not None:
        selection = [(args.episode_index, args.frame_start)]
    else:
        cands = enumerate_candidates(ds, rng)
        if args.sample_index is not None:
            selection = [cands[args.sample_index % len(cands)]]
        else:
            order = rng.permutation(len(cands))
            selection = [cands[i] for i in order[: max(args.num_samples * 3, args.num_samples)]]

    views = ["original", "processed"] if args.view == "both" else [args.view]

    summary = {"data_root": args.data_root, "num_video_frames": args.num_video_frames,
               "samples": [], "aggregate": {}}
    agg = {"left": [], "right": []}
    seen_tags: Dict[str, int] = {}
    produced = 0

    for (ei, fs) in selection:
        if produced >= args.num_samples:
            break
        try:
            sample = ds.get_debug_sample(ei, fs, load_video=False)
        except Exception as e:
            logger.warning(f"get_debug_sample({ei},{fs}) failed: {e}")
            continue
        if sample["K_cam01"] is None or sample["T_c_b_cam01"] is None:
            logger.warning(f"ep{ei} missing cam01 calibration; skipping")
            continue

        proj = compute_projections(sample)
        tags = classify_sample(sample, proj)

        if args.stratified and args.sample_index is None and args.episode_index is None:
            # prefer samples that add a new tag; skip over-represented ones
            novel = [t for t in tags if seen_tags.get(t, 0) < 3]
            if produced >= 3 and not novel and produced < args.num_samples:
                # still accept some, but bias toward novelty
                if rng.random() > 0.4:
                    continue

        checks = numerical_checks(sample, proj)
        for hand in ("left", "right"):
            if hand in checks.get("projection_quality", {}):
                agg[hand].append(checks["projection_quality"][hand])
        for t in tags:
            seen_tags[t] = seen_tags.get(t, 0) + 1

        sample_id = f"sample_{produced:06d}_ep{ei}_f{fs}"
        sdir = out_root / sample_id
        sdir.mkdir(parents=True, exist_ok=True)

        # metadata + debug json
        debug = build_debug_json(sample, proj, checks)
        (sdir / "debug.json").write_text(json.dumps(debug, indent=2))
        meta = {
            "sample_id": sample_id, "episode_index": ei, "frame_start": fs,
            "seq_name": sample["seq_name"], "ep_name": sample["ep_name"],
            "instruction": sample["instruction"], "tags": tags,
            "extraction_error": sample["error"],
            "clip_start": int(sample["window_indices"][0]),
            "clip_end": int(sample["window_indices"][-1]),
        }
        (sdir / "sample_metadata.json").write_text(json.dumps(meta, indent=2))

        vids = {}
        preview_written = False
        if not args.no_video:
            for view in views:
                frames = render_overlay(
                    sample, proj, view,
                    draw_history=not args.no_history,
                    draw_future=not args.no_future,
                    future_horizon=args.future_horizon,
                )
                vpath = sdir / f"overlay_{view}.mp4"
                write_video(frames, str(vpath), args.fps)
                vids[view] = str(vpath)
                if not preview_written and frames:
                    cv2.imwrite(str(sdir / "preview.png"), frames[len(frames) // 2])
                    preview_written = True

        summary["samples"].append({
            "sample_id": sample_id, "tags": tags, "videos": vids,
            "extraction_error": sample["error"],
            "projection_quality": checks.get("projection_quality", {}),
            "roundtrip_cam_max_err": checks.get("roundtrip_cam_max_err"),
        })
        produced += 1
        logger.info(f"[{produced}/{args.num_samples}] {sample_id} tags={tags} "
                    f"roundtrip_err={checks.get('roundtrip_cam_max_err')}")

    # aggregate
    def _agg(key_list, field):
        vals = [d[field] for d in key_list if field in d]
        return {"mean": float(np.mean(vals)), "min": float(np.min(vals)),
                "max": float(np.max(vals)), "n": len(vals)} if vals else None
    for hand in ("left", "right"):
        summary["aggregate"][hand] = {
            "gt_direct_inframe_frac": _agg(agg[hand], "gt_direct_inframe_frac"),
            "dataset_inframe_frac": _agg(agg[hand], "dataset_inframe_frac"),
            "dataset_behind_frac": _agg(agg[hand], "dataset_behind_frac"),
        }
    summary["tag_counts"] = seen_tags
    (out_root / "summary.json").write_text(json.dumps(summary, indent=2))
    logger.info(f"Done. Produced {produced} samples -> {out_root}")
    logger.info(f"Summary: {out_root/'summary.json'}")


if __name__ == "__main__":
    main()

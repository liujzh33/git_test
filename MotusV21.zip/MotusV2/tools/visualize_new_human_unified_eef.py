#!/usr/bin/env python3
"""
visualize_new_human_unified_eef.py
==================================

Unified-EEF correctness audit + trajectory-reprojection visualization for the
two newly added human datasets:

    --dataset egoverse   (EgoVerse ARIA subset,  data/egoverse/egoverse_dataset.py)
    --dataset openaoe    (OpenAoE-2000h,         data/openaoe/openaoe_dataset.py)

It follows exactly the method used to audit / fix Xperience and to confirm
EgoDex + VITRA: reuse the dataset's own training extraction through the
non-invasive ``get_debug_sample`` hook, then re-project two trajectories onto
every video frame:

  GT_DIRECT (green) : raw world-frame wrist projected via the per-frame camera
                      pose (camera->world) + intrinsics.
  DATASET   (red)   : the trajectory reconstructed from the dataset's own
                      ``state`` + ``action`` tensors, re-projected the same way.

For a CORRECT implementation the red dots sit exactly on the green dots and
both track the visible hand. Divergence localises the bug:
  * red behind the camera (z<=0) on every frame  -> wrong reference frame
    (this is the signature the Xperience bug produced);
  * green itself off the hand                    -> the raw pose/camera
    convention assumption is wrong (e.g. quaternion order, or head-vs-camera
    offset for EgoVerse);
  * red == green but both off the hand           -> dataset is self-consistent
    but the upstream convention needs fixing.

Both adapters expose the same debug keys (window_indices, K, R_w_c_win,
t_w_c_win, R_w_c_ref/t_w_c_ref, {left,right}_wrist_world_win,
{left,right}_valid_win, action, state, action_valid_mask, video_path), so the
projection/rendering code below is shared.

Run (on the training cluster, where the data lives):

    python tools/visualize_new_human_unified_eef.py \
        --dataset openaoe \
        --data-root /path/to/inclusionAI-OpenAoE-2000h \
        --output-dir outputs/openaoe_unified_eef_vis \
        --num-samples 12 --seed 0

    python tools/visualize_new_human_unified_eef.py \
        --dataset egoverse \
        --data-root /path/to/EgoVerse \
        --output-dir outputs/egoverse_unified_eef_vis \
        --num-samples 12 --seed 0
"""

import argparse
import json
import logging
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import cv2
import numpy as np

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from data.utils.image_utils import resize_with_padding  # noqa: E402

logging.basicConfig(level=logging.INFO, format="[%(levelname)s] %(message)s")
logger = logging.getLogger("viz_new_human_eef")

LEFT_T = slice(0, 3)
RIGHT_T = slice(8, 11)

C_GT = (0, 220, 0)        # green : GT_DIRECT
C_DATASET = (0, 0, 255)   # red   : dataset reconstruction
C_HIST = (0, 200, 200)
C_FUT = (255, 180, 0)
C_TXT = (255, 255, 255)


# --------------------------------------------------------------------------- #
# Geometry
# --------------------------------------------------------------------------- #
def project_pinhole(p_cam: np.ndarray, K: np.ndarray) -> Tuple[Optional[np.ndarray], float]:
    """OpenCV pinhole projection (+Z forward). K is 3x3."""
    z = float(p_cam[2])
    if z <= 1e-6:
        return None, z
    u = K[0, 0] * p_cam[0] / z + K[0, 2]
    v = K[1, 1] * p_cam[1] / z + K[1, 2]
    return np.array([u, v]), z


def world_to_cam(p_world: np.ndarray, R_w_c: np.ndarray, t_w_c: np.ndarray) -> np.ndarray:
    """World point -> camera frame, given a camera->world pose."""
    return R_w_c.T @ (p_world - t_w_c)


def reconstruct_dataset_anchor(state: np.ndarray, action: np.ndarray) -> Dict[str, np.ndarray]:
    """Absolute wrist positions in the anchor (frame-0) camera frame.

    p(0) = state, p(i+1) = state + action[i]  (anchor-based unified EEF).
    """
    F = action.shape[0]
    left = np.zeros((F + 1, 3))
    right = np.zeros((F + 1, 3))
    left[0] = state[LEFT_T]
    right[0] = state[RIGHT_T]
    for i in range(F):
        left[i + 1] = state[LEFT_T] + action[i][LEFT_T]
        right[i + 1] = state[RIGHT_T] + action[i][RIGHT_T]
    return {"left": left, "right": right}


def compute_projections(sample: Dict[str, Any], img_wh: Tuple[int, int]) -> Dict[str, Any]:
    W = sample["num_video_frames"] + 1
    K = sample["K"]
    img_w, img_h = img_wh
    R_w_c_win = sample["R_w_c_win"]
    t_w_c_win = sample["t_w_c_win"]
    R_ref, t_ref = sample["R_w_c_ref"], sample["t_w_c_ref"]

    has_ds = sample["action"] is not None and sample["state"] is not None and R_ref is not None
    ds_anchor = reconstruct_dataset_anchor(sample["state"], sample["action"]) if has_ds else None
    amask = sample.get("action_valid_mask")

    out: Dict[str, Any] = {"hands": {}}
    for hand, wkey, vkey, dim0 in (
        ("left", "left_wrist_world_win", "left_valid_win", 0),
        ("right", "right_wrist_world_win", "right_valid_win", 8),
    ):
        wpos = sample[wkey]
        valid = np.asarray(sample[vkey], dtype=bool) if sample[vkey] is not None else np.zeros(W, bool)

        # Frames the dataset actually supervises: j=0 is the anchor/state,
        # j>=1 comes from action_valid_mask[j-1, dim0].
        ds_valid = np.zeros(W, dtype=bool)
        if has_ds:
            ds_valid[0] = bool(valid[0])
            if amask is not None:
                for j in range(1, W):
                    ds_valid[j] = bool(amask[j - 1, dim0])

        gt_px = np.full((W, 2), np.nan); gt_z = np.full(W, np.nan); gt_status = ["missing"] * W
        ds_px = np.full((W, 2), np.nan); ds_z = np.full(W, np.nan); ds_status = ["missing"] * W

        for j in range(W):
            if wpos is not None and bool(valid[j]) and np.all(np.isfinite(wpos[j])) \
                    and np.all(np.isfinite(R_w_c_win[j])):
                px, z = project_pinhole(world_to_cam(wpos[j], R_w_c_win[j], t_w_c_win[j]), K)
                gt_z[j] = z
                if px is None:
                    gt_status[j] = "behind(z<=0)"
                else:
                    gt_px[j] = px
                    gt_status[j] = "ok" if (0 <= px[0] < img_w and 0 <= px[1] < img_h) else "out_of_frame"
            if has_ds and np.all(np.isfinite(R_w_c_win[j])):
                p_world = R_ref @ ds_anchor[hand][j] + t_ref
                px, z = project_pinhole(world_to_cam(p_world, R_w_c_win[j], t_w_c_win[j]), K)
                ds_z[j] = z
                if not ds_valid[j]:
                    ds_status[j] = "masked(not supervised)"
                elif px is None:
                    ds_status[j] = "behind(z<=0)"
                else:
                    ds_px[j] = px
                    ds_status[j] = "ok" if (0 <= px[0] < img_w and 0 <= px[1] < img_h) else "out_of_frame"

        out["hands"][hand] = {
            "world_pos": wpos, "valid": valid, "ds_valid": ds_valid,
            "dataset_anchor": None if ds_anchor is None else ds_anchor[hand],
            "gt_px": gt_px, "gt_z": gt_z, "gt_status": gt_status,
            "ds_px": ds_px, "ds_z": ds_z, "ds_status": ds_status,
        }
    return out


# --------------------------------------------------------------------------- #
# Rendering
# --------------------------------------------------------------------------- #
def load_native_frames(video_path: str, indices: List[int]) -> np.ndarray:
    import decord
    vr = decord.VideoReader(str(video_path), num_threads=2)
    n = len(vr)
    safe = [min(max(int(i), 0), n - 1) for i in indices]
    batch = vr.get_batch(safe).asnumpy()
    if batch.shape[-1] == 4:
        batch = batch[..., :3]
    return batch.astype(np.uint8)


def resize_with_padding_transform(orig_hw, target_hw):
    oh, ow = orig_hw
    th, tw = target_hw
    scale = min(th / oh, tw / ow)
    return scale, float((tw - int(ow * scale)) // 2), float((th - int(oh * scale)) // 2)


def _map_px(px, view, tf):
    if px is None or not np.all(np.isfinite(px)):
        return None
    if view == "processed":
        scale, xo, yo = tf
        return int(round(px[0] * scale + xo)), int(round(px[1] * scale + yo))
    return int(round(px[0])), int(round(px[1]))


def _fmt_px(px):
    return "--" if (px is None or not np.all(np.isfinite(px))) else f"({px[0]:.0f},{px[1]:.0f})"


def _polyline(img, pts, color, th, dashed=False):
    pts = [p for p in pts if p is not None]
    for a, b in zip(pts[:-1], pts[1:]):
        if dashed:
            mid = ((a[0] + b[0]) // 2, (a[1] + b[1]) // 2)
            cv2.line(img, a, mid, color, th, cv2.LINE_AA)
        else:
            cv2.line(img, a, b, color, th, cv2.LINE_AA)


def _safe_circle(img, p, r, color, filled=True, label=None):
    h, w = img.shape[:2]
    x, y = p
    if 0 <= x < w and 0 <= y < h:
        cv2.circle(img, (x, y), r, color, -1 if filled else 2, cv2.LINE_AA)
        if label:
            cv2.putText(img, label, (x + 5, y - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1, cv2.LINE_AA)
    else:
        cx, cy = max(4, min(w - 5, x)), max(4, min(h - 5, y))
        cv2.circle(img, (cx, cy), 4, color, 2, cv2.LINE_AA)
        cv2.putText(img, "OOF", (cx + 5, cy), cv2.FONT_HERSHEY_SIMPLEX, 0.4, color, 1, cv2.LINE_AA)


def render_overlay(sample, proj, view, draw_history, draw_future, future_horizon):
    W = sample["num_video_frames"] + 1
    idxs = sample["window_indices"].tolist()
    native = load_native_frames(sample["video_path"], idxs)
    raw_hw = (native.shape[1], native.shape[2])
    target_hw = (384, 320)
    tf = resize_with_padding_transform(raw_hw, target_hw)
    K = sample["K"]

    frames_out = []
    hand_colors = {"left": (255, 128, 0), "right": (0, 128, 255)}
    for j in range(W):
        img = (cv2.cvtColor(resize_with_padding(native[j], target_hw), cv2.COLOR_RGB2BGR).copy()
               if view == "processed" else cv2.cvtColor(native[j], cv2.COLOR_RGB2BGR).copy())
        panel = np.zeros((img.shape[0], 430, 3), dtype=np.uint8)
        y = 20

        def put(txt, col=C_TXT, dy=18):
            nonlocal y
            cv2.putText(panel, txt, (6, y), cv2.FONT_HERSHEY_SIMPLEX, 0.44, col, 1, cv2.LINE_AA)
            y += dy

        put(f"{sample.get('sample_id', '')}", (200, 255, 200))
        put(f"view={view} raw={raw_hw[1]}x{raw_hw[0]} stride={sample['frame_stride']}", (180, 220, 255))
        put(f"win_idx(j)={j}  clip_start={idxs[0]}  frame={idxs[j]}")
        put(f"K=[{K[0,0]:.0f},{K[1,1]:.0f},{K[0,2]:.0f},{K[1,2]:.0f}]", (150, 200, 150))
        put("GREEN=GT  RED=dataset", (0, 255, 255))
        for hand in ("left", "right"):
            hd = proj["hands"][hand]
            col = hand_colors[hand]
            put(f"[{hand}] valid={bool(hd['valid'][j])}", col, 16)
            put(f"  GT z={hd['gt_z'][j]:.3f} px={_fmt_px(hd['gt_px'][j])} {hd['gt_status'][j]}", C_GT, 16)
            put(f"  DS z={hd['ds_z'][j]:.3f} px={_fmt_px(hd['ds_px'][j])} {hd['ds_status'][j]}", C_DATASET, 18)
            if draw_history and j > 0:
                _polyline(img, [_map_px(hd["gt_px"][k], view, tf) for k in range(j + 1)], C_HIST, 1)
            if draw_future:
                hi = min(W, j + 1 + future_horizon)
                _polyline(img, [_map_px(hd["gt_px"][k], view, tf) for k in range(j, hi)], C_FUT, 1, dashed=True)
            if bool(hd["valid"][j]):
                p_gt = _map_px(hd["gt_px"][j], view, tf)
                if p_gt is not None:
                    _safe_circle(img, p_gt, 7, C_GT, True, hand[0].upper())
            if bool(hd["ds_valid"][j]):
                p_ds = _map_px(hd["ds_px"][j], view, tf)
                if p_ds is not None:
                    _safe_circle(img, p_ds, 6, C_DATASET, False)
        frames_out.append(np.hstack([img, panel]))
    return frames_out


def write_video(frames, path, fps):
    if not frames:
        return
    h, w = frames[0].shape[:2]
    vw = cv2.VideoWriter(path, cv2.VideoWriter_fourcc(*"mp4v"), fps, (w, h))
    for f in frames:
        vw.write(f)
    vw.release()


# --------------------------------------------------------------------------- #
# Numerical checks
# --------------------------------------------------------------------------- #
def numerical_checks(sample, proj):
    W = sample["num_video_frames"] + 1
    checks: Dict[str, Any] = {
        "time_alignment_ok": True,
        "window_indices": sample["window_indices"].tolist(),
        "frame_stride": int(sample["frame_stride"]),
    }
    R_w_c_win, t_w_c_win = sample["R_w_c_win"], sample["t_w_c_win"]
    R_ref, t_ref = sample["R_w_c_ref"], sample["t_w_c_ref"]

    # dataset-vs-GT pixel agreement over supervised frames (~0 when correct)
    px_err = []
    for hand in ("left", "right"):
        hd = proj["hands"][hand]
        for j in range(W):
            a, b = hd["gt_px"][j], hd["ds_px"][j]
            if np.all(np.isfinite(a)) and np.all(np.isfinite(b)):
                px_err.append(float(np.linalg.norm(a - b)))
    checks["dataset_vs_gt_pixel_max"] = float(np.max(px_err)) if px_err else None
    checks["dataset_vs_gt_pixel_mean"] = float(np.mean(px_err)) if px_err else None

    # world-space reconstruction error over supervised frames
    rt = []
    if sample["action"] is not None and R_ref is not None:
        ds_anchor = reconstruct_dataset_anchor(sample["state"], sample["action"])
        for hand in ("left", "right"):
            hd = proj["hands"][hand]
            if hd["world_pos"] is None:
                continue
            for j in range(W):
                if not (bool(hd["valid"][j]) and bool(hd["ds_valid"][j])):
                    continue
                p_world = R_ref @ ds_anchor[hand][j] + t_ref
                rt.append(float(np.linalg.norm(p_world - hd["world_pos"][j])))
    checks["dataset_world_recon_max_err"] = float(np.max(rt)) if rt else None
    checks["dataset_world_recon_mean_err"] = float(np.mean(rt)) if rt else None

    # unit / range sanity (metres, radians)
    stats = {}
    for hand in ("left", "right"):
        hd = proj["hands"][hand]
        if hd["world_pos"] is None:
            continue
        cam = np.array([world_to_cam(hd["world_pos"][t], R_w_c_win[t], t_w_c_win[t]) for t in range(W)])
        v = cam[hd["valid"]]
        if len(v):
            disp = np.linalg.norm(np.diff(v, axis=0), axis=1) if len(v) > 1 else np.array([0.0])
            stats[hand] = {
                "cam_min": v.min(0).tolist(), "cam_max": v.max(0).tolist(),
                "depth_min": float(v[:, 2].min()), "depth_max": float(v[:, 2].max()),
                "step_disp_mean": float(disp.mean()), "step_disp_max": float(disp.max()),
            }
    checks["hand_cam_stats"] = stats
    cam_t = t_w_c_win[np.all(np.isfinite(t_w_c_win), axis=1)]
    if len(cam_t) > 1:
        checks["camera_translation_range"] = (cam_t.max(0) - cam_t.min(0)).tolist()

    quant = {}
    for hand in ("left", "right"):
        hd = proj["hands"][hand]
        n = int(np.sum(hd["valid"]))
        nds = int(np.sum(hd["ds_valid"]))
        if n == 0:
            continue
        gt_ok = sum(1 for j in range(W) if hd["valid"][j] and hd["gt_status"][j] == "ok")
        gt_behind = sum(1 for j in range(W) if hd["valid"][j] and hd["gt_status"][j] == "behind(z<=0)")
        ds_ok = sum(1 for j in range(W) if hd["ds_valid"][j] and hd["ds_status"][j] == "ok")
        ds_behind = sum(1 for j in range(W) if hd["ds_valid"][j] and hd["ds_status"][j] == "behind(z<=0)")
        quant[hand] = {
            "n_gt_valid": n, "n_dataset_supervised": nds,
            "gt_direct_inframe_frac": gt_ok / n,
            "gt_direct_behind_frac": gt_behind / n,
            "dataset_inframe_frac": (ds_ok / nds) if nds else None,
            "dataset_behind_frac": (ds_behind / nds) if nds else None,
        }
    checks["projection_quality"] = quant
    return checks


def build_debug_json(sample, proj, checks):
    def arr(x):
        return None if x is None else np.asarray(x).tolist()
    d = {
        "sample_id": sample.get("sample_id"),
        "episode_index": sample["episode_index"],
        "frame_start": sample["frame_start"],
        "video_path": sample["video_path"],
        "clip_start": int(sample["window_indices"][0]),
        "clip_end": int(sample["window_indices"][-1]),
        "selected_frame_indices": sample["window_indices"].tolist(),
        "instruction": sample.get("instruction", ""),
        "extraction_error": sample["error"],
        "camera_intrinsics": arr(sample["K"]),
        "reference_camera_R_w_c": arr(sample["R_w_c_ref"]),
        "reference_camera_t_w_c": arr(sample["t_w_c_ref"]),
        "per_frame_R_w_c": arr(sample["R_w_c_win"]),
        "per_frame_t_w_c": arr(sample["t_w_c_win"]),
        "state": arr(sample["state"]),
        "action": arr(sample["action"]),
        "action_valid_mask": arr(sample["action_valid_mask"]),
        "hands": {}, "checks": checks,
    }
    for hand in ("left", "right"):
        hd = proj["hands"][hand]
        d["hands"][hand] = {
            "world_wrist_trajectory": arr(hd["world_pos"]),
            "dataset_anchor_trajectory": arr(hd["dataset_anchor"]),
            "valid_mask": arr(hd["valid"]),
            "dataset_supervised_mask": arr(hd["ds_valid"]),
            "gt_direct_pixels": arr(hd["gt_px"]), "gt_direct_depth": arr(hd["gt_z"]),
            "gt_direct_status": hd["gt_status"],
            "dataset_pixels": arr(hd["ds_px"]), "dataset_depth": arr(hd["ds_z"]),
            "dataset_status": hd["ds_status"],
        }
    return d


def classify_sample(sample, proj):
    tags = []
    lv = np.asarray(sample["left_valid_win"], bool) if sample["left_valid_win"] is not None else np.zeros(1, bool)
    rv = np.asarray(sample["right_valid_win"], bool) if sample["right_valid_win"] is not None else np.zeros(1, bool)
    if lv.any() and not rv.any(): tags.append("left_only")
    if rv.any() and not lv.any(): tags.append("right_only")
    if lv.any() and rv.any(): tags.append("both_hands")
    if not lv.all() or not rv.all(): tags.append("has_invalid")
    t = sample["t_w_c_win"]
    if t is not None and np.linalg.norm(t.max(0) - t.min(0)) > 0.1:
        tags.append("camera_motion")
    for hand in ("left", "right"):
        hd = proj["hands"][hand]
        n = int(np.sum(hd["valid"]))
        if not n:
            continue
        oob = sum(1 for j in range(len(hd["gt_status"])) if hd["valid"][j] and hd["gt_status"][j] == "out_of_frame")
        behind = sum(1 for j in range(len(hd["gt_status"])) if hd["valid"][j] and hd["gt_status"][j] == "behind(z<=0)")
        if oob / n > 0.3: tags.append("high_oob")
        if behind / n > 0.1: tags.append("neg_depth")
    return sorted(set(tags))


# --------------------------------------------------------------------------- #
# Dataset construction
# --------------------------------------------------------------------------- #
def build_dataset(args):
    common = dict(dataset_dir=args.data_root, num_video_frames=args.num_video_frames,
                  video_size=(384, 320), action_mode="unified_eef_camera_delta_wrist16",
                  frame_stride=args.frame_stride, vlm_checkpoint_path=None, t5_mode="none",
                  max_episodes=args.max_episodes)
    if args.dataset == "egoverse":
        from data.egoverse.egoverse_dataset import EgoVerseMotusDataset
        return EgoVerseMotusDataset(
            subset=args.subset, hand_pose_key=args.hand_pose_key,
            quat_order=args.quat_order, video_source=args.video_source or "mp4",
            pose_cache_dir=args.pose_cache_dir, **common)
    from data.openaoe.openaoe_dataset import OpenAoEMotusDataset
    return OpenAoEMotusDataset(video_source=args.video_source or "undistorted", **common)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--dataset", choices=["egoverse", "openaoe"], required=True)
    ap.add_argument("--data-root", required=True)
    ap.add_argument("--output-dir", required=True)
    ap.add_argument("--num-samples", type=int, default=12)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--episode-index", type=int, default=None)
    ap.add_argument("--frame-start", type=int, default=None)
    ap.add_argument("--num-video-frames", type=int, default=8)
    ap.add_argument("--frame-stride", type=int, default=1)
    ap.add_argument("--max-episodes", type=int, default=None)
    ap.add_argument("--fps", type=int, default=4)
    ap.add_argument("--future-horizon", type=int, default=4)
    ap.add_argument("--no-history", action="store_true")
    ap.add_argument("--no-future", action="store_true")
    ap.add_argument("--view", choices=["original", "processed", "both"], default="both")
    ap.add_argument("--no-video", action="store_true")
    # EgoVerse-specific convention switches (see the verification prompt doc)
    ap.add_argument("--subset", default="aria")
    ap.add_argument("--hand-pose-key", default="obs_wrist_pose",
                    choices=["obs_wrist_pose", "obs_ee_pose"])
    # VERIFIED on real ARIA data: obs_*_pose quaternions are scalar-first.
    ap.add_argument("--quat-order", default="wxyz", choices=["xyzw", "wxyz"])
    ap.add_argument("--pose-cache-dir", default=None,
                    help="egoverse: dir of .npz pose sidecars from prepare_egoverse_pose_cache.py")
    ap.add_argument("--video-source", default=None,
                    help="egoverse: mp4|zarr (default mp4); openaoe: undistorted|raw (default undistorted)")
    args = ap.parse_args()

    out_root = Path(args.output_dir); out_root.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(args.seed)

    logger.info(f"Building {args.dataset} dataset from {args.data_root} ...")
    ds = build_dataset(args)
    logger.info(f"{args.dataset}: {len(ds)} episodes")

    if args.episode_index is not None and args.frame_start is not None:
        selection = [(args.episode_index, args.frame_start)]
    else:
        F = args.num_video_frames
        need = F * args.frame_stride + 1
        cands = []
        for ei, ep in enumerate(ds.episodes):
            hi = int(ep["n_frames"]) - need
            if hi <= 0:
                continue
            for s in np.linspace(0, hi, 6).astype(int):
                cands.append((ei, int(s)))
        if not cands:
            raise RuntimeError("no candidate windows; episodes too short for this stride")
        order = rng.permutation(len(cands))
        selection = [cands[i] for i in order[: max(args.num_samples * 3, args.num_samples)]]

    views = ["original", "processed"] if args.view == "both" else [args.view]
    summary: Dict[str, Any] = {"dataset": args.dataset, "data_root": args.data_root,
                               "samples": [], "aggregate": {}}
    agg = {"left": [], "right": []}
    seen_tags: Dict[str, int] = {}
    produced = 0

    for ei, fs in selection:
        if produced >= args.num_samples:
            break
        try:
            sample = ds.get_debug_sample(ei, fs, load_video=False)
        except Exception as e:
            logger.warning(f"get_debug_sample({ei},{fs}) failed: {e}")
            continue
        if sample.get("error") or sample["K"] is None or sample["R_w_c_win"] is None:
            logger.info(f"skip ep{ei} f{fs}: {sample.get('error') or 'missing camera/intrinsics'}")
            continue

        sample["sample_id"] = f"sample_{produced:06d}_ep{ei}_f{fs}"
        # image size from the intrinsics' principal point (both datasets publish
        # a centred principal point for their released videos)
        img_wh = (int(round(2 * sample["K"][0, 2])), int(round(2 * sample["K"][1, 2])))
        proj = compute_projections(sample, img_wh)
        tags = classify_sample(sample, proj)
        checks = numerical_checks(sample, proj)
        for hand in ("left", "right"):
            if hand in checks.get("projection_quality", {}):
                agg[hand].append(checks["projection_quality"][hand])
        for t in tags:
            seen_tags[t] = seen_tags.get(t, 0) + 1

        sdir = out_root / sample["sample_id"]; sdir.mkdir(parents=True, exist_ok=True)
        (sdir / "debug.json").write_text(json.dumps(build_debug_json(sample, proj, checks), indent=2))
        (sdir / "sample_metadata.json").write_text(json.dumps({
            "sample_id": sample["sample_id"], "episode_index": ei, "frame_start": fs,
            "instruction": sample.get("instruction", ""), "tags": tags,
            "episode_name": sample.get("episode_name") or sample.get("sample_name"),
            "extraction_error": sample.get("error"),
        }, indent=2))

        vids = {}
        if not args.no_video:
            preview = False
            for view in views:
                try:
                    frames = render_overlay(sample, proj, view, not args.no_history,
                                            not args.no_future, args.future_horizon)
                except Exception as e:
                    logger.warning(f"render {sample['sample_id']} view={view} failed: {e}")
                    continue
                vp = sdir / f"overlay_{view}.mp4"
                write_video(frames, str(vp), args.fps)
                vids[view] = str(vp)
                if not preview and frames:
                    cv2.imwrite(str(sdir / "preview.png"), frames[len(frames) // 2]); preview = True

        summary["samples"].append({
            "sample_id": sample["sample_id"], "tags": tags, "videos": vids,
            "projection_quality": checks.get("projection_quality", {}),
            "dataset_vs_gt_pixel_max": checks.get("dataset_vs_gt_pixel_max"),
            "dataset_world_recon_max_err": checks.get("dataset_world_recon_max_err"),
        })
        produced += 1
        logger.info(f"[{produced}/{args.num_samples}] {sample['sample_id']} tags={tags} "
                    f"px_match_max={checks.get('dataset_vs_gt_pixel_max')}")

    def _agg(lst, field):
        vals = [d[field] for d in lst if d.get(field) is not None]
        return ({"mean": float(np.mean(vals)), "min": float(np.min(vals)),
                 "max": float(np.max(vals)), "n": len(vals)} if vals else None)
    for hand in ("left", "right"):
        summary["aggregate"][hand] = {
            k: _agg(agg[hand], k) for k in
            ("gt_direct_inframe_frac", "gt_direct_behind_frac",
             "dataset_inframe_frac", "dataset_behind_frac")
        }
    summary["tag_counts"] = seen_tags
    (out_root / "summary.json").write_text(json.dumps(summary, indent=2))
    logger.info(f"Done. Produced {produced} samples -> {out_root}")
    logger.info("Interpretation: dataset_vs_gt_pixel_max ~0 => dataset matches GT; "
                "gt_direct_behind_frac ~1 => the raw pose/camera convention assumption is wrong.")


if __name__ == "__main__":
    main()

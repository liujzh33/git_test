#!/usr/bin/env python3
"""
visualize_vitra_unified_eef.py
==============================

Correctness-audit tool for the VITRA ``unified_eef_camera_delta_wrist16``
pipeline, mirroring the Xperience / EgoDex tools.

Reuses VITRA's exact training extraction (``VitraHumanMotusDataset`` +
``data/human/unified_eef_action.py``) via the non-invasive
``VitraHumanMotusDataset.get_debug_sample`` method, then re-projects the wrist
trajectory back onto the video.

Two trajectories are projected onto every frame:

  GT_DIRECT (green) : raw world-frame wrist position projected via the per-frame
                      World2Cam extrinsics + intrinsics.
  DATASET   (red)   : trajectory reconstructed from the dataset's own state +
                      action tensors, re-projected under the dataset's semantics.

VITRA data model (verified OpenCV +Z convention):
    extrinsics[t]              : World2Cam SE(3) (p_cam = R_w2c @ p_world + t_w2c).
    transl/global_orient_worldspace : world-frame wrist pose.
    intrinsics                 : (3,3) pinhole K for the canonical (2*cx x 2*cy) image.

For a CORRECT implementation the red dots coincide with the green dots and both
track the hand (subject to VITRA's ~90% monocular reconstruction accuracy).

Run:
    python tools/visualize_vitra_unified_eef.py \
        --data-root /home/work/wenjj/data/vitra_data_root --dataset-name ssv2 \
        --output-dir /home/work/wenjj/MotusV2/outputs/vitra_unified_eef_vis \
        --num-samples 12 --seed 0
"""

import argparse
import json
import logging
import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import cv2
import numpy as np

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from data.human.vitra_dataset import VitraHumanMotusDataset  # noqa: E402
from data.human.vitra_core import load_video_decord  # noqa: E402
from data.utils.image_utils import resize_with_padding  # noqa: E402

logging.basicConfig(level=logging.INFO, format="[%(levelname)s] %(message)s")
logger = logging.getLogger("viz_vitra_eef")

LEFT_T = slice(0, 3)
RIGHT_T = slice(8, 11)

C_GT = (0, 220, 0)
C_DATASET = (0, 0, 255)
C_HIST = (0, 200, 200)
C_FUT = (255, 180, 0)
C_TXT = (255, 255, 255)


def project_pinhole(p_cam: np.ndarray, K: np.ndarray) -> Tuple[Optional[np.ndarray], float]:
    z = float(p_cam[2])
    if z <= 1e-6:
        return None, z
    u = K[0, 0] * p_cam[0] / z + K[0, 2]
    v = K[1, 1] * p_cam[1] / z + K[1, 2]
    return np.array([u, v]), z


def world_to_cam_w2c(p_world, R_w2c, t_w2c):
    """VITRA World2Cam: p_cam = R_w2c @ p_world + t_w2c."""
    return R_w2c @ p_world + t_w2c


def resize_with_padding_transform(orig_hw, target_hw):
    oh, ow = orig_hw
    th, tw = target_hw
    scale = min(th / oh, tw / ow)
    return scale, float((tw - int(ow * scale)) // 2), float((th - int(oh * scale)) // 2)


def load_raw_frames(sample: Dict[str, Any]) -> np.ndarray:
    """Load the window's raw frames (native resolution) honoring clip_len parts."""
    video_root = sample["video_root"]
    prefix = sample["dataset_prefix"]
    video_name = sample["video_name"]
    clip_len = sample["clip_len"]
    decode_ids = sample["decode_ids"].tolist()

    def resolve(part_idx):
        if prefix in ("Ego4D", "EgoExo4D"):
            suf = f"_part{part_idx + 1}.mp4" if clip_len is not None else ".mp4"
        elif prefix == "epic":
            suf = f"_part{part_idx + 1}.mp4" if clip_len is not None else ".MP4"
        else:  # somethingsomethingv2
            suf = f"_part{part_idx + 1}.mp4" if clip_len is not None else ".webm"
        return os.path.join(video_root, video_name + suf)

    images: List[Optional[np.ndarray]] = [None] * len(decode_ids)
    part_to_local: Dict[int, List[Tuple[int, int]]] = {}
    for pos, full_idx in enumerate(decode_ids):
        if clip_len is None:
            part_idx, fip = 0, int(full_idx)
        else:
            part_idx, fip = int(full_idx) // int(clip_len), int(full_idx) % int(clip_len)
        part_to_local.setdefault(part_idx, []).append((pos, fip))
    for part_idx, pairs in part_to_local.items():
        vp = resolve(part_idx)
        imgs, _ = load_video_decord(vp, frame_index=[p[1] for p in pairs], rotation=False)
        for (pos, _), img in zip(pairs, imgs):
            images[pos] = img
    return np.stack(images, axis=0).astype(np.uint8)


def reconstruct_dataset_anchor(state, action):
    F = action.shape[0]
    left = np.zeros((F + 1, 3)); right = np.zeros((F + 1, 3))
    left[0] = state[LEFT_T]; right[0] = state[RIGHT_T]
    for i in range(F):
        left[i + 1] = state[LEFT_T] + action[i][LEFT_T]
        right[i + 1] = state[RIGHT_T] + action[i][RIGHT_T]
    return {"left": left, "right": right}


def compute_projections(sample: Dict[str, Any]) -> Dict[str, Any]:
    W = sample["num_video_frames"] + 1
    K = sample["K"]
    Wc, Hc = int(round(2 * K[0, 2])), int(round(2 * K[1, 2]))
    R_w2c = sample["R_w2c_win"]; t_w2c = sample["t_w2c_win"]
    has_ds = sample["action"] is not None and sample["state"] is not None
    R_ref = sample["R_w_c_ref"]; t_ref = sample["t_w_c_ref"]
    ds_anchor = reconstruct_dataset_anchor(sample["state"], sample["action"]) if (has_ds and R_ref is not None) else None

    amask = sample["action_valid_mask"]  # (F,16) or None
    out = {"canonical_wh": (Wc, Hc), "hands": {}}
    for hand, wpos_key, valid_key, dim0 in [
        ("left", "left_wrist_world_win", "left_valid_win", 0),
        ("right", "right_wrist_world_win", "right_valid_win", 8),
    ]:
        wpos = sample[wpos_key]; valid = sample[valid_key]
        gt_px = np.full((W, 2), np.nan); gt_z = np.full((W,), np.nan); gt_status = ["missing"] * W
        ds_px = np.full((W, 2), np.nan); ds_z = np.full((W,), np.nan); ds_status = ["missing"] * W
        # dataset supervision mask per window frame:
        #   j==0 -> the anchor/state (valid if this hand is valid at the anchor)
        #   j>=1 -> action_valid_mask[j-1, dim0]
        ds_valid = np.zeros(W, dtype=bool)
        if ds_anchor is not None:
            ds_valid[0] = bool(valid[0])
            if amask is not None:
                for j in range(1, W):
                    ds_valid[j] = bool(amask[j - 1, dim0])
        for j in range(W):
            if bool(valid[j]) and np.all(np.isfinite(wpos[j])):
                pc = world_to_cam_w2c(wpos[j], R_w2c[j], t_w2c[j])
                px, z = project_pinhole(pc, K); gt_z[j] = z
                if px is None:
                    gt_status[j] = "behind(z<=0)"
                else:
                    gt_px[j] = px
                    gt_status[j] = "ok" if (0 <= px[0] < Wc and 0 <= px[1] < Hc) else "out_of_frame"
            if ds_anchor is not None:
                p_world = R_ref @ ds_anchor[hand][j] + t_ref
                pc = world_to_cam_w2c(p_world, R_w2c[j], t_w2c[j])
                px, z = project_pinhole(pc, K); ds_z[j] = z
                if not ds_valid[j]:
                    ds_status[j] = "masked(not supervised)"
                elif px is None:
                    ds_status[j] = "behind(z<=0)"
                else:
                    ds_px[j] = px
                    ds_status[j] = "ok" if (0 <= px[0] < Wc and 0 <= px[1] < Hc) else "out_of_frame"
        out["hands"][hand] = {
            "world_pos": wpos, "valid": valid.astype(bool), "ds_valid": ds_valid,
            "dataset_anchor": None if ds_anchor is None else ds_anchor[hand],
            "gt_px": gt_px, "gt_z": gt_z, "gt_status": gt_status,
            "ds_px": ds_px, "ds_z": ds_z, "ds_status": ds_status,
        }
    return out


def _map_px(px, view, canon_wh, raw_hw, tf):
    if px is None or not np.all(np.isfinite(px)):
        return None
    Wc, Hc = canon_wh
    if view == "processed":
        # canonical -> raw -> padded(384x320)
        rh, rw = raw_hw
        u = px[0] * rw / Wc
        v = px[1] * rh / Hc
        scale, xo, yo = tf
        return int(round(u * scale + xo)), int(round(v * scale + yo))
    return int(round(px[0])), int(round(px[1]))


def _fmt_px(px):
    return "--" if (px is None or not np.all(np.isfinite(px))) else f"({px[0]:.0f},{px[1]:.0f})"


def _polyline(img, pts, color, th, dashed=False):
    pts = [p for p in pts if p is not None]
    for a, b in zip(pts[:-1], pts[1:]):
        if dashed:
            mid = ((a[0] + b[0]) // 2, (a[1] + b[1]) // 2)
            cv2.line(img, a, mid, color, th, cv2.LINE_AA)
        else:
            cv2.line(img, a, b, color, th, cv2.LINE_AA)


def _safe_circle(img, p, r, color, filled=True, label=None):
    H, Wpx = img.shape[:2]
    x, y = p
    if 0 <= x < Wpx and 0 <= y < H:
        cv2.circle(img, (x, y), r, color, -1 if filled else 2, cv2.LINE_AA)
        if label:
            cv2.putText(img, label, (x + 5, y - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1, cv2.LINE_AA)
    else:
        cx, cy = max(4, min(Wpx - 5, x)), max(4, min(H - 5, y))
        cv2.circle(img, (cx, cy), 4, color, 2, cv2.LINE_AA)
        cv2.putText(img, "OOF", (cx + 5, cy), cv2.FONT_HERSHEY_SIMPLEX, 0.4, color, 1, cv2.LINE_AA)


def render_overlay(sample, proj, view, draw_history, draw_future, future_horizon):
    W = sample["num_video_frames"] + 1
    raw = load_raw_frames(sample)               # (W, rh, rw, 3)
    raw_hw = (raw.shape[1], raw.shape[2])
    Wc, Hc = proj["canonical_wh"]
    target_hw = (384, 320)
    tf = resize_with_padding_transform(raw_hw, target_hw)
    idxs = sample["window_indices"].tolist()
    decode_ids = sample["decode_ids"].tolist()

    frames_out = []
    hand_colors = {"left": (255, 128, 0), "right": (0, 128, 255)}
    for j in range(W):
        if view == "processed":
            img = cv2.cvtColor(resize_with_padding(raw[j], target_hw), cv2.COLOR_RGB2BGR).copy()
        else:  # original == canonical intrinsic resolution
            img = cv2.cvtColor(cv2.resize(raw[j], (Wc, Hc)), cv2.COLOR_RGB2BGR).copy()
        ph = img.shape[0]
        panel = np.zeros((ph, 430, 3), dtype=np.uint8)
        y = 20

        def put(txt, col=C_TXT, dy=18):
            nonlocal y
            cv2.putText(panel, txt, (6, y), cv2.FONT_HERSHEY_SIMPLEX, 0.44, col, 1, cv2.LINE_AA)
            y += dy

        put(f"ep={sample['episode_id']}", (200, 255, 200))
        put(f"view={view} canon={Wc}x{Hc} raw={raw_hw[1]}x{raw_hw[0]}", (180, 220, 255))
        put(f"win_idx(j)={j} epi_frame={idxs[j]} raw_frame={decode_ids[j]}")
        put(f"K=[{K_str(sample['K'])}]  anno={sample['anno_type']}", (150, 200, 150))
        put("GREEN=GT  RED=dataset", (0, 255, 255))
        for hand in ("left", "right"):
            hd = proj["hands"][hand]; col = hand_colors[hand]
            put(f"[{hand}] valid={bool(hd['valid'][j])}", col, 16)
            put(f"  GT z={hd['gt_z'][j]:.3f} px={_fmt_px(hd['gt_px'][j])} {hd['gt_status'][j]}", C_GT, 16)
            put(f"  DS z={hd['ds_z'][j]:.3f} px={_fmt_px(hd['ds_px'][j])} {hd['ds_status'][j]}", C_DATASET, 18)
            if draw_history and j > 0:
                _polyline(img, [_map_px(hd["gt_px"][k], view, (Wc, Hc), raw_hw, tf) for k in range(j + 1)], C_HIST, 1)
            if draw_future:
                hi = min(W, j + 1 + future_horizon)
                _polyline(img, [_map_px(hd["gt_px"][k], view, (Wc, Hc), raw_hw, tf) for k in range(j, hi)], C_FUT, 1, dashed=True)
            if bool(hd["valid"][j]):
                p_gt = _map_px(hd["gt_px"][j], view, (Wc, Hc), raw_hw, tf)
                if p_gt is not None:
                    _safe_circle(img, p_gt, 6, C_GT, True, hand[0].upper())
                p_ds = _map_px(hd["ds_px"][j], view, (Wc, Hc), raw_hw, tf)
                if p_ds is not None:
                    _safe_circle(img, p_ds, 5, C_DATASET, False)
        frames_out.append(np.hstack([img, panel]))
    return frames_out


def K_str(K):
    return f"{K[0,0]:.0f},{K[1,1]:.0f},{K[0,2]:.0f},{K[1,2]:.0f}"


def write_video(frames, path, fps):
    if not frames:
        return
    h, w = frames[0].shape[:2]
    vw = cv2.VideoWriter(path, cv2.VideoWriter_fourcc(*"mp4v"), fps, (w, h))
    for f in frames:
        vw.write(f)
    vw.release()


def numerical_checks(sample, proj):
    W = sample["num_video_frames"] + 1
    Wc, Hc = proj["canonical_wh"]
    checks = {"time_alignment_ok": True, "window_indices": sample["window_indices"].tolist(),
              "decode_ids": sample["decode_ids"].tolist()}
    R_w2c = sample["R_w2c_win"]; t_w2c = sample["t_w2c_win"]
    R_ref = sample["R_w_c_ref"]; t_ref = sample["t_w_c_ref"]

    # dataset-vs-GT pixel agreement
    px_err = []
    for hand in ("left", "right"):
        hd = proj["hands"][hand]
        for j in range(W):
            a, b = hd["gt_px"][j], hd["ds_px"][j]
            if np.all(np.isfinite(a)) and np.all(np.isfinite(b)):
                px_err.append(float(np.hypot(*(a - b))))
    checks["dataset_vs_gt_pixel_max"] = float(np.max(px_err)) if px_err else None
    checks["dataset_vs_gt_pixel_mean"] = float(np.mean(px_err)) if px_err else None

    # roundtrip world: reconstruct dataset world pos vs raw world pos (anchor uses same wrist)
    rt = []
    if R_ref is not None and sample["action"] is not None:
        ds_anchor = reconstruct_dataset_anchor(sample["state"], sample["action"])
        for hand in ("left", "right"):
            hd = proj["hands"][hand]
            for j in range(W):
                # only over frames the dataset actually supervises (mask-gated)
                if not (bool(hd["valid"][j]) and bool(hd["ds_valid"][j])):
                    continue
                p_world = R_ref @ ds_anchor[hand][j] + t_ref
                rt.append(float(np.linalg.norm(p_world - hd["world_pos"][j])))
    checks["dataset_world_recon_max_err"] = float(np.max(rt)) if rt else None
    checks["dataset_world_recon_mean_err"] = float(np.mean(rt)) if rt else None

    # first-frame ref + units
    ff = {}; stats = {}
    for hand in ("left", "right"):
        hd = proj["hands"][hand]
        ff[hand] = {"valid": bool(hd["valid"][0]),
                    "z": None if not np.isfinite(hd["gt_z"][0]) else float(hd["gt_z"][0]),
                    "status": hd["gt_status"][0]}
        cam = np.array([world_to_cam_w2c(hd["world_pos"][t], R_w2c[t], t_w2c[t]) for t in range(W)])
        v = cam[hd["valid"]]
        if len(v):
            disp = np.linalg.norm(np.diff(v, axis=0), axis=1) if len(v) > 1 else np.array([0.0])
            stats[hand] = {"cam_min": v.min(0).tolist(), "cam_max": v.max(0).tolist(),
                           "depth_min": float(v[:, 2].min()), "depth_max": float(v[:, 2].max()),
                           "step_disp_mean": float(disp.mean()), "step_disp_max": float(disp.max())}
    checks["first_frame_gt"] = ff
    checks["hand_cam_stats"] = stats
    checks["reprojection_2d_annotation"] = (
        "PSEUDO-GT AVAILABLE: joints_camspace exists (image-aligned monocular MANO fit). "
        "GT_DIRECT uses world wrist via extrinsics, which equals joints_camspace root to ~0 "
        "(verified). No manually-labelled 2D keypoints exist; accuracy is bounded by VITRA's "
        "~90% monocular reconstruction quality."
    )

    quant = {}
    for hand in ("left", "right"):
        hd = proj["hands"][hand]
        n = int(hd["valid"].sum())
        nds = int(hd["ds_valid"].sum())
        if n == 0:
            continue
        gt_ok = sum(1 for j in range(W) if hd["valid"][j] and hd["gt_status"][j] == "ok")
        ds_ok = sum(1 for j in range(W) if hd["ds_valid"][j] and hd["ds_status"][j] == "ok")
        ds_behind = sum(1 for j in range(W) if hd["ds_valid"][j] and hd["ds_status"][j] == "behind(z<=0)")
        quant[hand] = {
            "n_gt_valid": n, "n_dataset_supervised": nds,
            "gt_direct_inframe_frac": gt_ok / n,
            "dataset_inframe_frac": (ds_ok / nds) if nds else None,
            "dataset_behind_frac": (ds_behind / nds) if nds else None,
        }
    checks["projection_quality"] = quant
    return checks


def build_debug_json(sample, proj, checks):
    def arr(x):
        return None if x is None else np.asarray(x).tolist()
    d = {
        "data_id": sample["data_id"], "episode_id": sample["episode_id"], "frame_id": sample["frame_id"],
        "clip_start": int(sample["window_indices"][0]), "clip_end": int(sample["window_indices"][-1]),
        "selected_frame_indices": sample["window_indices"].tolist(),
        "decode_ids": sample["decode_ids"].tolist(),
        "instruction": sample["instruction"], "extraction_error": sample["error"],
        "camera_intrinsics": arr(sample["K"]),
        "reference_camera_R_w_c": arr(sample["R_w_c_ref"]), "reference_camera_t_w_c": arr(sample["t_w_c_ref"]),
        "per_frame_R_w2c": arr(sample["R_w2c_win"]), "per_frame_t_w2c": arr(sample["t_w2c_win"]),
        "state": arr(sample["state"]), "action": arr(sample["action"]),
        "action_valid_mask": arr(sample["action_valid_mask"]),
        "hands": {}, "checks": checks,
    }
    for hand in ("left", "right"):
        hd = proj["hands"][hand]
        d["hands"][hand] = {
            "world_wrist_trajectory": arr(hd["world_pos"]),
            "dataset_anchor_trajectory": arr(hd["dataset_anchor"]),
            "valid_mask": arr(hd["valid"]),
            "dataset_supervised_mask": arr(hd["ds_valid"]),
            "gt_direct_pixels": arr(hd["gt_px"]), "gt_direct_depth": arr(hd["gt_z"]),
            "gt_direct_status": hd["gt_status"],
            "dataset_pixels": arr(hd["ds_px"]), "dataset_depth": arr(hd["ds_z"]),
            "dataset_status": hd["ds_status"],
        }
    return d


def classify_sample(sample, proj):
    tags = []
    lv = sample["left_valid_win"]; rv = sample["right_valid_win"]
    if lv.any() and not rv.any(): tags.append("left_only")
    if rv.any() and not lv.any(): tags.append("right_only")
    if lv.any() and rv.any(): tags.append("both_hands")
    if not lv.all() or not rv.all(): tags.append("has_invalid")
    tp = sample["t_w2c_win"]
    if np.linalg.norm(tp.max(0) - tp.min(0)) > 0.05:
        tags.append("camera_motion")
    for hand in ("left", "right"):
        hd = proj["hands"][hand]
        n = int(hd["valid"].sum())
        if n and sum(1 for j in range(len(hd["gt_status"])) if hd["valid"][j] and hd["gt_status"][j] == "out_of_frame") / n > 0.3:
            tags.append("high_oob")
    return sorted(set(tags))


def build_dataset(data_root, dataset_name, num_video_frames):
    return VitraHumanMotusDataset(
        dataset_dir=data_root, dataset_name=dataset_name,
        num_video_frames=num_video_frames, video_size=(384, 320),
        action_mode="unified_eef_camera_delta_wrist16",
        clip_len=2000, normalization=False,
        vlm_checkpoint_path=None, t5_mode="none",
    )


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--data-root", default="/home/work/wenjj/data/vitra_data_root")
    ap.add_argument("--dataset-name", default="ssv2")
    ap.add_argument("--output-dir", default="/home/work/wenjj/MotusV2/outputs/vitra_unified_eef_vis")
    ap.add_argument("--num-samples", type=int, default=12)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--data-id", type=int, default=None)
    ap.add_argument("--num-video-frames", type=int, default=8)
    ap.add_argument("--fps", type=int, default=4)
    ap.add_argument("--future-horizon", type=int, default=4)
    ap.add_argument("--no-history", action="store_true")
    ap.add_argument("--no-future", action="store_true")
    ap.add_argument("--view", choices=["original", "processed", "both"], default="both")
    ap.add_argument("--no-video", action="store_true")
    args = ap.parse_args()

    out_root = Path(args.output_dir); out_root.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(args.seed)

    logger.info(f"Building VITRA dataset ({args.dataset_name}) from {args.data_root} ...")
    ds = build_dataset(args.data_root, args.dataset_name, args.num_video_frames)
    n_core = len(ds.core)

    if args.data_id is not None:
        selection = [args.data_id]
    else:
        selection = rng.integers(0, n_core, size=max(args.num_samples * 4, args.num_samples)).tolist()

    views = ["original", "processed"] if args.view == "both" else [args.view]
    summary = {"data_root": args.data_root, "dataset_name": args.dataset_name, "samples": [], "aggregate": {}}
    agg = {"left": [], "right": []}
    seen_tags: Dict[str, int] = {}
    produced = 0

    for data_id in selection:
        if produced >= args.num_samples:
            break
        try:
            sample = ds.get_debug_sample(int(data_id), load_video=False)
        except Exception as e:
            logger.warning(f"get_debug_sample({data_id}) failed: {e}")
            continue
        if sample["action"] is None:
            continue
        if not (sample["left_valid_win"].any() or sample["right_valid_win"].any()):
            continue
        proj = compute_projections(sample)
        tags = classify_sample(sample, proj)
        checks = numerical_checks(sample, proj)
        for hand in ("left", "right"):
            if hand in checks.get("projection_quality", {}):
                agg[hand].append(checks["projection_quality"][hand])
        for t in tags:
            seen_tags[t] = seen_tags.get(t, 0) + 1

        sample_id = f"sample_{produced:06d}_{sample['episode_id']}_f{sample['frame_id']}"
        sdir = out_root / sample_id; sdir.mkdir(parents=True, exist_ok=True)
        (sdir / "debug.json").write_text(json.dumps(build_debug_json(sample, proj, checks), indent=2))
        (sdir / "sample_metadata.json").write_text(json.dumps({
            "sample_id": sample_id, "data_id": int(data_id), "episode_id": sample["episode_id"],
            "frame_id": sample["frame_id"], "instruction": sample["instruction"],
            "anno_type": sample["anno_type"], "tags": tags, "extraction_error": sample["error"],
        }, indent=2))

        vids = {}
        if not args.no_video:
            preview = False
            for view in views:
                try:
                    frames = render_overlay(sample, proj, view, not args.no_history, not args.no_future, args.future_horizon)
                except Exception as e:
                    logger.warning(f"render {sample_id} view={view} failed: {e}")
                    continue
                vp = sdir / f"overlay_{view}.mp4"
                write_video(frames, str(vp), args.fps)
                vids[view] = str(vp)
                if not preview and frames:
                    cv2.imwrite(str(sdir / "preview.png"), frames[len(frames) // 2]); preview = True

        summary["samples"].append({
            "sample_id": sample_id, "tags": tags, "videos": vids,
            "extraction_error": sample["error"],
            "projection_quality": checks.get("projection_quality", {}),
            "dataset_vs_gt_pixel_max": checks.get("dataset_vs_gt_pixel_max"),
            "dataset_world_recon_max_err": checks.get("dataset_world_recon_max_err"),
        })
        produced += 1
        logger.info(f"[{produced}/{args.num_samples}] {sample_id} tags={tags} "
                    f"px_match_max={checks.get('dataset_vs_gt_pixel_max')}")

    def _agg(lst, field):
        vals = [d[field] for d in lst if d.get(field) is not None]
        return {"mean": float(np.mean(vals)), "min": float(np.min(vals)), "max": float(np.max(vals)), "n": len(vals)} if vals else None
    for hand in ("left", "right"):
        summary["aggregate"][hand] = {
            "gt_direct_inframe_frac": _agg(agg[hand], "gt_direct_inframe_frac"),
            "dataset_inframe_frac": _agg(agg[hand], "dataset_inframe_frac"),
            "dataset_behind_frac": _agg(agg[hand], "dataset_behind_frac"),
        }
    summary["tag_counts"] = seen_tags
    (out_root / "summary.json").write_text(json.dumps(summary, indent=2))
    logger.info(f"Done. Produced {produced} samples -> {out_root}")


if __name__ == "__main__":
    main()

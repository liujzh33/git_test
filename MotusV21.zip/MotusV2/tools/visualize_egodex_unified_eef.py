#!/usr/bin/env python3
"""
visualize_egodex_unified_eef.py
===============================

Correctness-audit tool for the EgoDex ``unified_eef_camera_delta_wrist16``
pipeline, mirroring tools/visualize_xperience_unified_eef.py.

It reuses EgoDex's exact training extraction (``EgoDexMotusDataset`` +
``data/human/unified_eef_action.py``) via the non-invasive
``EgoDexMotusDataset.get_debug_sample`` method, then re-projects the wrist
trajectory back onto the egocentric video.

Two trajectories are projected onto every frame:

  GT_DIRECT (green) : raw world-frame hand pose projected via the per-frame
                      camera-to-world transform (T_w_c) + intrinsics.
  DATASET   (red)   : trajectory reconstructed from the dataset's own state +
                      action tensors, re-projected under the dataset's semantics.

EgoDex data model (verified OpenCV +Z convention):
    transforms/camera[i]       : camera-to-world SE(3) (T_w_c), +Z forward.
    transforms/{left,right}Hand: hand pose in world SE(3).
    camera/intrinsic           : (3,3) pinhole K, image 1920x1080.

For a CORRECT implementation the red dots coincide with the green dots and both
track the hands.

Run:
    python tools/visualize_egodex_unified_eef.py \
        --data-root /home/work/wenjj/data/EgoDex --splits test \
        --output-dir /home/work/wenjj/MotusV2/outputs/egodex_unified_eef_vis \
        --num-samples 12 --seed 0
"""

import argparse
import json
import logging
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import cv2
import numpy as np

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from data.egodex.egodex_dataset import EgoDexMotusDataset  # noqa: E402
from data.utils.image_utils import resize_with_padding  # noqa: E402

logging.basicConfig(level=logging.INFO, format="[%(levelname)s] %(message)s")
logger = logging.getLogger("viz_egodex_eef")

LEFT_T = slice(0, 3)
RIGHT_T = slice(8, 11)

C_GT = (0, 220, 0)        # green : GT_DIRECT
C_DATASET = (0, 0, 255)   # red   : dataset reconstruction
C_HIST = (0, 200, 200)
C_FUT = (255, 180, 0)
C_TXT = (255, 255, 255)


# --------------------------------------------------------------------------- #
def project_pinhole(p_cam: np.ndarray, K: np.ndarray) -> Tuple[Optional[np.ndarray], float]:
    """OpenCV pinhole projection (+Z forward). K is 3x3."""
    z = float(p_cam[2])
    if z <= 1e-6:
        return None, z
    u = K[0, 0] * p_cam[0] / z + K[0, 2]
    v = K[1, 1] * p_cam[1] / z + K[1, 2]
    return np.array([u, v]), z


def world_to_cam(p_world: np.ndarray, T_w_c: np.ndarray) -> np.ndarray:
    """world point -> camera frame using camera-to-world T_w_c."""
    R = T_w_c[:3, :3]
    t = T_w_c[:3, 3]
    return R.T @ (p_world - t)


def resize_with_padding_transform(orig_hw, target_hw):
    oh, ow = orig_hw
    th, tw = target_hw
    scale = min(th / oh, tw / ow)
    new_h = int(oh * scale)
    new_w = int(ow * scale)
    return scale, float((tw - new_w) // 2), float((th - new_h) // 2)


def native_frames(mp4_path: str, indices: List[int]) -> np.ndarray:
    import decord
    vr = decord.VideoReader(str(mp4_path), num_threads=2)
    n = len(vr)
    safe = [min(max(int(i), 0), n - 1) for i in indices]
    batch = vr.get_batch(safe).asnumpy()
    if batch.shape[-1] == 4:
        batch = batch[..., :3]
    return batch.astype(np.uint8)


def reconstruct_dataset_anchor(state, action):
    F = action.shape[0]
    left = np.zeros((F + 1, 3)); right = np.zeros((F + 1, 3))
    left[0] = state[LEFT_T]; right[0] = state[RIGHT_T]
    for i in range(F):
        left[i + 1] = state[LEFT_T] + action[i][LEFT_T]
        right[i + 1] = state[RIGHT_T] + action[i][RIGHT_T]
    return {"left": left, "right": right}


def compute_projections(sample: Dict[str, Any]) -> Dict[str, Any]:
    W = sample["num_video_frames"] + 1
    K = sample["K"]
    cam_win = sample["cam_tfs_win"]          # (W,4,4) T_w_c
    R_ref = sample["R_w_c_ref"]; t_ref = sample["t_w_c_ref"]
    has_ds = sample["action"] is not None and sample["state"] is not None
    ds_anchor = reconstruct_dataset_anchor(sample["state"], sample["action"]) if has_ds else None

    out = {"cam_win": cam_win, "hands": {}}
    for hand, tfs_key, valid_key, tsl in [
        ("left", "left_tfs_win", "left_valid_win", LEFT_T),
        ("right", "right_tfs_win", "right_valid_win", RIGHT_T),
    ]:
        tfs = sample[tfs_key]          # (W,4,4) world
        valid = sample[valid_key]      # (W,)
        world_pos = tfs[:, :3, 3]      # (W,3)
        correct_cam0 = np.array([world_to_cam(world_pos[t], cam_win[0]) for t in range(W)])

        gt_px = np.full((W, 2), np.nan); gt_z = np.full((W,), np.nan); gt_status = ["missing"] * W
        ds_px = np.full((W, 2), np.nan); ds_z = np.full((W,), np.nan); ds_status = ["missing"] * W
        for j in range(W):
            if bool(valid[j]) and np.all(np.isfinite(world_pos[j])):
                pc = world_to_cam(world_pos[j], cam_win[j])
                px, z = project_pinhole(pc, K); gt_z[j] = z
                if px is None:
                    gt_status[j] = "behind(z<=0)"
                else:
                    gt_px[j] = px
                    gt_status[j] = "ok" if (0 <= px[0] < 1920 and 0 <= px[1] < 1080) else "out_of_frame"
            if has_ds:
                p_anchor = ds_anchor[hand][j]
                p_world = R_ref @ p_anchor + t_ref
                pc = world_to_cam(p_world, cam_win[j])
                px, z = project_pinhole(pc, K); ds_z[j] = z
                if px is None:
                    ds_status[j] = "behind(z<=0)"
                else:
                    ds_px[j] = px
                    ds_status[j] = "ok" if (0 <= px[0] < 1920 and 0 <= px[1] < 1080) else "out_of_frame"
        out["hands"][hand] = {
            "world_pos": world_pos, "valid": valid.astype(bool),
            "correct_cam0": correct_cam0,
            "dataset_anchor": None if ds_anchor is None else ds_anchor[hand],
            "gt_px": gt_px, "gt_z": gt_z, "gt_status": gt_status,
            "ds_px": ds_px, "ds_z": ds_z, "ds_status": ds_status,
        }
    return out


# --------------------------------------------------------------------------- #
def _map_px(px, view, tf):
    if px is None or not np.all(np.isfinite(px)):
        return None
    if view == "processed":
        scale, xo, yo = tf
        return int(round(px[0] * scale + xo)), int(round(px[1] * scale + yo))
    return int(round(px[0])), int(round(px[1]))


def _fmt_px(px):
    if px is None or not np.all(np.isfinite(px)):
        return "--"
    return f"({px[0]:.0f},{px[1]:.0f})"


def _polyline(img, pts, color, thickness, dashed=False):
    pts = [p for p in pts if p is not None]
    for a, b in zip(pts[:-1], pts[1:]):
        if dashed:
            mid = ((a[0] + b[0]) // 2, (a[1] + b[1]) // 2)
            cv2.line(img, a, mid, color, thickness, cv2.LINE_AA)
        else:
            cv2.line(img, a, b, color, thickness, cv2.LINE_AA)


def _safe_circle(img, p, r, color, filled=True, label=None):
    H, Wpx = img.shape[:2]
    x, y = p
    if 0 <= x < Wpx and 0 <= y < H:
        cv2.circle(img, (x, y), r, color, -1 if filled else 2, cv2.LINE_AA)
        if label:
            cv2.putText(img, label, (x + 6, y - 6), cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2, cv2.LINE_AA)
    else:
        cx, cy = max(6, min(Wpx - 7, x)), max(6, min(H - 7, y))
        cv2.circle(img, (cx, cy), 5, color, 2, cv2.LINE_AA)
        cv2.putText(img, "OOF", (cx + 6, cy), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1, cv2.LINE_AA)


def render_overlay(sample, proj, view, draw_history, draw_future, future_horizon):
    W = sample["num_video_frames"] + 1
    idxs = sample["window_indices"].tolist()
    native = native_frames(sample["mp4_path"], idxs)
    orig_hw = (native.shape[1], native.shape[2])
    target_hw = (384, 320)
    tf = resize_with_padding_transform(orig_hw, target_hw)

    frames_out = []
    hand_colors = {"left": (255, 128, 0), "right": (0, 128, 255)}
    for j in range(W):
        rgb = native[j]
        if view == "processed":
            rgb = resize_with_padding(rgb, target_hw)
        img = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR).copy()
        panel = np.zeros((img.shape[0], 420, 3), dtype=np.uint8)
        y = 22

        def put(txt, col=C_TXT, dy=20):
            nonlocal y
            cv2.putText(panel, txt, (6, y), cv2.FONT_HERSHEY_SIMPLEX, 0.5, col, 1, cv2.LINE_AA)
            y += dy

        put(f"task={sample['task_name']}", (200, 255, 200))
        put(f"view={view}  clip_start(f0)={idxs[0]}")
        put(f"win_idx(j)={j}  orig_frame={idxs[j]}", (180, 220, 255))
        put("GREEN=GT  RED=dataset", (0, 255, 255))
        for hand in ("left", "right"):
            hd = proj["hands"][hand]; col = hand_colors[hand]
            put(f"[{hand}] valid={bool(hd['valid'][j])}", col, 18)
            put(f"  GT z={hd['gt_z'][j]:.3f} px={_fmt_px(hd['gt_px'][j])} {hd['gt_status'][j]}", C_GT, 18)
            put(f"  DS z={hd['ds_z'][j]:.3f} px={_fmt_px(hd['ds_px'][j])} {hd['ds_status'][j]}", C_DATASET, 20)
            if draw_history and j > 0:
                _polyline(img, [_map_px(hd["gt_px"][k], view, tf) for k in range(j + 1)], C_HIST, 2)
            if draw_future:
                hi = min(W, j + 1 + future_horizon)
                _polyline(img, [_map_px(hd["gt_px"][k], view, tf) for k in range(j, hi)], C_FUT, 2, dashed=True)
            if bool(hd["valid"][j]):
                p_gt = _map_px(hd["gt_px"][j], view, tf)
                if p_gt is not None:
                    _safe_circle(img, p_gt, 9, C_GT, True, hand[0].upper())
                p_ds = _map_px(hd["ds_px"][j], view, tf)
                if p_ds is not None:
                    _safe_circle(img, p_ds, 7, C_DATASET, False)
        frames_out.append(np.hstack([img, panel]))
    return frames_out


def write_video(frames, path, fps):
    if not frames:
        return
    h, w = frames[0].shape[:2]
    vw = cv2.VideoWriter(path, cv2.VideoWriter_fourcc(*"mp4v"), fps, (w, h))
    for f in frames:
        vw.write(f)
    vw.release()


# --------------------------------------------------------------------------- #
def numerical_checks(sample, proj):
    W = sample["num_video_frames"] + 1
    checks = {"time_alignment_ok": True, "window_indices": sample["window_indices"].tolist()}

    # roundtrip: world -> frame0-cam -> world -> cam(t) == world_to_cam(world, cam(t))
    rt_err = []
    cam_win = proj["cam_win"]
    for hand in ("left", "right"):
        hd = proj["hands"][hand]
        for t in range(W):
            if not bool(hd["valid"][t]):
                continue
            corr = hd["correct_cam0"][t]
            # frame0-cam -> world
            p_world = cam_win[0][:3, :3] @ corr + cam_win[0][:3, 3]
            back = p_world - hd["world_pos"][t]
            rt_err.append(float(np.linalg.norm(back)))
    checks["roundtrip_world_max_err"] = float(np.max(rt_err)) if rt_err else None
    checks["roundtrip_world_mean_err"] = float(np.mean(rt_err)) if rt_err else None

    # dataset-vs-GT pixel agreement (should be ~0 for correct impl)
    px_err = []
    for hand in ("left", "right"):
        hd = proj["hands"][hand]
        for j in range(W):
            a, b = hd["gt_px"][j], hd["ds_px"][j]
            if np.all(np.isfinite(a)) and np.all(np.isfinite(b)):
                px_err.append(float(np.hypot(*(a - b))))
    checks["dataset_vs_gt_pixel_max"] = float(np.max(px_err)) if px_err else None
    checks["dataset_vs_gt_pixel_mean"] = float(np.mean(px_err)) if px_err else None

    # first-frame reference
    ff = {}
    for hand in ("left", "right"):
        hd = proj["hands"][hand]
        ff[hand] = {"valid": bool(hd["valid"][0]),
                    "z": None if not np.isfinite(hd["gt_z"][0]) else float(hd["gt_z"][0]),
                    "status": hd["gt_status"][0]}
    checks["first_frame_gt"] = ff

    # units / ranges
    stats = {}
    for hand in ("left", "right"):
        hd = proj["hands"][hand]
        cam_pos = np.array([world_to_cam(hd["world_pos"][t], cam_win[t]) for t in range(W)])
        v = cam_pos[hd["valid"]]
        if len(v):
            disp = np.linalg.norm(np.diff(v, axis=0), axis=1) if len(v) > 1 else np.array([0.0])
            stats[hand] = {"cam_min": v.min(0).tolist(), "cam_max": v.max(0).tolist(),
                           "depth_min": float(v[:, 2].min()), "depth_max": float(v[:, 2].max()),
                           "step_disp_mean": float(disp.mean()), "step_disp_max": float(disp.max())}
    checks["hand_cam_stats"] = stats
    cp = cam_win[:, :3, 3]
    checks["camera_translation_range"] = (cp.max(0) - cp.min(0)).tolist()

    checks["reprojection_2d_annotation"] = (
        "NOT AVAILABLE: EgoDex provides only 3D world SE(3) transforms + a camera "
        "intrinsic; no ground-truth 2D wrist keypoints. GT_DIRECT projection is the "
        "visual reference."
    )

    quant = {}
    for hand in ("left", "right"):
        hd = proj["hands"][hand]
        n = int(hd["valid"].sum())
        if n == 0:
            continue
        gt_ok = sum(1 for j in range(W) if hd["valid"][j] and hd["gt_status"][j] == "ok")
        ds_ok = sum(1 for j in range(W) if hd["valid"][j] and hd["ds_status"][j] == "ok")
        ds_behind = sum(1 for j in range(W) if hd["valid"][j] and hd["ds_status"][j] == "behind(z<=0)")
        quant[hand] = {"n_valid": n, "gt_direct_inframe_frac": gt_ok / n,
                       "dataset_inframe_frac": ds_ok / n, "dataset_behind_frac": ds_behind / n}
    checks["projection_quality"] = quant
    return checks


# --------------------------------------------------------------------------- #
def build_debug_json(sample, proj, checks):
    def arr(x):
        return None if x is None else np.asarray(x).tolist()
    d = {
        "sample_index": {"episode_index": sample["episode_index"], "frame_start": sample["frame_start"]},
        "video_path": sample["mp4_path"], "h5_path": sample["h5_path"],
        "clip_start": int(sample["window_indices"][0]), "clip_end": int(sample["window_indices"][-1]),
        "selected_frame_indices": sample["window_indices"].tolist(),
        "instruction": sample["instruction"], "extraction_error": sample["error"],
        "camera_intrinsics": arr(sample["K"]),
        "reference_camera_pose_T_w_c": arr(sample["cam_tfs_win"][0]),
        "per_frame_camera_T_w_c": arr(sample["cam_tfs_win"]),
        "state": arr(sample["state"]), "action": arr(sample["action"]),
        "action_valid_mask": arr(sample["action_valid_mask"]),
        "hands": {}, "checks": checks,
    }
    for hand in ("left", "right"):
        hd = proj["hands"][hand]
        d["hands"][hand] = {
            "world_wrist_trajectory": arr(hd["world_pos"]),
            "unified_eef_trajectory_frame0_cam": arr(hd["correct_cam0"]),
            "dataset_anchor_trajectory": arr(hd["dataset_anchor"]),
            "valid_mask": arr(hd["valid"]),
            "gt_direct_pixels": arr(hd["gt_px"]), "gt_direct_depth": arr(hd["gt_z"]),
            "gt_direct_status": hd["gt_status"],
            "dataset_pixels": arr(hd["ds_px"]), "dataset_depth": arr(hd["ds_z"]),
            "dataset_status": hd["ds_status"],
        }
    return d


def classify_sample(sample, proj):
    tags = []
    lv = sample["left_valid_win"]; rv = sample["right_valid_win"]
    if lv.any() and not rv.any(): tags.append("left_only")
    if rv.any() and not lv.any(): tags.append("right_only")
    if lv.any() and rv.any(): tags.append("both_hands")
    if not lv.all() or not rv.all(): tags.append("has_invalid")
    cp = sample["cam_tfs_win"][:, :3, 3]
    if np.linalg.norm(cp.max(0) - cp.min(0)) > 0.1:
        tags.append("camera_motion")
    for hand in ("left", "right"):
        hd = proj["hands"][hand]
        n = int(hd["valid"].sum())
        if n and sum(1 for j in range(len(hd["gt_status"])) if hd["valid"][j] and hd["gt_status"][j] == "out_of_frame") / n > 0.3:
            tags.append("high_oob")
    return sorted(set(tags))


# --------------------------------------------------------------------------- #
def build_dataset(data_root, splits, num_video_frames, max_episodes):
    return EgoDexMotusDataset(
        dataset_dir=data_root, splits=splits,
        num_video_frames=num_video_frames, video_size=(384, 320),
        action_mode="unified_eef_camera_delta_wrist16",
        confidence_threshold=0.3, vlm_checkpoint_path=None, t5_mode="none",
        max_episodes=max_episodes,
    )


def enumerate_candidates(ds, per_episode=6):
    F = ds.num_video_frames
    cands = []
    for ei, ep in enumerate(ds.episodes):
        hi = ep["n_frames"] - F - 1
        if hi <= 0:
            continue
        for s in np.linspace(0, hi, per_episode).astype(int):
            cands.append((ei, int(s)))
    return cands


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--data-root", default="/home/work/wenjj/data/EgoDex")
    ap.add_argument("--splits", nargs="+", default=["test"])
    ap.add_argument("--output-dir", default="/home/work/wenjj/MotusV2/outputs/egodex_unified_eef_vis")
    ap.add_argument("--num-samples", type=int, default=12)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--sample-index", type=int, default=None)
    ap.add_argument("--episode-index", type=int, default=None)
    ap.add_argument("--frame-start", type=int, default=None)
    ap.add_argument("--num-video-frames", type=int, default=8)
    ap.add_argument("--max-episodes", type=int, default=2000)
    ap.add_argument("--fps", type=int, default=4)
    ap.add_argument("--future-horizon", type=int, default=4)
    ap.add_argument("--no-history", action="store_true")
    ap.add_argument("--no-future", action="store_true")
    ap.add_argument("--view", choices=["original", "processed", "both"], default="both")
    ap.add_argument("--no-video", action="store_true")
    args = ap.parse_args()

    out_root = Path(args.output_dir); out_root.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(args.seed)

    logger.info(f"Building EgoDex dataset from {args.data_root} splits={args.splits} ...")
    ds = build_dataset(args.data_root, args.splits, args.num_video_frames, args.max_episodes)

    if args.episode_index is not None and args.frame_start is not None:
        selection = [(args.episode_index, args.frame_start)]
    else:
        cands = enumerate_candidates(ds)
        if args.sample_index is not None:
            selection = [cands[args.sample_index % len(cands)]]
        else:
            order = rng.permutation(len(cands))
            selection = [cands[i] for i in order[: max(args.num_samples * 3, args.num_samples)]]

    views = ["original", "processed"] if args.view == "both" else [args.view]
    summary = {"data_root": args.data_root, "splits": args.splits, "samples": [], "aggregate": {}}
    agg = {"left": [], "right": []}
    seen_tags: Dict[str, int] = {}
    produced = 0

    for (ei, fs) in selection:
        if produced >= args.num_samples:
            break
        try:
            sample = ds.get_debug_sample(ei, fs, load_video=False)
        except Exception as e:
            logger.warning(f"get_debug_sample({ei},{fs}) failed: {e}")
            continue
        if sample["K"] is None:
            continue
        proj = compute_projections(sample)
        tags = classify_sample(sample, proj)
        checks = numerical_checks(sample, proj)
        for hand in ("left", "right"):
            if hand in checks.get("projection_quality", {}):
                agg[hand].append(checks["projection_quality"][hand])
        for t in tags:
            seen_tags[t] = seen_tags.get(t, 0) + 1

        sample_id = f"sample_{produced:06d}_ep{ei}_f{fs}"
        sdir = out_root / sample_id; sdir.mkdir(parents=True, exist_ok=True)
        (sdir / "debug.json").write_text(json.dumps(build_debug_json(sample, proj, checks), indent=2))
        (sdir / "sample_metadata.json").write_text(json.dumps({
            "sample_id": sample_id, "episode_index": ei, "frame_start": fs,
            "task_name": sample["task_name"], "instruction": sample["instruction"],
            "tags": tags, "extraction_error": sample["error"],
        }, indent=2))

        vids = {}
        if not args.no_video:
            preview = False
            for view in views:
                frames = render_overlay(sample, proj, view, not args.no_history, not args.no_future, args.future_horizon)
                vp = sdir / f"overlay_{view}.mp4"
                write_video(frames, str(vp), args.fps)
                vids[view] = str(vp)
                if not preview and frames:
                    cv2.imwrite(str(sdir / "preview.png"), frames[len(frames) // 2]); preview = True

        summary["samples"].append({
            "sample_id": sample_id, "tags": tags, "videos": vids,
            "extraction_error": sample["error"],
            "projection_quality": checks.get("projection_quality", {}),
            "roundtrip_world_max_err": checks.get("roundtrip_world_max_err"),
            "dataset_vs_gt_pixel_max": checks.get("dataset_vs_gt_pixel_max"),
        })
        produced += 1
        logger.info(f"[{produced}/{args.num_samples}] {sample_id} tags={tags} "
                    f"px_match_max={checks.get('dataset_vs_gt_pixel_max')}")

    def _agg(lst, field):
        vals = [d[field] for d in lst if field in d]
        return {"mean": float(np.mean(vals)), "min": float(np.min(vals)), "max": float(np.max(vals)), "n": len(vals)} if vals else None
    for hand in ("left", "right"):
        summary["aggregate"][hand] = {
            "gt_direct_inframe_frac": _agg(agg[hand], "gt_direct_inframe_frac"),
            "dataset_inframe_frac": _agg(agg[hand], "dataset_inframe_frac"),
            "dataset_behind_frac": _agg(agg[hand], "dataset_behind_frac"),
        }
    summary["tag_counts"] = seen_tags
    (out_root / "summary.json").write_text(json.dumps(summary, indent=2))
    logger.info(f"Done. Produced {produced} samples -> {out_root}")


if __name__ == "__main__":
    main()

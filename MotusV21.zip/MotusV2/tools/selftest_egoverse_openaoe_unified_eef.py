#!/usr/bin/env python3
"""
selftest_egoverse_openaoe_unified_eef.py
========================================

Self-contained correctness test for the two new unified-EEF adapters
(``EgoVerseMotusDataset``, ``OpenAoEMotusDataset``) using SYNTHETIC fixtures.

Why synthetic: the real EgoVerse / OpenAoE data lives on the training cluster.
This test builds episodes whose ground truth we control exactly (a moving
camera + two moving hands in a shared world frame), writes them in each
dataset's on-disk format, runs the real dataset classes, and checks that the
emitted 16-D action/state carry EXACTLY the unified-EEF semantics used by
VITRA / EgoDex / Xperience:

    state[0:3]        = R_w_c(0)^T (t_w_left(0)  - t_w_c(0))
    state[3:6]        = log_SO3(R_w_c(0)^T R_w_left(0))
    action[i][0:3]    = R_w_c(0)^T (t_w_left(i+1) - t_w_left(0))
    (same for the right hand at dims 8:11 / 11:14)
    dims 6,7,14,15    = 0 and never masked in  (human data has no gripper)

and that reconstructing ``state + action`` and re-projecting through each
frame's camera lands on the true wrist pixel (the check used to validate the
Xperience fix).

Run:
    python tools/selftest_egoverse_openaoe_unified_eef.py
"""

import json
import shutil
import sys
import tempfile
from pathlib import Path

import numpy as np

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from scipy.spatial.transform import Rotation as R  # noqa: E402

from data.human.unified_eef_action import (  # noqa: E402
    compute_unified_eef_action_sequence,
    compute_unified_eef_state_from_poses,
    log_SO3,
    UNIFIED_EEF_EFFECTIVE_INDICES,
    UNIFIED_EEF_RESERVED_INDICES,
)

F = 8              # num_video_frames
N = 40             # episode length
IMG_H, IMG_W = 480, 640
FX = FY = 266.50860444
CX, CY = 320.0, 240.0

TOL = 1e-5


# --------------------------------------------------------------------------- #
# Ground-truth trajectory generator (shared by both fixtures)
# --------------------------------------------------------------------------- #
def make_ground_truth(seed: int = 0):
    """A moving camera and two moving hands, all in one world frame.

    Returns dict with:
        R_w_c (N,3,3), t_w_c (N,3)    camera -> world  (OpenCV +Z forward)
        R_w_l/R_w_r (N,3,3), t_w_l/t_w_r (N,3)   hand -> world
        valid_l/valid_r (N,) bool
    """
    rng = np.random.default_rng(seed)
    ts = np.linspace(0.0, 1.0, N)

    # Camera: translates ~1 m and rotates ~40 deg over the episode, so a wrong
    # reference frame cannot silently pass.
    t_w_c = np.stack([0.6 * ts, 0.15 * np.sin(3 * ts), 0.4 * ts], axis=1)
    cam_rotvec = np.stack([0.3 * ts, 0.7 * ts, -0.2 * ts], axis=1)
    R_w_c = R.from_rotvec(cam_rotvec).as_matrix()

    # Hands: in front of the camera (positive Z in camera frame) and moving.
    def hand_traj(offset, phase):
        local = np.stack([
            offset + 0.10 * np.sin(2 * np.pi * ts + phase),
            0.05 * np.cos(2 * np.pi * ts + phase),
            0.45 + 0.10 * ts,
        ], axis=1)                                   # in each frame's camera frame
        # place them in world via the per-frame camera pose so depths stay sane
        t_w = np.einsum("nij,nj->ni", R_w_c, local) + t_w_c
        rotvec = np.stack([0.4 * np.sin(ts + phase), 0.3 * ts, 0.2 * np.cos(ts)], axis=1)
        R_w = R.from_rotvec(rotvec).as_matrix()
        return R_w, t_w

    R_w_l, t_w_l = hand_traj(-0.12, 0.0)
    R_w_r, t_w_r = hand_traj(+0.12, 1.3)

    valid_l = np.ones(N, dtype=bool)
    valid_r = np.ones(N, dtype=bool)
    valid_l[5:8] = False       # a validity gap to exercise masking
    valid_r[N - 3:] = False

    return dict(R_w_c=R_w_c, t_w_c=t_w_c, R_w_l=R_w_l, t_w_l=t_w_l,
                R_w_r=R_w_r, t_w_r=t_w_r, valid_l=valid_l, valid_r=valid_r)


def reference_unified_eef(gt, win):
    """Reference action/state via a direct call to the SHARED unified-eef math.

    Every dataset (VITRA / EgoDex / Xperience / EgoVerse / OpenAoE) funnels into
    these two functions, so agreeing with this call is what "identical action
    space" means operationally.
    """
    actions, masks = compute_unified_eef_action_sequence(
        R_w_e_left=gt["R_w_l"][win], t_w_e_left=gt["t_w_l"][win],
        R_w_e_right=gt["R_w_r"][win], t_w_e_right=gt["t_w_r"][win],
        R_w_c=gt["R_w_c"][win[0]],
        left_valid=gt["valid_l"][win], right_valid=gt["valid_r"][win],
        num_action_frames=F,
    )
    state, _ = compute_unified_eef_state_from_poses(
        R_w_e_left=gt["R_w_l"][win[0]], t_w_e_left=gt["t_w_l"][win[0]],
        R_w_e_right=gt["R_w_r"][win[0]], t_w_e_right=gt["t_w_r"][win[0]],
        R_w_c=gt["R_w_c"][win[0]], t_w_c=gt["t_w_c"][win[0]],
        left_valid=bool(gt["valid_l"][win[0]]), right_valid=bool(gt["valid_r"][win[0]]),
    )
    return actions, state, masks


# --------------------------------------------------------------------------- #
# Fixture writers
# --------------------------------------------------------------------------- #
def write_dummy_mp4(path: Path, n_frames: int):
    import cv2
    path.parent.mkdir(parents=True, exist_ok=True)
    vw = cv2.VideoWriter(str(path), cv2.VideoWriter_fourcc(*"mp4v"), 30, (IMG_W, IMG_H))
    for i in range(n_frames):
        frame = np.full((IMG_H, IMG_W, 3), (i * 5) % 255, dtype=np.uint8)
        cv2.putText(frame, str(i), (30, 240), cv2.FONT_HERSHEY_SIMPLEX, 3, (255, 255, 255), 4)
        vw.write(frame)
    vw.release()


def write_openaoe_fixture(root: Path, gt, name="aoe_selftest_p000"):
    d = root / name
    (d / "ego_process/ego_hands_reconstruction").mkdir(parents=True, exist_ok=True)
    (d / "ego_process/ego_undistorted_video").mkdir(parents=True, exist_ok=True)
    (d / "ego_annotation").mkdir(parents=True, exist_ok=True)

    cam_c2w = np.zeros((N, 4, 4), dtype=np.float64)
    cam_c2w[:, :3, :3] = gt["R_w_c"]
    cam_c2w[:, :3, 3] = gt["t_w_c"]
    cam_c2w[:, 3, 3] = 1.0
    K = np.array([[FX, 0, CX], [0, FY, CY], [0, 0, 1]], dtype=np.float64)
    np.savez(d / "ego_process/ego_hands_reconstruction/camera_traj.npz",
             cam_c2w=cam_c2w, intrinsic=K)

    # index 0 = LEFT, index 1 = RIGHT (dataset convention)
    pred_trans = np.stack([gt["t_w_l"], gt["t_w_r"]]).astype(np.float32)
    pred_rot = np.stack([R.from_matrix(gt["R_w_l"]).as_rotvec(),
                         R.from_matrix(gt["R_w_r"]).as_rotvec()]).astype(np.float32)
    pred_valid = np.stack([gt["valid_l"], gt["valid_r"]]).astype(np.float32)
    R_w2c = np.transpose(gt["R_w_c"], (0, 2, 1))
    t_w2c = -np.einsum("nij,nj->ni", R_w2c, gt["t_w_c"])
    np.savez(d / "ego_process/ego_hands_reconstruction/hands.npz",
             R_w2c=R_w2c.astype(np.float32), t_w2c=t_w2c.astype(np.float32),
             R_c2w=gt["R_w_c"].astype(np.float32), t_c2w=gt["t_w_c"].astype(np.float32),
             pred_trans=pred_trans, pred_rot=pred_rot,
             pred_trans_cam=np.zeros_like(pred_trans), pred_rot_cam=np.zeros_like(pred_rot),
             pred_hand_pose=np.zeros((2, N, 45), np.float32),
             pred_betas=np.zeros((2, N, 10), np.float32),
             pred_valid=pred_valid, focal=np.float64(FX))

    json.dump([{
        "id": 1, "start_ts": "0.0", "end_ts": "2.0",
        "start_frame": "0", "end_frame": str(N), "scene": "table",
        "atomic_action": [{"verb": "grasp", "object": "cup", "hand": "both",
                           "description": "The person grasps the cup with both hands.",
                           "bbox": [0, 0, 10, 10], "confidence": 0.9}],
    }], open(d / "ego_annotation/ego_action_annotation.json", "w"))

    write_dummy_mp4(d / "raw_video.mp4", N)
    write_dummy_mp4(d / "ego_process/ego_undistorted_video/raw_video_undistorted.mp4", N)
    return d


def write_egoverse_fixture(root: Path, gt, name="2025-09-20-17-42-51-000000"):
    """Write only the parts readable without zarr (root zarr.json + mp4).

    The pose arrays are injected by monkeypatching ``_read_array`` in the test,
    because these are Zarr v3 stores and ``zarr>=3`` needs Python >= 3.11 which
    is not available in this environment.
    """
    aria = root / "aria"
    aria.mkdir(parents=True, exist_ok=True)
    zdir = aria / f"{name}.zarr"
    zdir.mkdir(parents=True, exist_ok=True)

    feature = lambda dim: {"dtype": "float64", "shape": [dim], "names": ["dim_0"]}  # noqa: E731
    attrs = {
        "embodiment": "human_bimanual",
        "total_frames": N,
        "fps": 30,
        "task_name": "fold_clothes",
        "task_description": "folding clothes",
        "features": {
            "left.obs_ee_pose": feature(7), "left.obs_wrist_pose": feature(7),
            "right.obs_ee_pose": feature(7), "right.obs_wrist_pose": feature(7),
            "obs_head_pose": feature(7), "obs_eye_gaze": feature(3),
            "images.front_1": {"dtype": "jpeg", "shape": [IMG_H, IMG_W, 3]},
        },
        "intrinsics": {"front_1": [[FX, 0.0, CX, 0.0], [0.0, FY, CY, 0.0], [0.0, 0.0, 1.0, 0.0]]},
    }
    json.dump({"attributes": attrs, "zarr_format": 3, "node_type": "group"},
              open(zdir / "zarr.json", "w"))
    write_dummy_mp4(aria / f"{name}.mp4", N)
    return zdir


def poses7_from_Rt(Rm, t, order="wxyz"):
    """(N,7) [xyz, quat] pose rows.

    Default is ``wxyz`` because that is what real ARIA episodes were verified to
    use (the field documentation's ``xyzw`` is wrong -- decoding as xyzw puts the
    wrist behind the camera).
    """
    q = R.from_matrix(Rm).as_quat()          # scipy returns xyzw
    if order == "wxyz":
        q = np.roll(q, 1, axis=-1)
    return np.concatenate([t, q], axis=-1)


# --------------------------------------------------------------------------- #
# Shared assertions
# --------------------------------------------------------------------------- #
def check_layout(name, action, state, mask):
    assert action.shape == (F, 16), f"{name}: action shape {action.shape}"
    assert state.shape == (16,), f"{name}: state shape {state.shape}"
    assert mask.shape == (F, 16), f"{name}: mask shape {mask.shape}"
    for d in UNIFIED_EEF_RESERVED_INDICES:      # 6,7,14,15
        assert np.allclose(action[:, d], 0), f"{name}: reserved dim {d} nonzero"
        assert np.allclose(state[d], 0), f"{name}: reserved state dim {d} nonzero"
        assert not mask[:, d].any(), f"{name}: reserved dim {d} is masked in"
    assert set(np.where(mask.any(axis=0))[0]).issubset(set(UNIFIED_EEF_EFFECTIVE_INDICES)), \
        f"{name}: mask covers dims outside the human effective set"
    print(f"  [{name}] layout OK: 16D, reserved dims {UNIFIED_EEF_RESERVED_INDICES} zero & unmasked")


def check_semantics(name, action, state, gt, win):
    """Verify the exact unified-EEF definition against the ground truth."""
    R_w_c0, t_w_c0 = gt["R_w_c"][win[0]], gt["t_w_c"][win[0]]
    for hand, tsl, rsl, tw, Rw in (("left", slice(0, 3), slice(3, 6), gt["t_w_l"], gt["R_w_l"]),
                                   ("right", slice(8, 11), slice(11, 14), gt["t_w_r"], gt["R_w_r"])):
        exp_t = R_w_c0.T @ (tw[win[0]] - t_w_c0)
        exp_r = log_SO3((R_w_c0.T @ Rw[win[0]]).reshape(1, 3, 3)).reshape(3)
        assert np.allclose(state[tsl], exp_t, atol=TOL), \
            f"{name}/{hand}: state xyz {state[tsl]} != {exp_t}"
        assert np.allclose(state[rsl], exp_r, atol=TOL), \
            f"{name}/{hand}: state rotvec mismatch"
        for i in range(F):
            exp_d = R_w_c0.T @ (tw[win[i + 1]] - tw[win[0]])
            assert np.allclose(action[i][tsl], exp_d, atol=TOL), \
                f"{name}/{hand}: action[{i}] {action[i][tsl]} != {exp_d}"
    print(f"  [{name}] semantics OK: state = wrist in anchor-cam frame; "
          f"action[i] = anchor-cam delta to frame i+1")


def check_reprojection(name, action, state, gt, win, K):
    """state+action must re-project onto the true wrist pixel in every frame."""
    R_w_c0, t_w_c0 = gt["R_w_c"][win[0]], gt["t_w_c"][win[0]]
    def project(p_world, fi):
        p_cam = gt["R_w_c"][fi].T @ (p_world - gt["t_w_c"][fi])
        u = K[0, 0] * p_cam[0] / p_cam[2] + K[0, 2]
        v = K[1, 1] * p_cam[1] / p_cam[2] + K[1, 2]
        return np.array([u, v]), float(p_cam[2])

    errs, depths = [], []
    for hand, tsl, tw, valid in (("left", slice(0, 3), gt["t_w_l"], gt["valid_l"]),
                                 ("right", slice(8, 11), gt["t_w_r"], gt["valid_r"])):
        for j in range(F + 1):
            fi = win[j]
            if not (valid[fi] and valid[win[0]]):
                continue
            # Reconstruct the wrist from state+action and lift back to world.
            p_anchor = state[tsl] + (action[j - 1][tsl] if j > 0 else 0.0)
            px_recon, _ = project(R_w_c0 @ p_anchor + t_w_c0, fi)
            px_true, depth = project(tw[fi], fi)
            assert depth > 0, f"{name}/{hand}: GT depth {depth} <= 0 at frame {fi}"
            depths.append(depth)
            errs.append(float(np.linalg.norm(px_recon - px_true)))
    print(f"  [{name}] reprojection OK: max px err={max(errs):.2e} "
          f"(n={len(errs)}), depth range [{min(depths):.3f}, {max(depths):.3f}] m")
    assert max(errs) < 1e-3, f"{name}: reprojection error too large: {max(errs)}"


# --------------------------------------------------------------------------- #
# Tests
# --------------------------------------------------------------------------- #
def test_openaoe(tmp: Path, gt) -> np.ndarray:
    from data.openaoe.openaoe_dataset import OpenAoEMotusDataset

    root = tmp / "openaoe"
    write_openaoe_fixture(root, gt)
    ds = OpenAoEMotusDataset(dataset_dir=str(root), num_video_frames=F, t5_mode="none",
                             vlm_checkpoint_path=None)
    assert len(ds) == 1, f"expected 1 episode, got {len(ds)}"

    frame_start = 10
    dbg = ds.get_debug_sample(0, frame_start, load_video=False)
    assert dbg["error"] is None, f"OpenAoE extraction failed: {dbg['error']}"
    win = dbg["window_indices"]
    action, state, mask = dbg["action"], dbg["state"], dbg["action_valid_mask"]

    check_layout("OpenAoE", action, state, mask)
    check_semantics("OpenAoE", action, state, gt, win)
    check_reprojection("OpenAoE", action, state, gt, win, dbg["K"])

    # Agreement with a direct call to the shared math (the definition of
    # "same action space" across datasets).
    ref_a, ref_s, ref_m = reference_unified_eef(gt, win)
    assert np.allclose(action, ref_a, atol=1e-6), "OpenAoE action != shared-math reference"
    assert np.allclose(state, ref_s, atol=1e-6), "OpenAoE state != shared-math reference"
    assert np.array_equal(mask, ref_m.astype(bool)), "OpenAoE mask != shared-math reference"
    print("  [OpenAoE] matches shared unified-eef reference exactly")

    # Full __getitem__ contract (includes real video decode).
    sample = ds[0]
    assert sample is not None, "OpenAoE __getitem__ returned None"
    assert sample["first_frame"].shape == (3, 384, 320), sample["first_frame"].shape
    assert sample["video_frames"].shape == (F, 3, 384, 320), sample["video_frames"].shape
    assert sample["action_sequence"].shape == (F, 16)
    assert sample["initial_state"].shape == (16,)
    assert sample["action_valid_mask"].shape == (F, 16)
    print(f"  [OpenAoE] __getitem__ OK: {sorted(sample.keys())}")
    return action


def test_egoverse(tmp: Path, gt) -> np.ndarray:
    from data.egoverse.egoverse_dataset import EgoVerseMotusDataset

    root = tmp / "egoverse"
    write_egoverse_fixture(root, gt)

    # Inject the pose arrays that would otherwise come from the Zarr v3 store.
    arrays = {
        "obs_head_pose": poses7_from_Rt(gt["R_w_c"], gt["t_w_c"]),
        "left.obs_wrist_pose": poses7_from_Rt(gt["R_w_l"], gt["t_w_l"]),
        "right.obs_wrist_pose": poses7_from_Rt(gt["R_w_r"], gt["t_w_r"]),
    }
    # Zero rows encode "no data" in the real stores; mirror the validity gaps.
    arrays["left.obs_wrist_pose"][~gt["valid_l"]] = 0.0
    arrays["right.obs_wrist_pose"][~gt["valid_r"]] = 0.0
    EgoVerseMotusDataset._read_array = lambda self, zarr_path, name: arrays[name]

    ds = EgoVerseMotusDataset(dataset_dir=str(root), num_video_frames=F, t5_mode="none",
                              vlm_checkpoint_path=None)
    assert len(ds) == 1, f"expected 1 episode, got {len(ds)}"

    frame_start = 10
    dbg = ds.get_debug_sample(0, frame_start, load_video=False)
    assert dbg["error"] is None, f"EgoVerse extraction failed: {dbg['error']}"
    win = dbg["window_indices"]
    action, state, mask = dbg["action"], dbg["state"], dbg["action_valid_mask"]

    check_layout("EgoVerse", action, state, mask)
    check_semantics("EgoVerse", action, state, gt, win)
    check_reprojection("EgoVerse", action, state, gt, win, dbg["K"])

    ref_a, ref_s, ref_m = reference_unified_eef(gt, win)
    assert np.allclose(action, ref_a, atol=1e-6), "EgoVerse action != shared-math reference"
    assert np.allclose(state, ref_s, atol=1e-6), "EgoVerse state != shared-math reference"
    assert np.array_equal(mask, ref_m.astype(bool)), "EgoVerse mask != shared-math reference"
    print("  [EgoVerse] matches shared unified-eef reference exactly")

    # The fixture is written in the VERIFIED wxyz order and the dataset default
    # is wxyz, so the default path must be the correct one; forcing the (wrong,
    # as-documented) xyzw must visibly change the result.
    assert ds.quat_order == "wxyz", f"default quat_order regressed to {ds.quat_order}"
    ds_x = EgoVerseMotusDataset(dataset_dir=str(root), num_video_frames=F, t5_mode="none",
                                vlm_checkpoint_path=None, quat_order="xyzw",
                                index_cache_path=str(tmp / "egoverse_xyzw_idx.json"))
    a_x = ds_x.get_debug_sample(0, frame_start)["action"]
    assert not np.allclose(a_x, action, atol=1e-3), \
        "quat_order='xyzw' produced identical output — the switch is not wired in"
    print("  [EgoVerse] default quat_order='wxyz' is the verified one; xyzw differs")

    # Pose sidecar: training envs without zarr>=3 must get identical numbers.
    cache_dir = tmp / "egoverse_pose_cache"
    cache_dir.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(cache_dir / f"{ds.episodes[0]['episode_name']}.poses.npz",
                        head_pose=arrays["obs_head_pose"].astype(np.float32),
                        left_pose=arrays["left.obs_wrist_pose"].astype(np.float32),
                        right_pose=arrays["right.obs_wrist_pose"].astype(np.float32))
    ds_c = EgoVerseMotusDataset(dataset_dir=str(root), num_video_frames=F, t5_mode="none",
                                vlm_checkpoint_path=None, pose_cache_dir=str(cache_dir),
                                require_pose_cache=True,
                                index_cache_path=str(tmp / "egoverse_cache_idx.json"))
    # Make the zarr path explode so we prove the sidecar is what gets read.
    ds_c._read_array = lambda *a, **k: (_ for _ in ()).throw(
        AssertionError("zarr path used despite an available pose cache"))
    a_c = ds_c.get_debug_sample(0, frame_start)["action"]
    assert np.allclose(a_c, action, atol=1e-5), "pose cache disagrees with the zarr path"
    print(f"  [EgoVerse] pose sidecar OK: zarr-free read matches "
          f"(max diff={np.max(np.abs(a_c - action)):.2e})")

    sample = ds[0]
    assert sample is not None, "EgoVerse __getitem__ returned None"
    assert sample["first_frame"].shape == (3, 384, 320), sample["first_frame"].shape
    assert sample["video_frames"].shape == (F, 3, 384, 320), sample["video_frames"].shape
    assert sample["action_sequence"].shape == (F, 16)
    print(f"  [EgoVerse] __getitem__ OK: {sorted(sample.keys())}")
    return action


def test_registry_wiring(tmp: Path):
    """Build both datasets through data/dataset.py the way training does.

    This is what catches a mis-forwarded config key (the registry copies an
    explicit allow-list, so a typo silently drops the setting instead of
    raising).
    """
    from omegaconf import OmegaConf
    from data.dataset import create_dataset

    def base_cfg(dataset_block):
        return OmegaConf.create({
            "common": {"num_video_frames": F, "video_height": 384, "video_width": 320,
                       "global_downsample_rate": 1, "video_action_freq_ratio": 1,
                       "action_dim": 16, "state_dim": 16},
            "model": {"vlm": {"checkpoint_path": None}},
            "dataset": dataset_block,
        })

    # 1) standalone entries
    cfg = base_cfg({
        "type": "openaoe", "dataset_dir": str(tmp / "openaoe"),
        "action_mode": "unified_eef_camera_delta_wrist16",
        "video_source": "raw", "frame_stride": 1,
        "params": {"t5_mode": "none"},
    })
    ds = create_dataset(cfg, val=False)
    assert ds.video_source == "raw", "openaoe: video_source not forwarded by the registry"
    assert len(ds) == 1
    print(f"  [registry] type=openaoe OK ({len(ds)} ep, video_source={ds.video_source})")

    cfg = base_cfg({
        "type": "egoverse", "dataset_dir": str(tmp / "egoverse"),
        "action_mode": "unified_eef_camera_delta_wrist16",
        "subset": "aria", "hand_pose_key": "obs_wrist_pose", "quat_order": "xyzw",
        "frame_stride": 1, "index_cache_path": str(tmp / "reg_egoverse_idx.json"),
        "params": {"t5_mode": "none"},
    })
    ds = create_dataset(cfg, val=False)
    assert ds.quat_order == "xyzw" and ds.hand_pose_key == "obs_wrist_pose", \
        "egoverse: convention keys not forwarded by the registry"
    assert len(ds) == 1
    print(f"  [registry] type=egoverse OK ({len(ds)} ep, hand_pose_key={ds.hand_pose_key})")

    # 2) the cross_dataset_mixed path used by the training config
    cfg = base_cfg({
        "type": "cross_dataset_mixed",
        "action_mode": "unified_eef_camera_delta_wrist16",
        "auto_weight": True,
        "datasets": [
            {"type": "openaoe", "dataset_dir": str(tmp / "openaoe"),
             "video_source": "undistorted", "frame_stride": 1,
             "index_cache_path": str(tmp / "mix_openaoe_idx.json")},
            {"type": "egoverse", "dataset_dir": str(tmp / "egoverse"),
             "subset": "aria", "quat_order": "xyzw", "frame_stride": 1,
             "index_cache_path": str(tmp / "mix_egoverse_idx.json")},
        ],
        "params": {"t5_mode": "none"},
    })
    mixed = create_dataset(cfg, val=False)
    assert len(mixed.datasets) == 2, f"expected 2 sub-datasets, got {len(mixed.datasets)}"
    sample = mixed[0]
    assert sample is not None and sample["action_sequence"].shape == (F, 16)
    print(f"  [registry] type=cross_dataset_mixed OK "
          f"(weights={mixed.weights}, action={tuple(sample['action_sequence'].shape)})")


def test_visualization_tool(tmp: Path):
    """Smoke-test tools/visualize_new_human_unified_eef.py on the OpenAoE fixture.

    The fixture video is a synthetic colour ramp, so the overlay cannot be
    judged visually here; what this asserts is that the tool runs end to end and
    reports a ~zero dataset-vs-GT pixel gap, which is the number a reviewer
    reads first on real data.
    """
    import subprocess

    out_dir = tmp / "viz_out"
    cmd = [
        sys.executable, str(REPO_ROOT / "tools" / "visualize_new_human_unified_eef.py"),
        "--dataset", "openaoe", "--data-root", str(tmp / "openaoe"),
        "--output-dir", str(out_dir), "--num-samples", "1", "--view", "original",
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
    assert proc.returncode == 0, f"viz tool failed:\n{proc.stdout}\n{proc.stderr}"

    summary = json.load(open(out_dir / "summary.json"))
    assert summary["samples"], f"viz tool produced no samples:\n{proc.stderr}"
    s = summary["samples"][0]
    px = s["dataset_vs_gt_pixel_max"]
    recon = s["dataset_world_recon_max_err"]
    assert px is not None and px < 1e-3, f"viz tool reports pixel gap {px}"
    assert recon is not None and recon < 1e-6, f"viz tool reports world recon error {recon}"
    sdir = out_dir / s["sample_id"]
    for f in ("debug.json", "sample_metadata.json", "overlay_original.mp4", "preview.png"):
        assert (sdir / f).exists(), f"viz tool did not write {f}"
    print(f"  [viz tool] OK: dataset_vs_gt_pixel_max={px:.2e}, "
          f"world_recon_max={recon:.2e}, artifacts={sorted(p.name for p in sdir.iterdir())}")


def main():
    gt = make_ground_truth()
    tmp = Path(tempfile.mkdtemp(prefix="unified_eef_selftest_"))
    print(f"fixtures: {tmp}\n")
    try:
        print("== OpenAoE ==")
        a_openaoe = test_openaoe(tmp, gt)
        print("\n== EgoVerse ==")
        a_egoverse = test_egoverse(tmp, gt)

        print("\n== cross-dataset agreement ==")
        # Same physical trajectory expressed in each dataset's native on-disk
        # format must yield the same 16-D action.
        assert np.allclose(a_openaoe, a_egoverse, atol=1e-6), \
            "EgoVerse and OpenAoE disagree on the same physical trajectory"
        print(f"  identical 16-D action from both formats "
              f"(max diff={np.max(np.abs(a_openaoe - a_egoverse)):.2e})")

        print("\n== registry / config wiring ==")
        test_registry_wiring(tmp)

        print("\n== visualization tool ==")
        test_visualization_tool(tmp)

        print("\nALL CHECKS PASSED")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    main()

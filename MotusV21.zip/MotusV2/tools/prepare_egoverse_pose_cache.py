#!/usr/bin/env python3
"""
prepare_egoverse_pose_cache.py
==============================

One-off pre-conversion so EgoVerse can be trained in a Python 3.10 environment.

EgoVerse episodes are **Zarr v3** stores, which require ``zarr>=3`` and hence
Python >= 3.11.  The MotusV2 training environment is on Python 3.10 and cannot
install it.  Only a handful of tiny arrays are actually needed for the
``unified_eef_camera_delta_wrist16`` action (the video comes from the mp4), so
this script reads them once in an environment that *does* have zarr and writes
a small ``<episode>.poses.npz`` sidecar per episode:

    head_pose  : (N, 7)  float32   obs_head_pose            (camera -> world)
    left_pose  : (N, 7)  float32   left.<hand_pose_key>     (EEF -> world)
    right_pose : (N, 7)  float32   right.<hand_pose_key>    (EEF -> world)

``EgoVerseMotusDataset`` prefers the sidecar and only falls back to zarr when it
is absent, so after running this the training path never imports zarr.

Size: ~7 floats x 3 arrays x N frames x 4 bytes.  At the ARIA average of ~4.3k
frames that is ~0.4 MB per episode, i.e. ~1 GB for all ~2.5k ARIA episodes
(against 0.59 TB of raw data).

Run it with an interpreter that has zarr>=3 (e.g. the base conda env), NOT
necessarily the training env::

    python tools/prepare_egoverse_pose_cache.py \
        --data-root /path/to/EgoVerse --subset aria

    # write the sidecars somewhere else (e.g. when the data root is read-only)
    python tools/prepare_egoverse_pose_cache.py \
        --data-root /path/to/EgoVerse --subset aria \
        --out-dir /cache/egoverse_pose_cache

Then point the dataset at them with ``pose_cache_dir`` (omit if the sidecars sit
next to the .zarr stores) and optionally ``require_pose_cache: true`` to fail
loudly instead of silently trying to import zarr.
"""

import argparse
import json
import os
import sys
import traceback
from pathlib import Path
from typing import Optional

import numpy as np

HUMAN_EMBODIMENTS = ("human_bimanual", "human_right_arm", "human_left_arm")

# Streams needed by the unified-EEF action. Cached under stable output names so
# the dataset does not need to know which hand_pose_key was used.
POSE_STREAMS = {
    "head_pose": "obs_head_pose",
    "left_pose": "left.{hand_pose_key}",
    "right_pose": "right.{hand_pose_key}",
}


def read_root_attrs(zarr_path: Path) -> dict:
    with open(zarr_path / "zarr.json", "r", encoding="utf-8") as f:
        return json.load(f).get("attributes", {}) or {}


def convert_episode(zarr_dir: Path, out_path: Path, hand_pose_key: str,
                    overwrite: bool) -> str:
    """Returns one of: 'written', 'skipped_exists', 'skipped_embodiment',
    'skipped_empty', 'skipped_no_head'."""
    if out_path.exists() and not overwrite:
        return "skipped_exists"

    attrs = read_root_attrs(zarr_dir)
    embodiment = str(attrs.get("embodiment", ""))
    if embodiment not in HUMAN_EMBODIMENTS:
        return "skipped_embodiment"
    n = int(attrs.get("total_frames", 0) or 0)
    if n <= 0:
        return "skipped_empty"

    features = attrs.get("features", {}) or {}
    import zarr  # required only here

    payload = {}
    for out_key, tmpl in POSE_STREAMS.items():
        name = tmpl.format(hand_pose_key=hand_pose_key)
        if name not in features:
            continue
        arr = np.asarray(zarr.open(str(zarr_dir / name), mode="r")[:])
        payload[out_key] = arr[:n].astype(np.float32)

    if "head_pose" not in payload:
        return "skipped_no_head"
    if "left_pose" not in payload and "right_pose" not in payload:
        return "skipped_empty"

    out_path.parent.mkdir(parents=True, exist_ok=True)
    tmp = out_path.with_suffix(out_path.suffix + f".tmp{os.getpid()}")
    np.savez_compressed(tmp, **payload)
    os.replace(tmp, out_path)
    return "written"


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--data-root", required=True, help="EgoVerse root (containing aria/ and eva/)")
    ap.add_argument("--subset", default="aria", help="only 'aria' is used for unified EEF")
    ap.add_argument("--hand-pose-key", default="obs_wrist_pose",
                    choices=["obs_wrist_pose", "obs_ee_pose"])
    ap.add_argument("--out-dir", default=None,
                    help="where to write sidecars; default: next to each .zarr store")
    ap.add_argument("--limit", type=int, default=None, help="convert at most N episodes")
    ap.add_argument("--overwrite", action="store_true")
    args = ap.parse_args()

    try:
        import zarr  # noqa: F401
    except ImportError:
        sys.exit("This script needs zarr>=3 (Python>=3.11). Run it with an interpreter "
                 "that has it, e.g. the base conda env; the training env does not need it.")

    subset_dir = Path(args.data_root) / args.subset
    if not subset_dir.is_dir():
        subset_dir = Path(args.data_root)
    if not subset_dir.is_dir():
        sys.exit(f"subset dir not found: {subset_dir}")

    out_dir = Path(args.out_dir) if args.out_dir else None
    stores = sorted(subset_dir.glob("*.zarr"))
    if args.limit:
        stores = stores[: args.limit]
    print(f"found {len(stores)} .zarr stores under {subset_dir}")

    counts = {}
    failures = []
    for i, zarr_dir in enumerate(stores, 1):
        name = zarr_dir.name[: -len(".zarr")]
        out_path = (out_dir / f"{name}.poses.npz") if out_dir else \
            (zarr_dir.parent / f"{name}.poses.npz")
        try:
            status = convert_episode(zarr_dir, out_path, args.hand_pose_key, args.overwrite)
        except Exception as e:
            status = "error"
            failures.append(f"{name}: {type(e).__name__}: {e}")
            if len(failures) <= 3:
                traceback.print_exc()
        counts[status] = counts.get(status, 0) + 1
        if i % 200 == 0 or i == len(stores):
            print(f"  [{i}/{len(stores)}] {counts}")

    print("\nsummary:", counts)
    if failures:
        print(f"{len(failures)} failures, first few:")
        for f in failures[:5]:
            print("  " + f)
    written = counts.get("written", 0) + counts.get("skipped_exists", 0)
    print(f"\nusable sidecars: {written}")
    if out_dir:
        print(f"point the dataset at them with:  pose_cache_dir: \"{out_dir}\"")
    else:
        print("sidecars sit next to the .zarr stores; no pose_cache_dir needed")


if __name__ == "__main__":
    main()

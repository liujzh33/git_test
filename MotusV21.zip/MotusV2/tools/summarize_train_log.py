#!/usr/bin/env python3
"""Condense a full MotusV2 training log into a compact Markdown report.

A 90k-step run produces hundreds of MB of logs that cannot be moved between
clusters. This parser keeps only what a training diagnosis needs: loss curves
downsampled into step buckets, every validation block verbatim, the epoch and
learning-rate progression, and any anomaly lines (NaN, large gradients,
resumes, OOM). The output is a single Markdown file small enough to paste into
a chat.

Usage:
    python tools/summarize_train_log.py <log> [<log> ...] -o report.md

Multiple files are concatenated in the order given, which is what you want when
a run was resumed and its output landed in several files.
"""

from __future__ import annotations

import argparse
import bz2
import glob
import gzip
import lzma
import pathlib
import re
import statistics
from collections import Counter, defaultdict
from typing import Iterator

# [Rank 0] ... - Step 1000/100000 (Epoch 15), Loss: 0.3353 (Video: 0.1595,
# Action: 0.1758, Token: 0.0000), LR(main/wan/vlm)=4.95e-05/..., Time: 3.01s
STEP_RE = re.compile(
    r"Step\s+(?P<step>\d+)/(?P<total>\d+)\s+\(Epoch\s+(?P<epoch>\d+)\),\s+"
    r"Loss:\s+(?P<loss>[-\d.eE+]+)\s+\("
    r"Video:\s+(?P<video>[-\d.eE+]+),\s+"
    r"Action:\s+(?P<action>[-\d.eE+]+),\s+"
    r"Token:\s+(?P<token>[-\d.eE+]+)\)"
    r"(?:.*?LR\(main/wan/vlm\)=(?P<lr_main>[-\d.eE+]+)/(?P<lr_wan>[-\d.eE+]+)/(?P<lr_vlm>[-\d.eE+]+))?"
    r"(?:.*?Time:\s+(?P<time>[-\d.eE+]+)s)?"
)
VAL_HEADER_RE = re.compile(r"Validation\s+-\s+Step\s+(?P<step>\d+)")
# "INFO -   video_mse: 0.0250", one metric per line. The run of spaces after the
# logger separator is what distinguishes a metric from an ordinary INFO message.
VAL_METRIC_RE = re.compile(
    r"INFO\s*-\s{2,}(?P<key>[a-zA-Z0-9_]+):\s+"
    r"(?P<val>[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?|nan|inf|-inf)\s*$"
)
TASK_SAMPLING_RE = re.compile(r"Observed task sampling over (?P<n>\d+) rank-0 samples; top=(?P<top>.*)$")

# Lines worth surfacing verbatim; each entry is (label, compiled pattern).
ANOMALY_PATTERNS = [
    ("nan_inf", re.compile(r"NaN|Inf\b|inf detected|loss_is_bad|non-finite", re.I)),
    ("large_grad", re.compile(r"large.?grad|grad_norm\s*[>=]|gradient norm", re.I)),
    ("oom", re.compile(r"out of memory|OutOfMemoryError|CUDA error", re.I)),
    ("resume", re.compile(r"Loading checkpoint from|Resetting scheduler|Checkpoint loaded successfully", re.I)),
    ("skip", re.compile(r"skipping step|skipped|zero_grad due to", re.I)),
    ("error", re.compile(r"\bERROR\b|Traceback|RuntimeError", re.I)),
]

# Startup lines that pin down the contract the run actually used.
CONTEXT_PATTERNS = [
    re.compile(r"Loaded config from|Config File:"),
    re.compile(r"Dataset type:|Dataset:|Dataloader creation took|Multi-dataset training"),
    re.compile(r"Training mode:|Action chunk size:|Video frames:|Action dim:"),
    re.compile(r"WAN checkpoint path:|Gradient checkpointing:|VLM causal attention:"),
    re.compile(r"Initialized FlowMatchScheduler"),
    re.compile(r"Gradient accumulation steps:|Trainer initialized on rank"),
    re.compile(r"world_size|World size|num_processes", re.I),
    re.compile(r"total (?:trainable )?param|Trainable param", re.I),
    re.compile(r"best_action_l2|Best action L2"),
]


def open_maybe_compressed(path: pathlib.Path):
    if path.suffix == ".gz":
        return gzip.open(path, "rt", errors="replace")
    if path.suffix == ".bz2":
        return bz2.open(path, "rt", errors="replace")
    if path.suffix in (".xz", ".lzma"):
        return lzma.open(path, "rt", errors="replace")
    return open(path, "rt", errors="replace")


def iter_lines(paths: list[pathlib.Path]) -> Iterator[str]:
    for path in paths:
        with open_maybe_compressed(path) as fh:
            yield from fh


def fnum(text: str | None) -> float | None:
    if text is None:
        return None
    try:
        return float(text)
    except ValueError:
        return None


def parse(paths: list[pathlib.Path]) -> dict:
    steps: list[dict] = []
    validations: list[dict] = []
    task_sampling: list[tuple[int, int, str]] = []
    anomalies: dict[str, list[tuple[int, str]]] = defaultdict(list)
    context: list[str] = []
    seen_context: set[str] = set()

    current_val: dict | None = None
    last_step = 0

    for raw in iter_lines(paths):
        line = raw.rstrip("\n")

        m = STEP_RE.search(line)
        if m:
            last_step = int(m.group("step"))
            steps.append({
                "step": last_step,
                "total": int(m.group("total")),
                "epoch": int(m.group("epoch")),
                "loss": fnum(m.group("loss")),
                "video": fnum(m.group("video")),
                "action": fnum(m.group("action")),
                "token": fnum(m.group("token")),
                "lr_main": fnum(m.group("lr_main")),
                "lr_wan": fnum(m.group("lr_wan")),
                "lr_vlm": fnum(m.group("lr_vlm")),
                "time": fnum(m.group("time")),
            })
            # A step line always terminates a validation block.
            if current_val is not None:
                validations.append(current_val)
                current_val = None
            continue

        m = VAL_HEADER_RE.search(line)
        if m:
            if current_val is not None:
                validations.append(current_val)
            current_val = {"step": int(m.group("step")), "metrics": {}}
            continue

        m = VAL_METRIC_RE.search(line)
        if m and current_val is not None:
            current_val["metrics"][m.group("key")] = fnum(m.group("val"))
            continue

        m = TASK_SAMPLING_RE.search(line)
        if m:
            task_sampling.append((last_step, int(m.group("n")), m.group("top")))
            continue

        for label, pat in ANOMALY_PATTERNS:
            if pat.search(line):
                anomalies[label].append((last_step, line.strip()[:400]))
                break

        for pat in CONTEXT_PATTERNS:
            if pat.search(line):
                trimmed = line.strip()[:400]
                # Startup banners repeat once per rank; keep one copy of each.
                if trimmed not in seen_context:
                    seen_context.add(trimmed)
                    context.append(trimmed)
                break

    if current_val is not None:
        validations.append(current_val)

    return {
        "steps": steps,
        "validations": validations,
        "task_sampling": task_sampling,
        "anomalies": anomalies,
        "context": context,
    }


def bucket_stats(steps: list[dict], bucket: int) -> list[dict]:
    buckets: dict[int, list[dict]] = defaultdict(list)
    for s in steps:
        buckets[s["step"] // bucket].append(s)

    rows = []
    for key in sorted(buckets):
        group = buckets[key]

        def agg(field: str, fn):
            vals = [g[field] for g in group if g.get(field) is not None]
            return fn(vals) if vals else None

        rows.append({
            "lo": key * bucket,
            "hi": key * bucket + bucket - 1,
            "n": len(group),
            "epoch": agg("epoch", max),
            "loss": agg("loss", statistics.mean),
            "video": agg("video", statistics.mean),
            "action": agg("action", statistics.mean),
            "action_min": agg("action", min),
            "action_max": agg("action", max),
            "token": agg("token", statistics.mean),
            "lr_main": agg("lr_main", statistics.mean),
            "time": agg("time", statistics.median),
        })
    return rows


def fmt(v, spec=".4f") -> str:
    return "-" if v is None else format(v, spec)


def render(data: dict, bucket: int, sources: list[pathlib.Path]) -> str:
    steps = data["steps"]
    out: list[str] = []
    out.append("# MotusV2 training log summary")
    out.append("")
    out.append("Generated by `tools/summarize_train_log.py`.")
    out.append("")
    out.append("## Sources")
    out.append("")
    for p in sources:
        try:
            size_mb = p.stat().st_size / 1e6
            out.append(f"- `{p}` ({size_mb:.1f} MB)")
        except OSError:
            out.append(f"- `{p}`")
    out.append("")

    if not steps:
        out.append("**No step lines matched.** The log format differs from the expected")
        out.append("`Step N/M (Epoch E), Loss: ... (Video: ..., Action: ..., Token: ...)`.")
        out.append("Paste ~30 raw lines so the parser can be adjusted.")
        return "\n".join(out)

    first, last = steps[0], steps[-1]
    times = [s["time"] for s in steps if s.get("time")]
    out.append("## Run overview")
    out.append("")
    out.append(f"- Step lines parsed: {len(steps)}")
    out.append(f"- Step range: {first['step']} -> {last['step']} (target {last['total']})")
    out.append(f"- Epoch range: {first['epoch']} -> {last['epoch']}")
    if last["epoch"] and last["step"]:
        out.append(f"- Steps per epoch (implied): {last['step'] / max(last['epoch'], 1):.1f}")
    if times:
        out.append(f"- Step time: median {statistics.median(times):.2f}s, "
                   f"p95 {sorted(times)[int(len(times) * 0.95)]:.2f}s, max {max(times):.2f}s")
    # A step number that goes backwards means the run was resumed.
    restarts = [steps[i]["step"] for i in range(1, len(steps)) if steps[i]["step"] < steps[i - 1]["step"]]
    out.append(f"- Step-number regressions (resume markers): {len(restarts)}"
               + (f" at steps {restarts[:10]}" if restarts else ""))
    out.append("")

    out.append(f"## Training curves (mean per {bucket}-step bucket)")
    out.append("")
    out.append("| steps | n | epoch | loss | video | action | action_min | action_max | token | lr_main | t/step |")
    out.append("|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|")
    for r in bucket_stats(steps, bucket):
        out.append(
            f"| {r['lo']}-{r['hi']} | {r['n']} | {r['epoch']} | {fmt(r['loss'])} | {fmt(r['video'])} | "
            f"{fmt(r['action'])} | {fmt(r['action_min'])} | {fmt(r['action_max'])} | {fmt(r['token'])} | "
            f"{fmt(r['lr_main'], '.2e')} | {fmt(r['time'], '.2f')} |"
        )
    out.append("")

    vals = data["validations"]
    out.append("## Validation blocks")
    out.append("")
    if not vals:
        out.append("None found.")
    else:
        keys: list[str] = []
        for v in vals:
            for k in v["metrics"]:
                if k not in keys:
                    keys.append(k)
        out.append("| step | " + " | ".join(keys) + " |")
        out.append("|---:|" + "---:|" * len(keys))
        for v in vals:
            cells = [fmt(v["metrics"].get(k)) for k in keys]
            out.append(f"| {v['step']} | " + " | ".join(cells) + " |")
    out.append("")

    ts = data["task_sampling"]
    out.append("## Task sampling distribution")
    out.append("")
    if not ts:
        out.append("None found.")
    else:
        out.append("First, middle, and last observations:")
        out.append("")
        picks = [ts[0]] + ([ts[len(ts) // 2]] if len(ts) > 2 else []) + ([ts[-1]] if len(ts) > 1 else [])
        for step, n, top in picks:
            out.append(f"- step {step}, {n} rank-0 samples: {top[:600]}")
    out.append("")

    out.append("## Anomalies")
    out.append("")
    anomalies = data["anomalies"]
    if not anomalies:
        out.append("None matched.")
    else:
        for label, entries in anomalies.items():
            out.append(f"### {label} ({len(entries)} lines)")
            out.append("")
            counts = Counter(e[1] for e in entries)
            for text, count in counts.most_common(12):
                steps_hit = [str(s) for s, t in entries if t == text][:6]
                out.append(f"- x{count} (steps {', '.join(steps_hit)}): `{text}`")
            out.append("")
    out.append("")

    out.append("## Startup / context lines")
    out.append("")
    for line in data["context"][:120]:
        out.append(f"- `{line}`")
    out.append("")

    return "\n".join(out)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("logs", nargs="+", help="log files; globs and .gz/.bz2/.xz are accepted")
    ap.add_argument("-o", "--output", default="train_log_summary.md")
    ap.add_argument("--bucket", type=int, default=1000, help="step-bucket width for the curve table")
    args = ap.parse_args()

    paths: list[pathlib.Path] = []
    for pattern in args.logs:
        matches = sorted(glob.glob(pattern))
        if not matches:
            raise SystemExit(f"no file matched: {pattern}")
        paths.extend(pathlib.Path(m) for m in matches)

    data = parse(paths)
    report = render(data, args.bucket, paths)
    pathlib.Path(args.output).write_text(report, encoding="utf-8")
    print(f"wrote {args.output} ({len(report) / 1000:.1f} KB), "
          f"{len(data['steps'])} step lines, {len(data['validations'])} validation blocks")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

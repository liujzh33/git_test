#!/bin/bash
# MotusV2 inference client launcher — runs on the robot-side machine (no GPU).
#
# Captures images, sends them to the 5090 GPU server for inference, receives
# action chunks, and executes them on the G1 robot at 30Hz.
#
# The GPU box (192.168.0.180) cannot expose a port directly, so the client talks
# to a local end of an SSH tunnel. Keep this running in another terminal:
#
#   ssh -p 34134 -i /path/to/id_ed25519_5090 \
#     -o ServerAliveInterval=30 -o ServerAliveCountMax=3 \
#     -N -L 127.0.0.1:15555:192.168.0.180:5555 \
#     root@116.63.180.90
#
# Usage:
#   bash inference_motusv2_client.sh
#
# Before running:
#   1. Point LEROBOT_ROOT at the unitree_lerobot checkout.
#   2. Make sure the inference server is already up on the GPU box.
#   3. Set UNITREE_DDSINTERFACE to the robot-facing NIC (see `ip link`).

set -Eeuo pipefail

# ==================== ROOT DIRS ====================
SCRIPTS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUNDLE_ROOT="$(dirname "$SCRIPTS_DIR")"
LEROBOT_ROOT="${LEROBOT_ROOT:-/home/robo/codes/unitree_lerobot/}"
# ===================================================

export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
cd "$LEROBOT_ROOT"
export PYTHONPATH="$LEROBOT_ROOT":"$SCRIPTS_DIR"

export UNITREE_DDSINTERFACE="${UNITREE_DDSINTERFACE:-eth0}"

# ==================== PATHS ====================
# --- Local end of the SSH tunnel to the GPU box ---
SERVER_HOST="${SERVER_HOST:-127.0.0.1}"
SERVER_PORT="${SERVER_PORT:-15555}"

CONFIG_PATH="${CONFIG_PATH:-$BUNDLE_ROOT/configs/eai_pick_place_wan_vlm_mask.yaml}"

# Must match the server's instruction (it keys the cached T5 embedding).
INSTRUCTION="${INSTRUCTION:-Pick up the marker and the plush toy and place them into the right basket, then pick up the empty water bottle and the draft paper and place them into the left basket}"

# Dataset root for the initial pose (empty = start from the robot's current pose)
DATASET_ROOT="${DATASET_ROOT:-}"
# ===============================================

# ==================== INFERENCE OPTIONS ====================
NUM_INFERENCE_STEPS="${NUM_INFERENCE_STEPS:-10}"
ACTION_INTERP_FACTOR="${ACTION_INTERP_FACTOR:-0}"
ASYNC_INFERENCE="${ASYNC_INFERENCE:-1}"
ASYNC_TRIGGER="${ASYNC_TRIGGER:-32}"
# ===========================================================

# ==================== ROBOT OPTIONS ====================
ARM="${ARM:-G1_29}"
EE="${EE:-dex1}"
FREQUENCY="${FREQUENCY:-30}"
IMAGE_HOST="${IMAGE_HOST:-192.168.123.164}"
# =======================================================

PYTHON="${PYTHON:-python}"

EXTRA_FLAGS=""
if [ "$ASYNC_INFERENCE" = "1" ]; then
    EXTRA_FLAGS="$EXTRA_FLAGS --async_inference"
fi

echo "[client] Starting MotusV2 remote inference client"
echo "[client] Server:     tcp://$SERVER_HOST:$SERVER_PORT (SSH tunnel -> 192.168.0.180:5555)"
echo "[client] Image host: $IMAGE_HOST"
echo "[client] Config:     $CONFIG_PATH"
echo "[client] Async:      $ASYNC_INFERENCE (trigger=$ASYNC_TRIGGER)"

"$PYTHON" "$SCRIPTS_DIR"/motus_inference_client.py \
    --arm="$ARM" \
    --ee="$EE" \
    --frequency="$FREQUENCY" \
    --image_host="$IMAGE_HOST" \
    --server_host="$SERVER_HOST" \
    --server_port="$SERVER_PORT" \
    --config_path="$CONFIG_PATH" \
    --root="$DATASET_ROOT" \
    --instruction="$INSTRUCTION" \
    --action_interp_factor="$ACTION_INTERP_FACTOR" \
    --async_trigger="$ASYNC_TRIGGER" \
    $EXTRA_FLAGS

#!/usr/bin/env python3
"""Smoke-test the MotusV2 inference server with a synthetic observation.

Sends the same request shape the robot client sends (384x320x3 stitched image +
16-dim state) and reports the round-trip latency and the returned chunk shape.

    python smoke_test_server.py --host 127.0.0.1 --port 5555
"""

import argparse
import pickle
import time

import numpy as np
import zmq

INSTRUCTION = ("Pick up the marker and the plush toy and place them into the right basket, "
               "then pick up the empty water bottle and the draft paper and place them into "
               "the left basket")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=5555)
    parser.add_argument("--repeat", type=int, default=3)
    parser.add_argument("--timeout", type=int, default=120000, help="recv timeout in ms")
    parser.add_argument("--instruction", default=INSTRUCTION)
    args = parser.parse_args()

    ctx = zmq.Context()
    sock = ctx.socket(zmq.REQ)
    sock.setsockopt(zmq.LINGER, 0)
    sock.setsockopt(zmq.RCVTIMEO, args.timeout)
    sock.connect(f"tcp://{args.host}:{args.port}")
    print(f"connected to tcp://{args.host}:{args.port}")

    rng = np.random.default_rng(0)
    first_frame = rng.integers(0, 256, size=(384, 320, 3), dtype=np.uint8)
    state = np.zeros(16, dtype=np.float32)

    for i in range(args.repeat):
        req = {"first_frame": first_frame, "state": state, "instruction": args.instruction}
        t0 = time.perf_counter()
        sock.send(pickle.dumps(req))
        resp = pickle.loads(sock.recv())
        rtt = (time.perf_counter() - t0) * 1000

        if resp.get("status") != "ok":
            print(f"[{i}] ERROR: {resp.get('message')}")
            return 1
        actions = resp["actions"]
        print(f"[{i}] rtt={rtt:7.1f}ms  server_predict={resp['predict_ms']:7.1f}ms  "
              f"chunk={actions.shape} {actions.dtype}  "
              f"range=[{actions.min():.3f}, {actions.max():.3f}]")

    sock.close()
    ctx.term()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

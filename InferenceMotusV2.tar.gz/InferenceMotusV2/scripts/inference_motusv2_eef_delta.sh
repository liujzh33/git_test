#!/bin/bash
# MotusV2 real-robot inference entry script for G1 — CARTESIAN eef_delta checkpoint.
# This script does NOT modify or depend on the pi0.5 pipeline.
#
# Cartesian variant of inference_motusv2.sh. The model emits 16-dim offsets from
# the pose the chunk was conditioned on; the adapter runs FK on the measured
# joints to build the state, denormalizes, composes the offsets onto that pose
# and runs IK to get joint targets. Config: g1d_pick_kettle_wan_vlm_mask_eef_delta.yaml
#
# Two artifacts belong to the CHECKPOINT, not to the robot, and must be copied
# over with the weights:
#   - the yaml (CONFIG_PATH), which carries action_mode and the chunk geometry
#   - eef_stats.json (EEF_STATS_PATH), the normalization constants
# Without the statistics every action is silently mis-scaled, so the adapter
# refuses to start rather than run without them.

# ==================== ROOT DIRS ====================
# Resolved from this script's own location, so the bundle runs wherever it is
# copied. Override any of them by exporting the variable before calling.
SCRIPTS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUNDLE_ROOT="$(dirname "$SCRIPTS_DIR")"
# unitree_lerobot repo (hardware interfaces) — external, robot-specific.
LEROBOT_ROOT="${LEROBOT_ROOT:-/home/robo/codes/unitree_lerobot/}"
# MODEL CODE dir = the folder that directly contains models/ bak/ utils/.
export MOTUS_POLICY_DIR="${MOTUS_POLICY_DIR:-$BUNDLE_ROOT/policy/MotusWanVlmDirectMaskMotion}"
# ===================================================

export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
cd "$LEROBOT_ROOT"
export PYTHONPATH="$LEROBOT_ROOT":"$SCRIPTS_DIR"


export UNITREE_DDS_INTERFACE="${UNITREE_DDS_INTERFACE:-enx607d09725112}"

# ==================== PATHS (modify these) ====================
CHECKPOINT_PATH="/home/robo/pretrained_models/ckpts/WanVlmMask-G1DPickKettleEps89-DeltaEEF64-standard-43000"
WAN_PATH="/home/robo/pretrained_models/Wan2.2-TI2V-5B"
VLM_PATH="/home/robo/pretrained_models/Qwen3-VL-2B-Instruct"
T5_CACHE_DIR="/home/robo/codes/cache/t5_cache_pick-kettle-and-cup"
DATASET_ROOT="/home/robo/datasets/pick-kettle-and-cup"
# Config and statistics travel inside the bundle, so these need no editing.
CONFIG_PATH="$BUNDLE_ROOT/configs/g1d_pick_kettle_wan_vlm_mask_eef_delta.yaml"
EEF_STATS_PATH="$BUNDLE_ROOT/assets/eef_stats.json"
INSTRUCTION="拿起水杯和茶壶，并倒水"

# G1 URDF for FK/IK. Empty = use the copy in $BUNDLE_ROOT/assets, which is what
# a packaged deployment should do; only set this to force a different model.
# Meshes are not needed: only the kinematic chain is read.
URDF_ROOT=""
# ==============================================================

# ==================== INFERENCE / SMOOTHING OPTIONS ====================
NUM_INFERENCE_STEPS=5

# Which CasADi graph the Unitree IPOPT problem is built from. Both express the
# IDENTICAL NLP (same cost weights, same limits); they differ only in how the
# derivatives are generated, and that is worth ~50x per iteration:
#   sx         hand-written SX kinematic chain. Measured 1.9 ms per solve.
#   pinocchio  cpin.framesForwardKinematics + exact Hessians. Measured 93 ms at
#              best and 670 ms when the target is far, i.e. 100% of a 30 Hz
#              control period, which is what stalled the loop to 1.8 Hz.
#   auto       whatever pinocchio.casadi availability decides (the old behaviour)
# The adapter times a few solves at startup and warns if they miss the budget.
MOTUS_IK_BACKEND=sx

# Reject an IK solution that moves any joint more than this in one control step.
# Unitree IPOPT already penalises ||q - q_last||, so this is a second-line guard.
MAX_JOINT_STEP=0.3

# Action interpolation: 0 = auto = the config's global_downsample_rate.
#   THIS CHECKPOINT SHIPS global_downsample_rate=1, so auto gives factor 1.
#   That is the correct value: the chunk is already 64 raw actions at 30Hz,
#   i.e. 64 exec steps = 2.13s — the same wall-clock chunk the qpos checkpoint
#   produced as 16 actions x factor 4. The async math below is therefore
#   unchanged; only the RAW-step RTC parameters move (see RTC_INFERENCE_DELAY).
#   Interpolation of a Cartesian chunk slerps the rotation dims instead of
#   averaging rotation-vector components, but at factor 1 it is a no-op anyway.
ACTION_INTERP_FACTOR=1

# Async double-buffer: run inference in a background thread while executing.
#
# Currently OFF, deliberately. Serial execution runs one chunk to completion and
# only then predicts, so the arm moves for 2.13 s and then holds for the ~1 s the
# forward pass takes. That pause is obvious, but it is also a clean boundary:
# whatever happens between two pauses is exactly one chunk, with no splicing and
# no cross-chunk guidance in the way. Judge the chunks first; turn this back to 1
# once a single chunk executes smoothly.
# CONTINUITY when re-enabled (C = 64 exec steps, I ~= 15 exec steps @30Hz):
#   ASYNC_TRIGGER >= I           -> 32 >= 15  OK
#   C >= ASYNC_TRIGGER + I       -> 64 >= 47  OK
ASYNC_INFERENCE=0
ASYNC_TRIGGER=32

# RTC needs async, and it blends the previous chunk's leftover into the new one,
# which is one more thing between the model and the arm. Keep it off until the
# chunks themselves look right.
USE_RTC=0
RTC_MODE=inpaint
RTC_DEBUG=0

# ==================== DIAGNOSTIC LOGGING ====================
# 1 = mirror the diagnostics to $DEBUG_LOG_DIR/inference_eef_delta_<stamp>.log
# and a .jsonl sibling for offline analysis; 0 = console only.
#
# Turn this on whenever the arm misbehaves. The log opens with the md5 of the
# config, eef_stats.json and the URDF, then a fingerprint of the model's raw
# output that says which normalizer the CHECKPOINT was actually trained with --
# which is the one failure the file md5s cannot catch, because a mismatched
# checkpoint rescales every action while every shipped file still checks out.
DEBUG_LOG=1
DEBUG_LOG_DIR="$BUNDLE_ROOT/logs"
# INFO is the useful level; DEBUG also captures library chatter.
DEBUG_LOG_LEVEL=INFO
# Log one control step in N (30 = ~1 Hz at 30 Hz control). IK guard events are
# never skipped regardless of this.
DEBUG_LOG_EVERY=30
# ============================================================

# RTC parameters are counted in RAW action tokens, so they scale with
# ACTION_INTERP_FACTOR — and that is exactly what changed against the qpos
# script (4 -> 1). Frozen prefix ~= I / factor = 15 / 1 = 15 raw steps, where the
# qpos checkpoint needed only 4.
RTC_INFERENCE_DELAY=15
# Where prefix weights reach 0. Must exceed RTC_INFERENCE_DELAY so a free region
# exists. 32 of 64 gives frozen[0:15] + blend[15:32] + free[32:64]: the executed
# part is held, then a soft handoff, then half the chunk fully re-planned.
RTC_EXECUTION_HORIZON=32
RTC_MAX_GUIDANCE_WEIGHT=5.0
RTC_SCHEDULE=exp
# ======================================================================

export MOTUS_COMPILE=0
export MOTUS_RTC_DEBUG=$RTC_DEBUG
export MOTUS_IK_BACKEND=$MOTUS_IK_BACKEND

EXTRA_FLAGS=""
if [ "$ASYNC_INFERENCE" = "1" ]; then EXTRA_FLAGS="$EXTRA_FLAGS --async_inference"; fi
if [ "$USE_RTC" = "1" ]; then EXTRA_FLAGS="$EXTRA_FLAGS --rtc"; fi
if [ -n "$URDF_ROOT" ]; then EXTRA_FLAGS="$EXTRA_FLAGS --urdf_root=$URDF_ROOT"; fi
if [ "$DEBUG_LOG" = "1" ]; then
    mkdir -p "$DEBUG_LOG_DIR"
    EXTRA_FLAGS="$EXTRA_FLAGS --debug_log --debug_log_dir=$DEBUG_LOG_DIR"
    EXTRA_FLAGS="$EXTRA_FLAGS --debug_log_level=$DEBUG_LOG_LEVEL --debug_log_every=$DEBUG_LOG_EVERY"
    echo "[debug] diagnostics -> $DEBUG_LOG_DIR/inference_eef_delta_<timestamp>.log(+.jsonl)"
fi

python "$SCRIPTS_DIR"/eval_g1_motus.py \
    --arm=G1_29 \
    --ee=dex1 \
    --frequency=30 \
    --checkpoint_path=$CHECKPOINT_PATH \
    --wan_path=$WAN_PATH \
    --vlm_path=$VLM_PATH \
    --config_path=$CONFIG_PATH \
    --t5_cache_dir=$T5_CACHE_DIR \
    --root=$DATASET_ROOT \
    --num_inference_steps=$NUM_INFERENCE_STEPS \
    --action_interp_factor=$ACTION_INTERP_FACTOR \
    --async_trigger=$ASYNC_TRIGGER \
    --rtc_inference_delay=$RTC_INFERENCE_DELAY \
    --rtc_execution_horizon=$RTC_EXECUTION_HORIZON \
    --rtc_max_guidance_weight=$RTC_MAX_GUIDANCE_WEIGHT \
    --rtc_schedule=$RTC_SCHEDULE \
    --rtc_mode=$RTC_MODE \
    --eef_stats_path=$EEF_STATS_PATH \
    --max_joint_step=$MAX_JOINT_STEP \
    $EXTRA_FLAGS \
    --instruction="$INSTRUCTION"

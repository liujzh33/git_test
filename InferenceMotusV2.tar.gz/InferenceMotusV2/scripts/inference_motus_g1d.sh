#!/bin/bash
# Motus (Stage-3) real-robot inference entry script for G1-D — SYNCHRONOUS, qpos.
#
# NAMING: this serves **Motus** (the trimodal WAN + Action Expert + Understanding
# Expert model in /home/work/wenjj/Motus, post-trained with scripts/train_g1d.sh).
# It is NOT MotusV2 — inference_motusv2.sh and inference_motusv2_eef_delta.sh
# serve that one, with a different checkpoint. Neither touches the other.
#
# The model emits absolute 16-dim qpos targets per chunk with normalization off,
# so a predicted action is a joint command after one reorder: no FK, no IK, no
# eef_stats.json. Chunk length comes from the config:
#   g1d_motus_pick_kettle.yaml / g1d_motus_pour_beans.yaml  48 actions = 1.60 s
#   g1d_motus_mixed.yaml                                    24 actions = 0.80 s
#
# THREE ARTIFACTS BELONG TO THE CHECKPOINT, NOT TO THE ROBOT, and must be copied
# over from the training cluster together with the weights:
#   1. CHECKPOINT_PATH  <checkpoint_dir>/<config>/<run>/checkpoint_step_N/
#                       (the directory holding pytorch_model/mp_rank_00_model_states.pt)
#   2. CONFIG_PATH      the training yaml. All three ship in the bundle; pick the
#                       one matching the run, because it fixes the chunk length.
#   3. T5_CACHE_DIR     <sha1(instruction)>.pt UMT5 embeddings. Motus and MotusV2
#                       use the identical scheme, so the MotusV2 cache already on
#                       the robot serves the same instruction — which is why it
#                       is the default below. Produce a fresh one with
#                         python scripts/precompute_t5_real_robot.py \
#                           --robot-type g1d --dataset-root <dataset>
#
# WAN_PATH and VLM_PATH are shared with the MotusV2 deployment and need no
# copying.

# ==================== ROOT DIRS ====================
# Resolved from this script's own location, so the bundle runs wherever it is
# copied. Override any of them by exporting the variable before calling.
SCRIPTS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUNDLE_ROOT="$(dirname "$SCRIPTS_DIR")"
# unitree_lerobot repo (hardware interfaces) — external, robot-specific.
LEROBOT_ROOT="${LEROBOT_ROOT:-/home/robo/codes/unitree_lerobot/}"
# MODEL CODE dir = the folder that directly contains models/ bak/ utils/ data/.
# Deliberately not MOTUS_POLICY_DIR: that one already selects the MotusV2 policy,
# and both scripts can be sourced in the same shell.
export MOTUS_STAGE3_DIR="${MOTUS_STAGE3_DIR:-$BUNDLE_ROOT/policy/Motus}"
# ===================================================

export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
cd "$LEROBOT_ROOT"
export PYTHONPATH="$LEROBOT_ROOT":"$SCRIPTS_DIR"

export UNITREE_DDS_INTERFACE="${UNITREE_DDS_INTERFACE:-enx607d09725112}"

# models/motus.py -> utils/common.py -> `import deepspeed.comm.comm`, and
# DeepSpeed probes $CUDA_HOME/bin/nvcc at import time even though this path
# compiles no CUDA op. The deployment's PyTorch wheels carry their own CUDA
# runtime and there is usually no system toolkit, so the adapter installs a
# minimal nvcc stub when CUDA_HOME is unusable (same trick as
# Motus/scripts/train_g1d.sh). Set CUDA_HOME here to use a real toolkit instead.
export DS_SKIP_CUDA_CHECK="${DS_SKIP_CUDA_CHECK:-1}"

# ==================== PATHS (modify these) ====================
# >>> FILL IN: the post-trained G1-D checkpoint directory. <<<
# The trainer writes <checkpoint_dir>/<config_stem>/<run_name>/checkpoint_step_N/
CHECKPOINT_PATH="/home/robo/pretrained_models/ckpts/motus-g1d-pick-kettle/checkpoint_step_100000"
# >>> Pick the config matching the run: it fixes the chunk length. <<<
CONFIG_PATH="${CONFIG_PATH:-$BUNDLE_ROOT/configs/g1d_motus_pick_kettle.yaml}"
# CONFIG_PATH="$BUNDLE_ROOT/configs/g1d_motus_pour_beans.yaml"    # chunk 48
# CONFIG_PATH="$BUNDLE_ROOT/configs/g1d_motus_mixed.yaml"         # chunk 24
# Shared with the MotusV2 deployment.
WAN_PATH="${WAN_PATH:-/home/robo/pretrained_models/Wan2.2-TI2V-5B}"
VLM_PATH="${VLM_PATH:-/home/robo/pretrained_models/Qwen3-VL-2B-Instruct}"
# Same sha1(instruction) scheme as MotusV2, so its cache is reused by default.
T5_CACHE_DIR="${T5_CACHE_DIR:-/home/robo/codes/cache/t5_cache_pick-kettle-and-cup}"
# Optional: LeRobot dataset root, used ONLY to move the arm to the pose episode 0
# started from. Empty = start from wherever the arm currently is.
DATASET_ROOT="/home/robo/datasets/pick-kettle-and-cup"

# The instruction has to be the exact string the T5 embedding was precomputed
# for — the cache key is sha1 of it, so one differing character is a startup
# error rather than a silent fallback.
#
# To print the exact strings a dataset was trained on and the cache filename each
# one maps to, run this on the TRAINING machine:
#
#   python -c '
#   import hashlib, json, sys, pathlib
#   p = pathlib.Path(sys.argv[1]) / "meta" / "tasks.jsonl"
#   for line in p.read_text(encoding="utf-8").splitlines():
#       t = json.loads(line)["task"]
#       print(repr(t), "->", hashlib.sha1(t.encode()).hexdigest() + ".pt")' <dataset_dir>
#
# pick-kettle-and-cup, verified against the dataset:
INSTRUCTION="拿起水杯和茶壶，并倒水"
#   -> 1996543b585036fc5f6ab0de7774ad1fe949e112.pt
#      (the same file the MotusV2 deployment already reads from T5_CACHE_DIR)
# pour-beans: fill in from the LeRobot dump the run actually used
# (configs/g1d_pour_beans.yaml points at pour-beans-eps380).
# INSTRUCTION="<the pour-beans task string>"
# ==============================================================

# ==================== INFERENCE OPTIONS ====================
# READ THIS BEFORE THE FIRST RUN. Motus is heavy, and the synchronous loop
# cannot hide it: the arm executes a chunk, then stands still for one whole
# inference. Measured on an RTX 5090 with the VAE decode skipped:
#
#     steps   inference   vs a 1.60 s chunk (pick-kettle, interp 1)
#         1      237 ms   15% standing still
#         2      403 ms   25%
#         5      918 ms   57%
#        10     1777 ms   111%   <- config default: pauses longer than it moves
#
#   fit: 66 ms fixed + 171 ms per denoising step
#
# Thor is slower than a 5090, so treat these as a floor. Three ways out, in the
# order worth trying:
#   1. NUM_INFERENCE_STEPS=5 below. Cost is chunk quality; the sampler is linear
#      in this, so it is the cheapest lever by far.
#   2. ACTION_INTERP_FACTOR=2. Stretches the same trajectory over 3.2 s so one
#      inference covers less than one chunk. Cost is half-speed motion.
#   3. Cache the understanding tokens. Motus calls
#      und_module.extract_und_features(vlm_inputs) once PER DENOISING STEP, on
#      inputs that do not change within a chunk: 35 ms each, so 9 of the 10
#      calls (319 ms, 18% of the total) are recomputation. Hoisting it out of
#      the loop in Motus/models/motus.py is exact, not an approximation — but it
#      changes the model code, so it is deliberately not done here.
#
# 0 = use the config's model.inference.num_inference_timesteps (10 for G1-D).
NUM_INFERENCE_STEPS=0

# Motus's inference_step always decodes the predicted video through the Wan2.2
# VAE and returns it. A controller uses only the actions, so that decode is pure
# latency. 0 skips it (the adapter swaps the decoder out for the duration of the
# call, leaving the vendored model code untouched); 1 keeps it when you want to
# look at what the model imagined.
DECODE_VIDEO=0

# Action interpolation: 0 = auto = the config's global_downsample_rate.
#   ALL THREE G1-D CONFIGS SHIP global_downsample_rate=1, so auto gives factor 1.
#   That is the correct value: the emitted actions are consecutive 30 Hz frames,
#   so 48 actions are 48 control ticks = 1.60 s of demonstrated motion. Raise it
#   only to deliberately run the motion slower.
ACTION_INTERP_FACTOR=0

# How much of each chunk to execute open loop before re-observing.
#   0 = the full horizon, which is what the model was trained to plan.
# The loop is synchronous, so every replan costs one inference of dead time:
# halving this doubles how often the arm pauses. Start at the full chunk, judge
# the chunks, and only shorten it if the policy is visibly reacting too late.
REPLAN_STEPS=0

# Refuse to move any joint more than this (rad) in one 30 Hz control step,
# measured against the PREVIOUS COMMAND rather than the measurement (the arm
# always trails its target; limiting against the measurement would drag every
# step back toward where the arm is instead of where it is going). The model
# emits absolute targets, so the first action of a chunk can sit far from the
# current pose — that is the case this guards. 0 = off.
#   0.10 rad/tick = 3 rad/s, comfortably above demonstrated speeds.
MAX_JOINT_STEP=0.10
# ===========================================================

# ==================== DIAGNOSTIC LOGGING ====================
# 1 = mirror the diagnostics to $DEBUG_LOG_DIR/inference_motus_g1d_<stamp>.log
# and a .jsonl sibling for offline analysis; 0 = console only.
#
# Turn this on whenever the arm misbehaves. The log opens with the md5 of the
# config and of the T5 embedding, then reports per chunk the SEAM
# (|first_action - measured_q|) — how hard the arm is being asked to snap at the
# chunk boundary, which is the failure this representation actually produces and
# which no other log line shows.
DEBUG_LOG=1
DEBUG_LOG_DIR="$BUNDLE_ROOT/logs"
# INFO is the useful level; DEBUG also captures library chatter.
DEBUG_LOG_LEVEL=INFO
# Log one control step in N (30 = ~1 Hz at 30 Hz control). Guard events are
# never skipped regardless of this.
DEBUG_LOG_EVERY=30
# ============================================================

EXTRA_FLAGS=""
if [ -n "$DATASET_ROOT" ]; then EXTRA_FLAGS="$EXTRA_FLAGS --root=$DATASET_ROOT"; fi
if [ "$DECODE_VIDEO" = "1" ]; then EXTRA_FLAGS="$EXTRA_FLAGS --decode_video"; fi
if [ "$DEBUG_LOG" = "1" ]; then
    mkdir -p "$DEBUG_LOG_DIR"
    EXTRA_FLAGS="$EXTRA_FLAGS --debug_log --debug_log_dir=$DEBUG_LOG_DIR"
    EXTRA_FLAGS="$EXTRA_FLAGS --debug_log_level=$DEBUG_LOG_LEVEL --debug_log_every=$DEBUG_LOG_EVERY"
    echo "[debug] diagnostics -> $DEBUG_LOG_DIR/inference_motus_g1d_<timestamp>.log(+.jsonl)"
fi

python "$SCRIPTS_DIR"/eval_g1_motus_stage3.py \
    --arm=G1_29 \
    --ee=dex1 \
    --frequency=30 \
    --checkpoint_path="$CHECKPOINT_PATH" \
    --config_path="$CONFIG_PATH" \
    --wan_path="$WAN_PATH" \
    --vlm_path="$VLM_PATH" \
    --t5_cache_dir="$T5_CACHE_DIR" \
    --num_inference_steps=$NUM_INFERENCE_STEPS \
    --action_interp_factor=$ACTION_INTERP_FACTOR \
    --replan_steps=$REPLAN_STEPS \
    --max_joint_step=$MAX_JOINT_STEP \
    $EXTRA_FLAGS \
    --instruction="$INSTRUCTION"

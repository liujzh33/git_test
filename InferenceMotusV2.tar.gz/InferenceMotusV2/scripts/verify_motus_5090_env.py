#!/usr/bin/env python3
"""Validate the Motus inference environment without connecting to the robot."""

from __future__ import annotations

import argparse
import importlib
import importlib.metadata
import importlib.util
import os
import sys
from pathlib import Path


EXPECTED_VERSIONS = {
    "torch": "2.12.1",
    "torchvision": "0.27.1",
    "transformers": "5.5.4",
    "accelerate": "1.14.0",
    "diffusers": "0.35.2",
    "deepspeed": "0.19.2",
    "numpy": "2.2.6",
    "opencv-python": "5.0.0.93",
    "Pillow": "12.2.0",
    "PyYAML": "6.0.3",
    "qwen-vl-utils": "0.0.14",
    "av": "14.2.0",
    "pyarrow": "24.0.0",
    "logging-mp": "0.2.1",
    "unitree-sdk2py": "1.0.1",
    "cyclonedds": "0.10.2",
}


class Validation:
    def __init__(self) -> None:
        self.failures: list[str] = []
        self.warnings: list[str] = []

    def ok(self, message: str) -> None:
        print(f"[ OK ] {message}")

    def fail(self, message: str) -> None:
        self.failures.append(message)
        print(f"[FAIL] {message}")

    def warn(self, message: str) -> None:
        self.warnings.append(message)
        print(f"[WARN] {message}")

    def require(self, condition: bool, success: str, failure: str) -> None:
        if condition:
            self.ok(success)
        else:
            self.fail(failure)


def distribution_version(name: str) -> str | None:
    try:
        return importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        return None


def import_check(validation: Validation, module_name: str) -> object | None:
    try:
        module = importlib.import_module(module_name)
    except BaseException as exc:
        validation.fail(
            f"import {module_name}: {type(exc).__name__}: {exc}"
        )
        return None
    validation.ok(f"import {module_name}")
    return module


def resolve_paths(args: argparse.Namespace) -> tuple[Path, Path | None]:
    script_root = Path(__file__).resolve().parents[1]
    motus_root = Path(
        args.motus_root or os.environ.get("MOTUS_ROOT", script_root)
    ).expanduser().resolve()

    configured_unitree = args.unitree_root or os.environ.get(
        "UNITREE_LEROBOT_ROOT"
    )
    candidates = [
        Path(configured_unitree).expanduser() if configured_unitree else None,
        motus_root.parent / "unitree_lerobot",
        Path.home() / "unitree_lerobot",
        Path.home() / "Documents" / "unitree_lerobot",
    ]
    unitree_root = next(
        (
            candidate.resolve()
            for candidate in candidates
            if candidate is not None
            and (candidate / "unitree_lerobot" / "eval_robot").is_dir()
        ),
        None,
    )
    return motus_root, unitree_root


def validate_python_and_packages(validation: Validation) -> None:
    print("\n== Python and package versions ==")
    print(f"python={sys.version.replace(chr(10), ' ')}")
    validation.require(
        sys.version_info[:2] == (3, 10),
        "Python is 3.10 (chosen for the CycloneDDS 0.10.2 binary wheel)",
        f"Expected Python 3.10, found {sys.version_info.major}.{sys.version_info.minor}",
    )

    for name, expected in EXPECTED_VERSIONS.items():
        actual = distribution_version(name)
        if actual is None:
            validation.fail(f"{name} is not installed (expected {expected})")
            continue
        normalized = actual.split("+", maxsplit=1)[0]
        validation.require(
            normalized == expected,
            f"{name}=={actual}",
            f"{name}: expected {expected}, found {actual}",
        )


def validate_cuda(validation: Validation, expected_gpus: int) -> None:
    print("\n== PyTorch and RTX 5090 CUDA runtime ==")
    torch = import_check(validation, "torch")
    if torch is None:
        return

    print(f"torch={torch.__version__}")
    print(f"torch.version.cuda={torch.version.cuda}")
    print(f"cudnn={torch.backends.cudnn.version()}")
    validation.require(
        torch.version.cuda == "13.0",
        "PyTorch uses the stable CUDA 13.0 runtime",
        f"Expected PyTorch CUDA 13.0, found {torch.version.cuda!r}",
    )
    validation.require(
        torch.cuda.is_available(),
        "torch.cuda is available",
        "torch.cuda is unavailable",
    )
    if not torch.cuda.is_available():
        return

    device_count = torch.cuda.device_count()
    validation.require(
        device_count >= expected_gpus,
        f"CUDA sees {device_count} GPU(s)",
        f"Expected at least {expected_gpus} GPU(s), found {device_count}",
    )

    try:
        arch_list = torch.cuda.get_arch_list()
    except BaseException as exc:
        validation.fail(
            f"Could not query PyTorch CUDA architecture list: {type(exc).__name__}: {exc}"
        )
        arch_list = []
    print(f"torch.cuda.get_arch_list()={arch_list}")
    validation.require(
        "sm_120" in arch_list,
        "PyTorch wheel contains native sm_120 support",
        "PyTorch wheel does not advertise sm_120 support",
    )

    for index in range(device_count):
        try:
            props = torch.cuda.get_device_properties(index)
            capability = torch.cuda.get_device_capability(index)
            memory_gib = props.total_memory / 1024**3
            print(
                f"gpu[{index}]={props.name}; capability={capability[0]}.{capability[1]}; "
                f"memory={memory_gib:.2f} GiB"
            )
            validation.require(
                capability == (12, 0),
                f"GPU {index} has compute capability 12.0",
                f"GPU {index} has unexpected compute capability {capability}",
            )
            validation.require(
                memory_gib >= 30.0,
                f"GPU {index} has at least 30 GiB",
                f"GPU {index} has only {memory_gib:.2f} GiB",
            )

            with torch.cuda.device(index), torch.inference_mode():
                left = torch.randn(
                    (256, 256), device=f"cuda:{index}", dtype=torch.bfloat16
                )
                right = torch.randn(
                    (256, 256), device=f"cuda:{index}", dtype=torch.bfloat16
                )
                result = left @ right
                torch.cuda.synchronize(index)
                finite = bool(torch.isfinite(result.float()).all().item())
            validation.require(
                finite,
                f"GPU {index} BF16 matrix multiplication succeeds",
                f"GPU {index} BF16 matrix multiplication produced non-finite values",
            )
        except BaseException as exc:
            validation.fail(
                f"GPU {index} runtime probe: {type(exc).__name__}: {exc}"
            )

    if device_count > 1 and hasattr(torch.cuda, "can_device_access_peer"):
        for source in range(device_count):
            for target in range(device_count):
                if source == target:
                    continue
                try:
                    peer = torch.cuda.can_device_access_peer(source, target)
                    print(f"peer_access[{source}->{target}]={peer}")
                except BaseException as exc:
                    validation.warn(
                        f"Could not query peer access {source}->{target}: {exc}"
                    )
        print(
            "Peer access is informational: this Motus inference path currently "
            "uses one CUDA device and does not require GPU P2P."
        )


def validate_imports(validation: Validation) -> None:
    print("\n== Runtime imports ==")
    modules = [
        "torchvision",
        "transformers",
        "accelerate",
        "diffusers",
        "deepspeed",
        "deepspeed.comm.comm",
        "numpy",
        "cv2",
        "PIL",
        "yaml",
        "qwen_vl_utils",
        "av",
        "imageio",
        "safetensors",
        "einops",
        "ftfy",
        "regex",
        "pyarrow",
        "pyarrow.parquet",
        "logging_mp",
        "cyclonedds",
        "unitree_sdk2py",
        "casadi",
        "pinocchio",
        "pinocchio.casadi",
        "meshcat",
        "zmq",
        "lerobot",
        "lerobot.utils.utils",
    ]
    for module_name in modules:
        import_check(validation, module_name)

    try:
        from transformers import AutoProcessor, Qwen3VLForConditionalGeneration

        _ = AutoProcessor, Qwen3VLForConditionalGeneration
        validation.ok(
            "transformers exports AutoProcessor and Qwen3VLForConditionalGeneration"
        )
    except BaseException as exc:
        validation.fail(
            "Qwen3-VL transformer API: "
            f"{type(exc).__name__}: {exc}"
        )

    if importlib.util.find_spec("flash_attn") is None:
        validation.ok(
            "flash-attn is absent as expected; Motus uses the PyTorch SDPA fallback"
        )
    else:
        validation.warn(
            "flash-attn is installed although the validated Thor environment did not use it"
        )


def validate_project_imports(
    validation: Validation,
    motus_root: Path,
    unitree_root: Path | None,
    check_ik: bool,
) -> None:
    print("\n== Motus and Unitree project imports ==")
    validation.require(
        (motus_root / "scripts" / "eval_g1_motus.py").is_file(),
        f"Motus root found at {motus_root}",
        f"Invalid Motus root: {motus_root}",
    )
    validation.require(
        unitree_root is not None
        and (unitree_root / "unitree_lerobot" / "eval_robot").is_dir(),
        f"unitree_lerobot root found at {unitree_root}",
        "unitree_lerobot root was not found; pass --unitree-root",
    )
    if unitree_root is None:
        return

    paths = [
        unitree_root,
        unitree_root / "lerobot" / "src",
        motus_root / "scripts",
    ]
    for path in reversed(paths):
        sys.path.insert(0, str(path))

    old_cwd = Path.cwd()
    try:
        os.chdir(unitree_root)
        from eval_g1_motus import _normalize_image_info
        from motusv2_adapter.adapter import MotusV2PolicyAdapter
        from unitree_lerobot.eval_robot.make_robot import (
            process_images_and_observations,
            setup_image_client,
            setup_robot_interface,
        )

        dummy_client = object()
        dummy_config = {"diagnostic": True}
        normalized = _normalize_image_info((dummy_client, dummy_config))
        if (
            normalized["image_client"] is not dummy_client
            or normalized["camera_config"] is not dummy_config
        ):
            raise AssertionError("tuple ImageClient setup normalization failed")

        _ = (
            MotusV2PolicyAdapter,
            process_images_and_observations,
            setup_image_client,
            setup_robot_interface,
        )
        validation.ok(
            "Motus adapter, ImageClient API compatibility, and Unitree "
            "hardware-interface imports"
        )

        urdf = (
            unitree_root
            / "unitree_lerobot"
            / "eval_robot"
            / "assets"
            / "g1"
            / "g1_body29_hand14.urdf"
        )
        validation.require(
            urdf.is_file(),
            f"G1 IK URDF found at {urdf}",
            f"G1 IK URDF is missing: {urdf}",
        )

        if check_ik and urdf.is_file():
            from unitree_lerobot.eval_robot.robot_control.robot_arm_ik import (
                G1_29_ArmIK,
            )

            _ = G1_29_ArmIK(Unit_Test=True, Visualization=False)
            validation.ok(
                "G1_29 IK/CasADi solver constructs without opening robot communication"
            )
    except BaseException as exc:
        validation.fail(
            f"Project import/IK validation: {type(exc).__name__}: {exc}"
        )
    finally:
        os.chdir(old_cwd)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Validate the RTX 5090 Motus environment without connecting to "
            "the robot or loading model weights."
        )
    )
    parser.add_argument("--motus-root", default="")
    parser.add_argument("--unitree-root", default="")
    parser.add_argument("--expected-gpus", type=int, default=2)
    parser.add_argument(
        "--skip-ik",
        action="store_true",
        help="Skip construction of the local G1 Pinocchio/CasADi IK solver.",
    )
    return parser


def main() -> int:
    args = build_parser().parse_args()
    validation = Validation()
    motus_root, unitree_root = resolve_paths(args)

    print("Motus RTX 5090 environment validation")
    print(f"motus_root={motus_root}")
    print(f"unitree_root={unitree_root or '<not-found>'}")

    validate_python_and_packages(validation)
    validate_cuda(validation, args.expected_gpus)
    validate_imports(validation)
    validate_project_imports(
        validation,
        motus_root,
        unitree_root,
        check_ik=not args.skip_ik,
    )

    print("\n== Result ==")
    print(f"warnings={len(validation.warnings)}")
    print(f"failures={len(validation.failures)}")
    if validation.failures:
        for failure in validation.failures:
            print(f" - {failure}")
        return 1
    print("Environment validation passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

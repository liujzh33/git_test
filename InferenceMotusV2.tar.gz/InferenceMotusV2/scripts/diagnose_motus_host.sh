#!/usr/bin/env bash
#
# Collect the host information needed to build an InferenceMotusV2
# installation plan. This script is read-only apart from its log and a
# temporary Python probe file, which is removed on exit.
#
# Run this script as the ordinary account that will own the Conda environment.
# Do not run it with sudo.

set -uo pipefail

SCRIPT_VERSION="1.0.1"
TARGET_CONDA_ENV="inference_motus"
OUTPUT_PATH=""
SKIP_NETWORK=0

usage() {
    cat <<'EOF'
Usage:
  bash diagnose_motus_host.sh [options]

Options:
  -o, --output FILE       Log path. Default:
                          ./motus_host_diagnostics_<host>_<time>.log
  -e, --conda-env NAME    Probe this existing Conda environment if present.
                          Default: inference_motus
      --skip-network      Skip outbound HTTPS reachability checks.
  -h, --help              Show this help.

Run this as the normal user who will run Motus, not with sudo:
  bash diagnose_motus_host.sh

The script does not install or change drivers, CUDA, Python, or packages.
It deliberately does not print environment variables that commonly contain
tokens, proxy URLs, GPU UUIDs, hardware serial numbers, or pip/Conda configs.
The log does contain the hostname, username, groups, filesystem paths, Conda
environment paths, and hardware/package details; review it before sharing.
EOF
}

while (($# > 0)); do
    case "$1" in
        -o|--output)
            if (($# < 2)); then
                printf 'ERROR: %s requires a value\n' "$1" >&2
                exit 2
            fi
            OUTPUT_PATH="$2"
            shift 2
            ;;
        -e|--conda-env)
            if (($# < 2)); then
                printf 'ERROR: %s requires a value\n' "$1" >&2
                exit 2
            fi
            TARGET_CONDA_ENV="$2"
            shift 2
            ;;
        --skip-network)
            SKIP_NETWORK=1
            shift
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            printf 'ERROR: unknown option: %s\n\n' "$1" >&2
            usage >&2
            exit 2
            ;;
    esac
done

HOST_SAFE="$(hostname -s 2>/dev/null || printf 'unknown-host')"
HOST_SAFE="${HOST_SAFE//[^A-Za-z0-9._-]/_}"
TIMESTAMP="$(date '+%Y%m%d_%H%M%S')"

if [[ -z "$OUTPUT_PATH" ]]; then
    OUTPUT_PATH="$PWD/motus_host_diagnostics_${HOST_SAFE}_${TIMESTAMP}.log"
elif [[ "$OUTPUT_PATH" != /* ]]; then
    OUTPUT_PATH="$PWD/$OUTPUT_PATH"
fi

OUTPUT_DIR="${OUTPUT_PATH%/*}"
if [[ ! -d "$OUTPUT_DIR" ]]; then
    printf 'ERROR: output directory does not exist: %s\n' "$OUTPUT_DIR" >&2
    exit 2
fi

umask 077
if ! : >"$OUTPUT_PATH"; then
    printf 'ERROR: cannot write log: %s\n' "$OUTPUT_PATH" >&2
    exit 2
fi

exec > >(tee -a "$OUTPUT_PATH") 2>&1

section() {
    printf '\n\n============================================================\n'
    printf '%s\n' "$1"
    printf '============================================================\n'
}

run_cmd() {
    local title="$1"
    shift
    printf '\n--- %s ---\n' "$title"
    printf '$'
    printf ' %q' "$@"
    printf '\n'
    "$@"
    local rc=$?
    printf '[exit_code=%d]\n' "$rc"
    return 0
}

run_shell() {
    local title="$1"
    local command_text="$2"
    printf '\n--- %s ---\n' "$title"
    printf '$ %s\n' "$command_text"
    bash -o pipefail -c "$command_text"
    local rc=$?
    printf '[exit_code=%d]\n' "$rc"
    return 0
}

print_access_summary() {
    printf 'effective_uid=%s\n' "$EUID"
    if ((EUID == 0)); then
        printf 'privilege=running-as-root (rerun as the intended Motus user)\n'
    elif ! command -v sudo >/dev/null 2>&1; then
        printf 'sudo=not-installed\n'
    elif sudo -n true >/dev/null 2>&1; then
        printf 'sudo=passwordless-access-available\n'
    else
        printf 'sudo=installed; passwordless check unavailable (password may be required)\n'
    fi
}

list_relevant_debs() {
    if ! command -v dpkg-query >/dev/null 2>&1; then
        printf 'dpkg-query not found\n'
        return 127
    fi

    dpkg-query -W -f='${binary:Package}\t${Version}\t${db:Status-Status}\n' 2>/dev/null |
        awk '
            $3 == "installed" &&
            $1 ~ /^(cuda($|[-:])|libcuda|libcud|cudnn|libnccl|nccl|nvidia($|[-:])|libnvidia|linux-headers|build-essential($|:)|gcc($|:)|g\+\+($|:)|cmake($|:)|ninja-build($|:)|git($|:)|git-lfs($|:)|ffmpeg($|:)|pkg-config($|:)|python3-dev($|:)|python3-venv($|:)|libgl1($|:)|libglib2\.0-0($|:)|libsm6($|:)|libxext6($|:)|libxrender1($|:)|openmpi-bin($|:)|libopenmpi-dev($|:)|ca-certificates($|:)|curl($|:))/ {
                print
            }
        ' | sort
}

list_cuda_installations() {
    local found=0
    local path
    shopt -s nullglob
    for path in /usr/local/cuda /usr/local/cuda-*; do
        found=1
        ls -ld "$path"
        if [[ -L "$path" ]]; then
            printf '  resolved_to=%s\n' "$(readlink -f "$path" 2>/dev/null || true)"
        fi
    done
    shopt -u nullglob
    if ((found == 0)); then
        printf 'No /usr/local/cuda* installation found\n'
    fi
}

show_cuda_version_files() {
    local found=0
    local file
    shopt -s nullglob
    for file in /usr/local/cuda*/version.json /usr/local/cuda*/version.txt; do
        found=1
        printf '\n[%s]\n' "$file"
        awk '{ print }' "$file"
    done
    shopt -u nullglob
    if ((found == 0)); then
        printf 'No CUDA version.json/version.txt files found\n'
    fi
}

show_cuda_headers() {
    local found=0
    local header
    shopt -s nullglob
    for header in \
        /usr/include/cudnn_version.h \
        /usr/include/x86_64-linux-gnu/cudnn_version_v*.h \
        /usr/local/cuda*/include/cudnn_version.h \
        /usr/include/nccl.h \
        /usr/local/cuda*/include/nccl.h; do
        [[ -f "$header" ]] || continue
        found=1
        printf '\n[%s]\n' "$header"
        awk '
            /^#define CUDNN_(MAJOR|MINOR|PATCHLEVEL)/ ||
            /^#define NCCL_(MAJOR|MINOR|PATCH)/ {
                print
            }
        ' "$header"
    done
    shopt -u nullglob
    if ((found == 0)); then
        printf 'No cuDNN/NCCL version headers found in standard paths\n'
    fi
}

show_gpu_device_permissions() {
    local devices=()
    local path
    shopt -s nullglob
    for path in /dev/nvidia* /dev/dri/renderD*; do
        devices+=("$path")
    done
    shopt -u nullglob
    if ((${#devices[@]} == 0)); then
        printf 'No /dev/nvidia* or /dev/dri/renderD* devices found\n'
        return 1
    fi
    stat -c '%A %U:%G %n' "${devices[@]}"
}

show_proxy_state() {
    local name
    for name in \
        http_proxy https_proxy ftp_proxy all_proxy no_proxy \
        HTTP_PROXY HTTPS_PROXY FTP_PROXY ALL_PROXY NO_PROXY; do
        if [[ -n "${!name-}" ]]; then
            printf '%s=set (value redacted)\n' "$name"
        else
            printf '%s=unset\n' "$name"
        fi
    done
}

network_checks() {
    if ! command -v curl >/dev/null 2>&1; then
        printf 'curl not found; HTTPS checks cannot run\n'
        return 127
    fi

    local urls=(
        "https://pypi.org/"
        "https://download.pytorch.org/"
        "https://repo.anaconda.com/"
        "https://github.com/"
        "https://huggingface.co/"
        "https://developer.download.nvidia.com/"
    )
    local url
    local pids=()
    local pid

    for url in "${urls[@]}"; do
        (
            local result rc
            result="$(
                curl \
                    --location \
                    --output /dev/null \
                    --silent \
                    --show-error \
                    --connect-timeout 4 \
                    --max-time 10 \
                    --user-agent "MotusHostDiagnostic/${SCRIPT_VERSION}" \
                    --write-out 'http=%{http_code} connect=%{time_connect}s total=%{time_total}s tls_verify=%{ssl_verify_result}' \
                    "$url" 2>&1
            )"
            rc=$?
            result="${result//$'\n'/; }"
            printf '%s -> curl_exit=%d %s\n' "$url" "$rc" "$result"
        ) &
        pids+=("$!")
    done

    # Do not use a bare `wait` here: the script-level tee process substitution
    # is also a child process and lives until stdout closes. Waiting for every
    # child would therefore deadlock tee and the collector.
    for pid in "${pids[@]}"; do
        wait "$pid" || true
    done
    return 0
}

printf 'Motus host diagnostic\n'
printf 'script_version=%s\n' "$SCRIPT_VERSION"
printf 'started_at=%s\n' "$(date --iso-8601=seconds 2>/dev/null || date)"
printf 'output_log=%s\n' "$OUTPUT_PATH"
printf 'target_conda_env=%s\n' "$TARGET_CONDA_ENV"
printf 'network_checks=%s\n' "$([[ "$SKIP_NETWORK" == 1 ]] && printf 'skipped' || printf 'enabled')"
printf '\nNOTE: command failures are recorded intentionally; one missing optional tool does not stop collection.\n'

section "1. USER, PRIVILEGES, AND OPERATING SYSTEM"
run_cmd "Hostname" hostname
run_cmd "Current user and groups" id
run_cmd "Privilege availability (non-interactive only)" print_access_summary
run_cmd "Kernel and architecture" uname -a
run_cmd "Machine architecture" uname -m
run_cmd "Userspace bit width" getconf LONG_BIT
run_cmd "Ubuntu/OS release" awk '{ print }' /etc/os-release
run_cmd "LSB release" lsb_release -a
run_cmd "Debian package architecture" dpkg --print-architecture
run_cmd "Foreign Debian architectures" dpkg --print-foreign-architectures
run_cmd "glibc version (getconf)" getconf GNU_LIBC_VERSION
run_cmd "glibc/loader version (ldd)" ldd --version
run_cmd "Virtualization type" systemd-detect-virt
run_cmd "Secure Boot state" mokutil --sb-state
run_cmd "Date and timezone" timedatectl
run_cmd "Locale" locale

KERNEL_RELEASE="$(uname -r)"
printf '\n--- Matching kernel headers ---\n'
printf 'kernel_release=%s\n' "$KERNEL_RELEASE"
if [[ -e "/lib/modules/$KERNEL_RELEASE/build" ]]; then
    printf 'kernel_build_link=present (%s)\n' "$(readlink -f "/lib/modules/$KERNEL_RELEASE/build" 2>/dev/null || true)"
else
    printf 'kernel_build_link=missing\n'
fi

section "2. CPU, NUMA, MEMORY, STORAGE, AND LIMITS"
run_cmd "CPU summary and instruction flags" lscpu
run_cmd "Logical CPU count" nproc --all
run_cmd "NUMA topology" numactl --hardware
run_cmd "RAM and swap" free -h
run_cmd "Block devices (serial numbers excluded)" lsblk -e 7 -o NAME,TYPE,SIZE,FSTYPE,MOUNTPOINTS,ROTA,MODEL
run_cmd "Space on relevant filesystems" df -hT / "${HOME:-/}" "$PWD" /tmp /dev/shm
run_cmd "Inodes on relevant filesystems" df -i / "${HOME:-/}" "$PWD" /tmp /dev/shm
run_cmd "Root mount options" findmnt -T /
run_cmd "Home mount options" findmnt -T "${HOME:-/}"
run_cmd "Temporary-directory mount options" findmnt -T /tmp
run_cmd "Shared-memory mount options" findmnt -T /dev/shm
run_shell "Process resource limits" "ulimit -a"

section "3. NVIDIA DRIVER AND GPU INVENTORY"
if command -v nvidia-smi >/dev/null 2>&1; then
    run_cmd "NVIDIA-SMI overview (includes driver-supported CUDA level)" nvidia-smi
    run_cmd \
        "Curated GPU properties (UUIDs and serials excluded)" \
        nvidia-smi \
        --query-gpu=index,name,driver_version,memory.total,memory.free,pci.bus_id,pstate,temperature.gpu,power.draw,power.limit \
        --format=csv,noheader
    run_cmd \
        "GPU compute capabilities" \
        nvidia-smi \
        --query-gpu=index,name,compute_cap \
        --format=csv,noheader
    run_cmd \
        "PCIe link widths and generations" \
        nvidia-smi \
        --query-gpu=index,pcie.link.gen.current,pcie.link.gen.max,pcie.link.width.current,pcie.link.width.max \
        --format=csv,noheader
    run_cmd "Two-GPU topology and CPU/NUMA affinity" nvidia-smi topo -m
    run_cmd "GPU peer-to-peer read capability" nvidia-smi topo -p2p r
else
    printf '\nnvidia-smi=not-found\n'
fi
run_cmd "NVIDIA PCI devices and bound kernel drivers" lspci -Dnnk -d 10de:
run_shell "Loaded NVIDIA kernel modules" "awk '\$1 ~ /^nvidia/ { print }' /proc/modules"
run_cmd "NVIDIA kernel-module version" modinfo -F version nvidia
run_cmd "NVIDIA kernel-module vermagic" modinfo -F vermagic nvidia
run_cmd "DKMS status" dkms status
run_cmd "GPU device-node permissions" show_gpu_device_permissions

section "4. CUDA TOOLKIT, cuDNN, NCCL, AND DYNAMIC LIBRARIES"
if command -v nvcc >/dev/null 2>&1; then
    run_cmd "nvcc location" command -v nvcc
    run_cmd "CUDA compiler version" nvcc --version
else
    printf '\nnvcc=not-found (a driver can work without a system CUDA Toolkit)\n'
fi
run_cmd "CUDA installations and symlinks" list_cuda_installations
run_cmd "CUDA version metadata" show_cuda_version_files
run_cmd "CUDA alternative selection" update-alternatives --display cuda
run_cmd "cuDNN and NCCL header versions" show_cuda_headers
run_shell \
    "CUDA/cuDNN/NCCL libraries visible to the dynamic linker" \
    "ldconfig -p 2>/dev/null | awk '/libcuda\\.so|libcudart|libnvrtc|libcudnn|libnccl/ { print }' | sort -u"
run_cmd "Relevant installed Debian packages" list_relevant_debs
run_cmd "Held Debian packages" apt-mark showhold

section "5. BUILD, MEDIA, AND CONTAINER TOOLCHAIN"
run_cmd "GNU C compiler" gcc --version
run_cmd "GNU C++ compiler" g++ --version
run_cmd "GNU linker" ld --version
run_cmd "Clang compiler" clang --version
run_cmd "CMake" cmake --version
run_cmd "Ninja" ninja --version
run_cmd "Make" make --version
run_cmd "pkg-config" pkg-config --version
run_cmd "Git" git --version
run_cmd "Git LFS" git lfs version
run_cmd "FFmpeg build and codec support" ffmpeg -version
run_cmd "OpenSSL" openssl version -a
run_cmd "curl" curl --version
run_cmd "ccache" ccache --version
run_cmd "Docker client" docker --version
run_cmd "NVIDIA Container Toolkit CLI" nvidia-ctk --version
run_cmd "NVIDIA container runtime" nvidia-container-cli --version

section "6. SHELL AND INSTALL-RELEVANT ENVIRONMENT PATHS"
printf 'SHELL=%s\n' "${SHELL-<unset>}"
printf 'PATH=%s\n' "${PATH-<unset>}"
printf 'LD_LIBRARY_PATH=%s\n' "${LD_LIBRARY_PATH-<unset>}"
printf 'LIBRARY_PATH=%s\n' "${LIBRARY_PATH-<unset>}"
printf 'CPATH=%s\n' "${CPATH-<unset>}"
printf 'CUDA_HOME=%s\n' "${CUDA_HOME-<unset>}"
printf 'CUDA_PATH=%s\n' "${CUDA_PATH-<unset>}"
printf 'CONDA_DEFAULT_ENV=%s\n' "${CONDA_DEFAULT_ENV-<unset>}"
printf 'CONDA_PREFIX=%s\n' "${CONDA_PREFIX-<unset>}"
printf 'VIRTUAL_ENV=%s\n' "${VIRTUAL_ENV-<unset>}"
printf 'XDG_CACHE_HOME=%s\n' "${XDG_CACHE_HOME-<unset>}"
run_cmd "Proxy-variable presence (values redacted)" show_proxy_state

section "7. PYTHON AND ENVIRONMENT MANAGERS"
run_cmd "System/default Python 3" python3 --version
run_cmd "System/default Python" python --version
run_cmd "pip for Python 3" python3 -m pip --version
run_cmd "pip for default Python" python -m pip --version
run_cmd "Conda version" conda --version
run_cmd "Mamba version" mamba --version
run_cmd "Micromamba version" micromamba --version
run_cmd "uv version" uv --version

CONDA_BIN=""
if [[ -n "${CONDA_EXE-}" && -x "${CONDA_EXE-}" ]]; then
    CONDA_BIN="$CONDA_EXE"
elif command -v conda >/dev/null 2>&1; then
    CONDA_BIN="$(command -v conda)"
fi

if [[ -n "$CONDA_BIN" ]]; then
    run_cmd "Conda executable" printf '%s\n' "$CONDA_BIN"
    run_cmd "Conda base directory" "$CONDA_BIN" info --base
    run_cmd "Conda environments" "$CONDA_BIN" env list
else
    printf '\nconda_executable=not-found\n'
fi

TMP_DIR=""
if TMP_DIR="$(mktemp -d -t motus-diagnostic.XXXXXX 2>/dev/null)"; then
    trap '[[ -n "${TMP_DIR-}" ]] && rm -rf "$TMP_DIR"' EXIT
    PYTHON_PROBE="$TMP_DIR/python_probe.py"
    cat >"$PYTHON_PROBE" <<'PY'
import importlib
import importlib.metadata
import os
import platform
import site
import sys
import sysconfig
import traceback


def line(name, value):
    print(f"{name}={value}")


line("python_executable", sys.executable)
line("python_version", sys.version.replace("\n", " "))
line("python_prefix", sys.prefix)
line("python_base_prefix", sys.base_prefix)
line("platform", platform.platform())
line("machine", platform.machine())
line("python_compiler", platform.python_compiler())
line("soabi", sysconfig.get_config_var("SOABI"))
line("sysconfig_platform", sysconfig.get_platform())
try:
    line("site_packages", site.getsitepackages())
except Exception as exc:
    line("site_packages_error", repr(exc))

distributions = [
    "torch",
    "torchvision",
    "triton",
    "transformers",
    "tokenizers",
    "accelerate",
    "diffusers",
    "deepspeed",
    "numpy",
    "opencv-python",
    "opencv-python-headless",
    "Pillow",
    "PyYAML",
    "qwen-vl-utils",
    "av",
    "imageio",
    "safetensors",
    "einops",
    "ftfy",
    "regex",
    "pyarrow",
    "logging-mp",
    "lerobot",
    "unitree-sdk2py",
    "cyclonedds",
]
print("\n[distribution_versions]")
for distribution in distributions:
    try:
        version = importlib.metadata.version(distribution)
    except importlib.metadata.PackageNotFoundError:
        version = "<not-installed>"
    except Exception as exc:
        version = f"<error: {exc!r}>"
    print(f"{distribution}={version}")

print("\n[key_import_checks]")
modules = [
    "torch",
    "torchvision",
    "transformers",
    "diffusers",
    "deepspeed",
    "cv2",
    "PIL",
    "yaml",
    "qwen_vl_utils",
    "av",
    "pyarrow",
    "logging_mp",
    "lerobot",
    "unitree_sdk2py",
    "cyclonedds",
]
for module in modules:
    try:
        importlib.import_module(module)
        print(f"{module}=import-ok")
    except BaseException as exc:
        print(f"{module}=import-failed: {type(exc).__name__}: {exc}")

print("\n[torch_cuda_probe]")
try:
    import torch

    line("torch_version", torch.__version__)
    line("torch_compiled_cuda", torch.version.cuda)
    line("torch_compiled_hip", torch.version.hip)
    line("cuda_available", torch.cuda.is_available())
    line("cuda_device_count", torch.cuda.device_count())
    line("cudnn_version", torch.backends.cudnn.version())
    line("cudnn_available", torch.backends.cudnn.is_available())
    line("distributed_available", torch.distributed.is_available())
    line("nccl_available", torch.distributed.is_nccl_available())
    try:
        line("nccl_version", torch.cuda.nccl.version())
    except BaseException as exc:
        line("nccl_version_error", f"{type(exc).__name__}: {exc}")
    try:
        line("torch_cuda_arch_list", torch.cuda.get_arch_list())
    except BaseException as exc:
        line("torch_cuda_arch_list_error", f"{type(exc).__name__}: {exc}")
    try:
        line(
            "flash_attention_backend_built",
            torch.backends.cuda.is_flash_attention_available(),
        )
    except BaseException as exc:
        line("flash_attention_backend_error", f"{type(exc).__name__}: {exc}")
    try:
        line("flash_sdp_enabled", torch.backends.cuda.flash_sdp_enabled())
        line(
            "memory_efficient_sdp_enabled",
            torch.backends.cuda.mem_efficient_sdp_enabled(),
        )
        line("math_sdp_enabled", torch.backends.cuda.math_sdp_enabled())
    except BaseException as exc:
        line("sdp_backend_error", f"{type(exc).__name__}: {exc}")

    if torch.cuda.is_available():
        try:
            line("bf16_supported_on_current_device", torch.cuda.is_bf16_supported())
        except BaseException as exc:
            line("bf16_probe_error", f"{type(exc).__name__}: {exc}")

        for index in range(torch.cuda.device_count()):
            try:
                props = torch.cuda.get_device_properties(index)
                print(f"\n[gpu_{index}]")
                line("name", props.name)
                line("compute_capability", f"{props.major}.{props.minor}")
                line("total_memory_bytes", props.total_memory)
                line("multiprocessor_count", props.multi_processor_count)
                with torch.cuda.device(index):
                    value = (torch.arange(16, device=f"cuda:{index}") ** 2).sum()
                    torch.cuda.synchronize(index)
                line("tiny_cuda_kernel", f"ok result={value.item()}")
            except BaseException as exc:
                line(
                    f"gpu_{index}_probe_error",
                    f"{type(exc).__name__}: {exc}",
                )

        if (
            torch.cuda.device_count() > 1
            and hasattr(torch.cuda, "can_device_access_peer")
        ):
            print("\n[peer_access]")
            for source in range(torch.cuda.device_count()):
                for target in range(torch.cuda.device_count()):
                    if source == target:
                        continue
                    try:
                        access = torch.cuda.can_device_access_peer(source, target)
                        line(f"gpu_{source}_to_gpu_{target}", access)
                    except BaseException as exc:
                        line(
                            f"gpu_{source}_to_gpu_{target}_error",
                            f"{type(exc).__name__}: {exc}",
                        )

    print("\n[torch_build_config]")
    print(torch.__config__.show())
except BaseException as exc:
    line("torch_probe_error", f"{type(exc).__name__}: {exc}")
    traceback.print_exc()
PY

    SEEN_PYTHONS=":"
    for PYTHON_NAME in python3 python; do
        PYTHON_PATH="$(command -v "$PYTHON_NAME" 2>/dev/null || true)"
        [[ -n "$PYTHON_PATH" ]] || continue
        PYTHON_REAL="$(readlink -f "$PYTHON_PATH" 2>/dev/null || printf '%s' "$PYTHON_PATH")"
        if [[ "$SEEN_PYTHONS" == *":$PYTHON_REAL:"* ]]; then
            continue
        fi
        SEEN_PYTHONS+="$PYTHON_REAL:"
        run_cmd "Python package and CUDA probe: $PYTHON_REAL" "$PYTHON_REAL" "$PYTHON_PROBE"
    done

    if [[ -n "$CONDA_BIN" ]]; then
        if "$CONDA_BIN" env list 2>/dev/null |
            awk -v target="$TARGET_CONDA_ENV" '$1 == target { found=1 } END { exit !found }'; then
            run_cmd \
                "Target Conda environment package and CUDA probe: $TARGET_CONDA_ENV" \
                "$CONDA_BIN" run --no-capture-output -n "$TARGET_CONDA_ENV" \
                python "$PYTHON_PROBE"
        else
            printf '\ntarget_conda_env_status=not-found (%s)\n' "$TARGET_CONDA_ENV"
        fi
    fi
else
    printf '\npython_probe=skipped (mktemp failed)\n'
fi

section "8. OUTBOUND PACKAGE/DOWNLOAD CONNECTIVITY"
run_cmd "Proxy-variable presence (values redacted)" show_proxy_state
if ((SKIP_NETWORK == 1)); then
    printf '\nnetwork_checks=skipped-by-option\n'
else
    run_cmd "Parallel HTTPS reachability checks" network_checks
fi

section "9. DIAGNOSTIC COMPLETE"
printf 'finished_at=%s\n' "$(date --iso-8601=seconds 2>/dev/null || date)"
printf 'log_file=%s\n' "$OUTPUT_PATH"
printf '\nPlease review the log, then return the complete file for the Motus installation-script design.\n'
printf 'A failed optional command is useful diagnostic evidence and does not mean this collector failed.\n'

exit 0

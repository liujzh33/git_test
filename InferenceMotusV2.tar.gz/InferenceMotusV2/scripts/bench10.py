import sys, os, time, torch, numpy as np
torch.backends.cuda.matmul.allow_tf32 = True
torch.backends.cudnn.allow_tf32 = True
torch.backends.cudnn.benchmark = True
from torch.nn.attention import sdpa_kernel, SDPBackend
from PIL import Image
sys.path.insert(0, '/home/unitree/scripts')
import test_motusv2_inference as T

print('Building model...', flush=True)
model = T.create_model()

t5_ckpt = os.path.join(T.WAN_PATH, 'models_t5_umt5-xxl-enc-bf16.pth')
from wan.modules.t5 import T5EncoderModel
t5_encoder = T5EncoderModel(text_len=512, dtype=torch.bfloat16, device='cuda', checkpoint_path=t5_ckpt, tokenizer_path=os.path.join(T.WAN_PATH,'google','umt5-xxl'))
language_embedding = T.get_t5_embedding(t5_encoder, T.INSTRUCTION)
t5_list = [language_embedding]

from transformers import AutoProcessor
vlm_processor = AutoProcessor.from_pretrained(T.VLM_PATH, trust_remote_code=True)

first_frame, state, first_frame_pil = T.make_random_input()
vlm_inputs = T.preprocess_vlm_messages(T.INSTRUCTION, first_frame_pil, vlm_processor)
vlm_inputs_device = {k: v.to('cuda') for k, v in vlm_inputs.items() if v is not None}

times = []
# With torch.compile enabled: run 1 = compile (can take tens of seconds),
# run 2 = CUDA-graph record (reduce-overhead), run 3+ = fast replay.
# So run more iterations and skip the first two when averaging.
N_RUNS = 6
N_SKIP = 2
for i in range(N_RUNS):
    torch.cuda.synchronize()
    t0 = time.time()
    # NOTE: do NOT call torch.cuda.empty_cache() between runs when using
    # reduce-overhead / CUDA graphs — it frees the graph's static memory pool
    # and forces a re-record (or errors). Keep the pool alive across runs.
    with torch.no_grad(), torch.autocast(device_type='cuda', dtype=torch.bfloat16):
        with sdpa_kernel([SDPBackend.EFFICIENT_ATTENTION, SDPBackend.MATH]):
            _, acts = model.inference_step(first_frame=first_frame, state=state, num_inference_steps=10, language_embeddings=t5_list, vlm_inputs=vlm_inputs_device, decode_video=False)
    torch.cuda.synchronize()
    dt = time.time() - t0
    times.append(dt)
    print(f'Run {i+1}: {dt:.3f}s', flush=True)
    del acts

print('---', flush=True)
warm = times[N_SKIP:]
print(f'All times: {[round(t,3) for t in times]}', flush=True)
if warm:
    print(f'Avg (skip {N_SKIP}): {np.mean(warm):.3f}s, Min: {min(warm):.3f}s, Max: {max(warm):.3f}s', flush=True)

import sys
import os
import logging
import time as _time
from pathlib import Path
from typing import Optional

import cv2
import numpy as np
import torch
import yaml
from PIL import Image
from transformers import AutoProcessor

def _resolve_policy_dir() -> str:
    """Locate the MotusWanVlmDirectMaskMotion policy dir across layouts.

    Works both for the Thor deployment layout
    (``<root>/codes/temp/MotusV2/policy/MotusWanVlmDirectMaskMotion``) and for the
    self-contained InferenceMotusV2 bundle
    (``<bundle>/policy/MotusWanVlmDirectMaskMotion``). Set ``MOTUS_POLICY_DIR`` to
    override explicitly.
    """
    here = Path(__file__).resolve()
    bundle_root = here.parents[2]  # .../InferenceMotusV2  or  /home/unitree (Thor scripts layout)
    candidates = []
    env = os.environ.get("MOTUS_POLICY_DIR")
    if env:
        candidates.append(Path(env))
    candidates.append(bundle_root / "policy" / "MotusWanVlmDirectMaskMotion")                       # self-contained bundle
    candidates.append(bundle_root / "codes" / "temp" / "MotusV2" / "policy" / "MotusWanVlmDirectMaskMotion")  # Thor layout
    for c in candidates:
        if (c / "models" / "motus_wan_vlm_direct_mask.py").exists():
            return str(c)
    # Fall back to the Thor layout (original behavior) if none matched.
    return str(bundle_root / "codes" / "temp" / "MotusV2" / "policy" / "MotusWanVlmDirectMaskMotion")


_POLICY_DIR = _resolve_policy_dir()
_MOTUS_ROOT = str(Path(_POLICY_DIR).parent.parent)  # .../MotusV2 or .../InferenceMotusV2
_MODELS_DIR = os.path.join(_POLICY_DIR, "models")
_BAK_DIR = os.path.join(_POLICY_DIR, "bak")
_UTILS_DIR = os.path.join(_POLICY_DIR, "utils")

for _p in [_MOTUS_ROOT, _POLICY_DIR, _MODELS_DIR, _BAK_DIR, _UTILS_DIR]:
    if _p not in sys.path:
        sys.path.insert(0, _p)

for _p in [os.path.join(_MOTUS_ROOT, "models"), os.path.join(_MOTUS_ROOT, "bak"),
           os.path.join(_MOTUS_ROOT, "utils")]:
    if _p not in sys.path:
        sys.path.append(_p)

from models.motus_wan_vlm_direct_mask import MotusWanVlmDirectMask, MotusWanVlmDirectMaskConfig
from wan.modules.t5 import T5EncoderModel
from utils.image_utils import resize_with_padding
from utils.vlm_utils import preprocess_vlm_messages

try:
    from qwen_vl_utils import process_vision_info
except ImportError:
    from wan.utils.qwen_vl_utils import process_vision_info

try:
    from motusv2_adapter import eef_delta as _eef
    from motusv2_adapter import debug as _debug
except ImportError:  # adapter.py imported directly rather than as a package member
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import eef_delta as _eef
    import debug as _debug

logger = logging.getLogger(__name__)

_REORDER_FROM_RAW = [0, 1, 2, 3, 4, 5, 6, 14, 7, 8, 9, 10, 11, 12, 13, 15]


class MotusV2PolicyAdapter:
    """
    Adapter that bridges MotusV2 model to the G1 real-robot eval loop.

    ``dataset.action_mode`` in the training config selects the representation and
    the adapter follows it:

    * ``qpos`` (default) -- 16-dim joint positions. Raw layout from the robot is
      [L7, R7, LG, RG] (grippers at 14/15); training reorders to [L7, LG, R7, RG]
      (gripper after its arm, dims 7/15), matching multi_source_pretrain. No IK.
    * ``eef`` / ``eef_delta`` -- 16-dim Cartesian, two per-arm blocks of
      [xyz(3), rotvec(3), reserved(1), gripper(1)]. State comes from FK on the
      measured joints, actions are denormalized, ``eef_delta`` additionally
      composes them onto the pose the chunk was conditioned on, and IK turns the
      result back into joint targets. See eef_delta.py.

    The Cartesian path needs two artifacts the robot does not otherwise carry: a
    G1 URDF (found under ``urdf_search_roots``) and the ``eef_stats.json`` the
    checkpoint was normalized with. Both are checked at construction.

    Cameras: cam_left_high (top) + cam_left_wrist (bottom-left) + cam_right_wrist (bottom-right),
    stitched into a T shape at 384x320.  ``dataset.stitch_mode`` in the config picks
    the geometry and must match what the checkpoint was trained with:
    "aspect" (default, aspect-preserving single resize, cam_left_high at 240x320)
    or "legacy" (the old double resize, cam_left_high at only 120x160).
    cam_right_high is UNUSED (matches training).

    Action time base: the model emits ``num_video_frames * video_action_freq_ratio``
    actions spaced ``common.global_downsample_rate`` frames apart at 30Hz, but the
    tensor itself carries no time scale.  ``action_interp_factor=0`` (the default)
    therefore resolves to that stride so the chunk replays at the demonstrated speed;
    pass a positive value only to deliberately run slower or faster.
    """

    @staticmethod
    def resolve_action_interp_factor(action_interp_factor: int, global_downsample_rate: int) -> int:
        """Pick the time-stretch factor for a predicted chunk.

        ``action_interp_factor <= 0`` means "auto": mirror the training frame stride,
        which is the only factor that replays the chunk at the speed it was
        demonstrated at.  A positive value is taken verbatim so the operator can
        deliberately run slower (e.g. to satisfy the async continuity condition).
        """
        if action_interp_factor > 0:
            return int(action_interp_factor)
        return max(1, int(global_downsample_rate))

    def __init__(
        self,
        checkpoint_path: str,
        wan_path: str,
        vlm_path: str,
        config_path: str,
        t5_cache_dir: str = "",
        device: str = "cuda",
        arm_ik=None,
        arm_dof: int = 14,
        ee_dof: int = 1,
        instruction: str = "",
        num_inference_steps: int = 0,
        action_interp_factor: int = 1,
        rtc_enabled: bool = False,
        rtc_inference_delay: int = 8,
        rtc_execution_horizon: int = 16,
        rtc_max_guidance_weight: float = 5.0,
        rtc_schedule: str = "exp",
        rtc_mode: str = "inpaint",
        eef_stats_path: str = "",
        urdf_search_roots: Optional[list] = None,
        max_joint_step: float = 0.5,
    ):
        self.device = device
        self.checkpoint_path = checkpoint_path
        self.wan_path = wan_path
        self.vlm_path = vlm_path
        self.arm_ik = arm_ik
        self.arm_dof = arm_dof
        self.ee_dof = ee_dof
        self.current_instruction = instruction
        self.t5_cache_dir = t5_cache_dir
        self._override_steps = num_inference_steps if num_inference_steps and num_inference_steps > 0 else None

        # --- action interpolation (upsample chunk in time -> slower, smoother) ---
        # 0 = auto: mirror the training frame stride, resolved once config_dict is loaded.
        self._action_interp_factor_arg = int(action_interp_factor)

        # --- RTC (Real-Time Chunking) cross-chunk guidance ---
        self.rtc_enabled = bool(rtc_enabled)
        self.rtc_inference_delay = int(rtc_inference_delay)
        self.rtc_execution_horizon = int(rtc_execution_horizon)
        self.rtc_max_guidance_weight = float(rtc_max_guidance_weight)
        self.rtc_schedule = str(rtc_schedule)
        # Guidance mechanism: "inpaint" (guidance-free clean-space blend),
        # "action_jacobian" (exact VJP through the Action Expert only) or
        # "pi05" (faithful LeRobot pi0.5 reproduction). See the model's
        # _rtc_correct_velocity docstring for the exact formulations.
        self.rtc_mode = str(rtc_mode)
        if self.rtc_mode not in ("inpaint", "action_jacobian", "pi05"):
            raise ValueError(
                "rtc_mode must be 'inpaint', 'action_jacobian' or 'pi05', "
                f"got {self.rtc_mode!r}"
            )

        self._config_path = str(config_path)
        with open(config_path, "r") as f:
            self.config_dict = yaml.safe_load(f)

        self._video_height = self.config_dict["common"]["video_height"]
        self._video_width = self.config_dict["common"]["video_width"]

        # Camera stitch geometry — MUST match the checkpoint's training config.
        # Default "aspect" mirrors G1DLeRobotDataset's default; checkpoints
        # trained before the aspect-preserving switch need "legacy".
        self._stitch_mode = str(
            self.config_dict.get("dataset", {}).get("stitch_mode", "aspect")
        )
        if self._stitch_mode not in ("aspect", "legacy"):
            raise ValueError(
                f"dataset.stitch_mode must be 'aspect' or 'legacy', got {self._stitch_mode!r}"
            )
        logger.info("MotusV2 camera stitch_mode=%s", self._stitch_mode)

        # model action chunk length (raw tokens the model outputs) — needs config_dict
        self._action_chunk_size = int(
            self.config_dict["common"]["num_video_frames"]
            * self.config_dict["common"]["video_action_freq_ratio"]
        )

        # Training frame stride: the 16 emitted actions are spaced this many 30Hz frames
        # apart, but carry no time scale of their own. Executing them one-per-tick would
        # therefore run global_downsample_rate times too fast, so the default interpolation
        # factor mirrors the stride and restores the demonstrated speed.
        self._global_downsample_rate = int(
            self.config_dict["common"].get("global_downsample_rate", 1)
        )
        self.action_interp_factor = self.resolve_action_interp_factor(
            self._action_interp_factor_arg, self._global_downsample_rate
        )
        if self.action_interp_factor != self._global_downsample_rate:
            logger.warning(
                "MotusV2 action_interp_factor=%d != global_downsample_rate=%d: the chunk "
                "spans %.2fs of demonstrated motion but will be executed as %d steps "
                "(%.2fs at 30Hz), i.e. %.2fx the demonstrated speed.",
                self.action_interp_factor, self._global_downsample_rate,
                self._action_chunk_size * self._global_downsample_rate / 30.0,
                self._action_chunk_size * self.action_interp_factor,
                self._action_chunk_size * self.action_interp_factor / 30.0,
                self._global_downsample_rate / max(1, self.action_interp_factor),
            )
        else:
            logger.info(
                "MotusV2 action_interp_factor=%d (matches global_downsample_rate): "
                "%d actions -> %d steps, %.2fs at 30Hz",
                self.action_interp_factor, self._action_chunk_size,
                self._action_chunk_size * self.action_interp_factor,
                self._action_chunk_size * self.action_interp_factor / 30.0,
            )

        self.model = self._load_model()

        # UMT5-XXL is ~11GB in bf16 on the GPU, but it is only needed when an
        # instruction is missing from t5_cache_dir. G1-D deploys one fixed
        # instruction against a pre-populated cache, so load the encoder lazily:
        # in the common (cache-hit) case it is never materialised at all.
        self._t5_checkpoint_path = os.path.join(wan_path, "models_t5_umt5-xxl-enc-bf16.pth")
        self._t5_tokenizer_path = os.path.join(wan_path, "google", "umt5-xxl")
        self.t5_encoder = None
        if self._t5_cache_path(instruction) and self._t5_cache_hit(instruction):
            logger.info(
                "T5 cache hit for the configured instruction -> UMT5-XXL encoder "
                "NOT loaded (saves ~11GB VRAM); it will load on demand if a "
                "later instruction misses the cache."
            )
        else:
            logger.warning(
                "T5 cache miss for instruction=%r (cache_dir=%s) -> the UMT5-XXL "
                "encoder (~11GB VRAM) will be loaded on first use. Pre-populate "
                "the cache to avoid this.",
                instruction, self.t5_cache_dir or "<unset>",
            )

        self.vlm_processor = AutoProcessor.from_pretrained(vlm_path, trust_remote_code=True)

        self.action_queue = []
        self.current_state = None
        self._first_frame = None
        self._t5_cache = {}

        self._setup_action_space(eef_stats_path, urdf_search_roots, max_joint_step)

        logger.info("MotusV2PolicyAdapter initialized (G1-D %s mode)", self.action_mode)

    def _setup_action_space(self, eef_stats_path, urdf_search_roots, max_joint_step):
        """Pick the action representation from the training config.

        Everything Cartesian is built here rather than lazily, so a missing URDF
        or statistics file fails at startup instead of on the first control tick
        with the robot already holding a pose.
        """
        ds_cfg = self.config_dict.get("dataset", {}) or {}
        self.action_mode = str(ds_cfg.get("action_mode", "qpos"))
        if self.action_mode not in ("qpos", "eef", "eef_delta"):
            raise ValueError(f"unsupported dataset.action_mode {self.action_mode!r}")

        self.kinematics = None
        self.state_normalizer = None
        self.action_normalizer = None
        self._ik_seed = None
        # Pose of the most recent state build, waiting to be attached to the
        # chunk that state produced. Kept separate from the pose the chunk being
        # executed was conditioned on: under --async_inference the next state is
        # built while the current chunk still has actions queued, and composing
        # the tail of one chunk onto the other chunk's pose displaces every
        # remaining target by however far the arm travelled in between.
        self._pending_cond_state_abs = None
        self._cond_state_abs = None
        self._reject_count = 0
        self._clamp_count = 0
        self._step_index = 0
        self._normalization_mode = "none"
        self._eef_stats_path = ""
        self._urdf_path = ""
        self._diag_stats = None
        self._range_lo = None
        self._range_hi = None
        self.max_joint_step = float(max_joint_step)
        # Residual above which a target counts as unreachable. Unitree IPOPT
        # trades millimetres for the 0.02||q||^2 home regularizer, so a 5 mm
        # DLS-era gate would reject valid teleop-style solves. 20 mm still
        # blocks the 30 cm misses from a broken policy.
        self.max_ik_error = 2e-2
        if self.action_mode == "qpos":
            return

        roots = list(urdf_search_roots or [])
        roots += [os.environ.get("UNITREE_LEROBOT_ROOT", ""),
                  os.path.join(_MOTUS_ROOT, "assets"), _MOTUS_ROOT,
                  "/home/work/wenjj", "/home/unitree"]
        urdf = _eef.find_urdf(roots)
        if urdf is None:
            raise FileNotFoundError(
                f"action_mode={self.action_mode!r} needs a G1 URDF for FK/IK; looked for "
                f"{list(_eef.URDF_CANDIDATES)} under {roots}. Pass urdf_search_roots or set "
                f"UNITREE_LEROBOT_ROOT."
            )
        self.kinematics = _eef.G1EefKinematics(urdf)
        self._urdf_path = urdf
        logger.info("MotusV2 Cartesian kinematics from %s", urdf)

        # Resolved regardless of whether normalization is on. With it off the
        # statistics scale nothing, but they still carry the physical range the
        # demonstrations covered, which is what the state and target range checks
        # compare against -- and what lets the fingerprint tell a raw checkpoint
        # from a normalized one.
        # Prefer the copy inside the bundle: the path recorded in the config
        # points into the training machine's dataset and will not exist here.
        stats = eef_stats_path
        if not stats and _eef.BUNDLED_STATS.exists():
            stats = str(_eef.BUNDLED_STATS)
        stats = stats or ds_cfg.get("normalization_stats_path") or ""
        self._eef_stats_path = stats if stats and Path(stats).exists() else ""
        self._diag_stats = _eef.load_stats_for_diagnostics(self._eef_stats_path)
        self._range_lo = (np.asarray(self._diag_stats["min"], dtype=np.float64)
                          if self._diag_stats else None)
        self._range_hi = (np.asarray(self._diag_stats["max"], dtype=np.float64)
                          if self._diag_stats else None)

        if bool(ds_cfg.get("normalization", False)):
            if not stats:
                raise ValueError(
                    "the training config has normalization on but no statistics were "
                    f"found: pass --eef_stats_path, or place eef_stats.json at "
                    f"{_eef.BUNDLED_STATS}"
                )
            # Must match training; the config carries it so a checkpoint and its
            # yaml cannot be paired with the wrong scaling.
            mode = str(ds_cfg.get("normalization_mode", "standard"))
            self.state_normalizer, self.action_normalizer = _eef.load_normalizers(
                stats, self.action_mode, mode)
            self._normalization_mode = mode
            logger.info("MotusV2 EEF %s normalization from %s", mode, stats)
        else:
            # Training's _load_normalizers returns (None, None) here, so the
            # dataset feeds the model raw physical units and expects them back:
            # metres and radians for the pose dims, raw opening for the gripper.
            # dataset.normalization_mode is inert in this case on both sides;
            # recording "none" keeps the banner and the fingerprint honest.
            self._normalization_mode = "none"
            logger.warning(
                "training config has normalization OFF: state and actions are raw physical "
                "units on both sides (no scaling applied). This must match how the checkpoint "
                "was trained -- serving a normalized checkpoint this way makes every action "
                "wrong by the normalizer's scale. dataset.normalization_mode=%r is ignored.",
                ds_cfg.get("normalization_mode"),
            )

    def debug_banner(self, frequency: float = 30.0) -> None:
        """Record the artifacts this run is bound to (no-op unless --debug_log).

        Called by the eval loop once the adapter is built, because that is the
        first moment every path has been resolved.
        """
        common = self.config_dict.get("common", {})
        ds_cfg = self.config_dict.get("dataset", {}) or {}
        steps = (self._override_steps
                 or self.config_dict.get("model", {}).get("inference", {})
                 .get("num_inference_timesteps", 0))
        _debug.banner(
            checkpoint=self.checkpoint_path,
            config_path=getattr(self, "_config_path", ""),
            stats_path=self._eef_stats_path,
            urdf=self._urdf_path,
            action_mode=self.action_mode,
            norm_mode=self._normalization_mode,
            chunk=self._action_chunk_size,
            interp=self.action_interp_factor,
            freq=frequency,
            inference_steps=int(steps),
            instruction=self.current_instruction or "",
            stitch_mode=self._stitch_mode,
            extra={
                "max_joint_step": self.max_joint_step,
                "max_ik_error": f"{self.max_ik_error * 1000:.1f} mm",
                "downsample": self._global_downsample_rate,
            },
        )

    def _action_valid_mask(self) -> Optional[torch.Tensor]:
        """Per-dim mask over the action chunk, mirroring
        ``G1DLeRobotDataset._action_valid_mask``.

        The Cartesian layout carries no signal in dims 6/14. Training zeroed them
        in the action encoder's input at every noise level, so sampling has to do
        the same or the encoder sees a channel it was never trained on. Only the
        eef modes have dead dims; qpos uses all 16.
        """
        if self.action_mode == "qpos":
            return None
        mask = getattr(self, "_valid_mask_cache", None)
        if mask is None:
            common = self.config_dict["common"]
            chunk = int(common["num_video_frames"]) * int(common["video_action_freq_ratio"])
            mask = torch.ones(chunk, int(common["action_dim"]), dtype=torch.float32)
            mask[:, list(_eef.RESERVED_DIMS)] = 0.0
            self._valid_mask_cache = mask
        return mask

    def set_instruction(self, instruction: str):
        self.current_instruction = instruction

    def _load_model(self) -> MotusWanVlmDirectMask:
        config = self._create_model_config()
        model = MotusWanVlmDirectMask(config)
        model = model.to(self.device)
        model.load_checkpoint(self.checkpoint_path, strict=False)
        model.eval()
        # Inference never needs parameter gradients. Freezing them also keeps the
        # rtc_mode="action_jacobian" backward confined to the action latent: with
        # frozen weights, autograd only tracks tensors derived from x_t, so the
        # 5B video / VLM branches build no graph at all.
        for param in model.parameters():
            param.requires_grad_(False)
        return model

    def _create_model_config(self) -> MotusWanVlmDirectMaskConfig:
        common = self.config_dict["common"]
        model_cfg = self.config_dict["model"]
        vae_path = os.path.join(self.wan_path, "Wan2.2_VAE.pth")
        hidden_size = model_cfg["action_expert"]["hidden_size"]
        ffn_multiplier = model_cfg["action_expert"]["ffn_dim_multiplier"]

        return MotusWanVlmDirectMaskConfig(
            wan_checkpoint_path=self.wan_path,
            vae_path=vae_path,
            wan_config_path=self.wan_path,
            video_precision="bfloat16",
            vlm_checkpoint_path=self.vlm_path,
            vlm_dim=model_cfg["qwen3_expert"]["vlm_dim"],
            qwen3_expert_head_dim=model_cfg["qwen3_expert"]["head_dim"],
            qwen3_expert_num_heads=model_cfg["qwen3_expert"]["num_heads"],
            qwen3_expert_num_layers=model_cfg["qwen3_expert"]["num_layers"],
            qwen3_expert_norm_eps=float(model_cfg["qwen3_expert"]["norm_eps"]),
            num_layers=model_cfg.get("num_layers", 30),
            action_state_dim=common["state_dim"],
            action_dim=common["action_dim"],
            action_expert_dim=hidden_size,
            action_expert_ffn_dim_multiplier=ffn_multiplier,
            action_expert_norm_eps=float(model_cfg["action_expert"]["norm_eps"]),
            global_downsample_rate=common["global_downsample_rate"],
            video_action_freq_ratio=common["video_action_freq_ratio"],
            num_video_frames=common["num_video_frames"],
            video_loss_weight=1.0,
            action_loss_weight=1.0,
            batch_size=1,
            video_height=common["video_height"],
            video_width=common["video_width"],
            training_mode="finetune",
            load_pretrained_backbones=False,
            vlm_frozen=False,
        )

    def reset(self):
        self.action_queue = []
        self.current_state = None
        self._first_frame = None
        # Cartesian state: drop the pose the last chunk was conditioned on and the
        # IK warm start, so a new episode cannot inherit the old arm branch.
        self._cond_state_abs = None
        self._pending_cond_state_abs = None
        self._ik_seed = None
        self._reject_count = 0
        self._clamp_count = 0
        if self.kinematics is not None:
            self.kinematics.reset()

    @staticmethod
    def _to_arm_interleaved(vec: np.ndarray) -> np.ndarray:
        """Reorder raw 16-dim [L7, R7, LG, RG] → [L7, LG, R7, RG].

        Matches g1d_dataset._to_arm_interleaved and multi_source_pretrain
        per-arm layout. Grippers move from dims 14/15 to dims 7/15.
        """
        return vec[_REORDER_FROM_RAW]

    @staticmethod
    def _from_arm_interleaved(vec: np.ndarray) -> np.ndarray:
        """Inverse reorder: [L7, LG, R7, RG] → [L7, R7, LG, RG].

        Maps dims: new[0:7]→old[0:7], new[7]→old[14], new[8:15]→old[7:14], new[15]→old[15].
        """
        out = np.empty(16, dtype=vec.dtype)
        out[0:7] = vec[0:7]
        out[14] = vec[7]
        out[7:14] = vec[8:15]
        out[15] = vec[15]
        return out

    def _decode_and_resize_cam(self, img: np.ndarray) -> np.ndarray:
        """Resize single camera image to full video_size (first pass of LEGACY double-resize).

        Matches g1d_dataset._decode_frames: resize_with_padding to video_size, uint8 → float32 [0,1].
        """
        resized = resize_with_padding(img, (self._video_height, self._video_width))
        if resized.dtype == np.uint8:
            resized = resized.astype(np.float32) / 255.0
        return resized

    def _t_shape_geometry(self, top_hw: tuple, bl_hw: tuple, br_hw: tuple) -> dict:
        """Solve the aspect-preserving T-shape layout.

        Must stay identical to G1DLeRobotDataset.t_shape_geometry, otherwise the
        deployed policy sees a different camera layout than it was trained on.
        """
        th, tw = self._video_height, self._video_width
        split_w = tw // 2
        right_w = tw - split_w

        def _natural_h(hw: tuple, target_w: int) -> int:
            h, w = hw
            return max(1, int(round(h * target_w / w)))

        bot_h = max(_natural_h(bl_hw, split_w), _natural_h(br_hw, right_w))
        bot_h = min(bot_h, th - 1)
        top_h = min(_natural_h(top_hw, tw), th - bot_h)
        natural_h = top_h + bot_h
        pad_top = (th - natural_h) // 2
        return {
            "top_h": top_h,
            "bot_h": bot_h,
            "split_w": split_w,
            "right_w": right_w,
            "pad_top": pad_top,
            "pad_bottom": th - natural_h - pad_top,
        }

    def build_stitched_image(
        self,
        head_img: np.ndarray,
        left_wrist_img: np.ndarray,
        right_wrist_img: np.ndarray,
    ) -> np.ndarray:
        """
        T-shape stitch, matching g1d_dataset._stitch_t_shape exactly.

        stitch_mode="aspect" (default): each camera is resized ONCE, straight
        into its sub-region, preserving its native aspect ratio.  For G1-D's
        480x640 cameras at 384x320:
            top (cam_left_high):          240 x 320  (full width, no padding)
            bottom-left/right (wrists):   120 x 160  (half width, no padding)
            natural height 360 -> 12px black strip at the top and bottom
        cam_left_high gets 62.5% of the canvas here; 320 is the canvas width, so
        240x320 is the largest it can be without distortion.

        stitch_mode="legacy": the old double resize (each camera resize-padded
        to the full 384x320 first, then re-resized into a fixed 50/50 split),
        which wasted 53.1% of the canvas on black padding and left
        cam_left_high at only 120x160.  Kept for checkpoints trained before the
        switch — it MUST match whatever the checkpoint was trained with.

        Layout:
            ┌────────────────────┐
            │     top (head)      │   top_h × video_width
            ├─────────┬──────────┤
            │ bl_wrist│ br_wrist │   bot_h × video_width//2 each
            └─────────┴──────────┘

        Input images are uint8 HWC. Returns float32 HWC [0,1] at (video_height, video_width).
        """
        th, tw = self._video_height, self._video_width

        if self._stitch_mode == "aspect":
            geo = self._t_shape_geometry(
                head_img.shape[:2], left_wrist_img.shape[:2], right_wrist_img.shape[:2]
            )
            top_h, bot_h = geo["top_h"], geo["bot_h"]
            split_w, right_w = geo["split_w"], geo["right_w"]
            y0 = geo["pad_top"]

            canvas = np.zeros((th, tw, 3), dtype=np.uint8)
            canvas[y0:y0 + top_h, :, :] = resize_with_padding(head_img, (top_h, tw))
            yb = y0 + top_h
            canvas[yb:yb + bot_h, :split_w, :] = resize_with_padding(left_wrist_img, (bot_h, split_w))
            canvas[yb:yb + bot_h, split_w:, :] = resize_with_padding(right_wrist_img, (bot_h, right_w))
            return canvas.astype(np.float32) / 255.0

        # --- legacy double resize ---
        top_full = self._decode_and_resize_cam(head_img)
        bl_full = self._decode_and_resize_cam(left_wrist_img)
        br_full = self._decode_and_resize_cam(right_wrist_img)

        top_h = th // 2
        bottom_h = th - top_h
        split_w = tw // 2
        right_w = tw - split_w

        def _to_sub_region(frames_full: np.ndarray, sub_h: int, sub_w: int) -> np.ndarray:
            if frames_full.shape[0] == sub_h and frames_full.shape[1] == sub_w:
                return frames_full
            arr_uint8 = (frames_full * 255.0).clip(0, 255).astype("uint8")
            resized = resize_with_padding(arr_uint8, (sub_h, sub_w))
            return resized.astype(np.float32) / 255.0

        top_r = _to_sub_region(top_full, top_h, tw)
        bl_r = _to_sub_region(bl_full, bottom_h, split_w)
        br_r = _to_sub_region(br_full, bottom_h, right_w)

        stitched = np.zeros((th, tw, 3), dtype=np.float32)
        stitched[:top_h, :] = top_r
        stitched[top_h:, :split_w] = bl_r
        stitched[top_h:, split_w:] = br_r

        return stitched

    def observation_to_model_input(
        self,
        observation: dict,
        current_arm_q: np.ndarray,
        ee_shared_mem: dict,
    ) -> tuple:
        """
        Convert G1 observation dict to MotusV2 model inputs.

        Image: cam_left_high → top, cam_left_wrist → bottom-left, cam_right_wrist → bottom-right.
        cam_right_high is UNUSED (matches training).

        State: 16-dim qpos in [L7, LG, R7, RG] interleaved layout.
        Built from current_arm_q[0:7] (left) + left_gripper + current_arm_q[7:14] (right) + right_gripper,
        then reordered to match training's _to_arm_interleaved layout.

        Returns:
            first_frame: [1, 3, H, W] float32 tensor in [0,1]
            state_tensor: [1, 16] float32 tensor (qpos interleaved layout)
        """
        import time as _time

        t0 = _time.perf_counter()
        head_left = observation.get("observation.images.cam_left_high")

        def _to_uint8_hwc(img):
            if isinstance(img, torch.Tensor):
                img = img.cpu().numpy()
            if img is not None and img.dtype != np.uint8:
                if img.max() <= 1.0:
                    img = (img * 255).astype(np.uint8)
                else:
                    img = img.astype(np.uint8)
            return img

        head_img = _to_uint8_hwc(head_left)
        if head_img is None:
            raise ValueError("Missing cam_left_high image for MotusV2 stitching")

        left_wrist = _to_uint8_hwc(observation.get("observation.images.cam_left_wrist"))
        right_wrist = _to_uint8_hwc(observation.get("observation.images.cam_right_wrist"))

        if left_wrist is None or right_wrist is None:
            raise ValueError("Missing wrist camera images for MotusV2 stitching")
        t_convert = _time.perf_counter() - t0

        t0 = _time.perf_counter()
        stitched = self.build_stitched_image(head_img, left_wrist, right_wrist)
        first_frame = torch.from_numpy(stitched).permute(2, 0, 1).unsqueeze(0).float()
        first_frame = first_frame.to(self.device)
        t_stitch = _time.perf_counter() - t0

        t0 = _time.perf_counter()
        left_grip_val = 0.0
        right_grip_val = 0.0
        if ee_shared_mem:
            with ee_shared_mem["lock"]:
                full_state = np.array(ee_shared_mem["state"][:])
                left_grip_val = float(full_state[:self.ee_dof][0])
                right_grip_val = float(full_state[self.ee_dof:][0])

        if self.action_mode == "qpos":
            raw_state = np.zeros(16, dtype=np.float32)
            raw_state[0:7] = current_arm_q[0:7]
            raw_state[7:14] = current_arm_q[7:14]
            raw_state[14] = left_grip_val
            raw_state[15] = right_grip_val
            state = self._to_arm_interleaved(raw_state)
        else:
            # Cartesian modes: the state is the TCP pose, so it comes from FK on
            # the measured joints rather than from the joints themselves. It stays
            # absolute even in eef_delta -- the offsets the model predicts are
            # only interpretable against where the arms currently are.
            state = self.kinematics.fk_state(
                np.asarray(current_arm_q, dtype=np.float64)[:14],
                left_grip_val, right_grip_val)
            # Staged, not applied: build_exec_queue attaches it to the chunk this
            # state produces. Applying it here would retarget the chunk already
            # executing (see _pending_cond_state_abs).
            self._pending_cond_state_abs = state.copy()
            raw_state_abs = state
            if self.state_normalizer is not None:
                state = self.state_normalizer.normalize(state).astype(np.float32)
            # Reported in every mode: "is the robot showing the policy something
            # it never saw" is the first thing to rule out, and it does not
            # depend on whether anything was scaled.
            self._debug_state(current_arm_q, raw_state_abs,
                              state if self.state_normalizer is not None else None,
                              left_grip_val, right_grip_val)

        state_tensor = torch.from_numpy(state).float().unsqueeze(0)
        state_tensor = state_tensor.to(self.device)
        t_state = _time.perf_counter() - t0

        self._first_frame = first_frame
        self.current_state = state_tensor

        logger.info(
            "[observation_to_model_input]\n"
            "    img_convert      : %7.1f ms\n"
            "    stitch_to_device : %7.1f ms\n"
            "    state_build      : %7.1f ms\n"
            "    %-16s : %7.1f ms",
            t_convert * 1000, t_stitch * 1000, t_state * 1000,
            "TOTAL", (t_convert + t_stitch + t_state) * 1000,
        )

        return first_frame, state_tensor

    def qpos_action_to_g1_action(self, qpos_action_16: np.ndarray) -> tuple:
        """
        Convert 16-dim qpos action (training interleaved layout) to G1 control format.

        Training layout: [L7, LG, R7, RG] (gripper at dims 7/15).
        We inverse-reorder to raw [L7, R7, LG, RG], then split into:
            arm_action: [14] = [L7, R7] joint angles (radians)
            left_grip: scalar
            right_grip: scalar

        NO IK is needed — the model directly outputs joint angles (qpos).
        """
        if qpos_action_16.shape[0] != 16:
            raise ValueError(f"Expected 16-dim qpos action, got {qpos_action_16.shape[0]}")

        raw = self._from_arm_interleaved(qpos_action_16)
        arm_action = np.concatenate([raw[0:7], raw[7:14]])
        left_grip = raw[14]
        right_grip = raw[15]

        return arm_action, left_grip, right_grip

    def _debug_state(self, current_arm_q, raw_abs, normalized, left_grip, right_grip):
        """Report where the conditioning state sits relative to what training saw.

        The model only ever received normalized inputs inside [0, 1]. A state dim
        outside that means the robot is presenting something the policy has no
        basis for, which produces bad actions without anything downstream being
        wrong -- so it is the first thing to rule out.
        """
        lo, hi = self._range_lo, self._range_hi
        bad = _eef.out_of_range(raw_abs, lo, hi) if lo is not None else []
        level = logger.warning if bad else logger.info
        level(
            "[eef state] joints=%s grip=(%.4f, %.4f)\n"
            "    absolute   : %s\n"
            "    %s\n"
            "    outside the training range: %s",
            np.round(np.asarray(current_arm_q, dtype=np.float64)[:14], 4),
            left_grip, right_grip,
            _eef.describe(raw_abs, lo, hi),
            (f"normalized : {_eef.describe(normalized)}" if normalized is not None
             else "normalized : (none: the model consumes raw physical units)"),
            ", ".join(bad) if bad else ("none" if lo is not None else "(no statistics)"),
        )

    def debug_chunk(self, actions: np.ndarray, cond: Optional[np.ndarray] = None) -> None:
        """Summarise a freshly predicted Cartesian chunk against training ranges.

        Answers, in order: did the model emit normalized values in the range it
        was trained to emit; do those denormalize to physically plausible offsets;
        and do the resulting absolute poses stay inside the workspace the
        statistics were built from.

        ``cond`` is the pose this chunk was conditioned on, which is not
        necessarily the one currently being executed.
        """
        if cond is None:
            cond = self._cond_state_abs
        if self.action_mode == "qpos" or cond is None:
            return
        an = self.action_normalizer
        raw = np.asarray(actions, dtype=np.float64)
        live = [i for i in range(16) if i not in _eef.RESERVED_DIMS]

        # Runs in every mode, including normalization off, where "none" is just
        # another hypothesis the fingerprint can confirm. Which fraction lands
        # outside [0, 1] is only meaningful under minmax; standard targets are
        # zero-mean unit-variance, so about half are below 0 by construction.
        # Reading that as a fault is what sent an earlier diagnosis down the
        # wrong path, so the verdict is made against the configured mode.
        fp = _debug.fingerprint(raw, self._normalization_mode, self._diag_stats)
        deltas = an.denormalize(raw) if an is not None else raw
        targets = _eef.from_delta(cond, deltas)

        lo, hi = self._range_lo, self._range_hi
        span = []
        if lo is not None:
            for i in live:
                below = int((targets[:, i] < lo[i] - 1e-6).sum())
                above = int((targets[:, i] > hi[i] + 1e-6).sum())
                if below or above:
                    span.append(f"{_eef.DIM_NAMES[i]}({below}<,{above}>)")

        d_xyz = np.concatenate([np.linalg.norm(deltas[:, s], axis=1) for s in _eef.XYZ_SLICES])
        d_rot = np.concatenate([np.linalg.norm(deltas[:, s], axis=1) for s in _eef.ROT_SLICES])
        logger.info(
            "[eef chunk] %d actions\n"
            "    raw output (pose dims)       : mean %+.3f std %.3f -> looks like %s "
            "(config says %s)\n"
            "    |delta xyz| over the chunk   : median %.1f mm  max %.1f mm\n"
            "    |delta rot| over the chunk   : median %.4f rad max %.4f rad\n"
            "    first target : %s\n"
            "    last  target : %s\n"
            "    targets outside the training range: %s",
            len(raw), fp["mean"], fp["std"], fp["looks_like"], fp["configured"],
            np.median(d_xyz) * 1000, d_xyz.max() * 1000,
            np.median(d_rot), d_rot.max(),
            _eef.describe(targets[0]), _eef.describe(targets[-1]),
            " ".join(span) if span else ("none" if lo is not None else "(no statistics)"),
        )

        if _debug.on():
            _debug.check_fingerprint(raw, self._normalization_mode, self._diag_stats)
            self._chunk_index = getattr(self, "_chunk_index", -1) + 1
            _debug.chunk(
                index=self._chunk_index, cond_abs=cond, deltas=deltas, targets=targets,
                raw=raw, dim_names=_eef.DIM_NAMES, lo=lo, hi=hi,
                predict_ms=float(getattr(self, "_last_predict_ms", 0.0)),
            )

    def eef_action_to_g1_action(self, eef_action_16: np.ndarray,
                                current_arm_q: np.ndarray,
                                cond: Optional[np.ndarray] = None) -> tuple:
        """Convert one 16-dim Cartesian action to G1 joint targets.

        Chain: denormalize -> (eef_delta only) compose onto the condition-frame
        pose the state was built from -> IK -> 14 joint angles. Grippers pass
        through, since they are the same scalar in every action mode.

        ``cond`` is the pose the chunk this action belongs to was conditioned on.
        ``step`` supplies it from the queue entry; it falls back to the last
        state build only for direct callers.

        The IK is Unitree's CasADi/IPOPT solver, seeded from the previous
        solution (falling back to the measured joints on the first tick of a
        chunk). Seeding from the measurement every tick would be worse: the
        robot lags its target, so the seed would pull each solve back towards
        where the arm is rather than where it is going.
        """
        if eef_action_16.shape[0] != 16:
            raise ValueError(f"Expected 16-dim EEF action, got {eef_action_16.shape[0]}")

        act = np.asarray(eef_action_16, dtype=np.float64)
        if self.action_normalizer is not None:
            act = self.action_normalizer.denormalize(act)
        if self.action_mode == "eef_delta":
            if cond is None:
                cond = getattr(self, "_cond_state_abs", None)
            if cond is None:
                raise RuntimeError(
                    "eef_delta needs the absolute pose the chunk was conditioned on; "
                    "call observation_to_model_input before step()"
                )
            act = _eef.from_delta(cond, act)[0]

        seed = self._ik_seed
        if seed is None:
            seed = np.asarray(current_arm_q, dtype=np.float64)[:14]
        _t_ik = _time.perf_counter()
        q, err, retried = self.kinematics.ik(act, seed)
        ik_ms = (_time.perf_counter() - _t_ik) * 1000.0

        step = float(np.abs(q - seed).max())
        guard = ""
        if err > self.max_ik_error:
            # An unreachable target is the dangerous case: IK returns its best
            # effort, which drives joints onto their stops. Each individual step
            # can stay under max_joint_step while the arm walks itself into a
            # contorted posture over many of them, so this has to be caught by
            # the residual rather than by the step size. Holding matches teleop,
            # which returns the measured joints when IPOPT cannot reach.
            self._reject_count += 1
            guard = "unreachable"
            logger.warning("[eef ik] rejected (unreachable, residual %.1f mm, retried=%s); "
                           "holding previous target. %d rejections so far",
                           err * 1000.0, retried, self._reject_count)
            q = seed
        elif step > self.max_joint_step:
            # Advance toward the solution at the guard's rate instead of holding.
            # Holding froze the seed while the targets kept moving away, so every
            # later solve tripped the same guard and the arm never moved again.
            # Scaling the whole joint delta (rather than clipping per joint)
            # keeps the direction of travel, and both endpoints obey the box
            # limits so the interpolated point does too.
            q = seed + (q - seed) * (self.max_joint_step / step)
            self._clamp_count += 1
            guard = "joint_step"
            logger.warning("[eef ik] step %.3f rad over max_joint_step %.3f; advancing at the "
                           "limit (retried=%s). %d clamped steps so far",
                           step, self.max_joint_step, retried, self._clamp_count)
        else:
            margin = float(np.minimum(q - self.kinematics.lo, self.kinematics.hi - q).min())
            if margin < 0.05:
                # Riding a joint stop is what a contorted posture looks like from
                # here, and it means the targets are leaving the trained workspace.
                logger.warning("[eef ik] a joint is %.3f rad from its limit "
                               "(err=%.3f mm) -- targets are near the workspace edge",
                               margin, err * 1000.0)

        self._ik_seed = q
        if _debug.on():
            self._step_index += 1
            _debug.step(index=self._step_index, q_cmd=q, q_meas=current_arm_q,
                        ik_err=err, joint_step=step, guard=guard,
                        queue=len(self.action_queue), ik_ms=ik_ms)
        return q.astype(np.float32), float(act[_eef.GRIPPER_DIMS[0]]), float(act[_eef.GRIPPER_DIMS[1]])

    def _t5_cache_path(self, instruction: str) -> Optional[str]:
        """Disk-cache path for an instruction's T5 embedding (None if no cache dir)."""
        if not self.t5_cache_dir:
            return None
        import hashlib
        key = hashlib.sha1(instruction.encode("utf-8")).hexdigest()
        return os.path.join(self.t5_cache_dir, f"{key}.pt")

    def _t5_cache_hit(self, instruction: str) -> bool:
        path = self._t5_cache_path(instruction)
        return bool(path and os.path.exists(path))

    def _ensure_t5_encoder(self) -> T5EncoderModel:
        """Materialise the UMT5-XXL encoder on first cache miss (~11GB VRAM)."""
        if self.t5_encoder is None:
            logger.warning(
                "Loading UMT5-XXL text encoder on demand (~11GB VRAM) — "
                "this happens only on a T5 cache miss."
            )
            self.t5_encoder = T5EncoderModel(
                text_len=512,
                dtype=torch.bfloat16,
                device=self.device,
                checkpoint_path=self._t5_checkpoint_path,
                tokenizer_path=self._t5_tokenizer_path,
            )
        return self.t5_encoder

    def _get_t5_embedding(self, instruction: str) -> torch.Tensor:
        cache_path = self._t5_cache_path(instruction)
        if cache_path and os.path.exists(cache_path):
            try:
                emb = torch.load(cache_path, map_location="cpu", weights_only=True)
                return emb.float()
            except Exception:
                logger.warning("Failed to read T5 cache %s; re-encoding", cache_path)

        with torch.no_grad():
            t5_out = self._ensure_t5_encoder()([instruction], self.device)

        if isinstance(t5_out, torch.Tensor):
            emb = t5_out.squeeze(0) if t5_out.dim() == 3 else t5_out
        elif isinstance(t5_out, list):
            emb = t5_out[0]
        else:
            raise ValueError("Unexpected T5 encoder output format")

        emb = emb.detach().cpu().float()
        if emb.ndim == 3 and emb.shape[0] == 1:
            emb = emb.squeeze(0)
        if emb.shape[0] < 512:
            pad = emb.new_zeros(512 - emb.shape[0], emb.shape[1])
            emb = torch.cat([emb, pad], dim=0)
        elif emb.shape[0] > 512:
            emb = emb[:512]

        if cache_path:
            os.makedirs(self.t5_cache_dir, exist_ok=True)
            tmp_path = cache_path + f".tmp_{os.getpid()}"
            torch.save(emb, tmp_path)
            os.replace(tmp_path, cache_path)

        return emb

    def interpolate_chunk(self, actions: np.ndarray) -> np.ndarray:
        """Upsample a raw action chunk [T, A] along time to [T*factor, A].

        Actions are absolute qpos targets, so linear interpolation in joint space
        produces valid intermediate poses. Executing the longer chunk at the same
        control frequency stretches the same trajectory over more wall-clock time
        (slower, smoother motion) so that one inference covers > one inference of
        wall-clock -> enables continuous async execution.

        Cartesian modes take the rotation dims through SO(3) instead: those three
        numbers are a rotation vector, and averaging two of them componentwise is
        not the rotation halfway between.
        """
        f = self.action_interp_factor
        if f <= 1:
            return actions
        if self.action_mode != "qpos":
            return self._interpolate_chunk_eef(actions, f)
        T, A = actions.shape
        N = T * f
        xp = np.arange(T, dtype=np.float64)
        xq = np.linspace(0.0, T - 1, N)
        out = np.empty((N, A), dtype=actions.dtype)
        for a in range(A):
            out[:, a] = np.interp(xq, xp, actions[:, a])
        return out

    def _interpolate_chunk_eef(self, actions: np.ndarray, f: int) -> np.ndarray:
        """Time-upsample a Cartesian chunk: linear on translation and gripper,
        slerp on the per-arm rotation vectors."""
        from scipy.spatial.transform import Rotation, Slerp

        T = actions.shape[0]
        xp = np.arange(T, dtype=np.float64)
        xq = np.linspace(0.0, T - 1, T * f)
        out = np.empty((len(xq), actions.shape[1]), dtype=actions.dtype)
        for a in range(actions.shape[1]):
            out[:, a] = np.interp(xq, xp, actions[:, a])
        for rot in _eef.ROT_SLICES:
            key = Rotation.from_rotvec(np.asarray(actions[:, rot], dtype=np.float64))
            out[:, rot] = Slerp(xp, key)(xq).as_rotvec()
        for d in _eef.RESERVED_DIMS:
            out[:, d] = 0.0
        return out

    def build_exec_queue(self, raw_actions: np.ndarray) -> list:
        """Turn a raw model chunk [T, A] into the executable action queue,
        applying interpolation if enabled.

        Entries are ``(action[A], cond)`` pairs. Carrying the condition pose per
        entry is what keeps a chunk decoding against the pose it was predicted
        from: the async loop builds the next state, and so the next condition
        pose, while this chunk still has actions left to execute.
        """
        cond = self._pending_cond_state_abs
        if cond is None:
            cond = self._cond_state_abs
        self.debug_chunk(raw_actions, cond)
        exec_actions = self.interpolate_chunk(raw_actions)
        return [(exec_actions[i], cond) for i in range(exec_actions.shape[0])]

    @staticmethod
    def _rtc_prefix_weights(start: int, end: int, total: int, schedule: str = "exp") -> torch.Tensor:
        """Prefix attention weights (ported from LeRobot RTCProcessor.get_prefix_weights).

        weights[:start]=1 (freeze toward previous chunk), then decay to 0 by `end`.
        `start`=inference_delay, `end`=execution_horizon, `total`=chunk size.
        """
        import math
        start = min(start, end)
        if schedule == "zeros":
            w = np.zeros(total, dtype=np.float64)
            w[:start] = 1.0
        elif schedule == "ones":
            w = np.ones(total, dtype=np.float64)
            w[end:] = 0.0
        else:  # "linear" or "exp"
            skip_end = max(total - end, 0)
            nlin = total - skip_end - start
            if end <= start or nlin <= 0:
                lin = np.zeros(0, dtype=np.float64)
            else:
                lin = np.linspace(1.0, 0.0, nlin + 2)[1:-1]
                if schedule == "exp" and lin.size > 0:
                    lin = lin * np.expm1(lin) / (math.e - 1.0)
            if total - end > 0:
                lin = np.concatenate([lin, np.zeros(total - end, dtype=np.float64)])
            if start > 0:
                lin = np.concatenate([np.ones(min(start, total), dtype=np.float64), lin])
            w = lin[:total]
            if w.shape[0] < total:  # safety pad
                w = np.concatenate([w, np.zeros(total - w.shape[0], dtype=np.float64)])
        return torch.tensor(w, dtype=torch.float32)

    @torch.no_grad()
    def predict_action_chunk(
        self,
        first_frame: torch.Tensor,
        state: torch.Tensor,
        prev_chunk_left_over: Optional[np.ndarray] = None,
        rtc_inference_delay: Optional[int] = None,
    ) -> np.ndarray:
        """
        Run MotusV2 inference and return action chunk [16, 16].

        rtc_inference_delay: optional per-call override for the RTC frozen-prefix
        length (in RAW action steps). The caller should pass the number of raw
        steps expected to elapse during THIS inference (estimated from the
        previous cycle) so the frozen region matches the splice boundary. Falls
        back to self.rtc_inference_delay when None.

        G1-D uses plain instruction text for both T5 and VLM (no scene_prefix, no motion-token prompt).
        Matches training: g1d_dataset uses preprocess_vlm_messages(instr, ...) with plain text,
        and T5 disk_cache encodes plain instruction text.
        """
        import time as _time

        t0 = _time.perf_counter()
        language_embedding = self._get_t5_embedding(self.current_instruction)
        t5_list = [language_embedding]
        t_t5 = _time.perf_counter() - t0

        t0 = _time.perf_counter()
        first_frame_pil = self._tensor_to_pil(first_frame.squeeze(0).cpu())
        t_pil = _time.perf_counter() - t0

        t0 = _time.perf_counter()
        vlm_inputs = preprocess_vlm_messages(
            self.current_instruction, first_frame_pil, self.vlm_processor
        )
        t_vlm_pre = _time.perf_counter() - t0

        t0 = _time.perf_counter()
        vlm_inputs_device = {
            "input_ids": vlm_inputs["input_ids"].to(self.device),
            "attention_mask": vlm_inputs["attention_mask"].to(self.device),
            "pixel_values": vlm_inputs["pixel_values"].to(self.device),
        }
        if "image_grid_thw" in vlm_inputs and vlm_inputs["image_grid_thw"] is not None:
            vlm_inputs_device["image_grid_thw"] = vlm_inputs["image_grid_thw"].to(self.device)
        if "mm_token_type_ids" in vlm_inputs and vlm_inputs["mm_token_type_ids"] is not None:
            vlm_inputs_device["mm_token_type_ids"] = vlm_inputs["mm_token_type_ids"].to(self.device)
        t_to_device = _time.perf_counter() - t0

        num_inference_steps = self._override_steps if self._override_steps else self.config_dict["model"]["inference"]["num_inference_timesteps"]

        # RTC guidance inputs (only when enabled and a previous chunk is available)
        rtc_prev = None
        rtc_weights = None
        if self.rtc_enabled and prev_chunk_left_over is not None:
            rtc_prev = torch.from_numpy(np.asarray(prev_chunk_left_over, dtype=np.float32)).to(self.device)
            eff_delay = self.rtc_inference_delay if rtc_inference_delay is None else int(rtc_inference_delay)
            # Freeze at most execution_horizon-1 so there is always a free region.
            eff_delay = max(1, min(eff_delay, self.rtc_execution_horizon - 1, self._action_chunk_size - 1))
            rtc_weights = self._rtc_prefix_weights(
                eff_delay, self.rtc_execution_horizon,
                self._action_chunk_size, self.rtc_schedule,
            ).to(self.device)
            logger.info(
                "[rtc-chunk] mode=%s schedule=%s | frozen_delay=%d (requested=%s) "
                "horizon=%d chunk=%d | prev_leftover=%d",
                self.rtc_mode, self.rtc_schedule, eff_delay,
                "cfg" if rtc_inference_delay is None else str(int(rtc_inference_delay)),
                self.rtc_execution_horizon, self._action_chunk_size,
                int(rtc_prev.shape[0]),
            )

        t0 = _time.perf_counter()
        with torch.autocast(device_type="cuda", dtype=torch.bfloat16):
            _, predicted_actions = self.model.inference_step(
                first_frame=first_frame,
                state=state,
                num_inference_steps=num_inference_steps,
                language_embeddings=t5_list,
                vlm_inputs=vlm_inputs_device,
                decode_video=False,  # real-robot control only needs actions; skip ~1s VAE decode
                rtc_prev_chunk=rtc_prev,
                rtc_weights=rtc_weights,
                rtc_max_guidance_weight=self.rtc_max_guidance_weight,
                rtc_mode=self.rtc_mode,
                action_valid_mask=self._action_valid_mask(),
            )
        t_forward = _time.perf_counter() - t0
        self._last_predict_ms = t_forward * 1000.0

        t0 = _time.perf_counter()
        actions_np = predicted_actions.squeeze(0).cpu().float().numpy()
        t_post = _time.perf_counter() - t0

        t_total = t_t5 + t_pil + t_vlm_pre + t_to_device + t_forward + t_post
        logger.info(
            "[predict_action_chunk] steps=%d rtc=%s\n"
            "    t5_embedding   : %7.1f ms\n"
            "    pil_convert    : %7.1f ms\n"
            "    vlm_preprocess : %7.1f ms\n"
            "    to_device      : %7.1f ms\n"
            "    model_forward  : %7.1f ms  (%4.1f%%)\n"
            "    post_process   : %7.1f ms\n"
            "    %-14s : %7.1f ms",
            num_inference_steps,
            self.rtc_mode if rtc_prev is not None else "off",
            t_t5 * 1000, t_pil * 1000, t_vlm_pre * 1000, t_to_device * 1000,
            t_forward * 1000, 100.0 * t_forward / max(t_total, 1e-9),
            t_post * 1000,
            "TOTAL", t_total * 1000,
        )

        return actions_np

    def step(self, current_arm_q: np.ndarray) -> Optional[tuple]:
        """
        Return the next (arm_action, left_grip, right_grip) from the action queue.
        If queue is empty, return None (caller should call predict first).

        Args:
            current_arm_q: Current arm joint angles [14]. Unused in qpos mode;
                in the Cartesian modes it seeds IK on the first tick of a chunk.

        Returns:
            (arm_action[14], left_grip_scalar, right_grip_scalar) or None
        """
        if not self.action_queue:
            return None

        entry = self.action_queue.pop(0)
        # build_exec_queue emits (action, cond) pairs; a bare vector is still
        # accepted so a caller can hand-feed the queue against _cond_state_abs.
        cond = None
        if isinstance(entry, tuple):
            entry, cond = entry
        if self.action_mode == "qpos":
            return self.qpos_action_to_g1_action(entry)
        if cond is not None:
            # Report the pose the action being executed is measured from, which
            # is what the diagnostics should show.
            self._cond_state_abs = cond
        return self.eef_action_to_g1_action(entry, current_arm_q, cond)

    @property
    def has_cached_actions(self) -> bool:
        return len(self.action_queue) > 0

    def _tensor_to_pil(self, tensor_chw: torch.Tensor) -> Image.Image:
        if tensor_chw.dtype != torch.float32:
            tensor_chw = tensor_chw.float()
        tensor_chw = tensor_chw.clamp(0, 1)
        np_img = (tensor_chw.permute(1, 2, 0).numpy() * 255.0).astype(np.uint8)
        return Image.fromarray(np_img, mode="RGB")

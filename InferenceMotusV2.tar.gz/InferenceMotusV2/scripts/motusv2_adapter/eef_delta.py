"""Cartesian EEF action space for the G1-D inference loop.

Mirrors the training side so a checkpoint trained with ``action_mode:
"eef_delta"`` can be executed on the robot. The inference bundle cannot import
from MotusV2, so the conventions below are duplicated; every one of them is
pinned to its source and asserted by tests/test_eef_delta_parity.py, which fails
if the two drift apart.

Sources:
    layout / to_delta / from_delta   MotusV2/data/g1d/eef_actions.py
    TCP_OFFSET, REPORT_FRAME_TO_TORSO, FK
                                     MotusV2/tools/g1_qpos_to_eef.py
    min-max normalisation            MotusV2/data/g1d/g1d_dataset.py
    IK (CasADi/IPOPT, cost weights)  unitree_eai/.../robot_arm_ik.py ``G1_29_ArmIK``

16-dim layout, two symmetric 8-dim per-arm blocks:
    [xyz(3), rotvec(3), reserved(1), gripper(1)]
with grippers at 7/15 and reserved dims 6/14 always zero.

Reference frame. Poses are absolute in the frame the G1-D controller reports in,
which is ``torso_link`` shifted by ``REPORT_FRAME_TO_TORSO``. With the waist at
zero that is exactly the pelvis of the reduced model ``G1_29_ArmIK`` builds, so a
target produced here can also be handed to ``G1_29_ArmIK.solve_ik`` unchanged.
"""

from __future__ import annotations

import json
import os
import logging
from pathlib import Path
from typing import Optional, Sequence

import numpy as np

logger = logging.getLogger(__name__)

ACTION_DIM = 16
ARM_BASES = (0, 8)
XYZ_SLICES = tuple(slice(b, b + 3) for b in ARM_BASES)
ROT_SLICES = tuple(slice(b + 3, b + 6) for b in ARM_BASES)
RESERVED_DIMS = (6, 14)
GRIPPER_DIMS = (7, 15)

TCP_OFFSET = np.array([0.05, 0.0, 0.0])
REPORT_FRAME_TO_TORSO = np.array([-0.0039635, 0.0, 0.044])

ARM_JOINTS = [
    f"{side}_{j}_joint"
    for side in ("left", "right")
    for j in ("shoulder_pitch", "shoulder_roll", "shoulder_yaw", "elbow",
              "wrist_roll", "wrist_pitch", "wrist_yaw")
]

# Arm chains are bit-identical between these two (same joint origins, axes,
# parents and limits), so either reproduces the training FK exactly. The
# dexterous-hand model is listed first because it is the one that ships with
# unitree_lerobot and is therefore present on the robot. Paths are relative and
# tried against several roots because the same checkout appears both flat and
# nested (``unitree_lerobot/unitree_lerobot/...``) depending on how it was
# installed.
URDF_CANDIDATES = (
    "g1_body29_hand14.urdf",
    "g1_d.urdf",
    "eval_robot/assets/g1/g1_body29_hand14.urdf",
    "unitree_lerobot/eval_robot/assets/g1/g1_body29_hand14.urdf",
    "unitree_lerobot/unitree_lerobot/eval_robot/assets/g1/g1_body29_hand14.urdf",
    "robots/g1_d_description/g1_d.urdf",
    "unitree_ros/robots/g1_d_description/g1_d.urdf",
)

# .../InferenceMotusV2 -- the directory that gets copied to the robot.
BUNDLE_ROOT = Path(__file__).resolve().parents[2]
BUNDLE_ASSETS = BUNDLE_ROOT / "assets"
# Shipped inside the bundle so a deployment needs neither the training dataset
# nor a particular unitree_lerobot layout on the target machine.
BUNDLED_URDF = BUNDLE_ASSETS / "g1_body29_hand14.urdf"
BUNDLED_STATS = BUNDLE_ASSETS / "eef_stats.json"


# --------------------------------------------------------------------------- #
# delta <-> absolute
# --------------------------------------------------------------------------- #
def to_delta(cond: np.ndarray, targets: np.ndarray) -> np.ndarray:
    """Absolute poses -> offsets from the condition frame (training's convention)."""
    from scipy.spatial.transform import Rotation

    cond = np.asarray(cond, dtype=np.float64)
    targets = np.atleast_2d(np.asarray(targets, dtype=np.float64))
    out = np.zeros_like(targets)
    for xyz, rot in zip(XYZ_SLICES, ROT_SLICES):
        r_inv = Rotation.from_rotvec(cond[rot]).inv()
        out[:, xyz] = r_inv.apply(targets[:, xyz] - cond[xyz])
        out[:, rot] = (r_inv * Rotation.from_rotvec(targets[:, rot])).as_rotvec()
    for g in GRIPPER_DIMS:
        out[:, g] = targets[:, g]
    return out


def from_delta(cond: np.ndarray, deltas: np.ndarray) -> np.ndarray:
    """Offsets -> absolute poses. Inverse of :func:`to_delta`.

    Translation is rotated out of the condition frame's own EEF frame and
    rotation composes on SO(3); adding rotation vectors would be wrong.
    """
    from scipy.spatial.transform import Rotation

    cond = np.asarray(cond, dtype=np.float64)
    deltas = np.atleast_2d(np.asarray(deltas, dtype=np.float64))
    out = np.zeros_like(deltas)
    for xyz, rot in zip(XYZ_SLICES, ROT_SLICES):
        r_cond = Rotation.from_rotvec(cond[rot])
        out[:, xyz] = r_cond.apply(deltas[:, xyz]) + cond[xyz]
        out[:, rot] = (r_cond * Rotation.from_rotvec(deltas[:, rot])).as_rotvec()
    for g in GRIPPER_DIMS:
        out[:, g] = deltas[:, g]
    return out


# --------------------------------------------------------------------------- #
# normalisation
# --------------------------------------------------------------------------- #
class AffineNormalizer:
    """Per-dimension affine scaling, mirroring _AffineNormalizer on the training side.

    ``standard`` (zero mean, unit variance) is the mode to use: the action expert
    is a flow-matching head with an N(0, 1) prior, and min-max to [0, 1] leaves
    the G1-D deltas at std ~0.17, a ~10x compression that measurably costs
    accuracy. ``minmax`` exists to serve checkpoints trained before the switch.
    """

    def __init__(self, offset: Sequence[float], scale: Sequence[float]):
        self.offset = np.asarray(offset, dtype=np.float32)
        self.scale = np.asarray(scale, dtype=np.float32)

    @classmethod
    def from_min_max(cls, vmin, vmax, epsilon: float = 1e-8):
        vmin = np.asarray(vmin, dtype=np.float32)
        return cls(vmin, np.asarray(vmax, dtype=np.float32) - vmin + epsilon)

    @classmethod
    def from_mean_std(cls, mean, std, epsilon: float = 1e-8):
        std = np.asarray(std, dtype=np.float32).copy()
        std[std < epsilon] = 1.0
        return cls(np.asarray(mean, dtype=np.float32), std)

    def normalize(self, x: np.ndarray) -> np.ndarray:
        return (x - self.offset) / self.scale

    def denormalize(self, y: np.ndarray) -> np.ndarray:
        return y * self.scale + self.offset


DIM_NAMES = (
    "L_x", "L_y", "L_z", "L_rx", "L_ry", "L_rz", "L_resv", "L_grip",
    "R_x", "R_y", "R_z", "R_rx", "R_ry", "R_rz", "R_resv", "R_grip",
)


def describe(vec: np.ndarray, lo=None, hi=None, tag: str = "") -> str:
    """One-line dump of a 16-dim vector, marking dims outside [lo, hi].

    Out-of-range is the thing worth seeing: the model only ever saw normalized
    inputs inside [0, 1], so a state dim outside that is a distribution mismatch
    and explains bad actions far better than anything downstream does.
    """
    vec = np.asarray(vec, dtype=np.float64).ravel()
    parts = []
    for i, v in enumerate(vec):
        flag = ""
        if lo is not None and hi is not None and not (lo[i] - 1e-6 <= v <= hi[i] + 1e-6):
            flag = "!"
        parts.append(f"{DIM_NAMES[i]}={v:+.4f}{flag}")
    return (tag + " " if tag else "") + " ".join(parts)


def out_of_range(vec: np.ndarray, lo, hi) -> list:
    vec = np.asarray(vec, dtype=np.float64).ravel()
    return [DIM_NAMES[i] for i in range(len(vec))
            if not (lo[i] - 1e-6 <= vec[i] <= hi[i] + 1e-6)]


def load_stats_for_diagnostics(stats_path: str) -> Optional[dict]:
    """Read eef_stats.json for its ranges only, never for scaling.

    With ``normalization: false`` nothing is scaled, but the statistics still
    describe the workspace the demonstrations covered and the per-dimension
    spread of the delta targets. Both are what the diagnostics compare against,
    so they stay useful in every mode. Missing or unreadable is not an error
    here: it costs diagnostics, not correctness.
    """
    if not stats_path:
        return None
    try:
        stats = json.loads(Path(stats_path).read_text())
    except Exception as e:
        logger.warning("could not read %s for diagnostics (%s); range checks disabled",
                       stats_path, e)
        return None
    missing = {"min", "max"} - set(stats)
    if missing:
        logger.warning("%s lacks %s; range checks disabled", stats_path, sorted(missing))
        return None
    return stats


def load_normalizers(stats_path: str, action_mode: str, mode: str = "standard"):
    """(state, action) normalizers from the G1-D statistics file.

    ``mode`` MUST match what the checkpoint was trained with; the two scale the
    targets differently and mixing them mis-scales every action.

    In ``eef_delta`` the state stays absolute while the actions are offsets, so
    the two use different constants.
    """
    if mode not in ("minmax", "standard"):
        raise ValueError(f"normalization mode must be 'minmax' or 'standard', got {mode!r}")
    path = Path(stats_path)
    if not path.exists():
        raise FileNotFoundError(
            f"action_mode={action_mode!r} with normalization needs the G1-D statistics at "
            f"{path}. Copy meta/eef_stats.json from the training dataset next to the "
            f"checkpoint; it is part of the checkpoint's contract, not of the robot."
        )
    stats = json.loads(path.read_text())

    def build(minmax_keys, meanstd_keys):
        keys = minmax_keys if mode == "minmax" else meanstd_keys
        missing = set(keys) - set(stats)
        if missing:
            raise KeyError(f"{path} is missing {sorted(missing)} needed for mode={mode!r}; "
                           f"regenerate it with tools/g1_qpos_to_eef.py --write")
        ctor = (AffineNormalizer.from_min_max if mode == "minmax"
                else AffineNormalizer.from_mean_std)
        n = ctor(stats[keys[0]], stats[keys[1]])
        # Kept for the diagnostics, which report against the physical range the
        # training data covered regardless of how it was scaled.
        n.raw_min = np.asarray(stats[minmax_keys[0]], dtype=np.float64)
        n.raw_max = np.asarray(stats[minmax_keys[1]], dtype=np.float64)
        return n

    state = build(("min", "max"), ("mean", "std"))
    if action_mode == "eef_delta":
        return state, build(("delta_min", "delta_max"), ("delta_mean", "delta_std"))
    return state, state


# --------------------------------------------------------------------------- #
# kinematics
# --------------------------------------------------------------------------- #
class G1EefKinematics:
    """FK and IK between the robot's 14 arm joints and the 16-dim EEF vector.

    FK stays in the training convention (rotvec, report frame). IK is Unitree's
    ``G1_29_ArmIK`` NLP: CasADi + IPOPT with cost

        50 ||e_t||^2 + ||e_R||^2 + 0.02 ||q||^2 + 0.1 ||q - q_last||^2

    hard joint-limit constraints and warm start from the previous command.
    Targets are converted from the report frame into the reduced-model pelvis
    frame before the solve, which is the frame Unitree passes 4x4 matrices in.
    The 4-tap joint FIR from teleop is omitted: the 0.1 ||q-q_last||^2 term
    already smooths, and a FIR on top lags a 30 Hz policy chunk.
    """

    def __init__(self, urdf_path: str, nullspace_gain: float = 0.1, damping: float = 1e-6,
                 max_iters: int = 100, tol: float = 1e-4):
        import pinocchio as pin

        self._pin = pin
        # Kinematics only. RobotWrapper would also build the collision and visual
        # models and refuse to start when the STL meshes are absent, which would
        # force ~50 mesh files into the deployment bundle for no benefit: this
        # class never touches geometry. The reduced models the two produce are
        # bit-identical.
        full = pin.buildModelFromUrdf(str(urdf_path))
        lock = [full.getJointId(n) for n in full.names[1:] if n not in set(ARM_JOINTS)]
        self.model = pin.buildReducedModel(full, lock, np.zeros(full.nq))
        if list(self.model.names[1:]) != ARM_JOINTS:
            raise RuntimeError(
                f"reduced model joint order {list(self.model.names[1:])} does not match the "
                f"training layout {ARM_JOINTS}"
            )
        for side, tag in (("left", "L_ee"), ("right", "R_ee")):
            self.model.addFrame(pin.Frame(
                tag, self.model.getJointId(f"{side}_wrist_yaw_joint"),
                pin.SE3(np.eye(3), TCP_OFFSET), pin.FrameType.OP_FRAME))
        self.data = self.model.createData()
        self.ee = [self.model.getFrameId("L_ee"), self.model.getFrameId("R_ee")]
        self.lo = self.model.lowerPositionLimit
        self.hi = self.model.upperPositionLimit
        self.mid = 0.5 * (self.lo + self.hi)
        self.rest = np.zeros(14)
        self.w = 1.0 / (self.hi - self.lo) ** 2
        self.w /= self.w.max()

        torso = self.model.getFrameId("torso_link")
        pin.framesForwardKinematics(self.model, self.data, np.zeros(14))
        self.oMbase = self.data.oMf[torso] * pin.SE3(np.eye(3), -REPORT_FRAME_TO_TORSO)

        # Kept so existing constructors still type-check; IK no longer uses DLS.
        self.nullspace_gain = float(nullspace_gain)
        self.damping = float(damping)
        self.max_iters = int(max_iters)
        self.tol = float(tol)

        self._tf_l = np.eye(4)
        self._tf_r = np.eye(4)
        self._build_ipopt()
        self._report_ik_speed()

    def _report_ik_speed(self, n: int = 12) -> float:
        """Time a few warm-started solves at startup and say whether 30 Hz fits.

        The solver's cost is a property of the backend and the machine, not of
        the policy, so it can be measured before the robot moves -- and it has to
        be, because an IK that misses the control budget does not fail visibly.
        It just stretches the chunk out and the arm stutters through it.
        """
        import time as _t

        q = 0.5 * (self.lo + self.hi)
        target = self.fk_state(q, 0.0, 0.0)
        seed = q.copy()
        dts = []
        for i in range(n):
            target[0] += 0.002        # a plausible per-step TCP move
            target[8] -= 0.002
            t0 = _t.perf_counter()
            try:
                seed, _, _ = self.ik(target, seed)
            except Exception as e:
                logger.warning("IK self-timing failed (%s); skipping", e)
                return float("nan")
            dts.append(_t.perf_counter() - t0)
        # Drop the first: it pays for graph construction, not for solving.
        med = float(np.median(dts[1:])) * 1000.0
        self.ik_ms_typical = med
        budget = 1000.0 / 30.0
        if med > 0.5 * budget:
            logger.warning(
                "IK self-timing: %.1f ms per solve on the %s backend, against a %.1f ms "
                "control budget at 30 Hz. The loop cannot keep up: the chunk will be "
                "replayed ~%.1fx slow and the arm will stutter. Try MOTUS_IK_BACKEND=sx.",
                med, self.ik_backend, budget, med / budget)
        else:
            logger.info("IK self-timing: %.1f ms per solve (%s), %.0f%% of the 30 Hz budget",
                        med, self.ik_backend, 100 * med / budget)
        return med

    def reset(self):
        """Hook for episode boundaries; IPOPT has no cross-episode state."""
        return

    # ---- FK ----
    def fk_poses(self, q14: np.ndarray):
        """[left SE3, right SE3] of the TCP in the report frame."""
        self._pin.framesForwardKinematics(self.model, self.data, np.asarray(q14, dtype=np.float64))
        return [self.oMbase.actInv(self.data.oMf[f]) for f in self.ee]

    def fk_state(self, q14: np.ndarray, left_gripper: float, right_gripper: float) -> np.ndarray:
        """Absolute 16-dim EEF state, the same vector training reads from
        ``observation.state.eef``."""
        out = np.zeros(ACTION_DIM, dtype=np.float32)
        for arm, pose in enumerate(self.fk_poses(q14)):
            base = arm * 8
            out[base:base + 3] = pose.translation
            out[base + 3:base + 6] = self._pin.log3(pose.rotation)
        out[GRIPPER_DIMS[0]] = left_gripper
        out[GRIPPER_DIMS[1]] = right_gripper
        return out

    # ---- IK (Unitree G1_29_ArmIK) ----
    def _targets_from_vec(self, eef16: np.ndarray):
        from scipy.spatial.transform import Rotation

        eef16 = np.asarray(eef16, dtype=np.float64)
        return [self._pin.SE3(Rotation.from_rotvec(eef16[rot]).as_matrix(), eef16[xyz].copy())
                for xyz, rot in zip(XYZ_SLICES, ROT_SLICES)]

    def _build_ipopt(self):
        """Build the Unitree NLP once; ``ik`` only updates parameters and solves."""
        try:
            import casadi
        except ImportError as e:
            raise ImportError(
                "eef_delta IK needs CasADi+IPOPT (the Unitree G1_29_ArmIK solver). "
                "Install casadi in the inference environment."
            ) from e

        try:
            from pinocchio import casadi as cpin
        except ImportError:
            cpin = None

        # Both backends express the identical NLP; they differ only in how the
        # derivatives are generated, and that difference is worth ~300x of wall
        # clock. Measured on the same targets: the SX chain solves in ~2 ms,
        # while pinocchio.casadi with exact Hessians measured 558 ms median on
        # the robot -- 100% of a control loop that then ran at 1.8 Hz instead of
        # 30. Prefer SX; MOTUS_IK_BACKEND=pinocchio forces the other one.
        want = os.environ.get("MOTUS_IK_BACKEND", "sx").strip().lower()
        if want not in ("sx", "pinocchio", "auto"):
            raise ValueError(
                f"MOTUS_IK_BACKEND must be 'sx', 'pinocchio' or 'auto', got {want!r}")

        self._casadi = casadi
        if want == "pinocchio" and cpin is None:
            logger.warning("MOTUS_IK_BACKEND=pinocchio but pinocchio.casadi is not "
                           "installed; falling back to the SX chain")
        use_pin = cpin is not None and want in ("pinocchio", "auto")
        if use_pin:
            self._build_ipopt_symbolic(casadi, cpin)
            backend = "pinocchio.casadi"
        else:
            self._build_ipopt_sx(casadi)
            backend = "casadi SX FK"
        self.ik_backend = backend
        logger.info("G1EefKinematics IK: Unitree IPOPT (%s, MOTUS_IK_BACKEND=%s)",
                    backend, want)

    def _ipopt_opts(self, exact_hessian: bool):
        opts = {
            "expand": exact_hessian,
            "detect_simple_bounds": True,
            "calc_lam_p": False,
            "print_time": False,
            "ipopt.sb": "yes",
            "ipopt.print_level": 0,
            "ipopt.max_iter": 30,
            "ipopt.tol": 1e-4,
            "ipopt.acceptable_tol": 5e-4,
            "ipopt.acceptable_iter": 5,
            "ipopt.warm_start_init_point": "yes",
            "ipopt.derivative_test": "none",
            "ipopt.jacobian_approximation": "exact",
        }
        if not exact_hessian:
            opts["ipopt.hessian_approximation"] = "limited-memory"
        return opts

    def _build_ipopt_symbolic(self, casadi, cpin):
        cmodel = cpin.Model(self.model)
        cdata = cmodel.createData()
        cq = casadi.SX.sym("q", self.model.nq, 1)
        c_tf_l = casadi.SX.sym("tf_l", 4, 4)
        c_tf_r = casadi.SX.sym("tf_r", 4, 4)
        cpin.framesForwardKinematics(cmodel, cdata, cq)
        trans_err = casadi.Function(
            "translational_error",
            [cq, c_tf_l, c_tf_r],
            [casadi.vertcat(
                cdata.oMf[self.ee[0]].translation - c_tf_l[:3, 3],
                cdata.oMf[self.ee[1]].translation - c_tf_r[:3, 3],
            )],
        )
        rot_err = casadi.Function(
            "rotational_error",
            [cq, c_tf_l, c_tf_r],
            [casadi.vertcat(
                cpin.log3(cdata.oMf[self.ee[0]].rotation @ c_tf_l[:3, :3].T),
                cpin.log3(cdata.oMf[self.ee[1]].rotation @ c_tf_r[:3, :3].T),
            )],
        )
        self.opti = casadi.Opti()
        self.var_q = self.opti.variable(self.model.nq)
        self.var_q_last = self.opti.parameter(self.model.nq)
        self.param_tf_l = self.opti.parameter(4, 4)
        self.param_tf_r = self.opti.parameter(4, 4)
        self.opti.subject_to(self.opti.bounded(self.lo, self.var_q, self.hi))
        self.opti.minimize(
            50 * casadi.sumsqr(trans_err(self.var_q, self.param_tf_l, self.param_tf_r))
            + casadi.sumsqr(rot_err(self.var_q, self.param_tf_l, self.param_tf_r))
            + 0.02 * casadi.sumsqr(self.var_q)
            + 0.1 * casadi.sumsqr(self.var_q - self.var_q_last)
        )
        self.opti.solver("ipopt", self._ipopt_opts(exact_hessian=True))
        self._uses_tf_params = True

    def _build_ipopt_sx(self, casadi):
        """Unitree NLP with a CasADi SX FK of the reduced revolute arms.

        Used when pinocchio was not built with CasADi. All 14 G1 arm joints are
        RX/RY/RZ, so the graph matches ``cpin.framesForwardKinematics`` and
        IPOPT can use exact Hessians with ``expand=True``.
        """
        cq = casadi.SX.sym("q", self.model.nq, 1)
        c_tf_l = casadi.SX.sym("tf_l", 4, 4)
        c_tf_r = casadi.SX.sym("tf_r", 4, 4)
        o_l, o_r = self._sx_tcp_poses(casadi, cq)
        trans_err = casadi.Function(
            "translational_error",
            [cq, c_tf_l, c_tf_r],
            [casadi.vertcat(o_l[:3, 3] - c_tf_l[:3, 3], o_r[:3, 3] - c_tf_r[:3, 3])],
        )
        rot_err = casadi.Function(
            "rotational_error",
            [cq, c_tf_l, c_tf_r],
            [casadi.vertcat(
                self._sx_log3(casadi, o_l[:3, :3] @ c_tf_l[:3, :3].T),
                self._sx_log3(casadi, o_r[:3, :3] @ c_tf_r[:3, :3].T),
            )],
        )
        self.opti = casadi.Opti()
        self.var_q = self.opti.variable(self.model.nq)
        self.var_q_last = self.opti.parameter(self.model.nq)
        self.param_tf_l = self.opti.parameter(4, 4)
        self.param_tf_r = self.opti.parameter(4, 4)
        self.opti.subject_to(self.opti.bounded(self.lo, self.var_q, self.hi))
        self.opti.minimize(
            50 * casadi.sumsqr(trans_err(self.var_q, self.param_tf_l, self.param_tf_r))
            + casadi.sumsqr(rot_err(self.var_q, self.param_tf_l, self.param_tf_r))
            + 0.02 * casadi.sumsqr(self.var_q)
            + 0.1 * casadi.sumsqr(self.var_q - self.var_q_last)
        )
        self.opti.solver("ipopt", self._ipopt_opts(exact_hessian=True))
        self._uses_tf_params = True

    def _sx_tcp_poses(self, casadi, cq):
        """4x4 L_ee / R_ee in the reduced-model pelvis frame, as CasADi SX."""
        Ts = [casadi.SX.eye(4) for _ in range(self.model.njoints)]
        for jid in range(1, self.model.njoints):
            parent = int(self.model.parents[jid])
            joint = self.model.joints[jid]
            kind = joint.shortname()
            qj = cq[int(joint.idx_q)]
            if kind == "JointModelRX":
                Rj = self._sx_rot_x(casadi, qj)
            elif kind == "JointModelRY":
                Rj = self._sx_rot_y(casadi, qj)
            elif kind == "JointModelRZ":
                Rj = self._sx_rot_z(casadi, qj)
            else:
                raise NotImplementedError(
                    f"symbolic FK only supports revolute RX/RY/RZ, got {kind} for "
                    f"{self.model.names[jid]}"
                )
            place = self.model.jointPlacements[jid]
            T_place = casadi.SX.eye(4)
            T_place[:3, :3] = place.rotation
            T_place[:3, 3] = place.translation
            T_q = casadi.SX.eye(4)
            T_q[:3, :3] = Rj
            Ts[jid] = Ts[parent] @ T_place @ T_q
        tcp = casadi.SX.eye(4)
        tcp[:3, 3] = TCP_OFFSET
        left = Ts[self.model.getJointId("left_wrist_yaw_joint")] @ tcp
        right = Ts[self.model.getJointId("right_wrist_yaw_joint")] @ tcp
        return left, right

    @staticmethod
    def _sx_rot_x(casadi, q):
        c, s = casadi.cos(q), casadi.sin(q)
        return casadi.vertcat(
            casadi.horzcat(1, 0, 0),
            casadi.horzcat(0, c, -s),
            casadi.horzcat(0, s, c),
        )

    @staticmethod
    def _sx_rot_y(casadi, q):
        c, s = casadi.cos(q), casadi.sin(q)
        return casadi.vertcat(
            casadi.horzcat(c, 0, s),
            casadi.horzcat(0, 1, 0),
            casadi.horzcat(-s, 0, c),
        )

    @staticmethod
    def _sx_rot_z(casadi, q):
        c, s = casadi.cos(q), casadi.sin(q)
        return casadi.vertcat(
            casadi.horzcat(c, -s, 0),
            casadi.horzcat(s, c, 0),
            casadi.horzcat(0, 0, 1),
        )

    @staticmethod
    def _sx_log3(casadi, R):
        """SO(3) log map, matching pinocchio.log3 / Unitree's rotational_error."""
        tr = R[0, 0] + R[1, 1] + R[2, 2]
        cos_th = casadi.fmin(casadi.fmax((tr - 1.0) * 0.5, -1.0), 1.0)
        theta = casadi.acos(cos_th)
        vee = casadi.vertcat(R[2, 1] - R[1, 2], R[0, 2] - R[2, 0], R[1, 0] - R[0, 1])
        small = 0.5 * vee
        sin_th = casadi.sin(theta)
        large = vee * theta / (2.0 * (sin_th + 1e-12))
        return casadi.if_else(theta < 1e-6, small, large)

    def ik(self, eef16: np.ndarray, q_seed: np.ndarray, retry_tol_m: float = 1e-3):
        """16-dim absolute EEF target -> 14 joint angles.

        Returns ``(q14, position_error_m, retried)``. ``retried`` is always
        False: Unitree IPOPT warm-starts from ``q_seed`` and does not cold-start
        from the joint midpoints (that jump was a DLS artefact).
        """
        del retry_tol_m
        targets = self._targets_from_vec(eef16)
        q0 = np.asarray(q_seed, dtype=np.float64).reshape(self.model.nq)
        self._tf_l = self.oMbase.act(targets[0]).homogeneous.copy()
        self._tf_r = self.oMbase.act(targets[1]).homogeneous.copy()
        self.opti.set_initial(self.var_q, q0)
        self.opti.set_value(self.var_q_last, q0)
        if self._uses_tf_params:
            self.opti.set_value(self.param_tf_l, self._tf_l)
            self.opti.set_value(self.param_tf_r, self._tf_r)
        try:
            self.opti.solve()
            q = np.asarray(self.opti.value(self.var_q), dtype=np.float64).reshape(-1)
        except Exception as e:
            try:
                q = np.asarray(self.opti.debug.value(self.var_q), dtype=np.float64).reshape(-1)
            except Exception:
                q = None
            if q is None or self._pose_error(targets, q) >= self._pose_error(targets, q0):
                logger.warning("IPOPT did not converge (%s); holding seed", e)
                return q0.copy(), self._pose_error(targets, q0), False
            logger.warning("IPOPT did not fully converge (%s); using last iterate", e)
        q = np.clip(q, self.lo, self.hi)
        return q, self._pose_error(targets, q), False

    def _pose_error(self, targets, q) -> float:
        return max(float(np.linalg.norm(t.translation - g.translation))
                   for t, g in zip(targets, self.fk_poses(q)))


def find_urdf(search_roots: Sequence[str] = ()) -> Optional[str]:
    """Locate a G1 URDF for FK/IK.

    The copy inside the bundle wins, so a packaged deployment resolves the same
    file on every machine. Failing that, the installed ``unitree_lerobot``
    package is asked where its assets are, which beats guessing a relative path.

    Only the kinematic chain is read, so the STL meshes the URDF references do
    not have to be present.
    """
    roots = [str(BUNDLE_ASSETS)]
    try:
        import unitree_lerobot

        roots.append(str(Path(unitree_lerobot.__file__).resolve().parent))
    except Exception:
        pass
    roots += [r for r in search_roots if r]

    for root in roots:
        for rel in URDF_CANDIDATES:
            p = Path(root) / rel
            if p.exists():
                return str(p)
    return None

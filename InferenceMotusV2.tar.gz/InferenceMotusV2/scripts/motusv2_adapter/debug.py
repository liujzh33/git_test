"""Opt-in diagnostic logging for the Cartesian (eef / eef_delta) inference loop.

Off by default: at 30 Hz the per-step records are noise during a healthy run.
``--debug_log`` turns it on and mirrors everything into a timestamped file next
to a JSONL sibling, so a session can be replayed offline without re-parsing
prose.

What gets recorded is chosen to separate the failure modes this pipeline
actually produces, in the order they bite:

1. Contract. The checkpoint, ``eef_stats.json`` and the yaml are a matched set
   that travels together. Serving a checkpoint with the statistics or the
   normalization mode of a different run mis-scales every action by ~10x, and
   nothing downstream looks wrong -- the arm just creeps or lunges. So the md5
   of each artifact is recorded before anything else.

2. Fingerprint. Stronger than the md5s, because it checks the checkpoint itself
   rather than the files shipped beside it: the model's raw output distribution
   is a direct signature of the normalizer it was trained with. See
   :func:`fingerprint`.

3. State. FK on the measured joints, absolute and normalized, against the range
   the training data covered. A state outside that range means the robot is
   showing the policy something it never saw, which explains bad actions
   without anything downstream being at fault.

4. Execution. IK residual, joint step, guard actions, and the tracking error
   between what was commanded and what the arm actually reached.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import time
from pathlib import Path
from typing import Any, Optional, Sequence

import numpy as np

logger = logging.getLogger(__name__)

# Pose dims only: xyz + rotvec for both arms. The grippers (7/15) pass through
# to_delta as ABSOLUTE values, so their normalized spread says nothing about the
# delta normalizer, and dims 6/14 are structurally zero. Excluding all four is
# what makes the fingerprint below sharp.
POSE_DIMS = [0, 1, 2, 3, 4, 5, 8, 9, 10, 11, 12, 13]

_state: dict = {"on": False}


# --------------------------------------------------------------------------- #
# setup
# --------------------------------------------------------------------------- #
def configure(enabled: bool, log_dir: str = "", level: str = "INFO",
              every: int = 30, tag: str = "eef_delta") -> Optional[str]:
    """Attach a file sink to the root logger and open the JSONL record.

    Returns the log path, or None when disabled. Safe to call twice; the second
    call is ignored so a re-entrant eval loop cannot double-log.
    """
    if _state.get("configured"):
        return _state.get("log_path")
    _state["configured"] = True
    _state["on"] = bool(enabled)
    _state["every"] = max(1, int(every))
    _state["t0"] = time.time()
    _state["counters"] = {}
    _state["ik_err"] = []
    _state["ik_step"] = []
    if not enabled:
        return None

    d = Path(log_dir) if log_dir else Path(__file__).resolve().parents[2] / "logs"
    d.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    log_path = d / f"inference_{tag}_{stamp}.log"
    jsonl_path = d / f"inference_{tag}_{stamp}.jsonl"

    fh = logging.FileHandler(log_path, encoding="utf-8")
    fh.setLevel(getattr(logging, str(level).upper(), logging.INFO))
    fh.setFormatter(logging.Formatter(
        "%(asctime)s %(levelname)-7s %(name)s | %(message)s", "%H:%M:%S"))
    root = logging.getLogger()
    root.addHandler(fh)
    if root.level > fh.level:
        root.setLevel(fh.level)

    _state["log_path"] = str(log_path)
    _state["jsonl"] = open(jsonl_path, "a", encoding="utf-8")
    logger.info("[debug] logging to %s (records: %s)", log_path, jsonl_path)
    return str(log_path)


def on() -> bool:
    return bool(_state.get("on"))


def _rec(kind: str, **fields) -> None:
    """Append one machine-readable record. Never raises into the control loop."""
    fh = _state.get("jsonl")
    if fh is None:
        return
    try:
        fields["t"] = round(time.time() - _state["t0"], 4)
        fields["kind"] = kind
        fh.write(json.dumps(fields, ensure_ascii=False, default=float) + "\n")
        fh.flush()
    except Exception as e:  # a broken log must never stop the robot
        logger.debug("[debug] record dropped: %s", e)


def count(name: str, n: int = 1) -> None:
    _state.setdefault("counters", {})
    _state["counters"][name] = _state["counters"].get(name, 0) + n


def _md5(path) -> str:
    try:
        h = hashlib.md5()
        with open(path, "rb") as f:
            for block in iter(lambda: f.read(1 << 20), b""):
                h.update(block)
        return h.hexdigest()
    except Exception:
        return "?"


# --------------------------------------------------------------------------- #
# 1. contract
# --------------------------------------------------------------------------- #
def banner(*, checkpoint: str, config_path: str, stats_path: str, urdf: str,
           action_mode: str, norm_mode: str, chunk: int, interp: int,
           freq: float, inference_steps: int, instruction: str,
           stitch_mode: str, extra: Optional[dict] = None) -> None:
    """One-time dump of everything that has to match the checkpoint.

    The md5s are the point: they are what a later reader needs to prove the run
    used the artifacts it was supposed to.
    """
    if not on():
        return
    art = {
        "checkpoint": checkpoint,
        "config": f"{config_path}  md5={_md5(config_path)}",
        "eef_stats": f"{stats_path}  md5={_md5(stats_path)}",
        "urdf": f"{urdf}  md5={_md5(urdf)}",
    }
    lines = ["[debug] ==== run contract ===="]
    for k, v in art.items():
        lines.append(f"    {k:12s}: {v}")
    lines.append(f"    {'action_mode':12s}: {action_mode}   normalization={norm_mode}")
    lines.append(f"    {'chunk':12s}: {chunk} actions  interp x{interp}  "
                 f"@ {freq:g} Hz  -> {chunk * interp / max(freq, 1e-9):.2f} s per chunk")
    lines.append(f"    {'sampling':12s}: {inference_steps} denoising steps")
    lines.append(f"    {'stitch':12s}: {stitch_mode}")
    lines.append(f"    {'instruction':12s}: {instruction!r}  "
                 f"sha1={hashlib.sha1(instruction.encode()).hexdigest()[:12]}")
    for k, v in (extra or {}).items():
        lines.append(f"    {k:12s}: {v}")
    logger.info("\n".join(lines))
    _rec("contract", checkpoint=checkpoint, config=config_path,
         config_md5=_md5(config_path), stats=stats_path, stats_md5=_md5(stats_path),
         urdf=urdf, urdf_md5=_md5(urdf), action_mode=action_mode, norm_mode=norm_mode,
         chunk=chunk, interp=interp, freq=freq, steps=inference_steps,
         instruction=instruction, stitch_mode=stitch_mode, **(extra or {}))


# --------------------------------------------------------------------------- #
# 2. normalization fingerprint
# --------------------------------------------------------------------------- #
def fingerprint(raw_chunk: np.ndarray, norm_mode: str,
                stats: Optional[dict] = None) -> dict:
    """Which normalizer does the model's raw output actually correspond to?

    Each mode leaves a per-dimension signature on the spread of the emitted pose
    dims, and all three follow from their definitions plus eef_stats.json:

      none      nothing is scaled, so dim d comes out with std delta_std[d]
                (metres for xyz, radians for rotvec)
      standard  targets were divided by delta_std, so every dim has std 1
      minmax    targets were divided by the span, so dim d has std
                delta_std[d] / (delta_max[d] - delta_min[d]), inside [0, 1]

    The score is per-dimension on purpose. Pooled, "none" (~0.12) and "minmax"
    (~0.08) are only 1.5x apart and would be easy to confuse; per dimension they
    are not, because minmax puts every dim near 0.08 while none spreads them
    from 0.04 to 0.42. The shape separates them where the magnitude does not.

    Without statistics this degrades to the pooled mean/std test, which can only
    separate minmax from standard.
    """
    x = np.asarray(raw_chunk, dtype=np.float64)
    if x.ndim == 1:
        x = x[None]
    p = x[:, POSE_DIMS]
    mean, std = float(p.mean()), float(p.std())
    outside = float(((p < 0.0) | (p > 1.0)).mean())
    obs = p.std(axis=0)

    scores: dict = {}
    if stats is not None and len(x) > 1:
        dstd = np.asarray(stats["delta_std"], dtype=np.float64)[POSE_DIMS]
        span = (np.asarray(stats["delta_max"], dtype=np.float64)
                - np.asarray(stats["delta_min"], dtype=np.float64))[POSE_DIMS]
        expected = {
            "none": dstd,
            "standard": np.ones_like(dstd),
            "minmax": dstd / np.maximum(span, 1e-9),
        }
        eps = 1e-9
        for h, e in expected.items():
            # Log-ratio: scale-free, and it penalises the wrong SHAPE as well as
            # the wrong magnitude.
            r = np.log((obs + eps) / (e + eps))
            s = float(np.mean(r ** 2))
            if h == "minmax":  # minmax also pins the centre at ~0.5
                s += (mean - 0.5) ** 2
            else:
                s += mean ** 2
            scores[h] = s
        ranked = sorted(scores, key=scores.get)
        best, runner = ranked[0], ranked[1]
        # Only claim a verdict when one hypothesis actually fits AND clearly
        # beats the next. An under-trained checkpoint emits a flatter per-dim
        # profile than any mode predicts, which used to make the closest-of-three
        # rule cry mismatch on a perfectly correct setup. A wrong "your
        # checkpoint does not match" is worse than no verdict.
        fits = scores[best] < 1.0            # within ~e^1 per dim
        decisive = scores[runner] > 2.0 * scores[best]
        looks_like = best if (fits and decisive) else "inconclusive"
    else:
        d_minmax = abs(mean - 0.5) / 0.5 + abs(std - 0.2) / 0.2
        d_standard = abs(mean - 0.0) / 0.5 + abs(std - 1.0) / 1.0
        looks_like = "minmax" if d_minmax < d_standard else "standard"

    return {"mean": mean, "std": std, "frac_outside_01": outside,
            "looks_like": looks_like, "configured": norm_mode,
            # "inconclusive" is not a disagreement: it means the output does not
            # look like any mode cleanly, which is a model-quality signal rather
            # than a wiring one.
            "agrees": looks_like in (norm_mode, "inconclusive"),
            "scores": {k: round(v, 4) for k, v in scores.items()}}


def check_fingerprint(raw_chunk: np.ndarray, norm_mode: str,
                      stats: Optional[dict] = None) -> dict:
    """:func:`fingerprint`, recorded every chunk but shouted about only once.

    Repeating the verdict every 2 seconds would bury the rest of the log, but
    the per-chunk numbers are worth keeping: a fingerprint that drifts mid-run
    is a different problem from one that was wrong at the start.
    """
    fp = fingerprint(raw_chunk, norm_mode, stats)
    _rec("fingerprint", **fp)
    if not _state.get("fp_logged"):
        _state["fp_logged"] = True
        msg = ("[debug] normalization fingerprint: pose dims mean=%.3f std=%.3f "
               "outside[0,1]=%.1f%%  scores=%s  -> looks like %r, config says %r")
        args = (fp["mean"], fp["std"], 100 * fp["frac_outside_01"], fp["scores"],
                fp["looks_like"], fp["configured"])
        if fp["looks_like"] == "inconclusive":
            logger.warning(
                msg + "\n"
                "    no mode fits cleanly. The wiring is probably fine (a real mismatch is "
                "off by ~10x and scores near zero on the other mode); this usually means the "
                "checkpoint's per-dimension spread is flatter than the data's, i.e. it is "
                "under-trained on the low-variance dims. Compare the |delta xyz| / |delta rot| "
                "medians below against the demonstrations instead.", *args)
        elif fp["agrees"]:
            logger.info(msg + "  OK", *args)
        else:
            logger.error(
                msg + "\n"
                "    *** MISMATCH: this checkpoint does not look like it was trained with "
                "normalization=%r. Serving it this way rescales every action. "
                "Check that the checkpoint, the yaml and eef_stats.json all come from the "
                "same training run ('none' means dataset.normalization: false). ***",
                *args, fp["configured"])
    elif not fp["agrees"]:
        count("fingerprint_mismatch")
    return fp


# --------------------------------------------------------------------------- #
# 3 / 4. per-chunk and per-step records
# --------------------------------------------------------------------------- #
def chunk(*, index: int, cond_abs: np.ndarray, deltas: np.ndarray,
          targets: np.ndarray, raw: np.ndarray, dim_names: Sequence[str],
          lo=None, hi=None, predict_ms: float = 0.0) -> None:
    """One record per predicted chunk: what was asked for, in physical units."""
    if not on():
        return
    d = np.asarray(deltas, dtype=np.float64)
    tg = np.asarray(targets, dtype=np.float64)
    xyz = [slice(0, 3), slice(8, 11)]
    rot = [slice(3, 6), slice(11, 14)]
    dp = np.concatenate([np.linalg.norm(d[:, s], axis=1) for s in xyz])
    dr = np.concatenate([np.linalg.norm(d[:, s], axis=1) for s in rot])
    # Step-to-step motion is what the hardware actually has to follow; a chunk
    # can look tame in total travel and still contain a jump.
    stepwise = np.concatenate([np.linalg.norm(np.diff(tg[:, s], axis=0), axis=1)
                               for s in xyz]) if len(tg) > 1 else np.zeros(1)
    oob = []
    if lo is not None and hi is not None:
        for i in range(tg.shape[1]):
            n = int(((tg[:, i] < lo[i] - 1e-6) | (tg[:, i] > hi[i] + 1e-6)).sum())
            if n:
                oob.append(f"{dim_names[i]}:{n}")
    logger.info(
        "[debug][chunk %d] %d actions, predict %.0f ms\n"
        "    |delta xyz|   median %6.1f mm   max %6.1f mm\n"
        "    |delta rot|   median %6.3f rad  max %6.3f rad\n"
        "    step-to-step  median %6.2f mm   max %6.2f mm  (30 Hz -> %.0f mm/s peak)\n"
        "    targets outside the training range: %s",
        index, len(d), predict_ms,
        np.median(dp) * 1000, dp.max() * 1000, np.median(dr), dr.max(),
        np.median(stepwise) * 1000, stepwise.max() * 1000, stepwise.max() * 1000 * 30,
        " ".join(oob) if oob else "none")
    _rec("chunk", index=index, n=len(d), predict_ms=predict_ms,
         cond_abs=np.asarray(cond_abs, dtype=float).tolist(),
         delta_xyz_median_mm=np.median(dp) * 1000, delta_xyz_max_mm=dp.max() * 1000,
         delta_rot_median=np.median(dr), delta_rot_max=dr.max(),
         step_max_mm=stepwise.max() * 1000, out_of_range=oob,
         raw_mean=float(np.mean(raw)), raw_std=float(np.std(raw)),
         first_target=tg[0].tolist(), last_target=tg[-1].tolist())


def loop(dt_s: float, target_hz: float) -> None:
    """One control-loop iteration took ``dt_s``.

    The eval loop reports this through logging_mp, which does not propagate to
    the root logger and so never reached the debug file -- which is how a loop
    running at 6.5 Hz against a 30 Hz target went unnoticed while every other
    number in the log looked healthy. Recorded here instead.

    A loop that cannot keep up does not fail: it replays the chunk in slow
    motion, and since each action is still a discrete target the arm snaps to
    and then holds, the motion reads as a stutter rather than as "too slow".
    """
    if not on():
        return
    _state.setdefault("loop_dt", []).append(float(dt_s))
    dts = _state["loop_dt"]
    if len(dts) % 300:
        return
    window = np.asarray(dts[-300:])
    hz = 1.0 / max(float(np.median(window)), 1e-9)
    _rec("loop", n=len(dts), hz=hz, median_ms=float(np.median(window) * 1000),
         p90_ms=float(np.percentile(window, 90) * 1000), target_hz=target_hz)
    if hz < 0.7 * target_hz:
        count("loop_underrun")
        logger.warning(
            "[debug][loop] %.1f Hz against a %.0f Hz target (iteration %.1f ms, budget %.1f ms). "
            "The chunk is being replayed %.1fx slower than demonstrated, and each action is "
            "held for %.0f ms instead of %.0f -- that is what a stutter looks like. "
            "Check the per-step ik_ms below for where the time goes.",
            hz, target_hz, 1000 / hz, 1000 / target_hz, target_hz / hz,
            1000 / hz, 1000 / target_hz)
    else:
        logger.info("[debug][loop] %.1f Hz (iteration %.1f ms of a %.1f ms budget)",
                    hz, 1000 / hz, 1000 / target_hz)


def step(*, index: int, q_cmd: np.ndarray, q_meas: np.ndarray, ik_err: float,
         joint_step: float, guard: str = "", queue: int = -1,
         ik_ms: float = 0.0) -> None:
    """Per-control-step record, throttled to one in ``--debug_log_every``.

    Guard events are never throttled: they are rare and they are the interesting
    ones. ``q_cmd - q_meas`` is the servo tracking error, which is what tells a
    "the policy is wrong" failure apart from a "the arm never got there" one.
    """
    if not on():
        return
    _state["ik_err"].append(float(ik_err))
    _state["ik_step"].append(float(joint_step))
    _state.setdefault("ik_ms", []).append(float(ik_ms))
    if guard:
        count(f"guard:{guard}")
    if not guard and index % _state["every"] != 0:
        return
    track = float(np.abs(np.asarray(q_cmd, dtype=float)
                         - np.asarray(q_meas, dtype=float)[:14]).max())
    level = logger.warning if guard else logger.info
    level("[debug][step %d] ik %.1f ms  ik_err %.2f mm  joint_step %.4f rad  "
          "tracking |cmd-meas| %.4f rad  queue %d%s",
          index, ik_ms, ik_err * 1000, joint_step, track, queue,
          f"  GUARD={guard}" if guard else "")
    _rec("step", index=index, ik_ms=ik_ms, ik_err_mm=ik_err * 1000,
         joint_step=joint_step, tracking_max_rad=track, queue=queue,
         guard=guard or None, q_cmd=np.asarray(q_cmd, dtype=float).tolist())


def summary() -> None:
    """End-of-run tally. Cheap, and it is what a bug report should start with."""
    if not on():
        return
    err = np.asarray(_state.get("ik_err") or [0.0]) * 1000
    stp = np.asarray(_state.get("ik_step") or [0.0])
    lines = ["[debug] ==== run summary ===="]
    lines.append(f"    duration      : {time.time() - _state['t0']:.1f} s")
    lines.append(f"    control steps : {len(err)}")
    lines.append(f"    IK residual   : median {np.median(err):.2f} mm  "
                 f"p95 {np.percentile(err, 95):.2f} mm  max {err.max():.2f} mm")
    lines.append(f"    joint step    : median {np.median(stp):.4f} rad  "
                 f"p95 {np.percentile(stp, 95):.4f} rad  max {stp.max():.4f} rad")
    ik = np.asarray(_state.get("ik_ms") or [0.0])
    lines.append(f"    IK solve time : median {np.median(ik):.1f} ms  "
                 f"p95 {np.percentile(ik, 95):.1f} ms  max {ik.max():.1f} ms")
    dts = _state.get("loop_dt")
    if dts:
        dts = np.asarray(dts)
        hz = 1.0 / max(float(np.median(dts)), 1e-9)
        lines.append(f"    control loop  : {hz:.1f} Hz achieved  "
                     f"(iteration median {np.median(dts) * 1000:.1f} ms, "
                     f"p90 {np.percentile(dts, 90) * 1000:.1f} ms)")
        lines.append(f"                    IK is {100 * np.median(ik) / max(np.median(dts) * 1000, 1e-9):.0f}%"
                     f" of the iteration")
    for k, v in sorted(_state.get("counters", {}).items()):
        lines.append(f"    {k:14s}: {v}")
    if _state.get("log_path"):
        lines.append(f"    log           : {_state['log_path']}")
    logger.info("\n".join(lines))
    _rec("summary", steps=len(err), ik_err_median_mm=float(np.median(err)),
         ik_err_max_mm=float(err.max()), joint_step_max=float(stp.max()),
         counters=dict(_state.get("counters", {})))
    fh = _state.get("jsonl")
    if fh is not None:
        try:
            fh.close()
        except Exception:
            pass

"""
G1 real-robot evaluation with MotusV2 policy.

Reuses hardware interfaces from unitree_lerobot (make_robot.py),
but replaces the LeRobot policy pipeline with MotusV2's own
inference pipeline via MotusV2PolicyAdapter.

The action representation follows dataset.action_mode in the training config:

  qpos       model outputs joint angles directly, no IK.
  eef_delta  model outputs Cartesian offsets from the pose the chunk was
             conditioned on; the adapter denormalizes, composes them onto that
             pose and runs IK to recover joint angles.

Either way the result goes through solve_tau for feedforward torque and then
ctrl_dual_arm, so the control path below is unchanged.

eef_delta additionally needs --eef-stats-path (the eef_stats.json the checkpoint
was normalized with) and a reachable G1 URDF.

This file does NOT modify any existing pi0.5 code.
"""

import argparse
import time
import logging
import numpy as np
import torch
from multiprocessing.sharedctypes import SynchronizedArray
from dataclasses import dataclass, field

from unitree_lerobot.eval_robot.make_robot import (
    setup_image_client,
    setup_robot_interface,
    process_images_and_observations,
)
from unitree_lerobot.eval_robot.utils.utils import to_list, to_scalar

from motusv2_adapter.adapter import MotusV2PolicyAdapter
from motusv2_adapter import debug as _debug

import logging_mp

logger_mp = logging_mp.getLogger(__name__)
logger_mp.setLevel(logging_mp.INFO)


@dataclass
class MotusEvalConfig:
    arm: str = "G1_29"
    ee: str = "dex1"
    frequency: float = 30.0
    motion: bool = False
    image_host: str = "192.168.123.164"
    instruction: str = ""
    checkpoint_path: str = ""
    wan_path: str = ""
    vlm_path: str = ""
    config_path: str = ""
    t5_cache_dir: str = ""
    root: str = ""
    num_inference_steps: int = 0
    # --- action interpolation (upsample chunk in time -> slower, smoother motion) ---
    # 0 = auto: use the config's global_downsample_rate, which is the factor that replays
    # the chunk at the speed it was demonstrated at.
    action_interp_factor: int = 0
    # --- async double-buffer inference (overlap predict with execution) ---
    async_inference: bool = False
    async_trigger: int = 40  # exec-queue length threshold to launch the next prediction (>= inference_steps)
    # --- RTC (Real-Time Chunking) cross-chunk guidance (async only) ---
    rtc: bool = False
    rtc_inference_delay: int = 8
    rtc_execution_horizon: int = 16
    rtc_max_guidance_weight: float = 5.0
    rtc_schedule: str = "exp"
    rtc_mode: str = "inpaint"  # inpaint | action_jacobian | pi05
    # --- Cartesian action modes (dataset.action_mode = eef / eef_delta) ---
    # eef_stats.json the checkpoint was normalized with; ships with the checkpoint,
    # not with the robot. Empty = fall back to the path recorded in the config.
    eef_stats_path: str = ""
    # Extra roots to search for a G1 URDF (FK/IK). Empty = the built-in guesses.
    urdf_root: str = ""
    # Reject an IK solution that would move any joint further than this in one
    # control step. Guards against a cold re-solve jumping to a different branch
    # of the redundant arm: valid pose, motion the hardware should not make.
    max_joint_step: float = 0.5
    # --- diagnostic logging (see motusv2_adapter/debug.py) ---
    # Off by default: at 30 Hz the per-step records are noise during a healthy
    # run. On, everything is mirrored to a timestamped file plus a JSONL record.
    debug_log: bool = False
    debug_log_dir: str = ""
    debug_log_level: str = "INFO"
    debug_log_every: int = 30  # per-step throttle; guard events are never skipped


def _write_gripper(ee_shared_mem, left_grip, right_grip):
    if not ee_shared_mem:
        return
    if isinstance(ee_shared_mem.get("left"), SynchronizedArray):
        ee_shared_mem["left"][:] = to_list(np.array([left_grip]))
        ee_shared_mem["right"][:] = to_list(np.array([right_grip]))
    elif hasattr(ee_shared_mem.get("left"), "value"):
        ee_shared_mem["left"].value = float(left_grip)
        ee_shared_mem["right"].value = float(right_grip)


def _load_initial_pose_from_dataset(root):
    import pyarrow.parquet as pq
    import os
    data_dir = os.path.join(root, "data", "chunk-000")
    files = sorted([f for f in os.listdir(data_dir) if f.endswith(".parquet")])
    for f in files:
        t = pq.read_table(os.path.join(data_dir, f))
        states = t.column("observation.state").to_pylist()
        ep_indices = t.column("episode_index").to_pylist()
        for i, ep in enumerate(ep_indices):
            if ep == 0:
                state = np.array(states[i], dtype=np.float32)
                arm_q = state[:14].copy()
                left_grip = float(state[14])
                right_grip = float(state[15])
                logger_mp.info(f"Loaded initial pose from dataset episode 0: arm_q={arm_q}, left_grip={left_grip:.4f}, right_grip={right_grip:.4f}")
                return arm_q, left_grip, right_grip
    raise FileNotFoundError(f"No episode 0 found in {root}")


def _move_robot_to_pose(arm_ctrl, arm_ik, ee_shared_mem, target_arm_q, left_grip, right_grip, steps=50):
    current_arm_q = arm_ctrl.get_current_dual_arm_q()
    for i in range(steps):
        alpha = (i + 1) / steps
        interp_q = current_arm_q * (1 - alpha) + target_arm_q * alpha
        tau = arm_ik.solve_tau(interp_q)
        arm_ctrl.ctrl_dual_arm(interp_q, tau)
        _write_gripper(ee_shared_mem, left_grip, right_grip)
        time.sleep(0.02)
    tau = arm_ik.solve_tau(target_arm_q)
    arm_ctrl.ctrl_dual_arm(target_arm_q, tau)
    _write_gripper(ee_shared_mem, left_grip, right_grip)
    time.sleep(0.5)
    logger_mp.info("Robot moved to dataset initial pose")


def build_policy(cfg: MotusEvalConfig, robot_interface) -> MotusV2PolicyAdapter:
    """Construct the MotusV2 policy adapter from cfg (shared by serial + async)."""
    _debug.configure(cfg.debug_log, cfg.debug_log_dir, cfg.debug_log_level,
                     cfg.debug_log_every)
    policy = MotusV2PolicyAdapter(
        checkpoint_path=cfg.checkpoint_path,
        wan_path=cfg.wan_path,
        vlm_path=cfg.vlm_path,
        config_path=cfg.config_path,
        t5_cache_dir=cfg.t5_cache_dir,
        device="cuda",
        arm_ik=robot_interface["arm_ik"],
        arm_dof=robot_interface["arm_dof"],
        ee_dof=robot_interface["ee_dof"],
        instruction=cfg.instruction,
        num_inference_steps=cfg.num_inference_steps,
        action_interp_factor=cfg.action_interp_factor,
        rtc_enabled=cfg.rtc,
        rtc_inference_delay=cfg.rtc_inference_delay,
        rtc_execution_horizon=cfg.rtc_execution_horizon,
        rtc_max_guidance_weight=cfg.rtc_max_guidance_weight,
        rtc_schedule=cfg.rtc_schedule,
        rtc_mode=cfg.rtc_mode,
        eef_stats_path=cfg.eef_stats_path,
        urdf_search_roots=[cfg.urdf_root] if cfg.urdf_root else None,
        max_joint_step=cfg.max_joint_step,
    )
    policy.set_instruction(cfg.instruction)
    policy.debug_banner(frequency=cfg.frequency)
    return policy


def _normalize_image_info(image_setup_result):
    """Accept both Unitree ImageClient setup APIs used across repo revisions."""
    if isinstance(image_setup_result, dict):
        image_info = image_setup_result
    elif isinstance(image_setup_result, tuple) and len(image_setup_result) == 2:
        image_client, camera_config = image_setup_result
        image_info = {
            "image_client": image_client,
            "camera_config": camera_config,
        }
    else:
        raise TypeError(
            "setup_image_client() must return either "
            "{'image_client', 'camera_config'} or (image_client, camera_config); "
            f"got {type(image_setup_result).__name__}"
        )

    missing = {"image_client", "camera_config"} - image_info.keys()
    if missing:
        raise KeyError(
            f"setup_image_client() result is missing keys: {sorted(missing)}"
        )
    return image_info


def run_eval(cfg: MotusEvalConfig):
    logger_mp.info(f"Config: {cfg}")

    image_info = _normalize_image_info(setup_image_client(cfg))
    robot_interface = setup_robot_interface(cfg)

    arm_ctrl = robot_interface["arm_ctrl"]
    arm_ik = robot_interface["arm_ik"]
    ee_shared_mem = robot_interface["ee_shared_mem"]
    arm_dof = robot_interface["arm_dof"]
    ee_dof = robot_interface["ee_dof"]
    img_client = image_info["image_client"]
    camera_config = image_info["camera_config"]

    policy = build_policy(cfg, robot_interface)

    if cfg.root:
        target_arm_q, init_left_grip, init_right_grip = _load_initial_pose_from_dataset(cfg.root)
        _move_robot_to_pose(arm_ctrl, arm_ik, ee_shared_mem, target_arm_q, init_left_grip, init_right_grip)
    else:
        init_arm_q = arm_ctrl.get_current_dual_arm_q()
        tau = arm_ik.solve_tau(init_arm_q)
        arm_ctrl.ctrl_dual_arm(init_arm_q, tau)
        time.sleep(1.0)
        logger_mp.info("Robot initialized to current pose")

    user_input = input("Enter 's' to start evaluation: ")
#    if user_input.lower() != "s":
#        logger_mp.info("Aborted")
#        return

    logger_mp.info(f"Starting evaluation at {cfg.frequency} Hz, instruction: {cfg.instruction}")
    policy.set_instruction(cfg.instruction)

    idx = 0
    try:
        while True:
            loop_start = time.perf_counter()

            if policy.has_cached_actions:
                t0 = time.perf_counter()
                current_arm_q = arm_ctrl.get_current_dual_arm_q()
                t_get_q = time.perf_counter() - t0

                t0 = time.perf_counter()
                result = policy.step(current_arm_q)
                t_step = time.perf_counter() - t0

                if result is not None:
                    arm_action, left_grip, right_grip = result

                    t0 = time.perf_counter()
                    tau = arm_ik.solve_tau(arm_action)
                    t_ik = time.perf_counter() - t0

                    t0 = time.perf_counter()
                    arm_ctrl.ctrl_dual_arm(arm_action, tau)
                    t_ctrl = time.perf_counter() - t0

                    t0 = time.perf_counter()
                    _write_gripper(ee_shared_mem, left_grip, right_grip)
                    t_grip = time.perf_counter() - t0
                else:
                    t_ik = t_ctrl = t_grip = 0.0

                loop_total = time.perf_counter() - loop_start
                logger_mp.info(
                    f"[{idx}|cached] loop={loop_total*1000:.1f}ms "
                    f"get_q={t_get_q*1000:.1f} step={t_step*1000:.1f} "
                    f"ik={t_ik*1000:.1f} ctrl={t_ctrl*1000:.1f} grip={t_grip*1000:.1f}"
                )
            else:
                t0 = time.perf_counter()
                observation, current_arm_q = process_images_and_observations(
                    img_client, camera_config, arm_ctrl
                )
                t_image = time.perf_counter() - t0

                t0 = time.perf_counter()
                first_frame, state_tensor = policy.observation_to_model_input(
                    observation, current_arm_q, ee_shared_mem
                )
                t_obs = time.perf_counter() - t0

                t0 = time.perf_counter()
                actions_chunk = policy.predict_action_chunk(first_frame, state_tensor)
                t_predict = time.perf_counter() - t0

                policy.action_queue = policy.build_exec_queue(actions_chunk)

                logger_mp.info(
                    f"[{idx}|predict] image_net={t_image*1000:.1f}ms "
                    f"obs_preprocess={t_obs*1000:.1f}ms "
                    f"policy_infer={t_predict*1000:.1f}ms "
                    f"chunk={actions_chunk.shape} queue={len(policy.action_queue)}"
                )

                t0 = time.perf_counter()
                result = policy.step(current_arm_q)
                t_step = time.perf_counter() - t0

                if result is not None:
                    arm_action, left_grip, right_grip = result

                    t0 = time.perf_counter()
                    tau = arm_ik.solve_tau(arm_action)
                    t_ik = time.perf_counter() - t0

                    t0 = time.perf_counter()
                    arm_ctrl.ctrl_dual_arm(arm_action, tau)
                    t_ctrl = time.perf_counter() - t0

                    t0 = time.perf_counter()
                    _write_gripper(ee_shared_mem, left_grip, right_grip)
                    t_grip = time.perf_counter() - t0
                else:
                    t_ik = t_ctrl = t_grip = 0.0

                loop_total = time.perf_counter() - loop_start
                logger_mp.info(
                    f"[{idx}|predict] TOTAL loop={loop_total*1000:.1f}ms "
                    f"step={t_step*1000:.1f} ik={t_ik*1000:.1f} "
                    f"ctrl={t_ctrl*1000:.1f} grip={t_grip*1000:.1f}"
                )

            idx += 1
            _debug.loop(time.perf_counter() - loop_start, cfg.frequency)
            t_sleep_start = time.perf_counter()
            time.sleep(max(0, (1.0 / cfg.frequency) - (time.perf_counter() - loop_start)))
            t_slept = time.perf_counter() - t_sleep_start
            logger_mp.info(
                f"[{idx}] cycle={1000/cfg.frequency:.1f}ms target, "
                f"actual_sleep={t_slept*1000:.1f}ms"
            )

    except KeyboardInterrupt:
        logger_mp.info("Interrupted by user")
    except Exception as e:
        logger_mp.info(f"Error: {e}")
    finally:
        _debug.summary()
        if image_info:
            image_info["image_client"].close()
        logger_mp.info("Evaluation ended")


def run_eval_async(cfg: MotusEvalConfig):
    """Async double-buffer eval loop.

    A background worker thread runs policy inference while the main thread keeps
    consuming the (interpolated) action queue at ``cfg.frequency``. When a new
    chunk is ready it is spliced in; RTC (if enabled) guides the new chunk toward
    the leftover of the current chunk so the seam is smooth. Continuous motion
    requires the (interpolated) chunk duration to exceed one inference time
    (chunk_len/freq > model_forward); tune ``--action_interp_factor`` accordingly.
    """
    import threading

    logger_mp.info(f"[async] Config: {cfg}")

    image_info = _normalize_image_info(setup_image_client(cfg))
    robot_interface = setup_robot_interface(cfg)

    arm_ctrl = robot_interface["arm_ctrl"]
    arm_ik = robot_interface["arm_ik"]
    ee_shared_mem = robot_interface["ee_shared_mem"]
    img_client = image_info["image_client"]
    camera_config = image_info["camera_config"]

    policy = build_policy(cfg, robot_interface)

    if cfg.root:
        target_arm_q, init_left_grip, init_right_grip = _load_initial_pose_from_dataset(cfg.root)
        _move_robot_to_pose(arm_ctrl, arm_ik, ee_shared_mem, target_arm_q, init_left_grip, init_right_grip)
    else:
        init_arm_q = arm_ctrl.get_current_dual_arm_q()
        tau = arm_ik.solve_tau(init_arm_q)
        arm_ctrl.ctrl_dual_arm(init_arm_q, tau)
        time.sleep(1.0)
        logger_mp.info("Robot initialized to current pose")

    input("Enter 's' to start evaluation: ")
    logger_mp.info(f"[async] Starting at {cfg.frequency} Hz, instruction: {cfg.instruction}")
    policy.set_instruction(cfg.instruction)

    interp_f = max(1, policy.action_interp_factor)
    trigger = max(1, cfg.async_trigger)

    lock = threading.Lock()
    shared = {
        "busy": False,
        "req_frame": None, "req_state": None, "req_prev": None, "req_delay": None,
        "result_exec": None, "result_raw": None,
        "stop": False,
    }

    def worker():
        while True:
            with lock:
                if shared["stop"]:
                    return
                go = shared["busy"] and shared["req_frame"] is not None
                frame = shared["req_frame"]; st = shared["req_state"]; prev = shared["req_prev"]
                delay = shared["req_delay"]
            if not go:
                time.sleep(0.002)
                continue
            try:
                raw = policy.predict_action_chunk(
                    frame, st, prev_chunk_left_over=prev, rtc_inference_delay=delay
                )
                exec_list = policy.build_exec_queue(raw)
            except Exception as e:
                logger_mp.info(f"[async worker] predict error: {e}")
                raw, exec_list = None, None
            with lock:
                shared["result_exec"] = exec_list
                shared["result_raw"] = raw
                shared["req_frame"] = None
                shared["busy"] = False

    th = threading.Thread(target=worker, daemon=True)
    th.start()

    # Bootstrap: first (blocking) chunk to fill the queue.
    observation, current_arm_q = process_images_and_observations(img_client, camera_config, arm_ctrl)
    first_frame, state_tensor = policy.observation_to_model_input(observation, current_arm_q, ee_shared_mem)
    raw = policy.predict_action_chunk(first_frame, state_tensor, prev_chunk_left_over=None)
    policy.action_queue = policy.build_exec_queue(raw)
    prev_raw = raw
    exec_since_chunk = 0     # exec steps consumed within the current chunk
    exec_count = 0           # monotonic exec-step counter
    pending_mark = None      # exec_count at the moment the in-flight request was issued
    last_skip = None         # measured exec steps elapsed during the previous inference
    raw_chunk_len = int(prev_raw.shape[0])  # raw actions per chunk (before interpolation)

    idx = 0
    try:
        while True:
            loop_start = time.perf_counter()
            current_arm_q = arm_ctrl.get_current_dual_arm_q()

            # 1) consume one action from the queue
            result = policy.step(current_arm_q)
            if result is not None:
                arm_action, left_grip, right_grip = result
                tau = arm_ik.solve_tau(arm_action)
                arm_ctrl.ctrl_dual_arm(arm_action, tau)
                _write_gripper(ee_shared_mem, left_grip, right_grip)
                exec_since_chunk += 1
                exec_count += 1
                drained = False
            else:
                drained = True  # queue empty: robot holds last command (interp factor too small?)

            # 2) splice a freshly computed chunk if ready. Skip the actions that
            #    were executed while inference was running (aligned to current
            #    progress) so we don't jump back; RTC froze exactly that prefix.
            with lock:
                ready_exec = shared["result_exec"]; ready_raw = shared["result_raw"]
                if ready_exec is not None:
                    shared["result_exec"] = None; shared["result_raw"] = None
            if ready_exec is not None:
                skip = 0
                if pending_mark is not None:
                    skip = max(0, exec_count - pending_mark)
                skip = min(skip, max(0, len(ready_exec) - 1))
                policy.action_queue = ready_exec[skip:]
                prev_raw = ready_raw
                exec_since_chunk = skip
                last_skip = skip           # remember actual inference latency (exec steps)
                pending_mark = None

            # 3) trigger next inference when queue is low and worker is idle
            with lock:
                worker_idle = not shared["busy"]
            if worker_idle and pending_mark is None and len(policy.action_queue) <= trigger:
                observation, snap_arm_q = process_images_and_observations(img_client, camera_config, arm_ctrl)
                snap_frame, snap_state = policy.observation_to_model_input(observation, snap_arm_q, ee_shared_mem)
                prev_for_rtc = None
                est_delay = None
                if cfg.rtc and prev_raw is not None:
                    # Exact interp->raw index mapping for the current chunk's
                    # interpolation grid (np.linspace(0, T-1, N)); avoids the
                    # off-by-<1 error of integer //interp_f.
                    N_cur = raw_chunk_len * interp_f
                    if N_cur > 1:
                        raw_pos = exec_since_chunk * (raw_chunk_len - 1) / (N_cur - 1)
                    else:
                        raw_pos = 0.0
                    raw_consumed = min(int(round(raw_pos)), raw_chunk_len)
                    leftover = prev_raw[raw_consumed:]
                    prev_for_rtc = leftover if leftover.shape[0] > 0 else None
                    # Adaptive frozen-prefix length (RAW steps expected to elapse
                    # during THIS inference), estimated from the previous cycle's
                    # measured skip so the freeze boundary matches the splice
                    # boundary. Falls back to the configured default on cycle 1.
                    if last_skip is not None:
                        est_delay = max(1, int(round(last_skip / interp_f)))
                    else:
                        est_delay = cfg.rtc_inference_delay
                    logger_mp.info(
                        f"[rtc] est_delay={est_delay} last_skip={last_skip} "
                        f"raw_consumed={raw_consumed} "
                        f"leftover={0 if prev_for_rtc is None else prev_for_rtc.shape[0]} "
                        f"queue={len(policy.action_queue)}"
                    )
                pending_mark = exec_count
                with lock:
                    shared["req_frame"] = snap_frame
                    shared["req_state"] = snap_state
                    shared["req_prev"] = prev_for_rtc
                    shared["req_delay"] = est_delay
                    shared["busy"] = True

            idx += 1
            loop_total = time.perf_counter() - loop_start
            _debug.loop(loop_total, cfg.frequency)
            if idx % 10 == 0:
                logger_mp.info(
                    f"[{idx}|async] loop={loop_total*1000:.1f}ms queue={len(policy.action_queue)} "
                    f"drained={drained} busy={shared['busy']}"
                )
            time.sleep(max(0, (1.0 / cfg.frequency) - (time.perf_counter() - loop_start)))

    except KeyboardInterrupt:
        logger_mp.info("Interrupted by user")
    except Exception as e:
        logger_mp.info(f"[async] Error: {e}")
    finally:
        with lock:
            shared["stop"] = True
        th.join(timeout=2.0)
        _debug.summary()
        if image_info:
            image_info["image_client"].close()
        logger_mp.info("Evaluation ended (async)")


if __name__ == "__main__":
    import sys
    from lerobot.utils.utils import init_logging

    init_logging()

    parser = argparse.ArgumentParser(description="G1 eval with MotusV2")
    parser.add_argument("--arm", type=str, default="G1_29")
    parser.add_argument("--ee", type=str, default="dex1")
    parser.add_argument("--frequency", type=float, default=30.0)
    parser.add_argument("--image_host", type=str, default="192.168.123.164")
    parser.add_argument("--instruction", type=str, required=True, help="Task instruction for MotusV2")
    parser.add_argument("--checkpoint_path", type=str, required=True, help="Path to MotusV2 checkpoint")
    parser.add_argument("--wan_path", type=str, required=True, help="Path to WAN 5B model directory")
    parser.add_argument("--vlm_path", type=str, required=True, help="Path to Qwen3-VL model directory")
    parser.add_argument("--config_path", type=str, required=True, help="Path to MotusV2 yaml config")
    parser.add_argument("--t5_cache_dir", type=str, default="", help="Path to pre-populated T5 cache dir")
    parser.add_argument("--motion", action="store_true", default=False)
    parser.add_argument("--root", type=str, default="", help="LeRobot dataset root for initial pose")
    parser.add_argument("--num_inference_steps", type=int, default=0, help="Override denoising steps (0 = use config default)")
    # --- action interpolation ---
    parser.add_argument("--action_interp_factor", type=int, default=0,
                        help="Upsample the 16-action chunk in time by this factor. "
                             "0 (default) = auto, i.e. use the config's global_downsample_rate, "
                             "which is exactly the factor that replays the chunk at the "
                             "demonstrated speed (the model's actions are spaced that many 30Hz "
                             "frames apart but carry no time scale). 1 = no interpolation, only "
                             "correct when global_downsample_rate is 1. Larger than the stride "
                             "= deliberately slower and smoother. For sustainable async "
                             "continuity需要 16*factor >= 2*inference_steps "
                             "(inference_steps ~= predict_time*frequency), which can pull the "
                             "factor above the stride at the cost of slow motion.")
    # --- async double-buffer ---
    parser.add_argument("--async_inference", action="store_true", default=False,
                        help="Run inference in a background thread and execute the queue continuously.")
    parser.add_argument("--async_trigger", type=int, default=40,
                        help="Launch the next prediction when the exec queue length drops to this. "
                             "Set >= inference_steps (+margin) to avoid draining before the new chunk is ready.")
    # --- RTC (async only) ---
    parser.add_argument("--rtc", action="store_true", default=False,
                        help="Enable Real-Time Chunking cross-chunk guidance (requires --async_inference).")
    parser.add_argument("--rtc_inference_delay", type=int, default=8,
                        help="RTC: raw-token count frozen toward the previous chunk (~inference time in raw steps).")
    parser.add_argument("--rtc_execution_horizon", type=int, default=16,
                        help="RTC: horizon over which prefix weights decay to 0.")
    parser.add_argument("--rtc_max_guidance_weight", type=float, default=5.0,
                        help="RTC: clamp on the guidance strength.")
    parser.add_argument("--rtc_schedule", type=str, default="exp",
                        choices=["exp", "linear", "ones", "zeros"], help="RTC prefix weight schedule.")
    parser.add_argument("--rtc_mode", type=str, default="inpaint",
                        choices=["inpaint", "action_jacobian", "pi05"],
                        help="RTC guidance mechanism. 'inpaint': guidance-free clean-space "
                             "blend (fastest, unconditionally stable). 'action_jacobian': exact "
                             "VJP back-propagated through the Action Expert only (the video/VLM "
                             "gradient is provably zero), with the pi0.5 guidance weight. "
                             "'pi05': faithful LeRobot pi0.5 reproduction (identity Jacobian).")
    # --- Cartesian action modes (dataset.action_mode = eef / eef_delta) ---
    parser.add_argument("--eef_stats_path", type=str, default="",
                        help="eef_stats.json the checkpoint was normalized with. It is part of "
                             "the checkpoint, not of the robot, so it has to be copied over "
                             "alongside the weights. Empty = use the path recorded in the config.")
    parser.add_argument("--urdf_root", type=str, default="",
                        help="Extra root to search for a G1 URDF (FK/IK). Empty = probe the "
                             "installed unitree_lerobot package and the usual locations.")
    # --- diagnostic logging ---
    parser.add_argument("--debug_log", action="store_true", default=False,
                        help="Mirror the diagnostic output to a timestamped file plus a JSONL "
                             "record. Off by default because the per-step records are noise "
                             "during a healthy 30 Hz run.")
    parser.add_argument("--debug_log_dir", type=str, default="",
                        help="Where to write them. Empty = <bundle>/logs.")
    parser.add_argument("--debug_log_level", type=str, default="INFO",
                        choices=["DEBUG", "INFO", "WARNING"],
                        help="File sink level. DEBUG also captures library chatter.")
    parser.add_argument("--debug_log_every", type=int, default=30,
                        help="Log one control step in N (default 30 = ~1 Hz). Guard events "
                             "(IK rejected / rate-limited) are never skipped.")
    parser.add_argument("--max_joint_step", type=float, default=0.5,
                        help="Refuse an IK solution moving any joint further than this in one "
                             "control step. Guards against a cold re-solve landing on a different "
                             "branch of the redundant arm: a valid pose reached by a motion the "
                             "hardware should not make.")

    args = parser.parse_args()

    cfg = MotusEvalConfig(
        arm=args.arm,
        ee=args.ee,
        frequency=args.frequency,
        image_host=args.image_host,
        instruction=args.instruction,
        checkpoint_path=args.checkpoint_path,
        wan_path=args.wan_path,
        vlm_path=args.vlm_path,
        config_path=args.config_path,
        t5_cache_dir=args.t5_cache_dir,
        motion=args.motion,
        root=args.root,
        num_inference_steps=args.num_inference_steps,
        action_interp_factor=args.action_interp_factor,
        async_inference=args.async_inference,
        async_trigger=args.async_trigger,
        rtc=args.rtc,
        rtc_inference_delay=args.rtc_inference_delay,
        rtc_execution_horizon=args.rtc_execution_horizon,
        rtc_max_guidance_weight=args.rtc_max_guidance_weight,
        rtc_schedule=args.rtc_schedule,
        rtc_mode=args.rtc_mode,
        eef_stats_path=args.eef_stats_path,
        urdf_root=args.urdf_root,
        max_joint_step=args.max_joint_step,
        debug_log=args.debug_log,
        debug_log_dir=args.debug_log_dir,
        debug_log_level=args.debug_log_level,
        debug_log_every=args.debug_log_every,
    )

    if cfg.rtc and not cfg.async_inference:
        logger_mp.info("[warn] --rtc requires --async_inference; RTC will be inactive in serial mode.")

    if cfg.async_inference:
        run_eval_async(cfg)
    else:
        run_eval(cfg)

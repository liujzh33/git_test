"""
G1 real-robot evaluation with the post-trained Motus (Stage-3) policy.

NOTE ON NAMING. This drives **Motus** -- the trimodal WAN + Action Expert +
Understanding Expert model in /home/work/wenjj/Motus, post-trained with
scripts/train_g1d.sh. The neighbouring eval_g1_motus.py drives **MotusV2**
(MotusWanVlmDirectMask), a different network with a different checkpoint. The
two are kept side by side deliberately; neither file imports the other.

Reuses the hardware interfaces from unitree_lerobot (make_robot.py) -- the same
ZMQ image client, the same DDS arm controller, the same Dex1 gripper shared
memory that eval_g1_motus.py drives -- and replaces only the policy with
MotusPolicyAdapter.

Motus on G1-D was post-trained on absolute 16-dim qpos (configs/g1d_*.yaml,
dataset.type=g1d, normalization: false), so a predicted action IS a joint
command after one reorder: no FK, no IK, no statistics file. solve_tau still
supplies the feedforward torque and ctrl_dual_arm still issues the command,
exactly as in the qpos path of eval_g1_motus.py.

The loop is SYNCHRONOUS by design. One chunk is 48 actions at 30 Hz (1.60 s of
motion, or 24 / 0.80 s for the mixed config) conditioned on a single
observation; the loop runs it to completion and only then predicts again. The
arm therefore holds its last command for one inference time between chunks,
which is visible but honest: whatever happens between two pauses is exactly one
chunk, with no splicing and no cross-chunk guidance in the way. Shorten the
open-loop segment with --replan_steps if you want to re-observe sooner.

This file does NOT modify or depend on eval_g1_motus.py or the MotusV2 adapter.
"""

import argparse
import time
from dataclasses import dataclass

import numpy as np
from multiprocessing.sharedctypes import SynchronizedArray

from unitree_lerobot.eval_robot.make_robot import (
    setup_image_client,
    setup_robot_interface,
    process_images_and_observations,
)
from unitree_lerobot.eval_robot.utils.utils import to_list

from motus_adapter.adapter import MotusPolicyAdapter
from motus_adapter import debug as _debug

import logging_mp

logger_mp = logging_mp.getLogger(__name__)
logger_mp.setLevel(logging_mp.INFO)


@dataclass
class MotusStage3EvalConfig:
    arm: str = "G1_29"
    ee: str = "dex1"
    frequency: float = 30.0
    motion: bool = False
    image_host: str = "192.168.123.164"
    instruction: str = ""
    # --- checkpoint artifacts (all three travel together, see the launch script) ---
    checkpoint_path: str = ""   # checkpoint_step_N dir, or the .pt inside it
    config_path: str = ""       # the training yaml that produced it
    t5_cache_dir: str = ""      # <sha1(instruction)>.pt UMT5 embeddings
    wan_path: str = ""          # dir holding Wan2.2_VAE.pth (shared with MotusV2)
    vlm_path: str = ""          # Qwen3-VL-2B-Instruct (shared with MotusV2)
    root: str = ""              # LeRobot dataset root, for the initial pose only
    # --- sampling ---
    num_inference_steps: int = 0   # 0 = the config's num_inference_timesteps (10)
    # Motus always decodes the predicted video; a controller discards it. Off by
    # default to save the VAE pass, on when the frames are wanted for debugging.
    decode_video: bool = False
    allow_checkpoint_mismatch: bool = False
    # --- chunk execution ---
    # 0 = auto: mirror the training frame stride (global_downsample_rate, 1 for
    # G1-D), which replays the chunk at the speed it was demonstrated at.
    action_interp_factor: int = 0
    # 0 = run the full horizon open loop before re-observing.
    replan_steps: int = 0
    # Refuse to move any joint further than this in one control step. The model
    # emits absolute targets, so the first action of a chunk can sit far from
    # the current pose; measured against the previous command. 0 disables it.
    max_joint_step: float = 0.0
    # --- diagnostic logging (see motus_adapter/debug.py) ---
    debug_log: bool = False
    debug_log_dir: str = ""
    debug_log_level: str = "INFO"
    debug_log_every: int = 30  # per-step throttle; guard events are never skipped


def _write_gripper(ee_shared_mem, left_grip, right_grip):
    if not ee_shared_mem:
        return
    if isinstance(ee_shared_mem.get("left"), SynchronizedArray):
        ee_shared_mem["left"][:] = to_list(np.array([left_grip]))
        ee_shared_mem["right"][:] = to_list(np.array([right_grip]))
    elif hasattr(ee_shared_mem.get("left"), "value"):
        ee_shared_mem["left"].value = float(left_grip)
        ee_shared_mem["right"].value = float(right_grip)


def _load_initial_pose_from_dataset(root):
    """First state of episode 0, used to put the arm where the demos started."""
    import os

    import pyarrow.parquet as pq

    data_dir = os.path.join(root, "data", "chunk-000")
    files = sorted(f for f in os.listdir(data_dir) if f.endswith(".parquet"))
    for f in files:
        t = pq.read_table(os.path.join(data_dir, f))
        states = t.column("observation.state").to_pylist()
        ep_indices = t.column("episode_index").to_pylist()
        for i, ep in enumerate(ep_indices):
            if ep == 0:
                state = np.array(states[i], dtype=np.float32)
                arm_q = state[:14].copy()
                left_grip = float(state[14])
                right_grip = float(state[15])
                logger_mp.info(
                    f"Loaded initial pose from dataset episode 0: arm_q={arm_q}, "
                    f"left_grip={left_grip:.4f}, right_grip={right_grip:.4f}"
                )
                return arm_q, left_grip, right_grip
    raise FileNotFoundError(f"No episode 0 found in {root}")


def _move_robot_to_pose(arm_ctrl, arm_ik, ee_shared_mem, target_arm_q,
                        left_grip, right_grip, steps=50):
    current_arm_q = arm_ctrl.get_current_dual_arm_q()
    for i in range(steps):
        alpha = (i + 1) / steps
        interp_q = current_arm_q * (1 - alpha) + target_arm_q * alpha
        tau = arm_ik.solve_tau(interp_q)
        arm_ctrl.ctrl_dual_arm(interp_q, tau)
        _write_gripper(ee_shared_mem, left_grip, right_grip)
        time.sleep(0.02)
    tau = arm_ik.solve_tau(target_arm_q)
    arm_ctrl.ctrl_dual_arm(target_arm_q, tau)
    _write_gripper(ee_shared_mem, left_grip, right_grip)
    time.sleep(0.5)
    logger_mp.info("Robot moved to dataset initial pose")


def build_policy(cfg: MotusStage3EvalConfig) -> MotusPolicyAdapter:
    """Construct the Motus policy adapter from cfg."""
    _debug.configure(cfg.debug_log, cfg.debug_log_dir, cfg.debug_log_level,
                     cfg.debug_log_every)
    policy = MotusPolicyAdapter(
        checkpoint_path=cfg.checkpoint_path,
        config_path=cfg.config_path,
        wan_path=cfg.wan_path,
        vlm_path=cfg.vlm_path,
        t5_cache_dir=cfg.t5_cache_dir,
        device="cuda",
        instruction=cfg.instruction,
        num_inference_steps=cfg.num_inference_steps,
        action_interp_factor=cfg.action_interp_factor,
        replan_steps=cfg.replan_steps,
        max_joint_step=cfg.max_joint_step,
        decode_video=cfg.decode_video,
        allow_checkpoint_mismatch=cfg.allow_checkpoint_mismatch,
    )
    policy.debug_banner(frequency=cfg.frequency)
    return policy


def _normalize_image_info(image_setup_result):
    """Accept both Unitree ImageClient setup APIs used across repo revisions."""
    if isinstance(image_setup_result, dict):
        image_info = image_setup_result
    elif isinstance(image_setup_result, tuple) and len(image_setup_result) == 2:
        image_client, camera_config = image_setup_result
        image_info = {"image_client": image_client, "camera_config": camera_config}
    else:
        raise TypeError(
            "setup_image_client() must return either "
            "{'image_client', 'camera_config'} or (image_client, camera_config); "
            f"got {type(image_setup_result).__name__}"
        )
    missing = {"image_client", "camera_config"} - image_info.keys()
    if missing:
        raise KeyError(f"setup_image_client() result is missing keys: {sorted(missing)}")
    return image_info


def _apply_action(arm_ctrl, arm_ik, ee_shared_mem, result):
    """Command one action and report where the time went."""
    if result is None:
        return 0.0, 0.0, 0.0
    arm_action, left_grip, right_grip = result

    t0 = time.perf_counter()
    tau = arm_ik.solve_tau(arm_action)
    t_ik = time.perf_counter() - t0

    t0 = time.perf_counter()
    arm_ctrl.ctrl_dual_arm(arm_action, tau)
    t_ctrl = time.perf_counter() - t0

    t0 = time.perf_counter()
    _write_gripper(ee_shared_mem, left_grip, right_grip)
    t_grip = time.perf_counter() - t0
    return t_ik, t_ctrl, t_grip


def run_eval(cfg: MotusStage3EvalConfig):
    logger_mp.info(f"Config: {cfg}")

    image_info = _normalize_image_info(setup_image_client(cfg))
    robot_interface = setup_robot_interface(cfg)

    arm_ctrl = robot_interface["arm_ctrl"]
    arm_ik = robot_interface["arm_ik"]
    ee_shared_mem = robot_interface["ee_shared_mem"]
    img_client = image_info["image_client"]
    camera_config = image_info["camera_config"]

    # Built before the arm is touched: a missing checkpoint, a stale config or an
    # uncached instruction must fail while the robot is still parked.
    policy = build_policy(cfg)

    if cfg.root:
        target_arm_q, init_left_grip, init_right_grip = _load_initial_pose_from_dataset(cfg.root)
        _move_robot_to_pose(arm_ctrl, arm_ik, ee_shared_mem,
                            target_arm_q, init_left_grip, init_right_grip)
    else:
        init_arm_q = arm_ctrl.get_current_dual_arm_q()
        tau = arm_ik.solve_tau(init_arm_q)
        arm_ctrl.ctrl_dual_arm(init_arm_q, tau)
        time.sleep(1.0)
        logger_mp.info("Robot initialized to current pose")

    input("Enter 's' to start evaluation: ")

    logger_mp.info(
        f"Starting evaluation at {cfg.frequency} Hz, instruction: {cfg.instruction}"
    )

    idx = 0
    try:
        while True:
            loop_start = time.perf_counter()

            if policy.has_cached_actions:
                t0 = time.perf_counter()
                current_arm_q = arm_ctrl.get_current_dual_arm_q()
                t_get_q = time.perf_counter() - t0

                t0 = time.perf_counter()
                result = policy.step(current_arm_q)
                t_step = time.perf_counter() - t0

                t_ik, t_ctrl, t_grip = _apply_action(arm_ctrl, arm_ik, ee_shared_mem, result)

                logger_mp.info(
                    f"[{idx}|cached] loop={(time.perf_counter() - loop_start)*1000:.1f}ms "
                    f"get_q={t_get_q*1000:.1f} step={t_step*1000:.1f} "
                    f"ik={t_ik*1000:.1f} ctrl={t_ctrl*1000:.1f} grip={t_grip*1000:.1f} "
                    f"queue={len(policy.action_queue)}"
                )
            else:
                t0 = time.perf_counter()
                observation, current_arm_q = process_images_and_observations(
                    img_client, camera_config, arm_ctrl
                )
                t_image = time.perf_counter() - t0

                t0 = time.perf_counter()
                first_frame, state_tensor = policy.observation_to_model_input(
                    observation, current_arm_q, ee_shared_mem
                )
                t_obs = time.perf_counter() - t0

                # Blocking: in the synchronous loop this is exactly the dead time
                # the arm spends holding its last command between chunks.
                t0 = time.perf_counter()
                actions_chunk = policy.predict_action_chunk(first_frame, state_tensor)
                t_predict = time.perf_counter() - t0

                policy.action_queue = policy.build_exec_queue(actions_chunk)

                logger_mp.info(
                    f"[{idx}|predict] image_net={t_image*1000:.1f}ms "
                    f"obs_preprocess={t_obs*1000:.1f}ms "
                    f"policy_infer={t_predict*1000:.1f}ms "
                    f"chunk={actions_chunk.shape} queue={len(policy.action_queue)}"
                )

                t0 = time.perf_counter()
                result = policy.step(current_arm_q)
                t_step = time.perf_counter() - t0

                t_ik, t_ctrl, t_grip = _apply_action(arm_ctrl, arm_ik, ee_shared_mem, result)

                logger_mp.info(
                    f"[{idx}|predict] TOTAL loop={(time.perf_counter() - loop_start)*1000:.1f}ms "
                    f"step={t_step*1000:.1f} ik={t_ik*1000:.1f} "
                    f"ctrl={t_ctrl*1000:.1f} grip={t_grip*1000:.1f}"
                )

            idx += 1
            _debug.loop(time.perf_counter() - loop_start, cfg.frequency)
            time.sleep(max(0, (1.0 / cfg.frequency) - (time.perf_counter() - loop_start)))

    except KeyboardInterrupt:
        logger_mp.info("Interrupted by user")
    except Exception as e:
        logger_mp.info(f"Error: {e}")
        raise
    finally:
        _debug.summary()
        if image_info:
            image_info["image_client"].close()
        logger_mp.info("Evaluation ended")


if __name__ == "__main__":
    from lerobot.utils.utils import init_logging

    init_logging()

    parser = argparse.ArgumentParser(description="G1 eval with Motus (Stage-3)")
    parser.add_argument("--arm", type=str, default="G1_29")
    parser.add_argument("--ee", type=str, default="dex1")
    parser.add_argument("--frequency", type=float, default=30.0)
    parser.add_argument("--image_host", type=str, default="192.168.123.164")
    parser.add_argument("--motion", action="store_true", default=False)
    parser.add_argument("--instruction", type=str, required=True,
                        help="Task instruction. Must match the string its T5 embedding "
                             "was precomputed for, character for character.")
    parser.add_argument("--checkpoint_path", type=str, required=True,
                        help="checkpoint_step_N directory from the training run (the one "
                             "containing pytorch_model/mp_rank_00_model_states.pt), or "
                             "the .pt file itself.")
    parser.add_argument("--config_path", type=str, required=True,
                        help="The training yaml that produced the checkpoint. It carries "
                             "the chunk geometry and the camera layout, so it has to be "
                             "the matching one: pick-kettle/pour-beans give 48-action "
                             "chunks, mixed gives 24.")
    parser.add_argument("--wan_path", type=str, required=True,
                        help="Wan2.2-TI2V-5B directory (or its parent). Same one the "
                             "MotusV2 deployment uses.")
    parser.add_argument("--vlm_path", type=str, required=True,
                        help="Qwen3-VL-2B-Instruct directory. Same one the MotusV2 "
                             "deployment uses.")
    parser.add_argument("--t5_cache_dir", type=str, required=True,
                        help="Directory of <sha1(instruction)>.pt UMT5 embeddings. Motus "
                             "and MotusV2 use the same scheme, so an existing MotusV2 "
                             "cache works for the same instruction.")
    parser.add_argument("--root", type=str, default="",
                        help="LeRobot dataset root, used only to move the arm to the pose "
                             "episode 0 started from.")
    parser.add_argument("--num_inference_steps", type=int, default=0,
                        help="Override the denoising steps (0 = the config's "
                             "model.inference.num_inference_timesteps, 10 for G1-D).")
    parser.add_argument("--decode_video", action="store_true", default=False,
                        help="Keep the Wan2.2 VAE decode of the predicted video. Off by "
                             "default: the controller uses only the actions, so the decode "
                             "is pure latency. Turn it on to inspect what the model "
                             "imagined.")
    parser.add_argument("--allow_checkpoint_mismatch", action="store_true", default=False,
                        help="Load the checkpoint with strict=False. Use only to diagnose "
                             "a key mismatch; a silently partial load produces a model "
                             "that runs and is wrong.")
    parser.add_argument("--action_interp_factor", type=int, default=0,
                        help="Upsample the chunk in time by this factor. 0 (default) = "
                             "auto, i.e. the config's global_downsample_rate, which "
                             "replays the chunk at the demonstrated speed. G1-D ships "
                             "rate 1, so auto is 1 and 48 actions are 48 control ticks "
                             "(1.60 s). Larger = deliberately slower and smoother.")
    parser.add_argument("--replan_steps", type=int, default=0,
                        help="Execute only this many steps of each chunk before "
                             "re-observing. 0 (default) = the full horizon, which is what "
                             "the model was trained to plan. Smaller reacts sooner but "
                             "pays one inference pause per replan.")
    parser.add_argument("--max_joint_step", type=float, default=0.0,
                        help="Refuse to move any joint further than this (rad) in one "
                             "control step, measured against the previous command. The "
                             "model emits absolute targets, so the first action of a chunk "
                             "can sit far from the current pose. 0 (default) = off.")
    parser.add_argument("--debug_log", action="store_true", default=False,
                        help="Mirror the diagnostics to a timestamped file plus a JSONL "
                             "record. Off by default because the per-step records are "
                             "noise during a healthy 30 Hz run.")
    parser.add_argument("--debug_log_dir", type=str, default="",
                        help="Where to write them. Empty = <bundle>/logs.")
    parser.add_argument("--debug_log_level", type=str, default="INFO",
                        choices=["DEBUG", "INFO", "WARNING"])
    parser.add_argument("--debug_log_every", type=int, default=30,
                        help="Log one control step in N (30 = ~1 Hz). Guard events are "
                             "never skipped.")

    args = parser.parse_args()

    cfg = MotusStage3EvalConfig(
        arm=args.arm,
        ee=args.ee,
        frequency=args.frequency,
        image_host=args.image_host,
        motion=args.motion,
        instruction=args.instruction,
        checkpoint_path=args.checkpoint_path,
        config_path=args.config_path,
        wan_path=args.wan_path,
        vlm_path=args.vlm_path,
        t5_cache_dir=args.t5_cache_dir,
        root=args.root,
        num_inference_steps=args.num_inference_steps,
        decode_video=args.decode_video,
        allow_checkpoint_mismatch=args.allow_checkpoint_mismatch,
        action_interp_factor=args.action_interp_factor,
        replan_steps=args.replan_steps,
        max_joint_step=args.max_joint_step,
        debug_log=args.debug_log,
        debug_log_dir=args.debug_log_dir,
        debug_log_level=args.debug_log_level,
        debug_log_every=args.debug_log_every,
    )

    run_eval(cfg)

"""Opt-in diagnostic logging for the Motus (Stage-3) G1-D control loop.

Off by default: at 30 Hz the per-step records are noise during a healthy run.
``--debug_log`` turns it on and mirrors everything into a timestamped file next
to a JSONL sibling, so a session can be replayed offline without re-parsing
prose.

Motus emits ABSOLUTE joint targets under no normalization, so the failure modes
match the FastWAM qpos path rather than the Cartesian MotusV2 one, and this
module records the same four things:

1. Contract. The weights and the training yaml are a matched set. The yaml
   carries the chunk geometry and the camera layout; a checkpoint served against
   a different one produces a plausible-looking but wrong trajectory. The md5 of
   each artifact goes in first, together with the T5 cache file the instruction
   resolved to -- a stale embedding is silent.

2. Seam. Every chunk is conditioned on a fresh observation, and its first
   action is an absolute pose. If that pose is far from where the arm actually
   is, the arm snaps at the chunk boundary. ``|a[0] - q_meas|`` is therefore the
   single most informative number per chunk, and no other log line shows it.

3. Travel. Peak step-to-step joint motion says whether the chunk asks for a
   speed the hardware should be making at all, before the arm demonstrates it.

4. Tracking. ``|cmd - meas|`` separates "the policy asked for the wrong thing"
   from "the arm never got there".
"""

from __future__ import annotations

import hashlib
import json
import logging
import time
from pathlib import Path
from typing import Optional

import numpy as np

logger = logging.getLogger(__name__)

_state: dict = {"on": False}


# --------------------------------------------------------------------------- #
# setup
# --------------------------------------------------------------------------- #
def configure(enabled: bool, log_dir: str = "", level: str = "INFO",
              every: int = 30, tag: str = "motus_g1d") -> Optional[str]:
    """Attach a file sink to the root logger and open the JSONL record.

    Returns the log path, or None when disabled. Safe to call twice; the second
    call is ignored so a re-entrant eval loop cannot double-log.
    """
    if _state.get("configured"):
        return _state.get("log_path")
    _state["configured"] = True
    _state["on"] = bool(enabled)
    _state["every"] = max(1, int(every))
    _state["t0"] = time.time()
    _state["counters"] = {}
    _state["track"] = []
    _state["loop_dt"] = []
    if not enabled:
        return None

    d = Path(log_dir) if log_dir else Path(__file__).resolve().parents[2] / "logs"
    d.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    log_path = d / f"inference_{tag}_{stamp}.log"
    jsonl_path = d / f"inference_{tag}_{stamp}.jsonl"

    fh = logging.FileHandler(log_path, encoding="utf-8")
    fh.setLevel(getattr(logging, str(level).upper(), logging.INFO))
    fh.setFormatter(logging.Formatter(
        "%(asctime)s %(levelname)-7s %(name)s | %(message)s", "%H:%M:%S"))
    root = logging.getLogger()
    root.addHandler(fh)
    if root.level > fh.level:
        root.setLevel(fh.level)

    _state["log_path"] = str(log_path)
    _state["jsonl"] = open(jsonl_path, "a", encoding="utf-8")
    logger.info("[debug] logging to %s (records: %s)", log_path, jsonl_path)
    return str(log_path)


def on() -> bool:
    return bool(_state.get("on"))


def _rec(kind: str, **fields) -> None:
    """Append one machine-readable record. Never raises into the control loop."""
    fh = _state.get("jsonl")
    if fh is None:
        return
    try:
        fields["t"] = round(time.time() - _state["t0"], 4)
        fields["kind"] = kind
        fh.write(json.dumps(fields, ensure_ascii=False, default=float) + "\n")
        fh.flush()
    except Exception as e:  # a broken log must never stop the robot
        logger.debug("[debug] record dropped: %s", e)


def count(name: str, n: int = 1) -> None:
    _state.setdefault("counters", {})
    _state["counters"][name] = _state["counters"].get(name, 0) + n


def _md5(path) -> str:
    try:
        h = hashlib.md5()
        with open(path, "rb") as f:
            for block in iter(lambda: f.read(1 << 20), b""):
                h.update(block)
        return h.hexdigest()
    except Exception:
        return "?"


# --------------------------------------------------------------------------- #
# 1. contract
# --------------------------------------------------------------------------- #
def banner(*, checkpoint: str, config_path: str, t5_path: str, instruction: str,
           chunk: int, interp: int, freq: float, inference_steps: int,
           video_size, cameras, decode_video: bool,
           extra: Optional[dict] = None) -> None:
    """One-time dump of everything that has to match the checkpoint.

    The md5s are the point: they are what a later reader needs to prove the run
    used the artifacts it was supposed to.
    """
    if not on():
        return
    lines = ["[debug] ==== run contract ===="]
    lines.append(f"    {'checkpoint':13s}: {checkpoint}")
    lines.append(f"    {'config':13s}: {config_path}  md5={_md5(config_path)}")
    lines.append(f"    {'t5_embedding':13s}: {t5_path}  md5={_md5(t5_path)}")
    lines.append(f"    {'instruction':13s}: {instruction!r}  "
                 f"sha1={hashlib.sha1(instruction.encode()).hexdigest()[:12]}")
    lines.append(f"    {'chunk':13s}: {chunk} actions  interp x{interp}  @ {freq:g} Hz"
                 f"  -> {chunk * interp / max(freq, 1e-9):.2f} s per chunk")
    lines.append(f"    {'sampling':13s}: {inference_steps} denoising steps")
    lines.append(f"    {'video':13s}: {list(video_size)}  cameras={list(cameras)}")
    lines.append(f"    {'vae_decode':13s}: {'on' if decode_video else 'skipped (actions only)'}")
    for k, v in (extra or {}).items():
        lines.append(f"    {k:13s}: {v}")
    logger.info("\n".join(lines))
    _rec("contract", checkpoint=checkpoint, config=config_path,
         config_md5=_md5(config_path), t5=t5_path, t5_md5=_md5(t5_path),
         instruction=instruction, chunk=chunk, interp=interp, freq=freq,
         steps=inference_steps, video_size=list(video_size), cameras=list(cameras),
         decode_video=decode_video, **(extra or {}))


# --------------------------------------------------------------------------- #
# 2 / 3. per-chunk record
# --------------------------------------------------------------------------- #
def chunk(*, index: int, actions: np.ndarray, q_meas: np.ndarray,
          predict_ms: float = 0.0, freq: float = 30.0) -> dict:
    """One record per predicted chunk, in joint space.

    ``actions`` is the RAW 16-dim chunk in training layout [L7, LG, R7, RG];
    ``q_meas`` the measured 14 arm joints the chunk was conditioned on. Returns
    the statistics so the caller can log them even with the file sink off.
    """
    a = np.asarray(actions, dtype=np.float64)
    arm = np.concatenate([a[:, 0:7], a[:, 8:15]], axis=1)  # drop the grippers
    meas = np.asarray(q_meas, dtype=np.float64)[:14]

    seam = float(np.abs(arm[0] - meas).max())
    travel = float(np.abs(arm[-1] - arm[0]).max())
    stepwise = np.abs(np.diff(arm, axis=0)).max(axis=1) if len(arm) > 1 else np.zeros(1)
    peak_rate = float(stepwise.max()) * freq
    grip = {"left": (float(a[:, 7].min()), float(a[:, 7].max())),
            "right": (float(a[:, 15].min()), float(a[:, 15].max()))}

    stats = {"seam_rad": seam, "travel_rad": travel,
             "step_max_rad": float(stepwise.max()), "peak_rad_s": peak_rate,
             "grip": grip}
    if not on():
        return stats

    logger.info(
        "[debug][chunk %d] %d actions, predict %.0f ms\n"
        "    seam |a[0]-q_meas| : %6.4f rad   <- how hard the arm snaps at the boundary\n"
        "    travel |a[-1]-a[0]|: %6.4f rad\n"
        "    step-to-step       : median %6.4f rad  max %6.4f rad  (%.2f rad/s peak)\n"
        "    gripper span       : left %.4f..%.4f  right %.4f..%.4f",
        index, len(a), predict_ms, seam, travel,
        float(np.median(stepwise)), float(stepwise.max()), peak_rate,
        grip["left"][0], grip["left"][1], grip["right"][0], grip["right"][1])
    _rec("chunk", index=index, n=len(a), predict_ms=predict_ms,
         first_action=arm[0].tolist(), q_meas=meas.tolist(), **stats)
    return stats


# --------------------------------------------------------------------------- #
# 4. per-step and loop records
# --------------------------------------------------------------------------- #
def step(*, index: int, q_cmd: np.ndarray, q_meas: np.ndarray,
         joint_step: float, guard: str = "", queue: int = -1) -> None:
    """Per-control-step record, throttled to one in ``--debug_log_every``.

    Guard events are never throttled: they are rare and they are the interesting
    ones. ``q_cmd - q_meas`` is the servo tracking error, which is what tells a
    "the policy is wrong" failure apart from a "the arm never got there" one.
    """
    if not on():
        return
    track = float(np.abs(np.asarray(q_cmd, dtype=float)
                         - np.asarray(q_meas, dtype=float)[:14]).max())
    _state["track"].append(track)
    if guard:
        count(f"guard:{guard}")
    if not guard and index % _state["every"] != 0:
        return
    level = logger.warning if guard else logger.info
    level("[debug][step %d] joint_step %.4f rad  tracking |cmd-meas| %.4f rad  "
          "queue %d%s", index, joint_step, track, queue,
          f"  GUARD={guard}" if guard else "")
    _rec("step", index=index, joint_step=joint_step, tracking_max_rad=track,
         queue=queue, guard=guard or None,
         q_cmd=np.asarray(q_cmd, dtype=float).tolist())


def loop(dt_s: float, target_hz: float) -> None:
    """One control-loop iteration took ``dt_s``.

    The eval loop reports this through logging_mp, which does not propagate to
    the root logger and so never reaches the debug file. Recorded here instead.

    A loop that cannot keep up does not fail: it replays the chunk in slow
    motion, and since each action is a discrete target the arm snaps to and then
    holds, the motion reads as a stutter rather than as "too slow".
    """
    if not on():
        return
    _state["loop_dt"].append(float(dt_s))
    dts = _state["loop_dt"]
    if len(dts) % 300:
        return
    window = np.asarray(dts[-300:])
    hz = 1.0 / max(float(np.median(window)), 1e-9)
    _rec("loop", n=len(dts), hz=hz, median_ms=float(np.median(window) * 1000),
         p90_ms=float(np.percentile(window, 90) * 1000), target_hz=target_hz)
    if hz < 0.7 * target_hz:
        count("loop_underrun")
        logger.warning(
            "[debug][loop] %.1f Hz against a %.0f Hz target (iteration %.1f ms, "
            "budget %.1f ms). The chunk is being replayed %.1fx slower than "
            "demonstrated, and each action is held for %.0f ms instead of %.0f "
            "-- that is what a stutter looks like.",
            hz, target_hz, 1000 / hz, 1000 / target_hz, target_hz / hz,
            1000 / hz, 1000 / target_hz)
    else:
        logger.info("[debug][loop] %.1f Hz (iteration %.1f ms of a %.1f ms budget)",
                    hz, 1000 / hz, 1000 / target_hz)


def predict(ms: float) -> None:
    """Wall-clock of one blocking inference, tallied for the summary.

    In the synchronous loop this is dead time: the arm holds its last command
    for exactly this long between chunks, so it is the number that decides
    whether the motion reads as continuous.
    """
    _state.setdefault("predict_ms", []).append(float(ms))


def summary() -> None:
    """End-of-run tally. Cheap, and it is what a bug report should start with."""
    if not on():
        return
    lines = ["[debug] ==== run summary ===="]
    lines.append(f"    duration      : {time.time() - _state['t0']:.1f} s")
    track = np.asarray(_state.get("track") or [0.0])
    lines.append(f"    control steps : {len(track)}")
    lines.append(f"    tracking error: median {np.median(track):.4f} rad  "
                 f"p95 {np.percentile(track, 95):.4f} rad  max {track.max():.4f} rad")
    pm = np.asarray(_state.get("predict_ms") or [0.0])
    lines.append(f"    inference     : {len(pm)} chunks, median {np.median(pm):.0f} ms  "
                 f"p95 {np.percentile(pm, 95):.0f} ms  max {pm.max():.0f} ms")
    dts = _state.get("loop_dt")
    if dts:
        dts = np.asarray(dts)
        hz = 1.0 / max(float(np.median(dts)), 1e-9)
        lines.append(f"    control loop  : {hz:.1f} Hz achieved "
                     f"(iteration median {np.median(dts) * 1000:.1f} ms, "
                     f"p90 {np.percentile(dts, 90) * 1000:.1f} ms)")
    for k, v in sorted(_state.get("counters", {}).items()):
        lines.append(f"    {k:14s}: {v}")
    if _state.get("log_path"):
        lines.append(f"    log           : {_state['log_path']}")
    logger.info("\n".join(lines))
    _rec("summary", steps=len(track), tracking_median_rad=float(np.median(track)),
         tracking_max_rad=float(track.max()),
         predict_median_ms=float(np.median(pm)),
         counters=dict(_state.get("counters", {})))
    fh = _state.get("jsonl")
    if fh is not None:
        try:
            fh.close()
        except Exception:
            pass

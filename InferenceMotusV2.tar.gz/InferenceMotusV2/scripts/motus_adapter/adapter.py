"""Bridge between the post-trained Motus G1-D checkpoint and the G1 eval loop.

NOTE ON NAMING. This serves **Motus** -- the trimodal WAN + Action Expert +
Understanding Expert model in ``/home/work/wenjj/Motus``, class ``Motus`` in
``models/motus.py``. It is NOT MotusV2 (``MotusWanVlmDirectMask``), which
``motusv2_adapter/`` and ``eval_g1_motus.py`` serve. The two share a lineage and
a Wan2.2 backbone but are different networks with different checkpoints.

Like the FastWAM G1-D path, Motus on G1-D is the easy action space: the model
emits absolute 16-dim qpos in the ``[L7, LG, R7, RG]`` layout with
``normalization: false``, so a predicted action is a joint command after one
reorder. No FK, no IK, no statistics file.

What differs from BOTH neighbours, and differs silently:

* Camera stitch. Motus stitches at native resolution and letterboxes ONCE at the
  end: ``concat_cameras_robotwin`` puts the head above two half-size wrists
  (480x640 -> 720x640) and ``resize_with_padding`` scales that to fit 384x320,
  leaving a black band. FastWAM instead resizes each camera into a fixed region
  that fills the canvas exactly. Same 384x320, different picture.
* Resize backend. Motus resizes with **Pillow BILINEAR** (``_resize_hwc``).
  The stale copy under ``Motus/inference/real_world/Motus/utils/image_utils.py``
  uses ``cv2.resize`` instead, which is a different filter on a 2x downscale --
  which is why this adapter vendors and calls the TRAINING implementation rather
  than that one.
* Value range. Motus consumes ``[0, 1]`` and normalises to ``[-1, 1]`` itself
  inside ``inference_step``; FastWAM wants ``[-1, 1]`` handed in.
* Text. Motus reads a bare ``[<=512, 4096]`` UMT5 tensor keyed by
  ``sha1(instruction)`` -- the same scheme MotusV2 uses, so an existing MotusV2
  cache directory works as-is for the same instruction.

Every step below therefore calls the training code itself where it can
(``concat_cameras_robotwin``, ``resize_with_padding``, ``tensor_to_pil``,
``unify_g1d_qpos_to_16``, ``preprocess_vlm_messages``) rather than reimplementing
it, and ``tests/test_motus_adapter_wiring.py`` pins the rest.

Time base: ``global_downsample_rate: 1``, so the emitted actions are consecutive
30 Hz frames and one chunk is ``num_video_frames * video_action_freq_ratio``
control ticks -- 48 (1.60 s) for pick-kettle / pour-beans, 24 (0.80 s) for mixed.
"""

from __future__ import annotations

import copy
import hashlib
import logging
import os
import sys
import tempfile
import time
from pathlib import Path
from typing import List, Optional, Tuple

import numpy as np
import torch
import yaml

try:
    from motus_adapter import debug as _debug
except ImportError:  # adapter.py imported directly rather than as a package member
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import debug as _debug  # type: ignore

logger = logging.getLogger(__name__)

# Raw robot layout [L7, R7, LG, RG] -> training layout [L7, LG, R7, RG].
# Mirrors data/real_robot/common.py::G1D_REORDER_FROM_RAW, which the wiring test
# asserts this against; kept here so the inverse can be written next to it.
_REORDER_FROM_RAW = [0, 1, 2, 3, 4, 5, 6, 14, 7, 8, 9, 10, 11, 12, 13, 15]

# Packages the vendored Motus inference closure needs. All of them are already
# in the MotusV2 deployment environment (scripts/install_motus_5090.sh), but the
# import that fails without one names a transitive module and reads like a bug
# in the bundle, so they are checked by name up front.
_REQUIRED_MODULES = {
    "torch": "torch",
    "transformers": "transformers",
    "diffusers": "diffusers==0.35.2",
    "deepspeed": "deepspeed==0.19.2",
    "qwen_vl_utils": "qwen-vl-utils==0.0.14",
    "pandas": "pandas",
    "PIL": "Pillow",
    "einops": "einops",
    "imageio": "imageio",
    "safetensors": "safetensors",
}


def _resolve_motus_dir() -> str:
    """Locate the vendored Motus sources across layouts.

    Works for the self-contained bundle (``<bundle>/policy/Motus``) and for a dev
    box pointing straight at the training checkout. Set ``MOTUS_STAGE3_DIR`` to
    override explicitly.

    Deliberately NOT named MOTUS_POLICY_DIR: that variable already selects the
    MotusV2 policy for the other deployment, and both scripts can be sourced in
    the same shell.
    """
    here = Path(__file__).resolve()
    bundle_root = here.parents[2]  # .../InferenceMotusV2
    candidates: List[Path] = []
    env = os.environ.get("MOTUS_STAGE3_DIR")
    if env:
        candidates.append(Path(env))
    candidates.append(bundle_root / "policy" / "Motus")
    candidates.append(Path("/home/work/wenjj/Motus"))
    for c in candidates:
        if (c / "models" / "motus.py").exists() and (c / "bak" / "wan").is_dir():
            return str(c)
    raise FileNotFoundError(
        "cannot find the Motus sources. Looked for models/motus.py + bak/wan under "
        f"{[str(c) for c in candidates]}. Set MOTUS_STAGE3_DIR, or re-sync the bundle:\n"
        "  rsync -a --exclude '__pycache__/' <Motus>/models/ <bundle>/policy/Motus/models/\n"
        "  rsync -a --exclude '__pycache__/' <Motus>/bak/    <bundle>/policy/Motus/bak/\n"
        "  rsync -a --exclude '__pycache__/' <Motus>/utils/  <bundle>/policy/Motus/utils/\n"
        "  cp <Motus>/data/{__init__.py,utils/__init__.py,utils/image_utils.py,"
        "real_robot/__init__.py,real_robot/common.py} <bundle>/policy/Motus/data/..."
    )


def _check_dependencies() -> None:
    import importlib.util

    missing = sorted(
        pip_name for mod, pip_name in _REQUIRED_MODULES.items()
        if importlib.util.find_spec(mod) is None
    )
    if missing:
        raise ImportError(
            "the Motus inference closure needs packages this environment does not "
            f"have: {missing}. Install them into the deployment env, e.g.\n"
            f"  python -m pip install {' '.join(missing)}"
        )


def _ensure_cuda_home_for_deepspeed() -> None:
    """Give DeepSpeed a CUDA_HOME so importing ``models.motus`` succeeds.

    ``models/motus.py`` -> ``utils/common.py`` -> ``import deepspeed.comm.comm``,
    and DeepSpeed probes ``$CUDA_HOME/bin/nvcc`` at import time even though this
    path compiles no CUDA op. The deployment installs PyTorch wheels that carry
    their own CUDA runtime, so there is often no system toolkit and the import
    dies with MissingCUDAException.

    ``Motus/scripts/train_g1d.sh`` solves this upstream by pointing CUDA_HOME at
    a directory holding a small ``nvcc`` that answers ``--version``; the same
    trick is applied here rather than stubbing the deepspeed module, so nothing
    lies about which packages are installed.
    """
    os.environ.setdefault("DS_SKIP_CUDA_CHECK", "1")
    current = os.environ.get("CUDA_HOME", "")
    if current and (Path(current) / "bin" / "nvcc").exists():
        return
    for real in ("/usr/local/cuda", "/usr/local/cuda-12", "/usr/lib/cuda"):
        if (Path(real) / "bin" / "nvcc").exists():
            os.environ["CUDA_HOME"] = real
            return

    root = Path(__file__).resolve().parents[2] / ".cuda_home_stub"
    try:
        (root / "bin").mkdir(parents=True, exist_ok=True)
    except OSError:  # a read-only bundle is a legitimate deployment
        root = Path(tempfile.mkdtemp(prefix="motus_cuda_home_"))
        (root / "bin").mkdir(parents=True, exist_ok=True)
    nvcc = root / "bin" / "nvcc"
    if not nvcc.exists():
        nvcc.write_text(
            "#!/bin/bash\n"
            "# Minimal nvcc stub so DeepSpeed can query a CUDA version when no system\n"
            "# toolkit is installed. Motus imports deepspeed.comm only; no CUDA op is\n"
            "# ever built. Mirrors Motus/scripts/train_g1d.sh.\n"
            'if [[ "$*" == *"-V"* ]] || [[ "$*" == *"--version"* ]]; then\n'
            '  echo "nvcc: NVIDIA (R) Cuda compiler driver"\n'
            '  echo "Cuda compilation tools, release 12.8, V12.8.61"\n'
            "  exit 0\n"
            "fi\n"
            'echo "stub nvcc invoked unexpectedly: $*" >&2\n'
            "exit 1\n"
        )
        nvcc.chmod(0o755)
    os.environ["CUDA_HOME"] = str(root)
    logger.info("CUDA_HOME not usable; pointing DeepSpeed at the stub %s", root)


def _alias_qwen_vl_utils(motus_dir: str) -> None:
    """Let ``utils/vlm_utils.py`` import ``qwen_vl_utils`` without the pip package.

    Upstream imports it unguarded at module scope. The deployment env installs
    ``qwen-vl-utils``, so this is a no-op there; on a machine that only has the
    vendored ``bak/wan/utils/qwen_vl_utils.py`` (the same file the MotusV2
    adapter falls back to) it registers that copy under the expected name so the
    wiring tests can run.
    """
    import importlib.util

    if importlib.util.find_spec("qwen_vl_utils") is not None:
        return
    fallback = Path(motus_dir) / "bak" / "wan" / "utils" / "qwen_vl_utils.py"
    if not fallback.is_file():
        return
    import importlib

    bak = str(Path(motus_dir) / "bak")
    if bak not in sys.path:
        sys.path.insert(0, bak)
    try:
        sys.modules["qwen_vl_utils"] = importlib.import_module("wan.utils.qwen_vl_utils")
        logger.info("qwen-vl-utils not installed; using the vendored copy in bak/wan.")
    except Exception as e:
        logger.warning("could not alias the vendored qwen_vl_utils: %s", e)


_MOTUS_DIR = _resolve_motus_dir()
if _MOTUS_DIR not in sys.path:
    sys.path.insert(0, _MOTUS_DIR)
_check_dependencies()
_ensure_cuda_home_for_deepspeed()
_alias_qwen_vl_utils(_MOTUS_DIR)

from data.real_robot.common import (  # noqa: E402
    G1D_REORDER_FROM_RAW,
    concat_cameras_robotwin,
    unify_g1d_qpos_to_16,
)
from data.utils.image_utils import resize_with_padding, tensor_to_pil  # noqa: E402
from models.motus import Motus, MotusConfig  # noqa: E402
from utils.vlm_utils import preprocess_vlm_messages  # noqa: E402

from transformers import AutoProcessor  # noqa: E402


def _resolve_checkpoint_file(path: str) -> Path:
    """Accept a run directory, a checkpoint_step_N directory, or the .pt itself.

    DeepSpeed writes ``checkpoint_step_N/pytorch_model/mp_rank_00_model_states.pt``;
    a repacked release often flattens that one level. Both are tried, matching
    ``inference/real_world/Motus/server_franka_multitask.py``.
    """
    p = Path(path).expanduser()
    if p.is_file():
        return p
    candidates = [
        p / "pytorch_model" / "mp_rank_00_model_states.pt",
        p / "mp_rank_00_model_states.pt",
    ]
    for c in candidates:
        if c.is_file():
            return c
    raise FileNotFoundError(
        f"could not find mp_rank_00_model_states.pt under {p}; tried "
        f"{[str(c) for c in candidates]}. Point --checkpoint_path at the "
        "checkpoint_step_N directory the trainer wrote, or at the .pt itself."
    )


class _NoVideoDecode:
    """Context manager that skips the Wan2.2 VAE decode during control.

    ``Motus.inference_step`` always decodes the predicted video and returns it,
    but a controller uses only the actions -- so on the robot that decode is
    pure latency, roughly a second per chunk on top of the denoising.

    Replacing ``video_model.decode_video`` for the duration of the call is the
    least invasive way to skip it: the vendored ``models/motus.py`` stays
    byte-identical to the training repo (which the wiring test verifies), and
    nothing about the action branch changes. The stub returns a tensor of the
    right rank and dtype but minimal size; ``inference_step`` slices it,
    rescales it and hands it back, and this adapter drops it on the floor.

    Pass ``--decode_video`` to keep the real decode when the predicted frames
    are wanted for debugging.
    """

    def __init__(self, model: Motus, enabled: bool) -> None:
        self._video_model = model.video_model
        self._enabled = enabled
        self._original = None

    def __enter__(self):
        if not self._enabled:
            return self
        self._original = self._video_model.decode_video

        def _skip(latent, *args, **kwargs):
            # [B, C, T>=2, H, W]: inference_step drops index 0 as the condition
            # frame, so T must be at least 2 for the slice to stay non-empty.
            return torch.zeros(
                (latent.shape[0], 3, 2, 1, 1),
                device=latent.device, dtype=latent.dtype,
            )

        self._video_model.decode_video = _skip
        return self

    def __exit__(self, *exc):
        if self._original is not None:
            self._video_model.decode_video = self._original
        return False


class MotusPolicyAdapter:
    """Motus G1-D policy behind the same interface the eval loop already uses.

    The public surface matches ``MotusV2PolicyAdapter`` and
    ``FastWAMPolicyAdapter`` so all three can be swapped without touching the
    control loop:

        set_instruction / debug_banner / has_cached_actions /
        observation_to_model_input / predict_action_chunk / build_exec_queue /
        step / reset / action_queue

    RTC and async double-buffering are deliberately absent. One chunk is a full
    48 (or 24) control ticks of absolute joint targets conditioned on one
    observation, and the synchronous loop runs it to completion before
    predicting again -- one chunk in, one chunk out, with nothing spliced in
    between. That makes a bad chunk attributable to the model rather than to the
    blending.
    """

    # ---------------------------------------------------------------- config

    @staticmethod
    def resolve_action_interp_factor(action_interp_factor: int,
                                     global_downsample_rate: int) -> int:
        """Pick the time-stretch factor for a predicted chunk.

        ``<= 0`` means "auto": mirror the training frame stride, which is the
        only factor that replays the chunk at the speed it was demonstrated at.
        The G1-D configs ship ``global_downsample_rate: 1``, so auto is 1 and the
        chunk is already one action per 30 Hz tick. A positive value is taken
        verbatim so the operator can deliberately run the motion slower.
        """
        if action_interp_factor > 0:
            return int(action_interp_factor)
        return max(1, int(global_downsample_rate))

    def __init__(
        self,
        checkpoint_path: str,
        config_path: str,
        wan_path: str,
        vlm_path: str,
        t5_cache_dir: str = "",
        device: str = "cuda",
        arm_dof: int = 14,
        ee_dof: int = 1,
        instruction: str = "",
        num_inference_steps: int = 0,
        action_interp_factor: int = 0,
        replan_steps: int = 0,
        max_joint_step: float = 0.0,
        decode_video: bool = False,
        allow_checkpoint_mismatch: bool = False,
    ):
        self.device = device
        self.checkpoint_path = str(checkpoint_path)
        self._config_path = str(config_path)
        self.arm_dof = int(arm_dof)
        self.ee_dof = int(ee_dof)
        self.current_instruction = instruction
        self.t5_cache_dir = str(t5_cache_dir)
        self.max_joint_step = float(max_joint_step)
        self.decode_video = bool(decode_video)
        self.allow_checkpoint_mismatch = bool(allow_checkpoint_mismatch)

        with open(config_path, "r", encoding="utf-8") as f:
            self.config_dict = yaml.safe_load(f)

        self._read_data_contract()

        self._override_steps = (
            int(num_inference_steps) if num_inference_steps and num_inference_steps > 0 else None
        )
        self.num_inference_steps = self._override_steps or int(
            self.config_dict["model"]["inference"]["num_inference_timesteps"]
        )

        self.action_interp_factor = self.resolve_action_interp_factor(
            int(action_interp_factor), self._global_downsample_rate
        )
        self._log_time_base()

        # 0 = run the whole chunk open loop, which is the horizon the model was
        # trained to plan over. A smaller value re-observes sooner at the cost of
        # one inference pause per replan; the synchronous loop has no way to hide
        # that pause, so shortening it is a deliberate reactivity/continuity trade.
        self.replan_steps = int(replan_steps) if replan_steps and replan_steps > 0 else 0

        self._init_runtime_state()
        # Before the model load, not after: a mistyped instruction or an
        # uncopied cache directory should fail in a second rather than after
        # minutes of building a 5B network, and long before the arm is live.
        self.set_instruction(instruction)

        self.vlm_processor = AutoProcessor.from_pretrained(vlm_path, trust_remote_code=True)
        self.model = self._load_model(wan_path, vlm_path)

        logger.info("MotusPolicyAdapter initialized (G1-D qpos, %d-action chunks)",
                    self.action_chunk_size)

    def _init_runtime_state(self) -> None:
        """Everything an episode mutates, separated from the model load.

        Kept apart so the wiring tests can exercise the observation and action
        paths on a bare instance without materialising the network.
        """
        self.action_queue: List[Tuple[np.ndarray, None]] = []
        self.current_state: Optional[torch.Tensor] = None
        self._first_frame: Optional[torch.Tensor] = None
        self._first_frame_pil = None
        self._last_cmd_q: Optional[np.ndarray] = None
        self._chunk_index = -1
        self._step_index = 0
        self._clamp_count = 0
        self._last_predict_ms = 0.0
        self._last_joint_step = 0.0
        self._last_guard = ""
        self._last_q_meas = np.zeros(14, dtype=np.float64)
        self._t5_embedding: Optional[torch.Tensor] = None
        self._t5_path = ""

    def _read_data_contract(self) -> None:
        """Pull the serving contract out of the training config and check it.

        Everything here is a property of the checkpoint, so reading it rather
        than hardcoding it is what lets one adapter serve pick-kettle (chunk 48)
        and mixed (chunk 24) alike. The assertions cover the cases where a wrong
        value would still run and just produce wrong actions.
        """
        common = self.config_dict["common"]
        ds_cfg = self.config_dict["dataset"]
        params = ds_cfg.get("params", {}) or {}

        robot = str(ds_cfg.get("type", "")).lower()
        if robot != "g1d":
            raise ValueError(
                f"dataset.type is {robot!r}, expected 'g1d'. This adapter maps the "
                "16-dim G1-D qpos layout onto the arm and gripper commands and has no "
                "meaning for another embodiment."
            )

        layout = str(params.get("camera_layout", "robotwin"))
        if layout != "robotwin":
            raise ValueError(
                f"dataset.params.camera_layout is {layout!r}, expected 'robotwin'. The "
                "stitch below is the T layout and nothing else."
            )

        # G1-D trains on raw absolute qpos. `normalization` may be absent, in
        # which case RealRobotMotusDataset defaults it to False for robot_type
        # g1d -- reproduce that default rather than guessing.
        norm = params.get("normalization", None)
        self.normalization = (robot != "g1d") if norm is None else bool(norm)
        if self.normalization:
            raise ValueError(
                "dataset.params.normalization is true, but this adapter ships no "
                "statistics and would feed the model unscaled state while reading "
                "unscaled actions back. G1-D trains with normalization: false."
            )

        self.action_dim = int(common["action_dim"])
        self.state_dim = int(common["state_dim"])
        if self.action_dim != 16 or self.state_dim != 16:
            raise ValueError(
                f"expected 16-dim action/state, got {self.action_dim}/{self.state_dim}"
            )

        self.image_keys: List[str] = list(params["image_keys"])
        if len(self.image_keys) != 3:
            raise ValueError(f"expected 3 cameras, got {self.image_keys}")

        self.num_video_frames = int(common["num_video_frames"])
        self.video_action_freq_ratio = int(common["video_action_freq_ratio"])
        self.action_chunk_size = self.num_video_frames * self.video_action_freq_ratio
        self._global_downsample_rate = int(common.get("global_downsample_rate", 1))
        self.video_size = [int(common["video_height"]), int(common["video_width"])]
        self.t5_text_len = int(params.get("t5_text_len", 512))
        self._config_t5_folder = str(params.get("t5_folder_name", "t5_cache"))

    def _log_time_base(self) -> None:
        chunk_s = self.action_chunk_size * self.action_interp_factor / 30.0
        if self.action_interp_factor == self._global_downsample_rate:
            logger.info(
                "Motus action_interp_factor=%d (matches global_downsample_rate): "
                "%d actions -> %d steps, %.2f s at 30 Hz",
                self.action_interp_factor, self.action_chunk_size,
                self.action_chunk_size * self.action_interp_factor, chunk_s,
            )
        else:
            logger.warning(
                "Motus action_interp_factor=%d != global_downsample_rate=%d: the chunk "
                "spans %.2f s of demonstrated motion but will be executed as %d steps "
                "(%.2f s at 30 Hz), i.e. %.2fx the demonstrated speed.",
                self.action_interp_factor, self._global_downsample_rate,
                self.action_chunk_size * self._global_downsample_rate / 30.0,
                self.action_chunk_size * self.action_interp_factor, chunk_s,
                self._global_downsample_rate / max(1, self.action_interp_factor),
            )

    # ----------------------------------------------------------------- model

    def _load_model(self, wan_path: str, vlm_path: str) -> Motus:
        """Build the network from the training config and load the weights.

        Mirrors ``server_franka_multitask.py::create_model``:
        ``load_pretrained_backbones=False`` because the trained checkpoint
        carries the WAN and VLM weights, so re-reading the pretrained shards
        would be ~30 GB of wasted I/O before being overwritten.
        """
        model_cfg = copy.deepcopy(self.config_dict["model"])
        common = self.config_dict["common"]

        wan_dir = Path(wan_path).expanduser().resolve()
        if wan_dir.name != "Wan2.2-TI2V-5B" and (wan_dir / "Wan2.2-TI2V-5B").is_dir():
            wan_dir = wan_dir / "Wan2.2-TI2V-5B"
        vae = wan_dir / "Wan2.2_VAE.pth"
        if not vae.is_file():
            raise FileNotFoundError(
                f"Wan2.2_VAE.pth not found under {wan_dir}. Motus encodes the "
                "observation with the Wan2.2 VAE, so the file has to be present; it is "
                "the same one the MotusV2 deployment already uses."
            )
        vlm_dir = Path(vlm_path).expanduser().resolve()
        if not vlm_dir.is_dir():
            raise FileNotFoundError(f"VLM directory not found: {vlm_dir}")

        und = model_cfg.get("und_expert", {}) or {}
        motus_config = MotusConfig(
            wan_checkpoint_path=str(wan_dir),
            vae_path=str(vae),
            wan_config_path=str(wan_dir),
            video_precision=model_cfg["wan"].get("precision", "bfloat16"),
            vlm_checkpoint_path=str(vlm_dir),
            und_expert_hidden_size=int(und.get("hidden_size", 512)),
            und_expert_ffn_dim_multiplier=int(und.get("ffn_dim_multiplier", 4)),
            und_expert_norm_eps=float(und.get("norm_eps", 1e-5)),
            vlm_adapter_input_dim=int(und.get("vlm", {}).get("input_dim", 2048)),
            vlm_adapter_projector_type=und.get("vlm", {}).get("projector_type", "mlp3x_silu"),
            num_layers=int(model_cfg.get("num_layers", 30)),
            action_state_dim=self.state_dim,
            action_dim=self.action_dim,
            action_expert_dim=int(model_cfg["action_expert"]["hidden_size"]),
            action_expert_ffn_dim_multiplier=int(
                model_cfg["action_expert"]["ffn_dim_multiplier"]
            ),
            action_expert_norm_eps=float(model_cfg["action_expert"].get("norm_eps", 1e-6)),
            global_downsample_rate=self._global_downsample_rate,
            video_action_freq_ratio=self.video_action_freq_ratio,
            num_video_frames=self.num_video_frames,
            video_height=self.video_size[0],
            video_width=self.video_size[1],
            batch_size=1,
            video_loss_weight=float(model_cfg["loss_weights"]["video_loss_weight"]),
            action_loss_weight=float(model_cfg["loss_weights"]["action_loss_weight"]),
            training_mode=str(self.config_dict.get("training_mode", "finetune")),
            load_pretrained_backbones=False,
        )
        if motus_config.action_chunk_size != self.action_chunk_size:
            raise RuntimeError(
                f"chunk mismatch: config says {self.action_chunk_size}, MotusConfig "
                f"derived {motus_config.action_chunk_size}"
            )

        t0 = time.perf_counter()
        logger.info("Building Motus (%s, chunk=%d)...",
                    motus_config.video_precision, motus_config.action_chunk_size)
        model = Motus(motus_config)
        t_build = time.perf_counter() - t0

        ckpt = _resolve_checkpoint_file(self.checkpoint_path)
        t0 = time.perf_counter()
        logger.info("Loading trained checkpoint: %s", ckpt)
        model.load_checkpoint(str(ckpt), strict=not self.allow_checkpoint_mismatch)
        t_load = time.perf_counter() - t0

        model = model.to(self.device).eval()
        for param in model.parameters():
            param.requires_grad_(False)
        logger.info("Motus ready | build %.1f s | weights %.1f s | vae_decode=%s",
                    t_build, t_load, "on" if self.decode_video else "skipped")
        return model

    # ------------------------------------------------------------------ text

    def _t5_cache_path(self, instruction: str) -> Path:
        """Where the T5 embedding for this instruction lives.

        ``sha1`` of the BARE instruction, matching
        ``RealRobotMotusDataset._t5_instruction_hash_path``. This is the same
        scheme MotusV2 uses, so an existing MotusV2 cache directory serves the
        same instruction without copying anything.
        """
        digest = hashlib.sha1(instruction.encode("utf-8")).hexdigest()
        return Path(self.t5_cache_dir).expanduser() / f"{digest}.pt"

    def set_instruction(self, instruction: str) -> None:
        """Bind the instruction and load its cached T5 embedding now.

        Failing here rather than lazily is deliberate: the alternative is a
        control loop that starts, moves the arm to the initial pose, waits for
        the operator's 's', and only then discovers it has no text embedding.
        """
        self.current_instruction = instruction
        if not self.t5_cache_dir:
            raise ValueError(
                "t5_cache_dir is empty. Motus needs a precomputed UMT5 embedding for the "
                "instruction; point --t5_cache_dir at the directory holding "
                "<sha1(instruction)>.pt (the MotusV2 deployment's cache works, same scheme)."
            )
        path = self._t5_cache_path(instruction)
        if not path.exists():
            available = sorted(p.name for p in path.parent.glob("*.pt")) \
                if path.parent.exists() else []
            raise FileNotFoundError(
                f"no cached T5 embedding for instruction {instruction!r}.\n"
                f"  expected : {path}\n"
                f"  cache dir: {path.parent} ({len(available)} file(s): {available[:8]})\n"
                "The embedding is part of the checkpoint, not of the robot. Generate it "
                "on the training machine with\n"
                "  python scripts/precompute_t5_real_robot.py --robot-type g1d "
                "--dataset-root <dataset>\n"
                "and copy the t5_cache/ directory over, or reuse the MotusV2 cache "
                "(identical sha1(instruction) scheme)."
            )
        emb = torch.load(str(path), map_location="cpu", weights_only=True)
        if isinstance(emb, dict):  # tolerate a wrapped payload
            emb = emb.get("context", emb.get("embedding"))
        emb = emb.float()
        if emb.ndim == 3 and emb.shape[0] == 1:
            emb = emb.squeeze(0)
        if emb.ndim != 2 or emb.shape[-1] != 4096:
            raise ValueError(
                f"bad T5 embedding {path}: got {tuple(emb.shape)}, expected [<=512, 4096]"
            )
        # preprocess_t5_embeddings pads or truncates to text_len itself; keeping
        # the tensor as stored means a cache written for either length works.
        self._t5_embedding = emb
        self._t5_path = str(path)
        logger.info("Instruction %r -> %s %s", instruction, path.name, tuple(emb.shape))

    # ----------------------------------------------------------------- image

    def build_stitched_image(
        self,
        head_img: np.ndarray,
        left_wrist_img: np.ndarray,
        right_wrist_img: np.ndarray,
    ) -> torch.Tensor:
        """Replicate the training video pipeline for a single timestep.

        Calls the training functions directly rather than reimplementing them:

            concat_cameras_robotwin  head on top, the two wrists side by side
                                     below at half height and half width
                                     (480x640 x3 -> 720x640)
            resize_with_padding      aspect-preserving scale to fit 384x320,
                                     black letterbox, centred (-> 360x320 + 12px
                                     bands top and bottom)
            /255                     -> [0, 1]; inference_step maps to [-1, 1]

        Args:
            three HxWx3 uint8 RGB arrays, in config image_keys order
            [cam_left_high, cam_left_wrist, cam_right_wrist].

        Returns:
            [1, 3, 384, 320] float32 tensor in [0, 1].
        """
        arrays = []
        for key, array in zip(self.image_keys,
                              (head_img, left_wrist_img, right_wrist_img)):
            array = np.asarray(array)
            if array.ndim != 3 or array.shape[2] != 3:
                raise ValueError(f"camera {key} image must be HxWx3 RGB, got {array.shape}")
            arrays.append(array if array.dtype == np.uint8 else array.astype(np.uint8))

        stitched = concat_cameras_robotwin(arrays[0], arrays[1], arrays[2])
        resized = resize_with_padding(stitched, tuple(self.video_size))
        frame = torch.from_numpy(np.ascontiguousarray(resized))
        return frame.permute(2, 0, 1).unsqueeze(0).float() / 255.0

    # ------------------------------------------------------------ state/action

    @staticmethod
    def _to_arm_interleaved(vec: np.ndarray) -> np.ndarray:
        """Raw 16-dim [L7, R7, LG, RG] -> training [L7, LG, R7, RG].

        Delegates to the training helper so the two cannot drift; it also accepts
        the 19/23-dim mobile layouts, which the robot does not produce here.
        """
        return unify_g1d_qpos_to_16(vec)

    @staticmethod
    def _from_arm_interleaved(vec: np.ndarray) -> np.ndarray:
        """Inverse reorder: [L7, LG, R7, RG] -> [L7, R7, LG, RG]."""
        out = np.empty(16, dtype=vec.dtype)
        out[0:7] = vec[0:7]
        out[14] = vec[7]
        out[7:14] = vec[8:15]
        out[15] = vec[15]
        return out

    def observation_to_model_input(
        self,
        observation: dict,
        current_arm_q: np.ndarray,
        ee_shared_mem: dict,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Convert one G1 observation into Motus's two model inputs.

        Cameras: cam_left_high -> top, cam_left_wrist -> bottom-left,
        cam_right_wrist -> bottom-right. cam_right_high is UNUSED, matching
        training.

        State: 16-dim absolute qpos in the training [L7, LG, R7, RG] layout, raw
        radians and raw gripper opening (normalization: false).

        Returns:
            first_frame: [1, 3, H, W] in [0, 1] on device
            state:       [1, 16] float32 on device
        """
        t0 = time.perf_counter()

        def _to_uint8_hwc(img):
            if isinstance(img, torch.Tensor):
                img = img.cpu().numpy()
            if img is not None and img.dtype != np.uint8:
                img = (img * 255).astype(np.uint8) if img.max() <= 1.0 else img.astype(np.uint8)
            return img

        frames = []
        for key in self.image_keys:
            img = _to_uint8_hwc(observation.get(key))
            if img is None:
                raise ValueError(
                    f"missing {key} in the observation; Motus needs all of {self.image_keys}"
                )
            frames.append(img)
        t_convert = time.perf_counter() - t0

        t0 = time.perf_counter()
        first_frame = self.build_stitched_image(*frames)
        # The VLM sees exactly the composed frame the video branch does, matching
        # RealRobotMotusDataset (tensor_to_pil(first_frame)). Built on CPU before
        # the transfer because the processor wants a PIL image.
        self._first_frame_pil = tensor_to_pil(first_frame[0])
        first_frame = first_frame.to(self.device)
        t_stitch = time.perf_counter() - t0

        t0 = time.perf_counter()
        left_grip_val = 0.0
        right_grip_val = 0.0
        if ee_shared_mem:
            with ee_shared_mem["lock"]:
                full_state = np.array(ee_shared_mem["state"][:])
                left_grip_val = float(full_state[:self.ee_dof][0])
                right_grip_val = float(full_state[self.ee_dof:][0])

        raw_state = np.zeros(16, dtype=np.float32)
        raw_state[0:7] = current_arm_q[0:7]
        raw_state[7:14] = current_arm_q[7:14]
        raw_state[14] = left_grip_val
        raw_state[15] = right_grip_val
        state = self._to_arm_interleaved(raw_state)
        state_tensor = torch.from_numpy(np.ascontiguousarray(state)).float()
        state_tensor = state_tensor.unsqueeze(0).to(self.device)
        t_state = time.perf_counter() - t0

        self._first_frame = first_frame
        self.current_state = state_tensor
        self._last_q_meas = np.asarray(current_arm_q, dtype=np.float64)[:14].copy()

        logger.info(
            "[observation_to_model_input]\n"
            "    img_convert      : %7.1f ms\n"
            "    stitch_to_device : %7.1f ms\n"
            "    state_build      : %7.1f ms\n"
            "    %-16s : %7.1f ms",
            t_convert * 1000, t_stitch * 1000, t_state * 1000,
            "TOTAL", (t_convert + t_stitch + t_state) * 1000,
        )
        return first_frame, state_tensor

    def qpos_action_to_g1_action(self, qpos_action_16: np.ndarray) -> tuple:
        """16-dim training-layout action -> G1 control format.

        Inverse-reorder to raw [L7, R7, LG, RG], then split into the 14 arm
        joints and the two gripper scalars. No IK: the model outputs joint
        angles directly.
        """
        if qpos_action_16.shape[0] != 16:
            raise ValueError(f"expected 16-dim qpos action, got {qpos_action_16.shape[0]}")
        raw = self._from_arm_interleaved(np.asarray(qpos_action_16, dtype=np.float64))
        return np.concatenate([raw[0:7], raw[7:14]]), float(raw[14]), float(raw[15])

    # ------------------------------------------------------------- inference

    @torch.no_grad()
    def predict_action_chunk(
        self,
        first_frame: torch.Tensor,
        state: torch.Tensor,
        prev_chunk_left_over: Optional[np.ndarray] = None,
        rtc_inference_delay: Optional[int] = None,
    ) -> np.ndarray:
        """Run Motus and return the raw action chunk ``[action_chunk_size, 16]``.

        ``prev_chunk_left_over`` / ``rtc_inference_delay`` are accepted and
        ignored so the signature stays compatible with the MotusV2 adapter; this
        policy runs synchronously and does no cross-chunk guidance.

        With ``normalization: false`` the returned array is already absolute
        qpos in the training layout, so there is nothing to denormalize.
        """
        if prev_chunk_left_over is not None or rtc_inference_delay is not None:
            logger.debug("RTC arguments ignored: the Motus path is synchronous.")
        if self._t5_embedding is None:
            raise RuntimeError("call set_instruction() before predicting")
        if self._first_frame_pil is None:
            raise RuntimeError("call observation_to_model_input() before predicting")

        t0 = time.perf_counter()
        vlm_inputs = preprocess_vlm_messages(
            self.current_instruction, self._first_frame_pil, self.vlm_processor
        )
        vlm_inputs = {
            k: (v.to(self.device) if isinstance(v, torch.Tensor) else v)
            for k, v in vlm_inputs.items()
        }
        t_vlm = time.perf_counter() - t0

        t0 = time.perf_counter()
        with _NoVideoDecode(self.model, enabled=not self.decode_video):
            _, predicted_actions = self.model.inference_step(
                first_frame=first_frame,
                state=state,
                num_inference_steps=self.num_inference_steps,
                language_embeddings=[self._t5_embedding],
                vlm_inputs=[vlm_inputs],
            )
        t_forward = time.perf_counter() - t0
        self._last_predict_ms = t_forward * 1000.0
        _debug.predict(self._last_predict_ms)

        t0 = time.perf_counter()
        actions = predicted_actions
        if actions.ndim == 3:
            actions = actions[0]
        actions_np = actions.detach().to("cpu", torch.float32).numpy()
        if actions_np.shape != (self.action_chunk_size, self.action_dim):
            raise RuntimeError(
                f"unexpected action shape {actions_np.shape}; expected "
                f"({self.action_chunk_size}, {self.action_dim})"
            )
        if not np.isfinite(actions_np).all():
            raise RuntimeError("model output contains NaN or infinity")
        t_post = time.perf_counter() - t0

        total = t_vlm + t_forward + t_post
        logger.info(
            "[predict_action_chunk] steps=%d chunk=%d vae_decode=%s\n"
            "    vlm_preprocess : %7.1f ms\n"
            "    model_forward  : %7.1f ms  (%4.1f%%)\n"
            "    post_process   : %7.1f ms\n"
            "    %-14s : %7.1f ms",
            self.num_inference_steps, self.action_chunk_size,
            "on" if self.decode_video else "skipped",
            t_vlm * 1000, t_forward * 1000, 100.0 * t_forward / max(total, 1e-9),
            t_post * 1000, "TOTAL", total * 1000,
        )
        return actions_np

    def interpolate_chunk(self, actions: np.ndarray) -> np.ndarray:
        """Upsample a raw chunk ``[T, 16]`` along time to ``[T*factor, 16]``.

        Actions are absolute qpos targets, so linear interpolation in joint
        space produces valid intermediate poses. At the G1-D default factor of 1
        this is a no-op; a larger factor stretches the same trajectory over more
        wall-clock time, i.e. slower and smoother motion.
        """
        f = self.action_interp_factor
        if f <= 1:
            return actions
        T, A = actions.shape
        xp = np.arange(T, dtype=np.float64)
        xq = np.linspace(0.0, T - 1, T * f)
        out = np.empty((T * f, A), dtype=actions.dtype)
        for a in range(A):
            out[:, a] = np.interp(xq, xp, actions[:, a])
        return out

    def build_exec_queue(self, raw_actions: np.ndarray) -> list:
        """Turn a raw chunk into the executable queue.

        Entries are ``(action, None)`` pairs. The second slot carries the
        condition pose in the Cartesian MotusV2 modes; absolute qpos needs no
        such context, but the shape is kept so all three queues drain through
        the same loop code.
        """
        self._chunk_index += 1
        stats = _debug.chunk(index=self._chunk_index, actions=raw_actions,
                             q_meas=self._last_q_meas,
                             predict_ms=self._last_predict_ms)
        logger.info(
            "[chunk %d] seam |a[0]-q_meas| %.4f rad  travel %.4f rad  "
            "peak %.2f rad/s  grip L %.3f..%.3f R %.3f..%.3f",
            self._chunk_index, stats["seam_rad"], stats["travel_rad"],
            stats["peak_rad_s"], *stats["grip"]["left"], *stats["grip"]["right"],
        )

        exec_actions = self.interpolate_chunk(raw_actions)
        if self.replan_steps:
            # Truncating the queue makes the loop re-observe after
            # replan_steps ticks instead of running the full horizon.
            exec_actions = exec_actions[: self.replan_steps * self.action_interp_factor]
        return [(exec_actions[i], None) for i in range(exec_actions.shape[0])]

    def step(self, current_arm_q: np.ndarray) -> Optional[tuple]:
        """Pop the next ``(arm_action[14], left_grip, right_grip)`` off the queue.

        Returns None when the queue is empty; the caller should predict first.
        ``current_arm_q`` seeds the rate guard on the first tick of a run.
        """
        if not self.action_queue:
            return None

        entry = self.action_queue.pop(0)
        if isinstance(entry, tuple):
            entry = entry[0]
        arm_action, left_grip, right_grip = self.qpos_action_to_g1_action(entry)
        arm_action = self._guard_joint_step(arm_action, current_arm_q)

        self._step_index += 1
        _debug.step(index=self._step_index, q_cmd=arm_action, q_meas=current_arm_q,
                    joint_step=self._last_joint_step, queue=len(self.action_queue),
                    guard=self._last_guard)
        return arm_action.astype(np.float32), left_grip, right_grip

    def _guard_joint_step(self, arm_action: np.ndarray,
                          current_arm_q: np.ndarray) -> np.ndarray:
        """Rate-limit the commanded joint delta, measured against the last command.

        The model emits absolute targets, so a chunk whose first action sits far
        from the current pose asks the arm to cover that gap in one 30 Hz tick.
        Comparing against the previous COMMAND rather than the measurement is
        what keeps the limit from fighting normal servo lag: the arm always
        trails its target, and rate-limiting against the measurement would drag
        every step back toward where the arm is instead of where it is going.

        Scaling the whole delta rather than clipping per joint preserves the
        direction of travel. ``max_joint_step <= 0`` disables the guard.
        """
        seed = self._last_cmd_q
        if seed is None:
            seed = np.asarray(current_arm_q, dtype=np.float64)[:14]
        delta = float(np.abs(arm_action - seed).max())
        self._last_joint_step = delta
        self._last_guard = ""

        if self.max_joint_step > 0 and delta > self.max_joint_step:
            arm_action = seed + (arm_action - seed) * (self.max_joint_step / delta)
            self._clamp_count += 1
            self._last_guard = "joint_step"
            logger.warning(
                "[guard] commanded step %.3f rad over max_joint_step %.3f; advancing at "
                "the limit. %d clamped steps so far",
                delta, self.max_joint_step, self._clamp_count,
            )
        self._last_cmd_q = arm_action.copy()
        return arm_action

    # ------------------------------------------------------------------ misc

    @property
    def has_cached_actions(self) -> bool:
        return len(self.action_queue) > 0

    def reset(self) -> None:
        """Drop everything an episode accumulated.

        The rate guard's seed goes with it: a new episode must not inherit the
        previous one's last command, or the first action is limited against a
        pose the arm no longer holds.
        """
        self.action_queue = []
        self.current_state = None
        self._first_frame = None
        self._first_frame_pil = None
        self._last_cmd_q = None
        self._clamp_count = 0

    def debug_banner(self, frequency: float = 30.0) -> None:
        """Record the artifacts this run is bound to (no-op unless --debug_log)."""
        _debug.banner(
            checkpoint=self.checkpoint_path,
            config_path=self._config_path,
            t5_path=self._t5_path,
            instruction=self.current_instruction or "",
            chunk=self.action_chunk_size,
            interp=self.action_interp_factor,
            freq=frequency,
            inference_steps=self.num_inference_steps,
            video_size=self.video_size,
            cameras=self.image_keys,
            decode_video=self.decode_video,
            extra={
                "stitch": "robotwin T (head over 2 half-size wrists), "
                          "pad-resized to the canvas, range [0, 1]",
                "replan_steps": self.replan_steps or f"{self.action_chunk_size} (full chunk)",
                "max_joint_step": self.max_joint_step or "off",
                "reorder": str(list(G1D_REORDER_FROM_RAW)),
            },
        )

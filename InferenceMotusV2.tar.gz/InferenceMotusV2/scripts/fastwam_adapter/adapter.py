"""Bridge between the post-trained FastWAM G1-D checkpoint and the G1 eval loop.

FastWAM on G1-D is the simplest action representation this repo serves: the
model emits 16 ABSOLUTE joint targets per step under identity normalization, in
the same ``[L7, LG, R7, RG]`` interleaved layout the MotusV2 qpos path uses. No
FK, no IK, no statistics file -- a predicted action is a joint command after a
single reorder.

What is NOT shared with MotusV2 is the observation pipeline, and the difference
is silent if it is got wrong:

* Camera stitch. FastWAM trains with the RoboTwin "T" layout, which resizes
  ``cam_left_high`` to 256x320 and each wrist to 128x160 and concatenates them
  edge to edge -- 256 + 128 = 384, so the canvas is filled exactly. The MotusV2
  ``aspect`` stitch puts a 240x320 head above 120x160 wrists and pads the
  remaining 24 rows with black. Same 384x320 canvas, different picture.
* Value range. FastWAM normalizes to [-1, 1] (mean 0.5, std 0.5); MotusV2 feeds
  [0, 1].
* Text. FastWAM consumes a cached Wan2.2 UMT5 context of shape [context_len,
  4096] keyed by the sha256 of the FULL training prompt, not of the bare
  instruction, and not the MotusV2 sha1 layout.

Every step below therefore mirrors ``FastWAM/serve/franka_policy.py`` and
``RobotVideoDatasetLerobotV30._get``, which is what the checkpoint was trained
against.

Time base: the training window is ``num_frames=33`` at ``global_sample_stride=1``,
so the 32 emitted actions are consecutive 30 Hz frames and one chunk is 32
control ticks (~1.07 s). ``action_interp_factor=0`` (the default) resolves to
that stride, i.e. 1: no interpolation, which is the correct replay speed.
"""

from __future__ import annotations

import copy
import hashlib
import logging
import os
import sys
import tempfile
import time
from pathlib import Path
from typing import Any, List, Optional, Sequence, Tuple

import numpy as np
import torch
import yaml

try:
    from fastwam_adapter import debug as _debug
except ImportError:  # adapter.py imported directly rather than as a package member
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import debug as _debug  # type: ignore

logger = logging.getLogger(__name__)


# --------------------------------------------------------------------------- #
# training-time constants, copied rather than imported
# --------------------------------------------------------------------------- #
# `fastwam.datasets.lerobot.robot_video_dataset` owns DEFAULT_PROMPT upstream,
# but importing it drags in accelerate, hydra and the whole LeRobot dataset
# stack for one f-string. The value is pinned here and
# tests/test_fastwam_adapter_wiring.py asserts it against the training repo
# whenever that repo is reachable, so a drift cannot go unnoticed.
DEFAULT_PROMPT = (
    "A video recorded from a robot's point of view executing the following "
    "instruction: {task}"
)
TEXT_ENCODER_ID = "wan22ti2v5b"

# Raw robot layout [L7, R7, LG, RG] -> training layout [L7, LG, R7, RG].
# Identical to g1d_qpos.G1D_REORDER_FROM_RAW and to the MotusV2 qpos path.
_REORDER_FROM_RAW = [0, 1, 2, 3, 4, 5, 6, 14, 7, 8, 9, 10, 11, 12, 13, 15]

# RoboTwin "T" geometry, in the order the shape_meta lists the cameras.
_T_TOP_HW = (256, 320)      # cam_left_high
_T_WRIST_HW = (128, 160)    # cam_left_wrist | cam_right_wrist

# Packages the vendored FastWAM inference closure needs on top of what the
# MotusV2 deployment already installs. Checked up front because the import that
# fails otherwise names a transitive module and reads like a bug in the bundle.
_REQUIRED_MODULES = {
    "torch": "torch",
    "torchvision": "torchvision",
    "einops": "einops",
    "safetensors": "safetensors",
    "transformers": "transformers",
    "tqdm": "tqdm",
    "rich": "rich",
    "imageio": "imageio",
}


def _resolve_fastwam_src() -> str:
    """Locate the vendored FastWAM sources across layouts.

    Works for the self-contained bundle (``<bundle>/policy/FastWAM/src``) and
    for a dev box pointing straight at the training checkout. Set
    ``FASTWAM_SRC_DIR`` to override explicitly.
    """
    here = Path(__file__).resolve()
    bundle_root = here.parents[2]  # .../InferenceMotusV2
    candidates: List[Path] = []
    env = os.environ.get("FASTWAM_SRC_DIR")
    if env:
        candidates.append(Path(env))
    candidates.append(bundle_root / "policy" / "FastWAM" / "src")
    candidates.append(Path("/home/work/wenjj/FastWAM/src"))
    for c in candidates:
        if (c / "fastwam" / "models" / "wan22" / "fastwam.py").exists():
            return str(c)
    raise FileNotFoundError(
        "cannot find the FastWAM sources. Looked for fastwam/models/wan22/fastwam.py "
        f"under {[str(c) for c in candidates]}. Set FASTWAM_SRC_DIR, or re-sync the "
        "bundle with:\n"
        "  rsync -a --delete --delete-excluded --exclude '__pycache__/' "
        "--exclude 'fastwam.egg-info/' --exclude 'fastwam/datasets/lerobot/' "
        "--exclude 'fastwam/trainer.py' --exclude 'fastwam/runtime.py' "
        "<FastWAM>/src/ <bundle>/policy/FastWAM/src/"
    )


def _check_dependencies() -> None:
    import importlib.util

    missing = sorted(
        pip_name for mod, pip_name in _REQUIRED_MODULES.items()
        if importlib.util.find_spec(mod) is None
    )
    if missing:
        raise ImportError(
            "the FastWAM inference closure needs packages this environment does not "
            f"have: {missing}. Install them into the deployment env, e.g.\n"
            f"  python -m pip install {' '.join(missing)}"
        )


_FASTWAM_SRC = _resolve_fastwam_src()
if _FASTWAM_SRC not in sys.path:
    sys.path.insert(0, _FASTWAM_SRC)
_check_dependencies()

from fastwam.datasets.dataset_utils import (  # noqa: E402
    CenterCrop,
    Normalize,
    ResizeSmallestSideAspectPreserving,
)
from fastwam.models.wan22.fastwam import FastWAM  # noqa: E402

import torchvision.transforms as TVT  # noqa: E402
from torchvision.transforms import functional as transforms_F  # noqa: E402


def _mixed_precision_to_dtype(mixed_precision: str) -> torch.dtype:
    key = str(mixed_precision).strip().lower()
    if key == "no":
        return torch.float32
    if key == "fp16":
        return torch.float16
    if key == "bf16":
        return torch.bfloat16
    raise ValueError(f"unsupported mixed_precision: {mixed_precision!r}")


class _ToTensor:
    """``fastwam.datasets.lerobot.transforms.image.ToTensor``, inlined.

    Three lines, and inlining them keeps the whole LeRobot transform package out
    of the bundle. The uint8 assertion is upstream's and is kept: a camera that
    starts handing over float frames would otherwise be divided by 255 twice.
    """

    def __call__(self, x: torch.Tensor) -> torch.Tensor:
        assert x.dtype == torch.uint8, f"expected uint8 frames, got {x.dtype}"
        return x.to(torch.float32) / 255.0


def _build_camera_transforms(spec: Sequence[dict]) -> List[Any]:
    """Rebuild the processor's ``val_transforms`` from the training config.

    Reading the list rather than hardcoding it is what makes a changed training
    recipe fail here instead of silently feeding the model a differently scaled
    image. Only the two transforms the G1-D recipe uses are supported; anything
    else has to be added deliberately.
    """
    out: List[Any] = []
    for entry in spec:
        target = str(entry.get("_target_", ""))
        if target.endswith("transforms.image.ToTensor"):
            out.append(_ToTensor())
        elif target == "torchvision.transforms.Resize":
            out.append(TVT.Resize(size=list(entry["size"])))
        else:
            raise ValueError(
                f"unsupported per-camera transform {target!r} in the training config. "
                "The deployment mirrors the training image pipeline exactly, so a new "
                "transform has to be added to _build_camera_transforms first."
            )
    return out


def _prepare_wan_model_root(wan_path: str, model_id: str, cache_root: Path) -> str:
    """Expose ``wan_path`` under the two-level layout FastWAM's loader expects.

    The loader resolves weights as ``$DIFFSYNTH_MODEL_BASE_PATH/<model_id>/<file>``,
    while the robot keeps the Wan2.2 weights in one flat directory shared with
    the MotusV2 deployment. Rather than asking anyone to move ~34 GB, link the
    flat directory into the expected shape. Only the VAE is actually read at
    serving time: ``load_text_encoder=False`` skips UMT5 and
    ``skip_dit_load_from_pretrain=True`` skips the DiT shards, both of which the
    trained checkpoint overrides anyway.
    """
    env_base = os.environ.get("DIFFSYNTH_MODEL_BASE_PATH")
    if env_base and (Path(env_base) / model_id / "Wan2.2_VAE.pth").exists():
        logger.info("Wan2.2 weights from DIFFSYNTH_MODEL_BASE_PATH=%s", env_base)
        return env_base

    src = Path(wan_path).expanduser().resolve()
    if not (src / "Wan2.2_VAE.pth").exists():
        raise FileNotFoundError(
            f"Wan2.2_VAE.pth not found under wan_path={src}. FastWAM encodes the "
            "observation with the Wan2.2 VAE, so the file has to be present; it is "
            "the same one the MotusV2 deployment already uses."
        )

    try:
        cache_root.mkdir(parents=True, exist_ok=True)
    except OSError:
        # A read-only bundle is a legitimate deployment; the link only has to
        # outlive the process.
        cache_root = Path(tempfile.mkdtemp(prefix="fastwam_wan_root_"))
        logger.info("Bundle not writable; linking Wan2.2 under %s instead.", cache_root)

    link = cache_root / model_id
    link.parent.mkdir(parents=True, exist_ok=True)
    # `exists()` follows the link, so a dangling one reads as absent and would
    # then collide in symlink_to. Test the link itself.
    if link.is_symlink() or link.exists():
        if link.is_symlink() and Path(os.readlink(link)) == src:
            os.environ["DIFFSYNTH_MODEL_BASE_PATH"] = str(cache_root)
            return str(cache_root)
        link.unlink()
    link.symlink_to(src, target_is_directory=True)
    os.environ["DIFFSYNTH_MODEL_BASE_PATH"] = str(cache_root)
    logger.info("Wan2.2 weights: %s -> %s", link, src)
    return str(cache_root)


class FastWAMPolicyAdapter:
    """FastWAM G1-D policy behind the same interface the eval loop already uses.

    The public surface matches ``MotusV2PolicyAdapter`` so the two can be swapped
    without touching the control loop:

        set_instruction / debug_banner / has_cached_actions /
        observation_to_model_input / predict_action_chunk / build_exec_queue /
        step / reset / action_queue

    RTC and async double-buffering are deliberately absent. FastWAM's chunk is a
    full 32 control ticks of absolute joint targets conditioned on one
    observation, and the synchronous loop runs it to completion before
    predicting again -- one chunk in, one chunk out, with nothing spliced in
    between. That makes a bad chunk attributable to the model rather than to the
    blending.
    """

    # ---------------------------------------------------------------- config

    @staticmethod
    def resolve_action_interp_factor(action_interp_factor: int,
                                     global_sample_stride: int) -> int:
        """Pick the time-stretch factor for a predicted chunk.

        ``<= 0`` means "auto": mirror the training frame stride, which is the
        only factor that replays the chunk at the speed it was demonstrated at.
        G1-D trains at stride 1, so auto is 1 and the chunk is already one
        action per 30 Hz tick. A positive value is taken verbatim so the
        operator can deliberately run the motion slower.
        """
        if action_interp_factor > 0:
            return int(action_interp_factor)
        return max(1, int(global_sample_stride))

    def __init__(
        self,
        checkpoint_path: str,
        config_path: str,
        wan_path: str,
        t5_cache_dir: str = "",
        device: str = "cuda",
        arm_dof: int = 14,
        ee_dof: int = 1,
        instruction: str = "",
        num_inference_steps: int = 0,
        action_interp_factor: int = 0,
        replan_steps: int = 0,
        seed: Optional[int] = None,
        max_joint_step: float = 0.0,
        text_cfg_scale: float = 1.0,
        sigma_shift: Optional[float] = None,
    ):
        self.device = device
        self.checkpoint_path = str(checkpoint_path)
        self._config_path = str(config_path)
        self.arm_dof = int(arm_dof)
        self.ee_dof = int(ee_dof)
        self.current_instruction = instruction
        self.t5_cache_dir = str(t5_cache_dir)
        self.seed = seed
        self.text_cfg_scale = float(text_cfg_scale)
        self.sigma_shift = sigma_shift
        self.max_joint_step = float(max_joint_step)

        with open(config_path, "r", encoding="utf-8") as f:
            self.config_dict = yaml.safe_load(f)

        self._read_data_contract()

        self._override_steps = (
            int(num_inference_steps) if num_inference_steps and num_inference_steps > 0 else None
        )
        self.num_inference_steps = (
            self._override_steps
            if self._override_steps
            else int(self.config_dict.get("eval_num_inference_steps", 10))
        )

        self.action_interp_factor = self.resolve_action_interp_factor(
            int(action_interp_factor), self._global_sample_stride
        )
        self._log_time_base()

        # 0 = run the whole chunk open loop, which is the horizon the model was
        # trained to plan over. A smaller value re-observes sooner at the cost of
        # one inference pause per replan; the synchronous loop has no way to hide
        # that pause, so shortening it is a deliberate reactivity/continuity trade.
        self.replan_steps = int(replan_steps) if replan_steps and replan_steps > 0 else 0

        self.model_dtype = _mixed_precision_to_dtype(
            self.config_dict.get("mixed_precision", "bf16")
        )
        self._init_runtime_state()
        # Before the model load, not after: a mistyped instruction or an
        # uncopied cache directory should fail in a second rather than after
        # thirty of building a 5B network, and long before the arm is live.
        self.set_instruction(instruction)
        self.model = self._load_model(wan_path)

        logger.info("FastWAMPolicyAdapter initialized (G1-D qpos, %d-action chunks)",
                    self.action_horizon)

    def _init_runtime_state(self) -> None:
        """Everything an episode mutates, separated from the model load.

        Kept apart so the wiring tests can exercise the observation and action
        paths on a bare instance without materialising 5B parameters.
        """
        self.action_queue: List[Tuple[np.ndarray, None]] = []
        self.current_state: Optional[torch.Tensor] = None
        self._first_frame: Optional[torch.Tensor] = None
        self._last_cmd_q: Optional[np.ndarray] = None
        self._chunk_index = -1
        self._step_index = 0
        self._clamp_count = 0
        self._last_predict_ms = 0.0
        self._last_joint_step = 0.0
        self._last_guard = ""
        self._last_q_meas = np.zeros(14, dtype=np.float64)
        self._context: Optional[torch.Tensor] = None
        self._context_mask: Optional[torch.Tensor] = None
        self._context_path = ""
        self.checkpoint_step = -1

    def _read_data_contract(self) -> None:
        """Pull the serving contract out of the training config and check it.

        Everything here is a property of the checkpoint, so reading it rather
        than hardcoding it is what lets one adapter serve a retrained model. The
        assertions cover the cases where a wrong value would still run and just
        produce wrong actions.
        """
        data_cfg = self.config_dict["data"]["train"]
        self.shape_meta = data_cfg["shape_meta"]
        proc = data_cfg["processor"]

        self.concat_multi_camera = str(data_cfg["concat_multi_camera"])
        if self.concat_multi_camera != "robotwin":
            raise ValueError(
                f"G1-D serving expects concat_multi_camera='robotwin', got "
                f"{self.concat_multi_camera!r}. The stitch geometry below is the "
                "RoboTwin T layout and nothing else."
            )

        self.unify_qpos = str(data_cfg.get("unify_qpos") or "")
        if self.unify_qpos != "g1d_16":
            raise ValueError(
                f"expected unify_qpos='g1d_16', got {self.unify_qpos!r}. The "
                "state/action reorder below assumes the 16-dim [L7, LG, R7, RG] layout."
            )

        self.norm_mode = str(proc["norm_default_mode"])
        if self.norm_mode != "identity":
            raise ValueError(
                f"norm_default_mode is {self.norm_mode!r}, but this adapter ships no "
                "dataset_stats.json and would feed the model unscaled state while "
                "reading unscaled actions back. Retrain with identity normalization, "
                "or add the statistics path and a LinearNormalizer here."
            )
        if proc.get("action_state_transforms") is not None:
            raise ValueError(
                "action_state_transforms is set in the training config; the actions "
                "are then not absolute qpos and cannot be commanded directly."
            )

        self.image_keys = [m["key"] for m in self.shape_meta["images"]]
        if len(self.image_keys) != 3:
            raise ValueError(f"expected 3 cameras, got {self.image_keys}")
        self.lerobot_image_keys = [m["lerobot_key"] for m in self.shape_meta["images"]]

        self.action_dim = int(proc["action_output_dim"])
        self.state_dim = int(proc["proprio_output_dim"])
        if self.action_dim != 16 or self.state_dim != 16:
            raise ValueError(
                f"expected 16-dim action/state, got {self.action_dim}/{self.state_dim}"
            )

        # num_frames covers one action per frame plus the trailing observation,
        # so the chunk is num_frames - 1 (32 for G1-D). This is exactly the
        # `action_horizon: null` default of the FastWAM serving configs.
        self.num_frames = int(data_cfg["num_frames"])
        self.action_horizon = self.num_frames - 1
        self._global_sample_stride = int(data_cfg.get("global_sample_stride", 1))
        self.video_size = list(data_cfg["video_size"])  # [H, W]
        self.context_len = int(data_cfg["context_len"])
        self._config_t5_cache_dir = str(data_cfg.get("text_embedding_cache_dir") or "")

        self._camera_transforms = _build_camera_transforms(proc["val_transforms"])
        self._resize_transform = ResizeSmallestSideAspectPreserving(
            args={"img_w": self.video_size[1], "img_h": self.video_size[0]},
        )
        self._crop_transform = CenterCrop(
            args={"img_w": self.video_size[1], "img_h": self.video_size[0]}
        )
        self._normalize_transform = Normalize(args={"mean": 0.5, "std": 0.5})

    def _log_time_base(self) -> None:
        chunk_s = self.action_horizon * self.action_interp_factor / 30.0
        if self.action_interp_factor == self._global_sample_stride:
            logger.info(
                "FastWAM action_interp_factor=%d (matches global_sample_stride): "
                "%d actions -> %d steps, %.2f s at 30 Hz",
                self.action_interp_factor, self.action_horizon,
                self.action_horizon * self.action_interp_factor, chunk_s,
            )
        else:
            logger.warning(
                "FastWAM action_interp_factor=%d != global_sample_stride=%d: the chunk "
                "spans %.2f s of demonstrated motion but will be executed as %d steps "
                "(%.2f s at 30 Hz), i.e. %.2fx the demonstrated speed.",
                self.action_interp_factor, self._global_sample_stride,
                self.action_horizon * self._global_sample_stride / 30.0,
                self.action_horizon * self.action_interp_factor, chunk_s,
                self._global_sample_stride / max(1, self.action_interp_factor),
            )

    # ----------------------------------------------------------------- model

    def _load_model(self, wan_path: str) -> FastWAM:
        """Build the network from the training config and load the weights.

        ``fastwam.runtime.create_fastwam`` is the upstream entry point, but it
        imports the trainer (and therefore accelerate and deepspeed) at module
        scope, which the robot has no reason to carry. The construction below is
        that function's body with the three serving overrides applied:

          load_text_encoder=False        cached UMT5 context, no 11 GB encoder
          skip_dit_load_from_pretrain    the trained checkpoint replaces both
          action_dit_pretrained_path=None  DiT backbones wholesale
        """
        model_cfg = copy.deepcopy(self.config_dict["model"])
        cache_root = Path(__file__).resolve().parents[2] / ".wan_model_root"
        os.environ.setdefault("DIFFSYNTH_SKIP_DOWNLOAD", "true")
        _prepare_wan_model_root(wan_path, str(model_cfg["model_id"]), cache_root)

        video_dit_config = dict(model_cfg["video_dit_config"])
        action_dit_config = dict(model_cfg["action_dit_config"] or {})
        for name, cfg in (("video", video_dit_config), ("action", action_dit_config)):
            if cfg.get("use_gradient_checkpointing"):
                logger.info("Disabling %s-expert gradient checkpointing for serving.", name)
                cfg["use_gradient_checkpointing"] = False

        video_sched = model_cfg.get("video_scheduler") or {}
        action_sched = model_cfg["action_scheduler"]
        loss = model_cfg.get("loss") or {}

        t0 = time.perf_counter()
        logger.info("Building FastWAM (dtype=%s, device=%s)...", self.model_dtype, self.device)
        model = FastWAM.from_wan22_pretrained(
            device=self.device,
            torch_dtype=self.model_dtype,
            model_id=str(model_cfg["model_id"]),
            tokenizer_model_id=str(model_cfg["tokenizer_model_id"]),
            tokenizer_max_len=int(model_cfg["tokenizer_max_len"]),
            load_text_encoder=False,
            proprio_dim=int(model_cfg["proprio_dim"]),
            redirect_common_files=bool(model_cfg.get("redirect_common_files", False)),
            video_dit_config=video_dit_config,
            action_dit_config=action_dit_config,
            action_dit_pretrained_path=None,
            skip_dit_load_from_pretrain=True,
            mot_checkpoint_mixed_attn=bool(model_cfg.get("mot_checkpoint_mixed_attn", False)),
            video_train_shift=float(video_sched.get("train_shift", 5.0)),
            video_infer_shift=float(video_sched.get("infer_shift", 5.0)),
            video_num_train_timesteps=int(video_sched.get("num_train_timesteps", 1000)),
            action_train_shift=float(action_sched["train_shift"]),
            action_infer_shift=float(action_sched["infer_shift"]),
            action_num_train_timesteps=int(action_sched["num_train_timesteps"]),
            loss_lambda_video=float(loss.get("lambda_video", 1.0)),
            loss_lambda_action=float(loss.get("lambda_action", 1.0)),
        )
        t_build = time.perf_counter() - t0

        if not Path(self.checkpoint_path).is_file():
            raise FileNotFoundError(
                f"checkpoint not found: {self.checkpoint_path}. The trainer writes it to "
                "<output_dir>/checkpoints/weights/step_XXXXXX.pt; copy that file and the "
                "<output_dir>/config.yaml beside it over to the robot."
            )
        t0 = time.perf_counter()
        logger.info("Loading trained checkpoint: %s", self.checkpoint_path)
        payload = model.load_checkpoint(self.checkpoint_path)
        self.checkpoint_step = int(payload.get("step", -1)) if isinstance(payload, dict) else -1
        t_load = time.perf_counter() - t0

        model = model.to(self.device).eval()
        for param in model.parameters():
            param.requires_grad_(False)
        logger.info("FastWAM ready | step=%s | build %.1f s | weights %.1f s",
                    self.checkpoint_step, t_build, t_load)
        return model

    # ------------------------------------------------------------------ text

    def _cache_path_for_prompt(self, prompt: str) -> Path:
        """Where ``scripts/precompute_text_embeds.py`` wrote this prompt.

        The key is the sha256 of the FULL prompt, i.e. DEFAULT_PROMPT with the
        instruction substituted in -- not of the bare instruction. Hashing the
        instruction alone silently misses every file in the cache.
        """
        hashed = hashlib.sha256(prompt.encode("utf-8")).hexdigest()
        cache_dir = Path(self.t5_cache_dir or self._config_t5_cache_dir).expanduser()
        return cache_dir / f"{hashed}.t5_len{self.context_len}.{TEXT_ENCODER_ID}.pt"

    def _load_cached_context(self, path: Path) -> Tuple[torch.Tensor, torch.Tensor]:
        payload = torch.load(str(path), map_location="cpu")
        context = payload["context"]
        context_mask = payload["mask"].to(torch.bool)
        if context.ndim != 2 or context.shape[0] != self.context_len:
            raise ValueError(
                f"bad cached embedding {path}: context {tuple(context.shape)}, "
                f"expected [{self.context_len}, 4096]"
            )
        # Identical to RobotVideoDatasetLerobotV30._get: zero the padding, then
        # unmask everything. Wan2.2 attends over the full padded length.
        context = context.clone()
        context[~context_mask] = 0.0
        return context, torch.ones_like(context_mask)

    def set_instruction(self, instruction: str) -> None:
        """Bind the instruction and resolve its cached T5 context now.

        Failing here rather than lazily is deliberate: the alternative is a
        control loop that starts, moves the arm to the initial pose, waits for
        the operator's 's', and only then discovers it has no text embedding.
        """
        self.current_instruction = instruction
        prompt = DEFAULT_PROMPT.format(task=instruction)
        cache_path = self._cache_path_for_prompt(prompt)
        if not cache_path.exists():
            available = sorted(p.name for p in cache_path.parent.glob("*.pt")) \
                if cache_path.parent.exists() else []
            raise FileNotFoundError(
                f"no cached T5 embedding for instruction {instruction!r}.\n"
                f"  expected : {cache_path}\n"
                f"  cache dir: {cache_path.parent} ({len(available)} file(s): {available})\n"
                "The embedding is part of the checkpoint, not of the robot: generate it on "
                "the training machine with\n"
                "  python scripts/precompute_text_embeds.py task=g1d_mixed_uncond_3cam_384_5e-5\n"
                "and copy FastWAM/data/text_embeds_cache/g1d_mixed/ into --t5_cache_dir."
            )
        self._context, self._context_mask = self._load_cached_context(cache_path)
        self._context_path = str(cache_path)
        logger.info("Instruction %r -> %s", instruction, cache_path.name)

    # ----------------------------------------------------------------- image

    def build_stitched_image(
        self,
        head_img: np.ndarray,
        left_wrist_img: np.ndarray,
        right_wrist_img: np.ndarray,
    ) -> torch.Tensor:
        """Replicate the training video pipeline for a single timestep.

        Mirrors ``RobotVideoDatasetLerobotV30._get`` and
        ``FastWAM/serve/franka_policy.py::build_image_tensor``:

            per camera : uint8 -> [0,1] -> Resize(240, 320)
            T layout   : head 256x320 above (left wrist | right wrist) 128x160
                         -> 384x320, filled exactly, no padding
            final      : aspect resize -> center crop -> (x - 0.5) / 0.5

        Args:
            three HxWx3 uint8 RGB arrays, in shape_meta order
            [cam_left_high, cam_left_wrist, cam_right_wrist].

        Returns:
            [1, 3, 384, 320] float tensor in [-1, 1].
        """
        per_camera: List[torch.Tensor] = []
        for meta, array in zip(self.shape_meta["images"],
                               (head_img, left_wrist_img, right_wrist_img)):
            array = np.asarray(array)
            if array.ndim != 3 or array.shape[2] != 3:
                raise ValueError(
                    f"camera {meta['key']} image must be HxWx3 RGB, got {array.shape}"
                )
            if array.dtype != np.uint8:
                array = array.astype(np.uint8)

            frame = torch.from_numpy(np.ascontiguousarray(array)).permute(2, 0, 1).unsqueeze(0)
            for transform in self._camera_transforms:
                frame = transform(frame)

            expected = [1] + list(meta["shape"])
            if list(frame.shape) != expected:
                raise ValueError(
                    f"camera {meta['key']} produced {list(frame.shape)} after transforms, "
                    f"expected {expected}"
                )
            per_camera.append(frame)

        def _resize(frame: torch.Tensor, hw) -> torch.Tensor:
            return transforms_F.resize(
                frame, size=list(hw),
                interpolation=transforms_F.InterpolationMode.BILINEAR, antialias=True,
            )

        cam_top = _resize(per_camera[0], _T_TOP_HW)
        bottom = torch.cat([_resize(per_camera[1], _T_WRIST_HW),
                            _resize(per_camera[2], _T_WRIST_HW)], dim=-1)
        video = torch.cat([cam_top, bottom], dim=-2)  # [1, 3, 384, 320]

        video = self._resize_transform(video)
        video = self._crop_transform(video)
        return self._normalize_transform(video)

    # ------------------------------------------------------------ state/action

    @staticmethod
    def _to_arm_interleaved(vec: np.ndarray) -> np.ndarray:
        """Raw 16-dim [L7, R7, LG, RG] -> training [L7, LG, R7, RG].

        Matches ``g1d_qpos.G1D_REORDER_FROM_RAW``: grippers move from dims 14/15
        to dims 7/15.
        """
        return vec[_REORDER_FROM_RAW]

    @staticmethod
    def _from_arm_interleaved(vec: np.ndarray) -> np.ndarray:
        """Inverse reorder: [L7, LG, R7, RG] -> [L7, R7, LG, RG]."""
        out = np.empty(16, dtype=vec.dtype)
        out[0:7] = vec[0:7]
        out[14] = vec[7]
        out[7:14] = vec[8:15]
        out[15] = vec[15]
        return out

    def observation_to_model_input(
        self,
        observation: dict,
        current_arm_q: np.ndarray,
        ee_shared_mem: dict,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Convert one G1 observation into FastWAM's two model inputs.

        Cameras: cam_left_high -> top, cam_left_wrist -> bottom-left,
        cam_right_wrist -> bottom-right. cam_right_high is UNUSED, matching
        training.

        State: 16-dim absolute qpos in the training [L7, LG, R7, RG] layout,
        identity-normalized, i.e. raw radians and raw gripper opening.

        Returns:
            first_frame: [1, 3, H, W] in [-1, 1], on device in the model dtype
            state:       [1, 16] float32 on device
        """
        t0 = time.perf_counter()

        def _to_uint8_hwc(img):
            if isinstance(img, torch.Tensor):
                img = img.cpu().numpy()
            if img is not None and img.dtype != np.uint8:
                img = (img * 255).astype(np.uint8) if img.max() <= 1.0 else img.astype(np.uint8)
            return img

        frames = []
        for key in self.lerobot_image_keys:
            img = _to_uint8_hwc(observation.get(key))
            if img is None:
                raise ValueError(
                    f"missing {key} in the observation; FastWAM needs all of "
                    f"{self.lerobot_image_keys}"
                )
            frames.append(img)
        t_convert = time.perf_counter() - t0

        t0 = time.perf_counter()
        first_frame = self.build_stitched_image(*frames).to(
            device=self.device, dtype=self.model.torch_dtype
        )
        t_stitch = time.perf_counter() - t0

        t0 = time.perf_counter()
        left_grip_val = 0.0
        right_grip_val = 0.0
        if ee_shared_mem:
            with ee_shared_mem["lock"]:
                full_state = np.array(ee_shared_mem["state"][:])
                left_grip_val = float(full_state[:self.ee_dof][0])
                right_grip_val = float(full_state[self.ee_dof:][0])

        raw_state = np.zeros(16, dtype=np.float32)
        raw_state[0:7] = current_arm_q[0:7]
        raw_state[7:14] = current_arm_q[7:14]
        raw_state[14] = left_grip_val
        raw_state[15] = right_grip_val
        state = self._to_arm_interleaved(raw_state)
        state_tensor = torch.from_numpy(state).float().unsqueeze(0).to(self.device)
        t_state = time.perf_counter() - t0

        self._first_frame = first_frame
        self.current_state = state_tensor
        self._last_q_meas = np.asarray(current_arm_q, dtype=np.float64)[:14].copy()

        logger.info(
            "[observation_to_model_input]\n"
            "    img_convert      : %7.1f ms\n"
            "    stitch_to_device : %7.1f ms\n"
            "    state_build      : %7.1f ms\n"
            "    %-16s : %7.1f ms",
            t_convert * 1000, t_stitch * 1000, t_state * 1000,
            "TOTAL", (t_convert + t_stitch + t_state) * 1000,
        )
        return first_frame, state_tensor

    def qpos_action_to_g1_action(self, qpos_action_16: np.ndarray) -> tuple:
        """16-dim training-layout action -> G1 control format.

        Inverse-reorder to raw [L7, R7, LG, RG], then split into the 14 arm
        joints and the two gripper scalars. No IK: the model outputs joint
        angles directly.
        """
        if qpos_action_16.shape[0] != 16:
            raise ValueError(f"expected 16-dim qpos action, got {qpos_action_16.shape[0]}")
        raw = self._from_arm_interleaved(np.asarray(qpos_action_16, dtype=np.float64))
        return np.concatenate([raw[0:7], raw[7:14]]), float(raw[14]), float(raw[15])

    # ------------------------------------------------------------- inference

    @torch.no_grad()
    def predict_action_chunk(
        self,
        first_frame: torch.Tensor,
        state: torch.Tensor,
        prev_chunk_left_over: Optional[np.ndarray] = None,
        rtc_inference_delay: Optional[int] = None,
    ) -> np.ndarray:
        """Run FastWAM and return the raw action chunk ``[action_horizon, 16]``.

        ``prev_chunk_left_over`` / ``rtc_inference_delay`` are accepted and
        ignored so the signature stays compatible with the MotusV2 adapter; this
        policy runs synchronously and does no cross-chunk guidance.

        Under identity normalization the returned array is already absolute
        qpos in the training layout, so there is nothing to denormalize.
        """
        if prev_chunk_left_over is not None or rtc_inference_delay is not None:
            logger.debug("RTC arguments ignored: the FastWAM path is synchronous.")
        if self._context is None:
            raise RuntimeError("call set_instruction() before predicting")

        t0 = time.perf_counter()
        pred = self.model.infer_action(
            prompt=None,
            input_image=first_frame,
            action_horizon=self.action_horizon,
            proprio=state,
            context=self._context,
            context_mask=self._context_mask,
            negative_prompt="",
            text_cfg_scale=self.text_cfg_scale,
            num_inference_steps=self.num_inference_steps,
            sigma_shift=self.sigma_shift,
            seed=self.seed,
            rand_device="cpu",
            tiled=False,
        )
        t_forward = time.perf_counter() - t0
        self._last_predict_ms = t_forward * 1000.0
        _debug.predict(self._last_predict_ms)

        t0 = time.perf_counter()
        actions = pred["action"]
        if actions.ndim == 3:
            actions = actions[0]
        actions_np = actions.detach().to("cpu", torch.float32).numpy()
        t_post = time.perf_counter() - t0

        logger.info(
            "[predict_action_chunk] steps=%d horizon=%d\n"
            "    model_forward  : %7.1f ms  (%4.1f%%)\n"
            "    post_process   : %7.1f ms\n"
            "    %-14s : %7.1f ms",
            self.num_inference_steps, self.action_horizon,
            t_forward * 1000, 100.0 * t_forward / max(t_forward + t_post, 1e-9),
            t_post * 1000, "TOTAL", (t_forward + t_post) * 1000,
        )
        return actions_np

    def interpolate_chunk(self, actions: np.ndarray) -> np.ndarray:
        """Upsample a raw chunk ``[T, 16]`` along time to ``[T*factor, 16]``.

        Actions are absolute qpos targets, so linear interpolation in joint
        space produces valid intermediate poses. At the G1-D default factor of 1
        this is a no-op; a larger factor stretches the same trajectory over more
        wall-clock time, i.e. slower and smoother motion.
        """
        f = self.action_interp_factor
        if f <= 1:
            return actions
        T, A = actions.shape
        xp = np.arange(T, dtype=np.float64)
        xq = np.linspace(0.0, T - 1, T * f)
        out = np.empty((T * f, A), dtype=actions.dtype)
        for a in range(A):
            out[:, a] = np.interp(xq, xp, actions[:, a])
        return out

    def build_exec_queue(self, raw_actions: np.ndarray) -> list:
        """Turn a raw chunk into the executable queue.

        Entries are ``(action, None)`` pairs. The second slot carries the
        condition pose in the Cartesian MotusV2 modes; absolute qpos needs no
        such context, but the shape is kept so both queues drain through the
        same loop code.
        """
        self._chunk_index += 1
        stats = _debug.chunk(index=self._chunk_index, actions=raw_actions,
                             q_meas=self._last_q_meas,
                             predict_ms=self._last_predict_ms)
        logger.info(
            "[chunk %d] seam |a[0]-q_meas| %.4f rad  travel %.4f rad  "
            "peak %.2f rad/s  grip L %.3f..%.3f R %.3f..%.3f",
            self._chunk_index, stats["seam_rad"], stats["travel_rad"],
            stats["peak_rad_s"], *stats["grip"]["left"], *stats["grip"]["right"],
        )

        exec_actions = self.interpolate_chunk(raw_actions)
        if self.replan_steps:
            # Truncating the queue makes the loop re-observe after
            # replan_steps ticks instead of running the full horizon.
            exec_actions = exec_actions[: self.replan_steps * self.action_interp_factor]
        return [(exec_actions[i], None) for i in range(exec_actions.shape[0])]

    def step(self, current_arm_q: np.ndarray) -> Optional[tuple]:
        """Pop the next ``(arm_action[14], left_grip, right_grip)`` off the queue.

        Returns None when the queue is empty; the caller should predict first.
        ``current_arm_q`` seeds the rate guard on the first tick of a run.
        """
        if not self.action_queue:
            return None

        entry = self.action_queue.pop(0)
        if isinstance(entry, tuple):
            entry = entry[0]
        arm_action, left_grip, right_grip = self.qpos_action_to_g1_action(entry)
        arm_action = self._guard_joint_step(arm_action, current_arm_q)

        self._step_index += 1
        _debug.step(index=self._step_index, q_cmd=arm_action, q_meas=current_arm_q,
                    joint_step=self._last_joint_step, queue=len(self.action_queue),
                    guard=self._last_guard)
        return arm_action.astype(np.float32), left_grip, right_grip

    def _guard_joint_step(self, arm_action: np.ndarray,
                          current_arm_q: np.ndarray) -> np.ndarray:
        """Rate-limit the commanded joint delta, measured against the last command.

        The model emits absolute targets, so a chunk whose first action sits far
        from the current pose asks the arm to cover that gap in one 30 Hz tick.
        Comparing against the previous COMMAND rather than the measurement is
        what keeps the limit from fighting normal servo lag: the arm always
        trails its target, and rate-limiting against the measurement would drag
        every step back toward where the arm is instead of where it is going.

        Scaling the whole delta rather than clipping per joint preserves the
        direction of travel. ``max_joint_step <= 0`` disables the guard.
        """
        seed = self._last_cmd_q
        if seed is None:
            seed = np.asarray(current_arm_q, dtype=np.float64)[:14]
        delta = float(np.abs(arm_action - seed).max())
        self._last_joint_step = delta
        self._last_guard = ""

        if self.max_joint_step > 0 and delta > self.max_joint_step:
            arm_action = seed + (arm_action - seed) * (self.max_joint_step / delta)
            self._clamp_count += 1
            self._last_guard = "joint_step"
            logger.warning(
                "[guard] commanded step %.3f rad over max_joint_step %.3f; advancing at "
                "the limit. %d clamped steps so far",
                delta, self.max_joint_step, self._clamp_count,
            )
        self._last_cmd_q = arm_action.copy()
        return arm_action

    # ------------------------------------------------------------------ misc

    @property
    def has_cached_actions(self) -> bool:
        return len(self.action_queue) > 0

    def reset(self) -> None:
        """Drop everything an episode accumulated.

        The rate guard's seed goes with it: a new episode must not inherit the
        previous one's last command, or the first action is limited against a
        pose the arm no longer holds.
        """
        self.action_queue = []
        self.current_state = None
        self._first_frame = None
        self._last_cmd_q = None
        self._clamp_count = 0

    def debug_banner(self, frequency: float = 30.0) -> None:
        """Record the artifacts this run is bound to (no-op unless --debug_log)."""
        _debug.banner(
            checkpoint=self.checkpoint_path,
            config_path=self._config_path,
            t5_path=self._context_path,
            instruction=self.current_instruction or "",
            prompt=DEFAULT_PROMPT.format(task=self.current_instruction or ""),
            chunk=self.action_horizon,
            interp=self.action_interp_factor,
            freq=frequency,
            inference_steps=self.num_inference_steps,
            norm_mode=self.norm_mode,
            video_size=self.video_size,
            cameras=self.image_keys,
            checkpoint_step=self.checkpoint_step,
            extra={
                "stitch": f"robotwin T ({_T_TOP_HW[0]}x{_T_TOP_HW[1]} head over "
                          f"2x{_T_WRIST_HW[0]}x{_T_WRIST_HW[1]} wrists), range [-1, 1]",
                "replan_steps": self.replan_steps or f"{self.action_horizon} (full chunk)",
                "max_joint_step": self.max_joint_step or "off",
                "text_cfg_scale": self.text_cfg_scale,
                "dtype": str(self.model_dtype),
            },
        )

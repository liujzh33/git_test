#!/usr/bin/env bash
#
# Reproducible InferenceMotusV2 environment installer for the diagnosed
# Ubuntu 24.04 x86_64 workstation with two RTX 5090 GPUs.
#
# Design choices:
#   * Keep the already working NVIDIA 595 driver.
#   * Use the official PyTorch 2.12.1 CUDA 13.0 wheel with native sm_120.
#   * Do not install a system CUDA Toolkit: PyTorch bundles its CUDA runtime,
#     and this inference path does not compile CUDA extensions.
#   * Use Python 3.10 deliberately. Unitree's package declares <3.11 and,
#     unlike Python 3.12, CPython 3.10 has a binary CycloneDDS 0.10.2 wheel.
#     This avoids an unnecessary and fragile CycloneDDS source build.
#   * Install LeRobot and unitree_lerobot from the local Unitree checkout.
#     No GitHub access is needed (the diagnosed proxy rejects GitHub's TLS
#     chain).
#
# This script installs software only. It does not connect to the robot, load
# model weights, change the NVIDIA driver, or modify the system CUDA setup.

set -Eeuo pipefail

INSTALLER_VERSION="1.0.0"
ENV_NAME="inference_motus"
RECREATE=0
SKIP_SYSTEM_PACKAGES=0
SKIP_VERIFY=0
EXPECTED_GPUS=2
UNITREE_ROOT=""
OUTPUT_LOG=""

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
MOTUS_ROOT="$(cd -- "$SCRIPT_DIR/.." && pwd)"

usage() {
    cat <<'EOF'
Usage:
  bash install_motus_5090.sh [options]

Options:
  --unitree-root DIR       Local unitree_lerobot checkout. It must include
                           the initialized lerobot submodule.
  --motus-root DIR         InferenceMotusV2 root. Default: parent of script/.
  -n, --env-name NAME      Conda environment name. Default: inference_motus
  --expected-gpus N        Minimum visible RTX 5090 count. Default: 2
  --recreate               Remove and rebuild an existing environment.
  --skip-system-packages   Do not run apt-get (for machines already prepared).
  --skip-verify            Install without the final GPU/import/IK validation.
  -o, --output FILE        Installer log path.
  -h, --help               Show this help.

Examples:
  bash scripts/install_motus_5090.sh \
    --unitree-root /home/robo/Documents/unitree_lerobot

  bash scripts/install_motus_5090.sh \
    --unitree-root /home/robo/Documents/unitree_lerobot \
    --recreate

Run as the ordinary account that will execute Motus. Do not use sudo to launch
the script; it invokes sudo only for Ubuntu system packages.
EOF
}

die() {
    printf 'ERROR: %s\n' "$*" >&2
    exit 1
}

while (($# > 0)); do
    case "$1" in
        --unitree-root)
            (($# >= 2)) || die "$1 requires a directory"
            UNITREE_ROOT="$2"
            shift 2
            ;;
        --motus-root)
            (($# >= 2)) || die "$1 requires a directory"
            MOTUS_ROOT="$2"
            shift 2
            ;;
        -n|--env-name)
            (($# >= 2)) || die "$1 requires a name"
            ENV_NAME="$2"
            shift 2
            ;;
        --expected-gpus)
            (($# >= 2)) || die "$1 requires an integer"
            EXPECTED_GPUS="$2"
            shift 2
            ;;
        --recreate)
            RECREATE=1
            shift
            ;;
        --skip-system-packages)
            SKIP_SYSTEM_PACKAGES=1
            shift
            ;;
        --skip-verify)
            SKIP_VERIFY=1
            shift
            ;;
        -o|--output)
            (($# >= 2)) || die "$1 requires a file"
            OUTPUT_LOG="$2"
            shift 2
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            die "unknown option: $1"
            ;;
    esac
done

[[ "$ENV_NAME" =~ ^[A-Za-z0-9._-]+$ ]] ||
    die "invalid Conda environment name: $ENV_NAME"
[[ "$EXPECTED_GPUS" =~ ^[0-9]+$ ]] ||
    die "--expected-gpus must be a non-negative integer"

MOTUS_ROOT="$(cd -- "$MOTUS_ROOT" 2>/dev/null && pwd)" ||
    die "Motus root does not exist: $MOTUS_ROOT"

if [[ -z "$UNITREE_ROOT" ]]; then
    UNITREE_CANDIDATES=(
        "$MOTUS_ROOT/../unitree_lerobot"
        "$HOME/unitree_lerobot"
        "$HOME/Documents/unitree_lerobot"
    )
    for candidate in "${UNITREE_CANDIDATES[@]}"; do
        if [[ -d "$candidate/unitree_lerobot/eval_robot" ]]; then
            UNITREE_ROOT="$candidate"
            break
        fi
    done
fi
[[ -n "$UNITREE_ROOT" ]] ||
    die "unitree_lerobot was not found; pass --unitree-root"
UNITREE_ROOT="$(cd -- "$UNITREE_ROOT" 2>/dev/null && pwd)" ||
    die "unitree_lerobot root does not exist: $UNITREE_ROOT"

if [[ -z "$OUTPUT_LOG" ]]; then
    OUTPUT_LOG="$PWD/install_motus_5090_$(date '+%Y%m%d_%H%M%S').log"
elif [[ "$OUTPUT_LOG" != /* ]]; then
    OUTPUT_LOG="$PWD/$OUTPUT_LOG"
fi
[[ -d "${OUTPUT_LOG%/*}" ]] ||
    die "installer log directory does not exist: ${OUTPUT_LOG%/*}"

umask 077
: >"$OUTPUT_LOG" || die "cannot write installer log: $OUTPUT_LOG"
exec > >(tee -a "$OUTPUT_LOG") 2>&1
umask 022

CURRENT_STEP="startup"
on_error() {
    local rc=$?
    printf '\nERROR: installer failed during: %s\n' "$CURRENT_STEP" >&2
    printf 'Command: %s\n' "${BASH_COMMAND-<unknown>}" >&2
    printf 'Exit code: %d\n' "$rc" >&2
    printf 'Log: %s\n' "$OUTPUT_LOG" >&2
    printf 'Fix the reported issue, then rerun with --recreate if the Conda environment was created.\n' >&2
    exit "$rc"
}
trap on_error ERR

step() {
    CURRENT_STEP="$1"
    printf '\n\n============================================================\n'
    printf '%s\n' "$CURRENT_STEP"
    printf '============================================================\n'
}

version_ge() {
    local actual="$1"
    local minimum="$2"
    printf '%s\n%s\n' "$minimum" "$actual" | sort -C -V
}

resolve_conda() {
    if [[ -n "${CONDA_EXE-}" && -x "${CONDA_EXE-}" ]]; then
        printf '%s\n' "$CONDA_EXE"
    elif command -v conda >/dev/null 2>&1; then
        command -v conda
    else
        return 1
    fi
}

conda_env_prefix() {
    "$CONDA_BIN" env list |
        awk -v target="$ENV_NAME" '$1 == target { print $NF; exit }'
}

conda_run() {
    "$CONDA_BIN" run --no-capture-output -n "$ENV_NAME" "$@"
}

pip_install() {
    conda_run python -m pip install --disable-pip-version-check "$@"
}

printf 'Motus RTX 5090 environment installer\n'
printf 'installer_version=%s\n' "$INSTALLER_VERSION"
printf 'started_at=%s\n' "$(date --iso-8601=seconds)"
printf 'user=%s\n' "$(id -un)"
printf 'motus_root=%s\n' "$MOTUS_ROOT"
printf 'unitree_root=%s\n' "$UNITREE_ROOT"
printf 'conda_env=%s\n' "$ENV_NAME"
printf 'installer_log=%s\n' "$OUTPUT_LOG"

step "1. Preflight checks"
if [[ -n "${PYTHONPATH-}" ]]; then
    printf 'Ignoring inherited PYTHONPATH during installation: %s\n' "$PYTHONPATH"
    unset PYTHONPATH
fi
export PYTHONNOUSERSITE=1
if [[ -n "${CUDA_VISIBLE_DEVICES-}" ]]; then
    printf 'Ignoring inherited CUDA_VISIBLE_DEVICES during two-GPU validation: %s\n' \
        "$CUDA_VISIBLE_DEVICES"
    unset CUDA_VISIBLE_DEVICES
fi

((EUID != 0)) ||
    die "do not run this installer as root; run it as the intended Motus user"
[[ "$(uname -s)" == "Linux" ]] || die "Linux is required"
[[ "$(uname -m)" == "x86_64" ]] || die "x86_64 is required"
if [[ -r /etc/os-release ]]; then
    # shellcheck disable=SC1091
    source /etc/os-release
    [[ "${ID-}" == "ubuntu" ]] || die "Ubuntu is required"
    [[ "${VERSION_ID-}" == "24.04" ]] ||
        die "this installer is validated for Ubuntu 24.04, found ${VERSION_ID-unknown}"
fi

[[ -f "$MOTUS_ROOT/scripts/eval_g1_motus.py" ]] ||
    die "invalid Motus root: missing scripts/eval_g1_motus.py"
[[ -f "$MOTUS_ROOT/scripts/motusv2_adapter/adapter.py" ]] ||
    die "invalid Motus root: missing adapter.py"
[[ -d "$UNITREE_ROOT/unitree_lerobot/eval_robot" ]] ||
    die "invalid unitree_lerobot root"
[[ -f "$UNITREE_ROOT/lerobot/pyproject.toml" ]] ||
    die "the unitree_lerobot lerobot submodule is missing; initialize/copy it first"
[[ -d "$UNITREE_ROOT/lerobot/src/lerobot" ]] ||
    die "the unitree_lerobot lerobot source tree is incomplete"
[[ -f "$UNITREE_ROOT/unitree_lerobot/eval_robot/assets/g1/g1_body29_hand14.urdf" ]] ||
    die "the G1 URDF asset is missing from unitree_lerobot"
[[ -f "$MOTUS_ROOT/scripts/verify_motus_5090_env.py" ]] ||
    die "missing scripts/verify_motus_5090_env.py"

command -v nvidia-smi >/dev/null 2>&1 ||
    die "nvidia-smi is missing"
DRIVER_VERSION="$(
    nvidia-smi --query-gpu=driver_version --format=csv,noheader |
        awk 'NR == 1 { print; exit }'
)"
version_ge "$DRIVER_VERSION" "580.65.06" ||
    die "NVIDIA driver >=580.65.06 is required for PyTorch cu130; found $DRIVER_VERSION"

mapfile -t GPU_ROWS < <(
    nvidia-smi \
        --query-gpu=index,name,compute_cap,memory.total \
        --format=csv,noheader
)
printf 'driver=%s\n' "$DRIVER_VERSION"
printf 'visible_gpu_count=%d\n' "${#GPU_ROWS[@]}"
printf '%s\n' "${GPU_ROWS[@]}"
((${#GPU_ROWS[@]} >= EXPECTED_GPUS)) ||
    die "expected at least $EXPECTED_GPUS GPUs, found ${#GPU_ROWS[@]}"

for row in "${GPU_ROWS[@]}"; do
    [[ "$row" == *"RTX 5090"* ]] ||
        die "unexpected GPU in target workstation: $row"
    [[ "$row" == *", 12.0,"* ]] ||
        die "GPU does not report compute capability 12.0: $row"
done

CONDA_BIN="$(resolve_conda)" ||
    die "Conda is not available; install Miniconda/Miniforge first"
printf 'conda=%s\n' "$CONDA_BIN"
"$CONDA_BIN" --version

printf '\nThe NVIDIA driver is compatible. A separate /usr/local/cuda Toolkit is intentionally not required.\n'

step "2. Ubuntu system packages"
if ((SKIP_SYSTEM_PACKAGES == 1)); then
    printf 'Skipped by --skip-system-packages\n'
else
    command -v sudo >/dev/null 2>&1 || die "sudo is required for apt packages"
    sudo -v
    SUDO_ENV_ARGS=()
    PROXY_NAMES=(
        http_proxy https_proxy no_proxy
        HTTP_PROXY HTTPS_PROXY NO_PROXY
    )
    PRESERVED_PROXY_NAMES=()
    for name in "${PROXY_NAMES[@]}"; do
        if [[ -n "${!name-}" ]]; then
            PRESERVED_PROXY_NAMES+=("$name")
        fi
    done
    if ((${#PRESERVED_PROXY_NAMES[@]} > 0)); then
        PRESERVED_PROXY_CSV="$(
            IFS=,
            printf '%s' "${PRESERVED_PROXY_NAMES[*]}"
        )"
        SUDO_ENV_ARGS+=("--preserve-env=$PRESERVED_PROXY_CSV")
    fi

    sudo "${SUDO_ENV_ARGS[@]}" apt-get update
    sudo "${SUDO_ENV_ARGS[@]}" env DEBIAN_FRONTEND=noninteractive \
        apt-get install -y --no-install-recommends \
        build-essential \
        ca-certificates \
        cmake \
        curl \
        ffmpeg \
        git \
        git-lfs \
        libegl1 \
        libgl1 \
        libglib2.0-0 \
        libgomp1 \
        libsm6 \
        libusb-1.0-0 \
        libxcb-cursor0 \
        libxext6 \
        libxkbcommon0 \
        libxrender1 \
        ninja-build \
        pkg-config
fi

step "3. Create the clean Conda environment"
EXISTING_PREFIX="$(conda_env_prefix || true)"
if [[ -n "$EXISTING_PREFIX" ]]; then
    if ((RECREATE == 0)); then
        die "Conda environment '$ENV_NAME' already exists at $EXISTING_PREFIX; use --recreate"
    fi
    printf 'Removing existing environment: %s\n' "$EXISTING_PREFIX"
    "$CONDA_BIN" env remove -y -n "$ENV_NAME"
fi

"$CONDA_BIN" create -y \
    -n "$ENV_NAME" \
    --override-channels \
    --strict-channel-priority \
    -c conda-forge \
    "python=3.10" \
    "numpy=2.2.6" \
    "pinocchio=4.1.0" \
    "casadi=3.7.2" \
    "ffmpeg=7.1.1" \
    "setuptools<81" \
    "cmake=4.1.3" \
    "ninja=1.13.0" \
    pip \
    wheel

ENV_PREFIX="$(conda_env_prefix)"
[[ -n "$ENV_PREFIX" ]] || die "could not resolve the new Conda environment"
printf 'environment_prefix=%s\n' "$ENV_PREFIX"

step "4. Install the RTX 5090 PyTorch CUDA runtime"
pip_install --upgrade \
    "pip==26.1.2" \
    "setuptools==80.10.2" \
    "wheel==0.47.0"

pip_install \
    --index-url https://download.pytorch.org/whl/cu130 \
    "torch==2.12.1" \
    "torchvision==0.27.1"

conda_run python - <<'PY'
import torch

print(f"torch={torch.__version__}")
print(f"torch.version.cuda={torch.version.cuda}")
print(f"cuda_available={torch.cuda.is_available()}")
print(f"arch_list={torch.cuda.get_arch_list()}")
assert torch.__version__.split("+", 1)[0] == "2.12.1"
assert torch.version.cuda == "13.0"
assert torch.cuda.is_available()
assert "sm_120" in torch.cuda.get_arch_list()
for index in range(torch.cuda.device_count()):
    assert torch.cuda.get_device_capability(index) == (12, 0)
    value = torch.ones(16, device=f"cuda:{index}").sum()
    torch.cuda.synchronize(index)
    assert value.item() == 16
    print(index, torch.cuda.get_device_name(index), "tiny_kernel=ok")
PY

step "5. Install Motus and Unitree runtime dependencies"
MOTUS_PACKAGES=(
    "accelerate==1.14.0"
    "av==14.2.0"
    "datasets==4.8.5"
    "deepspeed==0.19.2"
    "diffusers==0.35.2"
    "draccus==0.10.0"
    "easydict==1.13"
    "einops==0.8.2"
    "ftfy==6.3.1"
    "gymnasium==1.3.0"
    "huggingface-hub==1.22.0"
    "imageio==2.37.3"
    "imageio-ffmpeg==0.6.0"
    "jsonlines==4.0.0"
    "logging-mp==0.2.1"
    "matplotlib>=3.9,<3.11"
    "meshcat==0.3.2"
    "numpy==2.2.6"
    "omegaconf==2.3.0"
    "opencv-python==5.0.0.93"
    "packaging==25.0"
    "peft==0.19.1"
    "Pillow==12.2.0"
    "psutil==7.2.2"
    "pyarrow==24.0.0"
    "pydantic==2.13.4"
    "pyserial==3.5"
    "PyYAML==6.0.3"
    "pyzmq==27.1.0"
    "qwen-vl-utils==0.0.14"
    "regex==2026.6.28"
    "requests==2.34.2"
    "rich==15.0.0"
    "safetensors==0.8.0"
    "tokenizers==0.22.2"
    "tqdm==4.68.3"
    "transformers==5.5.4"
    "tyro==1.0.15"
)

# DeepSpeed installs in JIT mode. Motus only imports its communication helper;
# no DeepSpeed CUDA op is used by this inference path.
conda_run env DS_BUILD_OPS=0 python -m pip install \
    --disable-pip-version-check \
    "${MOTUS_PACKAGES[@]}"

# CPython 3.10 selects the bundled manylinux wheel. Requiring a wheel here is
# intentional: source-building 0.10.2 on Python 3.12 would require the exact
# CycloneDDS 0.10.2 C source and internal headers.
pip_install \
    --only-binary=:all: \
    "cyclonedds==0.10.2"
pip_install --no-deps "unitree-sdk2py==1.0.1"

step "6. Register the local LeRobot and Unitree source trees"
# --no-deps is deliberate. These source trees have historical upper bounds on
# torch/transformers, while this deployment uses the newer versions already
# validated on Thor. The runtime dependencies were installed explicitly above.
pip_install --no-deps --editable "$UNITREE_ROOT/lerobot"
pip_install --no-deps --editable "$UNITREE_ROOT"

step "7. Add Conda activation hooks"
ACTIVATE_DIR="$ENV_PREFIX/etc/conda/activate.d"
DEACTIVATE_DIR="$ENV_PREFIX/etc/conda/deactivate.d"
mkdir -p "$ACTIVATE_DIR" "$DEACTIVATE_DIR"

{
    printf '%s\n' '# Generated by install_motus_5090.sh'
    printf '%s\n' 'export _MOTUS_PREV_PYTHONPATH="${PYTHONPATH-}"'
    printf '%s\n' 'export _MOTUS_PREV_PYTHONNOUSERSITE="${PYTHONNOUSERSITE-}"'
    printf 'export MOTUS_ROOT=%q\n' "$MOTUS_ROOT"
    printf 'export UNITREE_LEROBOT_ROOT=%q\n' "$UNITREE_ROOT"
    printf 'export MOTUS_POLICY_DIR=%q\n' \
        "$MOTUS_ROOT/policy/MotusWanVlmDirectMaskMotion"
    printf 'export PYTHONPATH=%q:%q:%q${PYTHONPATH:+:$PYTHONPATH}\n' \
        "$UNITREE_ROOT" \
        "$UNITREE_ROOT/lerobot/src" \
        "$MOTUS_ROOT/scripts"
    printf '%s\n' 'export PYTHONNOUSERSITE=1'
    printf '%s\n' 'export CUDA_DEVICE_ORDER=PCI_BUS_ID'
    printf '%s\n' 'export MOTUS_COMPILE=0'
    printf '%s\n' 'export TOKENIZERS_PARALLELISM=false'
} >"$ACTIVATE_DIR/motus.sh"

cat >"$DEACTIVATE_DIR/motus.sh" <<'EOF'
# Generated by install_motus_5090.sh
export PYTHONPATH="${_MOTUS_PREV_PYTHONPATH-}"
export PYTHONNOUSERSITE="${_MOTUS_PREV_PYTHONNOUSERSITE-}"
unset _MOTUS_PREV_PYTHONPATH
unset _MOTUS_PREV_PYTHONNOUSERSITE
unset MOTUS_ROOT
unset UNITREE_LEROBOT_ROOT
unset MOTUS_POLICY_DIR
unset CUDA_DEVICE_ORDER
unset MOTUS_COMPILE
unset TOKENIZERS_PARALLELISM
EOF

step "8. Validate GPU, imports, Unitree interfaces, and local IK"
VERIFY_PYTHONPATH="$UNITREE_ROOT:$UNITREE_ROOT/lerobot/src:$MOTUS_ROOT/scripts"
if ((SKIP_VERIFY == 1)); then
    printf 'Skipped by --skip-verify\n'
else
    conda_run env \
        "PYTHONPATH=$VERIFY_PYTHONPATH" \
        "MOTUS_ROOT=$MOTUS_ROOT" \
        "UNITREE_LEROBOT_ROOT=$UNITREE_ROOT" \
        "PYTHONNOUSERSITE=1" \
        python "$MOTUS_ROOT/scripts/verify_motus_5090_env.py" \
        --motus-root "$MOTUS_ROOT" \
        --unitree-root "$UNITREE_ROOT" \
        --expected-gpus "$EXPECTED_GPUS"
fi

step "9. Save resolved package inventories"
conda_run python -m pip freeze |
    tee "$ENV_PREFIX/motus_pip_freeze.txt"
"$CONDA_BIN" list -n "$ENV_NAME" --explicit \
    >"$ENV_PREFIX/motus_conda_explicit.txt"
printf 'pip_freeze=%s\n' "$ENV_PREFIX/motus_pip_freeze.txt"
printf 'conda_explicit=%s\n' "$ENV_PREFIX/motus_conda_explicit.txt"

step "Installation complete"
printf 'finished_at=%s\n' "$(date --iso-8601=seconds)"
printf 'environment=%s\n' "$ENV_NAME"
printf 'environment_prefix=%s\n' "$ENV_PREFIX"
printf 'installer_log=%s\n' "$OUTPUT_LOG"
printf '\nActivate with:\n'
printf '  conda activate %q\n' "$ENV_NAME"
printf '\nRe-run validation with:\n'
printf '  python %q --unitree-root %q\n' \
    "$MOTUS_ROOT/scripts/verify_motus_5090_env.py" \
    "$UNITREE_ROOT"
printf '\nModel weights, dataset, T5 cache, robot network, and the path variables in\n'
printf 'scripts/inference_motusv2.sh are deployment assets/configuration and are not changed by this installer.\n'

exit 0

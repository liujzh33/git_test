"""End-to-end smoke test of the Motus adapter against the real network.

Everything the wiring test cannot reach: that the training yaml actually builds
a Motus, that the Wan2.2 VAE and the Qwen3-VL config resolve, that
``inference_step`` accepts the exact arguments the adapter passes, that the
VAE-decode skip does not disturb the action branch, and that a chunk comes back
in the shape the control loop expects.

The weights are deliberately NOT the trained ones. The checkpoint is a valid but
empty DeepSpeed payload (``{"module": {}}``, loaded with strict=False) and the
backbones are built from config, so the actions are meaningless -- the point is
the plumbing, and a wrong argument or a missing file fails here just as loudly
as it would with real weights.

Motus hardcodes ``device="cuda"`` when it builds its backbones, so pick the GPU
with CUDA_VISIBLE_DEVICES rather than an argument. Needs a free GPU (~16 GB) and
the Wan2.2 + Qwen3-VL directories; skips cleanly without them.

    CUDA_VISIBLE_DEVICES=0 python scripts/tests/test_motus_smoke_gpu.py
"""

import argparse
import hashlib
import shutil
import sys
import tempfile
import time
from pathlib import Path

import numpy as np
import torch

HERE = Path(__file__).resolve()
SCRIPTS = HERE.parents[1]
BUNDLE = HERE.parents[2]
sys.path.insert(0, str(SCRIPTS))

DEFAULT_CONFIG = BUNDLE / "configs" / "g1d_motus_pick_kettle.yaml"
WAN_CANDIDATES = [
    "/home/robo/pretrained_models/Wan2.2-TI2V-5B",
    "/home/work/wenjj/pretrained_models/Wan2.2-TI2V-5B",
    "/home/work/wenjj/FastWAM/checkpoints/Wan-AI/Wan2.2-TI2V-5B",
    "/home/work/cache/wx1469573/pretrained_models/Wan2.2-TI2V-5B",
]
VLM_CANDIDATES = [
    "/home/robo/pretrained_models/Qwen3-VL-2B-Instruct",
    "/home/work/wenjj/pretrained_models/Qwen3-VL-2B-Instruct",
    "/home/work/cache/wx1469573/pretrained_models/Qwen3-VL-2B-Instruct",
]
INSTRUCTION = "拿起水杯和茶壶，并倒水"


def _first_existing(override: str, candidates, marker: str = "") -> str:
    for c in ([override] if override else []) + list(candidates):
        if not c:
            continue
        p = Path(c)
        if (p / marker).exists() if marker else p.is_dir():
            return str(p)
    return ""


def _fake_artifacts(tmp: Path, text_len: int = 512, dim: int = 4096):
    """A structurally valid checkpoint and T5 embedding, with no information."""
    ckpt_dir = tmp / "checkpoint_step_000000" / "pytorch_model"
    ckpt_dir.mkdir(parents=True)
    torch.save({"module": {}}, ckpt_dir / "mp_rank_00_model_states.pt")

    cache_dir = tmp / "t5"
    cache_dir.mkdir()
    digest = hashlib.sha1(INSTRUCTION.encode("utf-8")).hexdigest()
    torch.save(torch.zeros(text_len, dim, dtype=torch.float32), cache_dir / f"{digest}.pt")
    return str(ckpt_dir.parent), str(cache_dir)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=str(DEFAULT_CONFIG))
    ap.add_argument("--wan-path", default="")
    ap.add_argument("--vlm-path", default="")
    ap.add_argument("--num-inference-steps", type=int, default=10)
    ap.add_argument("--decode-video", action="store_true", default=False,
                    help="Also time the VAE decode this path skips by default.")
    args = ap.parse_args()

    if not torch.cuda.is_available():
        print("smoke: no CUDA device, skipped")
        return 0
    wan_path = _first_existing(args.wan_path, WAN_CANDIDATES, "Wan2.2_VAE.pth")
    vlm_path = _first_existing(args.vlm_path, VLM_CANDIDATES, "config.json")
    if not wan_path:
        print(f"smoke: no Wan2.2_VAE.pth under {WAN_CANDIDATES}, skipped")
        return 0
    if not vlm_path:
        print(f"smoke: no Qwen3-VL under {VLM_CANDIDATES}, skipped")
        return 0

    from motus_adapter.adapter import MotusPolicyAdapter

    tmp = Path(tempfile.mkdtemp(prefix="motus_smoke_"))
    try:
        ckpt, t5_dir = _fake_artifacts(tmp)
        print(f"smoke: config={Path(args.config).name}\n"
              f"       wan={wan_path}\n       vlm={vlm_path}\n       scratch={tmp}")

        t0 = time.perf_counter()
        policy = MotusPolicyAdapter(
            checkpoint_path=ckpt,
            config_path=args.config,
            wan_path=wan_path,
            vlm_path=vlm_path,
            t5_cache_dir=t5_dir,
            device="cuda",
            instruction=INSTRUCTION,
            num_inference_steps=args.num_inference_steps,
            decode_video=args.decode_video,
            allow_checkpoint_mismatch=True,  # the payload is empty on purpose
        )
        print(f"smoke: adapter built in {time.perf_counter() - t0:.1f} s "
              f"(chunk={policy.action_chunk_size})")

        rng = np.random.default_rng(0)
        observation = {
            key: rng.integers(0, 256, (480, 640, 3), dtype=np.uint8)
            for key in policy.image_keys
        }
        current_arm_q = rng.uniform(-0.5, 0.5, 14)

        frame, state = policy.observation_to_model_input(observation, current_arm_q, {})
        assert tuple(frame.shape) == (1, 3, 384, 320), frame.shape
        assert tuple(state.shape) == (1, 16), state.shape
        assert 0.0 <= frame.min().item() and frame.max().item() <= 1.0, "expected [0, 1]"
        # normalization: false -> the state the model sees is the measurement.
        assert np.allclose(state[0, :7].cpu().numpy(), current_arm_q[:7], atol=1e-6)
        assert np.allclose(state[0, 8:15].cpu().numpy(), current_arm_q[7:14], atol=1e-6)
        print(f"smoke: obs -> frame{tuple(frame.shape)} {frame.dtype} "
              f"[{frame.min():.2f}, {frame.max():.2f}], state{tuple(state.shape)}")

        t0 = time.perf_counter()
        chunk = policy.predict_action_chunk(frame, state)
        dt = time.perf_counter() - t0
        assert chunk.shape == (policy.action_chunk_size, 16), chunk.shape
        assert np.isfinite(chunk).all(), "non-finite actions"
        print(f"smoke: chunk{chunk.shape} in {dt * 1000:.0f} ms "
              f"({args.num_inference_steps} steps, "
              f"{dt * 1000 / args.num_inference_steps:.0f} ms/step)")

        policy.action_queue = policy.build_exec_queue(chunk)
        assert len(policy.action_queue) == policy.action_chunk_size
        arm, left_grip, right_grip = policy.step(current_arm_q)
        assert arm.shape == (14,) and arm.dtype == np.float32, (arm.shape, arm.dtype)
        assert isinstance(left_grip, float) and isinstance(right_grip, float)
        print(f"smoke: step -> arm{arm.shape} {arm.dtype}, "
              f"grips ({left_grip:.3f}, {right_grip:.3f}), queue {len(policy.action_queue)}")

        t0 = time.perf_counter()
        policy.predict_action_chunk(frame, state)
        warm = time.perf_counter() - t0
        chunk_s = policy.action_chunk_size * policy.action_interp_factor / 30.0
        print(f"smoke: second inference {warm * 1000:.0f} ms warm; the chunk is "
              f"{chunk_s:.2f} s of motion, so the arm holds for "
              f"{100 * warm / chunk_s:.0f}% of a chunk between them")

        # What the default buys: the same call with the decode restored.
        if not args.decode_video:
            policy.decode_video = True
            t0 = time.perf_counter()
            policy.predict_action_chunk(frame, state)
            with_decode = time.perf_counter() - t0
            policy.decode_video = False
            print(f"smoke: with the VAE decode restored {with_decode * 1000:.0f} ms "
                  f"(+{(with_decode - warm) * 1000:.0f} ms, "
                  f"{100 * (with_decode - warm) / max(warm, 1e-9):.0f}% -- "
                  f"this is what --decode_video costs)")

        print("\nsmoke: PASS")
        return 0
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    sys.exit(main())

"""End-to-end smoke test of the FastWAM adapter against the real network.

Everything the wiring test cannot reach: that the training config actually
builds a FastWAM, that the Wan2.2 VAE resolves through the symlink shim, that
``infer_action`` accepts the exact kwargs the adapter passes, and that a chunk
comes back in the shape the control loop expects.

The weights are deliberately NOT the trained ones. The checkpoint is a valid but
empty payload (``{"mot": {}}``, which ``load_state_dict(strict=False)`` accepts)
and the DiT is randomly initialised, so the actions are meaningless -- the point
is the plumbing, and a wrong kwarg or a missing file fails here just as loudly
as it would with real weights. Only the VAE is read from disk, which is also all
the trained path reads.

Needs a free GPU (~14 GB) and the Wan2.2 weights; skips cleanly without them.

    python scripts/tests/test_fastwam_smoke_gpu.py [--device cuda:0] [--wan-path DIR]
"""

import argparse
import hashlib
import os
import shutil
import sys
import tempfile
import time
from pathlib import Path

import numpy as np
import torch

HERE = Path(__file__).resolve()
SCRIPTS = HERE.parents[1]
BUNDLE = HERE.parents[2]
sys.path.insert(0, str(SCRIPTS))

CONFIG = BUNDLE / "configs" / "g1d_fastwam_mixed.yaml"
WAN_CANDIDATES = [
    "/home/robo/pretrained_models/Wan2.2-TI2V-5B",
    "/home/work/wenjj/FastWAM/checkpoints/Wan-AI/Wan2.2-TI2V-5B",
    "/home/work/wenjj/pretrained_models/Wan2.2-TI2V-5B",
]
INSTRUCTION = "拿起水杯和茶壶，并倒水"


def _find_wan_path(override: str = "") -> str:
    for c in ([override] if override else []) + WAN_CANDIDATES:
        if c and (Path(c) / "Wan2.2_VAE.pth").exists():
            return c
    return ""


def _fake_artifacts(tmp: Path, context_len: int = 128, text_dim: int = 4096):
    """A structurally valid checkpoint and T5 embedding, with no information in them."""
    ckpt = tmp / "step_000000.pt"
    torch.save({"mot": {}, "step": 0, "torch_dtype": "torch.bfloat16"}, ckpt)

    from fastwam_adapter.adapter import DEFAULT_PROMPT, TEXT_ENCODER_ID

    cache_dir = tmp / "t5"
    cache_dir.mkdir(exist_ok=True)
    prompt = DEFAULT_PROMPT.format(task=INSTRUCTION)
    hashed = hashlib.sha256(prompt.encode("utf-8")).hexdigest()
    torch.save(
        {"context": torch.zeros(context_len, text_dim, dtype=torch.bfloat16),
         "mask": torch.ones(context_len, dtype=torch.bool)},
        cache_dir / f"{hashed}.t5_len{context_len}.{TEXT_ENCODER_ID}.pt",
    )
    return str(ckpt), str(cache_dir)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--device", default="cuda:0")
    ap.add_argument("--wan-path", default="")
    ap.add_argument("--num-inference-steps", type=int, default=10)
    args = ap.parse_args()

    if not torch.cuda.is_available():
        print("smoke: no CUDA device, skipped")
        return 0
    wan_path = _find_wan_path(args.wan_path)
    if not wan_path:
        print(f"smoke: no Wan2.2_VAE.pth under {WAN_CANDIDATES}, skipped")
        return 0

    from fastwam_adapter.adapter import FastWAMPolicyAdapter

    tmp = Path(tempfile.mkdtemp(prefix="fastwam_smoke_"))
    try:
        ckpt, t5_dir = _fake_artifacts(tmp)
        print(f"smoke: wan={wan_path}\n       device={args.device}  scratch={tmp}")

        t0 = time.perf_counter()
        policy = FastWAMPolicyAdapter(
            checkpoint_path=ckpt,
            config_path=str(CONFIG),
            wan_path=wan_path,
            t5_cache_dir=t5_dir,
            device=args.device,
            instruction=INSTRUCTION,
            num_inference_steps=args.num_inference_steps,
        )
        print(f"smoke: adapter built in {time.perf_counter() - t0:.1f} s")

        rng = np.random.default_rng(0)
        observation = {
            key: rng.integers(0, 256, (480, 640, 3), dtype=np.uint8)
            for key in policy.lerobot_image_keys
        }
        current_arm_q = rng.uniform(-0.5, 0.5, 14)

        frame, state = policy.observation_to_model_input(observation, current_arm_q, {})
        assert tuple(frame.shape) == (1, 3, 384, 320), frame.shape
        assert tuple(state.shape) == (1, 16), state.shape
        assert frame.dtype == policy.model.torch_dtype, frame.dtype
        # Identity normalization: the state the model sees is the measurement.
        assert np.allclose(state[0, :7].cpu().numpy(), current_arm_q[:7], atol=1e-6)
        assert np.allclose(state[0, 8:15].cpu().numpy(), current_arm_q[7:14], atol=1e-6)
        print(f"smoke: obs -> frame{tuple(frame.shape)} {frame.dtype} "
              f"[{frame.min():.2f}, {frame.max():.2f}], state{tuple(state.shape)}")

        t0 = time.perf_counter()
        chunk = policy.predict_action_chunk(frame, state)
        dt = time.perf_counter() - t0
        assert chunk.shape == (32, 16), chunk.shape
        assert np.isfinite(chunk).all(), "non-finite actions"
        print(f"smoke: chunk{chunk.shape} in {dt * 1000:.0f} ms "
              f"({args.num_inference_steps} steps, {dt * 1000 / args.num_inference_steps:.0f} ms/step)")

        policy.action_queue = policy.build_exec_queue(chunk)
        assert len(policy.action_queue) == 32, len(policy.action_queue)
        arm, left_grip, right_grip = policy.step(current_arm_q)
        assert arm.shape == (14,) and arm.dtype == np.float32, (arm.shape, arm.dtype)
        assert isinstance(left_grip, float) and isinstance(right_grip, float)
        print(f"smoke: step -> arm{arm.shape} {arm.dtype}, "
              f"grips ({left_grip:.3f}, {right_grip:.3f}), queue {len(policy.action_queue)}")

        # A second inference reuses the cached context and the built model, which
        # is what the control loop actually does.
        t0 = time.perf_counter()
        policy.predict_action_chunk(frame, state)
        print(f"smoke: second inference {(time.perf_counter() - t0) * 1000:.0f} ms "
              f"(warm; this is the pause the arm holds for between chunks)")

        print("\nsmoke: PASS")
        return 0
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    sys.exit(main())

"""FastWAM adapter wiring, without loading the model.

The one thing that cannot be caught by reading the code is preprocessing drift:
the adapter reimplements the training image and state pipeline outside the
dataset class, and a divergence there produces a plausible-looking but wrong
trajectory with nothing in the logs to show for it. So the centrepiece here is a
parity test that runs the SAME random observation through the adapter and
through the real training stack (FastWAMProcessor +
RobotVideoDatasetLerobotV30's T layout) and requires the tensors to match.

That half needs the training checkout, which only exists on the dev box; it
skips cleanly on the robot, where the remaining tests still cover the contract
checks, the reorder, the chunk geometry and the guards.

Instances are built with ``__new__`` so none of this needs the ~5 GB of Wan2.2
weights the real constructor loads.

    python scripts/tests/test_fastwam_adapter_wiring.py
"""

import os
import sys
from pathlib import Path

import numpy as np
import torch
import yaml

HERE = Path(__file__).resolve()
SCRIPTS = HERE.parents[1]
BUNDLE = HERE.parents[2]
sys.path.insert(0, str(SCRIPTS))

CONFIG = BUNDLE / "configs" / "g1d_fastwam_mixed.yaml"
FASTWAM_REPO = Path(os.environ.get("FASTWAM_REPO", "/home/work/wenjj/FastWAM"))
VENDORED_SRC = BUNDLE / "policy" / "FastWAM" / "src"
TRAINING_SRC = FASTWAM_REPO / "src"
# The parity tests need the dataset package, which the bundle deliberately does
# not carry. Point the adapter at the training checkout when it is reachable so
# one consistent `fastwam` serves both sides of the comparison; the bundled copy
# is checked separately, byte for byte, by test_vendored_sources_match_training.
def _training_repo_usable() -> bool:
    """The dataset package is only importable where its own deps are installed.

    Checking the directory alone is not enough: robot_video_dataset pulls in
    hydra and accelerate, which the deployment env has no reason to carry. Both
    conditions have to hold, or the parity tests report a failure that is really
    just "wrong environment".
    """
    import importlib.util

    if not (TRAINING_SRC / "fastwam" / "datasets" / "lerobot").is_dir():
        return False
    return all(importlib.util.find_spec(m) is not None
               for m in ("hydra", "omegaconf", "accelerate"))


HAVE_TRAINING_REPO = _training_repo_usable()
if HAVE_TRAINING_REPO:
    os.environ["FASTWAM_SRC_DIR"] = str(TRAINING_SRC)

from fastwam_adapter.adapter import (  # noqa: E402
    DEFAULT_PROMPT,
    TEXT_ENCODER_ID,
    FastWAMPolicyAdapter,
)


def _bare_adapter(config_path=CONFIG, **config_overrides):
    """An adapter with only the non-model half of __init__ run."""
    a = FastWAMPolicyAdapter.__new__(FastWAMPolicyAdapter)
    a.config_dict = yaml.safe_load(Path(config_path).read_text(encoding="utf-8"))
    for dotted, value in config_overrides.items():
        node = a.config_dict
        *path, leaf = dotted.split(".")
        for p in path:
            node = node[p]
        node[leaf] = value
    a.device = "cpu"
    a.ee_dof = 1
    a.arm_dof = 14
    a.t5_cache_dir = ""
    a.max_joint_step = 0.0
    a.replan_steps = 0
    a.seed = None
    a.text_cfg_scale = 1.0
    a.sigma_shift = None
    a.current_instruction = ""
    a._config_path = str(config_path)
    a._read_data_contract()
    a.action_interp_factor = a.resolve_action_interp_factor(0, a._global_sample_stride)
    a.num_inference_steps = int(a.config_dict.get("eval_num_inference_steps", 10))
    a.model_dtype = torch.float32
    a._init_runtime_state()
    return a


def _random_observation(seed=0):
    """Three 480x640 uint8 RGB frames, the raw G1-D camera format."""
    rng = np.random.default_rng(seed)
    return [rng.integers(0, 256, (480, 640, 3), dtype=np.uint8) for _ in range(3)]


# --------------------------------------------------------------------------- #
# contract
# --------------------------------------------------------------------------- #
def test_reads_the_training_contract():
    a = _bare_adapter()
    assert a.action_horizon == 32, a.action_horizon
    assert a.video_size == [384, 320], a.video_size
    assert a.norm_mode == "identity", a.norm_mode
    assert a.action_dim == a.state_dim == 16
    assert a.context_len == 128, a.context_len
    assert a.image_keys == ["cam_left_high", "cam_left_wrist", "cam_right_wrist"], a.image_keys
    assert a.action_interp_factor == 1, a.action_interp_factor
    print(f"config: {a.action_horizon} actions x interp {a.action_interp_factor} "
          f"= {a.action_horizon / 30:.2f} s @ 30 Hz, {a.norm_mode} normalization")


def test_rejects_a_mismatched_recipe():
    """Each of these would still run and just produce wrong actions."""
    cases = {
        "data.train.concat_multi_camera": "horizontal",
        "data.train.unify_qpos": "none",
        "data.train.processor.norm_default_mode": "min-max",
    }
    for dotted, bad in cases.items():
        try:
            _bare_adapter(**{dotted: bad})
        except ValueError:
            print(f"contract: rejects {dotted}={bad!r}")
        else:
            raise AssertionError(f"expected {dotted}={bad!r} to be rejected")


def test_rejects_an_unknown_camera_transform():
    """A changed image pipeline must fail here, not silently diverge."""
    try:
        _bare_adapter(**{"data.train.processor.val_transforms": [
            {"_target_": "torchvision.transforms.ColorJitter", "brightness": 0.2}]})
    except ValueError as e:
        assert "unsupported per-camera transform" in str(e), e
        print("contract: rejects an unknown per-camera transform")
        return
    raise AssertionError("expected an unknown transform to be rejected")


# --------------------------------------------------------------------------- #
# state / action layout
# --------------------------------------------------------------------------- #
def test_reorder_matches_training_and_round_trips():
    a = _bare_adapter()
    raw = np.arange(16, dtype=np.float32)          # [L7, R7, LG, RG]
    interleaved = a._to_arm_interleaved(raw)       # [L7, LG, R7, RG]

    assert np.array_equal(interleaved[0:7], raw[0:7])     # left arm
    assert interleaved[7] == raw[14]                      # left gripper
    assert np.array_equal(interleaved[8:15], raw[7:14])   # right arm
    assert interleaved[15] == raw[15]                     # right gripper
    assert np.array_equal(a._from_arm_interleaved(interleaved), raw)

    if not HAVE_TRAINING_REPO:
        print("reorder: round-trips (training repo unavailable, parity skipped)")
        return
    from fastwam.datasets.lerobot.g1d_qpos import unify_g1d_qpos_to_16

    assert np.array_equal(interleaved, unify_g1d_qpos_to_16(raw[None])[0]), \
        "the deployment reorder must equal g1d_qpos.unify_g1d_qpos_to_16"
    print("reorder: matches unify_g1d_qpos_to_16 and round-trips")


def test_action_decodes_to_the_right_slots():
    a = _bare_adapter()
    action = np.arange(16, dtype=np.float32)  # training layout
    arm, left_grip, right_grip = a.qpos_action_to_g1_action(action)
    assert arm.shape == (14,), arm.shape
    assert np.array_equal(arm[0:7], action[0:7])    # left arm
    assert np.array_equal(arm[7:14], action[8:15])  # right arm
    assert left_grip == action[7] and right_grip == action[15]
    print(f"decode: arm[14] + grips ({left_grip:.0f}, {right_grip:.0f}) from dims 7/15")


def test_prompt_constant_matches_training():
    if not HAVE_TRAINING_REPO:
        print("prompt: training repo unavailable, parity skipped")
        return
    from fastwam.datasets.lerobot.robot_video_dataset import (
        DEFAULT_PROMPT as TRAIN_PROMPT,
    )

    assert DEFAULT_PROMPT == TRAIN_PROMPT, \
        f"DEFAULT_PROMPT drifted:\n  adapter : {DEFAULT_PROMPT!r}\n  training: {TRAIN_PROMPT!r}"
    print("prompt: DEFAULT_PROMPT matches the training constant")


def test_vendored_sources_match_training():
    """The bundle carries a copy of the FastWAM inference closure; it must be one.

    The copy is what actually runs on the robot, so a hand-edit or a stale
    re-sync is a real deployment hazard and nothing else would catch it.
    """
    if not HAVE_TRAINING_REPO:
        print("vendored: training repo unavailable, comparison skipped")
        return
    import filecmp

    mismatched, missing = [], []
    for local in sorted(VENDORED_SRC.rglob("*.py")):
        rel = local.relative_to(VENDORED_SRC)
        upstream = TRAINING_SRC / rel
        if not upstream.is_file():
            missing.append(str(rel))
        elif not filecmp.cmp(local, upstream, shallow=False):
            mismatched.append(str(rel))
    assert not missing, f"vendored files with no upstream counterpart: {missing}"
    assert not mismatched, (
        f"vendored files differ from {TRAINING_SRC}: {mismatched}. Re-sync with the "
        "command in fastwam_adapter.adapter._resolve_fastwam_src."
    )
    n = len(list(VENDORED_SRC.rglob("*.py")))
    print(f"vendored: {n} files identical to {TRAINING_SRC}")


def test_t5_cache_path_is_the_sha256_of_the_full_prompt():
    """Hashing the bare instruction instead misses every file in the cache."""
    import hashlib

    a = _bare_adapter()
    a.t5_cache_dir = "/tmp/t5"
    instruction = "拿起水杯和茶壶，并倒水"
    prompt = DEFAULT_PROMPT.format(task=instruction)
    got = a._cache_path_for_prompt(prompt)
    want = hashlib.sha256(prompt.encode("utf-8")).hexdigest()
    assert got.name == f"{want}.t5_len128.{TEXT_ENCODER_ID}.pt", got.name
    assert got.name != f"{hashlib.sha256(instruction.encode()).hexdigest()}.t5_len128.{TEXT_ENCODER_ID}.pt"
    print(f"t5: {instruction!r} -> {got.name}")


def test_missing_embedding_fails_at_startup():
    """With a live arm, the first control tick is the wrong place to find out."""
    a = _bare_adapter()
    a.t5_cache_dir = "/tmp/fastwam_t5_definitely_absent"
    try:
        a.set_instruction("no embedding was ever computed for this")
    except FileNotFoundError as e:
        assert "precompute_text_embeds" in str(e), e
        print("t5: a missing embedding is a startup error naming the fix")
        return
    raise AssertionError("expected a missing embedding to raise")


# --------------------------------------------------------------------------- #
# image pipeline parity  (the point of this file)
# --------------------------------------------------------------------------- #
def test_image_pipeline_matches_training():
    """Same observation through the adapter and through the training stack.

    The training side is assembled from the real objects: FastWAMProcessor for
    the per-camera transforms, then the RoboTwin T concatenation and the final
    resize/crop/normalize exactly as RobotVideoDatasetLerobotV30._get does them.
    """
    if not HAVE_TRAINING_REPO:
        print("image parity: training repo unavailable, skipped")
        return
    from hydra.utils import instantiate
    from omegaconf import OmegaConf
    from torchvision.transforms import functional as tvF

    from fastwam.datasets.dataset_utils import (
        CenterCrop,
        Normalize,
        ResizeSmallestSideAspectPreserving,
    )

    a = _bare_adapter()
    images = _random_observation(seed=7)

    # ---- adapter -------------------------------------------------------- #
    got = a.build_stitched_image(*images)

    # ---- training ------------------------------------------------------- #
    data_cfg = OmegaConf.create(a.config_dict["data"]["train"])
    processor = instantiate(data_cfg.processor).eval()
    processor.set_normalizer_from_stats(None)  # identity

    sample = {
        "idx": 0,
        "task": "parity",
        "images": {
            meta["key"]: torch.from_numpy(np.ascontiguousarray(img)).permute(2, 0, 1)[None]
            for meta, img in zip(a.shape_meta["images"], images)
        },
        "state": {"default": torch.zeros(1, 16)},
        "action": {"default": torch.zeros(1, 16)},
        "state_is_pad": torch.zeros(1, dtype=torch.bool),
        "action_is_pad": torch.zeros(1, dtype=torch.bool),
        "image_is_pad": torch.zeros(1, dtype=torch.bool),
    }
    # num_obs_steps is 9 in training; one timestep is all serving ever has.
    processor.num_obs_steps = 1
    video = processor.preprocess(sample)["pixel_values"]  # [3, 1, C, 240, 320]

    bilinear = tvF.InterpolationMode.BILINEAR
    cam_top = tvF.resize(video[0], size=[256, 320], interpolation=bilinear, antialias=True)
    cam_left = tvF.resize(video[1], size=[128, 160], interpolation=bilinear, antialias=True)
    cam_right = tvF.resize(video[2], size=[128, 160], interpolation=bilinear, antialias=True)
    want = torch.cat([cam_top, torch.cat([cam_left, cam_right], dim=-1)], dim=-2)

    size = list(data_cfg.video_size)
    want = ResizeSmallestSideAspectPreserving(args={"img_w": size[1], "img_h": size[0]})(want)
    want = CenterCrop(args={"img_w": size[1], "img_h": size[0]})(want)
    want = Normalize(args={"mean": 0.5, "std": 0.5})(want)

    assert got.shape == want.shape == (1, 3, 384, 320), (got.shape, want.shape)
    err = (got - want).abs().max().item()
    assert err == 0.0, f"image pipeline diverged from training by {err}"
    assert -1.0 <= got.min().item() and got.max().item() <= 1.0, "expected [-1, 1]"
    print(f"image parity: exact match, {tuple(got.shape)} in "
          f"[{got.min():.2f}, {got.max():.2f}]")


def test_stitch_puts_each_camera_in_the_right_region():
    """Which camera lands where, probed with three flat colours.

    The RoboTwin T layout is 256x320 head over 128x160 + 128x160 wrists:
    256 + 128 = 384 and 160 + 160 = 320, so the canvas is filled exactly. The
    MotusV2 'aspect' stitch puts a 240x320 head over 120x160 wrists and pads the
    remaining 24 rows black. Same resolution, different picture -- serving a
    FastWAM checkpoint through the MotusV2 stitch is a silent failure, so the
    regions are asserted rather than eyeballed.
    """
    a = _bare_adapter()
    red, green, blue = (np.zeros((480, 640, 3), np.uint8) for _ in range(3))
    red[..., 0], green[..., 1], blue[..., 2] = 255, 255, 255

    frame = a.build_stitched_image(red, green, blue)[0]  # [3, 384, 320] in [-1, 1]
    assert frame.shape == (3, 384, 320), frame.shape

    def dominant(region):
        return int(region.mean(dim=(1, 2)).argmax())

    # Sampled inside each region so the bilinear seam rows are not counted.
    assert dominant(frame[:, 4:250, :]) == 0, "cam_left_high must occupy the top 256 rows"
    assert dominant(frame[:, 262:380, :158]) == 1, "cam_left_wrist must be bottom-left"
    assert dominant(frame[:, 262:380, 162:]) == 2, "cam_right_wrist must be bottom-right"

    # A padded row would be flat black in every channel; none may exist.
    black = ((frame + 1.0).abs().amax(dim=0) < 1e-3).all(dim=1)
    assert not black.any(), f"padded rows at {black.nonzero().flatten().tolist()[:8]}"
    print("stitch: head -> rows 0:256, wrists -> rows 256:384 split at col 160, no padding")


# --------------------------------------------------------------------------- #
# chunk execution
# --------------------------------------------------------------------------- #
def test_exec_queue_length_and_entry_shape():
    a = _bare_adapter()
    chunk = np.zeros((32, 16), dtype=np.float32)
    queue = a.build_exec_queue(chunk)
    assert len(queue) == 32, len(queue)
    action, cond = queue[0]
    assert action.shape == (16,) and cond is None
    print(f"queue: 32 actions -> {len(queue)} exec steps, entries are (action[16], None)")


def test_replan_steps_truncates_the_queue():
    a = _bare_adapter()
    a.replan_steps = 8
    queue = a.build_exec_queue(np.zeros((32, 16), dtype=np.float32))
    assert len(queue) == 8, len(queue)
    print("queue: --replan_steps 8 -> re-observe after 8 of 32 actions")


def test_interpolation_preserves_the_endpoints():
    a = _bare_adapter()
    a.action_interp_factor = 4
    chunk = np.linspace(0, 1, 32, dtype=np.float32)[:, None] * np.ones((1, 16), np.float32)
    out = a.interpolate_chunk(chunk)
    assert out.shape == (128, 16), out.shape
    assert np.allclose(out[0], chunk[0]) and np.allclose(out[-1], chunk[-1])
    print(f"interp: x4 -> {out.shape[0]} steps, endpoints preserved")


def test_queue_drains_and_then_asks_for_a_prediction():
    a = _bare_adapter()
    a.action_queue = a.build_exec_queue(np.zeros((32, 16), dtype=np.float32))
    q = np.zeros(14)
    n = 0
    while a.has_cached_actions:
        assert a.step(q) is not None
        n += 1
    assert n == 32 and a.step(q) is None
    print("queue: drains in 32 steps, then step() returns None")


# --------------------------------------------------------------------------- #
# safety guard
# --------------------------------------------------------------------------- #
def test_joint_step_guard_scales_without_changing_direction():
    a = _bare_adapter()
    a.max_joint_step = 0.1
    a._last_cmd_q = np.zeros(14)

    action = np.zeros(16, dtype=np.float32)
    action[0] = 1.0   # left shoulder pitch: 1 rad in one 30 Hz tick
    action[1] = 0.5
    a.action_queue = [(action, None)]
    arm, _, _ = a.step(np.zeros(14))

    # step() returns float32, so the tolerance is float32 eps, not something
    # tighter: under NumPy 1.x the promotion to float64 exposes ~1.5e-9 here.
    assert abs(np.abs(arm).max() - 0.1) < 1e-6, np.abs(arm).max()
    assert abs(arm[1] / arm[0] - 0.5) < 1e-6, "the direction of travel must be preserved"
    assert a._last_guard == "joint_step"
    print(f"guard: 1.000 rad step scaled to {np.abs(arm).max():.3f} rad, direction kept")


def test_guard_is_off_by_default_and_passes_actions_through():
    a = _bare_adapter()
    action = np.zeros(16, dtype=np.float32)
    action[0] = 1.0
    a.action_queue = [(action, None)]
    arm, _, _ = a.step(np.zeros(14))
    assert arm[0] == 1.0 and a._last_guard == ""
    print("guard: off by default, actions pass through unmodified")


def test_reset_drops_the_guard_seed():
    """A new episode must not rate-limit against the previous one's last command."""
    a = _bare_adapter()
    a.max_joint_step = 0.1
    a.action_queue = [(np.ones(16, dtype=np.float32), None)]
    a.step(np.zeros(14))
    assert a._last_cmd_q is not None
    a.reset()
    assert a._last_cmd_q is None and a.action_queue == []
    print("reset: clears the queue and the guard seed")


if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    failed = 0
    for t in tests:
        try:
            t()
        except Exception as e:  # keep going: one broken contract should not hide the rest
            failed += 1
            print(f"FAIL {t.__name__}: {type(e).__name__}: {e}")
    print(f"\n{len(tests) - failed}/{len(tests)} passed")
    sys.exit(1 if failed else 0)

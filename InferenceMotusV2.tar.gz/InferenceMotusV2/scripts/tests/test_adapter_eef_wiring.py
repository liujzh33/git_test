"""Adapter wiring for the Cartesian action modes, without loading the model.

The parity and replay tests cover the math. What is left is the adapter itself:
that it reads the mode out of the training config, that the condition pose is
carried from the state build to the action decode, that the gripper dims come
out of the right slots, and that the joint-step guard actually blocks a jump.

Instances are built with ``__new__`` so none of this needs the ~20 GB of WAN and
VLM weights the real constructor loads.

    python scripts/tests/test_adapter_eef_wiring.py
"""

import sys
import types
from pathlib import Path

import numpy as np
import yaml

HERE = Path(__file__).resolve()
sys.path.insert(0, str(HERE.parents[1]))

from motusv2_adapter import eef_delta as inf  # noqa: E402
from motusv2_adapter.debug import fingerprint as dbg_fingerprint  # noqa: E402

G1D = Path("/home/work/wenjj/data/G1-D/pick-kettle-and-cup")
TRAIN_CONFIG = Path("/home/work/wenjj/MotusV2/configs/g1d_pick_kettle_wan_vlm_mask_eef_delta.yaml")


def _stub_model_stack():
    """adapter.py imports the WAN/VLM stack at module scope.

    None of it is reachable from the action-space code under test, and importing
    it for real would drag deepspeed and ~20 GB of weights onto a machine that
    otherwise needs only numpy, scipy and pinocchio. Stubbing keeps this test
    runnable anywhere, including the robot.
    """
    stubs = {
        "models.motus_wan_vlm_direct_mask": {
            "MotusWanVlmDirectMask": object, "MotusWanVlmDirectMaskConfig": object},
        "wan.modules.t5": {"T5EncoderModel": object},
        "utils.image_utils": {"resize_with_padding": lambda *a, **k: None},
        "utils.vlm_utils": {"preprocess_vlm_messages": lambda *a, **k: None},
        "qwen_vl_utils": {"process_vision_info": lambda *a, **k: None},
    }
    for name in ("models", "wan", "wan.modules", "utils", *stubs):
        sys.modules.setdefault(name, types.ModuleType(name))
    for name, attrs in stubs.items():
        for k, v in attrs.items():
            setattr(sys.modules[name], k, v)


def _bare_adapter(config_path, **overrides):
    """An adapter with only the action-space half of __init__ run."""
    _stub_model_stack()
    from motusv2_adapter.adapter import MotusV2PolicyAdapter

    a = MotusV2PolicyAdapter.__new__(MotusV2PolicyAdapter)
    a.config_dict = yaml.safe_load(Path(config_path).read_text())
    for k, v in overrides.items():
        a.config_dict["dataset"][k] = v
    a._setup_action_space(str(G1D / "meta" / "eef_stats.json"), ["/home/work/wenjj"], 0.5)
    return a


def test_reads_action_mode_from_training_config():
    a = _bare_adapter(TRAIN_CONFIG)
    assert a.action_mode == "eef_delta", a.action_mode
    assert a.kinematics is not None
    print(f"config: action_mode={a.action_mode} (normalization={a._normalization_mode})")


def test_normalization_on_uses_separate_scalers():
    """Pinned rather than read from the config, which flips between runs."""
    a = _bare_adapter(TRAIN_CONFIG, normalization=True, normalization_mode="standard")
    assert a.action_normalizer is not None and a.state_normalizer is not None
    assert a.action_normalizer is not a.state_normalizer, \
        "eef_delta must scale absolute state and delta actions differently"
    assert a._normalization_mode == "standard"
    print("config: normalization on -> separate scalers for absolute state and delta actions")


def test_qpos_config_needs_no_kinematics():
    """The qpos path must not acquire a URDF or statistics dependency."""
    a = _bare_adapter(TRAIN_CONFIG, action_mode="qpos")
    assert a.kinematics is None and a.action_normalizer is None
    print("config: qpos mode stays free of FK/IK and statistics")


def test_condition_pose_flows_into_the_decode():
    """A delta action is meaningless without the pose it was measured from, so
    decoding before a state build must fail loudly rather than silently use a
    stale or zero pose."""
    a = _bare_adapter(TRAIN_CONFIG)
    a._cond_state_abs = None
    a._ik_seed = None
    try:
        a.eef_action_to_g1_action(np.zeros(16, dtype=np.float32), np.zeros(14))
    except RuntimeError as e:
        assert "conditioned on" in str(e), e
        print("decode: refuses to run before a state build")
        return
    raise AssertionError("expected RuntimeError without a condition pose")


def test_zero_delta_holds_position():
    """The identity case: a delta of zero must decode to the current pose.

    Unitree IPOPT includes a 0.02||q||^2 home regularizer, so the joints can
    drift by a few hundredths of a radian; the TCP still has to stay put.
    """
    a = _bare_adapter(TRAIN_CONFIG)
    rng = np.random.default_rng(0)
    kin = a.kinematics
    span = kin.hi - kin.lo
    q = rng.uniform(kin.lo + 0.3 * span, kin.hi - 0.3 * span)

    a._cond_state_abs = kin.fk_state(q, 4.2, 3.9)
    a._ik_seed = None
    zero_delta = np.zeros(16)
    zero_delta[list(inf.GRIPPER_DIMS)] = [4.2, 3.9]
    normalized = _encode(a, zero_delta)

    arm, lg, rg = a.eef_action_to_g1_action(normalized, q)
    got = kin.fk_state(arm, lg, rg)
    pos = max(np.linalg.norm(got[s] - a._cond_state_abs[s]) for s in inf.XYZ_SLICES)
    assert pos < 2e-2, pos
    assert abs(lg - 4.2) < 1e-3 and abs(rg - 3.9) < 1e-3, (lg, rg)
    print(f"decode: zero delta holds TCP to {pos * 1000:.2f} mm, "
          f"grippers pass through from dims 7/15")


def _encode(a, delta):
    """Encode a physical action the way the model emits it in *this* mode.

    With normalization off the model emits physical units, so this is identity.
    Keeping the tests mode-agnostic is what lets the same assertions cover both
    settings of dataset.normalization.
    """
    return (a.action_normalizer.normalize(delta).astype(np.float32)
            if a.action_normalizer is not None else np.asarray(delta, dtype=np.float32))


def _zero_delta_normalized(a):
    """An action that asks for "stay where the chunk started", in a's own units."""
    zero = np.zeros(16)
    zero[list(inf.GRIPPER_DIMS)] = [4.0, 4.0]
    return _encode(a, zero)


def test_guard_rate_limits_a_joint_jump():
    """A target far from the seed must be approached at the guard's rate.

    Holding instead was a deadlock: the seed stayed put while the targets kept
    moving away, so every later solve tripped the same guard (see
    test_guard_does_not_deadlock).
    """
    import logging

    a = _bare_adapter(TRAIN_CONFIG)
    kin = a.kinematics
    q_a = np.zeros(14)
    q_b = np.zeros(14)
    q_b[3] = 1.5          # elbow swung well past max_joint_step
    q_b[10] = 1.5

    a._cond_state_abs = kin.fk_state(q_b, 4.0, 4.0)
    a._ik_seed = q_a.copy()
    normalized = _zero_delta_normalized(a)

    logging.disable(logging.CRITICAL)
    arm, _, _ = a.eef_action_to_g1_action(normalized, q_a)
    logging.disable(logging.NOTSET)
    moved = np.abs(arm - q_a).max()
    assert moved <= a.max_joint_step + 1e-6, f"guard let a {moved:.3f} rad step through"
    assert moved > 0.5 * a.max_joint_step, "guard froze the arm instead of advancing"
    assert np.abs(arm - q_b).max() < np.abs(q_a - q_b).max(), "advanced away from the target"
    print(f"guard: a {abs(q_b[3] - q_a[3]):.2f} rad jump is advanced at "
          f"{moved:.3f} rad <= max_joint_step {a.max_joint_step}")


def test_guard_does_not_deadlock():
    """Repeated solves must converge, not freeze.

    The seed is the previous command, so holding it while the target stays put
    reproduces the failure exactly: every step trips the guard, the seed never
    advances, and the arm never moves again.
    """
    import logging

    a = _bare_adapter(TRAIN_CONFIG)
    kin = a.kinematics
    q_a = np.zeros(14)
    q_b = np.zeros(14)
    q_b[3] = 1.5
    q_b[10] = 1.5

    a._cond_state_abs = kin.fk_state(q_b, 4.0, 4.0)
    a._ik_seed = q_a.copy()
    normalized = _zero_delta_normalized(a)

    logging.disable(logging.CRITICAL)
    prev, n = q_a.copy(), 0
    for n in range(1, 21):
        arm, _, _ = a.eef_action_to_g1_action(normalized, q_a)
        assert np.abs(arm - prev).max() <= a.max_joint_step + 1e-6, "guard breached"
        prev = np.asarray(arm, dtype=np.float64)
        got = kin.fk_state(prev, 4.0, 4.0)
        err = max(np.linalg.norm(got[s] - a._cond_state_abs[s]) for s in inf.XYZ_SLICES)
        if err < 2e-2:
            break
    logging.disable(logging.NOTSET)
    assert err < 2e-2, f"never reached the target: {err * 1000:.1f} mm after {n} steps"
    print(f"guard: reaches a {abs(q_b[3]):.2f} rad move in {n} rate-limited steps "
          f"({err * 1000:.2f} mm residual), no deadlock")


def test_condition_pose_is_bound_to_its_chunk():
    """A chunk must keep decoding against the pose it was predicted from.

    ``--async_inference`` builds the next observation, and with it the next
    condition pose, while the current chunk still has actions queued. When the
    two shared one field, the tail of the executing chunk was composed onto the
    incoming pose, displacing every remaining target by however far the arm had
    travelled since the chunk started.
    """
    from motusv2_adapter.adapter import MotusV2PolicyAdapter

    a = _bare_adapter(TRAIN_CONFIG)
    a.action_interp_factor = 1
    kin = a.kinematics

    q_chunk = np.zeros(14)              # pose the chunk was conditioned on
    q_later = np.zeros(14)
    q_later[3] = 0.6                    # where the arm has travelled mid-chunk
    q_later[10] = 0.6
    cond_chunk = kin.fk_state(q_chunk, 4.0, 4.0)
    cond_later = kin.fk_state(q_later, 4.0, 4.0)
    apart = max(np.linalg.norm(cond_later[s] - cond_chunk[s]) for s in inf.XYZ_SLICES)
    assert apart > 0.1, f"test needs the two poses far apart, got {apart:.3f} m"

    a._pending_cond_state_abs = cond_chunk.copy()
    a._cond_state_abs = None
    a._ik_seed = None
    normalized = _zero_delta_normalized(a)
    a.action_queue = MotusV2PolicyAdapter.build_exec_queue(a, np.stack([normalized] * 4))
    queued = list(a.action_queue)

    # The async loop's next state build lands here, mid-chunk. Both fields are
    # written because the pre-fix state build assigned _cond_state_abs directly;
    # step() overwrites it from the queue entry, which is the point.
    a._pending_cond_state_abs = cond_later.copy()
    a._cond_state_abs = cond_later.copy()

    for i in range(4):
        arm, _, _ = MotusV2PolicyAdapter.step(a, q_chunk)
        got = kin.fk_state(arm, 4.0, 4.0)
        drift = max(np.linalg.norm(got[s] - cond_chunk[s]) for s in inf.XYZ_SLICES)
        assert drift < 2e-2, \
            f"action {i} decoded against the incoming pose, not its own ({drift * 1000:.1f} mm)"

    assert all(isinstance(e, tuple) and e[1] is not None for e in queued), \
        "queue entries must carry the pose their chunk was conditioned on"
    print(f"chunk cond: a mid-chunk state build {apart * 1000:.0f} mm away does not "
          f"retarget the queued actions")


def test_step_dispatches_on_mode():
    from motusv2_adapter.adapter import MotusV2PolicyAdapter

    a = _bare_adapter(TRAIN_CONFIG)
    kin = a.kinematics
    q = np.zeros(14)
    a._cond_state_abs = kin.fk_state(q, 4.0, 4.0)
    a._ik_seed = None
    zero = np.zeros(16)
    zero[list(inf.GRIPPER_DIMS)] = [4.0, 4.0]
    a.action_queue = [_encode(a, zero)]

    out = MotusV2PolicyAdapter.step(a, q)
    assert out is not None and len(out) == 3
    arm, lg, rg = out
    assert arm.shape == (14,), arm.shape
    assert not a.action_queue, "step should consume the queue entry"
    print(f"step: eef_delta path returns ({arm.shape}, gripper, gripper) and drains the queue")


def test_normalization_off_consumes_raw_physical_units():
    """``dataset.normalization: false`` must round-trip with no scaling at all.

    Training's ``_load_normalizers`` returns ``(None, None)`` in this mode, so
    the dataset hands the model raw metres/radians and expects them straight
    back. The adapter has to do exactly nothing to both the state and the
    action, or every target is off by the normalizer's scale.
    """
    a = _bare_adapter(TRAIN_CONFIG, normalization=False)
    assert a.state_normalizer is None and a.action_normalizer is None
    assert a._normalization_mode == "none", a._normalization_mode
    # The statistics must still be resolved: they scale nothing here, but the
    # range checks and the fingerprint depend on them.
    assert a._range_lo is not None and a._diag_stats is not None, \
        "diagnostics lost their reference ranges when normalization was turned off"

    kin = a.kinematics
    rng = np.random.default_rng(0)
    span = kin.hi - kin.lo
    q = rng.uniform(kin.lo + 0.3 * span, kin.hi - 0.3 * span)
    cond = kin.fk_state(q, 4.2, 3.9)

    # A raw delta, in metres and radians, exactly as training would emit it.
    delta = np.zeros(16)
    delta[0:3] = [0.01, -0.02, 0.015]
    delta[3:6] = [0.05, -0.03, 0.02]
    delta[8:11] = [-0.012, 0.008, 0.02]
    delta[11:14] = [-0.04, 0.02, 0.01]
    delta[list(inf.GRIPPER_DIMS)] = [4.2, 3.9]

    a._cond_state_abs = cond
    a._ik_seed = None
    arm, lg, rg = a.eef_action_to_g1_action(delta.astype(np.float32), q)

    want = inf.from_delta(cond, delta)[0]
    got = kin.fk_state(arm, lg, rg)
    pos = max(np.linalg.norm(got[s] - want[s]) for s in inf.XYZ_SLICES)
    assert pos < 2e-2, f"raw delta was rescaled somewhere: {pos * 1000:.1f} mm off"
    assert abs(lg - 4.2) < 1e-6 and abs(rg - 3.9) < 1e-6, (lg, rg)
    print(f"no-norm: a raw delta reaches its target to {pos * 1000:.2f} mm, "
          f"grippers pass through unscaled")


def test_fingerprint_separates_all_three_modes():
    """With statistics available the fingerprint must also recognise 'none'.

    This is the check that stops a normalized checkpoint from being served as
    raw: N(0,1) output read as metres would command ~1 m offsets.
    """
    import json

    stats = json.loads((G1D / "meta" / "eef_stats.json").read_text())
    dmin = np.asarray(stats["delta_min"])
    dmax = np.asarray(stats["delta_max"])
    dmu = np.asarray(stats["delta_mean"])
    dsd = np.asarray(stats["delta_std"]).copy()
    dsd[dsd < 1e-8] = 1.0

    rng = np.random.default_rng(0)
    # Raw physical deltas with the dataset's own per-dim spread.
    raw = rng.normal(dmu, dsd, (256, 16))
    emitted = {
        "none": raw,
        "standard": (raw - dmu) / dsd,
        "minmax": (raw - dmin) / (dmax - dmin + 1e-8),
    }
    for truth, x in emitted.items():
        fp = dbg_fingerprint(x, truth, stats)
        assert fp["looks_like"] == truth, (truth, fp["looks_like"], fp["scores"])
        # And every wrong label must be rejected.
        for other in emitted:
            if other != truth:
                assert not dbg_fingerprint(x, other, stats)["agrees"], \
                    f"{truth} output accepted as {other}"
    print("fingerprint: separates none / standard / minmax and rejects every swap")


def test_reserved_dims_are_masked_for_the_sampler():
    """Dims 6/14 must be zeroed in the sampler, as they were in training.

    training_step multiplies the action encoder's input by action_valid_mask at
    every noise level, so the encoder only ever saw 0.0 there -- and because the
    loss was masked too, those weight columns never received a gradient and sit
    at their init magnitude (measured: 1.38 against 1.65 for a trained column).
    Sampling from unmasked noise therefore drives a channel the encoder has no
    trained response for, and since the predicted velocity for those dims is
    equally untrained the noise drifts instead of decaying.
    """
    import torch

    a = _bare_adapter(TRAIN_CONFIG)
    mask = a._action_valid_mask()
    assert mask is not None, "eef_delta must supply a mask"

    common = a.config_dict["common"]
    chunk = int(common["num_video_frames"]) * int(common["video_action_freq_ratio"])
    assert tuple(mask.shape) == (chunk, int(common["action_dim"])), tuple(mask.shape)

    live = [i for i in range(16) if i not in inf.RESERVED_DIMS]
    assert (mask[:, list(inf.RESERVED_DIMS)] == 0).all(), "reserved dims are not zeroed"
    assert (mask[:, live] == 1).all(), "a live dim was masked out"

    latent = torch.randn(1, chunk, 16)
    masked = latent * mask
    assert (masked[..., list(inf.RESERVED_DIMS)] == 0).all()
    assert torch.equal(masked[..., live], latent[..., live]), "masking disturbed a live dim"

    assert _bare_adapter(TRAIN_CONFIG, action_mode="qpos")._action_valid_mask() is None, \
        "qpos uses all 16 dims and must not be masked"
    print(f"sampler mask: {chunk}x16, dims {inf.RESERVED_DIMS} zeroed, "
          f"{len(live)} live dims untouched, qpos exempt")


def test_sampler_applies_the_mask_every_step():
    """The mask has to reach the denoising loop and be re-applied each step.

    Masking only the initial latent is not enough: the velocity predicted for
    the reserved dims is untrained, so they walk away from zero again.
    """
    model_src = (HERE.parents[2] / "policy" / "MotusWanVlmDirectMaskMotion" /
                 "models" / "motus_wan_vlm_direct_mask.py").read_text()
    applied = model_src.count("action_latent = action_latent * action_valid_mask")
    assert applied >= 2, (
        f"expected the sampler to mask the latent at init AND after every step, "
        f"found {applied} application(s)"
    )
    assert "action_valid_mask: Optional[torch.Tensor] = None" in model_src, \
        "inference_step no longer accepts action_valid_mask"

    adapter_src = (HERE.parents[1] / "motusv2_adapter" / "adapter.py").read_text()
    assert "action_valid_mask=self._action_valid_mask()" in adapter_src, \
        "predict_action_chunk no longer hands the mask to inference_step"
    print(f"sampler wiring: mask applied {applied}x in the denoising loop and "
          f"passed from predict_action_chunk")


def test_reset_clears_the_pending_condition_pose():
    """A staged pose from the last episode must not be attached to a new chunk."""
    from motusv2_adapter.adapter import MotusV2PolicyAdapter

    a = _bare_adapter(TRAIN_CONFIG)
    a.action_queue = []
    a.current_state = None
    a._first_frame = None
    a._cond_state_abs = np.ones(16)
    a._pending_cond_state_abs = np.ones(16)
    a._ik_seed = np.ones(14)
    MotusV2PolicyAdapter.reset(a)
    assert a._pending_cond_state_abs is None, "a staged condition pose survived reset"
    print("reset: the staged condition pose is cleared too")


def test_reset_clears_cartesian_state():
    from motusv2_adapter.adapter import MotusV2PolicyAdapter

    a = _bare_adapter(TRAIN_CONFIG)
    a.action_queue = [np.zeros(16)]
    a.current_state = object()
    a._first_frame = object()
    a._cond_state_abs = np.ones(16)
    a._ik_seed = np.ones(14)
    MotusV2PolicyAdapter.reset(a)
    assert a._cond_state_abs is None and a._ik_seed is None, \
        "a new episode must not inherit the previous arm branch"
    print("reset: condition pose and IK warm start are cleared")


if __name__ == "__main__":
    test_reads_action_mode_from_training_config()
    test_normalization_on_uses_separate_scalers()
    test_qpos_config_needs_no_kinematics()
    test_condition_pose_flows_into_the_decode()
    test_zero_delta_holds_position()
    test_guard_rate_limits_a_joint_jump()
    test_guard_does_not_deadlock()
    test_condition_pose_is_bound_to_its_chunk()
    test_normalization_off_consumes_raw_physical_units()
    test_fingerprint_separates_all_three_modes()
    test_reserved_dims_are_masked_for_the_sampler()
    test_sampler_applies_the_mask_every_step()
    test_step_dispatches_on_mode()
    test_reset_clears_cartesian_state()
    test_reset_clears_the_pending_condition_pose()
    print("\nall adapter wiring checks passed")

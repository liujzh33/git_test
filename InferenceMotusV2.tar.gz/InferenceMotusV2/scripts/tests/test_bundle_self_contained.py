"""The bundle must carry everything the Cartesian path needs.

InferenceMotusV2 is copied wholesale to the inference machine. Anything the
Cartesian action path resolves outside that directory -- the URDF, the
normalization statistics, the training config -- is a file that will simply not
be there, and the failure would surface as a policy that reaches for the wrong
place rather than as an import error.

This test copies the bundle's own assets to a scratch directory, hides every
external source, and checks the code still finds what it needs.

    python scripts/tests/test_bundle_self_contained.py
"""

import shutil
import sys
import tempfile
import types
from pathlib import Path

import numpy as np
import yaml

HERE = Path(__file__).resolve()
sys.path.insert(0, str(HERE.parents[1]))

from motusv2_adapter import eef_delta as inf  # noqa: E402

BUNDLE = inf.BUNDLE_ROOT
CONFIG = BUNDLE / "configs" / "g1d_pick_kettle_wan_vlm_mask_eef_delta.yaml"


def test_assets_are_present():
    assert inf.BUNDLED_URDF.exists(), f"missing {inf.BUNDLED_URDF}"
    assert inf.BUNDLED_STATS.exists(), f"missing {inf.BUNDLED_STATS}"
    assert CONFIG.exists(), f"missing {CONFIG}"
    sizes = {p.name: p.stat().st_size for p in (inf.BUNDLED_URDF, inf.BUNDLED_STATS, CONFIG)}
    print("assets: " + ", ".join(f"{k} {v / 1024:.1f} KB" for k, v in sizes.items()))


def test_urdf_resolves_to_the_bundle_copy():
    """Even with a usable unitree_lerobot installed, the bundled file must win,
    so every machine loads the same kinematics."""
    found = inf.find_urdf()
    assert Path(found).resolve() == inf.BUNDLED_URDF.resolve(), found
    print(f"urdf: resolves to the bundle copy ({Path(found).name})")


def test_kinematics_build_without_meshes():
    """The URDF references ~50 STL files that are deliberately not shipped."""
    meshes = inf.BUNDLED_URDF.parent / "meshes"
    assert not meshes.exists(), f"{meshes} should not be in the bundle"
    kin = inf.G1EefKinematics(str(inf.BUNDLED_URDF))
    assert list(kin.model.names[1:]) == inf.ARM_JOINTS
    q = np.zeros(14)
    poses = kin.fk_poses(q)
    assert len(poses) == 2
    print(f"kinematics: builds from the URDF alone, {kin.model.nq} arm joints, no meshes needed")


def test_stats_load_from_the_bundle():
    state, action = inf.load_normalizers(str(inf.BUNDLED_STATS), "eef_delta")
    assert state is not action
    stats = yaml.safe_load(inf.BUNDLED_STATS.read_text())
    assert stats["delta_horizon"] >= 64, "delta stats must cover the 64-step chunk"
    print(f"stats: bundled copy loads, delta_horizon={stats['delta_horizon']}")


def test_setup_runs_with_external_paths_unreachable():
    """The end-to-end packaging check: point the config's dataset paths at a
    directory that does not exist, which is what the training machine's paths
    look like from the robot, and confirm startup still succeeds."""
    from test_adapter_eef_wiring import _stub_model_stack

    _stub_model_stack()
    from motusv2_adapter.adapter import MotusV2PolicyAdapter

    cfg = yaml.safe_load(CONFIG.read_text())
    cfg["dataset"]["dataset_dir"] = "/nonexistent/training/machine/dataset"
    cfg["dataset"]["normalization_stats_path"] = "/nonexistent/training/machine/eef_stats.json"

    a = MotusV2PolicyAdapter.__new__(MotusV2PolicyAdapter)
    a.config_dict = cfg
    # No eef_stats_path and no URDF root: everything must come from the bundle.
    a._setup_action_space("", None, 0.5)

    assert a.action_mode == "eef_delta"
    assert a.kinematics is not None
    # The statistics must still resolve to the bundle copy even when the config
    # points at the training machine, in every mode: with normalization off they
    # scale nothing but still supply the ranges the diagnostics report against.
    assert a._diag_stats is not None, "fell back to no statistics at all"
    q = np.zeros(14)
    a._cond_state_abs = a.kinematics.fk_state(q, 4.0, 4.0)
    a._ik_seed = None
    zero = np.zeros(16)
    zero[list(inf.GRIPPER_DIMS)] = [4.0, 4.0]
    emitted = (a.action_normalizer.normalize(zero).astype(np.float32)
               if a.action_normalizer is not None else zero.astype(np.float32))
    arm, lg, rg = a.eef_action_to_g1_action(emitted, q)
    assert np.abs(arm - q).max() < 1e-3
    print(f"startup: works with every training-machine path unreachable "
          f"(normalization={a._normalization_mode}), decode round-trips")


def test_copied_bundle_works_in_isolation():
    """Copy just the files a deployment carries into a scratch tree and run the
    Cartesian path from there, so nothing can silently reach back here."""
    with tempfile.TemporaryDirectory() as td:
        dst = Path(td) / "InferenceMotusV2"
        (dst / "scripts").mkdir(parents=True)
        shutil.copytree(BUNDLE / "assets", dst / "assets")
        shutil.copytree(BUNDLE / "scripts" / "motusv2_adapter", dst / "scripts" / "motusv2_adapter")

        # Import the copy under a distinct name so this process keeps using it.
        import importlib.util

        spec = importlib.util.spec_from_file_location(
            "copied_eef_delta", dst / "scripts" / "motusv2_adapter" / "eef_delta.py")
        copied = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(copied)

        assert copied.BUNDLE_ROOT.resolve() == dst.resolve(), copied.BUNDLE_ROOT
        urdf = copied.find_urdf()
        assert Path(urdf).resolve() == (dst / "assets" / "g1_body29_hand14.urdf").resolve(), urdf
        kin = copied.G1EefKinematics(urdf)
        _, action_norm = copied.load_normalizers(str(dst / "assets" / "eef_stats.json"), "eef_delta")

        q = np.zeros(14)
        q[3] = 0.4
        cond = kin.fk_state(q, 4.0, 4.0)
        zero = np.zeros(16)
        zero[list(copied.GRIPPER_DIMS)] = [4.0, 4.0]
        target = copied.from_delta(cond, action_norm.denormalize(action_norm.normalize(zero)))[0]
        q_ik, err, _ = kin.ik(target, q)
        assert err < 2e-2, err
        print(f"isolation: a copied bundle resolves its own assets and closes the "
              f"loop to {err * 1000:.4f} mm")


if __name__ == "__main__":
    test_assets_are_present()
    test_urdf_resolves_to_the_bundle_copy()
    test_kinematics_build_without_meshes()
    test_stats_load_from_the_bundle()
    test_setup_runs_with_external_paths_unreachable()
    test_copied_bundle_works_in_isolation()
    print("\nbundle is self-contained for the Cartesian path")

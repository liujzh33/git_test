"""The inference EEF math must agree with training's, bit for bit where possible.

InferenceMotusV2 cannot import from MotusV2, so scripts/motusv2_adapter/eef_delta.py
restates the layout, the delta convention, the frame constants and the FK. Nothing
in either repo forces those copies to stay in step, which is exactly the kind of
drift that produces a policy that runs but reaches for the wrong place. This test
imports both sides and compares them.

Run on a machine that has both checkouts:
    python scripts/tests/test_eef_delta_parity.py
"""

import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve()
sys.path.insert(0, str(HERE.parents[1]))                 # InferenceMotusV2/scripts
MOTUS_ROOT = Path("/home/work/wenjj/MotusV2")
G1D_STATS = Path("/home/work/wenjj/data/G1-D/pick-kettle-and-cup/meta/eef_stats.json")

from motusv2_adapter import eef_delta as inf  # noqa: E402


def _training_side():
    """Load MotusV2's copies without importing the data.g1d package, whose
    __init__ drags in the whole dataset stack."""
    import importlib.util

    def load(name, path):
        spec = importlib.util.spec_from_file_location(name, path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod

    return (load("train_eef_actions", MOTUS_ROOT / "data" / "g1d" / "eef_actions.py"),
            load("train_converter", MOTUS_ROOT / "tools" / "g1_qpos_to_eef.py"))


def _random_arm_q(rng, kin, n):
    lo, hi = kin.lo, kin.hi
    # Stay off the joint stops: near a limit both sides are correct but IK has no
    # room to move, which would test the clamp rather than the conventions.
    span = hi - lo
    return rng.uniform(lo + 0.2 * span, hi - 0.2 * span, size=(n, 14))


def test_constants_match():
    train_actions, train_conv = _training_side()
    assert tuple(inf.GRIPPER_DIMS) == tuple(train_actions.GRIPPER_DIMS)
    assert tuple(inf.RESERVED_DIMS) == tuple(train_actions.RESERVED_DIMS)
    assert tuple(inf.ARM_BASES) == tuple(train_actions.ARM_BASES)
    assert np.allclose(inf.TCP_OFFSET, train_conv.TCP_OFFSET)
    assert np.allclose(inf.REPORT_FRAME_TO_TORSO, train_conv.REPORT_FRAME_TO_TORSO)
    assert inf.ARM_JOINTS == train_conv.ARM_JOINTS
    print("constants: layout, TCP offset, report frame and joint order all match")


def test_delta_matches_training():
    train_actions, _ = _training_side()
    rng = np.random.default_rng(0)
    cond = rng.normal(0, 0.5, 16)
    targets = rng.normal(0, 0.5, (32, 16))
    for d in inf.RESERVED_DIMS:
        cond[d] = 0.0
        targets[:, d] = 0.0

    mine = inf.to_delta(cond, targets)
    theirs = train_actions.to_delta(cond, targets)
    assert np.abs(mine - theirs).max() < 1e-12, np.abs(mine - theirs).max()

    back = inf.from_delta(cond, mine)
    assert np.abs(back - targets).max() < 1e-9, np.abs(back - targets).max()
    print("delta: matches training to 1e-12 and inverts to 1e-9")


def test_fk_matches_training_converter():
    """Inference FK on 14 joints must reproduce the training converter's
    observation.state.eef for the same joints."""
    _, train_conv = _training_side()
    urdf = inf.find_urdf(["/home/work/wenjj"])
    assert urdf, "no G1 URDF found"
    kin = inf.G1EefKinematics(urdf)
    fk_train = train_conv.G1ArmFK()

    rng = np.random.default_rng(1)
    q = _random_arm_q(rng, kin, 64)
    grips = rng.uniform(2.0, 5.4, size=(64, 2))

    theirs = fk_train(np.concatenate([q, grips], axis=1))
    worst_p = worst_r = 0.0
    for i in range(len(q)):
        mine = kin.fk_state(q[i], grips[i, 0], grips[i, 1])
        for base in inf.ARM_BASES:
            worst_p = max(worst_p, np.abs(mine[base:base + 3] - theirs[i, base:base + 3]).max())
            worst_r = max(worst_r, np.abs(mine[base + 3:base + 6] - theirs[i, base + 3:base + 6]).max())
        assert np.allclose(mine[list(inf.GRIPPER_DIMS)], grips[i])
        assert np.all(mine[list(inf.RESERVED_DIMS)] == 0.0)
    print(f"fk: matches the training converter to {worst_p * 1e6:.2f} um / {worst_r:.2e} rad")
    assert worst_p < 1e-5, worst_p
    assert worst_r < 1e-5, worst_r


def test_full_inference_chain_recovers_joints():
    """The end-to-end contract: joints -> FK -> delta -> normalize is what the
    model was trained on, and denormalize -> from_delta -> IK is what inference
    does. Composed, they must return the joints we started from."""
    train_actions, train_conv = _training_side()
    urdf = inf.find_urdf(["/home/work/wenjj"])
    kin = inf.G1EefKinematics(urdf)
    state_norm, action_norm = inf.load_normalizers(str(G1D_STATS), "eef_delta")

    rng = np.random.default_rng(2)
    q_cond = _random_arm_q(rng, kin, 1)[0]
    # Targets a short distance away, like consecutive steps of one chunk.
    q_targets = q_cond + rng.normal(0, 0.05, (16, 14))
    q_targets = np.clip(q_targets, kin.lo + 0.05, kin.hi - 0.05)

    cond_abs = kin.fk_state(q_cond, 4.0, 4.0)
    abs_targets = np.stack([kin.fk_state(q, 4.0, 4.0) for q in q_targets])

    # training side
    deltas = train_actions.to_delta(cond_abs, abs_targets)
    model_targets = action_norm.normalize(deltas)

    # inference side
    seed, worst_q, worst_p = q_cond.copy(), 0.0, 0.0
    for i in range(len(q_targets)):
        act = action_norm.denormalize(model_targets[i])
        recovered_abs = inf.from_delta(cond_abs, act)[0]
        worst_p = max(worst_p, float(np.abs(recovered_abs - abs_targets[i]).max()))
        q_ik, err, _ = kin.ik(recovered_abs, seed)
        # Redundancy means IK need not return the same joints, but it must reach
        # the same pose; compare in task space and only sanity-check joint drift.
        assert err < 2e-2, f"step {i}: IK missed by {err * 1000:.2f} mm"
        worst_q = max(worst_q, float(np.abs(q_ik - q_targets[i]).max()))
        seed = q_ik

    assert worst_p < 1e-5, worst_p
    print(f"chain: absolute targets recovered to {worst_p * 1e6:.2f} um, "
          f"IK reached every pose (<20 mm, Unitree IPOPT), joint deviation up to {worst_q:.3f} rad "
          f"(redundancy, not error)")


def test_normalizer_round_trip():
    state_norm, action_norm = inf.load_normalizers(str(G1D_STATS), "eef_delta")
    assert state_norm is not action_norm, "eef_delta needs separate state/action scaling"
    rng = np.random.default_rng(3)
    x = rng.normal(0, 0.3, (8, 16))
    assert np.abs(action_norm.denormalize(action_norm.normalize(x)) - x).max() < 1e-5
    # Reserved dims are pinned to a [0, 1] span so a zero stays a zero.
    z = np.zeros(16)
    assert np.all(action_norm.normalize(z)[list(inf.RESERVED_DIMS)] == 0.0)
    print("normalizer: invertible, reserved dims stay at zero")


if __name__ == "__main__":
    test_constants_match()
    test_delta_matches_training()
    test_normalizer_round_trip()
    test_fk_matches_training_converter()
    test_full_inference_chain_recovers_joints()
    print("\nall inference/training parity checks passed")

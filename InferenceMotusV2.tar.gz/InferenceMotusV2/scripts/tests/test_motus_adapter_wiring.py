"""Motus (Stage-3) adapter wiring, without loading the model.

The one thing that cannot be caught by reading the code is preprocessing drift:
the adapter drives the training image and state pipeline from outside the
dataset class, and a divergence there produces a plausible-looking but wrong
trajectory with nothing in the logs to show for it.

Motus has a specific trap here. Two implementations of the same pipeline exist
in the training repo:

    data/utils/image_utils.py                       Pillow BILINEAR  <- training
    inference/real_world/Motus/utils/image_utils.py cv2.resize       <- stale copy

On the 2x downscale this pipeline performs those are different filters, so a
deployment built on the second one feeds the checkpoint images it never saw.
test_image_pipeline_matches_training pins the adapter to the first, and
test_stale_cv2_pipeline_is_actually_different demonstrates that the distinction
is not academic.

The parity half needs the training checkout, which only exists on the dev box;
it skips cleanly on the robot, where the remaining tests still cover the
contract checks, the reorder, the chunk geometry and the guards.

Instances are built with ``__new__`` so none of this needs the ~16 GB of weights
the real constructor loads.

    python scripts/tests/test_motus_adapter_wiring.py
"""

import os
import sys
from pathlib import Path

import numpy as np
import torch
import yaml

HERE = Path(__file__).resolve()
SCRIPTS = HERE.parents[1]
BUNDLE = HERE.parents[2]
sys.path.insert(0, str(SCRIPTS))

CONFIGS = {
    "pick_kettle": BUNDLE / "configs" / "g1d_motus_pick_kettle.yaml",
    "pour_beans": BUNDLE / "configs" / "g1d_motus_pour_beans.yaml",
    "mixed": BUNDLE / "configs" / "g1d_motus_mixed.yaml",
}
DEFAULT_CONFIG = CONFIGS["pick_kettle"]

MOTUS_REPO = Path(os.environ.get("MOTUS_REPO", "/home/work/wenjj/Motus"))
VENDORED = BUNDLE / "policy" / "Motus"
HAVE_TRAINING_REPO = (MOTUS_REPO / "data" / "real_robot" / "base_dataset.py").is_file()

from motus_adapter.adapter import MotusPolicyAdapter  # noqa: E402


def _bare_adapter(config_path=DEFAULT_CONFIG, **config_overrides):
    """An adapter with only the non-model half of __init__ run."""
    a = MotusPolicyAdapter.__new__(MotusPolicyAdapter)
    a.config_dict = yaml.safe_load(Path(config_path).read_text(encoding="utf-8"))
    for dotted, value in config_overrides.items():
        node = a.config_dict
        *path, leaf = dotted.split(".")
        for p in path:
            node = node[p]
        node[leaf] = value
    a.device = "cpu"
    a.ee_dof = 1
    a.arm_dof = 14
    a.t5_cache_dir = ""
    a.max_joint_step = 0.0
    a.replan_steps = 0
    a.decode_video = False
    a.current_instruction = ""
    a._config_path = str(config_path)
    a._read_data_contract()
    a.action_interp_factor = a.resolve_action_interp_factor(0, a._global_downsample_rate)
    a.num_inference_steps = int(
        a.config_dict["model"]["inference"]["num_inference_timesteps"]
    )
    a._init_runtime_state()
    return a


def _random_observation(seed=0):
    """Three 480x640 uint8 RGB frames, the raw G1-D camera format."""
    rng = np.random.default_rng(seed)
    return [rng.integers(0, 256, (480, 640, 3), dtype=np.uint8) for _ in range(3)]


# --------------------------------------------------------------------------- #
# contract
# --------------------------------------------------------------------------- #
def test_reads_the_training_contract():
    a = _bare_adapter()
    assert a.action_chunk_size == 48, a.action_chunk_size
    assert a.video_size == [384, 320], a.video_size
    assert a.normalization is False
    assert a.action_dim == a.state_dim == 16
    assert a.image_keys == ["observation.images.cam_left_high",
                            "observation.images.cam_left_wrist",
                            "observation.images.cam_right_wrist"], a.image_keys
    assert a.action_interp_factor == 1, a.action_interp_factor
    assert a.num_inference_steps == 10, a.num_inference_steps
    print(f"config: {a.action_chunk_size} actions x interp {a.action_interp_factor} "
          f"= {a.action_chunk_size / 30:.2f} s @ 30 Hz, raw qpos, {a.num_inference_steps} steps")


def test_all_three_configs_load_with_their_own_chunk():
    """One adapter has to serve pick-kettle and mixed alike.

    The expected numbers are recomputed from num_video_frames *
    video_action_freq_ratio, which is what MotusConfig.__post_init__ does. Note
    that g1d_mixed.yaml's inline comment claims "action_chunk = 24"; 8 * 2 is
    16, and 16 is what the model is actually built with. Pinning the arithmetic
    here rather than the comment is the whole point of reading the config.
    """
    want = {"pick_kettle": 48, "pour_beans": 48, "mixed": 16}
    for name, path in CONFIGS.items():
        a = _bare_adapter(path)
        assert a.action_chunk_size == want[name], (name, a.action_chunk_size)
        assert a.action_chunk_size == a.num_video_frames * a.video_action_freq_ratio
        print(f"config: {name:12s} -> chunk {a.action_chunk_size:2d} "
              f"({a.action_chunk_size / 30:.2f} s @ 30 Hz)")


def test_rejects_a_mismatched_recipe():
    """Each of these would still run and just produce wrong actions."""
    cases = {
        "dataset.type": "franka",
        "dataset.params.camera_layout": "horizontal",
        "dataset.params.normalization": True,
    }
    for dotted, bad in cases.items():
        try:
            _bare_adapter(**{dotted: bad})
        except ValueError:
            print(f"contract: rejects {dotted}={bad!r}")
        else:
            raise AssertionError(f"expected {dotted}={bad!r} to be rejected")


def test_absent_normalization_key_defaults_to_raw_for_g1d():
    """RealRobotMotusDataset defaults normalization to False for robot_type g1d.

    Guessing True here would silently rescale everything, so the default has to
    be reproduced rather than assumed.
    """
    a = _bare_adapter(**{"dataset.params.normalization": None})
    assert a.normalization is False
    print("contract: a missing normalization key resolves to raw qpos, as in training")


# --------------------------------------------------------------------------- #
# state / action layout
# --------------------------------------------------------------------------- #
def test_reorder_matches_training_and_round_trips():
    a = _bare_adapter()
    raw = np.arange(16, dtype=np.float32)          # [L7, R7, LG, RG]
    interleaved = a._to_arm_interleaved(raw)       # [L7, LG, R7, RG]

    assert np.array_equal(interleaved[0:7], raw[0:7])     # left arm
    assert interleaved[7] == raw[14]                      # left gripper
    assert np.array_equal(interleaved[8:15], raw[7:14])   # right arm
    assert interleaved[15] == raw[15]                     # right gripper
    assert np.array_equal(a._from_arm_interleaved(interleaved), raw)

    from data.real_robot.common import G1D_REORDER_FROM_RAW

    assert list(G1D_REORDER_FROM_RAW) == [0, 1, 2, 3, 4, 5, 6, 14,
                                          7, 8, 9, 10, 11, 12, 13, 15]
    print("reorder: delegates to unify_g1d_qpos_to_16 and round-trips")


def test_action_decodes_to_the_right_slots():
    a = _bare_adapter()
    action = np.arange(16, dtype=np.float32)  # training layout
    arm, left_grip, right_grip = a.qpos_action_to_g1_action(action)
    assert arm.shape == (14,), arm.shape
    assert np.array_equal(arm[0:7], action[0:7])    # left arm
    assert np.array_equal(arm[7:14], action[8:15])  # right arm
    assert left_grip == action[7] and right_grip == action[15]
    print(f"decode: arm[14] + grips ({left_grip:.0f}, {right_grip:.0f}) from dims 7/15")


def test_t5_cache_path_is_the_sha1_of_the_bare_instruction():
    """Motus keys on the instruction itself, not on a wrapped prompt.

    FastWAM hashes DEFAULT_PROMPT.format(task=...) with sha256; using that
    scheme here would miss every file in the cache.
    """
    import hashlib

    a = _bare_adapter()
    a.t5_cache_dir = "/tmp/t5"
    instruction = "拿起水杯和茶壶，并倒水"
    got = a._t5_cache_path(instruction)
    want = hashlib.sha1(instruction.encode("utf-8")).hexdigest()
    assert got.name == f"{want}.pt", got.name
    print(f"t5: {instruction!r} -> {got.name}")


def test_missing_embedding_fails_at_startup():
    """With a live arm, the first control tick is the wrong place to find out."""
    a = _bare_adapter()
    a.t5_cache_dir = "/tmp/motus_t5_definitely_absent"
    try:
        a.set_instruction("no embedding was ever computed for this")
    except FileNotFoundError as e:
        assert "precompute_t5_real_robot" in str(e), e
        print("t5: a missing embedding is a startup error naming the fix")
        return
    raise AssertionError("expected a missing embedding to raise")


# --------------------------------------------------------------------------- #
# image pipeline parity  (the point of this file)
# --------------------------------------------------------------------------- #
def test_image_pipeline_matches_training():
    """Same observation through the adapter and through the training helpers."""
    a = _bare_adapter()
    images = _random_observation(seed=7)

    got = a.build_stitched_image(*images)

    from data.real_robot.common import concat_cameras_robotwin
    from data.utils.image_utils import resize_with_padding

    stitched = concat_cameras_robotwin(images[0], images[1], images[2])
    resized = resize_with_padding(stitched, (384, 320))
    want = torch.from_numpy(np.ascontiguousarray(resized)).permute(2, 0, 1)[None].float() / 255.0

    assert got.shape == want.shape == (1, 3, 384, 320), (got.shape, want.shape)
    err = (got - want).abs().max().item()
    assert err == 0.0, f"image pipeline diverged from training by {err}"
    assert 0.0 <= got.min().item() and got.max().item() <= 1.0, "expected [0, 1]"
    print(f"image parity: exact match, {tuple(got.shape)} in "
          f"[{got.min():.2f}, {got.max():.2f}]")


def test_pipeline_uses_pillow_not_the_stale_cv2_copy():
    """The two image_utils in the Motus repo are not interchangeable.

    data/utils/image_utils.py resizes with Pillow BILINEAR; the copy under
    inference/real_world/Motus/utils/ uses cv2.resize. This pipeline downscales
    720x640 to 360x320, exactly the regime where the two filters disagree, so
    the choice is load-bearing. Fails loudly if the bundle ever picks up the
    cv2 variant.
    """
    if not HAVE_TRAINING_REPO:
        print("filter: training repo unavailable, comparison skipped")
        return
    try:
        import cv2
    except ImportError:
        print("filter: cv2 not installed, comparison skipped")
        return
    from data.real_robot.common import concat_cameras_robotwin

    images = _random_observation(seed=11)
    stitched = concat_cameras_robotwin(images[0], images[1], images[2])

    # The cv2 path, reproduced from the stale copy.
    th, tw = 384, 320
    oh, ow = stitched.shape[:2]
    scale = min(th / oh, tw / ow)
    nh, nw = int(oh * scale), int(ow * scale)
    cv2_resized = np.zeros((th, tw, 3), dtype=stitched.dtype)
    y0, x0 = (th - nh) // 2, (tw - nw) // 2
    cv2_resized[y0:y0 + nh, x0:x0 + nw] = cv2.resize(stitched, (nw, nh))
    cv2_frame = torch.from_numpy(cv2_resized).permute(2, 0, 1)[None].float() / 255.0

    a = _bare_adapter()
    pillow_frame = a.build_stitched_image(*images)

    diff = (pillow_frame - cv2_frame).abs()
    assert diff.max().item() > 0.05, (
        "the Pillow and cv2 pipelines produced nearly identical output; this test "
        "can no longer prove the distinction matters"
    )
    print(f"filter: Pillow vs cv2 differ by up to {diff.max():.3f} "
          f"(mean {diff.mean():.4f}) -- the adapter uses Pillow, as training does")


def test_stitch_geometry_puts_each_camera_in_the_right_region():
    """Which camera lands where, probed with three flat colours.

    Motus stitches at native resolution (480x640 head over two 240x320 wrists =
    720x640) and letterboxes once to 384x320, so the content occupies rows
    12..372 with black bands above and below. Those bands are part of what the
    model was trained on -- FastWAM's stitch has none -- so their presence is
    asserted, not tolerated.
    """
    a = _bare_adapter()
    red, green, blue = (np.zeros((480, 640, 3), np.uint8) for _ in range(3))
    red[..., 0], green[..., 1], blue[..., 2] = 255, 255, 255

    frame = a.build_stitched_image(red, green, blue)[0]  # [3, 384, 320] in [0, 1]

    def dominant(region):
        return int(region.mean(dim=(1, 2)).argmax())

    # 720 -> 360 at scale 0.5, centred in 384: content rows 12..372, the head
    # taking the first 240 of them and the wrists the remaining 120.
    assert dominant(frame[:, 20:245, :]) == 0, "cam_left_high must be the top band"
    assert dominant(frame[:, 260:365, :158]) == 1, "cam_left_wrist must be bottom-left"
    assert dominant(frame[:, 260:365, 162:]) == 2, "cam_right_wrist must be bottom-right"

    black = (frame.amax(dim=0) < 1e-3).all(dim=1)
    padded = black.nonzero().flatten().tolist()
    assert padded[:6] == [0, 1, 2, 3, 4, 5] and len(padded) == 24, (
        f"expected 12 black rows top and bottom from the letterbox, got {len(padded)}: "
        f"{padded[:30]}"
    )
    print(f"stitch: head rows 12:252, wrists 252:372 split at col 160, "
          f"{len(padded)} letterbox rows")


# --------------------------------------------------------------------------- #
# chunk execution
# --------------------------------------------------------------------------- #
def test_exec_queue_length_and_entry_shape():
    a = _bare_adapter()
    chunk = np.zeros((a.action_chunk_size, 16), dtype=np.float32)
    queue = a.build_exec_queue(chunk)
    assert len(queue) == 48, len(queue)
    action, cond = queue[0]
    assert action.shape == (16,) and cond is None
    print(f"queue: 48 actions -> {len(queue)} exec steps, entries are (action[16], None)")


def test_replan_steps_truncates_the_queue():
    a = _bare_adapter()
    a.replan_steps = 12
    queue = a.build_exec_queue(np.zeros((48, 16), dtype=np.float32))
    assert len(queue) == 12, len(queue)
    print("queue: --replan_steps 12 -> re-observe after 12 of 48 actions")


def test_interpolation_preserves_the_endpoints():
    a = _bare_adapter()
    a.action_interp_factor = 3
    chunk = np.linspace(0, 1, 48, dtype=np.float32)[:, None] * np.ones((1, 16), np.float32)
    out = a.interpolate_chunk(chunk)
    assert out.shape == (144, 16), out.shape
    assert np.allclose(out[0], chunk[0]) and np.allclose(out[-1], chunk[-1])
    print(f"interp: x3 -> {out.shape[0]} steps, endpoints preserved")


def test_queue_drains_and_then_asks_for_a_prediction():
    a = _bare_adapter()
    a.action_queue = a.build_exec_queue(np.zeros((48, 16), dtype=np.float32))
    q = np.zeros(14)
    n = 0
    while a.has_cached_actions:
        assert a.step(q) is not None
        n += 1
    assert n == 48 and a.step(q) is None
    print("queue: drains in 48 steps, then step() returns None")


# --------------------------------------------------------------------------- #
# safety guard
# --------------------------------------------------------------------------- #
def test_joint_step_guard_scales_without_changing_direction():
    a = _bare_adapter()
    a.max_joint_step = 0.1
    a._last_cmd_q = np.zeros(14)

    action = np.zeros(16, dtype=np.float32)
    action[0] = 1.0   # left shoulder pitch: 1 rad in one 30 Hz tick
    action[1] = 0.5
    a.action_queue = [(action, None)]
    arm, _, _ = a.step(np.zeros(14))

    # step() returns float32, so the tolerance is float32 eps, not something
    # tighter: under NumPy 1.x the promotion to float64 exposes ~1.5e-9 here.
    assert abs(np.abs(arm).max() - 0.1) < 1e-6, np.abs(arm).max()
    assert abs(arm[1] / arm[0] - 0.5) < 1e-6, "the direction of travel must be preserved"
    assert a._last_guard == "joint_step"
    print(f"guard: 1.000 rad step scaled to {np.abs(arm).max():.3f} rad, direction kept")


def test_guard_is_off_by_default_and_passes_actions_through():
    a = _bare_adapter()
    action = np.zeros(16, dtype=np.float32)
    action[0] = 1.0
    a.action_queue = [(action, None)]
    arm, _, _ = a.step(np.zeros(14))
    assert arm[0] == 1.0 and a._last_guard == ""
    print("guard: off by default, actions pass through unmodified")


def test_reset_drops_the_guard_seed():
    """A new episode must not rate-limit against the previous one's last command."""
    a = _bare_adapter()
    a.max_joint_step = 0.1
    a.action_queue = [(np.ones(16, dtype=np.float32), None)]
    a.step(np.zeros(14))
    assert a._last_cmd_q is not None
    a.reset()
    assert a._last_cmd_q is None and a.action_queue == []
    print("reset: clears the queue and the guard seed")


# --------------------------------------------------------------------------- #
# vendored copy
# --------------------------------------------------------------------------- #
def test_vendored_sources_match_training():
    """The bundle carries a copy of the Motus inference closure; it must be one.

    The copy is what actually runs on the robot, so a hand-edit or a stale
    re-sync is a real deployment hazard and nothing else would catch it. This is
    also what lets the adapter skip the VAE decode by swapping the decoder at
    call time rather than by editing models/motus.py.
    """
    if not HAVE_TRAINING_REPO:
        print("vendored: training repo unavailable, comparison skipped")
        return
    import filecmp

    pairs = [(VENDORED / sub, MOTUS_REPO / sub)
             for sub in ("models", "bak", "utils")]
    pairs += [(VENDORED / "data" / p, MOTUS_REPO / "data" / p)
              for p in ("utils/image_utils.py", "real_robot/common.py")]

    mismatched, missing, n = [], [], 0
    for local, upstream in pairs:
        files = sorted(local.rglob("*.py")) if local.is_dir() else [local]
        for f in files:
            n += 1
            rel = f.relative_to(VENDORED)
            up = MOTUS_REPO / rel
            if not up.is_file():
                missing.append(str(rel))
            elif not filecmp.cmp(f, up, shallow=False):
                mismatched.append(str(rel))
    assert not missing, f"vendored files with no upstream counterpart: {missing}"
    assert not mismatched, (
        f"vendored files differ from {MOTUS_REPO}: {mismatched}. Re-sync with the "
        "command in motus_adapter.adapter._resolve_motus_dir."
    )
    print(f"vendored: {n} files identical to {MOTUS_REPO}")


if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    failed = 0
    for t in tests:
        try:
            t()
        except Exception as e:  # keep going: one broken contract should not hide the rest
            failed += 1
            print(f"FAIL {t.__name__}: {type(e).__name__}: {e}")
    print(f"\n{len(tests) - failed}/{len(tests)} passed")
    sys.exit(1 if failed else 0)

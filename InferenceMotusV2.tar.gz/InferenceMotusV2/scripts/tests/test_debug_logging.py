"""The diagnostic logger: off by default, and correct when on.

The part worth testing is the normalization fingerprint. It is the only check
that inspects the CHECKPOINT rather than the files shipped beside it, so it is
what catches a checkpoint served under the wrong normalization -- a failure that
rescales every action while every md5 still matches. It is verified here against
real delta targets from the dataset, normalized both ways.

    python scripts/tests/test_debug_logging.py
"""

import json
import sys
import tempfile
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve()
sys.path.insert(0, str(HERE.parents[1]))

from motusv2_adapter import debug as dbg  # noqa: E402
from motusv2_adapter import eef_delta as inf  # noqa: E402

G1D = Path("/home/work/wenjj/data/G1-D/pick-kettle-and-cup")
STATS = G1D / "meta" / "eef_stats.json"
CHUNK = 64


def _reset():
    dbg._state.clear()
    dbg._state["on"] = False


def _real_delta_targets(n_windows=40):
    """Delta targets exactly as the dataset builds them: cond = state[t],
    targets = action[t+1 .. t+64]."""
    import pandas as pd

    f = next(G1D.glob("data/chunk-*/file-*.parquet"))
    df = pd.read_parquet(f, columns=["observation.state.eef", "action.eef", "episode_index"])
    state = np.stack(df["observation.state.eef"].to_numpy()).astype(np.float64)
    action = np.stack(df["action.eef"].to_numpy()).astype(np.float64)
    ep = df["episode_index"].to_numpy()
    rng = np.random.default_rng(0)
    out = []
    for e in np.unique(ep)[:12]:
        idx = np.flatnonzero(ep == e)
        if len(idx) < CHUNK + 2:
            continue
        for _ in range(n_windows // 12 + 1):
            t = rng.integers(0, len(idx) - CHUNK - 1)
            out.append(inf.to_delta(state[idx[t]], action[idx[t + 1:t + 1 + CHUNK]]))
    return np.concatenate(out)


def test_disabled_by_default_and_inert():
    _reset()
    assert dbg.configure(False) is None
    assert dbg.on() is False
    # Every entry point must be a no-op rather than raise, because a broken log
    # must never be able to stop the robot.
    dbg.banner(checkpoint="x", config_path="x", stats_path="x", urdf="x",
               action_mode="eef_delta", norm_mode="standard", chunk=64, interp=1,
               freq=30.0, inference_steps=5, instruction="i", stitch_mode="aspect")
    dbg.chunk(index=0, cond_abs=np.zeros(16), deltas=np.zeros((4, 16)),
              targets=np.zeros((4, 16)), raw=np.zeros((4, 16)), dim_names=inf.DIM_NAMES)
    dbg.step(index=1, q_cmd=np.zeros(14), q_meas=np.zeros(14), ik_err=0.0, joint_step=0.0)
    dbg.summary()
    print("disabled: configure returns None and every hook is inert")


def test_fingerprint_tells_the_two_normalizers_apart():
    """The decisive test: real targets, normalized both ways, must be identified."""
    stats = json.loads(STATS.read_text())
    D = _real_delta_targets()

    dmin = np.asarray(stats["delta_min"])
    dmax = np.asarray(stats["delta_max"])
    dmu = np.asarray(stats["delta_mean"])
    dsd = np.asarray(stats["delta_std"]).copy()
    dsd[dsd < 1e-8] = 1.0

    z_minmax = (D - dmin) / (dmax - dmin + 1e-8)
    z_standard = (D - dmu) / dsd

    fp_mm = dbg.fingerprint(z_minmax, "minmax")
    fp_st = dbg.fingerprint(z_standard, "standard")
    print(f"  minmax-normalized targets  : mean {fp_mm['mean']:+.3f} std {fp_mm['std']:.3f} "
          f"outside[0,1] {100*fp_mm['frac_outside_01']:.1f}%  -> {fp_mm['looks_like']}")
    print(f"  standard-normalized targets: mean {fp_st['mean']:+.3f} std {fp_st['std']:.3f} "
          f"outside[0,1] {100*fp_st['frac_outside_01']:.1f}%  -> {fp_st['looks_like']}")

    assert fp_mm["looks_like"] == "minmax" and fp_mm["agrees"], fp_mm
    assert fp_st["looks_like"] == "standard" and fp_st["agrees"], fp_st
    # And it must FLAG the swap, which is the case that actually happens.
    assert not dbg.fingerprint(z_minmax, "standard")["agrees"], \
        "a minmax checkpoint served as standard went undetected"
    assert not dbg.fingerprint(z_standard, "minmax")["agrees"], \
        "a standard checkpoint served as minmax went undetected"
    print("fingerprint: identifies both normalizers on real targets and flags either swap")


def test_enabled_writes_a_log_and_a_parseable_record():
    _reset()
    with tempfile.TemporaryDirectory() as d:
        path = dbg.configure(True, d, "INFO", every=10)
        assert path and Path(path).exists(), path
        assert dbg.on()

        dbg.banner(checkpoint="/ckpt/x", config_path=str(STATS), stats_path=str(STATS),
                   urdf=str(inf.BUNDLED_URDF), action_mode="eef_delta",
                   norm_mode="standard", chunk=64, interp=1, freq=30.0,
                   inference_steps=5, instruction="拿起水杯和茶壶，并倒水",
                   stitch_mode="aspect")

        rng = np.random.default_rng(0)
        cond = np.zeros(16)
        deltas = rng.normal(0, 0.02, (CHUNK, 16))
        targets = inf.from_delta(cond, deltas)
        dbg.chunk(index=0, cond_abs=cond, deltas=deltas, targets=targets,
                  raw=deltas, dim_names=inf.DIM_NAMES, predict_ms=812.0)

        for i in range(1, 26):
            guard = "joint_step" if i == 7 else ""
            dbg.step(index=i, q_cmd=np.zeros(14), q_meas=np.full(14, 0.01),
                     ik_err=0.003, joint_step=0.02, guard=guard, queue=64 - i)
        dbg.summary()

        text = Path(path).read_text()
        assert "run contract" in text and "run summary" in text
        # The md5s are the point of the banner.
        import hashlib
        want = hashlib.md5(STATS.read_bytes()).hexdigest()
        assert want in text, "the statistics md5 is missing from the contract block"
        assert "[debug][chunk 0]" in text
        assert "GUARD=joint_step" in text, "a guard event was throttled away"

        rec = [json.loads(l) for l in Path(str(path)[:-4] + ".jsonl").read_text().splitlines()]
        kinds = [r["kind"] for r in rec]
        assert kinds[0] == "contract" and kinds[-1] == "summary", kinds
        steps = [r for r in rec if r["kind"] == "step"]
        # every=10 over indices 1..25 -> 10 and 20, plus the unthrottled guard at 7
        assert {s["index"] for s in steps} == {7, 10, 20}, sorted(s["index"] for s in steps)
        assert next(r for r in rec if r["kind"] == "summary")["counters"] == {"guard:joint_step": 1}
        ch = next(r for r in rec if r["kind"] == "chunk")
        assert ch["n"] == CHUNK and ch["predict_ms"] == 812.0
        print(f"enabled: {len(rec)} records, contract md5 recorded, throttle honoured "
              f"(steps {sorted(s['index'] for s in steps)}), guard never skipped")
    _reset()


if __name__ == "__main__":
    test_disabled_by_default_and_inert()
    test_fingerprint_tells_the_two_normalizers_apart()
    test_enabled_writes_a_log_and_a_parseable_record()
    print("\nall debug logging checks passed")

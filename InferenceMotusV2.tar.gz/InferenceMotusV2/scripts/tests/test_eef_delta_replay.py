"""Replay a real G1-D episode through the whole inference chain.

The parity test proves the two sides compute the same functions. This one asks
the question that actually decides whether the robot moves correctly: if the
policy emitted exactly what the demonstration contains, does the inference chain
turn it back into the demonstrated joint trajectory?

Everything except the model is exercised -- FK on measured joints, the delta
composition, normalisation both ways, IK, the warm-start seeding across a chunk
and the joint-step guard.

    python scripts/tests/test_eef_delta_replay.py
"""

import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve()
sys.path.insert(0, str(HERE.parents[1]))

from motusv2_adapter import eef_delta as inf  # noqa: E402

G1D = Path("/home/work/wenjj/data/G1-D/pick-kettle-and-cup")
STATS = G1D / "meta" / "eef_stats.json"
CHUNK = 64
MAX_JOINT_STEP = 0.5


def replay(episode: int, kin, action_norm, state_norm):
    df = pd.read_parquet(next(G1D.glob("data/chunk-*/file-*.parquet")))
    rows = df[df.episode_index == episode].reset_index(drop=True)
    q_all = np.stack(rows["action"].to_numpy()).astype(np.float64)
    eef_all = np.stack(rows["action.eef"].to_numpy()).astype(np.float64)

    pos_err, joint_dev, steps, clamps, retries, times = [], [], [], 0, 0, []
    seed = None
    for start in range(0, len(rows) - CHUNK - 1, CHUNK):
        # --- what the robot does at the top of a chunk ---
        q_meas = q_all[start, :14]
        cond_abs = kin.fk_state(q_meas, q_all[start, 14], q_all[start, 15])
        if state_norm is not None:
            _ = state_norm.normalize(cond_abs)      # what the model would see
        seed = q_meas.copy()

        # --- what the model would emit for this chunk, taken from the demo ---
        idx = [start + i + 1 for i in range(CHUNK)]
        deltas = inf.to_delta(cond_abs, eef_all[idx])
        emitted = action_norm.normalize(deltas) if action_norm else deltas

        for i in range(CHUNK):
            t0 = time.perf_counter()
            act = action_norm.denormalize(emitted[i]) if action_norm else emitted[i]
            target_abs = inf.from_delta(cond_abs, act)[0]
            q_ik, err, retried = kin.ik(target_abs, seed)
            times.append(time.perf_counter() - t0)
            retries += bool(retried)

            step = float(np.abs(q_ik - seed).max())
            if step > MAX_JOINT_STEP:
                clamps += 1
                q_ik = seed
            steps.append(step)
            pos_err.append(err)
            joint_dev.append(float(np.abs(q_ik - q_all[idx[i], :14]).max()))
            seed = q_ik
    return map(np.array, (pos_err, joint_dev, steps, times)), clamps, retries


def main():
    urdf = inf.find_urdf(["/home/work/wenjj"])
    print(f"URDF: {urdf}")
    kin = inf.G1EefKinematics(urdf)

    # Both settings of dataset.normalization. With it off the dataset hands the
    # model raw metres and radians and expects them straight back, so the chain
    # has to close with no scaling anywhere -- which is only a real test if the
    # same replay is run through it.
    modes = {
        "standard": inf.load_normalizers(str(STATS), "eef_delta", "standard"),
        "minmax": inf.load_normalizers(str(STATS), "eef_delta", "minmax"),
        "none (normalization: false)": (None, None),
    }

    for label, (state_norm, action_norm) in modes.items():
        all_p, all_d, all_s, all_t = [], [], [], []
        total_clamps = total_retries = 0
        for ep in range(6):
            (p, d, s, t), clamps, retries = replay(ep, kin, action_norm, state_norm)
            all_p.append(p); all_d.append(d); all_s.append(s); all_t.append(t)
            total_clamps += clamps
            total_retries += retries
        p, d, s, t = map(np.concatenate, (all_p, all_d, all_s, all_t))

        print(f"\n--- normalization = {label} ---")
        print(f"  replayed 6 episodes, {len(p)} control steps")
        print(f"  IK pose error      median {np.median(p) * 1000:.4f} mm   "
              f"p99 {np.percentile(p, 99) * 1000:.4f} mm   max {p.max() * 1000:.3f} mm")
        print(f"  joint vs demo      median {np.median(d):.4f} rad  "
              f"p99 {np.percentile(d, 99):.4f} rad  max {d.max():.4f} rad")
        print(f"  per-step joint move median {np.median(s):.4f} rad  max {s.max():.4f} rad")
        print(f"  cold re-solves {total_retries}   guard clamps {total_clamps}")
        print(f"  IK latency         median {np.median(t) * 1000:.3f} ms  "
              f"p99 {np.percentile(t, 99) * 1000:.3f} ms  -> {1 / np.median(t):.0f} Hz")

        assert np.percentile(p, 99) < 2e-2, f"[{label}] IK not tracking the demonstrated poses"
        assert np.median(t) < 0.01, f"[{label}] IK too slow for a 30 Hz loop"

    print("\nreplay OK: the chain reproduces the demonstration within IK tolerance "
          "in every normalization mode")


if __name__ == "__main__":
    main()

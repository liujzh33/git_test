#!/bin/bash
# MotusV2 real-robot inference entry script for G1
# This script does NOT modify or depend on the pi0.5 pipeline
#
# G1-D uses 16-dim qpos joint-position actions (NOT eepos).
# Config: g1d_pick_kettle_wan_vlm_mask.yaml

# ==================== ROOT DIRS (Thor original layout) ====================
# SCRIPTS_DIR = where eval_g1_motus.py + motusv2_adapter/adapter.py live.
SCRIPTS_DIR="/home/unitree/scripts"
# unitree_lerobot repo (hardware interfaces):
LEROBOT_ROOT="/home/unitree/codes/unitree_lerobot/"
# MODEL CODE dir = the folder that directly contains models/ bak/ utils/
# (the MotusWanVlmDirectMaskMotion package). adapter.py can auto-detect it, but
# setting it explicitly avoids all path guessing.
export MOTUS_POLICY_DIR="/home/unitree/codes/temp/MotusV2/policy/MotusWanVlmDirectMaskMotion"
# =========================================================================

export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
cd "$LEROBOT_ROOT"
export PYTHONPATH="$LEROBOT_ROOT":"$SCRIPTS_DIR"

# ==================== PATHS (modify these) ====================
# --- Model weights / data ---
CHECKPOINT_PATH="/home/unitree/pretrained_models/ckpts/WamVlmMask_g1d_pick_kettle_2w"
WAN_PATH="/home/unitree/pretrained_models/Wan2.2-TI2V-5B"
VLM_PATH="/home/unitree/pretrained_models/Qwen3-VL-2B-Instruct"
T5_CACHE_DIR="/home/unitree/codes/temp/t5_cache_pick-kettle-and-cup"
DATASET_ROOT="/home/unitree/datasets/pick-kettle-and-cup"
# --- Config (verify this path on your Thor; it is the g1d yaml you edited) ---
CONFIG_PATH="/home/unitree/codes/temp/MotusV2/configs/g1d_pick_kettle_wan_vlm_mask.yaml"
# --- Task instruction ---
INSTRUCTION="拿起水杯和茶壶，并倒水"
# ==============================================================

# ==================== INFERENCE / SMOOTHING OPTIONS ====================
# Denoising steps (5 tested OK; 10 higher quality but slower).
NUM_INFERENCE_STEPS=5

# Action interpolation: upsample the 16-action chunk in time by this factor.
#   0  = auto (recommended): take the factor from the config's global_downsample_rate.
#        The model's 16 actions are spaced that many 30Hz frames apart but carry no time
#        scale, so this is exactly the factor that replays them at the demonstrated speed.
#        A gdr=4 checkpoint run with factor 1 moves 4x too fast; factor 4 gives 64 steps
#        = 2.13s. Auto keeps the two in sync as long as the config ships with the ckpt.
#   1  = no interpolation. Only correct when global_downsample_rate is 1.
#   >stride = deliberately slower and smoother than the demonstration.
#
#   CONTINUITY CONDITIONS for async (C = 16*factor exec steps, I = inference in exec steps):
#       ASYNC_TRIGGER >= I            (queue must not drain while inference runs)
#       C >= ASYNC_TRIGGER + I        (enough runway between two splices)
#
#   MEASURED (NUM_INFERENCE_STEPS=5, see docs/log_260728_2155.txt):
#       model_forward ~358ms, full predict_action_chunk ~409-441ms,
#       + obs capture ~7ms  =>  I ~450ms  =>  I ~= 14 exec steps @30Hz (use 15 w/ margin).
#   This checkpoint ships global_downsample_rate=4, so auto (0) gives factor 4:
#       C = 16*4 = 64 exec steps = 2.13s of motion  >>  2*I = 30.
#   i.e. replaying at the DEMONSTRATED speed already satisfies continuity with a
#   wide margin — no deliberate slow-down is needed. Keep this at 0.
ACTION_INTERP_FACTOR=0

# Async double-buffer: run inference in a background thread while executing.
ASYNC_INFERENCE=1        # 0=serial (original), 1=async
# Launch next prediction when exec queue length <= this.
#   Valid range from the conditions above: I(15) <= trigger <= C-I(49).
#   32 gives a min queue of 32-15 = 17 steps (survives an inference spike up to
#   ~1.07s) and replans every ~32 steps ~= 1.07s, so plans stay fresh.
ASYNC_TRIGGER=32

# RTC (Real-Time Chunking) cross-chunk guidance. Requires ASYNC_INFERENCE=1.
USE_RTC=1                # 0=off, 1=on

# RTC guidance mechanism:
#   inpaint         = guidance-free clean-space blend (default; fastest, cannot overshoot)
#   action_jacobian = exact VJP back-propagated through the Action Expert ONLY.
#                     The attention mask makes the video(5B)/VLM gradient exactly
#                     zero, so this equals the full-network Jacobian at ~a few %
#                     extra cost. Forces the eager step (no torch.compile).
#   pi05            = faithful LeRobot pi0.5 reproduction (identity Jacobian +
#                     pi0.5 guidance weight; can overshoot at large t)
RTC_MODE=pi05

# Per-denoising-step RTC diagnostics (verbose: num_inference_steps lines/chunk).
RTC_DEBUG=0              # 0=off, 1=on -> exports MOTUS_RTC_DEBUG

# Frozen-prefix length in RAW action steps ~= I / ACTION_INTERP_FACTOR = 15/4 ~= 4.
# Only seeds the FIRST inference: afterwards eval_g1_motus.py re-estimates it from
# the previous cycle's measured skip, so the freeze boundary tracks real latency.
RTC_INFERENCE_DELAY=4
# Where the prefix weights reach 0. Must exceed RTC_INFERENCE_DELAY so a free
# region exists. 8 gives: frozen[0:4] + blend[4:8] + free[8:16] — the executed
# part (from raw step ~4) is a short soft handoff then a fully fresh plan.
# (16 would leave no free region and over-constrain the chunk to the stale plan.)
RTC_EXECUTION_HORIZON=8
# Only used by RTC_MODE=pi05 / action_jacobian (inpaint needs no gain).
RTC_MAX_GUIDANCE_WEIGHT=5.0
RTC_SCHEDULE=exp         # exp | linear | ones | zeros
# ======================================================================

# torch.compile is disabled by default in code; set explicitly as a safety belt.
export MOTUS_COMPILE=0
export MOTUS_RTC_DEBUG=$RTC_DEBUG

# Assemble optional store_true flags.
EXTRA_FLAGS=""
if [ "$ASYNC_INFERENCE" = "1" ]; then EXTRA_FLAGS="$EXTRA_FLAGS --async_inference"; fi
if [ "$USE_RTC" = "1" ]; then EXTRA_FLAGS="$EXTRA_FLAGS --rtc"; fi

python "$SCRIPTS_DIR"/eval_g1_motus.py \
    --arm=G1_29 \
    --ee=dex1 \
    --frequency=30 \
    --checkpoint_path=$CHECKPOINT_PATH \
    --wan_path=$WAN_PATH \
    --vlm_path=$VLM_PATH \
    --config_path=$CONFIG_PATH \
    --t5_cache_dir=$T5_CACHE_DIR \
    --root=$DATASET_ROOT \
    --num_inference_steps=$NUM_INFERENCE_STEPS \
    --action_interp_factor=$ACTION_INTERP_FACTOR \
    --async_trigger=$ASYNC_TRIGGER \
    --rtc_inference_delay=$RTC_INFERENCE_DELAY \
    --rtc_execution_horizon=$RTC_EXECUTION_HORIZON \
    --rtc_max_guidance_weight=$RTC_MAX_GUIDANCE_WEIGHT \
    --rtc_schedule=$RTC_SCHEDULE \
    --rtc_mode=$RTC_MODE \
    $EXTRA_FLAGS \
    --instruction="$INSTRUCTION"

#!/bin/bash
# FastWAM real-robot inference entry script for G1-D — SYNCHRONOUS, qpos checkpoint.
# This script does NOT modify or depend on the MotusV2 / pi0.5 pipelines.
#
# The model emits 32 absolute 16-dim qpos targets per chunk under identity
# normalization, so a predicted action is a joint command after one reorder: no
# FK, no IK, no eef_stats.json. Config: configs/g1d_fastwam_mixed.yaml
#
# THREE ARTIFACTS BELONG TO THE CHECKPOINT, NOT TO THE ROBOT, and must be copied
# over from the training machine together with the weights:
#   1. CHECKPOINT_PATH  <output_dir>/checkpoints/weights/step_XXXXXX.pt
#   2. CONFIG_PATH      <output_dir>/config.yaml — the chunk geometry, the camera
#                       stitch and the normalization mode. A copy resolved from
#                       task=g1d_mixed_uncond_3cam_384_5e-5 ships in the bundle
#                       and is the default; point this at the run's own
#                       config.yaml if the recipe was changed.
#   3. T5_CACHE_DIR     FastWAM/data/text_embeds_cache/g1d_mixed/ — the Wan2.2
#                       UMT5 embedding of the instruction. Keyed by the sha256 of
#                       the FULL training prompt, so a missing or stale file is
#                       silent; the adapter refuses to start without it. Produce
#                       it on the training machine with
#                         python scripts/precompute_text_embeds.py \
#                           task=g1d_mixed_uncond_3cam_384_5e-5
#
# WAN_PATH is shared with the MotusV2 deployment and needs no copying: only
# Wan2.2_VAE.pth is read (the DiT and UMT5 weights are replaced by the
# checkpoint and by the T5 cache respectively).

# ==================== ROOT DIRS ====================
# Resolved from this script's own location, so the bundle runs wherever it is
# copied. Override any of them by exporting the variable before calling.
SCRIPTS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUNDLE_ROOT="$(dirname "$SCRIPTS_DIR")"
# unitree_lerobot repo (hardware interfaces) — external, robot-specific.
LEROBOT_ROOT="${LEROBOT_ROOT:-/home/robo/codes/unitree_lerobot/}"
# MODEL CODE dir = the folder that directly contains fastwam/.
export FASTWAM_SRC_DIR="${FASTWAM_SRC_DIR:-$BUNDLE_ROOT/policy/FastWAM/src}"
# ===================================================

export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
cd "$LEROBOT_ROOT"
export PYTHONPATH="$LEROBOT_ROOT":"$SCRIPTS_DIR"

export UNITREE_DDS_INTERFACE="${UNITREE_DDS_INTERFACE:-enx607d09725112}"

# Never reach for the network to fill a missing weight file: the loader would
# otherwise try to pull ~34 GB from ModelScope over the robot's link. With this
# set, a missing file is an immediate error naming the path.
export DIFFSYNTH_SKIP_DOWNLOAD=true

# ==================== PATHS (modify these) ====================
# >>> FILL IN: the post-trained G1-D weights and the config.yaml beside them. <<<
CHECKPOINT_PATH="/home/robo/pretrained_models/ckpts/fastwam_g1d_mixed/checkpoints/weights/step_040000.pt"
# The bundled copy matches task=g1d_mixed_uncond_3cam_384_5e-5. Replace with the
# run's own <output_dir>/config.yaml if the training recipe was modified.
CONFIG_PATH="${CONFIG_PATH:-$BUNDLE_ROOT/configs/g1d_fastwam_mixed.yaml}"
# >>> FILL IN: copied from FastWAM/data/text_embeds_cache/g1d_mixed/ <<<
T5_CACHE_DIR="${T5_CACHE_DIR:-$BUNDLE_ROOT/assets/t5_cache_g1d_fastwam}"
# Shared with the MotusV2 deployment; only Wan2.2_VAE.pth is read.
WAN_PATH="${WAN_PATH:-/home/robo/pretrained_models/Wan2.2-TI2V-5B}"
# Optional: LeRobot dataset root, used ONLY to move the arm to the pose episode 0
# started from. Empty = start from wherever the arm currently is.
DATASET_ROOT="/home/robo/datasets/pick-kettle-and-cup"

# The instruction has to be the exact string the T5 embedding was precomputed
# for — the cache key is a hash of it, so one differing character is a startup
# error rather than a silent fallback. Both post-training tasks are listed;
# uncomment the one being run.
#
# To print the exact strings a dataset was trained on and the cache filename each
# one maps to, run this on the TRAINING machine:
#
#   PYTHONPATH=<FastWAM>/src python -c '
#   import hashlib, sys
#   from fastwam.datasets.lerobot.g1d_qpos import iter_dataset_task_strings
#   from fastwam.datasets.lerobot.robot_video_dataset import DEFAULT_PROMPT
#   for t in iter_dataset_task_strings(sys.argv[1]):
#       h = hashlib.sha256(DEFAULT_PROMPT.format(task=t).encode()).hexdigest()
#       print(repr(t), "->", h + ".t5_len128.wan22ti2v5b.pt")' <dataset_dir>
#
# pick-kettle-and-cup, verified against the dataset:
INSTRUCTION="拿起水杯和茶壶，并倒水"
#   -> 4fb59b31bfbc06c66a78897edcadbc8ee042e0726ea167dd290d6391b1527421.t5_len128.wan22ti2v5b.pt
# pour-beans: fill in from the LeRobot dump the run actually used
# (configs/data/g1d_mixed.yaml points at pour-beans-eps380).
# INSTRUCTION="<the pour-beans task string>"
# ==============================================================

# ==================== INFERENCE OPTIONS ====================
# 0 = the config's eval_num_inference_steps (10 for G1-D). The flow-matching
# sampler is linear in this, so it is the first knob to turn if the pause
# between chunks is too long — at the cost of chunk quality.
NUM_INFERENCE_STEPS=0

# Fix the sampling noise so two runs from the same observation are comparable.
# <0 = unseeded, which is what a real evaluation should use.
SEED=-1

# Action interpolation: 0 = auto = the config's global_sample_stride.
#   THIS CHECKPOINT SHIPS global_sample_stride=1, so auto gives factor 1.
#   That is the correct value: num_frames=33 means the 32 emitted actions are
#   consecutive 30 Hz frames, i.e. 32 exec steps = 1.07 s of demonstrated
#   motion. Raise it only to deliberately run the motion slower.
ACTION_INTERP_FACTOR=0

# How much of each chunk to execute open loop before re-observing.
#   0 = the full 32-action horizon, which is what the model was trained to plan.
# The loop is synchronous, so every replan costs one inference of dead time:
# halving this doubles how often the arm pauses. Start at the full chunk, judge
# the chunks, and only shorten it if the policy is visibly reacting too late.
REPLAN_STEPS=0

# Refuse to move any joint more than this (rad) in one 30 Hz control step,
# measured against the PREVIOUS COMMAND rather than the measurement (the arm
# always trails its target; limiting against the measurement would drag every
# step back toward where the arm is instead of where it is going). The model
# emits absolute targets, so the first action of a chunk can sit far from the
# current pose — that is the case this guards. 0 = off.
#   0.10 rad/tick = 3 rad/s, comfortably above demonstrated speeds.
MAX_JOINT_STEP=0.10
# ===========================================================

# ==================== DIAGNOSTIC LOGGING ====================
# 1 = mirror the diagnostics to $DEBUG_LOG_DIR/inference_fastwam_g1d_<stamp>.log
# and a .jsonl sibling for offline analysis; 0 = console only.
#
# Turn this on whenever the arm misbehaves. The log opens with the md5 of the
# config and of the T5 embedding, then reports per chunk the SEAM
# (|first_action - measured_q|) — how hard the arm is being asked to snap at the
# chunk boundary, which is the failure this representation actually produces and
# which no other log line shows.
DEBUG_LOG=1
DEBUG_LOG_DIR="$BUNDLE_ROOT/logs"
# INFO is the useful level; DEBUG also captures library chatter.
DEBUG_LOG_LEVEL=INFO
# Log one control step in N (30 = ~1 Hz at 30 Hz control). Guard events are
# never skipped regardless of this.
DEBUG_LOG_EVERY=30
# ============================================================

EXTRA_FLAGS=""
if [ -n "$DATASET_ROOT" ]; then EXTRA_FLAGS="$EXTRA_FLAGS --root=$DATASET_ROOT"; fi
if [ "$DEBUG_LOG" = "1" ]; then
    mkdir -p "$DEBUG_LOG_DIR"
    EXTRA_FLAGS="$EXTRA_FLAGS --debug_log --debug_log_dir=$DEBUG_LOG_DIR"
    EXTRA_FLAGS="$EXTRA_FLAGS --debug_log_level=$DEBUG_LOG_LEVEL --debug_log_every=$DEBUG_LOG_EVERY"
    echo "[debug] diagnostics -> $DEBUG_LOG_DIR/inference_fastwam_g1d_<timestamp>.log(+.jsonl)"
fi

python "$SCRIPTS_DIR"/eval_g1_fastwam.py \
    --arm=G1_29 \
    --ee=dex1 \
    --frequency=30 \
    --checkpoint_path="$CHECKPOINT_PATH" \
    --config_path="$CONFIG_PATH" \
    --wan_path="$WAN_PATH" \
    --t5_cache_dir="$T5_CACHE_DIR" \
    --num_inference_steps=$NUM_INFERENCE_STEPS \
    --seed=$SEED \
    --action_interp_factor=$ACTION_INTERP_FACTOR \
    --replan_steps=$REPLAN_STEPS \
    --max_joint_step=$MAX_JOINT_STEP \
    $EXTRA_FLAGS \
    --instruction="$INSTRUCTION"

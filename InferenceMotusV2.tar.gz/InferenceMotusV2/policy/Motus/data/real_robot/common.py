"""
Shared helpers for Franka / Dobot / G1-D LeRobot-format datasets.

Supports:
  - LeRobot v2.1 (per-episode parquet + videos/chunk-*/{key}/episode_*.mp4)
  - LeRobot v3.0 (shared file parquet + videos/{key}/chunk-*/file-*.mp4
    with per-episode video timestamp offsets, including G1-D)
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple, Union

import numpy as np
import pandas as pd

from data.utils.image_utils import _resize_hwc

logger = logging.getLogger(__name__)

G1D_IMAGE_KEYS = [
    "observation.images.cam_left_high",
    "observation.images.cam_left_wrist",
    "observation.images.cam_right_wrist",
]
G1D_ACTION_KEY = "action"
G1D_STATE_KEY = "observation.state"

PICK_KETTLE_ACTION_ORDER = [
    "kLeftShoulderPitch",
    "kLeftShoulderRoll",
    "kLeftShoulderYaw",
    "kLeftElbow",
    "kLeftWristRoll",
    "kLeftWristPitch",
    "kLeftWristYaw",
    "kRightShoulderPitch",
    "kRightShoulderRoll",
    "kRightShoulderYaw",
    "kRightElbow",
    "kRightWristRoll",
    "kRightWristPitch",
    "kRightWristYaw",
    "kLeftGripper",
    "kRightGripper",
]

POUR_BEANS_ACTION_ORDER = [
    "kLeftShoulderPitch",
    "kLeftShoulderRoll",
    "kLeftShoulderYaw",
    "kLeftElbow",
    "kLeftWristRoll",
    "kLeftWristPitch",
    "kLeftWristYaw",
    "kRightShoulderPitch",
    "kRightShoulderRoll",
    "kRightShoulderYaw",
    "kRightElbow",
    "kRightWristRoll",
    "kRightWristPitch",
    "kRightWristYaw",
    "kHighLift",
    "kMoveX",
    "kMoveYaw",
    "kLeftGripper",
    "kRightGripper",
]

POUR_BEANS_STATE_ORDER = POUR_BEANS_ACTION_ORDER + [
    "kBasePosX",
    "kBasePosY",
    "kBaseCosYaw",
    "kBaseSinYaw",
]

# MotusV2 G1-D training layout: [L7, LG, R7, RG] (grippers at dims 7/15).
# Dex1-raw parquet is [L7, R7, LG, RG]; G1D-mobile 19/23 drops chassis/lift/base
# first, then the same reorder is applied.
G1D_UNIFIED_DIM = 16
G1D_UNIFIED_ACTION_ORDER = [
    "kLeftShoulderPitch",
    "kLeftShoulderRoll",
    "kLeftShoulderYaw",
    "kLeftElbow",
    "kLeftWristRoll",
    "kLeftWristPitch",
    "kLeftWristYaw",
    "kLeftGripper",
    "kRightShoulderPitch",
    "kRightShoulderRoll",
    "kRightShoulderYaw",
    "kRightElbow",
    "kRightWristRoll",
    "kRightWristPitch",
    "kRightWristYaw",
    "kRightGripper",
]
G1D_MOBILE_TO_DEX1_RAW = np.array(
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 17, 18], dtype=np.int64
)
G1D_REORDER_FROM_RAW = np.array(
    [0, 1, 2, 3, 4, 5, 6, 14, 7, 8, 9, 10, 11, 12, 13, 15], dtype=np.int64
)


def unify_g1d_qpos_to_16(arr: np.ndarray) -> np.ndarray:
    """Map G1-D qpos onto MotusV2 16-dim [L7, LG, R7, RG].

    Dex1 16-dim is already [L7, R7, LG, RG] and is only reordered.
    G1D-mobile 19-dim action / 23-dim state drop HighLift / MoveX / MoveYaw
    (and base pose on state), keeping grippers at source indices 17/18.
    """
    arr = np.asarray(arr, dtype=np.float32)
    if arr.ndim == 0:
        raise ValueError("qpos vector is scalar")
    leading = arr.shape[:-1]
    n = int(arr.shape[-1])
    flat = arr.reshape(-1, n)
    if n == G1D_UNIFIED_DIM:
        out = flat[:, G1D_REORDER_FROM_RAW]
    elif n in (19, 23):
        out = flat[:, G1D_MOBILE_TO_DEX1_RAW][:, G1D_REORDER_FROM_RAW]
    else:
        raise ValueError(
            f"qpos vector has dim {n}; expected 16 (Dex1) or 19/23 (G1D-mobile)"
        )
    return out.reshape(*leading, G1D_UNIFIED_DIM)

HIDDEN_OR_NON_TASK_DIRS = {
    ".git",
    ".cache",
    "__pycache__",
    "t5_embedding",
    "t5_cache",
    "umt5_wan",
    "debug_outputs",
    "logs",
    "outputs",
    "checkpoints",
}


@dataclass
class EpisodeRecord:
    """One episode in a single-task LeRobot root."""

    task_name: str
    task_root: Path
    episode_index: int
    length: int
    instruction: str
    codebase_version: str
    fps: float
    # Absolute row slice into the loaded task frame table (inclusive start, exclusive end)
    frame_start: int
    frame_end: int
    # Video resolution helpers
    video_paths: Dict[str, Path] = field(default_factory=dict)
    # For v3 shared videos: absolute timestamp = local_ts + video_ts_offset[key]
    video_ts_offset: Dict[str, float] = field(default_factory=dict)
    t5_embedding_path: Optional[str] = None


@dataclass
class TaskSchema:
    task_name: str
    codebase_version: str
    fps: float
    features: Dict[str, Any]
    image_keys: List[str]
    action_key: str
    state_key: str
    action_dim: int
    state_dim: int


def _read_json(path: Path) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _read_jsonl(path: Path) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            rows.append(json.loads(line))
    return rows


def is_lerobot_task_dir(path: Path) -> bool:
    """A valid task dir must contain meta/info.json and a data/ directory."""
    return (path / "meta" / "info.json").is_file() and (path / "data").is_dir()


def discover_task_dirs(
    dataset_root: Union[str, Path],
    task_name: Optional[Union[str, Sequence[str]]] = None,
    *,
    nested_roots: Optional[Sequence[str]] = None,
) -> List[Path]:
    """
    Discover LeRobot task directories under dataset_root.

    nested_roots: optional subdirectories to search (e.g. ['NormalData'] for Dobot).
    If None, look for tasks directly under dataset_root; if none found and nested_roots
    provided, search those; if nested_roots is None, also try common names.
    """
    root = Path(dataset_root).resolve()
    if not root.is_dir():
        raise FileNotFoundError(f"Dataset root not found: {root}")

    def _list_tasks(parent: Path) -> List[Path]:
        tasks = []
        for child in sorted(parent.iterdir()):
            if not child.is_dir():
                continue
            if child.name.startswith(".") or child.name in HIDDEN_OR_NON_TASK_DIRS:
                continue
            if is_lerobot_task_dir(child):
                tasks.append(child)
        return tasks

    # Direct children
    tasks = _list_tasks(root)

    # The root itself may be a single-task LeRobot dump (G1-D pick/pour).
    if not tasks and is_lerobot_task_dir(root):
        tasks = [root]

    # Nested (Dobot: NormalData / RecoveryData)
    if not tasks:
        search_names = list(nested_roots) if nested_roots is not None else ["NormalData"]
        for name in search_names:
            nested = root / name
            if nested.is_dir():
                tasks.extend(_list_tasks(nested))
        tasks = sorted(tasks, key=lambda p: p.name)

    if task_name is None or (isinstance(task_name, str) and task_name.lower() == "null"):
        selected = tasks
    elif isinstance(task_name, str):
        selected = [t for t in tasks if t.name == task_name]
        if not selected:
            # Allow path-like or nested name match
            selected = [t for t in tasks if t.name == Path(task_name).name]
        if not selected:
            raise ValueError(
                f"Task '{task_name}' not found under {root}. "
                f"Available: {[t.name for t in tasks]}"
            )
    else:
        wanted = list(task_name)
        by_name = {t.name: t for t in tasks}
        missing = [n for n in wanted if n not in by_name]
        if missing:
            raise ValueError(
                f"Tasks not found under {root}: {missing}. "
                f"Available: {sorted(by_name)}"
            )
        selected = [by_name[n] for n in wanted]  # preserve user order

    if not selected:
        raise ValueError(f"No valid LeRobot task directories found under {root}")

    return selected


def _feature_shape(feat: Dict[str, Any]) -> Tuple[int, ...]:
    shape = feat.get("shape")
    if shape is None:
        return ()
    return tuple(int(x) for x in shape)


def load_task_schema(
    task_root: Path,
    *,
    image_keys: Sequence[str],
    action_key: str,
    state_key: str,
) -> TaskSchema:
    info = _read_json(task_root / "meta" / "info.json")
    features = info.get("features") or {}
    version = str(info.get("codebase_version", "unknown"))
    fps = float(info.get("fps", 30))

    missing_img = [k for k in image_keys if k not in features]
    if missing_img:
        raise KeyError(
            f"Task '{task_root.name}' missing image keys {missing_img}. "
            f"Available features: {sorted(features)}"
        )
    if action_key not in features:
        raise KeyError(
            f"Task '{task_root.name}' missing action key '{action_key}'. "
            f"Available: {sorted(features)}"
        )
    if state_key not in features:
        raise KeyError(
            f"Task '{task_root.name}' missing state key '{state_key}'. "
            f"Available: {sorted(features)}"
        )

    action_dim = int(_feature_shape(features[action_key])[-1] if _feature_shape(features[action_key]) else 0)
    state_dim = int(_feature_shape(features[state_key])[-1] if _feature_shape(features[state_key]) else 0)
    if action_dim <= 0 or state_dim <= 0:
        # Fall back by reading one parquet row later; keep placeholders
        action_dim = int((_feature_shape(features[action_key]) or (0,))[-1])
        state_dim = int((_feature_shape(features[state_key]) or (0,))[-1])

    return TaskSchema(
        task_name=task_root.name,
        codebase_version=version,
        fps=fps,
        features=features,
        image_keys=list(image_keys),
        action_key=action_key,
        state_key=state_key,
        action_dim=action_dim,
        state_dim=state_dim,
    )


def validate_schemas(
    schemas: Sequence[TaskSchema],
    *,
    check_dims: bool = True,
) -> None:
    """Fail fast if multi-task schemas disagree."""
    if not schemas:
        raise ValueError("No task schemas to validate")
    ref = schemas[0]
    for s in schemas[1:]:
        if s.image_keys != ref.image_keys:
            raise ValueError(
                f"Schema mismatch image_keys: task '{ref.task_name}'={ref.image_keys} "
                f"vs '{s.task_name}'={s.image_keys}"
            )
        if s.action_key != ref.action_key or s.state_key != ref.state_key:
            raise ValueError(
                f"Schema mismatch action/state keys: "
                f"'{ref.task_name}' action={ref.action_key} state={ref.state_key} vs "
                f"'{s.task_name}' action={s.action_key} state={s.state_key}"
            )
        if check_dims and s.action_dim != ref.action_dim:
            raise ValueError(
                f"Schema mismatch action_dim: '{ref.task_name}'={ref.action_dim} "
                f"vs '{s.task_name}'={s.action_dim}"
            )
        if check_dims and s.state_dim != ref.state_dim:
            raise ValueError(
                f"Schema mismatch state_dim: '{ref.task_name}'={ref.state_dim} "
                f"vs '{s.task_name}'={s.state_dim}"
            )
        if abs(s.fps - ref.fps) > 1e-6:
            raise ValueError(
                f"Schema mismatch fps: '{ref.task_name}'={ref.fps} vs '{s.task_name}'={s.fps}"
            )


def _load_tasks_map(task_root: Path) -> Dict[int, str]:
    tasks_jsonl = task_root / "meta" / "tasks.jsonl"
    tasks_json = task_root / "meta" / "tasks.json"
    tasks_parquet = task_root / "meta" / "tasks.parquet"
    out: Dict[int, str] = {}
    if tasks_jsonl.is_file():
        for row in _read_jsonl(tasks_jsonl):
            out[int(row["task_index"])] = str(row["task"])
    elif tasks_json.is_file():
        data = _read_json(tasks_json)
        # either list or dict
        if isinstance(data, dict):
            for k, v in data.items():
                if isinstance(v, dict) and "task" in v:
                    out[int(v.get("task_index", k))] = str(v["task"])
                else:
                    out[int(k)] = str(v)
        elif isinstance(data, list):
            for row in data:
                out[int(row["task_index"])] = str(row["task"])
    elif tasks_parquet.is_file():
        df = pd.read_parquet(tasks_parquet)
        if "task" not in df.columns:
            df = df.reset_index()
            if "task" not in df.columns and "index" in df.columns:
                df = df.rename(columns={"index": "task"})
        if "task_index" in df.columns and "task" in df.columns:
            for _, row in df.iterrows():
                text = str(row["task"]).strip()
                # LeRobot v3 sometimes stores a numeric placeholder; skip those
                # so episode.tasks / folder-name fallback can supply the real prompt.
                if not text or text.isdigit():
                    continue
                out[int(row["task_index"])] = text
    return out


def _load_episodes_v21(task_root: Path) -> List[Dict[str, Any]]:
    path = task_root / "meta" / "episodes.jsonl"
    if not path.is_file():
        raise FileNotFoundError(f"Missing episodes.jsonl for v2.1 dataset: {path}")
    return _read_jsonl(path)


def _load_episodes_v30(task_root: Path) -> pd.DataFrame:
    ep_dir = task_root / "meta" / "episodes"
    if not ep_dir.is_dir():
        # Some exports may still have episodes.jsonl
        jsonl = task_root / "meta" / "episodes.jsonl"
        if jsonl.is_file():
            return pd.DataFrame(_read_jsonl(jsonl))
        raise FileNotFoundError(f"Missing meta/episodes for v3 dataset: {ep_dir}")
    files = sorted(ep_dir.rglob("*.parquet"))
    if not files:
        raise FileNotFoundError(f"No episode parquet files under {ep_dir}")
    return pd.concat([pd.read_parquet(f) for f in files], ignore_index=True)


def _stack_numeric(series: pd.Series) -> np.ndarray:
    vals = series.to_numpy()
    if len(vals) == 0:
        return np.zeros((0, 0), dtype=np.float32)
    first = np.asarray(vals[0], dtype=np.float32)
    if first.ndim == 0:
        return vals.astype(np.float32).reshape(-1, 1)
    return np.stack([np.asarray(v, dtype=np.float32) for v in vals], axis=0)


def load_task_frames(
    task_root: Path,
    schema: TaskSchema,
) -> Tuple[pd.DataFrame, List[EpisodeRecord]]:
    """
    Load all frame-level rows for a task and build EpisodeRecord list.

    Returns a dataframe with at least:
      episode_index, frame_index, timestamp, <action_key>, <state_key>
    and EpisodeRecords whose frame_start/frame_end index into this dataframe.
    """
    version = schema.codebase_version
    tasks_map = _load_tasks_map(task_root)
    default_instruction = tasks_map.get(0, task_root.name.replace("_", " "))

    if version.startswith("v2"):
        return _load_task_frames_v21(task_root, schema, tasks_map, default_instruction)
    if version.startswith("v3"):
        return _load_task_frames_v30(task_root, schema, tasks_map, default_instruction)
    # Heuristic: presence of episodes.jsonl vs meta/episodes/
    if (task_root / "meta" / "episodes.jsonl").is_file():
        return _load_task_frames_v21(task_root, schema, tasks_map, default_instruction)
    return _load_task_frames_v30(task_root, schema, tasks_map, default_instruction)


def _load_task_frames_v21(
    task_root: Path,
    schema: TaskSchema,
    tasks_map: Dict[int, str],
    default_instruction: str,
) -> Tuple[pd.DataFrame, List[EpisodeRecord]]:
    info = _read_json(task_root / "meta" / "info.json")
    chunks_size = int(info.get("chunks_size", 1000))
    episodes_meta = _load_episodes_v21(task_root)

    frames_list: List[pd.DataFrame] = []
    records: List[EpisodeRecord] = []
    cursor = 0

    for ep in episodes_meta:
        ep_idx = int(ep["episode_index"])
        length = int(ep.get("length", 0))
        chunk = ep_idx // chunks_size
        parquet_path = (
            task_root
            / "data"
            / f"chunk-{chunk:03d}"
            / f"episode_{ep_idx:06d}.parquet"
        )
        if not parquet_path.is_file():
            raise FileNotFoundError(
                f"Missing parquet for task={task_root.name} episode={ep_idx}: {parquet_path}"
            )
        df = pd.read_parquet(parquet_path)
        if length <= 0:
            length = len(df)
        if len(df) != length:
            logger.warning(
                "Task %s episode %s length mismatch: meta=%s parquet=%s; using parquet length",
                task_root.name,
                ep_idx,
                length,
                len(df),
            )
            length = len(df)

        # Instruction
        instr = default_instruction
        if "tasks" in ep and ep["tasks"]:
            t0 = ep["tasks"][0]
            instr = str(t0)
        elif "task_index" in df.columns:
            ti = int(df["task_index"].iloc[0])
            instr = tasks_map.get(ti, default_instruction)

        video_paths: Dict[str, Path] = {}
        for key in schema.image_keys:
            vp = (
                task_root
                / "videos"
                / f"chunk-{chunk:03d}"
                / key
                / f"episode_{ep_idx:06d}.mp4"
            )
            if not vp.is_file():
                # Fallback: path stored in parquet
                if key in df.columns and isinstance(df[key].iloc[0], str):
                    cand = task_root / str(df[key].iloc[0])
                    if cand.is_file():
                        vp = cand
            if not vp.is_file():
                raise FileNotFoundError(
                    f"Missing video for task={task_root.name} episode={ep_idx} key={key}: {vp}"
                )
            video_paths[key] = vp

        records.append(
            EpisodeRecord(
                task_name=task_root.name,
                task_root=task_root,
                episode_index=ep_idx,
                length=length,
                instruction=instr,
                codebase_version=schema.codebase_version,
                fps=schema.fps,
                frame_start=cursor,
                frame_end=cursor + length,
                video_paths=video_paths,
                video_ts_offset={k: 0.0 for k in schema.image_keys},
                t5_embedding_path=ep.get("t5_embedding_path"),
            )
        )
        frames_list.append(df)
        cursor += length

    if not frames_list:
        raise ValueError(f"No episodes loaded for task {task_root.name}")
    all_frames = pd.concat(frames_list, ignore_index=True)
    return all_frames, records


def _load_task_frames_v30(
    task_root: Path,
    schema: TaskSchema,
    tasks_map: Dict[int, str],
    default_instruction: str,
) -> Tuple[pd.DataFrame, List[EpisodeRecord]]:
    info = _read_json(task_root / "meta" / "info.json")
    data_path_tmpl = info.get(
        "data_path", "data/chunk-{chunk_index:03d}/file-{file_index:03d}.parquet"
    )
    video_path_tmpl = info.get(
        "video_path",
        "videos/{video_key}/chunk-{chunk_index:03d}/file-{file_index:03d}.mp4",
    )

    ep_df = _load_episodes_v30(task_root)
    # Load all data parquet files referenced
    data_files = sorted((task_root / "data").rglob("*.parquet"))
    if not data_files:
        raise FileNotFoundError(f"No data parquet under {task_root / 'data'}")
    # Prefer loading by episode meta indices to avoid huge multi-file concat issues
    # But Dobot often has one big file; load all once.
    frames = pd.concat([pd.read_parquet(f) for f in data_files], ignore_index=True)
    frames = frames.sort_values(["episode_index", "frame_index"]).reset_index(drop=True)

    records: List[EpisodeRecord] = []
    # Build episode -> row ranges from dataframe (more reliable than meta indices alone)
    for ep_idx, group in frames.groupby("episode_index", sort=True):
        ep_idx = int(ep_idx)
        idxs = group.index.to_numpy()
        frame_start = int(idxs.min())
        frame_end = int(idxs.max()) + 1
        length = frame_end - frame_start

        # Episode meta row (optional)
        meta_row = None
        if "episode_index" in ep_df.columns:
            match = ep_df[ep_df["episode_index"] == ep_idx]
            if len(match) > 0:
                meta_row = match.iloc[0]

        instr = default_instruction
        if meta_row is not None and "tasks" in meta_row and meta_row["tasks"] is not None:
            tasks_val = meta_row["tasks"]
            if isinstance(tasks_val, (list, np.ndarray)) and len(tasks_val) > 0:
                instr = str(tasks_val[0])
            elif isinstance(tasks_val, str):
                instr = tasks_val
        elif "task" in group.columns:
            instr = str(group["task"].iloc[0])
        elif "task_index" in group.columns:
            instr = tasks_map.get(int(group["task_index"].iloc[0]), default_instruction)

        video_paths: Dict[str, Path] = {}
        video_ts_offset: Dict[str, float] = {}
        for key in schema.image_keys:
            if meta_row is not None:
                chunk_col = f"videos/{key}/chunk_index"
                file_col = f"videos/{key}/file_index"
                from_col = f"videos/{key}/from_timestamp"
                if chunk_col in meta_row and file_col in meta_row:
                    chunk_i = int(meta_row[chunk_col])
                    file_i = int(meta_row[file_col])
                    vp = task_root / video_path_tmpl.format(
                        video_key=key, chunk_index=chunk_i, file_index=file_i
                    )
                    video_paths[key] = vp
                    video_ts_offset[key] = float(meta_row[from_col]) if from_col in meta_row else 0.0
            if key not in video_paths:
                # Fallback: try episode-local naming (rare for v3)
                vp = task_root / "videos" / key / f"episode_{ep_idx:06d}.mp4"
                video_paths[key] = vp
                video_ts_offset[key] = 0.0
            if not video_paths[key].is_file():
                raise FileNotFoundError(
                    f"Missing video for task={task_root.name} episode={ep_idx} "
                    f"key={key}: {video_paths[key]}"
                )

        records.append(
            EpisodeRecord(
                task_name=task_root.name,
                task_root=task_root,
                episode_index=ep_idx,
                length=length,
                instruction=instr,
                codebase_version=schema.codebase_version,
                fps=schema.fps,
                frame_start=frame_start,
                frame_end=frame_end,
                video_paths=video_paths,
                video_ts_offset=video_ts_offset,
                t5_embedding_path=None,
            )
        )

    logger.info(
        "Loaded v3 task %s: %d episodes, %d frames (tmpl data=%s)",
        task_root.name,
        len(records),
        len(frames),
        data_path_tmpl,
    )
    return frames, records


def extract_action_state_arrays(
    frames: pd.DataFrame,
    action_key: str,
    state_key: str,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Return actions [T,D], states [T,D], timestamps [T]."""
    if action_key not in frames.columns:
        raise KeyError(f"action key '{action_key}' not in columns {list(frames.columns)}")
    if state_key not in frames.columns:
        raise KeyError(f"state key '{state_key}' not in columns {list(frames.columns)}")
    actions = _stack_numeric(frames[action_key])
    states = _stack_numeric(frames[state_key])
    if "timestamp" in frames.columns:
        timestamps = frames["timestamp"].to_numpy(dtype=np.float64)
    else:
        timestamps = np.arange(len(frames), dtype=np.float64)
    return actions, states, timestamps


def concat_cameras_robotwin(
    head: np.ndarray,
    left: np.ndarray,
    right: np.ndarray,
) -> np.ndarray:
    """
    T-layout used by Motus/RobotWin/FastWAM Franka:
      top: head (H,W)
      bottom: left|right each resized to (H/2, W/2)
    Returns uint8 RGB [H*1.5, W, 3]
    """
    if head.ndim != 3 or head.shape[2] != 3:
        raise ValueError(f"Expected HxWx3 head image, got {head.shape}")
    h, w = head.shape[:2]
    half_h, half_w = h // 2, w // 2
    left_r = _resize_hwc(left, (half_w, half_h))
    right_r = _resize_hwc(right, (half_w, half_h))
    bottom = np.concatenate([left_r, right_r], axis=1)
    if bottom.shape[1] != w:
        # Fix odd width
        bottom = _resize_hwc(bottom, (w, half_h))
    return np.concatenate([head, bottom], axis=0)


def concat_cameras_horizontal(images: Sequence[np.ndarray]) -> np.ndarray:
    """Horizontal stitch; resize all to first camera height."""
    if not images:
        raise ValueError("No images to concatenate")
    h = images[0].shape[0]
    resized = []
    for img in images:
        if img.shape[0] != h:
            new_w = int(round(img.shape[1] * (h / img.shape[0])))
            img = _resize_hwc(img, (new_w, h))
        resized.append(img)
    return np.concatenate(resized, axis=1)

"""Real-robot (Franka / Dobot / G1-D) Motus dataset adapters."""

from typing import Any

__all__ = ["RealRobotMotusDataset"]


def __getattr__(name: str) -> Any:
    if name == "RealRobotMotusDataset":
        from .base_dataset import RealRobotMotusDataset

        return RealRobotMotusDataset
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

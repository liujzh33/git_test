# Copyright 2024-2025 The Alibaba Wan Team Authors. All rights reserved.
import torch

try:
    import flash_attn_interface
    FLASH_ATTN_3_AVAILABLE = True
except ModuleNotFoundError:
    FLASH_ATTN_3_AVAILABLE = False

try:
    import flash_attn
    FLASH_ATTN_2_AVAILABLE = True
except ModuleNotFoundError:
    FLASH_ATTN_2_AVAILABLE = False


import warnings

__all__ = [
    'flash_attention',
    'attention',
]


def flash_attention(
    q,
    k,
    v,
    q_lens=None,
    k_lens=None,
    attn_mask=None,
    dropout_p=0.,
    softmax_scale=None,
    q_scale=None,
    causal=False,
    window_size=(-1, -1),
    deterministic=False,
    dtype=torch.bfloat16,
    version=None,
):
    """
    q:              [B, Lq, Nq, C1].
    k:              [B, Lk, Nk, C1].
    v:              [B, Lk, Nk, C2]. Nq must be divisible by Nk.
    q_lens:         [B].
    k_lens:         [B].
    attn_mask:      [B, Lq, Lk] or None. Custom attention mask (1=allow, 0=mask).
    dropout_p:      float. Dropout probability.
    softmax_scale:  float. The scaling of QK^T before applying softmax.
    causal:         bool. Whether to apply causal attention mask.
    window_size:    (left right). If not (-1, -1), apply sliding window local attention.
    deterministic:  bool. If True, slightly slower and uses more memory.
    dtype:          torch.dtype. Apply when dtype of q/k/v is not float16/bfloat16.
    """
    half_dtypes = (torch.float16, torch.bfloat16)
    assert dtype in half_dtypes
    assert q.device.type == 'cuda' and q.size(-1) <= 256

    # params
    b, lq, lk, out_dtype = q.size(0), q.size(1), k.size(1), q.dtype

    def half(x):
        return x if x.dtype in half_dtypes else x.to(dtype)

    # Check if custom attn_mask is provided (skip k_lens mechanism)
    # NOTE: attn_mask semantics - User's mask: True=allow, False=mask (blocked)
    #       PyTorch 2.9+ SDPA mask: True=allow, False=mask (compatible!)
    #       So we DON'T need to invert the mask!
    if attn_mask is not None:
        # Using scaled_dot_product_attention with custom mask
        # attn_mask shape: [B, Lq, Lk], True=allow, False=mask

        # Ensure mask matches actual q/k lengths
        Lq_actual = q.size(1)
        Lk_actual = k.size(1)
        attn_mask = attn_mask[:, :Lq_actual, :Lk_actual]

        # Directly use user's mask without inversion
        # (PyTorch SDPA: True=allow, False=mask, same as user's semantic)
        attn_mask_sdpa = attn_mask.unsqueeze(1)  # [B, 1, Lq, Lk]

        q = q.to(dtype).transpose(1, 2)  # [B, N, Lq, C]
        k = k.to(dtype).transpose(1, 2)  # [B, N, Lk, C]
        v = v.to(dtype).transpose(1, 2)  # [B, N, Lk, C]

        out = torch.nn.functional.scaled_dot_product_attention(
            q, k, v, attn_mask=attn_mask_sdpa, is_causal=causal, dropout_p=dropout_p
        )
        return out.transpose(1, 2).contiguous().type(out_dtype)

    # Standard Flash Attention path with k_lens
    # preprocess query
    if q_lens is None:
        q = half(q.flatten(0, 1))
        q_lens = torch.tensor(
            [lq] * b, dtype=torch.int32).to(
                device=q.device, non_blocking=True)
    else:
        q = half(torch.cat([u[:v] for u, v in zip(q, q_lens)]))

    # preprocess key, value
    if k_lens is None:
        k = half(k.flatten(0, 1))
        v = half(v.flatten(0, 1))
        k_lens = torch.tensor(
            [lk] * b, dtype=torch.int32).to(
                device=k.device, non_blocking=True)
    else:
        k = half(torch.cat([u[:v] for u, v in zip(k, k_lens)]))
        v = half(torch.cat([u[:v] for u, v in zip(v, k_lens)]))

    q = q.to(v.dtype)
    k = k.to(v.dtype)

    if q_scale is not None:
        q = q * q_scale

    if version is not None and version == 3 and not FLASH_ATTN_3_AVAILABLE:
        warnings.warn(
            'Flash attention 3 is not available, use flash attention 2 instead.'
        )

    # apply attention
    if (version is None or version == 3) and FLASH_ATTN_3_AVAILABLE:
        # Note: dropout_p, window_size are not supported in FA3 now.
        x = flash_attn_interface.flash_attn_varlen_func(
            q=q,
            k=k,
            v=v,
            cu_seqlens_q=torch.cat([q_lens.new_zeros([1]), q_lens]).cumsum(
                0, dtype=torch.int32).to(q.device, non_blocking=True),
            cu_seqlens_k=torch.cat([k_lens.new_zeros([1]), k_lens]).cumsum(
                0, dtype=torch.int32).to(q.device, non_blocking=True),
            seqused_q=None,
            seqused_k=None,
            max_seqlen_q=lq,
            max_seqlen_k=lk,
            softmax_scale=softmax_scale,
            causal=causal,
            deterministic=deterministic)[0].unflatten(0, (b, lq))
    elif FLASH_ATTN_2_AVAILABLE:
        x = flash_attn.flash_attn_varlen_func(
            q=q,
            k=k,
            v=v,
            cu_seqlens_q=torch.cat([q_lens.new_zeros([1]), q_lens]).cumsum(
                0, dtype=torch.int32).to(q.device, non_blocking=True),
            cu_seqlens_k=torch.cat([k_lens.new_zeros([1]), k_lens]).cumsum(
                0, dtype=torch.int32).to(q.device, non_blocking=True),
            max_seqlen_q=lq,
            max_seqlen_k=lk,
            dropout_p=dropout_p,
            softmax_scale=softmax_scale,
            causal=causal,
            window_size=window_size,
            deterministic=deterministic).unflatten(0, (b, lq))
    elif b == 1:
        # Single-sequence fast path (real-robot inference): no padding is needed
        # because there is exactly one sequence, so avoid the Python loop and the
        # data-dependent .item() slicing (q_lens[i]) and warnings.warn. Those
        # cause CPU<->GPU syncs / graph breaks that prevent CUDA-graph capture
        # and torch.compile fusion. q/k/v here are [total_tokens, N, C]; for b==1
        # total_tokens == lq/lk, so a plain unsqueeze + SDPA is exact.
        q_sdpa = q.unsqueeze(0).transpose(1, 2)  # [1, N, Lq, C]
        k_sdpa = k.unsqueeze(0).transpose(1, 2)  # [1, N, Lk, C]
        v_sdpa = v.unsqueeze(0).transpose(1, 2)  # [1, N, Lk, C]
        x = torch.nn.functional.scaled_dot_product_attention(
            q_sdpa, k_sdpa, v_sdpa,
            attn_mask=None,
            is_causal=causal,
            dropout_p=dropout_p,
            scale=softmax_scale,
        )
        x = x.transpose(1, 2)  # [1, Lq, N, C] == [b, lq, N, C]
        return x.type(out_dtype)
    else:
        warnings.warn(
            'Flash attention is not available, falling back to PyTorch SDPA. '
            'Performance may be degraded on variable-length sequences.'
        )
        cu_seqlens_q = torch.cat([q_lens.new_zeros([1]), q_lens]).cumsum(0, dtype=torch.int32).to(q.device, non_blocking=True)
        cu_seqlens_k = torch.cat([k_lens.new_zeros([1]), k_lens]).cumsum(0, dtype=torch.int32).to(q.device, non_blocking=True)

        q_padded = torch.zeros(b, lq, q.size(-2), q.size(-1), dtype=q.dtype, device=q.device)
        k_padded = torch.zeros(b, lk, k.size(-2), k.size(-1), dtype=k.dtype, device=k.device)
        v_padded = torch.zeros(b, lk, v.size(-2), v.size(-1), dtype=v.dtype, device=v.device)

        for i in range(b):
            q_padded[i, :q_lens[i]] = q[cu_seqlens_q[i]:cu_seqlens_q[i + 1]]
            k_padded[i, :k_lens[i]] = k[cu_seqlens_k[i]:cu_seqlens_k[i + 1]]
            v_padded[i, :k_lens[i]] = v[cu_seqlens_k[i]:cu_seqlens_k[i + 1]]

        q_sdpa = q_padded.transpose(1, 2)
        k_sdpa = k_padded.transpose(1, 2)
        v_sdpa = v_padded.transpose(1, 2)

        x = torch.nn.functional.scaled_dot_product_attention(
            q_sdpa, k_sdpa, v_sdpa,
            attn_mask=None,
            is_causal=causal,
            dropout_p=dropout_p,
            scale=softmax_scale,
        )
        x = x.transpose(1, 2)
        out_list = []
        for i in range(b):
            out_list.append(x[i, :q_lens[i]])
        x = torch.cat(out_list, dim=0).unflatten(0, (b, lq))

    # output
    return x.type(out_dtype)


def attention(
    q,
    k,
    v,
    q_lens=None,
    k_lens=None,
    attn_mask=None,
    dropout_p=0.,
    softmax_scale=None,
    q_scale=None,
    causal=False,
    window_size=(-1, -1),
    deterministic=False,
    dtype=torch.bfloat16,
    fa_version=None,
):
    if FLASH_ATTN_2_AVAILABLE or FLASH_ATTN_3_AVAILABLE:
        return flash_attention(
            q=q,
            k=k,
            v=v,
            q_lens=q_lens,
            k_lens=k_lens,
            attn_mask=attn_mask,
            dropout_p=dropout_p,
            softmax_scale=softmax_scale,
            q_scale=q_scale,
            causal=causal,
            window_size=window_size,
            deterministic=deterministic,
            dtype=dtype,
            version=fa_version,
        )
    else:
        if q_lens is not None or k_lens is not None:
            warnings.warn(
                'Padding mask is disabled when using scaled_dot_product_attention. It can have a significant impact on performance.'
            )
        attn_mask = None

        q = q.transpose(1, 2).to(dtype)
        k = k.transpose(1, 2).to(dtype)
        v = v.transpose(1, 2).to(dtype)

        out = torch.nn.functional.scaled_dot_product_attention(
            q, k, v, attn_mask=attn_mask, is_causal=causal, dropout_p=dropout_p)

        out = out.transpose(1, 2).contiguous()
        return out

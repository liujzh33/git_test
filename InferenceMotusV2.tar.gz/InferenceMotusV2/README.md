# InferenceMotusV2 — G1 实机推理代码包（审核版）

本目录是从原始开发环境中抽取的 **MotusV2 G1-D 实机推理** 所需全部代码与配置文件的自包含副本，供审核官检查调用链完整性与代码逻辑。

> **说明**：预训练模型权重、T5 缓存、数据集等大体积二进制资源 **未打包**，仅在本文档标注其原始路径。`unitree_lerobot` 仓库也 **未打包**（共用基础设施），仅标注其路径与被引用的模块。

---

## 1. 目录结构

```
InferenceMotusV2/
├── README.md                              ← 本文件
├── scripts/
│   ├── inference_motusv2.sh               ← 入口 shell 脚本（已改写路径指向本目录）
│   ├── eval_g1_motus.py                   ← 推理主循环
│   └── motusv2_adapter/
│       ├── __init__.py
│       └── adapter.py                     ← MotusV2PolicyAdapter（路径自动解析到 ../policy/）
├── policy/
│   └── MotusWanVlmDirectMaskMotion/       ← MotusV2 策略实现（从原仓库完整复制）
│       ├── models/                        ← 模型定义
│       ├── bak/wan/                       ← WAN 2.2 骨干（legacy，被 models/ import）
│       └── utils/                         ← 图像/调度器等工具
└── configs/
    └── g1d_pick_kettle_wan_vlm_mask.yaml  ← 推理配置
```

---

## 2. 运行入口

```bash
bash /home/unitree/codes/temp/InferenceMotusV2/scripts/inference_motusv2.sh
```

脚本做了以下事情：
1. `cd` 到 `unitree_lerobot` 仓库（真机接口依赖，未打包）。
2. 设置 `PYTHONPATH` = `unitree_lerobot` : `InferenceMotusV2/scripts/`。
3. 调用 `InferenceMotusV2/scripts/eval_g1_motus.py`，传入权重/数据/配置路径。

---

## 3. 完整调用链（逐文件）

### 3.1 第一层：入口脚本

| 文件 | 作用 |
|---|---|
| `scripts/inference_motusv2.sh` | 设置环境变量、`PYTHONPATH`，定义路径变量，启动 Python |

### 3.2 第二层：推理主循环

| 文件 | 作用 |
|---|---|
| `scripts/eval_g1_motus.py` | G1 实机 eval 主循环：图像采集 → 策略推理 → IK → 控制循环 |

**关键导入**：
```python
# 来自 unitree_lerobot（未打包，外部依赖）
from unitree_lerobot.eval_robot.make_robot import (
    setup_image_client, setup_robot_interface, process_images_and_observations,
)
from unitree_lerobot.eval_robot.utils.utils import to_list, to_scalar

# 来自本包
from motusv2_adapter.adapter import MotusV2PolicyAdapter
```

### 3.3 第三层：策略适配器

| 文件 | 作用 |
|---|---|
| `scripts/motusv2_adapter/adapter.py` | `MotusV2PolicyAdapter`：桥接 MotusV2 模型到 G1 eval loop |

**路径解析逻辑**（`adapter.py:14-27`）：
```python
_MOTUS_ROOT  = .../InferenceMotusV2/          # adapter.py 上溯三级
_POLICY_DIR  = _MOTUS_ROOT/policy/MotusWanVlmDirectMaskMotion
_MODELS_DIR  = _POLICY_DIR/models
_BAK_DIR     = _POLICY_DIR/bak
_UTILS_DIR   = _POLICY_DIR/utils
```
上述路径被 `sys.path.insert(0, ...)` 插到最前，确保 `import models.*`、`import wan.*`、`import utils.*` 解析到 `policy/.../` 下的副本。

**关键导入**：
```python
from models.motus_wan_vlm_direct_mask import MotusWanVlmDirectMask, MotusWanVlmDirectMaskConfig
from wan.modules.t5 import T5EncoderModel
from utils.image_utils import resize_with_padding
from utils.vlm_utils import preprocess_vlm_messages
```

### 3.4 第四层：MotusV2 策略实现

所有文件位于 `policy/MotusWanVlmDirectMaskMotion/`。

#### `models/` — 模型定义

| 文件 | 类 / 功能 | 被 import 自 |
|---|---|---|
| `motus_wan_vlm_direct_mask.py` | `MotusWanVlmDirectMask` 主模型 + Config，含 `inference_step` | `adapter.py`, `models/__init__.py` |
| `wan_model_mask.py` | `WanVideoModel` — WAN 5B 视频编/解码 | `motus_wan_vlm_direct_mask.py` |
| `action_expert.py` | `ActionExpert` — DiT 动作预测 | `motus_wan_vlm_direct_mask.py` |
| `qwen3_module_wan.py` | `Qwen3VLWanModule` — Qwen3-VL 逐层 hidden states | `motus_wan_vlm_direct_mask.py` |
| `__init__.py` | 导出上述四个类 | — |

#### `bak/wan/` — WAN 2.2 骨干（legacy）

| 文件 | 类 / 功能 | 被 import 自 |
|---|---|---|
| `modules/t5.py` | `T5EncoderModel`, `T5Encoder`, `T5Decoder` | `adapter.py`, `bak/wan/modules/__init__.py` |
| `modules/tokenizers.py` | `HuggingfaceTokenizer` | `t5.py` |
| `modules/model.py` | `WanModel`, `WanRMSNorm`, `WanLayerNorm`, `sinusoidal_embedding_1d`, `rope_apply` | `qwen3_module_wan.py`, `action_expert.py`, `bak/wan/modules/__init__.py` |
| `modules/model_mask.py` | `WanModel`（mask 版）, `sinusoidal_embedding_1d` | `wan_model_mask.py`, `motus_wan_vlm_direct_mask.py` |
| `modules/attention.py` | `flash_attention` | `model.py`, `action_expert.py`, `bak/wan/modules/__init__.py` |
| `modules/attention_mask.py` | `flash_attention`（mask 版） | `model_mask.py` |
| `modules/vae2_2.py` | `Wan2_2_VAE` | `wan_model_mask.py`, `bak/wan/modules/__init__.py` |
| `modules/vae2_1.py` | VAE 2.1（未使用，`__init__.py` 未导出） | — |
| `modules/__init__.py` | 统一导出 | — |
| `utils/fm.py` | `FlowMatchScheduler` | `motus_wan_vlm_direct_mask.py` |
| `utils/fm_solvers_unipc.py` | `FlowUniPCMultistepScheduler` | `motus_wan_vlm_direct_mask.py` |
| `utils/qwen_vl_utils.py` | `process_vision_info`（`qwen_vl_utils` 包缺失时的回退） | `adapter.py` 回退路径 |
| `utils/__init__.py` | — | — |
| `__init__.py` | — | — |

> `bak/qwen2_5_vl/` 为 Qwen2.5-VL 的 HF 兼容代码，推理时由 `transformers` 自动加载 Qwen3-VL，不会直接 import，但随 `bak/` 一并保留。

#### `utils/` — 工具函数

| 文件 | 类 / 功能 | 被 import 自 |
|---|---|---|
| `image_utils.py` | `resize_with_padding` — T 形图像拼接 | `adapter.py` |
| `vlm_utils.py` | `preprocess_vlm_messages` | `adapter.py` |
| `common.py` | `get_t_distribution` 等通用工具 | `motus_wan_vlm_direct_mask.py` |
| `scheduler.py` | LR scheduler（训练用，推理不调用） | — |
| `checkpointer.py` | checkpoint 工具（训练用） | — |
| `fm_solvers.py` | FM solver（训练用） | — |
| `__init__.py` | — | — |

### 3.5 第五层：配置

| 文件 | 作用 |
|---|---|
| `configs/g1d_pick_kettle_wan_vlm_mask.yaml` | 定义 action_dim=16、video 384x320x8、inference timesteps=10、WAN/VLM 路径等 |

---

## 4. 外部依赖（未打包，需在运行环境存在）

### 4.1 预训练模型权重与数据

| 变量 | 原始路径 | 说明 |
|---|---|---|
| `CHECKPOINT_PATH` | `/home/unitree/pretrained_models/ckpts/WamVlmMask_g1d_pick_kettle_2w` | MotusV2 策略权重（DeepSpeed checkpoint） |
| `WAN_PATH` | `/home/unitree/pretrained_models/Wan2.2-TI2V-5B` | WAN 5B 模型目录，含 `Wan2.2_VAE.pth`、`models_t5_umt5-xxl-enc-bf16.pth`、`google/umt5-xxl/` |
| `VLM_PATH` | `/home/unitree/pretrained_models/Qwen3-VL-2B-Instruct` | Qwen3-VL 2B 模型目录 |
| `T5_CACHE_DIR` | `/home/unitree/codes/temp/t5_cache_pick-kettle-and-cup` | UMT5-XXL 文本 embedding 缓存目录 |
| `DATASET_ROOT` | `/home/unitree/datasets/pick-kettle-and-cup` | LeRobot 数据集，读取 `data/chunk-000/*.parquet` 中的 `observation.state` 作为初始位姿 |

### 4.2 unitree_lerobot 仓库

路径：`/home/unitree/codes/unitree_lerobot/`

推理实际调用的模块（`--arm=G1_29 --ee=dex1` 配置下）：

| 模块路径 | 类 / 函数 |
|---|---|
| `unitree_lerobot/eval_robot/make_robot.py` | `setup_image_client`, `setup_robot_interface`, `process_images_and_observations` |
| `unitree_lerobot/eval_robot/utils/utils.py` | `to_list`, `to_scalar` |
| `unitree_lerobot/eval_robot/image_server/image_client.py` | `ImageClient` |
| `unitree_lerobot/eval_robot/robot_control/robot_arm.py` | `G1_29_ArmController`, `G1_23_ArmController` |
| `unitree_lerobot/eval_robot/robot_control/robot_arm_ik.py` | `G1_29_ArmIK`, `G1_23_ArmIK` |
| `unitree_lerobot/eval_robot/robot_control/robot_hand_unitree.py` | `Dex1_1_Gripper_Controller`, `Dex3_1_Controller` |
| `unitree_lerobot/eval_robot/robot_control/robot_hand_inspire.py` | `Inspire_Controller`（被 import 但未实例化） |
| `unitree_lerobot/eval_robot/robot_control/robot_hand_brainco.py` | `Brainco_Controller`（被 import 但未实例化） |
| `unitree_lerobot/eval_robot/robot_control/mobile_control.py` | `G1_Mobile_Lift_Controller`（被 import 但未实例化） |
| `unitree_lerobot/eval_robot/utils/episode_writer.py` | `EpisodeWriter`（仅 sim 模式） |
| `lerobot/utils/utils.py` | `init_logging`（`eval_g1_motus.py` `__main__` 中调用） |

### 4.3 pip 包

`transformers`、`diffusers`、`deepspeed`、`imageio`、`safetensors`、`einops`、`ftfy`、`regex`、`pyarrow`、`opencv-python`、`logging_mp`、`qwen_vl_utils`、`lerobot`、`unitree_sdk2py`、`torch`、`numpy`、`Pillow`、`PyYAML`

---

## 5. 数据流概要

```
inference_motusv2.sh
  └─ eval_g1_motus.py::run_eval()
       ├─ setup_image_client()          → ImageClient (ZMQ 图像)
       ├─ setup_robot_interface()       → G1_29_ArmController + G1_29_ArmIK + Dex1 gripper
       ├─ MotusV2PolicyAdapter(...)     → 加载模型/T5/VLM processor
       ├─ _load_initial_pose_from_dataset()  → 读 parquet 初始位姿
       ├─ _move_robot_to_pose()         → 插值移动到初始位姿
       └─ 控制循环 (30Hz):
            ├─ [predict] process_images_and_observations()  → 4 相机图像 + arm_q
            ├─ [predict] policy.observation_to_model_input() → T 形拼接 + state 重排
            ├─ [predict] policy.predict_action_chunk()
            │    ├─ _get_t5_embedding()        → T5 编码指令 (带磁盘缓存)
            │    ├─ preprocess_vlm_messages()  → VLM 输入预处理
            │    └─ model.inference_step()      → WAN+VLM+ActionExpert 联合推理
            ├─ [cached] policy.step()          → 从 action_queue 弹出下一帧
            ├─ arm_ik.solve_tau(arm_action)    → 前馈力矩
            ├─ arm_ctrl.ctrl_dual_arm(q, tau)  → 发送关节指令
            └─ _write_gripper()                → 夹爪控制
```

---

## 6. 与原环境的对应关系

| 本包路径 | 原始路径 |
|---|---|
| `InferenceMotusV2/scripts/inference_motusv2.sh` | `/home/unitree/scripts/inference_motusv2.sh` |
| `InferenceMotusV2/scripts/eval_g1_motus.py` | `/home/unitree/scripts/eval_g1_motus.py` |
| `InferenceMotusV2/scripts/motusv2_adapter/` | `/home/unitree/scripts/motusv2_adapter/` |
| `InferenceMotusV2/policy/MotusWanVlmDirectMaskMotion/` | `/home/unitree/codes/temp/MotusV2/policy/MotusWanVlmDirectMaskMotion/` |
| `InferenceMotusV2/configs/g1d_pick_kettle_wan_vlm_mask.yaml` | `/home/unitree/codes/temp/MotusV2/configs/g1d_pick_kettle_wan_vlm_mask.yaml` |

**唯一修改**：`inference_motusv2.sh` 中的路径变量改为指向 `InferenceMotusV2/` 本目录（`CONFIG_PATH`、`python` 脚本路径、`PYTHONPATH` 中的 scripts 段）。`adapter.py` 路径解析基于自身相对位置，**未做任何修改**，在新结构下自动正确解析。

---

## 7. Ubuntu 24.04 + 双 RTX 5090 环境安装

适用目标为 `x86_64`、Ubuntu 24.04、RTX 5090（compute capability 12.0）和
NVIDIA Driver `>=580.65.06`。安装前需要把本目录和包含完整 `lerobot`
子模块的 `unitree_lerobot` 仓库复制到工作站。

```bash
cd /path/to/InferenceMotusV2
bash scripts/install_motus_5090.sh \
  --unitree-root /path/to/unitree_lerobot
```

安装器会创建全新的 `inference_motus` Conda 环境并自动执行无机器人连接的
GPU、依赖导入和 G1 IK 验收。若同名环境已经存在，安装器会停止；确认可以删除后
显式传入 `--recreate`。

```bash
conda activate inference_motus
python scripts/verify_motus_5090_env.py \
  --unitree-root /path/to/unitree_lerobot
```

环境采用 Python 3.10、PyTorch 2.12.1 + CUDA 13.0 和 torchvision 0.27.1。
Python 3.10 是为了同时满足 Unitree 的版本约束，并直接使用包含 CycloneDDS
0.10.2 C 库的官方二进制 wheel。PyTorch wheel 自带 CUDA runtime，因此不安装
也不要求 `/usr/local/cuda`；现有 NVIDIA 驱动无需改动。

安装器不会下载模型权重、数据集或 T5 cache，也不会修改
`scripts/inference_motusv2.sh` 中的部署路径。当前 Motus 推理代码默认使用单个
CUDA device，第二张 5090 不会自动用于模型并行。

---

## 8. FastWAM 后训练策略（同步推理）

第二套策略后端。硬件层（`unitree_lerobot` 的相机、DDS 机械臂、Dex1 夹爪）完全复用，
**未改动第 2–6 节描述的任何 MotusV2 文件**；只是把策略换成 FastWAM。

```bash
bash /path/to/InferenceMotusV2/scripts/inference_fastwam_g1d.sh
```

### 8.1 与 MotusV2 路径的差异

| | MotusV2 (eef_delta) | FastWAM (本节) |
|---|---|---|
| 动作表示 | 16 维笛卡尔 offset，需 FK/IK | **16 维绝对 qpos，重排后即关节指令** |
| 归一化 | eef_stats.json | **identity（原始弧度，无统计文件）** |
| 相机拼接 | `aspect`：240×320 头部 + 120×160 腕部，上下留黑边 | **RoboTwin T：256×320 头部 + 2×128×160 腕部，正好铺满 384×320** |
| 图像值域 | `[0, 1]` | **`[-1, 1]`** |
| 文本条件 | UMT5 embedding，key = sha1(instruction) | **Wan2.2 UMT5 context `[128, 4096]`，key = sha256(完整训练 prompt)** |
| chunk | 64 动作 × interp 1 = 2.13 s | **32 动作 × interp 1 = 1.07 s** |
| 循环 | 串行 / 可选 async + RTC | **仅同步**，一个 chunk 跑完再推理 |
| 额外依赖 | pinocchio / casadi | 无（`einops`、`imageio`、`rich` 等小包） |

相机拼接与值域这两条是静默失败点：分辨率相同、画面不同，用错了不会报错，只会让
轨迹整体变形。`scripts/tests/test_fastwam_adapter_wiring.py` 中的图像 parity 测试
就是为此而设，它把同一帧同时喂给适配器和真实训练管线并要求逐元素相等。

### 8.2 新增文件

| 路径 | 作用 |
|---|---|
| `scripts/inference_fastwam_g1d.sh` | 入口脚本，路径全部相对 bundle 解析 |
| `scripts/eval_g1_fastwam.py` | 同步推理主循环 |
| `scripts/fastwam_adapter/adapter.py` | `FastWAMPolicyAdapter`，接口与 `MotusV2PolicyAdapter` 一致 |
| `scripts/fastwam_adapter/debug.py` | 诊断日志（`--debug_log`） |
| `policy/FastWAM/src/fastwam/` | FastWAM 推理闭包（29 个文件，从训练仓库原样复制） |
| `configs/g1d_fastwam_mixed.yaml` | `task=g1d_mixed_uncond_3cam_384_5e-5` 解析后的训练配置 |
| `scripts/tests/test_fastwam_adapter_wiring.py` | 契约 / 重排 / 图像 parity / 队列 / 保护，不加载模型 |
| `scripts/tests/test_fastwam_smoke_gpu.py` | 端到端连通性，需 GPU 与 Wan2.2 VAE |

`policy/FastWAM/src/` 只包含推理实际用到的部分：`fastwam/models/`、`fastwam/utils/`、
`fastwam/datasets/dataset_utils.py`。`trainer.py`、`runtime.py` 与
`datasets/lerobot/` 被刻意排除，它们在模块顶层 import accelerate / hydra / GitPython，
机器人上没有理由携带。同步命令见 `adapter.py::_resolve_fastwam_src` 的报错信息；
`test_fastwam_adapter_wiring.py` 会逐字节校验这份副本与训练仓库一致。

### 8.3 需要从训练机拷贝的三样东西

它们属于 **checkpoint 而不是机器人**，必须与权重一起搬运：

1. `<output_dir>/checkpoints/weights/step_XXXXXX.pt` — 权重
2. `<output_dir>/config.yaml` — chunk 几何、相机拼接、归一化模式。bundle 内已附
   `configs/g1d_fastwam_mixed.yaml` 作为默认值；只有改过训练配方才需要替换
3. `FastWAM/data/text_embeds_cache/g1d_mixed/*.pt` — 指令的 UMT5 embedding，
   放进 `assets/t5_cache_g1d_fastwam/`。缺失或过期都是静默错误，因此适配器在
   **启动时**（而非第一个控制周期）就解析它并在缺失时报出期望的文件名

   ```bash
   # 在训练机上生成
   python scripts/precompute_text_embeds.py task=g1d_mixed_uncond_3cam_384_5e-5
   ```

`WAN_PATH` 与 MotusV2 共用，无需拷贝：serving 只读 `Wan2.2_VAE.pth`（DiT 由
checkpoint 覆盖，UMT5 由 T5 cache 取代）。适配器会自动建一个符号链接，把这个扁平
目录变成加载器期望的 `<base>/Wan-AI/Wan2.2-TI2V-5B/` 结构。

### 8.4 时序

RTX 5090 上实测：构建 34 s，预热后单次推理 376 ms（10 步去噪）。一个 chunk 是
1.07 s 的动作，因此同步循环中机械臂每跑 1.07 s 会保持末次指令约 0.4 s。Thor 上会
更慢，若停顿过长，依次考虑降低 `NUM_INFERENCE_STEPS`、或调大
`ACTION_INTERP_FACTOR` 把同一条轨迹拉长。`REPLAN_STEPS` 只会让停顿更频繁。

---

## 9. Motus（Stage-3）后训练策略（同步推理）

第三套策略后端，对应 `/home/work/wenjj/Motus`（三模态 WAN + Action Expert +
Understanding Expert，类名 `Motus`），用 `scripts/train_g1d.sh` 后训练。

> **命名**：本节的 Motus **不是** MotusV2（`MotusWanVlmDirectMask`）。第 2–6 节的
> `eval_g1_motus.py` 驱动的是 MotusV2。两者共用 Wan2.2 骨干但是不同的网络、不同的
> 权重。三条路径互不 import，硬件层完全复用。

```bash
bash /path/to/InferenceMotusV2/scripts/inference_motus_g1d.sh
```

### 9.1 三条路径对照

| | MotusV2 (eef_delta) | FastWAM | **Motus（本节）** |
|---|---|---|---|
| 动作表示 | 笛卡尔 offset + IK | 绝对 qpos | **绝对 qpos** |
| 归一化 | eef_stats.json | identity | **normalization: false** |
| 相机拼接 | `aspect`：分区域 resize | RoboTwin T：256×320 + 2×128×160，铺满 | **原分辨率拼接（720×640）后整体 letterbox → 上下各 12 行黑边** |
| resize 后端 | — | torchvision bilinear | **Pillow BILINEAR** |
| 图像值域 | `[0, 1]` | `[-1, 1]` | **`[0, 1]`**（模型内部转 `[-1, 1]`） |
| 文本 key | sha1(instruction) | sha256(完整 prompt) | **sha1(instruction)**，与 MotusV2 相同 |
| chunk | 64 | 32 | **48**（pick/pour）/ **16**（mixed） |
| 单次推理 @10 步 | ~920 ms (5 步, Thor) | 376 ms (5090) | **1777 ms (5090)** |

**注意 `g1d_mixed.yaml` 的注释有误**：文件里写 `# action_chunk = 24`，但
`num_video_frames(8) × video_action_freq_ratio(2) = 16`，`MotusConfig` 实际用的是
16（0.53 s @ 30 Hz）。适配器按公式计算，测试里钉住的也是 16。

**resize 后端是个静默陷阱**：Motus 仓库里有两份 `image_utils.py`，
`data/utils/`（训练用，Pillow BILINEAR）和
`inference/real_world/Motus/utils/`（cv2.resize）。这条管线要把 720×640 缩到
360×320，正是两种滤波差异最大的区间——实测逐像素最大差 0.32。因此本包 vendor 的是
**训练那一份**，`test_motus_adapter_wiring.py` 里有一条测试专门证明两者不等价。

### 9.2 新增文件

| 路径 | 作用 |
|---|---|
| `scripts/inference_motus_g1d.sh` | 入口脚本 |
| `scripts/eval_g1_motus_stage3.py` | 同步推理主循环 |
| `scripts/motus_adapter/adapter.py` | `MotusPolicyAdapter`，接口与另两个适配器一致 |
| `scripts/motus_adapter/debug.py` | 诊断日志（`--debug_log`） |
| `policy/Motus/` | Motus 推理闭包（41 个文件，从训练仓库原样复制） |
| `configs/g1d_motus_{pick_kettle,pour_beans,mixed}.yaml` | 三份训练配置，`CONFIG_PATH` 选择 |
| `scripts/tests/test_motus_adapter_wiring.py` | 19 条：契约 / 重排 / 图像 parity / 滤波 / 队列 / 保护 |
| `scripts/tests/test_motus_smoke_gpu.py` | 端到端连通性，需 GPU |

`policy/Motus/` 包含 `models/`、`bak/wan/`、`utils/`，以及
`data/utils/image_utils.py` + `data/real_robot/common.py`（拼接与 qpos 重排）。
适配器直接调用训练函数（`concat_cameras_robotwin`、`resize_with_padding`、
`tensor_to_pil`、`unify_g1d_qpos_to_16`、`preprocess_vlm_messages`）而不是重写，
测试会逐字节校验这份副本与训练仓库一致。

### 9.3 两个环境细节

- **DeepSpeed**：`models/motus.py` → `utils/common.py` → `import deepspeed.comm.comm`，
  DeepSpeed 在 import 时会探测 `$CUDA_HOME/bin/nvcc`，即便这条路径不编译任何 CUDA
  算子。部署环境的 PyTorch wheel 自带 runtime、通常没有系统 toolkit，因此适配器在
  `CUDA_HOME` 不可用时会自动放一个只回答 `--version` 的 nvcc stub（与
  `Motus/scripts/train_g1d.sh` 的做法一致），而不是去 stub Python 模块。
- **VAE decode**：`inference_step` 总是解码预测视频并返回，控制器用不到。默认在调用
  期间把 `video_model.decode_video` 换掉以跳过（vendor 的模型代码保持逐字节不变），
  实测省 274 ms / 16%。想看模型"想象"的画面时把 `DECODE_VIDEO=1`。

### 9.4 时序（RTX 5090，跳过 VAE decode）

| 去噪步数 | 单次推理 | 相对 1.60 s chunk |
|---|---|---|
| 1 | 237 ms | 15% |
| 2 | 403 ms | 25% |
| 5 | 918 ms | 57% |
| 10（配置默认） | 1777 ms | **111%** |

拟合：`66 ms 固定 + 171 ms/步`。构建约 104 s。

10 步下机械臂静止的时间比运动还长，Thor 上只会更糟。优先级：先降
`NUM_INFERENCE_STEPS=5`；再考虑 `ACTION_INTERP_FACTOR=2`（同一轨迹拉到 3.2 s，代价
是半速）；最后是把 `und_module.extract_und_features` 提出去噪循环——它每步都在对
不变的输入重算一次（35 ms × 9 = 319 ms，占 18%），提出去是等价变换，但那要改模型
代码，所以本包没有动。

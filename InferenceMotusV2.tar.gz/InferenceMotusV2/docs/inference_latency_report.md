# MotusV2 推理时延测试报告

## 测试环境

| 项目 | 配置 |
|------|------|
| GPU | NVIDIA Thor (Tegra) |
| 驱动版本 | 580.00 |
| CUDA 版本 | 13.0 |
| Conda 环境 | inference_motus |
| 模型 | MotusWanVlmDirectMask |
| Checkpoint | WamVlmMask_g1d_pick_kettle_2w |
| VLM | Qwen3-VL-2B-Instruct |
| 视频骨干 | Wan2.2-TI2V-5B |
| 视频分辨率 | 384×320 (H×W) |
| state_dim / action_dim | 16 / 16 |
| action chunk 形状 | [1, 16, 16] |
| 精度 | bfloat16 |
| Flash Attention | 未启用（回退至 PyTorch SDPA） |
| 指令 | "拿起水杯和茶壶，并倒水" |
| 输入 | 随机图像 + 零状态（dry-run） |

## 测试脚本

- 参考脚本: `/home/unitree/scripts/test_motusv2_inference.py`
- Profiling 脚本: `/tmp/opencode/profile_motus.py`
- 纯推理 benchmark（无 VAE decode）: `/home/unitree/tmp/bench10.py`
- 真机评测脚本: `/home/unitree/scripts/eval_g1_motus.py`（入口: `/home/unitree/scripts/inference_motusv2.sh`）
- 策略适配器: `/home/unitree/scripts/motusv2_adapter/adapter.py`

## 端到端时延

### num_inference_steps=2

| Run | 耗时 |
|-----|------|
| 1 (warmup) | 8.261s |
| 2 (异常尖峰) | 80.303s |
| 3 | 1.942s |
| 4 | 1.889s |
| 5 | 1.886s |

**稳定后单次推理时延 ≈ 1.9s**

### num_inference_steps=10

| Run | 耗时 |
|-----|------|
| 1 (warmup) | 5.417s |
| 2 | 4.953s |
| 3 | 4.894s |

**稳定后单次推理时延 ≈ 4.9s**（含 VAE decode）

### num_inference_steps=10, decode_video=False（跳过 VAE 解码）

代码修改后 `inference_step` 新增 `decode_video` 参数，跳过 ~1s 的 VAE 解码：

| Run | 耗时 |
|-----|------|
| 1 (warmup) | 3.550s |
| 2 | 3.507s |
| 3 | 3.524s |

**稳定后单次推理时延 ≈ 3.5s**（纯推理脚本，无后台进程）

> 注：2 步约 1.9s，10 步约 4.9s，去噪步数从 2 增至 10（5 倍），时延增至约 2.6 倍，并非严格线性，说明去噪循环外的固定开销（VAE 编解码、VLM 特征提取等）占有一定比例。

## 各模块时延分解（num_inference_steps=10）

> 测试方式：在 warmup 后运行 1 次，每个模块前后插入 `torch.cuda.synchronize()` 进行精确计时。
> 注意：由于每处 synchronize 会打断 GPU 流水线并行，各模块计时之和（8.44s）高于端到端无打断的时延（4.9s）。以下数据主要用于分析各模块的**相对占比**。

| 模块 | 耗时 | 占比 | 说明 |
|------|------|------|------|
| 4b_time_embedding | 3.805s | 45.1% | 时间嵌入 + AdaLN 调制参数计算（10步×30层） |
| 4c_joint_attention | 1.952s | 23.1% | 三模态联合注意力（WAN+Action+VLM，30层×10步） |
| 5_vae_decode | 1.046s | 12.4% | VAE 解码视频 latent（仅 1 次） |
| 4e_ffn | 0.774s | 9.2% | WAN/Action/VLM 三路 FFN（30层×10步） |
| 4d_cross_attention | 0.678s | 8.0% | WAN 与 T5 文本嵌入的交叉注意力（30层×10步） |
| 2_vlm_extract_features | 0.092s | 1.1% | Qwen3-VL 逐层特征提取（仅 1 次） |
| 1_vae_encode | 0.070s | 0.8% | VAE 编码首帧（仅 1 次） |
| 4f_heads_euler | 0.014s | 0.2% | 输出头 + Euler 积分（10步） |
| 4a_prepare_input | 0.008s | 0.1% | token 准备（video/action token 构造，10步） |
| 3_t5_preprocess | 0.001s | 0.0% | T5 嵌入预处理（仅 1 次） |
| **TOTAL** | **8.440s** | 100% | |

## 瓶颈分析

### 1. Time Embedding（45.1%）— 最大瓶颈

- 包含每步去噪中的 `get_time_embedding` 和 30 层的 `compute_adaln_modulation`。
- 10 步去噪共执行 10 次，是累计耗时最大的模块。
- 优化方向：缓存/预计算 AdaLN 调制参数（若 timestep 接近可复用）；减少 float32 计算。

### 2. Joint Attention（23.1%）— 第二大瓶颈

- 三模态（WAN + Action + VLM）联合注意力，30 层 × 10 步 = 300 次注意力计算。
- 当前未启用 Flash Attention，回退到 PyTorch SDPA，性能受损。
- 优化方向：启用 Flash Attention（需安装 `flash-attn`）；考虑对 VLM token 做长度裁剪。

### 3. VAE Decode（12.4%）— 已优化

- 仅执行 1 次，但 VAE 解码 384×320 视频帧开销较大。
- **已实现 `decode_video=False` 参数**，真机控制时跳过 VAE 解码，节省 ~1s（4.9s→3.5s）。

### 4. FFN + Cross Attention（17.2%）

- FFN 占 9.2%，Cross Attention 占 8.0%，均为 30 层 × 10 步的循环内计算。
- 优化方向：与 Joint Attention 一并考虑算子融合或精度优化。

## 优化建议汇总

| 优先级 | 优化方向 | 预期收益 |
|--------|----------|----------|
| 高 | 启用 Flash Attention | 降低 Joint Attention 耗时，预计节省 20-30% |
| 高 | 预计算/缓存 Time Embedding & AdaLN | 降低 Time Embedding 耗时，预计节省 15-25% |
| ~~中~~ | ~~仅输出 action 时跳过 VAE 解码~~ | **已实现**（`decode_video=False`，节省 ~1s，4.9s→3.5s） |
| 中 | 减少去噪步数（如 10→4，配合更好的 ODE solver） | 近线性降低循环内开销 |
| 中 | 降低真机评测后台线程资源竞争 | 预计将真机推理从 ~7.5s 降至接近 ~3.5s |
| 低 | VLM token 长度裁剪 | 降低 Attention 和 FFN 开销 |
| 低 | 算子融合（FFN + Cross Attention） | 小幅降低循环内开销 |

## 复现方法

```bash
conda activate inference_motus

# 端到端时延测试（10步，含 VAE decode）
python -u /tmp/opencode/bench10.py

# 端到端时延测试（10步，跳过 VAE decode，即 decode_video=False）
python -u /home/unitree/tmp/bench10.py

# 各模块 profiling（10步）
python -u /tmp/opencode/profile_motus.py

# 真机评测（含机器人控制后台进程）
bash /home/unitree/scripts/inference_motusv2.sh

# 对比真实图像 vs 随机图像的 VLM token 和推理时延
python -u /tmp/opencode/compare_real_vs_rand.py
```

## 注意事项

1. **显存管理**：循环推理必须使用 `torch.no_grad()`，否则计算图累积会导致显存占满、机器崩溃重启。
2. **Warmup**：首次推理因 CUDA kernel 编译/cuDNN autotuning 耗时显著偏高，测试时需跳过第一次。
3. **Flash Attention**：当前环境 Flash Attention 不可用，回退至 PyTorch SDPA，性能受损。日志中可见警告：
   > `Flash attention is not available, falling back to PyTorch SDPA. Performance may be degraded on variable-length sequences.`
4. **Profiling 精度**：带 `torch.cuda.synchronize()` 的分模块计时会打断 GPU 流水线，各模块之和高于端到端时延，仅用于分析相对占比。

---

## 真机评测 vs 纯推理脚本时延差异分析

### 现象

在 `num_inference_steps=10`、`decode_video=False` 的相同条件下：

| 场景 | 脚本 | 纯 `inference_step` 耗时 |
|------|------|--------------------------|
| 纯推理（无后台进程） | `/home/unitree/tmp/bench10.py` | **~3.5s** |
| 真机评测（带机器人控制） | `/home/unitree/scripts/eval_g1_motus.py` | **~7.5s** |

真机评测日志（`adapter.py:454`）显示 `model_forward=7625.7ms`，且该计时不包含 T5 编码和 VLM 预处理（已分开计时）。

### 排除的因素

通过对照实验逐一排查：

| 假设 | 实验方法 | 结论 |
|------|----------|------|
| 图像内容不同导致 VLM token 数不同 | 对比随机图像 vs 真实数据集图像的 VLM 输入 | ❌ 完全一致：input_ids=139, pixel_values=[480,1536], grid_thw=[1,24,20] |
| 真实图像 vs 随机图像计算量不同 | 同模型同输入分别计时 | ❌ ratio=0.99x，无差异 |
| `decode_video` 参数不同 | 检查 adapter 代码 | ❌ 两边都传 `decode_video=False`（adapter.py:446） |
| 代码版本不同 | 对比 3 个同名文件的 `inference_step` | ❌ bench10 和 eval 均通过 `sys.path` 加载同一 `policy/` 版本 |
| T5/VLM 预处理开销 | 检查 eval 日志分项计时 | ❌ `model_forward` 只计 `inference_step` 本身，预处理已分开（t5=7.6ms, vlm_preprocess=43.8ms） |

### 根因：后台线程/进程资源竞争

`eval_g1_motus.py` 运行时存在大量后台线程和子进程，持续竞争 CPU 和内存带宽：

| 后台组件 | 线程/进程 | 来源 |
|----------|-----------|------|
| 图像客户端 | ZMQ 订阅线程 + 解码线程 | `image_client.py` — 持续接收解码 4 路相机图像 |
| 机器人臂控制 | motor state 订阅线程 + 控制发布线程 | `robot_arm.py` — 持续读写关节状态 |
| 夹爪控制 | 独立子进程 + subscribe 线程 | `robot_hand_unitree.py` |
| Shared Memory | 多进程间频繁数据交换 | `make_robot.py` |

这些后台负载导致：

1. **CPU 竞争 → CUDA kernel launch 延迟**：CUDA kernel 由 CPU 发射，后台线程抢占 CPU 导致 kernel 排队，GPU 出现空闲间隙。
2. **Python GIL 竞争**：Python 线程间 GIL 切换增加推理主线程的等待时间。
3. **内存带宽竞争**：图像解码和 shared memory 拷贝占用内存带宽，影响 GPU 数据传输。

### 验证方法

```bash
# 推理期间监控线程 CPU 占用
top -H -p <eval_g1_motus PID>

# 推理期间监控 GPU 利用率波动
nvidia-smi dmon -s u
```

### 优化建议

| 优化方向 | 具体措施 | 预期收益 |
|----------|----------|----------|
| 推理期间降低后台频率 | 暂停/降低图像订阅频率，推理结束后恢复 | 减少 CPU 竞争 |
| 图像解码 offload | 用 GPU 硬件解码（NVDEC）代替 CPU 解码 | 释放 CPU、降低内存带宽竞争 |
| 进程优先级提升 | `nice -n -20` 或 `chrt` 提升推理进程优先级 | 减少 CPU 调度延迟 |
| CPU 核心绑定 | `taskset` 将推理线程绑定到独立 CPU 核心 | 隔离后台干扰 |
| 后台线程 GIL 释放 | 后台线程中频繁调用 `time.sleep` 或使用 C 扩展释放 GIL | 减少 GIL 竞争 |

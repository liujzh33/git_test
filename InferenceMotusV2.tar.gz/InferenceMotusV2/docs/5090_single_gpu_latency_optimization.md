# MotusV2 (WamVlmMask) 单卡 5090 推理加速全记录：1.67s → 254ms

> 目标：G1-D `pick-kettle-and-cup` 策略（WAN2.2-TI2V-5B + Qwen3-VL-2B + Action Expert），
> 在**单张 RTX 5090** 上把一个 **16 长度 action chunk** 的推理时延压到最低。
>
> 结论：**10 步 461ms / 5 步 254ms**，相比最初的 1.67s 提升 **3.6× / 6.6×**，
> 且除"减去噪步数"外**全部改动零精度损失**（compiled 输出与 eager 逐位相同）。

---

## 1. 结论速览

| 阶段 | 改动 | 10 步 | 5 步 |
|---|---|---|---|
| ① 原始基线（训练仓库代码，含 VAE 解码） | — | 1668 ms | — |
| ② Thor 四项优化（已在 InferenceMotusV2） | 见 §3 | 1404 ms | — |
| ③ 跳过 VAE 视频解码 | `decode_video=False` | 1128 ms | 578 ms |
| ④ **compile 友好 RoPE + torch.compile** | 见 §4 | **461 ms** | **254 ms** |

**最终时延模型（实测拟合）**

```
compiled:  时延 ≈ 47.2 ms（固定）+ N × 41.4 ms/步
eager   :  时延 ≈ 47.0 ms（固定）+ N × 105.6 ms/步
```

固定部分 = VLM 前向（~39ms）+ VAE 编码（~11ms），在去噪循环之外，不被 compile 覆盖。

**实时性**：一个 chunk = 16 步 @30Hz = **533 ms** 执行时长。

| 方案 | 时延 | 占执行时长 | 能否 30Hz 实时闭环 |
|---|---|---|---|
| eager 10 步（当前部署） | 1103 ms | 2.07× | ❌ |
| compiled 10 步 | 461 ms | 0.87× | ✅ 刚好 |
| **compiled 5 步** | **254 ms** | **0.48×** | ✅ 2.1× 裕度 |

---

## 2. 测试环境与方法

| 项目 | 配置 |
|---|---|
| GPU | NVIDIA GeForce RTX 5090（sm_120, Blackwell, 32GB, 575W） |
| PyTorch | 2.10.0 + cu128 |
| transformers | 5.2.0 |
| 精度 | bfloat16（时间嵌入/AdaLN 为 fp32） |
| 模型 | MotusWanVlmDirectMask，WAN dim=3072 / ffn=14336 / 30 层 |
| 输入 | T 形拼接 384×320，state/action 16 维，chunk=16，10 去噪步 |
| batch | 1 |
| 峰值显存 | 18.83 GB（decode=OFF） |

**方法说明**：
- 全部为 `inference_step()` 端到端计时，`torch.cuda.synchronize()` 前后包裹，跳过 warmup。
- 权重为随机初始化（`load_pretrained_backbones=False`）。**对时延测量保真**——耗时只由网络结构、张量形状和数值精度决定，与权重数值无关。
- 每个数据点重复 3 次取最小值，重复间误差 < 1 ms。
- 测量在独占 GPU 上进行（其余卡的任务已确认不影响）。

---

## 3. 已落地的优化（Thor 迁移，已在 InferenceMotusV2 代码中）

这四项来自 Thor 真机加速（见 `optimization_report.md`），迁移到 5090 后**依然有效**：

| # | 优化 | 说明 | 5090 上是否生效 |
|---|---|---|---|
| 3.1 | **跳过 VAE 视频解码** | `inference_step(decode_video=False)`。真机控制只用 action，视频帧被丢弃 | ✅ 省固定 ~275 ms |
| 3.2 | **Time-embedding 去冗余** | 只算长度-1 `[B,1,...]`，下游 AdaLN 靠广播（原来逐 token 重复做 FP32 投影） | ✅ 减少真实 FP32 计算 |
| 3.3 | **RoPE b==1 实数快速路径** | 用预建实数 cos/sin 替代 `torch.unique`+`.tolist()`+复数+float64 | ✅ 减少计算与主机同步 |
| 3.4 | 注意力 b==1 SDPA 快速路径 | 绕开变长 padding 的 Python 循环与 `.item()` | ⚠️ **5090 上不生效**：该分支排在 `elif FLASH_ATTN_2_AVAILABLE` 之后，装了 flash-attn 时走不到 |

**Thor vs 5090 的收益差异**：Thor 上这套优化拿到 ~34%，5090 上只有 ~20%。原因是 Thor 是
**launch-bound**（弱 Tegra CPU 发射不过来，GPU 空等），而 5090 CPU/GPU 都强，主机同步类优化
的头顶空间小；真正在 5090 上仍有效的是 3.1/3.2/3.3 这些**削减真实计算量**的部分。

---

## 4. 关键突破：compile 友好 RoPE + torch.compile（2.4×）

### 4.1 问题：RoPE 的 Python 侧缓存把整图撕碎

`bak/wan/modules/model_mask.py` 的 `rope_apply` 为了复用实数 cos/sin，用了：

```python
_ROPE_FAST_CACHE = {}
key = (T, N, CC, x.device, freqs.data_ptr())   # ← data_ptr() 无法被 dynamo trace
entry = _ROPE_FAST_CACHE.get(key)              # ← 字典查找 → graph break
...
@lru_cache(maxsize=256)                        # ← lru_cache 无法 trace
def _make_freq_grid(f, h, w): ...
```

`rope_apply` 在每层对 q、k 各调一次（**约 60 次/步**），于是编译时每步产生约 60 处
**graph break**，整个去噪步被撕成几十个小图 —— 这正是 Thor 报告里 `torch.compile` "跑不通、
收益 ≤ eager" 的根因。

**实测佐证**：保持原 RoPE 直接 compile，10 步只从 1122ms → 1020ms（**仅 1.10×**）。

### 4.2 解决：纯张量 RoPE（数值完全等价）

把 cos/sin 一次性建好存为模块级张量，函数体只做纯张量旋转，去掉 `dict` / `data_ptr` /
`lru_cache`：

```python
_CF = {"cos": None, "sin": None, "seq": 0}

def rope_apply_cf(x, grid_sizes, freqs):
    B, T, N, CC = x.shape
    if _CF["cos"] is None:                      # 仅首次（eager warmup）构建
        _CF["cos"], _CF["sin"], _CF["seq"] = _build_cossin(grid_sizes, freqs, CC // 2)
    cos, sin, seq = _CF["cos"], _CF["sin"], _CF["seq"]
    xr = x[:, :seq].float()[..., 0::2]
    xi = x[:, :seq].float()[..., 1::2]
    y = torch.stack([xr * cos - xi * sin, xr * sin + xi * cos], dim=-1).reshape(B, seq, N, CC)
    if seq < T:
        y = torch.cat([y, x[:, seq:].float()], dim=1)
    return y.to(x.dtype)
```

数学与现有 eager 快速路径 `_rope_rotate_real` **完全相同**（后者本就通过 `allclose` 自检过与
复数参考实现一致），只是去掉了 Python 侧的缓存包装。

### 4.3 效果

- **`torch.compile(fullgraph=True)` 编译通过，零 graph break** —— 整个 30 层去噪步是一张完整图。
- **数值逐位一致**：同随机种子下 `max|Δaction| = 0.000e+00`（5 步、10 步均验证）。
- **10 步 1103 → 461 ms（2.39×）；5 步 576 → 254 ms（2.27×）**。
- 每步从 105.6 ms 降到 41.4 ms。

### 4.4 完整曲线（实测）

| 去噪步数 | eager | compiled | 提速 |
|---|---|---|---|
| 1 | 152.5 ms | 88.9 ms | 1.71× |
| 2 | 257.1 ms | 130.0 ms | 1.98× |
| **5** | 576.3 ms | **253.6 ms** | 2.27× |
| 10 | 1102.8 ms | **461.4 ms** | 2.39× |

步数越少 compile 的相对收益越小，因为 ~47ms 的固定开销（VLM + VAE 编码）不在编译范围内。

### 4.5 compile 模式选择（重要）

| mode | 结果 |
|---|---|
| `default` | ✅ 可用，即上表数据 |
| `reduce-overhead`（CUDA graph） | ❌ `accessing tensor output of CUDAGraphs that has been overwritten by a subsequent run` |
| `max-autotune`（含 CUDA graph） | ❌ 同上 |

> ⚠️ 代码里 `_get_denoise_step_fn()` 的默认 `MOTUS_COMPILE_MODE` 是 **`reduce-overhead`**，
> 直接开 `MOTUS_COMPILE=1` 会命中 CUDA graph 报错。**必须显式设 `MOTUS_COMPILE_MODE=default`。**

CUDA graph 失败的原因是去噪步返回的张量在下一次调用中被覆盖。若后续把返回张量 `clone()`
掉解决它，理论上还能进一步压缩（当前每步 41.4ms 距离纯 GEMM 下限 ~25ms 仍有空间）。

**编译耗时**：冷缓存约 197s，热缓存约 47–85s。机器人端建议开启持久化 inductor 缓存。

### 4.6 ⚠️ 必须先 eager 预热一次，再 compile

`rope_apply_cf` 首次调用时才构建 cos/sin（`if _CF["cos"] is None:` 分支里含
`grid_sizes.tolist()` 主机同步 + 复数构建）。**如果先 `torch.compile` 再首次调用**，dynamo 会把
这个冷分支编进图，性能显著劣化：

| 顺序 | 10 步 | 5 步 |
|---|---|---|
| 先 compile，后首次调用（错误） | 715.3 ms | 389.7 ms |
| **先 eager 跑一次，再 compile（正确）** | **464.4 ms** | **257.9 ms** |

**部署时必须**：加载模型后先用 eager 跑 1 次 dummy 推理（把 cos/sin 建好），再启用 compile。

---

## 5. 验证过但**无效**的方向（不必重复投入）

### 5.1 fp16 —— 无收益，且有风险

| 去噪步数 | bf16 | fp16 |
|---|---|---|
| 5 | 585.9 ms | 593.8 ms（**慢 1.4%**） |
| 10 | 1118.8 ms | 1144.8 ms（**慢 2.3%**） |

Blackwell 的 Tensor Core 对 fp16 与 bf16 **吞吐完全相同**（都是 16-bit，同一条数据通路），
显存占用也一样。而 fp16 只有 5 位指数（bf16 是 8 位，与 fp32 同量程），在扩散模型的大激活值
下**容易溢出成 NaN**。结论：**保持 bf16**。

### 5.2 fp8 (E4M3) —— 硬件有潜力，但这个模型上是负优化

**硬件确实支持且 GEMM 有 2–3× 潜力**（`torch._scaled_mm` 在 sm_120 可用）：

| GEMM 形状 (M,K,N) | bf16 | fp8 上限（预量化） | fp8 + 动态量化 |
|---|---|---|---|
| WAN attn 投影 (360,3072,3072) | 0.039 ms | **1.89×** | 0.56×（更慢） |
| WAN FFN up (360,3072,14336) | 0.218 ms | **2.79×** | 2.15× |
| WAN FFN down (360,14336,3072) | 0.226 ms | **2.62×** | 1.80× |
| action FFN (480,1024,4096) | 0.027 ms | 1.62× | 0.40×（更慢） |

**而且 FLOPs 结构对 fp8 本应极其有利**：每步 GEMM 占 **97%** FLOPs（4569 GFLOP），
SDPA 注意力仅 3%（137 GFLOP）。

**但端到端全部是负优化**：

| 方案 | 10 步 | vs bf16 |
|---|---|---|
| 手写 fp8 动态量化 | 1698 ms | 0.66× |
| 手写 fp8 静态 scale | 1452 ms | 0.77× |
| 手写 fp8 + 逐算子 compile | 2556 ms | 0.44× |
| **torchao 标准路线 + 整图 compile** | **580 ms** | **1.93×，仍不如纯 bf16 compile 的 2.39×** |

**根因**：模型每步是 ~400 个**中小 GEMM**（40% FLOPs 是 M≈360 的 attn 投影，fp8 上限仅 1.89×）。
一旦整图 compile，bf16 的小 kernel 已被充分融合；此时 fp8 每个 GEMM 还要额外做
"求 amax + 转 fp8" 的量化访存，在小 GEMM 上得不偿失，整体净亏。注意力（3% FLOPs）也始终是
bf16，封住了上限。

**结论：不要上 fp8。** 投入大（torchao 集成 + 精度校准 + 回归评测）、有精度风险，且实测比纯
bf16 compile 更慢。

---

## 6. torch.compile 与 RTC 的兼容性（RTC_MODE=pi05）

**结论：`RTC_MODE=pi05` 与 torch.compile 完全兼容，额外开销为零。只有
`action_jacobian` 需要梯度、与 compile 冲突，而代码里已有守卫自动回退到 eager。**

### 6.1 三种 RTC 模式是否需要梯度

| 模式 | 是否需要 autograd | 与 compile |
|---|---|---|
| `inpaint`（默认） | ❌ 纯代数：`x1_g = x1 + w*(prev-x1)`; `v = (x_t-x1_g)/t` | ✅ 兼容 |
| **`pi05`** | ❌ 纯代数：`err = (prev-x1)*w`; `v = v_t - gw(t)*err` | ✅ **兼容** |
| `action_jacobian` | ✅ `torch.autograd.grad(x1, x_t, err)` | ❌ 冲突，已自动回退 eager |

关键点在于 **pi05 不需要反向传播**。`_rtc_correct_velocity` 的 docstring 已说明原因：LeRobot
pi0.5 参考实现是在**跑完 denoiser 之后**才调 `x_t.requires_grad_(True)`，因此它那句
`autograd.grad(x1, x_t, err)` 退化成**恒等 Jacobian**，返回值恰好就是 `err`。MotusV2 直接用
解析形式复现，结构上逐位等价，**完全不需要建图**：

```python
# _rtc_correct_velocity, mode="pi05"
err = (prev_chunk - x1) * weights
gw  = _rtc_guidance_weight(t, max_guidance_weight)
v_new = v_t - gw * err          # correction=None -> corr = err
```

只有 `action_jacobian` 会设 `need_jac=True` → `requires_grad_(True)` + `torch.enable_grad()`
+ `torch.autograd.grad(...)`。

### 6.2 代码里已有的守卫

`inference_step` 已经正确处理了这个冲突，无需改动：

```python
# action_jacobian runs autograd inside the step, which torch.compile /
# CUDA graphs cannot capture — always use the eager step for it.
if rtc_prev_chunk is not None and rtc_mode == "action_jacobian":
    step_fn = self._mot_denoise_step        # eager
else:
    step_fn = self._get_denoise_step_fn()   # compiled
```

### 6.3 实测验证（RTX 5090，compiled default，decode=OFF）

| 配置 | 5 步 | 10 步 | vs RTC off |
|---|---|---|---|
| RTC off | 257.9 ms | 464.4 ms | — |
| RTC `inpaint`（compiled） | 255.2 ms | 462.7 ms | −1.7 ms |
| **RTC `pi05`（compiled）** | **257.6 ms** | **464.1 ms** | **−0.3 ms** |
| RTC `action_jacobian`（回退 eager） | 992.0 ms | 1661.6 ms | **+1197 ms** |

- **pi05 的额外开销是 −0.3 ms，即纯测量噪声——完全免费。** 因为它只是在每步的 velocity 上加
  几个逐元素运算（`err`、`gw*err`），相对 41.4 ms/步的主干可忽略。
- `action_jacobian` 慢 3.6×：既丢掉了 compile 的 2.4×，又要为每步的反向传播额外付费。
  **若要用 compile，就不要用 `action_jacobian`。**

### 6.4 需要注意的一次性重编译

`rtc_prev_chunk` 在**第一个 chunk 是 `None`、之后是张量**，这在 `dynamic=False` 下是一次
guard 变化 → 触发**一次额外编译**（实测约 50s）。即总共两张图（RTC-off / RTC-on），
之后稳定复用，不会每个 chunk 都重编译。

其余 RTC 入参都不会引发重编译：
- `rtc_weights` 已被归一化成固定形状 `[1, 16, 1]`，**只有数值随延迟变化**，数值变化不触发重编译；
- `rtc_mode`（str）和 `rtc_max_guidance_weight`（float）运行期固定，只特化一次。

---

## 7. 推荐配置与落地清单

### 推荐部署配置

```bash
MOTUS_COMPILE=1
MOTUS_COMPILE_MODE=default        # 不能用 reduce-overhead / max-autotune
RTC_MODE=pi05                     # 与 compile 完全兼容，零开销
# inference_step(..., decode_video=False)
# num_inference_timesteps: 10（保精度）或 5（追求裕度，需评测）
```

| 配置 | 时延 | 精度风险 |
|---|---|---|
| compiled + decode off + 10 步 + RTC pi05 | **464 ms** | 无（逐位等价） |
| compiled + decode off + 5 步 + RTC pi05 | **≈258 ms** | ⚠️ 减步数需真机/仿真成功率评测 |

### 待落地的代码改动

1. **`bak/wan/modules/model_mask.py`**：把 `rope_apply` 改成 §4.2 的 compile 友好版本
   （去掉 `_ROPE_FAST_CACHE` 的 `data_ptr` 键与 `@lru_cache`）。**这是解锁 2.4× 的唯一必需改动。**
   目前仅在 benchmark 中以 monkeypatch 验证，尚未落到仓库。
2. **加载后先 eager 跑 1 次 dummy 推理再 compile**（见 §4.6），否则慢 1.5×。
3. **`_get_denoise_step_fn()`**：把默认 `MOTUS_COMPILE_MODE` 从 `reduce-overhead` 改为 `default`，
   否则开 compile 会直接报 CUDA graph 错误。
4. RTC 保持 `pi05`（或 `inpaint`）；**不要用 `action_jacobian`**，它会退回 eager 并慢 3.6×。
5. 上线前跑一次 eager vs compiled 的逐帧数值一致性校验（本文档中 5 步/10 步均为 `Δ=0`）。

### 后续可选（若要冲 <200ms）

- **修复 CUDA graph**：把去噪步返回张量 `clone()` 后再试 `reduce-overhead`。当前 41.4ms/步
  距离纯 GEMM 理论下限 ~25ms/步仍有约 1.6× 空间。
- **减去噪步数**：5 步已实测 254ms；2 步 130ms、1 步 89ms（精度需评测）。
- 不要再试 fp16 / fp8（见 §5）。

---

## 8. 复现方式

benchmark 脚本位于 `/home/work/wenjj/`（不属于本仓库，仅供复现）：

| 脚本 | 用途 |
|---|---|
| `bench_compare.py` | 基线 vs 优化版对比（模型构建入口，被其它脚本复用） |
| `bench_min_latency.py` | compile 多模式扫描 + compile 友好 RoPE 定义 |
| `bench_min_verify.py` | graph break 诊断（`fullgraph=True`）+ 重复测量 |
| `bench_5step.py` | 1/2/5/10 步完整曲线 + 数值一致性校验 |
| `bench_fp8_gemm.py` | fp8 vs bf16 GEMM 微基准 |
| `bench_fp8_e2e.py` / `bench_fp8_torchao.py` | fp8 端到端（手写 / torchao 标准路线） |
| `bench_rtc_compile.py` | compile × RTC（off / inpaint / pi05 / action_jacobian）兼容性与开销 |

```bash
cd /home/work/wenjj
CUDA_VISIBLE_DEVICES=<free_gpu> \
PYTHONPATH=/home/work/wenjj/.benchpkgs \
LD_LIBRARY_PATH=/home/work/liujingzhi/envs/wallx/lib \
/home/work/liujingzhi/envs/wallx/bin/python3.10 -u bench_5step.py
```

> 注：`.benchpkgs` 是隔离的依赖目录（diffusers / deepspeed stub / ftfy stub / torchao），
> 避免污染 `wallx` 环境。

# MotusV2 Thor 真机推理加速报告（7.5s → 2.1s）

> 目标：G1-D `pick-kettle-and-cup` 策略（WAN2.2-TI2V-5B + Qwen3-VL-2B + Action Expert），
> 在 NVIDIA Jetson Thor 上真机部署，`num_inference_steps=10` 不变（保动作精度）的前提下，
> 把单次动作 chunk 推理时延从 **~7.5s** 降到 **~2.1s**。

sudo nvpmodel -m 0        # 切到最高性能档 MAXN（档位号以 nvpmodel -q 为准）
sudo jetson_clocks        # 锁定 CPU/GPU/EMC 到最高频
sudo jetson_clocks --show # 确认 GPU 和 EMC(内存) 频率确实拉满
tegrastats               # 推理时看 GPU(GR3D) 利用率、EMC 带宽、是否降频

---

## 1. 结论速览

| 阶段 | 纯推理 bench（10 步, decode off） | 真机 `model_forward` | 说明 |
|---|---|---|---|
| 初始（GLM 适配版） | 4.9s（含 VAE 解码） | — | 动作能跑但很慢 |
| 跳过 VAE 解码 | 3.5s | ~7.5s | 真机受后台线程竞争，约 2× 劣化 |
| + Time-embedding 去冗余 | 2.78s | — | |
| + RoPE / Attention 去主机同步 | **2.30s** | **~2.1s** | 真机竞争惩罚基本消失 |

**最终真机：`model_forward ≈ 1.8–2.0s`，端到端 `total ≈ 1.94–2.02s`，稳定。**

核心判断：该负载是 **launch-bound（CPU 发射瓶颈）而非 GPU 算力瓶颈**，因此优化主线是
「**减少每次推理的 kernel 数量与 CPU↔GPU 主机同步**」，而不是堆算力。

---

## 2. 硬件 / 软件环境

| 项目 | 配置 |
|---|---|
| GPU | NVIDIA Jetson Thor（tegra264, aarch64），GPU 锁频 1.575GHz，EMC 4266MHz，NV Power 120W |
| CPU | 14 核 @2.6GHz |
| CUDA / 驱动 | CUDA 13.0 / Driver 580 |
| PyTorch | 2.12.1+cu130（triton 3.7.1），**未安装 flash-attn** |
| transformers | 5.5.4 |
| 精度 | bfloat16 |
| 模型 | MotusWanVlmDirectMask（30 层 MoT：WAN + Action + VLM） |
| 输入 | T 形拼接 384×320，state/action 16 维 qpos，chunk=16 |

---

## 3. 诊断方法（先定位，再优化）

1. **分模块 profiling 不可信**：带 `torch.cuda.synchronize()` 的逐模块计时之和（8.44s）远大于端到端（4.9s），
   "time_embedding 占 45%" 是同步气泡假象，不能据此优化。
2. **步数扫描**：2 步≈1.9s、10 步≈4.9s，非线性 → 存在与步数无关的固定开销（VAE 编解码等）。
3. **`tegrastats` 决定性证据**：推理时 **519/753 采样有单核 100%**、570/753 ≥90%（均值峰值核 90.5%），
   而 **VDD_GPU 有 552/753 停在空载 7505mW**（Thor 上限 ~120W，全程均值仅 10.8W）。
   → **一个 Python 线程把单核打满在发射 kernel，GPU 绝大多数时间在空等 → launch-bound。**
4. 由 3 推得：**减少 CPU 侧的 kernel 发射与主机同步**是关键；这也解释了真机比纯 bench 慢 2×
   （后台 ZMQ 图像/机械臂/夹爪线程抢 CPU 与 GIL，直接拖慢 kernel 发射）。

---

## 4. 逐项优化

### 4.1 跳过 VAE 视频解码（decode_video=False）
- **问题**：`inference_step` 每次都跑 WAN VAE 解码整段视频，但真机控制只用 action，视频帧被丢弃。
- **改动**：`inference_step` 增加 `decode_video` 参数；`adapter.predict_action_chunk` 传 `decode_video=False`。
- **收益**：VAE 解码是与步数无关的固定开销（~1s），bench 4.9s → 3.5s。
- **代码**：`models/motus_wan_vlm_direct_mask.py`（`inference_step`）、`scripts/motusv2_adapter/adapter.py`。

### 4.2 Time-embedding 去 per-token 冗余
- **问题**：`get_time_embedding` 把标量 timestep `expand` 到 `seq_len` **逐 token 重复**做 FP32 投影
  （视频侧 ~90×、动作侧 ~21× 冗余），生成 `[B, seq_len, 6, dim]` 大张量。
- **改动**：只算长度-1 `[B,1,...]`，下游 AdaLN / WAN Head 全靠广播（数值完全等价，因每行本就相同）。
- **收益**：bench 3.5s → 2.78s；减少 FP32 计算量与逐元素小 kernel。
- **代码**：`models/motus_wan_vlm_direct_mask.py`（`VideoModule.get_time_embedding`、`ActionModule.get_time_embedding`）。

### 4.3 注意力回退：b==1 直连 SDPA 快速路径
- **问题**：无 flash-attn 时走的 SDPA 回退里有变长 padding 的 Python 循环 + 数据依赖切片
  `q_padded[i, :q_lens[i]]`（触发 `.item()` 主机同步）+ `warnings.warn`；WAN cross-attn 每层每步都命中。
- **改动**：`b == 1` 时直接 `unsqueeze(0)` → SDPA，绕开循环 / `.item()` / warn。
- **收益**：消除一处每步的主机同步；配合 4.4 共同把 bench 降到 2.30s。
- **代码**：`bak/wan/modules/attention_mask.py`、`bak/wan/modules/attention.py`。

### 4.4 RoPE：b==1 capture-safe 实数快速路径（最大单点）
- **问题**：`rope_apply` 在每层对 q、k 各调一次（**~600 次/推理**），每次都用
  `torch.unique` + `.tolist()` + `.nonzero()` + `@lru_cache` + **complex** + **float64** —
  既是主机同步/CPU 密集，也是最主要的单核打满来源。
- **改动**：`B == 1` 时从固定视频网格 + freqs **一次性建好实数 cos/sin 缓存复用**，之后每次只做纯张量旋转
  （无 `unique/tolist/nonzero`、无复数、无 float64）。带**一次性 `allclose` 自检**，与原复数实现不符则自动回退。
  训练（B>1）走原路径，训练数值不变。
- **收益**：bench 2.78s → **2.30s**；真机因此从 ~7.5s 直接降到 ~2.1s（见 §5）。
- **代码**：`bak/wan/modules/model_mask.py`（`rope_apply` / `_rope_apply_full` / `_rope_rotate_real`）。

### 4.5 真机竞争惩罚的消除（副产品）
- 之前真机 7.5s vs bench 3.5s 的 2× 差距，来自后台线程抢 CPU/GIL，拖慢本就 launch-bound 的 kernel 发射。
- 4.2 / 4.3 / 4.4 大幅削减了推理线程的 CPU 侧工作量与主机同步次数（尤其 4.4 去掉 ~600 次/推理的同步），
  **推理线程对 CPU/GIL 的占用骤降 → 后台竞争不再造成明显劣化**，真机直接逼近纯推理值。

---

## 5. 真机实测（`num_inference_steps=10`, `decode_video=False`）

来源：`log_260720_2300.txt`（稳定段，节选）

```
model_forward=2118.6ms  total=2141.3ms
model_forward=2114.4ms  total=2140.3ms
model_forward=2109.5ms  total=2135.5ms
model_forward=2117.9ms  total=2142.5ms
...
```

- 单次推理 `model_forward ≈ 2.11–2.20s`，端到端 `total ≈ 2.14–2.22s`。
- 预处理开销极小：`t5 ≈ 4ms`、`vlm_preprocess ≈ 17ms`、`obs_preprocess ≈ 4ms`。

---

## 6. 附带完成的训推一致性修复（正确性，非性能）
- **VLM 自注意力掩码**：推理旧副本写死为「因果」，而 g1d 训练默认「双向」(`vlm_causal_attention=False`)。
  已改为由 `vlm_causal_attention` 控制、默认双向，与训练对齐（首帧日志应打印 `VLM→bidirectional-VLM`）。
- **代码**：`models/motus_wan_vlm_direct_mask.py`（config 字段 + `process_joint_attention` + `__init__` 传参）。
- 仍待你侧核对：Thor 上 `transformers` 版本与训练一致（Qwen3-VL 的 `get_image_features` / `get_rope_index` 行为），
  以及部署 `--instruction` 与训练 `tasks.parquet` 文本逐字符一致（影响 T5 缓存命中与 VLM 文本）。

---

## 7. 尝试过但未采用的方案

| 方案 | 结论 |
|---|---|
| 安装 flash-attn | 无效：最贵的三模态联合注意力走的是「SDPA + 自定义布尔 mask」，flash varlen 不支持任意 mask，装了也不走它。 |
| `torch.compile`（default / reduce-overhead） | **放弃**。在 Thor(aarch64)/torch2.12 + 复数 RoPE + `layer_idx` 特化下：反复撞 `recompile_limit`、`CUDA Graph is empty`、`accessing tensor output overwritten` 崩溃。首帧还要 30–44s 编译。收益 ≤ eager，且不稳定。**已把 `MOTUS_COMPILE` 默认设为 0（关闭），真机默认走 eager。** |
| 减少去噪步数（10→4，1.23s） | 用户要求保 10 步以保动作精度，未采用。 |

---

## 8. 后续可选（若要冲 <1.5s）
- **手写 CUDA Graph**（launch-bound 的正确工具，torch.compile 不适用）：捕获 eager 真实 kernel 流，
  不受复数/`layer_idx`/Python 结构影响。前置条件：把 `unpatchify` 的 `grid_sizes.tolist()`（10 次/推理）也缓存掉，
  再用静态缓冲捕获 10 步循环回放。GPU 现基本空闲，理论上有望到 ~1.0–1.5s。
- **CPU/GIL 隔离**（若后续接入更多后台服务导致回退）：`chrt -f` 提优先级 + `taskset` 绑核 +
  `torch.set_num_threads` 限制线程；必要时把图像采集/控制放独立进程避开 GIL。

---

## 9. 改动文件清单（相对 `policy/MotusWanVlmDirectMaskMotion/` 与 `scripts/`）

| 文件 | 改动 |
|---|---|
| `models/motus_wan_vlm_direct_mask.py` | `decode_video` 开关；`get_time_embedding` 去冗余；VLM 掩码训推对齐；`_mot_denoise_step`/`_get_denoise_step_fn`（compile 脚手架，**默认关闭**） |
| `bak/wan/modules/attention_mask.py` | b==1 SDPA 快速路径 |
| `bak/wan/modules/attention.py` | b==1 SDPA 快速路径 |
| `bak/wan/modules/model_mask.py` | `rope_apply` b==1 实数快速路径 + allclose 自检 |
| `scripts/motusv2_adapter/adapter.py` | 调用 `inference_step(..., decode_video=False)` |

> 真机对应路径：`/home/unitree/codes/temp/MotusV2/policy/MotusWanVlmDirectMaskMotion/...`
> 与 `/home/unitree/scripts/motusv2_adapter/adapter.py`。

## 10. 运行方式
```bash
# MOTUS_COMPILE 默认已为 0（eager，稳定）；显式设置更保险
MOTUS_COMPILE=0 bash /home/unitree/scripts/inference_motusv2.sh
```
> 注：首帧因 RoPE 的一次性 `allclose` 自检 + cuDNN autotune 会略慢，从第 2 次预测起为稳定值。

# InferenceMotusV2 eef_delta 推理诊断报告

> 日期: 2026-08-26
> 脚本: `scripts/inference_motusv2_eef_delta.sh`
> Checkpoint: `WanVlmMask-G1D-PickKettle-DeltaEEF-12500`
> 日志文件: `logs/inference_eef_delta_20260826.log`

---

## 1. 背景与问题现象

运行 `inference_motusv2_eef_delta.sh` 脚本进行 G1 实机推理，机械臂呈现**畸形姿态**，
手臂关节处于不合理位置，无法正常执行任务。

### 推理链路概要

```
inference_motusv2_eef_delta.sh
  └─ eval_g1_motus.py::run_eval()
       ├─ setup_image_client()          → ImageClient (ZMQ 图像)
       ├─ setup_robot_interface()       → G1_29_ArmController + G1_29_ArmIK + Dex1 gripper
       ├─ MotusV2PolicyAdapter(...)     → 加载模型/T5/VLM processor
       ├─ _load_initial_pose_from_dataset()  → 读 parquet 初始位姿
       ├─ _move_robot_to_pose()         → 插值移动到初始位姿
       └─ 控制循环 (30Hz):
            ├─ process_images_and_observations()  → 4 相机图像 + arm_q
            ├─ policy.observation_to_model_input() → T 形拼接 + state 构建
            ├─ policy.predict_action_chunk()       → 模型推理
            ├─ policy.step()                       → 从 action_queue 弹出下一帧
            │    └─ eef_action_to_g1_action()      → denorm + from_delta + IK
            ├─ arm_ik.solve_tau(arm_action)        → 前馈力矩
            ├─ arm_ctrl.ctrl_dual_arm(q, tau)      → 发送关节指令
            └─ _write_gripper()                    → 夹爪控制
```

### 两套运动学的职责

| 组件 | 来源 | 职责 |
|---|---|---|
| `G1EefKinematics` (eef_delta.py) | `InferenceMotusV2/assets/g1_body29_hand14.urdf` | FK (qpos→EEF state) + IK (EEF target→qpos) |
| `G1_29_ArmIK` (robot_arm_ik.py) | `unitree_lerobot/.../g1_body29_hand14.urdf` | **仅 solve_tau** (qpos→前馈力矩)，推理中不调用 solve_ik |

---

## 2. 问题一：`predict_action_chunk` 的 `state_tensor` 是什么？

### 结论

`state_tensor` 是一个 `[1, 16]` 的 float32 张量，内容是**当前时刻双臂末端 (TCP) 绝对位姿 + 双夹爪开合量**，
经过 MinMax 归一化到 `[0, 1]`。**不是**关节角 qpos，**不是** delta 偏移。

### 16 维布局

每臂 8 维 = 6 DoF TCP 位姿 + 1 夹爪 + 1 占位，共 16 维：

| 维度 | 含义 | 来源 |
|---|---|---|
| `[0:3]` | 左臂 TCP 平移 (x,y,z)，report frame，单位 m | `fk_poses(q14)[0].translation` |
| `[3:6]` | 左臂 TCP 旋转向量 (axis×angle)，rad | `pin.log3(pose.rotation)` |
| `[6]` | 占位（保留，始终 0） | — |
| `[7]` | 左夹爪开合标量 | `ee_shared_mem["state"][0]` |
| `[8:11]` | 右臂 TCP 平移 | `fk_poses(q14)[1].translation` |
| `[11:14]` | 右臂 TCP 旋转向量 | `pin.log3(pose.rotation)` |
| `[14]` | 占位（保留，始终 0） | — |
| `[15]` | 右夹爪开合标量 | `ee_shared_mem["state"][ee_dof]` |

### 关键定义

- **TCP**: 沿腕部偏航轴向外 50 mm 处的工作点 (`TCP_OFFSET = [0.05, 0, 0]`)
- **参考系**: report frame = `torso_link` 平移 `REPORT_FRAME_TO_TORSO = [-0.0039635, 0, 0.044]`
- **归一化**: 用 `eef_stats.json` 的 `min/max`（**不是** `delta_min/delta_max`，那是给 action 用的）
- **绝对 vs delta**: state 用绝对位姿（让模型知道"我在哪"），action 是相对 condition frame 的 delta 偏移

### 代码位置

- 构建: `adapter.py:591-604` (`observation_to_model_input` 的 else 分支)
- FK: `eef_delta.py:229-239` (`fk_state`)
- 归一化: `adapter.py:600-601` (`state_normalizer.normalize`)
- 使用: `adapter.py:917-919` (传入 `model.inference_step`)

---

## 3. 问题二：能否直接从机器人获得末端 EEF？

### 结论：当前 SDK 不支持，且即便支持也不应该用。

### SDK 接口现状

`G1_29_ArmController`（`unitree_lerobot/eval_robot/robot_control/robot_arm.py:76-235`）
只暴露关节级接口：

| 方法 | 返回 |
|---|---|
| `get_current_motor_q()` | 全身电机角度 |
| `get_current_dual_arm_q()` | 双臂 14 关节角度 |
| `get_current_dual_arm_dq()` | 双臂关节速度 |
| `ctrl_dual_arm(q, tau)` | 关节级指令 |

底层 `hg_LowState` 消息体只有 `motor_state[id].q / .dq`，**没有末端位姿字段**。
4 个 ArmController 类（G1_29 / G1_23 / T1 / H1_29）均无任何 `get_*_pose / get_*_eef` 接口。

### 为什么不应该用机器人内部位姿

1. **训练一致性**: 训练时 parquet 的 `observation.state.eef` 列是离线用 `tools/g1_qpos_to_eef.py` 跑 FK 算的，
   推理时必须用同一条 FK 链路，否则归一化后的 `state_tensor` 与训练分布不一致。

2. **参考系/TCP 不匹配**: 机器人内部报告的位姿可能用 pelvis/world/base_link，TCP 可能用腕部原点或夹爪中心，
   旋转可能用四元数/欧拉角。即使数值接近，5 cm 的 TCP 偏移在归一化后就是 ~0.5 的 state 偏差。

3. **精度**: Pinocchio FK 是闭式解（误差 < 1e-12 m），机器人控制器内部可能用单精度、不同零位标定。

### 正确的排查方向

不是换数据源，而是验证当前 FK 是否和训练数据一致（已验证通过，见下文第 5 节）。
真正的误差来源可能是 **图像-qpos 时间错位**（`get_current_dual_arm_q()` 的 buffer 每 2ms 更新，
图像采集延迟 30-100ms，FK 出来的 EEF 是"过时的位姿"）。

---

## 4. 问题三：URDF 是否与真实机器人不匹配？

### 结论：URDF 完全匹配，不是问题原因。

### 验证结果

| 对比项 | `G1EefKinematics`（推理 FK/IK） | `G1_29_ArmIK`（控制器力矩） | 一致？ |
|---|---|---|---|
| **URDF 文件** | `InferenceMotusV2/assets/g1_body29_hand14.urdf` | `unitree_lerobot/.../g1_body29_hand14.urdf` | ✅ bit-identical (`filecmp.cmp` 确认) |
| **关节顺序** | 14 个臂关节 | 14 个臂关节 | ✅ 完全相同 |
| **TCP offset** | `[0.05, 0, 0]` | `[0.05, 0, 0]` | ✅ 相同 |
| **参考系** | report frame（零位时 = pelvis 原点） | reduced robot 世界系（= pelvis） | ✅ 零位时重合 |
| **关节限位** | 14 个关节逐个对比 | — | ✅ 全部相同 |
| **同一组 qpos FK 输出** | L_ee=[0.0274, 0.2735, -0.1063] | L_ee=[0.0274, 0.2735, -0.1063] | ✅ 一致（差异 < 1e-7） |

### 参考系重合的数学证明

```
torso_link 零位世界坐标 = [-0.0039635, 0, 0.044]  (从 URDF kinematic chain 算出)
REPORT_FRAME_TO_TORSO  = [-0.0039635, 0, 0.044]
report frame 原点 = torso_link - REPORT_FRAME_TO_TORSO = [0, 0, 0] = pelvis 原点
G1_29_ArmIK 世界系原点 = pelvis（reduced robot root）
=> 零位时两套参考系完全重合
```

推理时 waist 关节被锁定在零位（reduced model），重合关系始终成立。

### 推理流程中的 IK 归属

```
模型推理流程:
  qpos → G1EefKinematics.fk_state() → EEF state → 模型输入
  模型输出 → G1EefKinematics.ik() → qpos target → arm_ctrl.ctrl_dual_arm()
                                                          ↑
                              G1_29_ArmIK.solve_tau(qpos) → 前馈力矩
```

`G1_29_ArmIK` 在推理时**只做 `solve_tau`**（RNEA 逆动力学），**不做 IK**。
EEF→qpos 的逆运动学完全由 `G1EefKinematics.ik()` 完成。

### 训练侧 URDF 一致性

训练时 `tools/g1_qpos_to_eef.py` 生成 parquet 的 `observation.state.eef` 列时用的 URDF，
如果和推理时不同会导致系统性偏移。但 log 验证排除：推理 FK 输出的 16 维 EEF 全部在训练 stats 的
`[min, max]` 范围内，normalized 值全部在 `[0, 1]`，说明训练和推理的 EEF 定义一致。

---

## 5. 问题四：日志分析 — 定位畸形根因

### 日志文件

`logs/inference_eef_delta_20260826.log`（493KB，3506 行，运行约 47 秒）

### 已排除的问题（验证通过）

| 检查项 | 结果 | 证据 |
|---|---|---|
| checkpoint 加载 | ✅ missing=0, unexpected=0 | log 第 73 行 |
| FK 输出的 EEF state | ✅ 16 维全部在训练 [min,max] 范围内 | log 第 84-86 行 |
| normalized state 值域 | ✅ 全部在 [0,1]，`outside the training range: none` | log 第 86 行 |
| URDF 一致性 | ✅ bit-identical，关节顺序/TCP/参考系/限位全一致 | 第 4 节验证 |
| stitch_mode | ✅ config 和 adapter 一致（"aspect"） | log 第 42 行 |
| IK round-trip（离线验证） | ✅ warm seed 误差 0 rad | 代码验证 |
| 训练/推理 state 处理方式 | ✅ 一致（`state.unsqueeze(1)` → `input_encoder`） | 代码验证 |

### 根因：模型输出的 EEF 轨迹质量极差

#### 证据 1: 模型输出的绝对 EEF target 大量超出训练范围

第 1 个 chunk 的 64 个 action：

```
targets outside the training range:
  L_x(22<,0>)     — 22/64 帧左臂 x 超下限
  L_z(3<,0>)      — 3/64 帧左臂 z 超下限
  L_ry(0<,6>)     — 6/64 帧左臂旋转 y 超上限
  L_grip(0<,35>)  — 35/64 帧左夹爪超上限 5.4
  R_x(1<,0>)      — 1/64 帧右臂 x 超下限
  R_ry(0<,2>)     — 2/64 帧右臂旋转 y 超上限
  R_rz(8<,0>)     — 8/64 帧右臂旋转 z 超下限
  R_grip(0<,36>)  — 36/64 帧右夹爪超上限 5.4
```

**16 次 predict 全部呈现类似模式**，每次都有多个维度超限。

#### 证据 2: IK 984 次全部被拒绝 — 机器人从未执行任何手臂动作

| 拒绝类型 | 次数 | 中位值 | 含义 |
|---|---|---|---|
| unreachable (残差过大) | 305 | **311.7 mm** | IK 目标超出可达工作空间 |
| joint step 过大 | 679 | **1.176 rad** (67°) | IK 解跳到冗余臂另一分支 |
| **总计** | **984** | — | **984/984 全部被拒绝** |

`max_ik_error = 5e-3` (5mm)，`max_joint_step = 0.3` rad — 所有帧都远超阈值。

#### 证据 3: 雪崩效应

```
第 0 帧: IK 残差 40.8mm → 拒绝，机器人不动
第 1 帧: 模型基于"没动的状态"继续预测 → target 越来越偏离
第 3 帧: 残差 340.8mm
第 5 帧: 残差 480.5mm
...
第 29 帧: 残差 627.8mm
```

#### 证据 4: 夹爪异常开合

gripper 值不经 IK 直接执行。模型输出 5.54、5.80 等超出训练上限 5.4 的值，
夹爪在物理上可能被驱动到异常位置。

#### 证据 5: 机器人实际未动

log 中所有帧的 `ik=0.0 ctrl=0.0`（IK 被拒绝后不发送新指令），
`step>0` 的 1008 行全部是 `policy.step()` 的计时（从队列弹出 action 并尝试 IK），
但 IK 结果全部被 reject 并 `holding previous target`。

**你看到的"畸形"是 `_move_robot_to_pose` 把机器人摆到 dataset 初始位姿后的静止状态，
加上夹爪在异常开合。**

### delta rotation 验证

对第 1 个 chunk 的 last target 做了 SO(3) 反推：

```
last target L_ry=1.8450（超训练上限 1.6275）
  delta rotation = 0.7102 rad（在训练 delta 范围内）
  => delta 本身合理，但叠加到 condition pose 后绝对值超限

last target R_rz=-1.6805（超训练下限 -1.6445）
  delta rotation = 0.8388 rad（在训练 delta 范围内）
  => 同上
```

说明模型学到的 delta 本身大小合理，但**方向不够准确**，叠加后偏离了训练分布。

---

## 6. 根因总结

**所有推理链路组件（FK、IK、归一化、URDF、checkpoint 加载、state 构建）均验证通过。
问题在于模型预测的 action 质量本身。**

### 模型输出问题的具体表现

1. **gripper 输出超出物理极限**: 训练数据夹爪最大 5.4，模型输出 5.5-5.8
2. **chunk 后半段旋转超出训练范围**: delta 本身合理，但叠加 condition pose 后绝对旋转超限
3. **IK 残差中位 311.7mm**: 目标位姿远离可达区域，不是边缘问题而是根本性偏离

### 最可能的原因（按概率排序）

**① checkpoint 12500 步训练不足**（最可能）

eef_delta 比 qpos 更难学：需要在 SO(3) 上复合旋转 delta、需要理解 condition frame 的相对性。
12500 步对 8.52B 参数的模型来说可能远不够。

**② 训练时 condition frame 采样策略与推理不匹配**

训练时 condition frame 可能从轨迹中间帧采样，推理时总是用当前帧。
训练分布和推理分布不匹配时模型外推能力不足。

**③ 训练侧 eef 数据生成问题**

如果训练时 `observation.state.eef` / `action.eef` parquet 列的生成方式
与推理时的 FK/`from_delta` 不完全一致，模型学到的是错误映射。

---

## 7. 建议的下一步

### 短期验证

| 优先级 | 动作 | 目的 |
|---|---|---|
| **高** | 用 qpos checkpoint 跑 `inference_motusv2.sh` | 确认问题在 eef_delta 模型本身，而非推理环境 |
| **高** | 检查 eef_delta checkpoint 的训练 loss 曲线 | 确认 12500 步时 action loss 是否还在下降 |
| 中 | 如果有更晚的 checkpoint（25000、50000 步），换用 | 验证是否训练步数不足 |
| 中 | 检查训练侧 `tools/g1_qpos_to_eef.py` 的 FK/`to_delta` 实现 | 确认与推理侧 `eef_delta.py` 完全一致 |

### 如果必须用当前 checkpoint

| 方案 | 效果 | 风险 |
|---|---|---|
| 放宽 `max_ik_error`（5mm→20mm）和 `max_joint_step`（0.3→0.8） | 让机器人动起来 | 动作质量仍差，可能危险 |
| 对模型输出做 clamp（gripper→[3.6,5.4]，rotation→训练范围） | 减少超限 | 治标不治本 |
| 降低 `num_inference_steps`（10→5） | 减少发散 | 不太可能根因 |

### 根本解决

继续训练 eef_delta checkpoint 到更多步数，或检查训练侧的 eef 数据生成是否正确。

---

## 8. 带日志记录的运行命令

```bash
cd /home/robo/codes/InferenceMotusV2

LOG_DIR=logs
mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/inference_eef_delta_$(date +%Y%m%d_%H%M%S).log"

# stdout + stderr 全部同步写入 log，同时回显到终端
bash scripts/inference_motusv2_eef_delta.sh 2>&1 | tee "$LOG_FILE"
```

关键点：
- `2>&1` 合并 stderr 到 stdout（Python logging 多走 stderr）
- `tee` 同时输出到终端和文件
- 文件名带时间戳，避免覆盖

---

## 附录 A: 关键代码位置

| 文件 | 行号 | 内容 |
|---|---|---|
| `adapter.py` | 523-620 | `observation_to_model_input` — 构建 state_tensor |
| `adapter.py` | 644-692 | `eef_action_to_g1_action` — denorm + from_delta + IK |
| `adapter.py` | 843-953 | `predict_action_chunk` — 模型推理 |
| `adapter.py` | 745-788 | IK 拒绝逻辑（`max_ik_error` / `max_joint_step`） |
| `eef_delta.py` | 82-115 | `to_delta` / `from_delta` — SO(3) 旋转复合 |
| `eef_delta.py` | 121-157 | `MinMaxNormalizer` + `load_normalizers` |
| `eef_delta.py` | 163-296 | `G1EefKinematics` — FK/IK 实现 |
| `eef_delta.py` | 229-239 | `fk_state` — qpos→16维 EEF state |
| `motus_wan_vlm_direct_mask.py` | 1240-1387 | `inference_step` — 模型推理入口 |
| `robot_arm.py` | 76-235 | `G1_29_ArmController` — 机器人控制器 |
| `robot_arm_ik.py` | 20-287 | `G1_29_ArmIK` — 控制器 IK（推理中仅用 solve_tau） |

## 附录 B: 关键配置值

| 参数 | 值 | 来源 |
|---|---|---|
| `action_mode` | `eef_delta` | config yaml:103 |
| `action_dim` / `state_dim` | 16 | config yaml:75-76 |
| `action_chunk_size` | 64 (8 frames × 8 ratio) | config yaml:88 |
| `global_downsample_rate` | 1 | config yaml:87 |
| `num_inference_timesteps` | 10 | config yaml:157 |
| `normalization` | true | config yaml:104 |
| `max_ik_error` | 5e-3 (5mm) | adapter.py:287 |
| `max_joint_step` | 0.3 rad | 脚本参数 |
| `TCP_OFFSET` | [0.05, 0, 0] | eef_delta.py:43 |
| `REPORT_FRAME_TO_TORSO` | [-0.0039635, 0, 0.044] | eef_delta.py:44 |
| `GRIPPER_DIMS` | (7, 15) | eef_delta.py:41 |
| `RESERVED_DIMS` | (6, 14) | eef_delta.py:40 |

## 附录 C: eef_stats.json 关键值

| 维度 | label | min | max | delta_min | delta_max |
|---|---|---|---|---|---|
| 0 | L_x | -0.0151 | +0.4118 | -0.4111 | +0.1604 |
| 1 | L_y | -0.0364 | +0.4733 | -0.2733 | +0.3216 |
| 2 | L_z | -0.1187 | +0.3475 | -0.2993 | +0.3577 |
| 3 | L_rx | -1.2822 | +2.2383 | -2.5719 | +1.8255 |
| 4 | L_ry | -1.1567 | +1.6275 | -1.6377 | +1.8809 |
| 5 | L_rz | -1.3368 | +1.4993 | -2.0007 | +2.1810 |
| 7 | L_grip | +3.6476 | +5.4000 | +3.6476 | +5.4000 |
| 8 | R_x | -0.0998 | +0.4044 | -0.4330 | +0.1747 |
| 9 | R_y | -0.5161 | +0.0408 | -0.2892 | +0.2874 |
| 10 | R_z | -0.1199 | +0.3974 | -0.3566 | +0.3494 |
| 11 | R_rx | -2.2211 | +0.9752 | -2.1833 | +2.6978 |
| 12 | R_ry | -1.5732 | +1.6506 | -1.8665 | +1.4418 |
| 13 | R_rz | -1.6445 | +1.2905 | -2.0881 | +1.9011 |
| 15 | R_grip | +1.9548 | +5.4137 | +1.9548 | +5.4137 |

# EEF Delta 诊断对话记录

> 日期：2026-08-27
> 主题：G1-D 机器人 eef_delta 推理畸形姿态诊断 — 深入分析 unitree_eai 遥操代码与训练/推理一致性验证

---

## 目录

1. [背景回顾](#1-背景回顾)
2. [unitree_eai 是否直接从机器人读取 EEF？](#2-unitree_eai-是否直接从机器人读取-eef)
3. [两套 IK 解算方式的差异](#3-两套-ik-解算方式的差异)
4. [遥操如何保证机器人 EEF 跟随手柄？](#4-遥操如何保证机器人-eef-跟随手柄)
5. [unitree_eai 使用的 URDF 是否与我们相同？](#5-unitree_eai-使用的-urdf-是否与我们相同)
6. [能否替换 FK/IK 为 unitree_eai 的实现？](#6-能否替换-fkik-为-unitree_eai-的实现)
7. [遥操录制是否记录 EEF 轨迹？](#7-遥操录制是否记录-eef-轨迹)
8. [训练侧 vs 推理侧一致性验证（Parity Test）](#8-训练侧-vs-推理侧一致性验证parity-test)
9. [最终结论](#9-最终结论)

---

## 1. 背景回顾

### 已完成的诊断工作

在本次对话之前，已完成以下诊断（详见 `logs/diagnostic_report_eef_delta.md`）：

- **Checkpoint**：`WanVlmMask-G1D-PickKettle-DeltaEEF-12500`（12500 步，8.52B 参数）
- **Config**：`configs/g1d_pick_kettle_wan_vlm_mask_eef_delta.yaml` — `action_mode: "eef_delta"`, `action_dim: 16`, `state_dim: 16`, `action_chunk_size: 64`, `num_inference_timesteps: 10`
- **state_tensor** = [1,16] float32：绝对 TCP 位姿（xyz + rotvec）+ 每臂夹爪，使用 `eef_stats.json` 的 min/max 归一化到 [0,1]
- **action** = 归一化 delta 偏移；反归一化后通过 `from_delta()` 组合到 condition pose，再 IK 到关节角
- **URDF** 在两套运动学系统之间 bit-identical

### 根因初步定位

- **984/984 IK 尝试全部被拒绝**（305 帧 unreachable，中位残差 311.7mm；679 帧 joint-step，中位跳变 1.176 rad）
- 机械臂从未移动，停留在数据集初始位姿
- 模型输出 EEF 目标系统性超出训练范围
- 根因：模型动作质量不足（checkpoint 12500 步对 eef_delta 训练不足，或训练/推理 condition frame 采样不匹配）

### 本次对话的新增问题

用户提出三个深入问题：

1. unitree_eai 遥操代码获取 EEF 的方式是否与我们不同？能否直接从机器人读取 EEF？
2. 我们的 IK 解算与 unitree_eai 的解算方式是否有差异？
3. 能否将我们的 FK/IK 替换为 unitree_eai 的实现？

---

## 2. unitree_eai 是否直接从机器人读取 EEF？

### 代码路径

`/home/robo/codes/unitree_eai/xr_teleoperate/teleop/teleop_hand_and_arm.py`

### 关键代码（339-345 行）

```python
# get current robot state data.
current_lr_arm_q  = arm_ctrl.get_current_dual_arm_q()           # ① 读关节角
left_arm_pose_state, right_arm_pose_state = arm_ik.solve_fk(current_lr_arm_q)  # ② FK 算 EEF（仅用于录制）
# solve ik using motor data and wrist pose, then use ik results to control arms.
sol_q, sol_tauff  = arm_ik.solve_ik(tele_data.left_wrist_pose, tele_data.right_wrist_pose, current_lr_arm_q)  # ③ IK
left_arm_pose_action, right_arm_pose_action = arm_ik.solve_fk(sol_q)  # ④ FK 算动作 EEF（仅用于录制）
```

### 结论

**unitree_eai 也没有直接从机器人读 EEF，和我们一样是用 qpos → FK 算出来的。**

- **`current_lr_arm_q`** = `arm_ctrl.get_current_dual_arm_q()` — 从 SDK 读关节角，和 InferenceMotusV2 完全一样
- **`left_arm_pose_state`** = `arm_ik.solve_fk(current_lr_arm_q)` — 用 FK 从 qpos 算 EEF state，和 InferenceMotusV2 的 `fk_state()` 完全一样
- **`tele_data.left_wrist_pose`** — 这是 XR（VR）设备追踪到的人手腕位姿，是**遥操目标**，不是机器人读数

G1 SDK（`G1_29_ArmController`）只暴露关节级接口：`get_current_dual_arm_q()`、`get_current_dual_arm_dq()`、`ctrl_dual_arm(q, tau)`，**没有笛卡尔/EEF 位姿读取接口**。两套系统都是从 qpos 通过 FK 计算 EEF，不存在"直接读 EEF"的可能。

---

## 3. 两套 IK 解算方式的差异

### 对比表

| 对比项 | unitree_eai (`G1_29_ArmIK`) | InferenceMotusV2 (`G1EefKinematics`) |
|---|---|---|
| **求解器** | CasADi + IPOPT（非线性规划 NLP） | 阻尼最小二乘 DLS（雅可比迭代） |
| **优化目标** | 多目标加权：`50×平移误差 + 旋转误差 + 0.02×关节正则 + 0.1×平滑项` | 纯误差最小化 + 零空间偏置 |
| **旋转误差** | `log3`（SO(3) 测地距离） | `log6`（SE(3) 平移+旋转合并） |
| **平滑性** | 显式 `smooth_cost = sum_sqr(q - q_last)` + **加权移动滤波器** [0.4,0.3,0.2,0.1] | 无时间平滑，每帧独立求解 |
| **零空间处理** | 关节正则 `sum_sqr(q)`（惩罚大关节角） | 向**绝对静止姿态**偏置，按关节范围加权 `w = 1/(hi-lo)²` |
| **最大迭代** | 30（IPOPT） | 100（DLS） |
| **失败处理** | 返回当前 q（**保持不动**） | **冷启动重试**（从中间姿态重新求解） |
| **关节限位** | 约束（bounded，IPOPT 内部处理） | 硬裁剪 `clip(q, lo, hi)` |
| **输入** | 左右手腕 4×4 齐次矩阵 | 16 维 EEF 向量（xyz + rotvec + gripper） |
| **输出后处理** | WeightedMovingFilter 4 帧平滑 | 无 |
| **设计场景** | 实时遥操 30Hz，处理 VR 追踪噪声 | 策略动作执行，精确跟踪 chunk |

### 关键差异的影响

**unitree_eai 的 IK 更适合遥操**：
1. IPOPT 多目标优化产生**更平滑的轨迹**（smooth_cost + 移动滤波器）
2. 失败时**保持不动**，对操作员安全
3. 能吸收 VR 追踪的抖动

**InferenceMotusV2 的 IK 更精确但更"硬"**：
1. DLS 收敛到精确目标（如果可达）
2. **无时间平滑**——每一帧独立求解，action chunk 内相邻帧之间可能跳变
3. 冷启动重试可能导致**位置突跳**
4. 零空间偏置向绝对 rest 姿态，防止冗余自由度漂移，但不保证连续性

### 旋转表示差异（与 IK 无关，但影响数据格式）

| | unitree_eai `solve_fk` | InferenceMotusV2 `fk_state` |
|---|---|---|
| 旋转表示 | XYZ 欧拉角 `as_euler('xyz')` | 旋转向量 `log3` / `as_rotvec` |
| 参考系 | pelvis（reduced model root） | report frame = torso_link + REPORT_FRAME_TO_TORSO |

- 旋转表示不同，但 InferenceMotusV2 用 rotvec 是因为**训练数据用 rotvec**，这是正确的（训练一致性）
- 参考系在 waist=0 时数学上等价（已验证）

---

## 4. 遥操如何保证机器人 EEF 跟随手柄？

### 核心澄清

`solve_fk(current_lr_arm_q)` 不是用于跟随闭环。看 teleop 主循环：

```
VR 手柄位姿 (绝对，机器人坐标系)
        │
        ▼
   IK 求解: 找 sol_q 使得 FK(sol_q) ≈ 手柄位姿
        │   - 初始猜测 = 当前关节角 (warm start)
        │   - smooth_cost + 移动滤波 → 平滑
        ▼
   ctrl_dual_arm(sol_q) → 关节位置控制器 (PD)
        │
        ▼
   实际关节角 ≈ sol_q  (PD 控制器保证跟踪)
        │
        ▼
   实际 EEF = FK(实际关节角) ≈ FK(sol_q) ≈ 手柄位姿  ✓
```

### 跟随精度依赖三件事

1. **关节控制器跟踪精度** — SDK 内置 PD 位置控制，保证 `实际 q ≈ 指令 q`
2. **运动学模型准确** — URDF 准确反映实际机器人几何
3. **IK 求解精度** — IPOPT 优化到 `tol=1e-4`

**不存在"测量 EEF → 反馈 → 修正"的笛卡尔闭环**。整个系统是关节空间闭环：手柄给目标位姿 → IK 算出对应关节角 → 关节控制器精确执行 → 假设模型准确则 EEF 自然到位。

### 与 InferenceMotusV2 eef_delta 的关键区别

| | unitree_eai 遥操 | InferenceMotusV2 eef_delta |
|---|---|---|
| **目标来源** | VR 手柄实时位姿（物理可达，人手在机器人 workspace 内） | 模型预测的 EEF 目标 |
| **目标质量** | 人手平滑、连续、物理合理 | 模型输出可能超出训练范围、不连续 |
| **闭环频率** | 30Hz 实时闭环，每帧修正 | chunk=64 帧开环执行，中间无修正 |
| **失败处理** | 保持不动，人重新调整手柄 | IK 拒绝 → 机械臂不动 |

**核心区别**：遥操的目标是人手在物理空间中的实时位姿，天然可达且平滑；我们的目标是模型预测的 EEF，如果模型输出超范围，IK 无解，机械臂就不动。这印证了诊断报告的结论——问题在模型输出质量，不在 IK。

---

## 5. unitree_eai 使用的 URDF 是否与我们相同？

### MD5 校验

| 文件 | MD5 |
|---|---|
| `InferenceMotusV2/assets/g1_body29_hand14.urdf` | `cddd25e97ae95fb33da624cc872a0783` |
| `unitree_lerobot/.../assets/g1/g1_body29_hand14.urdf` | `cddd25e97ae95fb33da624cc872a0783` ← 与 InferenceMotusV2 **相同** |
| **`xr_teleoperate/assets/g1/g1_body29_hand14.urdf`**（teleop 实际使用） | `b2acaa069d0231b1574e84b0a4569c95` ← **MD5 不同** |

### Diff 结果

```diff
1476c1476
< </robot>
---
> </robot>
\ No newline at end of file
```

差异只是**文件末尾的换行符**——teleop 版本没有 trailing newline，InferenceMotusV2 版本有一个。去掉换行后 diff 为空（exit code 0）。

### 结论

**三个文件内容完全相同**，只是末尾换行符的差异导致 MD5 不同。URDF 是同一个，运动学模型一致。

---

## 6. 能否替换 FK/IK 为 unitree_eai 的实现？

### 不建议替换的原因

#### FK/IK 本身已验证正确

| 验证项 | 结果 |
|---|---|
| FK 输出 16 维全部落在 `eef_stats.json` [min,max] 内 | ✓ |
| 归一化后全部在 [0,1] | ✓ |
| IK warm seed round-trip 误差 | 0 rad |
| IK cold seed round-trip 误差 | 0.039 rad |
| URDF 内容 | 与 unitree_eai 完全一致 |
| TCP offset [0.05,0,0] | 与 unitree_eai 一致 |
| 关节顺序、关节限位 | 与 unitree_eai 一致 |

#### 984 帧 IK 失败的真正原因

- **305 帧 "unreachable"**（中位残差 311.7mm）——目标离工作空间中心 30cm 以上，**任何 IK 求解器都解不出来**，IPOPT 也不行
- **679 帧 "joint-step"**（中位关节跳变 1.176 rad）——目标理论上可达，但 adapter 有安全阈值拒绝大跳变

305 帧的 311.7mm 残差是**几何不可达**，换什么求解器都一样。这是模型输出超范围的直接证据。

#### 替换 FK 会破坏训练一致性

| | InferenceMotusV2 `fk_state` | unitree_eai `solve_fk` |
|---|---|---|
| 旋转表示 | **旋转向量** `log3` | **XYZ 欧拉角** `as_euler('xyz')` |
| 参考系 | **report frame** (torso + REPORT_FRAME_TO_TORSO) | **pelvis** (reduced model root) |
| 输出格式 | 16 维向量 [xyz, rotvec, resv, grip]×2 | 两个 (xyz, rpy) 元组 |

训练数据用的是 rotvec + report frame。如果 FK 换成 xyzrpy + pelvis，**模型输入的 state 分布会完全改变**，归一化常数 `eef_stats.json` 也会失效。这不是改进，是破坏。

#### 替换 IK 求解器：治标不治本

可以把 DLS 换成 IPOPT，但：

1. **305 帧几何不可达**——IPOPT 也解不出来
2. **679 帧关节跳变**——IPOPT 的 smooth_cost + 移动滤波器**可能**让跳变更平滑，但这意味着机械臂会执行超出训练范围的危险动作，只是"更平滑地犯错"
3. 接口适配工作量大：IPOPT 接收 4×4 矩阵，当前是 16 维向量；需要重写 `_targets_from_vec`、`from_delta` 组合逻辑

### 值得借鉴的部分

**WeightedMovingFilter**（加权移动滤波器 [0.4, 0.3, 0.2, 0.1]）

这不改变 FK/IK 求解，只在 IK 输出的 `sol_q` 上做 4 帧加权平滑。对 action chunk 执行时的帧间跳变有帮助。但前提还是模型输出在合理范围内。

---

## 7. 遥操录制是否记录 EEF 轨迹？

### 是的，记录在 `left_arm_pose` / `right_arm_pose` 字段

`teleop_hand_and_arm.py` 录制部分（443-553 行）：

```python
states = {
    "left_arm":      {"qpos": left_arm_state.tolist(), ...},        # 关节角
    "right_arm":     {"qpos": right_arm_state.tolist(), ...},
    "left_arm_pose": {"qpos": left_arm_pose_state.tolist(), ...},   # ← EEF state
    "right_arm_pose":{"qpos": right_arm_pose_state.tolist(), ...},  # ← EEF state
    "left_ee":       {"qpos": left_ee_state, ...},                  # 夹爪
    "right_ee":      {"qpos": right_ee_state, ...},
    ...
}
actions = {
    "left_arm":      {"qpos": left_arm_action.tolist(), ...},       # IK 解的关节角
    "right_arm":     {"qpos": right_arm_action.tolist(), ...},
    "left_arm_pose": {"qpos": left_arm_pose_action.tolist(), ...},  # ← EEF action
    "right_arm_pose":{"qpos": right_arm_pose_action.tolist(), ...}, # ← EEF action
    ...
}
```

### 字段对应关系

| 字段 | 含义 | 来源 |
|---|---|---|
| `states.left_arm_pose.qpos` | 当前帧 EEF 位姿（6 维 xyzrpy） | `solve_fk(current_q)` |
| `states.right_arm_pose.qpos` | 当前帧 EEF 位姿（6 维 xyzrpy） | `solve_fk(current_q)` |
| `actions.left_arm_pose.qpos` | IK 目标 EEF 位姿（6 维 xyzrpy） | `solve_fk(sol_q)` |
| `actions.right_arm_pose.qpos` | IK 目标 EEF 位姿（6 维 xyzrpy） | `solve_fk(sol_q)` |

### ⚠️ 格式与 InferenceMotusV2 训练数据不同

| | teleop 录制的 `left_arm_pose` | InferenceMotusV2 训练用的 `observation.state.eef` |
|---|---|---|
| 旋转表示 | **XYZ 欧拉角** | **旋转向量** (rotvec) |
| 维度 | 6 (xyz + rpy) | 8 (xyz + rotvec + resv + grip) |
| 参考系 | pelvis (reduced model root) | report frame (torso + offset) |
| 夹爪 | 单独在 `left_ee` 字段 | 合并在 16 维向量内 |

**所以 teleop 录制的 `*_arm_pose` 字段不能直接作为 eef_delta 训练输入**——训练侧需要用 `tools/g1_qpos_to_eef.py` 重新从 qpos 转换成 rotvec + report frame 格式的 16 维向量。这也解释了为什么训练机器人的数据集有预计算的 `.eef` 列，而本地 parquet 只有 `observation.state`（qpos）。

---

## 8. 训练侧 vs 推理侧一致性验证（Parity Test）

### 训练侧源文件

从训练机器获取到本地的文件：

- `/home/robo/codes/MotusV2-main/tools/g1_qpos_to_eef.py` — 训练侧 FK + 数据转换
- `/home/robo/codes/MotusV2-main/data/g1d/eef_actions.py` — 训练侧 delta 约定

### 推理侧文件

- `/home/robo/codes/InferenceMotusV2/scripts/motusv2_adapter/eef_delta.py` — 推理侧 FK/IK/delta/归一化

### 已有的 Parity Test

`/home/robo/codes/InferenceMotusV2/scripts/tests/test_eef_delta_parity.py` 设计用于验证推理侧和训练侧完全一致，但原路径指向训练机器（`/home/work/wenjj/MotusV2`），本地无法直接运行。

### 本地执行的 Parity Test 结果

使用 `inference_motus` conda 环境（有 pinocchio + scipy），将训练侧文件加载到本地对比：

#### 8.1 常量对比

```
=== 1. Constants ===
  GRIPPER_DIMS         inf=(7, 15)  train=(7, 15)  OK
  RESERVED_DIMS        inf=(6, 14)  train=(6, 14)  OK
  ARM_BASES            inf=(0, 8)  train=(0, 8)  OK
  ACTION_DIM           inf=16  train=16  OK
  TCP_OFFSET           inf=[0.05 0. 0.]  train=[0.05 0. 0.]  OK
  REPORT_FRAME_TO_TORSO inf=[-0.0039635 0. 0.044]  train=[-0.0039635 0. 0.044]  OK
  ARM_JOINTS           OK
```

#### 8.2 to_delta / from_delta 对比

```
=== 2. to_delta / from_delta ===
  to_delta max diff: 0.00e+00  OK
  from_delta round-trip: 5.55e-16  OK
```

`to_delta` 差异为 **0**（逐字节相同的代码），round-trip 误差 5.55e-16（机器精度）。

#### 8.3 FK 对比（关键验证）

推理侧用 `g1_body29_hand14.urdf` + reduced model，训练侧用 `g1_d.urdf` + full model。100 帧随机关节角：

```
Inference model: nq=14, nframes=108
Training full model: nq=31, njoints=32
Training qadr: [3, 4, 5, 6, 7, 8, 9, 17, 18, 19, 20, 21, 22, 23]

=== FK Comparison ===
  FK position worst diff:  0.00 um  (OK)
  FK rotation worst diff:  0.00e+00 rad  (OK)
```

**FK 完全一致——100 帧随机关节角，位置和旋转差异都是 0。** 两个 URDF 的手臂运动学链是等价的。

#### 8.4 全链路 Round-Trip

qpos → FK → delta → normalize → denormalize → from_delta → IK：

```
=== Full Chain Round-Trip ===
  abs target recovery: 0.00 um  (OK)
  IK position error:    0.0208 mm  (OK)
  joint deviation:      0.6849 rad (redundancy, not error)

=== Normalizer ===
  round-trip: 5.13e-16  (OK)
  reserved dims stay zero: OK

ALL PARITY CHECKS PASSED
```

### Parity Test 汇总

| 验证项 | 容差 | 结果 | 状态 |
|---|---|---|---|
| **常量** (TCP_OFFSET, REPORT_FRAME, ARM_JOINTS, GRIPPER_DIMS, RESERVED_DIMS, ARM_BASES) | 精确匹配 | 全部一致 | ✅ |
| **to_delta** | 1e-12 | **0.00** (完全相同) | ✅ |
| **from_delta** round-trip | 1e-9 | 5.55e-16 | ✅ |
| **FK** (100 帧随机关节角，两个不同 URDF) | 10 μm / 1e-5 rad | **0.00 μm / 0.00 rad** | ✅ |
| **全链路 round-trip** | 10 μm + IK<1mm | 0.00 μm + 0.02mm | ✅ |
| **归一化** 可逆性 | 1e-5 | 5.13e-16 | ✅ |
| **reserved dims** 保持零 | — | 通过 | ✅ |

---

## 9. 最终结论

### 9.1 EEF 获取方式

**两套系统完全一样**，都是 qpos → FK → EEF。G1 SDK 不提供直接读 EEF 的接口，unitree_eai 也没有这么做。

### 9.2 IK 解算差异

**差异显著但与根因无关**：

- unitree_eai 用 IPOPT 优化 + 移动滤波（平滑、鲁棒、失败保持不动）
- InferenceMotusV2 用 DLS 雅可比（精确、无平滑、失败冷启动重试）
- 305 帧的 311.7mm 残差是几何不可达，换什么求解器都一样

### 9.3 URDF 一致性

**三个 URDF 文件内容完全相同**（仅末尾换行符差异）。运动学模型一致。

### 9.4 训练/推理一致性

**推理侧的 FK/IK/delta/归一化与训练侧完全一致，没有任何差异**：

- FK：100 帧随机角度，位置和旋转差异为 0
- to_delta / from_delta：差异为 0
- 全链路 round-trip：0.02mm
- 归一化：机器精度

**这彻底排除了 FK/IK 实现不一致导致推理畸形的可能性。**

### 9.5 根因确认

问题确实在**模型输出质量**上：

- Checkpoint 12500 步对 eef_delta 模式训练不足
- 或训练/推理 condition frame 采样方式不匹配

### 9.6 建议的下一步

1. **用 qpos checkpoint 跑对比验证** — 确认问题是否 eef_delta 特有
2. **检查训练 loss 曲线** — 确认 12500 步是否训练不足
3. **尝试更晚的 checkpoint**（25000+, 50000+）
4. **验证训练侧 condition frame 采样** — 确认训练/推理采样方式一致
5. **（可选）借鉴 WeightedMovingFilter** — 对 action chunk 执行时的帧间跳变有帮助，但前提是模型输出在合理范围内

---

## 相关文件索引

| 文件 | 说明 |
|---|---|
| `scripts/inference_motusv2_eef_delta.sh` | 主推理入口脚本 |
| `scripts/eval_g1_motus.py` | eval 循环 |
| `scripts/motusv2_adapter/adapter.py` | MotusV2PolicyAdapter |
| `scripts/motusv2_adapter/eef_delta.py` | 推理侧 FK/IK/delta/归一化 |
| `configs/g1d_pick_kettle_wan_vlm_mask_eef_delta.yaml` | 推理配置 |
| `assets/eef_stats.json` | 归一化常数 |
| `assets/g1_body29_hand14.urdf` | 推理侧 URDF |
| `logs/diagnostic_report_eef_delta.md` | 初始诊断报告 |
| `logs/inference_eef_delta_20260826.log` | 运行时日志 |
| `scripts/tests/test_eef_delta_parity.py` | Parity test（原始版本） |
| — | — |
| `/home/robo/codes/MotusV2-main/tools/g1_qpos_to_eef.py` | 训练侧 FK + 数据转换 |
| `/home/robo/codes/MotusV2-main/data/g1d/eef_actions.py` | 训练侧 delta 约定 |
| — | — |
| `/home/robo/codes/unitree_eai/xr_teleoperate/teleop/teleop_hand_and_arm.py` | 遥操主循环 |
| `/home/robo/codes/unitree_eai/xr_teleoperate/teleop/robot_control/robot_arm_ik.py` | 遥操 IK（IPOPT） |
| `/home/robo/codes/unitree_eai/xr_teleoperate/teleop/robot_control/robot_arm.py` | 遥操机械臂控制 |
| `/home/robo/codes/unitree_eai/xr_teleoperate/assets/g1/g1_body29_hand14.urdf` | 遥操 URDF |

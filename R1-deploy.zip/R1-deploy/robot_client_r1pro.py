"""Robot client for r1pro.py (ros2_robot_omni) → RLDX websocket server."""

from __future__ import annotations

import argparse
import dataclasses
import time
from collections import deque

import numpy as np
import rclpy
from pynput import keyboard

from r1pro import r1pro_robot
from utils import extract_action_chunk
from websocket_policy_client import WebsocketClientPolicy

HELP_TEXT = """
Robot client (r1pro):
    a - Send a single action (request first if queue empty)
    r - Request actions from server
    l - Loop: execute actions and replan
    p - Pause loop
    q - Quit
"""


@dataclasses.dataclass
class Args:
    host: str = "127.0.0.1"
    port: int = 8010
    task: str = "Pick up the bottle"
    replan_steps: int = 10
    hz: int = 15


def main(args: Args) -> None:
    rclpy.init()
    robot = r1pro_robot
    print(f"Connecting to policy server {args.host}:{args.port}")
    policy_client = WebsocketClientPolicy(host=args.host, port=args.port)
    print("Connected")

    actions: deque = deque()
    context = {"action_index": 0, "quit": False, "loop": False, "has_shown_help": False}
    obs: dict = {"prompt": args.task, "task": args.task}

    def get_actions() -> None:
        if not robot.observation:
            print("Robot observation not ready (all r1pro topics required)")
            return
        obs.update(robot.observation)
        print(f"Sending obs keys: {list(obs.keys())}")
        prediction = policy_client.infer(obs)
        chunk = extract_action_chunk(prediction)[: args.replan_steps]
        print(f"Received {len(chunk)} actions, first={chunk[0] if len(chunk) else None}")
        context["action_index"] = 0
        actions.clear()
        actions.extend(chunk)

    def send_action() -> None:
        if not actions:
            print("No actions in queue")
            return
        action = actions.popleft()
        pub = robot.get_publisher("arm_right_publisher")
        from sensor_msgs.msg import JointState

        msg = JointState()
        msg.position = action[:7].tolist()
        msg.velocity = [0.5] * 7
        pub.publish(msg)
        if action.shape[0] >= 8:
            grip_pub = robot.get_publisher("gripper_right_publisher")
            grip = JointState()
            grip.position = action[7:8].tolist()
            grip.velocity = [0.3]
            grip_pub.publish(grip)
        print(f"Sent action #{context['action_index']}: {action}, remaining={len(actions)}")
        context["action_index"] += 1

    def on_press(key) -> None:
        try:
            if key.char == "a":
                if not actions:
                    get_actions()
                send_action()
            elif key.char == "r":
                get_actions()
            elif key.char == "l":
                context["loop"] = True
            elif key.char == "p":
                context["loop"] = False
            elif key.char == "q":
                context["quit"] = True
        except Exception as exc:
            print(f"Key handler error: {exc}")

    listener = keyboard.Listener(on_press=on_press)
    listener.start()

    ts_execute = time.time()
    execute_delay = 1.0 / args.hz
    try:
        while rclpy.ok() and not context["quit"]:
            rclpy.spin_once(robot, timeout_sec=0.001)
            now = time.time()
            if context["loop"] and now >= ts_execute:
                if not actions:
                    get_actions()
                if actions:
                    send_action()
                ts_execute = now + execute_delay
    except KeyboardInterrupt:
        pass
    finally:
        listener.stop()
        listener.join()
        robot.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="R1 Pro client using r1pro.py obs keys")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8010)
    parser.add_argument("--task", default="Pick up the bottle")
    parser.add_argument("--replan_steps", type=int, default=10)
    parser.add_argument("--hz", type=int, default=15)
    main(Args(**vars(parser.parse_args())))

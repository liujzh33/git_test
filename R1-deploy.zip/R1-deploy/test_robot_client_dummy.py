import numpy as np
from websocket_policy_client import WebsocketClientPolicy
import time


def make_dummy_example():
    return {
        "observation.image1": np.random.randint(
            256, size=(224, 224, 3), dtype=np.uint8
        ),
        "observation.image2": np.random.randint(
            256, size=(224, 224, 3), dtype=np.uint8
        ),
        "observation.image3": np.random.randint(
            256, size=(224, 224, 3), dtype=np.uint8
        ),
        "state": np.random.rand(8),
        "prompt": "pick up the bottle",
    }


def make_groot_dummy_example():
    return {
        # 应该是 256x256x3
        "observation.image": np.random.randint(256, size=(224, 224, 3), dtype=np.uint8),
        "observation.image2": np.random.randint(
            256, size=(224, 224, 3), dtype=np.uint8
        ),
        "state": np.random.rand(8),
        "prompt": "pick up the bottle",
    }

    # 返回 {"actions": np.ndarray of shape(50,8)}


def make_zero_vla_dummy_example():
    DUMMY_EE_POSE = np.random.rand(7)
    DUMMY_JOINT = np.random.rand(7)
    DUMMY_GRIPPER = np.random.rand(1)
    DUMMY_TORSO_JOINT = np.random.rand(4)
    return {
        "observation.state.left_ee_pose": DUMMY_EE_POSE,
        "observation.state.right_ee_pose": DUMMY_EE_POSE,
        "observation.state.torso": DUMMY_TORSO_JOINT,
        "observation.state.left_arm": DUMMY_JOINT,
        "observation.state.right_arm": DUMMY_JOINT,
        "observation.state.left_gripper": DUMMY_GRIPPER,
        "observation.state.right_gripper": DUMMY_GRIPPER,
        "observation.images.head_rgb": np.random.randint(
            256, size=(224, 224, 3), dtype=np.uint8
        ),
        "observation.images.left_hand_rgb": np.random.randint(
            256, size=(224, 224, 3), dtype=np.uint8
        ),
        "observation.images.right_hand_rgb": np.random.randint(
            256, size=(224, 224, 3), dtype=np.uint8
        ),
        "task": "pick up the bottle",
    }


def main():
    host = "10.90.79.79"
    port = 4577
    print(f"Connecting on {host}:{port}")
    policy_client = WebsocketClientPolicy(host=host, port=port)

    # inputs = make_dummy_example()
    inputs = make_zero_vla_dummy_example()

    begin_time = time.time()
    prediction = policy_client.infer(obs=inputs)
    print(f"Infer delay: {time.time() - begin_time}")

    print(f"The prediction is \n {prediction}")


if __name__ == "__main__":
    main()
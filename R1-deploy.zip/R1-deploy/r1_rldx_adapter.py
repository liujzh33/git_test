"""Convert R1-deploy websocket wire format ↔ RLDX-1 policy I/O."""

from __future__ import annotations

import logging
from typing import Any

import numpy as np

logger = logging.getLogger(__name__)

# model video key -> client flat keys (first match wins)
DEFAULT_VIDEO_ALIASES: dict[str, list[str]] = {
    "observation.images.rgb.head_256_256": [
        "observation.images.head_rgb",
        "observation.image3",
        "primary",
        "video.primary",
    ],
    "observation.images.rgb.left_wrist_256_256": [
        "observation.images.left_hand_rgb",
        "observation.image1",
        "wrist_left",
        "video.wrist_left",
    ],
    "observation.images.rgb.right_wrist_256_256": [
        "observation.images.right_hand_rgb",
        "observation.image2",
        "wrist_right",
        "video.wrist_right",
    ],
    "primary": ["observation.images.head_rgb", "observation.image3"],
    "wrist_left": ["observation.images.left_hand_rgb", "observation.image1"],
    "wrist_right": ["observation.images.right_hand_rgb", "observation.image2"],
    "egocentric_resized": ["observation.images.head_rgb", "observation.image3"],
    # X1 / general_embodiment training keys (x1_robot_config.py)
    "head": [
        "observation.images.base",  # custom R1 deploy client
        "observation.images.head_rgb",  # r1pro.py
        "observation.images.head",
        "observation.image3",  # robot_client.py / ros2_robot.py
        "primary",
        "video.head",
    ],
    "hand_left": [
        "observation.images.left_wrist",  # custom R1 deploy client
        "observation.images.left_hand_rgb",  # r1pro.py
        "observation.images.hand_left",
        "observation.image1",
        "wrist_left",
        "video.hand_left",
    ],
    "hand_right": [
        "observation.images.right_wrist",  # custom R1 deploy client
        "observation.images.right_hand_rgb",  # r1pro.py
        "observation.images.hand_right",
        "observation.image2",
        "wrist_right",
        "video.hand_right",
    ],
}

# model state key -> client flat keys
DEFAULT_STATE_ALIASES: dict[str, list[str]] = {
    "state": ["state"],
    "left_ee_pose": ["observation.state.left_ee_pose"],
    "right_ee_pose": ["observation.state.right_ee_pose"],
    "torso": ["observation.state.torso"],
    "left_arm": ["observation.state.left_arm"],
    "right_arm": ["observation.state.right_arm"],
    "left_gripper": ["observation.state.left_gripper"],
    "right_gripper": ["observation.state.right_gripper"],
    "left_hand": ["observation.state.left_gripper"],
    "right_hand": ["observation.state.right_gripper"],
    # X1 / general_embodiment training keys
    "base_wheels": ["observation.state.base_wheels", "base_wheels"],
    "torso_joints": [
        "observation.state.torso",  # r1pro.py
        "observation.state.torso_joints",
        "torso_joints",
    ],
    "left_arm_joints": [
        "observation.state.left_arm",  # r1pro.py
        "observation.state.left_arm_joints",
        "left_arm_joints",
    ],
    "right_arm_joints": [
        "observation.state.right_arm",  # r1pro.py
        "observation.state.right_arm_joints",
        "right_arm_joints",
    ],
}

# X1 full state layout (24-dim), see datasets/X1-Robot-dataset/meta/modality.json
X1_STATE_SLICES: dict[str, tuple[int, int]] = {
    "base_wheels": (0, 6),
    "torso_joints": (6, 10),
    "left_arm_joints": (10, 17),
    "right_arm_joints": (17, 24),
}
X1_STATE_DIMS: dict[str, int] = {k: e - s for k, (s, e) in X1_STATE_SLICES.items()}

# 16-dim observation.state: left_arm(7) + right_arm(7) + grippers(2)
R1_DUAL_ARM_STATE_SLICES: dict[str, tuple[int, int]] = {
    "left_arm_joints": (0, 7),
    "right_arm_joints": (7, 14),
}

X1_ACTION_KEYS = ("left_arm_joints", "right_arm_joints", "grippers")

# Substring hints for fuzzy video key matching (lowercased key names).
VIDEO_KEY_HINTS: dict[str, list[str]] = {
    "head": ["images.base", "head_rgb", "head", "image3", "primary", "high", "egocentric"],
    "hand_left": ["left_wrist", "left_hand_rgb", "hand_left", "left_hand", "image1", "wrist_left"],
    "hand_right": ["right_wrist", "right_hand_rgb", "hand_right", "right_hand", "image2", "wrist_right"],
}

R1_STATE_CONCAT_ORDER = [
    "observation.state.left_ee_pose",
    "observation.state.right_ee_pose",
    "observation.state.torso",
    "observation.state.left_arm",
    "observation.state.right_arm",
    "observation.state.left_gripper",
    "observation.state.right_gripper",
]


def is_rldx_nested_obs(obs: dict[str, Any]) -> bool:
    return (
        isinstance(obs, dict)
        and "video" in obs
        and "state" in obs
        and "language" in obs
        and isinstance(obs["video"], dict)
        and isinstance(obs["state"], dict)
        and isinstance(obs["language"], dict)
    )


def unwrap_wire_payload(payload: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any] | None]:
    if isinstance(payload, dict) and "observation" in payload:
        obs = payload["observation"]
        if isinstance(obs, dict):
            return expand_wire_obs({**payload, **obs}), payload.get("options")
        return obs, payload.get("options")
    return expand_wire_obs(payload), None


def _is_image_array(value: Any) -> bool:
    if not isinstance(value, np.ndarray):
        return False
    if value.ndim == 3:
        return value.shape[-1] in (1, 3, 4) or value.shape[0] in (1, 3, 4)
    return value.ndim == 4 and value.shape[-1] in (1, 3, 4)


def expand_wire_obs(obs: dict[str, Any]) -> dict[str, Any]:
    """Flatten common nested observation layouts into a single lookup dict."""
    out: dict[str, Any] = dict(obs)

    def merge(prefix: str, inner: dict[str, Any]) -> None:
        for key, value in inner.items():
            full = f"{prefix}.{key}" if prefix else key
            out[full] = value
            out.setdefault(key, value)
            if isinstance(value, dict):
                merge(full, value)

    if isinstance(obs.get("observation"), dict):
        merge("observation", obs["observation"])
    if isinstance(obs.get("images"), dict):
        merge("observation.images", obs["images"])
    if isinstance(obs.get("video"), dict):
        merge("video", obs["video"])

    nested_images = obs.get("observation.images")
    if isinstance(nested_images, dict):
        merge("observation.images", nested_images)

    return out


def _lookup_flat(flat: dict[str, Any], aliases: list[str]) -> Any | None:
    for key in aliases:
        if key in flat:
            return flat[key]
    return None


def _list_payload_keys(flat: dict[str, Any]) -> str:
    parts: list[str] = []
    for key, value in flat.items():
        if _is_image_array(value):
            arr = np.asarray(value)
            parts.append(f"{key}(image{list(arr.shape)})")
        elif isinstance(value, np.ndarray):
            parts.append(f"{key}(array{list(value.shape)})")
        elif isinstance(value, dict):
            parts.append(f"{key}(dict)")
        else:
            parts.append(f"{key}({type(value).__name__})")
    return ", ".join(parts) if parts else "(empty)"


def _resolve_video_array(flat: dict[str, Any], video_key: str) -> np.ndarray | None:
    aliases = DEFAULT_VIDEO_ALIASES.get(
        video_key, [video_key, f"video.{video_key}", f"observation.images.{video_key}"]
    )
    raw = _lookup_flat(flat, aliases)
    if raw is not None:
        return np.asarray(raw)

    for hint in VIDEO_KEY_HINTS.get(video_key, [video_key]):
        for key, value in flat.items():
            if not _is_image_array(value):
                continue
            if hint in str(key).lower():
                return np.asarray(value)

    return None


def _flat_state_vector(flat: dict[str, Any]) -> np.ndarray | None:
    raw = _lookup_flat(flat, ["state", "observation.state"])
    if raw is None:
        return None
    return np.asarray(raw, dtype=np.float32).reshape(-1)


def _resolve_state_vector(flat: dict[str, Any], state_key: str) -> np.ndarray:
    aliases = DEFAULT_STATE_ALIASES.get(
        state_key, [state_key, f"observation.state.{state_key}"]
    )
    raw = _lookup_flat(flat, aliases)
    if raw is not None:
        return np.asarray(raw, dtype=np.float32).reshape(-1)

    full = _flat_state_vector(flat)
    if full is not None:
        if len(full) == sum(X1_STATE_DIMS.values()) and state_key in X1_STATE_SLICES:
            start, end = X1_STATE_SLICES[state_key]
            return full[start:end]
        if len(full) == 16 and state_key in R1_DUAL_ARM_STATE_SLICES:
            start, end = R1_DUAL_ARM_STATE_SLICES[state_key]
            return full[start:end]
        # R1-deploy: flat state is right_arm (7) + right_gripper (1)
        if state_key == "right_arm_joints" and len(full) >= 7:
            if len(full) == 8:
                return full[:7]
            return full[:7]
        if state_key == "left_arm_joints" and len(full) == 8:
            return np.zeros(X1_STATE_DIMS["left_arm_joints"], dtype=np.float32)

    if state_key in X1_STATE_DIMS:
        return np.zeros(X1_STATE_DIMS[state_key], dtype=np.float32)

    raise KeyError(f"Missing state observation for model key '{state_key}'")


def _to_hwc_uint8(image: np.ndarray) -> np.ndarray:
    arr = np.asarray(image)
    if arr.ndim == 3 and arr.shape[0] == 3:
        arr = np.transpose(arr, (1, 2, 0))
    if arr.dtype != np.uint8:
        if arr.size > 0 and arr.max() <= 1.0:
            arr = (arr * 255.0).clip(0, 255)
        arr = arr.astype(np.uint8)
    return arr


def _as_batched_video(image: np.ndarray) -> np.ndarray:
    hwc = _to_hwc_uint8(image)
    return hwc[np.newaxis, np.newaxis, ...]


def _as_batched_state(vector: np.ndarray) -> np.ndarray:
    vec = np.asarray(vector, dtype=np.float32).reshape(-1)
    return vec[np.newaxis, np.newaxis, :]


def _concat_r1_state(flat: dict[str, Any]) -> np.ndarray | None:
    parts: list[np.ndarray] = []
    for key in R1_STATE_CONCAT_ORDER:
        if key not in flat:
            continue
        parts.append(np.asarray(flat[key], dtype=np.float32).reshape(-1))
    if not parts:
        return None
    return np.concatenate(parts, axis=0)


def _language_text(flat: dict[str, Any]) -> str:
    for key in (
        "task",
        "prompt",
        "annotation.human.task_description",
        "annotation.human.coarse_action",
    ):
        value = flat.get(key)
        if isinstance(value, str) and value:
            return value
        if isinstance(value, (list, tuple)) and value and isinstance(value[0], str):
            return value[0]
    return ""


def wire_obs_to_rldx_obs(flat: dict[str, Any], modality_configs) -> dict[str, Any]:
    """Convert R1-deploy flat websocket obs to RLDX nested observation."""
    flat = expand_wire_obs(flat)
    if is_rldx_nested_obs(flat):
        return flat

    video_cfg = modality_configs["video"]
    state_cfg = modality_configs["state"]
    language_cfg = modality_configs["language"]

    video: dict[str, np.ndarray] = {}
    for video_key in video_cfg.modality_keys:
        raw = _resolve_video_array(flat, video_key)
        if raw is None:
            msg = (
                f"Missing video observation for model key '{video_key}'. "
                f"Received keys: {_list_payload_keys(flat)}"
            )
            logger.error(msg)
            raise KeyError(msg)
        video[video_key] = _as_batched_video(raw)

    state: dict[str, np.ndarray] = {}
    if len(state_cfg.modality_keys) == 1 and state_cfg.modality_keys[0] == "state":
        raw_state = _lookup_flat(flat, ["state"]) or _concat_r1_state(flat)
        if raw_state is None:
            raise KeyError("Missing state observation (expected 'state' or observation.state.*)")
        state["state"] = _as_batched_state(raw_state)
    else:
        for state_key in state_cfg.modality_keys:
            raw = _resolve_state_vector(flat, state_key)
            state[state_key] = _as_batched_state(raw)

    language: dict[str, list[list[str]]] = {}
    text = _language_text(flat)
    for language_key in language_cfg.modality_keys:
        if language_key in flat:
            value = flat[language_key]
            if isinstance(value, str):
                language[language_key] = [[value]]
            elif isinstance(value, (list, tuple)) and value:
                language[language_key] = [[str(value[0])]]
            else:
                language[language_key] = [[text]]
        elif language_key == "annotation.human.coarse_action" and "annotation.human.coarse_action" in flat:
            value = flat["annotation.human.coarse_action"]
            if isinstance(value, str):
                language[language_key] = [[value]]
            else:
                language[language_key] = [[str(value[0])]]
        else:
            language[language_key] = [[text]]

    return {"video": video, "state": state, "language": language}


def _r1_action_from_x1(action: dict[str, Any]) -> np.ndarray:
    """Map X1 action (left/right arm + 2 grippers) to R1 8-dim right-arm command."""
    right_arm = np.asarray(action["right_arm_joints"], dtype=np.float32)[0]
    grippers = np.asarray(action["grippers"], dtype=np.float32)[0]
    if grippers.shape[-1] >= 2:
        right_gripper = grippers[..., 1:2]
    else:
        right_gripper = grippers[..., :1]
    return np.concatenate([right_arm, right_gripper], axis=-1)


def rldx_action_to_wire(action: dict[str, Any], modality_configs) -> dict[str, Any]:
    """Flatten RLDX action dict into arrays expected by robot_client."""
    action_keys = modality_configs["action"].modality_keys
    chunks: list[np.ndarray] = []
    response: dict[str, Any] = {}

    for key in action_keys:
        if key not in action:
            raise KeyError(f"RLDX action missing key '{key}'")
        arr = np.asarray(action[key], dtype=np.float32)
        if arr.ndim != 3:
            raise ValueError(f"Expected action['{key}'] with shape (B, T, D), got {arr.shape}")
        step_arr = arr[0]
        chunks.append(step_arr)
        response[f"action.{key}"] = step_arr

    if tuple(action_keys) == X1_ACTION_KEYS:
        stacked = _r1_action_from_x1(action)
    else:
        stacked = np.concatenate(chunks, axis=-1) if len(chunks) > 1 else chunks[0]
    response["action"] = stacked
    response["actions"] = stacked
    return response

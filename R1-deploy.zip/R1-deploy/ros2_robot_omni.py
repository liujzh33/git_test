"""Configurable ROS2 robot node driven by topic/observation/publisher specs."""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

import cv2
import message_filters
import numpy as np
import rclpy
from geometry_msgs.msg import PoseStamped
from message_filters import ApproximateTimeSynchronizer
from rclpy.node import Node
from rclpy.qos import HistoryPolicy, QoSProfile, ReliabilityPolicy
from sensor_msgs.msg import CompressedImage, JointState


def decode_image(proto_msg: CompressedImage) -> np.ndarray:
    arr = np.frombuffer(proto_msg.data, dtype=np.uint8)
    img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError("Failed to decode compressed image")
    return cv2.cvtColor(img, cv2.COLOR_BGR2RGB)


def joint_state_to_array(msg: JointState) -> np.ndarray:
    return np.array(msg.position, dtype=np.float32)


def pose_stamped_to_array(msg: PoseStamped) -> np.ndarray:
    pose = msg.pose
    return np.array(
        [
            pose.position.x,
            pose.position.y,
            pose.position.z,
            pose.orientation.x,
            pose.orientation.y,
            pose.orientation.z,
            pose.orientation.w,
        ],
        dtype=np.float32,
    )


@dataclass
class TopicSpec:
    topic_name: str
    msg_type: type
    transform: Callable[[Any], Any]
    sync_group: str | None = None


@dataclass
class ObservationSpec:
    key: str
    source_topics: list[str]
    transform: Callable[[Any], Any]


@dataclass
class PublisherSpec:
    topic_name: str
    msg_type: type
    identifier: str


@dataclass
class RobotTopics:
    topics: list[TopicSpec]
    observations: list[ObservationSpec]
    publishers: list[PublisherSpec]


class Robot(Node):
    def __init__(self, config: RobotTopics) -> None:
        super().__init__("omni_robot")
        self._config = config
        self._topic_values: dict[str, Any] = {}
        self._publishers: dict[str, Any] = {}

        camera_qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=10,
        )

        sync_groups: dict[str, list[tuple[TopicSpec, message_filters.Subscriber]]] = (
            defaultdict(list)
        )
        for spec in config.topics:
            if spec.sync_group:
                sub = message_filters.Subscriber(
                    self, spec.msg_type, spec.topic_name, qos_profile=camera_qos
                )
                sync_groups[spec.sync_group].append((spec, sub))
            else:
                self.create_subscription(
                    spec.msg_type,
                    spec.topic_name,
                    self._make_callback(spec),
                    10,
                )

        for items in sync_groups.values():
            specs = [entry[0] for entry in items]
            subs = [entry[1] for entry in items]
            synchronizer = ApproximateTimeSynchronizer(subs, queue_size=10, slop=0.1)
            synchronizer.registerCallback(self._make_sync_callback(specs))

        for pub_spec in config.publishers:
            self._publishers[pub_spec.identifier] = self.create_publisher(
                pub_spec.msg_type, pub_spec.topic_name, 10
            )

    def _make_callback(self, spec: TopicSpec):
        def callback(msg):
            self._topic_values[spec.topic_name] = spec.transform(msg)

        return callback

    def _make_sync_callback(self, specs: list[TopicSpec]):
        def callback(*msgs):
            for spec, msg in zip(specs, msgs):
                self._topic_values[spec.topic_name] = spec.transform(msg)

        return callback

    @property
    def observation(self) -> dict[str, Any] | None:
        result: dict[str, Any] = {}
        for obs_spec in self._config.observations:
            if len(obs_spec.source_topics) == 1:
                raw = self._topic_values.get(obs_spec.source_topics[0])
            else:
                parts = [self._topic_values.get(topic) for topic in obs_spec.source_topics]
                raw = None if any(part is None for part in parts) else parts
            if raw is None:
                return None
            result[obs_spec.key] = obs_spec.transform(raw)
        return result

    def get_publisher(self, identifier: str):
        return self._publishers[identifier]

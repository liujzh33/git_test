#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
import numpy as np
import cv2
import math
import time
from dataclasses import dataclass, asdict

from sensor_msgs.msg import CompressedImage, JointState
from std_msgs.msg import Header


@dataclass
class RobotTopics:
    """话题配置：用户需在此填入实际的话题名称，不需要的部分设为 None"""

    head_rgb: str = "/camera/camera/color/image_raw/compressed"

    # 左臂组
    left_wrist_rgb: str | None = "/hdas/camera_wrist_left/color/image_raw/compressed"
    left_arm_joint_state: str | None = "/hdas/feedback_arm_left"
    left_gripper_state: str | None = "/hdas/feedback_gripper_left"
    left_arm_action: str | None = "/motion_target/target_joint_state_arm_left"
    left_gripper_action: str | None = "/motion_target/target_position_gripper_left"

    # 右臂组
    right_wrist_rgb: str | None = "/hdas/camera_wrist_right/color/image_raw/compressed"
    right_arm_joint_state: str | None = "/hdas/feedback_arm_right"
    right_gripper_state: str | None = "/hdas/feedback_gripper_right"
    right_arm_action: str | None = "/motion_target/target_joint_state_arm_right"
    right_gripper_action: str | None = "/motion_target/target_position_gripper_right"


class MockRobotPublisher(Node):
    def __init__(self):
        super().__init__("mock_robot_publisher")

        # ================= 配置区域 =================
        self.fps = 30.0
        self.period = 1.0 / self.fps
        self.robot_topics = RobotTopics()

        # 话题定义 (与你之前的配置完全一致)
        self.topics = {
            "head_rgb": "/camera/camera/color/image_raw/compressed",
            "left_wrist_rgb": "/hdas/camera_wrist_left/color/image_raw/compressed",
            "left_arm_joint": "/hdas/feedback_arm_left",
            "left_gripper": "/hdas/feedback_gripper_left",
            "left_arm_action": "/motion_target/target_joint_state_arm_left",
            "left_gripper_action": "/motion_target/target_position_gripper_left",
            "right_wrist_rgb": "/hdas/camera_head/right_raw/image_raw_color/compressed",
            "right_arm_joint": "/hdas/feedback_arm_right",
            "right_gripper": "/hdas/feedback_gripper_right",
            "right_arm_action": "/motion_target/target_joint_state_arm_right",
            "right_gripper_action": "/motion_target/target_position_gripper_right",
        }
        self.topics.update(asdict(self.robot_topics))

        # 创建发布者
        self.pubs = {}
        # 图像发布者
        self.pubs["head_rgb"] = self.create_publisher(
            CompressedImage, self.topics["head_rgb"], 10
        )

        self.pubs["left_wrist_rgb"] = self.create_publisher(
            CompressedImage, self.topics["left_wrist_rgb"], 10
        )
        # 状态发布者
        self.pubs["left_arm_joint"] = self.create_publisher(
            JointState, self.topics["left_arm_joint"], 10
        )
        self.pubs["left_gripper"] = self.create_publisher(
            JointState, self.topics["left_gripper"], 10
        )
        # 动作发布者
        self.pubs["left_arm_action"] = self.create_publisher(
            JointState, self.topics["left_arm_action"], 10
        )
        self.pubs["left_gripper_action"] = self.create_publisher(
            JointState, self.topics["left_gripper_action"], 10
        )


        self.pubs["right_wrist_rgb"] = self.create_publisher(
            CompressedImage, self.topics["right_wrist_rgb"], 10
        )
        # 状态发布者
        self.pubs["right_arm_joint"] = self.create_publisher(
            JointState, self.topics["right_arm_joint"], 10
        )
        self.pubs["right_gripper"] = self.create_publisher(
            JointState, self.topics["right_gripper"], 10
        )
        # 动作发布者
        self.pubs["right_arm_action"] = self.create_publisher(
            JointState, self.topics["right_arm_action"], 10
        )
        self.pubs["right_gripper_action"] = self.create_publisher(
            JointState, self.topics["right_gripper_action"], 10
        )

        # 内部计数器，用于生成正弦波和移动图像
        self.counter = 0
        self.start_time = time.time()

        # 定时器
        self.timer = self.create_timer(self.period, self.timer_callback)
        self.get_logger().info(f"Mock Robot Started. Publishing at {self.fps} Hz...")

    def get_ros_header(self, frame_id):
        header = Header()
        header.frame_id = frame_id
        header.stamp = self.get_clock().now().to_msg()
        return header

    def generate_fake_image(self, width=320, height=240, color=(0, 255, 0)):
        """生成一个带有移动圆形的图像，模拟动态视频"""
        img = np.zeros((height, width, 3), dtype=np.uint8)

        # 让圆圈根据 counter 移动
        t = self.counter * 0.1
        cx = int(width / 2 + (width / 4) * math.sin(t))
        cy = int(height / 2 + (height / 4) * math.cos(t))

        # 画圆
        cv2.circle(img, (cx, cy), 80, color, -1)

        # 加时间戳文字
        cv2.putText(
            img,
            f"Frame: {self.counter}",
            (10, 30),
            cv2.FONT_HERSHEY_SIMPLEX,
            1,
            (255, 255, 255),
            2,
        )

        return img

    def pack_compressed_image(self, cv_img, frame_id):
        """将 OpenCV 图像打包为 CompressedImage"""
        msg = CompressedImage()
        msg.header = self.get_ros_header(frame_id)
        msg.format = "jpeg"
        # 编码为 JPEG
        success, encoded_data = cv2.imencode(".jpg", cv_img)
        if success:
            msg.data = encoded_data.tobytes()
        return msg

    def generate_joint_state(
        self, num_joints, frame_id, prefix="joint", phase_shift=0.0
    ):
        """生成正弦波关节数据"""
        msg = JointState()
        msg.header = self.get_ros_header(frame_id)

        t = self.counter * 0.05 + phase_shift

        msg.name = [f"{prefix}_{i}" for i in range(num_joints)]
        # 生成 -1.0 到 1.0 之间的正弦波
        msg.position = [math.sin(t + i * 0.5) for i in range(num_joints)]
        msg.velocity = [math.cos(t + i * 0.5) for i in range(num_joints)]  # 导数
        msg.effort = [0.0] * num_joints

        return msg

    def timer_callback(self):
        self.counter += 1

        # 1. 发布头部相机 (绿色圆圈)
        if self.counter % 3 == 0:
            head_img = self.generate_fake_image(color=(0, 255, 0))  # Green
            msg_head = self.pack_compressed_image(head_img, "camera_head_link")
            self.pubs["head_rgb"].publish(msg_head)

        # 2. 发布左腕相机 (红色圆圈)
        wrist_img = self.generate_fake_image(color=(0, 0, 255))  # Red
        msg_wrist = self.pack_compressed_image(wrist_img, "camera_left_wrist_link")
        self.pubs["left_wrist_rgb"].publish(msg_wrist)

        # 3. 发布左臂状态 (7个关节)
        msg_arm = self.generate_joint_state(
            7, "base_link", "left_arm", phase_shift=0.0
        )
        self.pubs["left_arm_joint"].publish(msg_arm)

        # 4. 发布左夹爪状态 (1个关节)
        msg_grip = self.generate_joint_state(
            1, "left_hand_link", "left_gripper", phase_shift=0.0
        )
        self.pubs["left_gripper"].publish(msg_grip)

        # # 5. 发布左臂 Action (通常 Action 是下一步的期望状态，这里加一点相位差模拟)
        # msg_arm_cmd = self.generate_joint_state(
        #     7, "base_link", "left_arm", phase_shift=0.5
        # )
        # self.pubs["left_arm_action"].publish(msg_arm_cmd)


        # 2. 发布左腕相机 (红色圆圈)
        wrist_img = self.generate_fake_image(color=(0, 0, 255))  # Red
        msg_wrist = self.pack_compressed_image(wrist_img, "camera_right_wrist_link")
        self.pubs["right_wrist_rgb"].publish(msg_wrist)

        # 3. 发布左臂状态 (7个关节)
        msg_arm = self.generate_joint_state(
            7, "base_link", "right_arm", phase_shift=0.0
        )
        self.pubs["right_arm_joint"].publish(msg_arm)

        # 4. 发布左夹爪状态 (1个关节)
        msg_grip = self.generate_joint_state(
            1, "right_hand_link", "right_gripper", phase_shift=0.0
        )
        self.pubs["right_gripper"].publish(msg_grip)

        # 5. 发布左臂 Action (通常 Action 是下一步的期望状态，这里加一点相位差模拟)
        # msg_arm_cmd = self.generate_joint_state(
        #     7, "base_link", "right_arm", phase_shift=0.5
        # )
        # self.pubs["right_arm_action"].publish(msg_arm_cmd)



        # 6. 发布左夹爪 Action
        # msg_grip_cmd = self.generate_joint_state(
        #     1, "right_hand_link", "right_gripper", phase_shift=0.5
        # )
        # self.pubs["right_gripper_action"].publish(msg_grip_cmd)

        if self.counter % 130 == 0:
            self.get_logger().info(f"Published {self.counter} frames...")


def main(args=None):
    rclpy.init(args=args)
    node = MockRobotPublisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
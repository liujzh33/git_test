## 启动

**注意**，监听键盘按键事件的库 pynput 库要求在有显示器设备的环境启动，否则不能监听键盘的按键．

### 制作镜像和容器

如果已经启动容器，可以跳过此节．

首先制作镜像，镜像依赖 ROS2 Humble 环境构建．

```bash
docker build -f ./docker/Dockerfile -t robot_client:latest
```

或者直接从导出的容器 docker/robot_client_container.tar 加载为镜像：

```bash
docker import docker/robot_client_container.tar robot_client:latest
```

创建容器：

```bash
bash scripts/create_client_container.sh
```

### 控制和推理

进入容器，确认在目录 /robot_client 下，执行命令：

```bash
python3 robot_client.py \
    --port 8010 \
    --args.task "Pick up the bottle" \
    --args.replan_steps 30 \
    --args.hz 15 \
    --args.use_edge_triggered_gripper
```

随后，终端进入交互场景，等待观察数据获取完毕后，可以按照提示交互．

## ZeroVLA

```
# joint + gripper
10.90.79.79:4577
# ee pose + gripper
10.90.79.79:4578
```
import cv2
import numpy as np
from pathlib import Path
from typing import Callable, Any

def write_chw_rgb(path: str | Path, image: np.ndarray, bgr2rgb: bool = True):
    hwc_rgb = image.transpose(1, 2, 0)  # H W C
    hwc_rgb = (hwc_rgb * 255).astype(np.uint8)
    image_path = Path(path)
    image_path.parent.mkdir(exist_ok=True, parents=True)
    if bgr2rgb:
        hwc_rgb = cv2.cvtColor(hwc_rgb, cv2.COLOR_RGB2BGR)
    cv2.imwrite(str(image_path), hwc_rgb)

def extract_action_chunk(
    prediction: dict[str, Any],
    action_dim: int | None = None,
) -> np.ndarray:
    raw = prediction.get("actions")
    if raw is None:
        raw = prediction.get("action")
    if raw is None:
        raise KeyError("Prediction has no 'action' or 'actions' key")

    actions = np.asarray(raw)
    if actions.ndim == 3:
        actions = actions[0]
    if action_dim is not None and actions.shape[-1] > action_dim:
        actions = actions[..., :action_dim]
    return actions


def dict_apply(x: dict[str, Any], fn: Callable[[Any], Any]) -> dict[str, Any]:
    result = {}
    for k, v in x.items():
        if isinstance(v, dict):
            result[k] = dict_apply(v, fn)
        elif isinstance(v, list):
            result[k] = [fn(e) for e in v]
        else:
            result[k] = fn(v)
    return result
from ros2_robot_omni import (
    TopicSpec,
    ObservationSpec,
    PublisherSpec,
    RobotTopics,
    Robot,
    decode_image,
    joint_state_to_array,
    pose_stamped_to_array,
)

from sensor_msgs.msg import JointState, CompressedImage
from geometry_msgs.msg import PoseStamped


# ========== 提取的配置 ==========
# 1. topics（订阅话题）
topics = [
    # 相机组（同步）
    TopicSpec(
        topic_name="/camera/camera/color/image_raw/compressed",
        msg_type=CompressedImage,
        transform=decode_image,
        sync_group="cameras",
    ),
    TopicSpec(
        topic_name="/camera/hand_left/color/image_rect_raw/compressed",
        msg_type=CompressedImage,
        transform=decode_image,
        sync_group="cameras",
    ),
    TopicSpec(
        topic_name="/camera/hand_right/color/image_rect_raw/compressed",
        msg_type=CompressedImage,
        transform=decode_image,
        sync_group="cameras",
    ),
    # 左臂关节
    TopicSpec(
        topic_name="/hdas/feedback_arm_left",
        msg_type=JointState,
        transform=joint_state_to_array,
    ),
    # 右臂关节
    TopicSpec(
        topic_name="/hdas/feedback_arm_right",
        msg_type=JointState,
        transform=joint_state_to_array,
    ),
    # 左夹爪
    TopicSpec(
        topic_name="/hdas/feedback_gripper_left",
        msg_type=JointState,
        transform=joint_state_to_array,
    ),
    # 右夹爪
    TopicSpec(
        topic_name="/hdas/feedback_gripper_right",
        msg_type=JointState,
        transform=joint_state_to_array,
    ),
    # 左臂末端位姿
    TopicSpec(
        topic_name="/motion_control/pose_ee_arm_left",
        msg_type=PoseStamped,
        transform=pose_stamped_to_array,
    ),
    # 右臂末端位姿
    TopicSpec(
        topic_name="/motion_control/pose_ee_arm_right",
        msg_type=PoseStamped,
        transform=pose_stamped_to_array,
    ),
    # 躯干关节
    TopicSpec(
        topic_name="/hdas/feedback_torso",
        msg_type=JointState,
        transform=joint_state_to_array,
    ),
]

# 2. observations（观测项，每个观测直接对应一个话题）
observations = [
    ObservationSpec(
        key="observation.state.left_ee_pose",
        source_topics=["/motion_control/pose_ee_arm_left"],
        transform=lambda x: x,  # 直接返回
    ),
    ObservationSpec(
        key="observation.state.right_ee_pose",
        source_topics=["/motion_control/pose_ee_arm_right"],
        transform=lambda x: x,
    ),
    ObservationSpec(
        key="observation.state.torso",
        source_topics=["/hdas/feedback_torso"],
        transform=lambda x: x,
    ),
    ObservationSpec(
        key="observation.state.left_arm",
        source_topics=["/hdas/feedback_arm_left"],
        transform=lambda x: x,
    ),
    ObservationSpec(
        key="observation.state.right_arm",
        source_topics=["/hdas/feedback_arm_right"],
        transform=lambda x: x,
    ),
    ObservationSpec(
        key="observation.state.left_gripper",
        source_topics=["/hdas/feedback_gripper_left"],
        transform=lambda x: x,
    ),
    ObservationSpec(
        key="observation.state.right_gripper",
        source_topics=["/hdas/feedback_gripper_right"],
        transform=lambda x: x,
    ),
    ObservationSpec(
        key="observation.images.head_rgb",
        source_topics=["/camera/camera/color/image_raw/compressed"],
        transform=lambda x: x,
    ),
    ObservationSpec(
        key="observation.images.left_hand_rgb",
        source_topics=["/camera/hand_left/color/image_rect_raw/compressed"],
        transform=lambda x: x,
    ),
    ObservationSpec(
        key="observation.images.right_hand_rgb",
        source_topics=["/camera/hand_right/color/image_rect_raw/compressed"],
        transform=lambda x: x,
    ),
]

# 3. publishers（发布器）
publishers = [
    PublisherSpec(
        topic_name="/motion_target/target_joint_state_arm_left",
        msg_type=JointState,
        identifier="arm_left_publisher",
    ),
    PublisherSpec(
        topic_name="/motion_target/target_joint_state_arm_right",
        msg_type=JointState,
        identifier="arm_right_publisher",
    ),
    PublisherSpec(
        topic_name="/motion_target/target_position_gripper_left",
        msg_type=JointState,
        identifier="gripper_left_publisher",
    ),
    PublisherSpec(
        topic_name="/motion_target/target_position_gripper_right",
        msg_type=JointState,
        identifier="gripper_right_publisher",
    ),
    PublisherSpec(
        topic_name="/motion_target/target_pose_arm_left",
        msg_type=PoseStamped,
        identifier="left_ee_pose_publisher",
    ),
    PublisherSpec(
        topic_name="/motion_target/target_pose_arm_right",
        msg_type=PoseStamped,
        identifier="right_ee_pose_publisher",
    ),
    PublisherSpec(
        topic_name="/motion_target/target_joint_state_torso",
        msg_type=JointState,
        identifier="torso_publisher",
    ),
]

robot_topics = RobotTopics(topics=topics, observations=observations, publishers=publishers)
r1pro_robot = Robot(config=robot_topics)
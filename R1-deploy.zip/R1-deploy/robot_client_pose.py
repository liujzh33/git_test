import rclpy
from pynput import keyboard
from websocket_policy_client import WebsocketClientPolicy
from copy import deepcopy
import time
import numpy as np
import dataclasses
import argparse

from ros2_robot_pose import R1ProRobot
from utils import extract_action_chunk


@dataclasses.dataclass
class Args:
    host: str = "127.0.0.1"
    port: int = 8000

    task: str = "Pick up the bottle"
    replan_steps: int = 10  # 请求模型预测 action chunk 后，执行的步数
    hz: int = 15  # 模型预测的动作后，执行的频率
    delay_ms_before_infer: int = 0  # 请求前等待的毫秒数，配合与 loop 用
    use_edge_triggered_gripper: bool = False  # 用跳变状态控制机器人

    save_observation_image: bool = False  # 保存当前机器人收到的图像

    # 控制请求字典的 key
    head_rgb_frame_key: str = "observation.image3"
    left_wrist_rgb_frame_key: str = "observation.image1"
    right_wrist_rgb_frame_key: str = "observation.image2"
    state_frame_key: str = "state"
    action_frame_key: str = "action"

    is_joint_angle: bool = False


HELP_TEXT = """
Robot client:
    a - Send a single action. Requesting at first if the action queue is empty,.
    r - Just request for server.
    l - Looping the workflow: send actions at a specific rate, request if neccessary.
    p - Pause looping.
    q - quit.
"""


def main(args: Args):
    print(f"args is {args}")
    rclpy.init()
    robot = R1ProRobot(
        head_rgb_frame_key=args.head_rgb_frame_key,
        left_wrist_rgb_frame_key=args.left_wrist_rgb_frame_key,
        right_wrist_rgb_frame_key=args.right_wrist_rgb_frame_key,
        state_frame_key=args.state_frame_key,
        action_frame_key=args.action_frame_key,
    )
    host = args.host
    port = args.port
    print(f"Connecting on {host}:{port}")

    policy_client = WebsocketClientPolicy(host=host, port=port)
    print("Connected")
    from collections import deque

    actions = deque()
    context = {"action_index": 0, "quit": False, "loop": False, "has_shown_help": False}
    task = args.task
    obs = {"prompt": task, "task": task}

    print(f"args is {args}")

    def get_actions():
        print("Requesting robot observation...")
        if not obs:
            print("No observation")
            return
        prediction = policy_client.infer(obs)
        prediction_actions = extract_action_chunk(prediction, action_dim=16)
        prediction_actions = prediction_actions[: args.replan_steps]
        print(f"Received num of actions {len(prediction_actions)}")
        print(f"Received actions {prediction_actions[:5]}...")

        if args.use_edge_triggered_gripper:
            gripper_states = (prediction_actions[:, -1] > 0.5).astype(np.int32)
            change = np.diff(gripper_states, prepend=gripper_states[0])
            output_actions = []
            print("Processing gripper state")
            for i in range(len(change)):
                print(f"In {i}-th turn, change[i] is {change[i]}")
                if change[i] == 1:
                    print(f"change {change[i]}")
                    prediction_actions[i, -1] = 0.2
                    output_actions.append(prediction_actions[i])
                elif change[i] == -1:
                    print(f"change {change[i]}")
                    prediction_actions[i, -1] = 100.0
                    output_actions.append(prediction_actions[i])
                else:
                    print("Gripper state has no changed")
                    output_actions.append(prediction_actions[i, :7])
            prediction_actions = output_actions

        context["action_index"] = 0
        actions.clear()
        actions.extend(prediction_actions)

    def update_observation():
        # 更新环境
        if robot.observation:
            if not context["has_shown_help"]:
                print(HELP_TEXT)
                context["has_shown_help"] = True
            obs.update(robot.observation)
        else:
            robot.get_logger().info("No obs")

    def send_action():
        if actions:
            a = actions.popleft()
            robot.send_action(a, args.is_joint_angle)
            print(
                f"Sent the {context['action_index']}-th action: {a}, remains num {len(actions)}"
            )
            context["action_index"] += 1
        else:
            print("No actions received")

    def on_press(key):
        try:
            if key.char == "a":
                print("Sending action...")
                if not actions:
                    if not obs:
                        print("No observation")
                        return
                    get_actions()
                send_action()
            elif key.char == "r":
                get_actions()
            elif key.char == "q":
                print("Quiting...")
                context["quit"] = True
            elif key.char == "l":
                print("Looping...")
                context["loop"] = True
            elif key.char == "p":
                print("Pause looping...")
                context["loop"] = False
        except Exception as e:
            print(f"Error handling key press: {e}")

    listener = keyboard.Listener(on_press=on_press)
    listener.start()
    try:
        ts_execute = time.time()
        execute_delay = 1 / args.hz
        post_delay_on_action_chunk = 0.0  # 请求 obs 前的 delay
        while rclpy.ok() and not context["quit"]:
            current_ts = time.time()
            rclpy.spin_once(robot, timeout_sec=0.001)

            if context["loop"] and ts_execute <= current_ts:
                if not actions:
                    if not obs:
                        print("No observation")
                        continue
                    get_actions()
                send_action()
                ts_execute = current_ts + execute_delay
                if not actions:
                    # 最后一轮发送数据，检查是否需要 delay 再请求
                    # wait 200ms for obs update
                    ts_execute = current_ts + post_delay_on_action_chunk
                    print(
                        f"Delay on obs, current_ts is {current_ts}, ts_execute is {ts_execute}"
                    )
            update_observation()

    except KeyboardInterrupt:
        pass
    finally:
        print("Clearing up...")
        listener.stop()
        listener.join()
        robot.destroy_node()
        rclpy.shutdown()
        print("Clean")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", type=str, default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--task", type=str, default="Pick up the bottle")
    parser.add_argument("--replan_steps", type=int, default=10)
    parser.add_argument("--is_joint_angle", type=bool, default=False)
    parser.add_argument("--hz", type=int, default=15)
    parser.add_argument("--use_edge_triggered_gripper", type=bool, default=False)
    parser.add_argument("--save_observation_image", type=bool, default=False)
    parser.add_argument("--head_rgb_frame_key", type=str, default="observation.image3")
    parser.add_argument(
        "--left_wrist_rgb_frame_key", type=str, default="observation.image1"
    )
    parser.add_argument(
        "--right_wrist_rgb_frame_key", type=str, default="observation.image2"
    )
    parser.add_argument("--state_frame_key", type=str, default="state")
    parser.add_argument("--action_frame_key", type=str, default="action")
    args = parser.parse_args()
    main(Args(**vars(args)))
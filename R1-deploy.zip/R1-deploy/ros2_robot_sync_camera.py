from rclpy.node import Node
import rclpy
from sensor_msgs.msg import JointState, CompressedImage
import copy
from dataclasses import dataclass
import numpy as np
import cv2
from pathlib import Path
from utils import write_chw_rgb
from datetime import datetime
from message_filters import ApproximateTimeSynchronizer
import message_filters


def decode_image_from_compressed(proto_msg: CompressedImage) -> np.ndarray:
    """
    读取图像，归一化，并转换为形状 c,h,w

    CompressedImage 图像的存储已经确定，是 RGB 格式．与从文件读取不同，不再需要转换为 RGB 格式．
    """
    arr = np.frombuffer(proto_msg.data, dtype=np.uint8)
    # 默认返回 BGR
    img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    normalized = img.astype(np.float32) / 255.0
    permuted = normalized.transpose(2, 0, 1)  # hwc to chw
    return permuted


@dataclass
class RobotTopics:
    """话题配置：用户需在此填入实际的话题名称，不需要的部分设为 None"""

    head_rgb: str = "/camera/camera/color/image_raw/compressed"

    # 左臂组
    # left_wrist_rgb: str | None = "/hdas/camera_wrist_left/color/image_raw/compressed"
    left_wrist_rgb: str | None = "/camera/hand_left/color/image_rect_raw/compressed"
    left_arm_joint_state: str | None = "/hdas/feedback_arm_left"
    left_gripper_state: str | None = "/hdas/feedback_gripper_left"
    left_arm_action: str | None = "/motion_target/target_joint_state_arm_left"
    left_gripper_action: str | None = "/motion_target/target_position_gripper_left"

    # 右臂组
    # right_wrist_rgb: str | None = "/hdas/camera_wrist_right/color/image_raw/compressed"
    right_wrist_rgb: str | None = "/camera/hand_right/color/image_rect_raw/compressed"
    right_arm_joint_state: str | None = "/hdas/feedback_arm_right"
    right_gripper_state: str | None = "/hdas/feedback_gripper_right"
    right_arm_action: str | None = "/motion_target/target_joint_state_arm_right"
    right_gripper_action: str | None = "/motion_target/target_position_gripper_right"


@dataclass
class RobotState:
    """话题配置：用户需在此填入实际的话题名称，不需要的部分设为 None"""

    head_rgb: np.ndarray | None = None

    # 左臂组
    left_wrist_rgb: np.ndarray | None = None
    left_arm_joint_state: np.ndarray | None = None
    left_gripper_state: np.ndarray | None = None

    # 右臂组
    right_wrist_rgb: np.ndarray | None = None
    right_arm_joint_state: np.ndarray | None = None
    right_gripper_state: np.ndarray | None = None


class R1ProRobot(Node):
    """
    机器人控制节点
    """

    def __init__(
        self,
        robot_topics: RobotTopics = RobotTopics(),
        head_rgb_frame_key: str = "observation.image3",
        left_wrist_rgb_frame_key: str = "observation.image1",
        right_wrist_rgb_frame_key: str = "observation.image2",
        state_frame_key: str = "state",
        action_frame_key: str = "action",
        *,
        save_observation_image: bool = False,
    ) -> None:
        super().__init__("policy_node")

        self.head_rgb_frame_key = head_rgb_frame_key
        self.left_wrist_rgb_frame_key = left_wrist_rgb_frame_key
        self.right_wrist_rgb_frame_key = right_wrist_rgb_frame_key
        self.state_frame_key = state_frame_key
        self.action_frame_key = action_frame_key

        self.robot_topics = robot_topics
        self.pub_arm_left = self.create_publisher(
            JointState,
            self.robot_topics.left_arm_action,
            10,
        )
        self.pub_arm_right = self.create_publisher(
            JointState,
            self.robot_topics.right_arm_action,
            10,
        )
        self.pub_gripper_left = self.create_publisher(
            JointState,
            self.robot_topics.left_gripper_action,
            10,
        )
        self.pub_gripper_right = self.create_publisher(
            JointState,
            self.robot_topics.right_gripper_action,
            10,
        )
        self.pub_torso = self.create_publisher(
            JointState,
            "/motion_target/target_joint_state_torso",
            10,
        )

        self.create_subscription(
            JointState, self.robot_topics.left_arm_joint_state, self.arm_left_cb, 10
        )
        self.create_subscription(
            JointState, self.robot_topics.right_arm_joint_state, self.arm_right_cb, 10
        )
        self.create_subscription(
            JointState, self.robot_topics.left_gripper_state, self.gripper_left_cb, 10
        )
        self.create_subscription(
            JointState,
            self.robot_topics.right_gripper_state,
            self.gripper_right_cb,
            10,
        )

        qos_profile = rclpy.qos.QoSProfile(
            reliability=rclpy.qos.ReliabilityPolicy.BEST_EFFORT,  # RELIABLE # BEST_EFFORT
            history=rclpy.qos.HistoryPolicy.KEEP_LAST,
            depth=10,
            # durability=rclpy.qos.DurabilityPolicy.TRANSIENT_LOCAL,
        )
        self.head_rgb_sub = message_filters.Subscriber(
            self, CompressedImage, self.robot_topics.head_rgb, qos_profile=qos_profile
        )

        # 右胸相机订阅
        self.right_wrist_rgb_sub = message_filters.Subscriber(
            self,
            CompressedImage,
            self.robot_topics.right_wrist_rgb,
            qos_profile=qos_profile,
        )

        # 左胸相机订阅
        self.left_wrist_rgb_sub = message_filters.Subscriber(
            self,
            CompressedImage,
            self.robot_topics.left_wrist_rgb,
            qos_profile=qos_profile,
        )

        self.ts = ApproximateTimeSynchronizer(
            [
                self.head_rgb_sub,  # 原相机
                self.left_wrist_rgb_sub,  # 左胸相机
                self.right_wrist_rgb_sub,  # 右胸相机
            ],
            queue_size=qos_profile.depth,  # 保持原队列大小
            slop=0.1,  # 允许的最大时间差（单位：秒，可根据实际情况调整）
        )

        self.ts.registerCallback(self.sync_camera_cb)

        self.robot_state = RobotState()

        self._local_image_count = 0

        if save_observation_image:
            self.timer = self.create_timer(1, self.timer_cb)
        print("Robot ok")

    @property
    def observation(self) -> dict[str, np.ndarray] | None:
        if any(
            (
                self.robot_state.head_rgb is None,
                self.robot_state.right_wrist_rgb is None,
                self.robot_state.right_arm_joint_state is None,
                self.robot_state.right_gripper_state is None,
            )
        ):
            if self.robot_state.head_rgb is None:
                self.get_logger().warn("Head rgb not ok")
            if self.robot_state.right_wrist_rgb is None:
                self.get_logger().warn("Right rgb not ok")
            if self.robot_state.right_arm_joint_state is None:
                self.get_logger().warn("Right joint state not ok")
            if self.robot_state.right_gripper_state is None:
                self.get_logger().warn("Right gripper not OK")
            return None
        res = {
            self.head_rgb_frame_key: copy.deepcopy(self.robot_state.head_rgb),
            self.left_wrist_rgb_frame_key: copy.deepcopy(
                self.robot_state.left_wrist_rgb
            ),
            self.right_wrist_rgb_frame_key: copy.deepcopy(
                self.robot_state.right_wrist_rgb
            ),
            self.state_frame_key: copy.deepcopy(
                np.concatenate(
                    [
                        self.robot_state.right_arm_joint_state,
                        self.robot_state.right_gripper_state,
                    ],
                    axis=-1,
                )
            ),
        }
        return res

    def arm_left_cb(self, msg: JointState):
        self.robot_state.left_arm_joint_state = np.array(msg.position).astype(
            np.float32
        )

    def arm_right_cb(self, msg: JointState):
        self.robot_state.right_arm_joint_state = np.array(msg.position).astype(
            np.float32
        )

    def gripper_left_cb(self, msg: JointState):
        self.robot_state.left_gripper_state = np.array(msg.position).astype(np.float32)

    def gripper_right_cb(self, msg: JointState):
        self.robot_state.right_gripper_state = np.array(msg.position).astype(np.float32)

    def img_high_cb(self, msg: CompressedImage):
        self.robot_state.head_rgb = decode_image_from_compressed(msg)

    def img_left_wrist_cb(self, msg: CompressedImage):
        self.robot_state.left_wrist_rgb = decode_image_from_compressed(msg)

    def img_right_wrist_cb(self, msg: CompressedImage):
        self.robot_state.right_wrist_rgb = decode_image_from_compressed(msg)

    def sync_camera_cb(
        self,
        head_rgb: CompressedImage,
        left_rgb: CompressedImage,
        right_rgb: CompressedImage,
    ):
        self.robot_state.head_rgb = decode_image_from_compressed(head_rgb)
        self.robot_state.left_wrist_rgb = decode_image_from_compressed(left_rgb)
        self.robot_state.right_wrist_rgb = decode_image_from_compressed(right_rgb)

    def timer_cb(self):
        obs = self.observation
        if obs is None:
            print("Robot observation not ready.")
            return
        head_rgb = obs[self.head_rgb_frame_key]
        wrist_rgb = obs[self.right_wrist_rgb_frame_key]
        now = datetime.now().strftime("%Y_%m_%d-%H_%M_%S")
        head_rgb_path = Path(f"obs/head_rgb/{now}.png")
        head_rgb_path.parent.mkdir(exist_ok=True, parents=True)
        wrist_rgb_path = Path(f"obs/wrist_rgb/{now}.png")
        wrist_rgb_path.parent.mkdir(exist_ok=True, parents=True)
        write_chw_rgb(head_rgb_path, head_rgb)
        write_chw_rgb(wrist_rgb_path, wrist_rgb)

    def send_action(self, action: np.ndarray):
        """
        shape (8,)，前 7 个动作对应右臂的关节角．最后一个对应夹爪的值．
        """
        right_arm_action = JointState()
        right_arm_action.position = action[:7].tolist()
        right_arm_action.velocity = [0.5] * 7
        self.pub_arm_right.publish(right_arm_action)
        if action.shape[0] < 8:
            return
        right_gripper_action = JointState()
        right_gripper_action.position = action[7:].tolist()
        right_gripper_action.velocity = [0.3] * 1
        self.pub_gripper_right.publish(right_gripper_action)
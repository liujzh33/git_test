"""Websocket inference server for RLDX-1 on R1 real-robot deploy."""

from __future__ import annotations

import asyncio
import http
import logging
import os
import socket
import traceback
import warnings
from dataclasses import dataclass
from time import time

import msgpack_numpy
import tyro
import websockets.asyncio.server as _server
import websockets.frames

from r1_rldx_adapter import (
    is_rldx_nested_obs,
    rldx_action_to_wire,
    unwrap_wire_payload,
    wire_obs_to_rldx_obs,
)
from rldx.data.embodiment_tags import EmbodimentTag
from rldx.policy.rldx_policy import RLDXPolicy

warnings.simplefilter("ignore", category=FutureWarning)
logger = logging.getLogger(__name__)


@dataclass
class ServerConfig:
    """RLDX-1 websocket server for R1-deploy clients."""

    model_path: str
    """Path to the RLDX-1 checkpoint directory."""

    embodiment_tag: EmbodimentTag = EmbodimentTag.GENERAL_EMBODIMENT
    """Embodiment tag stored in the checkpoint / processor."""

    host: str = "0.0.0.0"
    port: int = 8010
    device: str = "cuda"
    strict: bool = False
    """Set False when using R1 flat wire obs via r1_rldx_adapter."""

    sample_timestep_from_beta_dist: bool = False
    denoising_timesteps: list[float] | None = None
    deactivate_memory: bool = False
    verbose: bool = False

    rtc_inference_mode: str | None = None
    rtc_inference_delay: int | None = None
    rtc_inference_exec_horizon: int | None = None
    rtc_jacobian_beta: float | None = None
    rtc_jacobian_steps_only: int | None = None


class RLDXWebsocketPolicy:
    """Thin wrapper: wire obs → RLDXPolicy.get_action → wire response."""

    def __init__(self, policy: RLDXPolicy) -> None:
        self.policy = policy

    def infer(self, payload: dict, options: dict | None = None) -> dict:
        wire_obs, wire_options = unwrap_wire_payload(payload)
        if options is None:
            options = wire_options

        if is_rldx_nested_obs(wire_obs):
            rldx_obs = wire_obs
        else:
            try:
                rldx_obs = wire_obs_to_rldx_obs(wire_obs, self.policy.modality_configs)
            except KeyError as exc:
                keys = list(wire_obs.keys()) if isinstance(wire_obs, dict) else type(wire_obs)
                logger.error("Wire obs conversion failed: %s | payload keys=%s", exc, keys)
                raise

        action, info = self.policy.get_action(rldx_obs, options=options)
        response = rldx_action_to_wire(action, self.policy.modality_configs)
        if info:
            response["info"] = info
        return response


class WebsocketPolicyServer:
    """Serve RLDX-1 over the R1-deploy websocket + msgpack protocol."""

    def __init__(
        self,
        policy: RLDXWebsocketPolicy,
        host: str = "0.0.0.0",
        port: int | None = None,
        metadata: dict | None = None,
    ) -> None:
        self._policy = policy
        self._host = host
        self._port = port
        self._metadata = metadata or {}
        logging.getLogger("websockets.server").setLevel(logging.INFO)

    def serve_forever(self) -> None:
        asyncio.run(self.run())

    async def run(self):
        async with _server.serve(
            self._handler,
            self._host,
            self._port,
            compression=None,
            max_size=None,
            process_request=_health_check,
        ) as server:
            await server.serve_forever()

    async def _handler(self, websocket: _server.ServerConnection):
        logger.info("Connection from %s opened", websocket.remote_address)
        packer = msgpack_numpy.Packer()
        await websocket.send(packer.pack(self._metadata))

        prev_total_time = None
        while True:
            try:
                start_time = time()
                payload = msgpack_numpy.unpackb(await websocket.recv())

                infer_time = time()
                action = self._policy.infer(payload)
                infer_time = time() - infer_time

                action["server_timing"] = {"infer_ms": infer_time * 1000}
                if prev_total_time is not None:
                    action["server_timing"]["prev_total_ms"] = prev_total_time * 1000

                await websocket.send(packer.pack(action))
                prev_total_time = time() - start_time

            except websockets.ConnectionClosed:
                logger.info("Connection from %s closed", websocket.remote_address)
                break
            except Exception:
                await websocket.send(traceback.format_exc())
                await websocket.close(
                    code=websockets.frames.CloseCode.INTERNAL_ERROR,
                    reason="Internal server error. Traceback included in previous frame.",
                )
                raise


def _health_check(
    connection: _server.ServerConnection, request: _server.Request
) -> _server.Response | None:
    if request.path == "/healthz":
        return connection.respond(http.HTTPStatus.OK, "OK\n")
    return None


def build_policy(config: ServerConfig) -> RLDXWebsocketPolicy:
    if config.model_path.startswith("/") and not os.path.exists(config.model_path):
        raise FileNotFoundError(f"Model path does not exist: {config.model_path}")

    policy = RLDXPolicy(
        embodiment_tag=config.embodiment_tag,
        model_path=config.model_path,
        device=config.device,
        strict=config.strict,
        sample_timestep_from_beta_dist=config.sample_timestep_from_beta_dist,
        denoising_timesteps=config.denoising_timesteps,
        verbose=config.verbose,
        deactivate_memory=config.deactivate_memory,
        rtc_inference_mode=config.rtc_inference_mode,
        rtc_inference_delay=config.rtc_inference_delay,
        rtc_inference_exec_horizon=config.rtc_inference_exec_horizon,
        rtc_jacobian_beta=config.rtc_jacobian_beta,
        rtc_jacobian_steps_only=config.rtc_jacobian_steps_only,
    )
    return RLDXWebsocketPolicy(policy)


def main(config: ServerConfig | None = None) -> None:
    if config is None:
        config = tyro.cli(ServerConfig)

    hostname = socket.gethostname()
    local_ip = socket.gethostbyname(hostname)
    print(f"Starting RLDX-1 websocket server on {config.host}:{config.port}")
    print(f"  host={hostname}, ip={local_ip}")
    print(f"  model_path={config.model_path}")
    print(f"  embodiment_tag={config.embodiment_tag}")

    metadata = {
        "policy": "rldx-1",
        "embodiment_tag": config.embodiment_tag.value,
        "model_path": config.model_path,
    }
    server = WebsocketPolicyServer(
        build_policy(config),
        host=config.host,
        port=config.port,
        metadata=metadata,
    )
    server.serve_forever()


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    main()

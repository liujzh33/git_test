#!/usr/bin/env python3
"""Load xinhaitu subtask weights and run one dummy inference."""

import argparse
import logging
import os
import sys
import time
from pathlib import Path

import torch
from PIL import Image
from transformers import AutoProcessor

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "bak"))

from models.motus_wan_vlm_direct_mask import MotusWanVlmDirectMask, MotusWanVlmDirectMaskConfig
from server_client.server_vlm_mask import (  # noqa: E402
    build_vlm_inputs,
    compose_multiview_image,
    image_to_tensor,
    load_t5_embeddings,
    load_yaml_config,
    resize_image_with_padding,
)


log = logging.getLogger("test_subtask_load")


def to_float(val):
    return float(val) if isinstance(val, str) else val


def build_config(cfg, wan_path, vlm_path, video_device, vlm_device):
    common = cfg["common"]
    model_cfg = cfg["model"]
    return MotusWanVlmDirectMaskConfig(
        wan_checkpoint_path=wan_path,
        vae_path=os.path.join(wan_path, "Wan2.2_VAE.pth"),
        wan_config_path=wan_path,
        vlm_checkpoint_path=vlm_path,
        video_precision="bfloat16",
        action_state_dim=common["state_dim"],
        action_dim=common["action_dim"],
        action_expert_dim=model_cfg["action_expert"]["hidden_size"],
        action_expert_ffn_dim_multiplier=model_cfg["action_expert"]["ffn_dim_multiplier"],
        action_expert_norm_eps=to_float(model_cfg["action_expert"].get("norm_eps", 1e-6)),
        vlm_dim=model_cfg["qwen3_expert"]["vlm_dim"],
        qwen3_expert_head_dim=model_cfg["qwen3_expert"]["head_dim"],
        qwen3_expert_num_heads=model_cfg["qwen3_expert"]["num_heads"],
        qwen3_expert_num_layers=model_cfg["qwen3_expert"]["num_layers"],
        qwen3_expert_norm_eps=to_float(model_cfg["qwen3_expert"].get("norm_eps", 1e-5)),
        global_downsample_rate=common["global_downsample_rate"],
        video_action_freq_ratio=common["video_action_freq_ratio"],
        num_video_frames=common["num_video_frames"],
        video_height=common["video_height"],
        video_width=common["video_width"],
        batch_size=1,
        video_loss_weight=model_cfg["loss_weights"]["video_loss_weight"],
        action_loss_weight=model_cfg["loss_weights"]["action_loss_weight"],
        training_mode="finetune",
        load_pretrained_backbones=False,
        vlm_frozen=bool(model_cfg.get("vlm", {}).get("frozen", False)),
        video_device=video_device,
        vlm_device=vlm_device,
        subtask_prediction=model_cfg.get("subtask_prediction"),
        progress_detection=model_cfg.get("progress_detection"),
    )


def compare_keys(model, ckpt_path):
    checkpoint = torch.load(ckpt_path, map_location="cpu")
    state_dict = checkpoint["module"]
    model_keys = set(model.state_dict().keys())
    ckpt_keys = set(state_dict.keys())
    missing = sorted(model_keys - ckpt_keys)
    unexpected = sorted(ckpt_keys - model_keys)
    shape_mismatch = []
    for key in sorted(model_keys & ckpt_keys):
        if tuple(model.state_dict()[key].shape) != tuple(state_dict[key].shape):
            shape_mismatch.append(
                (key, tuple(model.state_dict()[key].shape), tuple(state_dict[key].shape))
            )
    extra = [k for k in sorted(ckpt_keys) if k.startswith(("subtask_", "progress_mlp_"))]
    return {
        "ckpt_keys": len(ckpt_keys),
        "model_keys": len(model_keys),
        "missing": missing,
        "unexpected": unexpected,
        "shape_mismatch": shape_mismatch,
        "subtask_progress_keys": extra,
    }


def dummy_t_image(height, width):
    head = Image.new("RGB", (640, 480), (40, 80, 160))
    left = Image.new("RGB", (320, 240), (40, 160, 80))
    right = Image.new("RGB", (320, 240), (160, 80, 40))
    return compose_multiview_image([head, left, right], size_hw=(height, width))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_config", default=str(ROOT / "configs/xinghaitu_subtask_deploy.yaml"))
    parser.add_argument("--ckpt_dir", default="/data/checkpoint/xinhaitu_subtask/xinhaitu_subtask/40000")
    parser.add_argument("--wan_path", default="/data/liujingzhi/Motus/pretrained_models/Wan2.2-TI2V-5B")
    parser.add_argument("--vlm_path", default="/data/liujingzhi/Motus/pretrained_models/Qwen3-VL-2B-Instruct")
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--vlm_device", default="cuda:1")
    parser.add_argument(
        "--instruction_file",
        default="/data/liujingzhi/xinghaitu_deploy_t5_embeddings/t5_by_hash/bf9581c3f5611d807e358e1cf61ac96a.txt",
    )
    parser.add_argument(
        "--t5_path",
        default="/data/liujingzhi/xinghaitu_deploy_t5_embeddings/t5_by_hash/bf9581c3f5611d807e358e1cf61ac96a.pt",
    )
    parser.add_argument("--steps", type=int, default=10)
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
    cfg = load_yaml_config(args.model_config)
    common = cfg["common"]
    ckpt_file = Path(args.ckpt_dir) / "mp_rank_00_model_states.pt"
    if not ckpt_file.exists():
        raise FileNotFoundError(ckpt_file)

    log.info("Building model on video=%s vlm=%s", args.device, args.vlm_device)
    model = MotusWanVlmDirectMask(
        build_config(cfg, args.wan_path, args.vlm_path, args.device, args.vlm_device)
    )
    stats = compare_keys(model, str(ckpt_file))
    print("=== checkpoint vs model ===")
    print("ckpt_keys", stats["ckpt_keys"], "model_keys", stats["model_keys"])
    print("missing", len(stats["missing"]))
    print("unexpected", len(stats["unexpected"]))
    print("shape_mismatch", len(stats["shape_mismatch"]))
    print("subtask/progress keys", len(stats["subtask_progress_keys"]))
    if stats["missing"][:10]:
        print("missing sample:", stats["missing"][:10])
    if stats["unexpected"][:10]:
        print("unexpected sample:", stats["unexpected"][:10])
    if stats["shape_mismatch"][:10]:
        print("shape mismatch sample:", stats["shape_mismatch"][:10])

    extra_present = all(
        hasattr(model, name)
        for name in ("subtask_text_decoder", "subtask_action_memory_proj", "progress_mlp_in", "progress_mlp_out")
    )
    print("subtask heads constructed:", extra_present)
    print("subtask_enabled:", model.subtask_prediction_enabled, "mode:", model.subtask_mode)
    print("progress_enabled:", model.progress_detection_enabled)

    model.load_checkpoint(args.ckpt_dir, strict=False)
    model.eval()
    model.vlm_model = model.vlm_model.to(args.vlm_device)

    processor = AutoProcessor.from_pretrained(args.vlm_path, trust_remote_code=True)
    instruction = Path(args.instruction_file).read_text(encoding="utf-8").strip()
    t5 = load_t5_embeddings(args.t5_path, torch.device(args.device))
    image = dummy_t_image(common["video_height"], common["video_width"])
    first_frame = image_to_tensor(image, (common["video_height"], common["video_width"])).to(args.device)
    state = torch.zeros((1, common["state_dim"]), dtype=torch.float32, device=args.device)
    vlm_inputs = [build_vlm_inputs(processor, instruction, resize_image_with_padding(image, (common["video_height"], common["video_width"])), torch.device(args.vlm_device))]

    print("=== dummy inference ===")
    t0 = time.time()
    with torch.inference_mode():
        frames, actions, progress, subtask = model.inference_step(
            first_frame=first_frame,
            state=state,
            num_inference_steps=args.steps,
            language_embeddings=t5,
            vlm_inputs=vlm_inputs,
        )
    elapsed = time.time() - t0
    action_cpu = actions.detach().float().cpu()
    if action_cpu.dim() == 3:
        action_cpu = action_cpu.squeeze(0)
    print("action_shape", tuple(action_cpu.shape))
    print("frames_shape", tuple(frames.shape))
    print("progress", None if progress is None else float(progress.detach().float().reshape(-1)[0].cpu()))
    print("subtask", repr(subtask))
    print("elapsed_s", round(elapsed, 3))
    for i, device_name in enumerate(["cuda:0", "cuda:1"]):
        if torch.cuda.is_available() and i < torch.cuda.device_count():
            allocated = torch.cuda.memory_allocated(i) / 1024**3
            reserved = torch.cuda.memory_reserved(i) / 1024**3
            print(f"{device_name} allocated={allocated:.2f}G reserved={reserved:.2f}G")

    ok = (
        tuple(action_cpu.shape) == (16, 20)
        and extra_present
        and len(stats["missing"]) == 0
        and len(stats["shape_mismatch"]) == 0
        and model.subtask_prediction_enabled
        and model.progress_detection_enabled
        and subtask is not None
        and str(subtask).strip() != ""
    )
    print("PASS" if ok else "FAIL")
    if not ok:
        raise SystemExit(1)


if __name__ == "__main__":
    main()

#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CODE_DIR="${CODE_DIR:-$ROOT/xinhaitu-main}"
ENV_DIR="${ENV_DIR:-}"

if [[ -z "$ENV_DIR" ]]; then
  if [[ -f "$ROOT/../xinghaitu_motus_server_pack/motus_env/bin/activate" ]]; then
    ENV_DIR="$ROOT/../xinghaitu_motus_server_pack/motus_env"
  elif [[ -f "$ROOT/motus_env/bin/activate" ]]; then
    ENV_DIR="$ROOT/motus_env"
  fi
fi

if [[ -n "${ENV_DIR}" && -f "$ENV_DIR/bin/activate" ]]; then
  # shellcheck disable=SC1091
  source "$ENV_DIR/bin/activate"
fi

: "${CKPT_DIR:?Set CKPT_DIR to the xinhaitu_subtask checkpoint dir that contains mp_rank_00_model_states.pt}"
: "${WAN_PATH:?Set WAN_PATH to the Wan2.2-TI2V-5B directory}"
: "${VLM_PATH:?Set VLM_PATH to the Qwen3-VL-2B-Instruct directory}"

HOST="${HOST:-0.0.0.0}"
PORT="${PORT:-8001}"
MODEL_CONFIG="${MODEL_CONFIG:-$CODE_DIR/configs/xinghaitu_subtask_deploy.yaml}"
DEVICE="${DEVICE:-cuda:0}"
VLM_DEVICE="${VLM_DEVICE:-cuda:1}"

if [[ ! -f "$CKPT_DIR/mp_rank_00_model_states.pt" ]]; then
  echo "CKPT_DIR has no mp_rank_00_model_states.pt: $CKPT_DIR" >&2
  echo "Point it at the 40000/ directory, not a parent or pytorch_model subdir." >&2
  exit 1
fi
if [[ ! -f "$WAN_PATH/Wan2.2_VAE.pth" ]]; then
  echo "WAN_PATH has no Wan2.2_VAE.pth: $WAN_PATH" >&2
  exit 1
fi
if [[ ! -d "$VLM_PATH" ]]; then
  echo "VLM_PATH not found: $VLM_PATH" >&2
  exit 1
fi
if [[ ! -f "$MODEL_CONFIG" ]]; then
  echo "MODEL_CONFIG not found: $MODEL_CONFIG" >&2
  exit 1
fi

export PYTHONPATH="$CODE_DIR:$CODE_DIR/bak${PYTHONPATH:+:$PYTHONPATH}"
cd "$CODE_DIR"

CMD=(
  python server_client/server_vlm_mask.py
  --model_config "$MODEL_CONFIG"
  --ckpt_dir "$CKPT_DIR"
  --wan_path "$WAN_PATH"
  --vlm_path "$VLM_PATH"
  --device "$DEVICE"
  --vlm_device "$VLM_DEVICE"
  --host "$HOST"
  --port "$PORT"
)

if [[ -n "${DEFAULT_INSTRUCTION_FILE:-}" ]]; then
  CMD+=(--default_instruction_file "$DEFAULT_INSTRUCTION_FILE")
fi
if [[ -n "${DEFAULT_T5_EMBEDDINGS_PATH:-}" ]]; then
  CMD+=(--default_t5_embeddings_path "$DEFAULT_T5_EMBEDDINGS_PATH")
fi
if [[ -n "${T5_EMBEDDINGS_DIR:-}" ]]; then
  CMD+=(--t5_embeddings_dir "$T5_EMBEDDINGS_DIR")
fi
if [[ -n "${DEFAULT_INSTRUCTION:-}" ]]; then
  CMD+=(--default_instruction "$DEFAULT_INSTRUCTION")
fi

echo "Launching Motus xinghaitu subtask server"
printf '  %q' "${CMD[@]}"
printf '\n'

exec "${CMD[@]}"
